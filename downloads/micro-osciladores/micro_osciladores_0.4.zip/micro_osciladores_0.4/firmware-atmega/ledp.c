//--------------------------------------------
//-- ledp.c
//------------------------------------
//-- Juan Gonzalez Gomez (Obijuan)
//-- Skymega "hello world" program
//---------------------------------------

#define F_CPU 16000000          
#include <avr/io.h>
#include <util/delay.h>


int main(void)
{
  //-- Configurar led (bit 5 del puerto B)
  DDRB= 0x20;

  for(;;) {
    PORTB = 0x20;
    _delay_ms(100);
    PORTB = 0x0;
    _delay_ms(100);
  }

  return 0;
}

