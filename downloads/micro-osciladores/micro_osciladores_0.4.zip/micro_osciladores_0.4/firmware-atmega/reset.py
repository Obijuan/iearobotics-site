 #!/usr/bin/env python
 # -*- coding: iso-8859-15 -*-

import serial
import time

s = serial.Serial("/dev/ttyUSB0")

s.setRTS(0);
time.sleep(0.100);
s.setRTS(1);




