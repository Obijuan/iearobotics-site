How to test

1) Compile with make:
$ make

2) Download into the skymega microcontroller:

$ ./d328 ledp.hex

