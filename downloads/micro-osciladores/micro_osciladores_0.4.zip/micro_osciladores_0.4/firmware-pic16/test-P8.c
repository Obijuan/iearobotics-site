/*****************************************************************************/
/* test-P8.c  Enero-2010                                                     */
/*---------------------------------------------------------------------------*/
/* Ejemplo de movimiento de un robot de 8 modulos del grupo cabecep-cabeceo  */
/* Se ha probado con el robot Cube Revolutions:                              */
/* http://www.iearobotics.com/wiki/index.php?title=Cube_Revolutions          */
/*---------------------------------------------------------------------------*/
/*  Juan Gonzalez <juan@iearobotics.com>                                     */
/*  Andres Prieto-Moreno <andres@iearobotics.com>                            */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

//-- Especificar el pic a emplear
#include <pic16f877.h>
#include "servos.h"
#include "oscillator-pn.h"

/***********************************************************************/
/*  PARAMETROS DE LAS OSCILACIONES. MODIFICABLES POR EL USUARIO        */
/***********************************************************************/
//-- Mas documentacion en el rfichero oscillator-pn.h

//-- Velocidad de fase
#define INC 4

//-- Amplitud (en grados) (0-90)
#define A 30

//-- Diferencia de fase (en grados) (-180 a 180)
#define DF -90

//--Fase inicial de los servos (en grados) (0-360)
#define FASE0 0

//-- Correspondencia entre servos virtuales y reales
//-- Cambiarlo segun el conexionado del robot y el numero de modulos usados
//-- El '0' inicial se ignora
//-- Servos virtuales:            1  2  3  4  5  6  7  8
//-- '0' significa NO-USADO

//-- Conexionado para Cube Revolutions
unsigned char v[9]={0,            7, 5, 3, 1, 2, 4, 6, 8};


/*******************************************************/
/* RUTINA DE ATENCION A LAS INTERRUPCIONES             */
/*******************************************************/
void intr(void) interrupt 0
{
  //---------------------------------------------------------------
  //-- Rutina de servicio del timer0 para actualizar las senales
  //-- de PWM
  //-----------------------------------------------------------
  if (T0IF==1)
    servos_intr();
}


//----------------------------
//- Comienzo del programa  
//----------------------------
void main(void)
{

  //-- Inicializacion del modulo de servos
  servos_init();

  //-- Inicializar los osciladores
  oscillator_init(A,DF,FASE0);
    
  //-- Habilitar Interrupciones
  GIE=1;

  //----------------------
  //-- Bucle principal
  //----------------------
  while (1) {

    //-- Refrescar osciladores
    oscillator_calculate(INC);

  } 
}

