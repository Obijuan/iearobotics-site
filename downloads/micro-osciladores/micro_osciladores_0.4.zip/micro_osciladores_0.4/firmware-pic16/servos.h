/*************************************************************************** */
/* Andres Prieto-Moreno                                                      */
/* Juan gonzalez                                                             */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

#ifndef SERVOS_H
#define SERVOS_H

//-- Constantes para habilitar los servos
#define SERVO1 0x01
#define SERVO2 0x02
#define SERVO3 0x04
#define SERVO4 0x08
#define SERVO5 0x10
#define SERVO6 0x20
#define SERVO7 0x40
#define SERVO8 0x80
#define SERVOS_ALL  0xFF
#define SERVOS_NONE 0x00

void servos_init(void);
void servos_enable_mask(unsigned char mascara);
void servos_enable(unsigned char servo);
void servos_disable(unsigned char servo);

int servos_grados2tiempo(int grados);
void servos_set_raw(int servo, int tiempo);void servos_set(int servo, int grados);
void servos_intr();


#endif

