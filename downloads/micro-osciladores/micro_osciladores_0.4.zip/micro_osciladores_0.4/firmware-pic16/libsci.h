/*************************************************************************** */
/* libsci.h                                                                  */
/*---------------------------------------------------------------------------*/
/* Ejemplo para las tarjetas SKYPIC/SKYCUBE 1.0                              */
/*---------------------------------------------------------------------------*/
/* Biblioteca de comunicaciones serie. La velocidad por defecto es de 56K    */
/* baudios                                                                   */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/


// Configurar el puerto serie
void sci_conf();

// Leer un caracter del SCI. 
unsigned char sci_read();

//-- Enviar un caracter por el SCI
void sci_write(unsigned char dato);

//-- Enviar una cadena por el SCI
void sci_cad(unsigned char *cad);
