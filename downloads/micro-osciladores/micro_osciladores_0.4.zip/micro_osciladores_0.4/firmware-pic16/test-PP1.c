/*****************************************************************************/
/* test-PP1.c  Enero-2010                                                    */
/*---------------------------------------------------------------------------*/
/* Ejemplo de movimiento de la configuracion PP                              */
/*---------------------------------------------------------------------------*/
/*  Juan Gonzalez <juan@iearobotics.com>                                     */
/*  Andres Prieto-Moreno <andres@iearobotics.com>                            */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

//-- Especificar el pic a emplear
#include <pic16f877.h>
#include "servos.h"
#include "oscillator-pn.h"

//-- Indicar la tarjeta usada: Skycube o Skypic
//-- Si la siguiente linea se comenta, se supondra una Skypic
//-- La configuracion SKYCUBE tambien es valida para una skypic on una
//-- tarjeta Skypads conectada al puerto A
#define SKYCUBE

//-- Definir el bit del pulsador de pruebas, segun la tarjeta usada
#ifdef SKYCUBE
  #define PULSADOR RA0  //-- Skycube 
#else
  #define PULSADOR RB0  //-- Skypic
#endif

//-- Constantes para determinar si pulsador esta apretado o no
#define ON       0
#define OFF      1

/***********************************************************************/
/*  PARAMETROS DE LAS OSCILACIONES. MODIFICABLES POR EL USUARIO        */
/***********************************************************************/
//-- Mas documentacion en el rfichero oscillator-pn.h

//-- Velocidad de fase
#define INC 4

//-- Amplitud (en grados) (0-90)
#define A 45

//-- Diferencia de fase (en grados) (-180 a 180)
#define DF 120

//--Fase inicial de los servos (en grados) (0-360)
#define FASE0 0

//-- Correspondencia entre servos virtuales y reales
//-- Cambiarlo segun el conexionado del robot y el numero de modulos usados
//-- El '0' inicial se ignora
//-- Servos virtuales:            1  2  3  4  5  6  7  8
//-- '0' significa NO-USADO
unsigned char v[9]={0,            2, 4, 0, 0, 0, 0, 0, 0};


/*******************************************************/
/* RUTINA DE ATENCION A LAS INTERRUPCIONES             */
/*******************************************************/
void intr(void) interrupt 0
{
  //---------------------------------------------------------------
  //-- Rutina de servicio del timer0 para actualizar las senales
  //-- de PWM
  //-----------------------------------------------------------
  if (T0IF==1)
    servos_intr();
}


//----------------------------
//- Comienzo del programa  
//----------------------------
void main(void)
{
  char inc;

  //-- Inicializacion del modulo de servos
  servos_init();

  //-- Inicializar los osciladores
  oscillator_init(A,DF,FASE0);
    
  //-- Habilitar Interrupciones
  GIE=1;

  //-- Inicializar variables
  inc = INC;

  //-- Configurar el pulsador usado. Segun la tarjeta se hara una cosa u otra
  #ifdef SKYCUBE
    ADCON1=0x06; //-- Configurar RA0 como entrada digital
    TRISA0 = 1;  //-- RA0 como entrada
  #else
    TRISB0=1;  //-- RB0 como entrada
  #endif

  //----------------------
  //-- Bucle principal
  //----------------------
  while (1) {

    //-- Refrescar osciladores
    oscillator_calculate(inc);

    //-- Si el pulsador esta apretado, cambiar el incremento de fase
    if (PULSADOR==ON) {
      inc=-inc;

      //-- Esperar hasta que el boton se suelte
      while(PULSADOR==ON);
    }
  } 
}

