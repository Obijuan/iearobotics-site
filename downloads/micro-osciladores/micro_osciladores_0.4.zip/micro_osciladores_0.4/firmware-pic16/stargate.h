/*************************************************************/
/* CONSTANTES RELACIONADAS CON EL STARGATE                   */
/*************************************************************/

//-- Identificadores de los servicios
#define SID   'I'   // Servicio de identificacion (0x49)
#define SPING 'P'   // Servicio de PING (0x50)
#define SENA  'E'   // Servicio de Habilitacion con mascara (0X45)
#define SENA2 'F'   // Servicio de habilitacion de servo (0x46)
#define SDIS  'D'   // Servicio de deshabilitacion de servo (0x44)

#define SOSCM 'M'   // Servicio de mascara de oscilacion (0x4D)
#define SON   'O'   // Servicio de activacion de oscilador (0x4F)
#define SOFF  'S'   // Servicio de desactivacion de oscilador. Stop. (0x53)


#define SPOS  'W'   // Servicio de Posicionamiento (0x57)


//-- Identificadores para la respuesta
#define RPING 'O'   // Respuesta al Servicio de PING (0x4F)
#define RSI   'I'   // RSI. Codigo de respuesta del servicio de identificacion

//----- Datos devueltos por el servicio de identificacion
#define IS  0x50    // IS. Identificacion del servidor
#define IM  0x30    // IM. Identificacion del microcontrolador
#define IPV 0x11    // IPV. SKYPIC v1
