#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
import libStargate.Oscillator

#-------------------------------------------------------
#-- Prueba 1: oscilacion + posicionamiento estatico
#-------------------------------------------------------
def prueba1(o):
  import time;

  o.on(2);
  o.on(8);
  o.off(1);

  for i in range(5):
    o.pos(1,50);
    time.sleep(1);
    o.pos(1,-50);
    time.sleep(1);


#-- Programa principal

o=libStargate.Oscillator.Open_session("/dev/ttyUSB0")
prueba1(o)


#---------------------
#-- Prueba de metodos
#---------------------

#---- enable_mask(mascara, [nodo]). Aplicar mascara de habilitacion de servos
# o.enable_mask(0xff)    #-- Habilitar todos los servos del nodo Maestro (0)
# o.enable_mask(0xff,1)  #-- Habilitar todos los servos del nodo 1

#---- enable(servo, [nodo]). Habilitar un servo. Servo entre 1 y 8. Nodo entre 0 y 255
# o.enable(1)    #-- Habilitar servo 1 del maestro (nodo 0)
# o.enable(8,2)  #-- Habilitar servo 8 del nodo 2

#---- disable(servo, [nodo]). Deshabilitar un servo. Servo entre 1 y 8. Nodo entre 0 y 255
# o.enable(1)    #-- Deshabilitar servo 1 del maestro (nodo 0)
# o.enable(8,2)  #-- Desabilitar servo 8 del nodo 2

#---- on_mask(mascara, [nodo]). Aplicar mascara de activacion de osciladores
# o.on_mask(0xff)   #-- Activar todos los osciladores del nodo Maestro (0)
# o.on_mask(0xff,1) #-- Activar todos los osciladores del nodo 1

#--- on(servo,[nodo]). Activar un oscilador
# o.on(1)   #-- Activar oscilador 1 (del nodo maestro (0))
# o.on(8,2) #-- Activar oscilador 8 del nodo 2

#--- off(servo,[nodo]). Desactivar un oscilador
# o.off(1)   #-- Desactivar oscilador 1 (del nodo maestro (0))
# o.off(8,2) #-- Desactivar oscilador 8 del nodo 2

#--- pos(servo, pos, [nodo]). Posicionamiento estatico. Solo tiene efecto en
#-- en modo OFF
# o.pos(1,45)     #-- Mover servo 1 a 45 grados (del nodo 0: maestro)
# o.pos(2,-50,8)  #-- Mover servo 2 del nodo 8 a -50 grados

