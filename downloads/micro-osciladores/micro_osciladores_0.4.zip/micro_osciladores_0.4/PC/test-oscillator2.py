#-- Prueba para comprobar los templores en los servos
#-- Se envian las posiciones al servo a la maxima velocidad (20ms)
#-- Se comprueba que no se cuelga y que las posiciones las recibe bien,
#-- sin embargo se puede apreciar el "temblor" de los servos debido a que
#-- durante el procesamiento de la trama no se genera la senal PWM

import libStargate.Oscillator
import time;

o=libStargate.Oscillator.Open_session("/dev/ttyUSB0")

#o.on(2);
#o.on(8);

o.pos(1,-70);
time.sleep(2);

for i in range(140):
  o.pos(1,-70 + i)
  time.sleep(0.020)

for i in range(140):
  o.pos(1,70-i)
  time.sleep(0.020)

