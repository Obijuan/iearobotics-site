#-------------------------------------------------------------------------------
#--  ej_posicion_ir.py
#--  Ejemplo coordenadas IR LED
#-------------------------------------------------------------------------------
#-- Carlos Pastor
#-------------------------------------------------------------------------------

#Importar modulos
import sys
import cwiid
import time

#Variables
led=0;
reintentos=0;
ok=False;

print 'Pulsa las teclas 1+2 en el Wiimote......'

#Establecer conexion con Wiimote
while reintentos<3 and not ok:
  try:
    print "Reintento ",reintentos
    if len(sys.argv) > 1:
      wiimote = cwiid.Wiimote(sys.argv[1])
    else:
      wiimote = cwiid.Wiimote()
    ok=True
  except RuntimeError, msg:
    reintentos+=1;

#Si se superan los reintentos, terminar
if reintentos==3:
  print "Sin conexion con wiimote despues de "+repr(reintentos)+" reintentos"
  sys.exit(1)

#Conexion establecida
#Encender el led 1 del wiimote
wiimote.led = cwiid.LED1_ON  

#Activamos ir
wiimote.rpt_mode = cwiid.RPT_IR 

#Bucle principal
while 1:
	#Acceder al estado del wiimote
	state = wiimote.state

	if 'ir_src' in state:
            for src in state['ir_src']:
                  if src:
                     	posicion=src['pos']
			print posicion	
		
	#Introducimos una pausa para mejorar la visualizacion
	time.sleep(0.1)

