#-------------------------------------------------------------------------------
#--  ej_wiiboard.py
#--  Ejemplo valores ofrecidos por WiiBoard
#-------------------------------------------------------------------------------
#-- Carlos Pastor
#-------------------------------------------------------------------------------

#Importar modulos
import sys
import cwiid
import time

#Variables
led=0;
reintentos=0;
ok=False;

print 'Pulsa el boton de sync de la wiiboard (donde estan las pilas)...'

#Establecer conexion con Wiimote
while reintentos<3 and not ok:
  try:
    print "Reintento ",reintentos
    if len(sys.argv) > 1:
      wiimote = cwiid.Wiimote(sys.argv[1])
    else:
      wiimote = cwiid.Wiimote()
    ok=True
  except RuntimeError, msg:
    reintentos+=1;

#Si se superan los reintentos, terminar
if reintentos==3:
  print "Sin conexion con wiimote", reintentos
  sys.exit(-1)

#Conexion establecida
#Encender el led de la wii-board
wiimote.led = cwiid.LED1_ON

#Activar la wii-board
wiimote.rpt_mode = cwiid.RPT_BALANCE

while 1:
       #Leer el estado de la wiiboard
       state = wiimote.state

       #Leer los 4 sensores de presion
       a = state['balance']['left_top']
       b = state['balance']['right_top']
       c = state['balance']['left_bottom']
       d = state['balance']['right_bottom']
       
       #Imprimir en pantalla
       str = "A=%d, B=%d, C=%d, D=%d" % (a,b,c,d)
       print str

       #Introducimos una pausa para mejorar la visualizacion
       time.sleep(0.1)  

