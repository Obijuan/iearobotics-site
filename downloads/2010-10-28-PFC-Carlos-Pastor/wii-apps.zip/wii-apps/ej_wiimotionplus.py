#-------------------------------------------------------------------------------
#--  ej_wiimotionplus.py
#--  Ejemplo valores ofrecidos por Wii Motion Plus
#-------------------------------------------------------------------------------
#-- Carlos Pastor
#-------------------------------------------------------------------------------

#Importar modulos
import sys
import cwiid
import time

#Variables
led=0;
reintentos=0;
ok=False;

print 'Pulsa las teclas 1+2 en el Wiimote......'

#Establecer conexion con Wiimote
while reintentos<3 and not ok:
  try:
    print "Reintento ",reintentos
    if len(sys.argv) > 1:
      wiimote = cwiid.Wiimote(sys.argv[1])
    else:
      wiimote = cwiid.Wiimote()
    ok=True
  except RuntimeError, msg:
    reintentos+=1;

#Si se superan los reintentos, terminar
if reintentos==3:
  print "Sin conexion con wiimote despues de "+repr(reintentos)+" reintentos"
  sys.exit(1)

#Conexion establecida
#Encendemos el led 1 del wiimote
wiimote.led = cwiid.LED1_ON  

#Activar Wii Motion Plus
wiimote.enable(cwiid.FLAG_MOTIONPLUS)
wiimote.rpt_mode = cwiid.RPT_MOTIONPLUS

#Bucle principal
while 1:
	
	if wiimote.state.has_key('motionplus'):
		#Leemos velocidades angulares del estado del wiimote
		vel_ang=wiimote.state['motionplus']['angle_rate']		
		print vel_ang

	#Introducimos una pausa para mejorar la visualizacion	
	time.sleep(0.1)

