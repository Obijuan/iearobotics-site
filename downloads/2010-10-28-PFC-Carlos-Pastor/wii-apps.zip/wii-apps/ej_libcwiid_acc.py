#-------------------------------------------------------------------------------
#--  ej_libcwiid_acc.py
#--  Ejemplo lectura acelerometro
#-------------------------------------------------------------------------------
#-- Carlos Pastor
#-------------------------------------------------------------------------------

#Importar modulos
import sys
import cwiid
import time

#Variables
led=0;
reintentos=0;
ok=False;

print 'Pulsa las teclas 1+2 en el Wiimote...'

#Establecer conexion con Wiimote
while reintentos<3 and not ok:
  try:
    print "Reintento ",reintentos
    if len(sys.argv) > 1:
      wiimote = cwiid.Wiimote(sys.argv[1])
    else:
      wiimote = cwiid.Wiimote()
    ok=True
  except RuntimeError, msg:
    reintentos+=1;

#Si se superan los reintentos, terminar
if reintentos==3:
  print "Sin conexion con wiimote", reintentos
  sys.exit(-1)

#Conexion establecida 
#Encendemos el led 1 para saber que la conexion esta establecida 
wiimote.led = cwiid.LED1_ON

#Activamos los acelerometros
wiimote.rpt_mode = cwiid.RPT_ACC

#Bucle principal
while 1:
    # Leer las aceleraciones
    acc = wiimote.state['acc']

    # Sacar por pantalla
    str = "X: %.1f, Y: %.1f, Z: %.1f " % (acc[cwiid.X],acc[cwiid.Y],acc[cwiid.Z])
    print str
    
    #Introducimos una pausa para mejorar la visualizacion
    time.sleep(0.5)

