(<alteration>)
(<alterationFile>) startP1.gcode (</alterationFile>)
( Set units to mm. )
G21 (Set units to mm)
( Set positioning to absolute. )
G90 (Absolute coordinates)
( Start at home. )
G28 (--Home all Axis ---)
G92 X0 Y0 Z0 E0 (-- Current position is 0,0,0 ---)
( Linear move to (0.0, 0.0, 5.0). )
G1 Z5.0 F300.0
( Linear move to (50.0, 50.0, 5.0). )
G1 X50 Y50 F2000.0
(</alteration>)
(<format> skeinforge gcode </format>)
(<version> 12.03.14 </version>)
(<created> 12.08.02|16:51 </created>)
(<extruderInitialization>)
( Set positioning to absolute. )
G90 ;set positioning to absolute
( Set units to mm. )
G21 ;set units to millimeters
( Extruder off. )
M103
(<craftTypeName> extrusion </craftTypeName>)
(<decimalPlacesCarried> 4 </decimalPlacesCarried>)
(<layerThickness> 0.4 </layerThickness>)
(<infillWidth> 0.6 </infillWidth>)
(<volumeFraction> 0.82 </volumeFraction>)
(<infillPerimeterOverlap> 0.15 </infillPerimeterOverlap>)
(<sharpestProduct> 0.866 </sharpestProduct>)
(<layerHeight> 0.4 </layerHeight>)
(<threadSequenceString> edge loops infill </threadSequenceString>)
(<maximumZFeedRatePerSecond> 1.0 </maximumZFeedRatePerSecond>)
(<objectFirstLayerFeedRateInfillMultiplier> 0.3 </objectFirstLayerFeedRateInfillMultiplier>)
(<operatingFeedRatePerSecond> 30.0 </operatingFeedRatePerSecond>)
(<objectFirstLayerFlowRateInfillMultiplier> 0.3 </objectFirstLayerFlowRateInfillMultiplier>)
(<operatingFlowRate> 25.0 </operatingFlowRate>)
(<orbitalFeedRatePerSecond> 15.0 </orbitalFeedRatePerSecond>)
(<travelFeedRatePerSecond> 100.0 </travelFeedRatePerSecond>)
(<skirtOutset> 2.52 </skirtOutset>)
( Turn fan on. )
M106
(<edgeWidth> 0.72 </edgeWidth>)
(<perimeterWidth> 0.72 </perimeterWidth>)
(<profileName> P1 </profileName>)
(<settings>)
(<setting> alteration Activate_Alteration True </setting>)
(<setting> alteration Name_of_End_File: endP1.gcode </setting>)
(<setting> alteration Name_of_Start_File: startP1.gcode </setting>)
(<setting> alteration Remove_Redundant_Mcode True </setting>)
(<setting> alteration Replace_Variable_with_Setting True </setting>)
(<setting> bottom Activate_Bottom True </setting>)
(<setting> bottom Additional_Height_over_Layer_Thickness_(ratio): 0.7 </setting>)
(<setting> bottom Altitude_(mm): 0.1 </setting>)
(<setting> bottom SVG_Viewer: webbrowser </setting>)
(<setting> cool Activate_Cool True </setting>)
(<setting> cool Bridge_Cool_(Celcius): 1.0 </setting>)
(<setting> cool Orbit False </setting>)
(<setting> cool Slow_Down True </setting>)
(<setting> cool Maximum_Cool_(Celcius): 2.0 </setting>)
(<setting> cool Minimum_Layer_Time_(seconds): 15.0 </setting>)
(<setting> cool Minimum_Orbital_Radius_(millimeters): 10.0 </setting>)
(<setting> cool Name_of_Cool_End_File: cool_end.gcode </setting>)
(<setting> cool Name_of_Cool_Start_File: cool_start.gcode </setting>)
(<setting> cool Orbital_Outset_(millimeters): 2.0 </setting>)
(<setting> cool Turn_Fan_On_at_Beginning True </setting>)
(<setting> cool Turn_Fan_Off_at_Ending True </setting>)
(<setting> dimension Activate_Dimension True </setting>)
(<setting> dimension Absolute_Extrusion_Distance True </setting>)
(<setting> dimension Relative_Extrusion_Distance False </setting>)
(<setting> dimension Extruder_Retraction_Speed_(mm/s): 20.0 </setting>)
(<setting> dimension Filament_Diameter_(mm): 3.3 </setting>)
(<setting> dimension Filament_Packing_Density_(ratio): 1.0 </setting>)
(<setting> dimension Maximum_E_Value_before_Reset_(float): 91234.0 </setting>)
(<setting> dimension Minimum_Travel_for_Retraction_(millimeters): 1.0 </setting>)
(<setting> dimension Retract_Within_Island False </setting>)
(<setting> dimension Retraction_Distance_(millimeters): 1.0 </setting>)
(<setting> dimension Restart_Extra_Distance_(millimeters): 0.0 </setting>)
(<setting> export Activate_Export True </setting>)
(<setting> export Add_Descriptive_Extension False </setting>)
(<setting> export Add_Export_Suffix True </setting>)
(<setting> export Add_Profile_Extension False </setting>)
(<setting> export Add_Timestamp_Extension False </setting>)
(<setting> export Also_Send_Output_To:  </setting>)
(<setting> export Analyze_Gcode True </setting>)
(<setting> export Do_Not_Delete_Comments False </setting>)
(<setting> export Delete_Crafting_Comments False </setting>)
(<setting> export Delete_All_Comments True </setting>)
(<setting> export Do_Not_Change_Output False </setting>)
(<setting> export binary_16_byte False </setting>)
(<setting> export gcode_step False </setting>)
(<setting> export gcode_time_segment False </setting>)
(<setting> export gcode_small True </setting>)
(<setting> export File_Extension: gcode </setting>)
(<setting> export Name_of_Replace_File: replace.csv </setting>)
(<setting> export Save_Penultimate_Gcode False </setting>)
(<setting> fill Activate_Fill True </setting>)
(<setting> fill Diaphragm_Period_(layers): 100 </setting>)
(<setting> fill Diaphragm_Thickness_(layers): 0 </setting>)
(<setting> fill Extra_Shells_on_Alternating_Solid_Layer_(layers): 1 </setting>)
(<setting> fill Extra_Shells_on_Base_(layers): 1 </setting>)
(<setting> fill Extra_Shells_on_Sparse_Layer_(layers): 1 </setting>)
(<setting> fill Grid_Circle_Separation_over_Perimeter_Width_(ratio): 0.2 </setting>)
(<setting> fill Grid_Extra_Overlap_(ratio): 0.1 </setting>)
(<setting> fill Grid_Junction_Separation_Band_Height_(layers): 10 </setting>)
(<setting> fill Grid_Junction_Separation_over_Octogon_Radius_At_End_(ratio): 0.0 </setting>)
(<setting> fill Grid_Junction_Separation_over_Octogon_Radius_At_Middle_(ratio): 0.0 </setting>)
(<setting> fill Infill_Begin_Rotation_(degrees): 45.0 </setting>)
(<setting> fill Infill_Begin_Rotation_Repeat_(layers): 1 </setting>)
(<setting> fill Infill_Odd_Layer_Extra_Rotation_(degrees): 90.0 </setting>)
(<setting> fill Grid_Circular False </setting>)
(<setting> fill Grid_Hexagonal True </setting>)
(<setting> fill Grid_Rectangular False </setting>)
(<setting> fill Line False </setting>)
(<setting> fill Infill_Perimeter_Overlap_(ratio): 0.15 </setting>)
(<setting> fill Infill_Solidity_(ratio): 0.3 </setting>)
(<setting> fill Sharpest_Angle_(degrees): 60.0 </setting>)
(<setting> fill Solid_Surface_Thickness_(layers): 3 </setting>)
(<setting> fill Lower_Left True </setting>)
(<setting> fill Nearest False </setting>)
(<setting> fill Surrounding_Angle_(degrees): 60.0 </setting>)
(<setting> fill Infill_>_Loops_>_Perimeter False </setting>)
(<setting> fill Infill_>_Perimeter_>_Loops False </setting>)
(<setting> fill Loops_>_Infill_>_Perimeter False </setting>)
(<setting> fill Loops_>_Perimeter_>_Infill False </setting>)
(<setting> fill Perimeter_>_Infill_>_Loops False </setting>)
(<setting> fill Perimeter_>_Loops_>_Infill True </setting>)
(<setting> limit Activate_Limit True </setting>)
(<setting> limit Maximum_Initial_Feed_Rate_(mm/s): 5.0 </setting>)
(<setting> multiply Activate_Multiply True </setting>)
(<setting> multiply Center_X_(mm): 60.0 </setting>)
(<setting> multiply Center_Y_(mm): 60.0 </setting>)
(<setting> multiply Number_of_Columns_(integer): 1 </setting>)
(<setting> multiply Number_of_Rows_(integer): 1 </setting>)
(<setting> multiply Reverse_Sequence_every_Odd_Layer False </setting>)
(<setting> multiply Separation_over_Perimeter_Width_(ratio): 15.0 </setting>)
(<setting> raft Activate_Raft True </setting>)
(<setting> raft Add_Raft,_Elevate_Nozzle,_Orbit: True </setting>)
(<setting> raft Base_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Base_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Base_Infill_Density_(ratio): 0.5 </setting>)
(<setting> raft Base_Layer_Thickness_over_Layer_Thickness: 2.0 </setting>)
(<setting> raft Base_Layers_(integer): 0 </setting>)
(<setting> raft Base_Nozzle_Lift_over_Base_Layer_Thickness_(ratio): 0.4 </setting>)
(<setting> raft Initial_Circling: False </setting>)
(<setting> raft Infill_Overhang_over_Extrusion_Width_(ratio): 0.05 </setting>)
(<setting> raft Interface_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Interface_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Interface_Infill_Density_(ratio): 0.5 </setting>)
(<setting> raft Interface_Layer_Thickness_over_Layer_Thickness: 1.0 </setting>)
(<setting> raft Interface_Layers_(integer): 0 </setting>)
(<setting> raft Interface_Nozzle_Lift_over_Interface_Layer_Thickness_(ratio): 0.45 </setting>)
(<setting> raft Name_of_Support_End_File: support_end.gcode </setting>)
(<setting> raft Name_of_Support_Start_File: support_start.gcode </setting>)
(<setting> raft Operating_Nozzle_Lift_over_Layer_Thickness_(ratio): 0.5 </setting>)
(<setting> raft Raft_Additional_Margin_over_Length_(%): 1.0 </setting>)
(<setting> raft Raft_Margin_(mm): 3.0 </setting>)
(<setting> raft Support_Cross_Hatch False </setting>)
(<setting> raft Support_Flow_Rate_over_Operating_Flow_Rate_(ratio): 1.0 </setting>)
(<setting> raft Support_Gap_over_Perimeter_Extrusion_Width_(ratio): 1.0 </setting>)
(<setting> raft None True </setting>)
(<setting> raft Empty_Layers_Only False </setting>)
(<setting> raft Everywhere False </setting>)
(<setting> raft Exterior_Only False </setting>)
(<setting> raft Support_Minimum_Angle_(degrees): 60.0 </setting>)
(<setting> skirt Activate_Skirt True </setting>)
(<setting> skirt Convex: True </setting>)
(<setting> skirt Gap_over_Perimeter_Width_(ratio): 3.0 </setting>)
(<setting> skirt Layers_To_(index): 1 </setting>)
(<setting> speed Activate_Speed True </setting>)
(<setting> speed Add_Flow_Rate: True </setting>)
(<setting> speed Bridge_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> speed Bridge_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> speed Duty_Cyle_at_Beginning_(portion): 1.0 </setting>)
(<setting> speed Duty_Cyle_at_Ending_(portion): 0.0 </setting>)
(<setting> speed Feed_Rate_(mm/s): 30.0 </setting>)
(<setting> speed Flow_Rate_Setting_(float): 25.0 </setting>)
(<setting> speed Object_First_Layer_Feed_Rate_Infill_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Object_First_Layer_Feed_Rate_Perimeter_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Object_First_Layer_Flow_Rate_Infill_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Object_First_Layer_Flow_Rate_Perimeter_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Orbital_Feed_Rate_over_Operating_Feed_Rate_(ratio): 0.5 </setting>)
(<setting> speed Maximum_Z_Feed_Rate_(mm/s): 1.0 </setting>)
(<setting> speed Perimeter_Feed_Rate_Multiplier_(ratio): 0.75 </setting>)
(<setting> speed Perimeter_Flow_Rate_Multiplier_(ratio): 0.75 </setting>)
(<setting> speed Travel_Feed_Rate_(mm/s): 100.0 </setting>)
(</settings>)
(<timeStampPreface> 20120802_165152 </timeStampPreface>)
(<procedureName> carve </procedureName>)
(<procedureName> bottom </procedureName>)
(<procedureName> preface </procedureName>)
(<procedureName> inset </procedureName>)
(<procedureName> fill </procedureName>)
(<procedureName> multiply </procedureName>)
(<procedureName> speed </procedureName>)
(<procedureName> raft </procedureName>)
(<procedureName> skirt </procedureName>)
(<procedureName> cool </procedureName>)
(<procedureName> limit </procedureName>)
(<procedureName> dimension </procedureName>)
(<procedureName> alteration </procedureName>)
(</extruderInitialization>)
(<crafting>)
M113 S1.0
( Set extruder speed to 5.625. )
M108 S5.625
(<layer> 0.58 )
(<skirt>)
( Linear move to (27.48, 58.4374, 0.58). )
G1 X27.48 Y58.4374 Z0.58 F300.0
( Linear move to (27.48, 58.4374, 0.58). )
G1 F1200.0
( Linear move to (27.48, 58.4374, 0.58). )
G1 E1.0
( Linear move to (27.48, 58.4374, 0.58). )
G1 F300.0
( Extruder on, forward. )
M101
( Linear move to (27.48, 71.1887, 0.58). )
G1 X27.48 Y71.1887 Z0.58 F405.0 E1.3578
( Linear move to (29.477, 72.52, 0.58). )
G1 X29.477 Y72.52 Z0.58 F405.0 E1.4252
( Linear move to (81.0467, 82.5306, 0.58). )
G1 X81.0467 Y82.5306 Z0.58 F405.0 E2.8992
( Linear move to (92.52, 82.4147, 0.58). )
G1 X92.52 Y82.4147 Z0.58 F405.0 E3.2212
( Linear move to (92.52, 38.6823, 0.58). )
G1 X92.52 Y38.6823 Z0.58 F405.0 E4.4483
( Linear move to (89.8148, 37.48, 0.58). )
G1 X89.8148 Y37.48 Z0.58 F405.0 E4.5314
( Linear move to (79.5843, 37.48, 0.58). )
G1 X79.5843 Y37.48 Z0.58 F405.0 E4.8185
( Linear move to (28.8132, 47.48, 0.58). )
G1 X28.8132 Y47.48 Z0.58 F405.0 E6.2705
( Linear move to (27.48, 49.702, 0.58). )
G1 X27.48 Y49.702 Z0.58 F405.0 E6.3432
( Linear move to (27.48, 58.4374, 0.58). )
G1 X27.48 Y58.4374 Z0.58 F405.0 E6.5883
( Linear move to (27.48, 58.4374, 0.58). )
G1 F1200.0
( Linear move to (27.48, 58.4374, 0.58). )
G1 E5.5883
( Linear move to (27.48, 58.4374, 0.58). )
G1 F405.0
( Extruder off. )
M103
( Set extruder speed to 5.625. )
M108 S5.625
(</skirt>)
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X42.0023 Y55.1779 Z0.58 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y55.1779 Z0.58 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y57.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X30.0 Y57.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X30.0 Y50.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X82.0 Y50.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X82.0 Y40.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X90.0 Y40.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X90.0 Y57.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y57.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y55.1779 Z0.58 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y55.1779 Z0.58 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y57.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y57.0 Z0.58 </boundaryPoint>)
(<edge> outer )
( Linear move to (30.36, 50.36, 0.58). )
G1 X30.36 Y50.36 Z0.58 F6000.0
( Linear move to (30.36, 50.36, 0.58). )
G1 F1200.0
( Linear move to (30.36, 50.36, 0.58). )
G1 E6.5883
( Linear move to (30.36, 50.36, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (82.36, 50.36, 0.58). )
G1 X82.36 Y50.36 Z0.58 F405.0 E8.0475
( Linear move to (82.36, 40.36, 0.58). )
G1 X82.36 Y40.36 Z0.58 F405.0 E8.3281
( Linear move to (89.64, 40.36, 0.58). )
G1 X89.64 Y40.36 Z0.58 F405.0 E8.5324
( Linear move to (89.64, 56.64, 0.58). )
G1 X89.64 Y56.64 Z0.58 F405.0 E8.9892
( Linear move to (84.3623, 56.64, 0.58). )
G1 X84.3623 Y56.64 Z0.58 F405.0 E9.1373
( Linear move to (84.3623, 54.8179, 0.58). )
G1 X84.3623 Y54.8179 Z0.58 F405.0 E9.1884
( Linear move to (77.6513, 54.8179, 0.58). )
G1 X77.6513 Y54.8179 Z0.58 F405.0 E9.3767
( Linear move to (77.6513, 56.64, 0.58). )
G1 X77.6513 Y56.64 Z0.58 F405.0 E9.4278
( Linear move to (42.3623, 56.64, 0.58). )
G1 X42.3623 Y56.64 Z0.58 F405.0 E10.4181
( Linear move to (42.3623, 54.8179, 0.58). )
G1 X42.3623 Y54.8179 Z0.58 F405.0 E10.4692
( Linear move to (35.6513, 54.8179, 0.58). )
G1 X35.6513 Y54.8179 Z0.58 F405.0 E10.6575
( Linear move to (35.6513, 56.64, 0.58). )
G1 X35.6513 Y56.64 Z0.58 F405.0 E10.7086
( Linear move to (30.36, 56.64, 0.58). )
G1 X30.36 Y56.64 Z0.58 F405.0 E10.8571
( Linear move to (30.36, 50.36, 0.58). )
G1 X30.36 Y50.36 Z0.58 F405.0 E11.0333
( Linear move to (30.36, 50.36, 0.58). )
G1 F1200.0
( Linear move to (30.36, 50.36, 0.58). )
G1 E10.0333
( Linear move to (30.36, 50.36, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X47.1697 Y55.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y54.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y54.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.25 Y53.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y52.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y52.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y51.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X46.5 Y51.75 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y51.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y52.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y52.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.75 Y53.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y54.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y54.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y55.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X46.5 Y55.25 Z0.58 </boundaryPoint>)
(<edge> inner )
( Linear move to (44.4499, 53.1634, 0.58). )
G1 X44.4499 Y53.1634 Z0.58 F6000.0
( Linear move to (44.4499, 53.1634, 0.58). )
G1 F1200.0
( Linear move to (44.4499, 53.1634, 0.58). )
G1 E11.0333
( Linear move to (44.4499, 53.1634, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (44.3829, 53.5, 0.58). )
G1 X44.3829 Y53.5 Z0.58 F405.0 E11.043
( Linear move to (44.5441, 54.3102, 0.58). )
G1 X44.5441 Y54.3102 Z0.58 F405.0 E11.0661
( Linear move to (45.0031, 54.9969, 0.58). )
G1 X45.0031 Y54.9969 Z0.58 F405.0 E11.0893
( Linear move to (45.6898, 55.4559, 0.58). )
G1 X45.6898 Y55.4559 Z0.58 F405.0 E11.1125
( Linear move to (46.5, 55.6171, 0.58). )
G1 X46.5 Y55.6171 Z0.58 F405.0 E11.1357
( Linear move to (47.3102, 55.4559, 0.58). )
G1 X47.3102 Y55.4559 Z0.58 F405.0 E11.1589
( Linear move to (47.9969, 54.9969, 0.58). )
G1 X47.9969 Y54.9969 Z0.58 F405.0 E11.182
( Linear move to (48.4559, 54.3102, 0.58). )
G1 X48.4559 Y54.3102 Z0.58 F405.0 E11.2052
( Linear move to (48.6171, 53.5, 0.58). )
G1 X48.6171 Y53.5 Z0.58 F405.0 E11.2284
( Linear move to (48.4559, 52.6898, 0.58). )
G1 X48.4559 Y52.6898 Z0.58 F405.0 E11.2516
( Linear move to (47.9969, 52.0031, 0.58). )
G1 X47.9969 Y52.0031 Z0.58 F405.0 E11.2748
( Linear move to (47.3102, 51.5441, 0.58). )
G1 X47.3102 Y51.5441 Z0.58 F405.0 E11.2979
( Linear move to (46.5, 51.3829, 0.58). )
G1 X46.5 Y51.3829 Z0.58 F405.0 E11.3211
( Linear move to (45.6898, 51.5441, 0.58). )
G1 X45.6898 Y51.5441 Z0.58 F405.0 E11.3443
( Linear move to (45.0031, 52.0031, 0.58). )
G1 X45.0031 Y52.0031 Z0.58 F405.0 E11.3675
( Linear move to (44.5441, 52.6898, 0.58). )
G1 X44.5441 Y52.6898 Z0.58 F405.0 E11.3906
( Linear move to (44.4499, 53.1634, 0.58). )
G1 X44.4499 Y53.1634 Z0.58 F405.0 E11.4042
( Linear move to (44.4499, 53.1634, 0.58). )
G1 F1200.0
( Linear move to (44.4499, 53.1634, 0.58). )
G1 E10.4042
( Linear move to (44.4499, 53.1634, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X73.1697 Y51.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X72.5 Y51.75 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y51.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y52.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y52.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.75 Y53.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y54.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y54.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y55.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X72.5 Y55.25 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y55.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y54.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y54.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.25 Y53.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y52.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y52.2626 Z0.58 </boundaryPoint>)
(<edge> inner )
( Linear move to (70.3829, 53.5, 0.58). )
G1 X70.3829 Y53.5 Z0.58 F6000.0
( Linear move to (70.3829, 53.5, 0.58). )
G1 F1200.0
( Linear move to (70.3829, 53.5, 0.58). )
G1 E11.4042
( Linear move to (70.3829, 53.5, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (70.5441, 54.3102, 0.58). )
G1 X70.5441 Y54.3102 Z0.58 F405.0 E11.4274
( Linear move to (71.0031, 54.9969, 0.58). )
G1 X71.0031 Y54.9969 Z0.58 F405.0 E11.4506
( Linear move to (71.6898, 55.4559, 0.58). )
G1 X71.6898 Y55.4559 Z0.58 F405.0 E11.4737
( Linear move to (72.5, 55.6171, 0.58). )
G1 X72.5 Y55.6171 Z0.58 F405.0 E11.4969
( Linear move to (73.3102, 55.4559, 0.58). )
G1 X73.3102 Y55.4559 Z0.58 F405.0 E11.5201
( Linear move to (73.9969, 54.9969, 0.58). )
G1 X73.9969 Y54.9969 Z0.58 F405.0 E11.5433
( Linear move to (74.4559, 54.3102, 0.58). )
G1 X74.4559 Y54.3102 Z0.58 F405.0 E11.5664
( Linear move to (74.6171, 53.5, 0.58). )
G1 X74.6171 Y53.5 Z0.58 F405.0 E11.5896
( Linear move to (74.4559, 52.6898, 0.58). )
G1 X74.4559 Y52.6898 Z0.58 F405.0 E11.6128
( Linear move to (73.9969, 52.0031, 0.58). )
G1 X73.9969 Y52.0031 Z0.58 F405.0 E11.636
( Linear move to (73.3102, 51.5441, 0.58). )
G1 X73.3102 Y51.5441 Z0.58 F405.0 E11.6592
( Linear move to (72.5, 51.3829, 0.58). )
G1 X72.5 Y51.3829 Z0.58 F405.0 E11.6823
( Linear move to (71.6898, 51.5441, 0.58). )
G1 X71.6898 Y51.5441 Z0.58 F405.0 E11.7055
( Linear move to (71.0031, 52.0031, 0.58). )
G1 X71.0031 Y52.0031 Z0.58 F405.0 E11.7287
( Linear move to (70.5441, 52.6898, 0.58). )
G1 X70.5441 Y52.6898 Z0.58 F405.0 E11.7519
( Linear move to (70.3829, 53.5, 0.58). )
G1 X70.3829 Y53.5 Z0.58 F405.0 E11.7751
( Linear move to (70.3829, 53.5, 0.58). )
G1 F1200.0
( Linear move to (70.3829, 53.5, 0.58). )
G1 E11.7751
( Linear move to (70.3829, 53.5, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<loop> outer )
( Set extruder speed to 7.5. )
M108 S7.5
( Linear move to (69.71, 53.5, 0.58). )
G1 X69.71 Y53.5 Z0.58 F6000.0
( Linear move to (69.71, 53.5, 0.58). )
G1 F1200.0
( Linear move to (69.71, 53.5, 0.58). )
G1 E11.7751
( Linear move to (69.71, 53.5, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (69.9224, 54.5677, 0.58). )
G1 X69.9224 Y54.5677 Z0.58 F540.0 E11.8056
( Linear move to (70.2724, 55.0915, 0.58). )
G1 X70.2724 Y55.0915 Z0.58 F540.0 E11.8233
( Linear move to (69.8541, 55.98, 0.58). )
G1 X69.8541 Y55.98 Z0.58 F540.0 E11.8508
( Linear move to (48.8192, 55.98, 0.58). )
G1 X48.8192 Y55.98 Z0.58 F540.0 E12.4411
( Linear move to (48.6737, 55.1722, 0.58). )
G1 X48.6737 Y55.1722 Z0.58 F540.0 E12.4641
( Linear move to (49.0776, 54.5677, 0.58). )
G1 X49.0776 Y54.5677 Z0.58 F540.0 E12.4845
( Linear move to (49.29, 53.5, 0.58). )
G1 X49.29 Y53.5 Z0.58 F540.0 E12.5151
( Linear move to (49.0776, 52.4323, 0.58). )
G1 X49.0776 Y52.4323 Z0.58 F540.0 E12.5456
( Linear move to (48.6663, 51.8168, 0.58). )
G1 X48.6663 Y51.8168 Z0.58 F540.0 E12.5664
( Linear move to (48.7787, 51.02, 0.58). )
G1 X48.7787 Y51.02 Z0.58 F540.0 E12.589
( Linear move to (70.0668, 51.02, 0.58). )
G1 X70.0668 Y51.02 Z0.58 F540.0 E13.1863
( Linear move to (70.3065, 51.8576, 0.58). )
G1 X70.3065 Y51.8576 Z0.58 F540.0 E13.2108
( Linear move to (69.9224, 52.4323, 0.58). )
G1 X69.9224 Y52.4323 Z0.58 F540.0 E13.2302
( Linear move to (69.71, 53.5, 0.58). )
G1 X69.71 Y53.5 Z0.58 F540.0 E13.2607
( Linear move to (69.71, 53.5, 0.58). )
G1 F1200.0
( Linear move to (69.71, 53.5, 0.58). )
G1 E12.2607
( Linear move to (69.71, 53.5, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (73.9814, 51.1988, 0.58). )
G1 X73.9814 Y51.1988 Z0.58 F6000.0
( Linear move to (73.9814, 51.1988, 0.58). )
G1 F1200.0
( Linear move to (73.9814, 51.1988, 0.58). )
G1 E13.2607
( Linear move to (73.9814, 51.1988, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (74.0071, 51.02, 0.58). )
G1 X74.0071 Y51.02 Z0.58 F540.0 E13.2658
( Linear move to (83.02, 51.02, 0.58). )
G1 X83.02 Y51.02 Z0.58 F540.0 E13.5187
( Linear move to (83.02, 41.02, 0.58). )
G1 X83.02 Y41.02 Z0.58 F540.0 E13.7993
( Linear move to (88.98, 41.02, 0.58). )
G1 X88.98 Y41.02 Z0.58 F540.0 E13.9665
( Linear move to (88.98, 55.98, 0.58). )
G1 X88.98 Y55.98 Z0.58 F540.0 E14.3863
( Linear move to (85.0223, 55.98, 0.58). )
G1 X85.0223 Y55.98 Z0.58 F540.0 E14.4974
( Linear move to (85.0223, 54.1579, 0.58). )
G1 X85.0223 Y54.1579 Z0.58 F540.0 E14.5485
( Linear move to (76.9913, 54.1579, 0.58). )
G1 X76.9913 Y54.1579 Z0.58 F540.0 E14.7738
( Linear move to (76.9913, 55.98, 0.58). )
G1 X76.9913 Y55.98 Z0.58 F540.0 E14.825
( Linear move to (75.0338, 55.98, 0.58). )
G1 X75.0338 Y55.98 Z0.58 F540.0 E14.8799
( Linear move to (74.7101, 55.1176, 0.58). )
G1 X74.7101 Y55.1176 Z0.58 F540.0 E14.9057
( Linear move to (75.0776, 54.5677, 0.58). )
G1 X75.0776 Y54.5677 Z0.58 F540.0 E14.9243
( Linear move to (75.29, 53.5, 0.58). )
G1 X75.29 Y53.5 Z0.58 F540.0 E14.9549
( Linear move to (75.0776, 52.4323, 0.58). )
G1 X75.0776 Y52.4323 Z0.58 F540.0 E14.9854
( Linear move to (74.4728, 51.5272, 0.58). )
G1 X74.4728 Y51.5272 Z0.58 F540.0 E15.0159
( Linear move to (73.9814, 51.1988, 0.58). )
G1 X73.9814 Y51.1988 Z0.58 F540.0 E15.0325
( Linear move to (73.9814, 51.1988, 0.58). )
G1 F1200.0
( Linear move to (73.9814, 51.1988, 0.58). )
G1 E14.0325
( Linear move to (73.9814, 51.1988, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (44.5557, 51.0132, 0.58). )
G1 X44.5557 Y51.0132 Z0.58 F6000.0
( Linear move to (44.5557, 51.0132, 0.58). )
G1 F1200.0
( Linear move to (44.5557, 51.0132, 0.58). )
G1 E15.0325
( Linear move to (44.5557, 51.0132, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (44.3971, 51.722, 0.58). )
G1 X44.3971 Y51.722 Z0.58 F540.0 E15.0529
( Linear move to (43.9224, 52.4323, 0.58). )
G1 X43.9224 Y52.4323 Z0.58 F540.0 E15.0769
( Linear move to (43.71, 53.5, 0.58). )
G1 X43.71 Y53.5 Z0.58 F540.0 E15.1074
( Linear move to (43.9224, 54.5677, 0.58). )
G1 X43.9224 Y54.5677 Z0.58 F540.0 E15.138
( Linear move to (44.4083, 55.2948, 0.58). )
G1 X44.4083 Y55.2948 Z0.58 F540.0 E15.1625
( Linear move to (44.6738, 56.0342, 0.58). )
G1 X44.6738 Y56.0342 Z0.58 F540.0 E15.1846
( Linear move to (43.0223, 55.98, 0.58). )
G1 X43.0223 Y55.98 Z0.58 F540.0 E15.2309
( Linear move to (43.0223, 54.1579, 0.58). )
G1 X43.0223 Y54.1579 Z0.58 F540.0 E15.2821
( Linear move to (34.9913, 54.1579, 0.58). )
G1 X34.9913 Y54.1579 Z0.58 F540.0 E15.5074
( Linear move to (34.9913, 55.98, 0.58). )
G1 X34.9913 Y55.98 Z0.58 F540.0 E15.5585
( Linear move to (31.02, 55.98, 0.58). )
G1 X31.02 Y55.98 Z0.58 F540.0 E15.67
( Linear move to (31.02, 51.02, 0.58). )
G1 X31.02 Y51.02 Z0.58 F540.0 E15.8092
( Linear move to (44.5557, 51.0132, 0.58). )
G1 X44.5557 Y51.0132 Z0.58 F540.0 E16.189
( Linear move to (44.5557, 51.0132, 0.58). )
G1 F1200.0
( Linear move to (44.5557, 51.0132, 0.58). )
G1 E15.2683
( Linear move to (44.5557, 51.0132, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X43.0223 Y54.1579 Z0.38 </infillPoint>)
(<infillPoint> X34.9913 Y54.1579 Z0.38 </infillPoint>)
(<infillPoint> X34.9913 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X31.02 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X31.02 Y51.02 Z0.38 </infillPoint>)
(<infillPoint> X44.5557 Y51.0132 Z0.38 </infillPoint>)
(<infillPoint> X44.3971 Y51.722 Z0.38 </infillPoint>)
(<infillPoint> X43.9224 Y52.4323 Z0.38 </infillPoint>)
(<infillPoint> X43.71 Y53.5 Z0.38 </infillPoint>)
(<infillPoint> X43.9224 Y54.5677 Z0.38 </infillPoint>)
(<infillPoint> X44.4083 Y55.2948 Z0.38 </infillPoint>)
(<infillPoint> X44.6738 Y56.0342 Z0.38 </infillPoint>)
(<infillPoint> X43.0223 Y55.98 Z0.38 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X48.7787 Y51.02 Z0.38 </infillPoint>)
(<infillPoint> X70.0668 Y51.02 Z0.38 </infillPoint>)
(<infillPoint> X70.3065 Y51.8576 Z0.38 </infillPoint>)
(<infillPoint> X69.9224 Y52.4323 Z0.38 </infillPoint>)
(<infillPoint> X69.71 Y53.5 Z0.38 </infillPoint>)
(<infillPoint> X69.9224 Y54.5677 Z0.38 </infillPoint>)
(<infillPoint> X70.2724 Y55.0915 Z0.38 </infillPoint>)
(<infillPoint> X69.8541 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X48.8192 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X48.6737 Y55.1722 Z0.38 </infillPoint>)
(<infillPoint> X49.0776 Y54.5677 Z0.38 </infillPoint>)
(<infillPoint> X49.29 Y53.5 Z0.38 </infillPoint>)
(<infillPoint> X49.0776 Y52.4323 Z0.38 </infillPoint>)
(<infillPoint> X48.6663 Y51.8168 Z0.38 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X74.0071 Y51.02 Z0.38 </infillPoint>)
(<infillPoint> X83.02 Y51.02 Z0.38 </infillPoint>)
(<infillPoint> X83.02 Y41.02 Z0.38 </infillPoint>)
(<infillPoint> X88.98 Y41.02 Z0.38 </infillPoint>)
(<infillPoint> X88.98 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X85.0223 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X85.0223 Y54.1579 Z0.38 </infillPoint>)
(<infillPoint> X76.9913 Y54.1579 Z0.38 </infillPoint>)
(<infillPoint> X76.9913 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X75.0338 Y55.98 Z0.38 </infillPoint>)
(<infillPoint> X74.7101 Y55.1176 Z0.38 </infillPoint>)
(<infillPoint> X75.0776 Y54.5677 Z0.38 </infillPoint>)
(<infillPoint> X75.29 Y53.5 Z0.38 </infillPoint>)
(<infillPoint> X75.0776 Y52.4323 Z0.38 </infillPoint>)
(<infillPoint> X74.4728 Y51.5272 Z0.38 </infillPoint>)
(<infillPoint> X73.9814 Y51.1988 Z0.38 </infillPoint>)
(</infillBoundary>)
( Linear move to (43.3822, 52.5337, 0.58). )
G1 X43.3822 Y52.5337 Z0.58 F6000.0
( Linear move to (43.3822, 52.5337, 0.58). )
G1 F1200.0
( Linear move to (43.3822, 52.5337, 0.58). )
G1 E16.189
( Linear move to (43.3822, 52.5337, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (42.3728, 51.5243, 0.58). )
G1 X42.3728 Y51.5243 Z0.58 F540.0 E16.229
( Linear move to (43.2209, 51.5238, 0.58). )
G1 X43.2209 Y51.5238 Z0.58 F540.0 E16.2528
( Linear move to (43.6376, 51.9405, 0.58). )
G1 X43.6376 Y51.9405 Z0.58 F540.0 E16.2694
( Linear move to (43.6376, 51.9405, 0.58). )
G1 F1200.0
( Linear move to (43.6376, 51.9405, 0.58). )
G1 E15.2694
( Linear move to (43.6376, 51.9405, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (41.5247, 51.5247, 0.58). )
G1 X41.5247 Y51.5247 Z0.58 F6000.0
( Linear move to (41.5247, 51.5247, 0.58). )
G1 F1200.0
( Linear move to (41.5247, 51.5247, 0.58). )
G1 E16.2694
( Linear move to (41.5247, 51.5247, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (43.2415, 53.2415, 0.58). )
G1 X43.2415 Y53.2415 Z0.58 F540.0 E16.3375
( Linear move to (42.7994, 53.6479, 0.58). )
G1 X42.7994 Y53.6479 Z0.58 F540.0 E16.3543
( Linear move to (40.6766, 51.5251, 0.58). )
G1 X40.6766 Y51.5251 Z0.58 F540.0 E16.4386
( Linear move to (39.8285, 51.5255, 0.58). )
G1 X39.8285 Y51.5255 Z0.58 F540.0 E16.4624
( Linear move to (41.9508, 53.6479, 0.58). )
G1 X41.9508 Y53.6479 Z0.58 F540.0 E16.5466
( Linear move to (41.1023, 53.6479, 0.58). )
G1 X41.1023 Y53.6479 Z0.58 F540.0 E16.5704
( Linear move to (38.9804, 51.526, 0.58). )
G1 X38.9804 Y51.526 Z0.58 F540.0 E16.6546
( Linear move to (38.1323, 51.5264, 0.58). )
G1 X38.1323 Y51.5264 Z0.58 F540.0 E16.6784
( Linear move to (40.2538, 53.6479, 0.58). )
G1 X40.2538 Y53.6479 Z0.58 F540.0 E16.7626
( Linear move to (39.4053, 53.6479, 0.58). )
G1 X39.4053 Y53.6479 Z0.58 F540.0 E16.7864
( Linear move to (37.2842, 51.5268, 0.58). )
G1 X37.2842 Y51.5268 Z0.58 F540.0 E16.8706
( Linear move to (36.4361, 51.5273, 0.58). )
G1 X36.4361 Y51.5273 Z0.58 F540.0 E16.8944
( Linear move to (38.5567, 53.6479, 0.58). )
G1 X38.5567 Y53.6479 Z0.58 F540.0 E16.9785
( Linear move to (37.7082, 53.6479, 0.58). )
G1 X37.7082 Y53.6479 Z0.58 F540.0 E17.0023
( Linear move to (35.588, 51.5277, 0.58). )
G1 X35.588 Y51.5277 Z0.58 F540.0 E17.0865
( Linear move to (34.7399, 51.5281, 0.58). )
G1 X34.7399 Y51.5281 Z0.58 F540.0 E17.1103
( Linear move to (36.8597, 53.6479, 0.58). )
G1 X36.8597 Y53.6479 Z0.58 F540.0 E17.1944
( Linear move to (36.0111, 53.6479, 0.58). )
G1 X36.0111 Y53.6479 Z0.58 F540.0 E17.2182
( Linear move to (33.8918, 51.5285, 0.58). )
G1 X33.8918 Y51.5285 Z0.58 F540.0 E17.3023
( Linear move to (33.0437, 51.529, 0.58). )
G1 X33.0437 Y51.529 Z0.58 F540.0 E17.3261
( Linear move to (35.1626, 53.6479, 0.58). )
G1 X35.1626 Y53.6479 Z0.58 F540.0 E17.4102
( Linear move to (34.4813, 53.8151, 0.58). )
G1 X34.4813 Y53.8151 Z0.58 F540.0 E17.4299
( Linear move to (32.1956, 51.5294, 0.58). )
G1 X32.1956 Y51.5294 Z0.58 F540.0 E17.5206
( Linear move to (31.6464, 51.8287, 0.58). )
G1 X31.6464 Y51.8287 Z0.58 F540.0 E17.5381
( Linear move to (34.4813, 54.6636, 0.58). )
G1 X34.4813 Y54.6636 Z0.58 F540.0 E17.6506
( Linear move to (34.2526, 55.2835, 0.58). )
G1 X34.2526 Y55.2835 Z0.58 F540.0 E17.6692
( Linear move to (31.53, 52.5609, 0.58). )
G1 X31.53 Y52.5609 Z0.58 F540.0 E17.7772
( Linear move to (31.53, 53.4094, 0.58). )
G1 X31.53 Y53.4094 Z0.58 F540.0 E17.801
( Linear move to (33.5906, 55.47, 0.58). )
G1 X33.5906 Y55.47 Z0.58 F540.0 E17.8828
( Linear move to (32.7421, 55.47, 0.58). )
G1 X32.7421 Y55.47 Z0.58 F540.0 E17.9066
( Linear move to (31.53, 54.2579, 0.58). )
G1 X31.53 Y54.2579 Z0.58 F540.0 E17.9547
( Linear move to (31.53, 54.2579, 0.58). )
G1 F1200.0
( Linear move to (31.53, 54.2579, 0.58). )
G1 E16.9547
( Linear move to (31.53, 54.2579, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (69.4327, 52.2798, 0.58). )
G1 X69.4327 Y52.2798 Z0.58 F6000.0
( Linear move to (69.4327, 52.2798, 0.58). )
G1 F1200.0
( Linear move to (69.4327, 52.2798, 0.58). )
G1 E17.9547
( Linear move to (69.4327, 52.2798, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (68.6829, 51.53, 0.58). )
G1 X68.6829 Y51.53 Z0.58 F540.0 E17.9845
( Linear move to (67.8344, 51.53, 0.58). )
G1 X67.8344 Y51.53 Z0.58 F540.0 E18.0083
( Linear move to (69.2919, 52.9876, 0.58). )
G1 X69.2919 Y52.9876 Z0.58 F540.0 E18.0661
( Linear move to (69.2482, 53.7923, 0.58). )
G1 X69.2482 Y53.7923 Z0.58 F540.0 E18.0887
( Linear move to (66.9858, 51.53, 0.58). )
G1 X66.9858 Y51.53 Z0.58 F540.0 E18.1785
( Linear move to (66.1373, 51.53, 0.58). )
G1 X66.1373 Y51.53 Z0.58 F540.0 E18.2023
( Linear move to (69.5788, 54.9715, 0.58). )
G1 X69.5788 Y54.9715 Z0.58 F540.0 E18.3389
( Linear move to (69.2288, 55.47, 0.58). )
G1 X69.2288 Y55.47 Z0.58 F540.0 E18.356
( Linear move to (65.2888, 51.53, 0.58). )
G1 X65.2888 Y51.53 Z0.58 F540.0 E18.5123
( Linear move to (64.4403, 51.53, 0.58). )
G1 X64.4403 Y51.53 Z0.58 F540.0 E18.5361
( Linear move to (68.3803, 55.47, 0.58). )
G1 X68.3803 Y55.47 Z0.58 F540.0 E18.6925
( Linear move to (67.5317, 55.47, 0.58). )
G1 X67.5317 Y55.47 Z0.58 F540.0 E18.7163
( Linear move to (63.5917, 51.53, 0.58). )
G1 X63.5917 Y51.53 Z0.58 F540.0 E18.8727
( Linear move to (62.7432, 51.53, 0.58). )
G1 X62.7432 Y51.53 Z0.58 F540.0 E18.8965
( Linear move to (66.6832, 55.47, 0.58). )
G1 X66.6832 Y55.47 Z0.58 F540.0 E19.0528
( Linear move to (65.8347, 55.47, 0.58). )
G1 X65.8347 Y55.47 Z0.58 F540.0 E19.0766
( Linear move to (61.8947, 51.53, 0.58). )
G1 X61.8947 Y51.53 Z0.58 F540.0 E19.233
( Linear move to (61.0461, 51.53, 0.58). )
G1 X61.0461 Y51.53 Z0.58 F540.0 E19.2568
( Linear move to (64.9861, 55.47, 0.58). )
G1 X64.9861 Y55.47 Z0.58 F540.0 E19.4131
( Linear move to (64.1376, 55.47, 0.58). )
G1 X64.1376 Y55.47 Z0.58 F540.0 E19.4369
( Linear move to (60.1976, 51.53, 0.58). )
G1 X60.1976 Y51.53 Z0.58 F540.0 E19.5933
( Linear move to (59.3491, 51.53, 0.58). )
G1 X59.3491 Y51.53 Z0.58 F540.0 E19.6171
( Linear move to (63.2891, 55.47, 0.58). )
G1 X63.2891 Y55.47 Z0.58 F540.0 E19.7735
( Linear move to (62.4406, 55.47, 0.58). )
G1 X62.4406 Y55.47 Z0.58 F540.0 E19.7973
( Linear move to (58.5006, 51.53, 0.58). )
G1 X58.5006 Y51.53 Z0.58 F540.0 E19.9536
( Linear move to (57.652, 51.53, 0.58). )
G1 X57.652 Y51.53 Z0.58 F540.0 E19.9774
( Linear move to (61.592, 55.47, 0.58). )
G1 X61.592 Y55.47 Z0.58 F540.0 E20.1338
( Linear move to (60.7435, 55.47, 0.58). )
G1 X60.7435 Y55.47 Z0.58 F540.0 E20.1576
( Linear move to (56.8035, 51.53, 0.58). )
G1 X56.8035 Y51.53 Z0.58 F540.0 E20.314
( Linear move to (55.955, 51.53, 0.58). )
G1 X55.955 Y51.53 Z0.58 F540.0 E20.3378
( Linear move to (59.895, 55.47, 0.58). )
G1 X59.895 Y55.47 Z0.58 F540.0 E20.4941
( Linear move to (59.0465, 55.47, 0.58). )
G1 X59.0465 Y55.47 Z0.58 F540.0 E20.5179
( Linear move to (55.1065, 51.53, 0.58). )
G1 X55.1065 Y51.53 Z0.58 F540.0 E20.6743
( Linear move to (54.2579, 51.53, 0.58). )
G1 X54.2579 Y51.53 Z0.58 F540.0 E20.6981
( Linear move to (58.1979, 55.47, 0.58). )
G1 X58.1979 Y55.47 Z0.58 F540.0 E20.8544
( Linear move to (57.3494, 55.47, 0.58). )
G1 X57.3494 Y55.47 Z0.58 F540.0 E20.8782
( Linear move to (53.4094, 51.53, 0.58). )
G1 X53.4094 Y51.53 Z0.58 F540.0 E21.0346
( Linear move to (52.5609, 51.53, 0.58). )
G1 X52.5609 Y51.53 Z0.58 F540.0 E21.0584
( Linear move to (56.5009, 55.47, 0.58). )
G1 X56.5009 Y55.47 Z0.58 F540.0 E21.2148
( Linear move to (55.6523, 55.47, 0.58). )
G1 X55.6523 Y55.47 Z0.58 F540.0 E21.2386
( Linear move to (51.7123, 51.53, 0.58). )
G1 X51.7123 Y51.53 Z0.58 F540.0 E21.3949
( Linear move to (50.8638, 51.53, 0.58). )
G1 X50.8638 Y51.53 Z0.58 F540.0 E21.4187
( Linear move to (54.8038, 55.47, 0.58). )
G1 X54.8038 Y55.47 Z0.58 F540.0 E21.5751
( Linear move to (53.9553, 55.47, 0.58). )
G1 X53.9553 Y55.47 Z0.58 F540.0 E21.5989
( Linear move to (50.0153, 51.53, 0.58). )
G1 X50.0153 Y51.53 Z0.58 F540.0 E21.7552
( Linear move to (49.3202, 51.6834, 0.58). )
G1 X49.3202 Y51.6834 Z0.58 F540.0 E21.7752
( Linear move to (53.1068, 55.47, 0.58). )
G1 X53.1068 Y55.47 Z0.58 F540.0 E21.9255
( Linear move to (52.2582, 55.47, 0.58). )
G1 X52.2582 Y55.47 Z0.58 F540.0 E21.9493
( Linear move to (49.6912, 52.903, 0.58). )
G1 X49.6912 Y52.903 Z0.58 F540.0 E22.0512
( Linear move to (49.7485, 53.8088, 0.58). )
G1 X49.7485 Y53.8088 Z0.58 F540.0 E22.0766
( Linear move to (51.4097, 55.47, 0.58). )
G1 X51.4097 Y55.47 Z0.58 F540.0 E22.1426
( Linear move to (50.5612, 55.47, 0.58). )
G1 X50.5612 Y55.47 Z0.58 F540.0 E22.1664
( Linear move to (49.6078, 54.5166, 0.58). )
G1 X49.6078 Y54.5166 Z0.58 F540.0 E22.2042
( Linear move to (49.3506, 55.1079, 0.58). )
G1 X49.3506 Y55.1079 Z0.58 F540.0 E22.2223
( Linear move to (49.7126, 55.47, 0.58). )
G1 X49.7126 Y55.47 Z0.58 F540.0 E22.2367
( Linear move to (49.7126, 55.47, 0.58). )
G1 F1200.0
( Linear move to (49.7126, 55.47, 0.58). )
G1 E21.2367
( Linear move to (49.7126, 55.47, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (76.017, 55.47, 0.58). )
G1 X76.017 Y55.47 Z0.58 F6000.0
( Linear move to (76.017, 55.47, 0.58). )
G1 F1200.0
( Linear move to (76.017, 55.47, 0.58). )
G1 E22.2367
( Linear move to (76.017, 55.47, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (75.4602, 54.9132, 0.58). )
G1 X75.4602 Y54.9132 Z0.58 F540.0 E22.2588
( Linear move to (75.6583, 54.2627, 0.58). )
G1 X75.6583 Y54.2627 Z0.58 F540.0 E22.2778
( Linear move to (76.4658, 55.0703, 0.58). )
G1 X76.4658 Y55.0703 Z0.58 F540.0 E22.3099
( Linear move to (76.4813, 54.2372, 0.58). )
G1 X76.4813 Y54.2372 Z0.58 F540.0 E22.3333
( Linear move to (75.799, 53.555, 0.58). )
G1 X75.799 Y53.555 Z0.58 F540.0 E22.3603
( Linear move to (76.7405, 53.6479, 0.58). )
G1 X76.7405 Y53.6479 Z0.58 F540.0 E22.3869
( Linear move to (75.6157, 52.5231, 0.58). )
G1 X75.6157 Y52.5231 Z0.58 F540.0 E22.4315
( Linear move to (75.4711, 51.53, 0.58). )
G1 X75.4711 Y51.53 Z0.58 F540.0 E22.4597
( Linear move to (77.589, 53.6479, 0.58). )
G1 X77.589 Y53.6479 Z0.58 F540.0 E22.5437
( Linear move to (78.4376, 53.6479, 0.58). )
G1 X78.4376 Y53.6479 Z0.58 F540.0 E22.5675
( Linear move to (76.3197, 51.53, 0.58). )
G1 X76.3197 Y51.53 Z0.58 F540.0 E22.6516
( Linear move to (77.1682, 51.53, 0.58). )
G1 X77.1682 Y51.53 Z0.58 F540.0 E22.6754
( Linear move to (79.2861, 53.6479, 0.58). )
G1 X79.2861 Y53.6479 Z0.58 F540.0 E22.7594
( Linear move to (80.1346, 53.6479, 0.58). )
G1 X80.1346 Y53.6479 Z0.58 F540.0 E22.7833
( Linear move to (78.0167, 51.53, 0.58). )
G1 X78.0167 Y51.53 Z0.58 F540.0 E22.8673
( Linear move to (78.8652, 51.53, 0.58). )
G1 X78.8652 Y51.53 Z0.58 F540.0 E22.8911
( Linear move to (80.9831, 53.6479, 0.58). )
G1 X80.9831 Y53.6479 Z0.58 F540.0 E22.9752
( Linear move to (81.8317, 53.6479, 0.58). )
G1 X81.8317 Y53.6479 Z0.58 F540.0 E22.999
( Linear move to (79.7138, 51.53, 0.58). )
G1 X79.7138 Y51.53 Z0.58 F540.0 E23.083
( Linear move to (80.5623, 51.53, 0.58). )
G1 X80.5623 Y51.53 Z0.58 F540.0 E23.1068
( Linear move to (82.6802, 53.6479, 0.58). )
G1 X82.6802 Y53.6479 Z0.58 F540.0 E23.1909
( Linear move to (83.5287, 53.6479, 0.58). )
G1 X83.5287 Y53.6479 Z0.58 F540.0 E23.2147
( Linear move to (81.4108, 51.53, 0.58). )
G1 X81.4108 Y51.53 Z0.58 F540.0 E23.2987
( Linear move to (82.2594, 51.53, 0.58). )
G1 X82.2594 Y51.53 Z0.58 F540.0 E23.3225
( Linear move to (84.3773, 53.6479, 0.58). )
G1 X84.3773 Y53.6479 Z0.58 F540.0 E23.4066
( Linear move to (85.2258, 53.6479, 0.58). )
G1 X85.2258 Y53.6479 Z0.58 F540.0 E23.4304
( Linear move to (83.1079, 51.53, 0.58). )
G1 X83.1079 Y51.53 Z0.58 F540.0 E23.5144
( Linear move to (83.53, 51.1036, 0.58). )
G1 X83.53 Y51.1036 Z0.58 F540.0 E23.5313
( Linear move to (87.8964, 55.47, 0.58). )
G1 X87.8964 Y55.47 Z0.58 F540.0 E23.7045
( Linear move to (88.3998, 55.1249, 0.58). )
G1 X88.3998 Y55.1249 Z0.58 F540.0 E23.7217
( Linear move to (83.53, 50.2551, 0.58). )
G1 X83.53 Y50.2551 Z0.58 F540.0 E23.9149
( Linear move to (83.53, 49.4065, 0.58). )
G1 X83.53 Y49.4065 Z0.58 F540.0 E23.9387
( Linear move to (88.47, 54.3465, 0.58). )
G1 X88.47 Y54.3465 Z0.58 F540.0 E24.1348
( Linear move to (88.47, 53.498, 0.58). )
G1 X88.47 Y53.498 Z0.58 F540.0 E24.1586
( Linear move to (83.53, 48.558, 0.58). )
G1 X83.53 Y48.558 Z0.58 F540.0 E24.3546
( Linear move to (83.53, 47.7095, 0.58). )
G1 X83.53 Y47.7095 Z0.58 F540.0 E24.3784
( Linear move to (88.47, 52.6495, 0.58). )
G1 X88.47 Y52.6495 Z0.58 F540.0 E24.5745
( Linear move to (88.47, 51.801, 0.58). )
G1 X88.47 Y51.801 Z0.58 F540.0 E24.5983
( Linear move to (83.53, 46.861, 0.58). )
G1 X83.53 Y46.861 Z0.58 F540.0 E24.7943
( Linear move to (83.53, 46.0124, 0.58). )
G1 X83.53 Y46.0124 Z0.58 F540.0 E24.8181
( Linear move to (88.47, 50.9524, 0.58). )
G1 X88.47 Y50.9524 Z0.58 F540.0 E25.0141
( Linear move to (88.47, 50.1039, 0.58). )
G1 X88.47 Y50.1039 Z0.58 F540.0 E25.038
( Linear move to (83.53, 45.1639, 0.58). )
G1 X83.53 Y45.1639 Z0.58 F540.0 E25.234
( Linear move to (83.53, 44.3154, 0.58). )
G1 X83.53 Y44.3154 Z0.58 F540.0 E25.2578
( Linear move to (88.47, 49.2554, 0.58). )
G1 X88.47 Y49.2554 Z0.58 F540.0 E25.4538
( Linear move to (88.47, 48.4068, 0.58). )
G1 X88.47 Y48.4068 Z0.58 F540.0 E25.4776
( Linear move to (83.53, 43.4668, 0.58). )
G1 X83.53 Y43.4668 Z0.58 F540.0 E25.6737
( Linear move to (83.53, 42.6183, 0.58). )
G1 X83.53 Y42.6183 Z0.58 F540.0 E25.6975
( Linear move to (88.47, 47.5583, 0.58). )
G1 X88.47 Y47.5583 Z0.58 F540.0 E25.8935
( Linear move to (88.47, 46.7098, 0.58). )
G1 X88.47 Y46.7098 Z0.58 F540.0 E25.9173
( Linear move to (83.6177, 41.8575, 0.58). )
G1 X83.6177 Y41.8575 Z0.58 F540.0 E26.1099
( Linear move to (84.1387, 41.53, 0.58). )
G1 X84.1387 Y41.53 Z0.58 F540.0 E26.1272
( Linear move to (88.47, 45.8613, 0.58). )
G1 X88.47 Y45.8613 Z0.58 F540.0 E26.299
( Linear move to (88.47, 45.0127, 0.58). )
G1 X88.47 Y45.0127 Z0.58 F540.0 E26.3229
( Linear move to (84.9873, 41.53, 0.58). )
G1 X84.9873 Y41.53 Z0.58 F540.0 E26.4611
( Linear move to (85.8358, 41.53, 0.58). )
G1 X85.8358 Y41.53 Z0.58 F540.0 E26.4849
( Linear move to (88.47, 44.1642, 0.58). )
G1 X88.47 Y44.1642 Z0.58 F540.0 E26.5894
( Linear move to (88.47, 43.3157, 0.58). )
G1 X88.47 Y43.3157 Z0.58 F540.0 E26.6132
( Linear move to (86.6843, 41.53, 0.58). )
G1 X86.6843 Y41.53 Z0.58 F540.0 E26.6841
( Linear move to (87.5329, 41.53, 0.58). )
G1 X87.5329 Y41.53 Z0.58 F540.0 E26.7079
( Linear move to (88.47, 42.4671, 0.58). )
G1 X88.47 Y42.4671 Z0.58 F540.0 E26.7451
( Linear move to (88.47, 42.4671, 0.58). )
G1 F1200.0
( Linear move to (88.47, 42.4671, 0.58). )
G1 E25.7451
( Linear move to (88.47, 42.4671, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (85.5323, 53.9544, 0.58). )
G1 X85.5323 Y53.9544 Z0.58 F6000.0
( Linear move to (85.5323, 53.9544, 0.58). )
G1 F1200.0
( Linear move to (85.5323, 53.9544, 0.58). )
G1 E26.7451
( Linear move to (85.5323, 53.9544, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (87.0479, 55.47, 0.58). )
G1 X87.0479 Y55.47 Z0.58 F540.0 E26.8052
( Linear move to (86.1994, 55.47, 0.58). )
G1 X86.1994 Y55.47 Z0.58 F540.0 E26.829
( Linear move to (85.5323, 54.8029, 0.58). )
G1 X85.5323 Y54.8029 Z0.58 F540.0 E26.8555
( Linear move to (85.5323, 54.8029, 0.58). )
G1 F1200.0
( Linear move to (85.5323, 54.8029, 0.58). )
G1 E25.8555
( Linear move to (85.5323, 54.8029, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X78.0113 Y64.8221 Z0.58 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y64.8221 Z0.58 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y63.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X90.0 Y63.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X82.0 Y80.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X82.0 Y70.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X30.0 Y70.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X30.0 Y63.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y63.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y64.8221 Z0.58 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y64.8221 Z0.58 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y63.0 Z0.58 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y63.0 Z0.58 </boundaryPoint>)
(<edge> outer )
( Set extruder speed to 5.625. )
M108 S5.625
( Linear move to (85.5323, 63.36, 0.58). )
G1 X85.5323 Y63.36 Z0.58 F6000.0
( Linear move to (85.5323, 63.36, 0.58). )
G1 F1200.0
( Linear move to (85.5323, 63.36, 0.58). )
G1 E26.8555
( Linear move to (85.5323, 63.36, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (89.64, 63.36, 0.58). )
G1 X89.64 Y63.36 Z0.58 F405.0 E26.9708
( Linear move to (89.64, 79.64, 0.58). )
G1 X89.64 Y79.64 Z0.58 F405.0 E27.4276
( Linear move to (82.36, 79.64, 0.58). )
G1 X82.36 Y79.64 Z0.58 F405.0 E27.6319
( Linear move to (82.36, 69.64, 0.58). )
G1 X82.36 Y69.64 Z0.58 F405.0 E27.9125
( Linear move to (30.36, 69.64, 0.58). )
G1 X30.36 Y69.64 Z0.58 F405.0 E29.3716
( Linear move to (30.36, 63.36, 0.58). )
G1 X30.36 Y63.36 Z0.58 F405.0 E29.5478
( Linear move to (35.6513, 63.36, 0.58). )
G1 X35.6513 Y63.36 Z0.58 F405.0 E29.6963
( Linear move to (35.6513, 65.1821, 0.58). )
G1 X35.6513 Y65.1821 Z0.58 F405.0 E29.7474
( Linear move to (42.3623, 65.1821, 0.58). )
G1 X42.3623 Y65.1821 Z0.58 F405.0 E29.9357
( Linear move to (42.3623, 63.36, 0.58). )
G1 X42.3623 Y63.36 Z0.58 F405.0 E29.9869
( Linear move to (77.6513, 63.36, 0.58). )
G1 X77.6513 Y63.36 Z0.58 F405.0 E30.9771
( Linear move to (77.6513, 65.1821, 0.58). )
G1 X77.6513 Y65.1821 Z0.58 F405.0 E31.0282
( Linear move to (84.3623, 65.1821, 0.58). )
G1 X84.3623 Y65.1821 Z0.58 F405.0 E31.2165
( Linear move to (84.3623, 63.36, 0.58). )
G1 X84.3623 Y63.36 Z0.58 F405.0 E31.2677
( Linear move to (85.5323, 63.36, 0.58). )
G1 X85.5323 Y63.36 Z0.58 F405.0 E31.3005
( Linear move to (85.5323, 63.36, 0.58). )
G1 F1200.0
( Linear move to (85.5323, 63.36, 0.58). )
G1 E30.3005
( Linear move to (85.5323, 63.36, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X72.5 Y64.75 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y64.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y65.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y65.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.75 Y66.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y67.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y67.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y68.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X72.5 Y68.25 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y68.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y67.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y67.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.25 Y66.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y65.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y65.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y64.8832 Z0.58 </boundaryPoint>)
(<edge> inner )
( Linear move to (74.4559, 65.6898, 0.58). )
G1 X74.4559 Y65.6898 Z0.58 F6000.0
( Linear move to (74.4559, 65.6898, 0.58). )
G1 F1200.0
( Linear move to (74.4559, 65.6898, 0.58). )
G1 E31.3005
( Linear move to (74.4559, 65.6898, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (73.9969, 65.0031, 0.58). )
G1 X73.9969 Y65.0031 Z0.58 F405.0 E31.3237
( Linear move to (73.3102, 64.5441, 0.58). )
G1 X73.3102 Y64.5441 Z0.58 F405.0 E31.3469
( Linear move to (72.5, 64.3829, 0.58). )
G1 X72.5 Y64.3829 Z0.58 F405.0 E31.37
( Linear move to (71.6898, 64.5441, 0.58). )
G1 X71.6898 Y64.5441 Z0.58 F405.0 E31.3932
( Linear move to (71.0031, 65.0031, 0.58). )
G1 X71.0031 Y65.0031 Z0.58 F405.0 E31.4164
( Linear move to (70.5441, 65.6898, 0.58). )
G1 X70.5441 Y65.6898 Z0.58 F405.0 E31.4396
( Linear move to (70.3829, 66.5, 0.58). )
G1 X70.3829 Y66.5 Z0.58 F405.0 E31.4627
( Linear move to (70.5441, 67.3102, 0.58). )
G1 X70.5441 Y67.3102 Z0.58 F405.0 E31.4859
( Linear move to (71.0031, 67.9969, 0.58). )
G1 X71.0031 Y67.9969 Z0.58 F405.0 E31.5091
( Linear move to (71.6898, 68.4559, 0.58). )
G1 X71.6898 Y68.4559 Z0.58 F405.0 E31.5323
( Linear move to (72.5, 68.6171, 0.58). )
G1 X72.5 Y68.6171 Z0.58 F405.0 E31.5555
( Linear move to (73.3102, 68.4559, 0.58). )
G1 X73.3102 Y68.4559 Z0.58 F405.0 E31.5786
( Linear move to (73.9969, 67.9969, 0.58). )
G1 X73.9969 Y67.9969 Z0.58 F405.0 E31.6018
( Linear move to (74.4559, 67.3102, 0.58). )
G1 X74.4559 Y67.3102 Z0.58 F405.0 E31.625
( Linear move to (74.6171, 66.5, 0.58). )
G1 X74.6171 Y66.5 Z0.58 F405.0 E31.6482
( Linear move to (74.4559, 65.6898, 0.58). )
G1 X74.4559 Y65.6898 Z0.58 F405.0 E31.6714
( Linear move to (74.4559, 65.6898, 0.58). )
G1 F1200.0
( Linear move to (74.4559, 65.6898, 0.58). )
G1 E30.6714
( Linear move to (74.4559, 65.6898, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X45.2626 Y65.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y65.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.75 Y66.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y67.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y67.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y68.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X46.5 Y68.25 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y68.1168 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y67.7374 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y67.1697 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.25 Y66.5 Z0.58 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y65.8303 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y65.2626 Z0.58 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y64.8832 Z0.58 </boundaryPoint>)
(<boundaryPoint> X46.5 Y64.75 Z0.58 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y64.8832 Z0.58 </boundaryPoint>)
(<edge> inner )
( Linear move to (48.6171, 66.5, 0.58). )
G1 X48.6171 Y66.5 Z0.58 F6000.0
( Linear move to (48.6171, 66.5, 0.58). )
G1 F1200.0
( Linear move to (48.6171, 66.5, 0.58). )
G1 E31.6714
( Linear move to (48.6171, 66.5, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (48.4559, 65.6898, 0.58). )
G1 X48.4559 Y65.6898 Z0.58 F405.0 E31.6945
( Linear move to (47.9969, 65.0031, 0.58). )
G1 X47.9969 Y65.0031 Z0.58 F405.0 E31.7177
( Linear move to (47.3102, 64.5441, 0.58). )
G1 X47.3102 Y64.5441 Z0.58 F405.0 E31.7409
( Linear move to (46.5, 64.3829, 0.58). )
G1 X46.5 Y64.3829 Z0.58 F405.0 E31.7641
( Linear move to (45.6898, 64.5441, 0.58). )
G1 X45.6898 Y64.5441 Z0.58 F405.0 E31.7873
( Linear move to (45.0031, 65.0031, 0.58). )
G1 X45.0031 Y65.0031 Z0.58 F405.0 E31.8104
( Linear move to (44.5441, 65.6898, 0.58). )
G1 X44.5441 Y65.6898 Z0.58 F405.0 E31.8336
( Linear move to (44.3829, 66.5, 0.58). )
G1 X44.3829 Y66.5 Z0.58 F405.0 E31.8568
( Linear move to (44.5441, 67.3102, 0.58). )
G1 X44.5441 Y67.3102 Z0.58 F405.0 E31.88
( Linear move to (45.0031, 67.9969, 0.58). )
G1 X45.0031 Y67.9969 Z0.58 F405.0 E31.9031
( Linear move to (45.6898, 68.4559, 0.58). )
G1 X45.6898 Y68.4559 Z0.58 F405.0 E31.9263
( Linear move to (46.5, 68.6171, 0.58). )
G1 X46.5 Y68.6171 Z0.58 F405.0 E31.9495
( Linear move to (47.3102, 68.4559, 0.58). )
G1 X47.3102 Y68.4559 Z0.58 F405.0 E31.9727
( Linear move to (47.9969, 67.9969, 0.58). )
G1 X47.9969 Y67.9969 Z0.58 F405.0 E31.9959
( Linear move to (48.4559, 67.3102, 0.58). )
G1 X48.4559 Y67.3102 Z0.58 F405.0 E32.019
( Linear move to (48.6171, 66.5, 0.58). )
G1 X48.6171 Y66.5 Z0.58 F405.0 E32.0422
( Linear move to (48.6171, 66.5, 0.58). )
G1 F1200.0
( Linear move to (48.6171, 66.5, 0.58). )
G1 E32.0422
( Linear move to (48.6171, 66.5, 0.58). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<loop> outer )
( Set extruder speed to 7.5. )
M108 S7.5
( Linear move to (49.29, 66.5, 0.58). )
G1 X49.29 Y66.5 Z0.58 F6000.0
( Linear move to (49.29, 66.5, 0.58). )
G1 F1200.0
( Linear move to (49.29, 66.5, 0.58). )
G1 E32.0422
( Linear move to (49.29, 66.5, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (49.0776, 65.4323, 0.58). )
G1 X49.0776 Y65.4323 Z0.58 F540.0 E32.0728
( Linear move to (48.6737, 64.8278, 0.58). )
G1 X48.6737 Y64.8278 Z0.58 F540.0 E32.0932
( Linear move to (48.8192, 64.02, 0.58). )
G1 X48.8192 Y64.02 Z0.58 F540.0 E32.1162
( Linear move to (69.8541, 64.02, 0.58). )
G1 X69.8541 Y64.02 Z0.58 F540.0 E32.7064
( Linear move to (70.2724, 64.9085, 0.58). )
G1 X70.2724 Y64.9085 Z0.58 F540.0 E32.734
( Linear move to (69.9224, 65.4323, 0.58). )
G1 X69.9224 Y65.4323 Z0.58 F540.0 E32.7517
( Linear move to (69.71, 66.5, 0.58). )
G1 X69.71 Y66.5 Z0.58 F540.0 E32.7822
( Linear move to (69.9224, 67.5677, 0.58). )
G1 X69.9224 Y67.5677 Z0.58 F540.0 E32.8128
( Linear move to (70.3065, 68.1424, 0.58). )
G1 X70.3065 Y68.1424 Z0.58 F540.0 E32.8322
( Linear move to (70.0668, 68.98, 0.58). )
G1 X70.0668 Y68.98 Z0.58 F540.0 E32.8566
( Linear move to (48.7787, 68.98, 0.58). )
G1 X48.7787 Y68.98 Z0.58 F540.0 E33.454
( Linear move to (48.6663, 68.1832, 0.58). )
G1 X48.6663 Y68.1832 Z0.58 F540.0 E33.4765
( Linear move to (49.0776, 67.5677, 0.58). )
G1 X49.0776 Y67.5677 Z0.58 F540.0 E33.4973
( Linear move to (49.29, 66.5, 0.58). )
G1 X49.29 Y66.5 Z0.58 F540.0 E33.5279
( Linear move to (49.29, 66.5, 0.58). )
G1 F1200.0
( Linear move to (49.29, 66.5, 0.58). )
G1 E32.5279
( Linear move to (49.29, 66.5, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (44.4083, 64.7052, 0.58). )
G1 X44.4083 Y64.7052 Z0.58 F6000.0
( Linear move to (44.4083, 64.7052, 0.58). )
G1 F1200.0
( Linear move to (44.4083, 64.7052, 0.58). )
G1 E33.5279
( Linear move to (44.4083, 64.7052, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (43.9224, 65.4323, 0.58). )
G1 X43.9224 Y65.4323 Z0.58 F540.0 E33.5524
( Linear move to (43.71, 66.5, 0.58). )
G1 X43.71 Y66.5 Z0.58 F540.0 E33.583
( Linear move to (43.9224, 67.5677, 0.58). )
G1 X43.9224 Y67.5677 Z0.58 F540.0 E33.6135
( Linear move to (44.3971, 68.278, 0.58). )
G1 X44.3971 Y68.278 Z0.58 F540.0 E33.6375
( Linear move to (44.5557, 68.9868, 0.58). )
G1 X44.5557 Y68.9868 Z0.58 F540.0 E33.6579
( Linear move to (31.02, 68.98, 0.58). )
G1 X31.02 Y68.98 Z0.58 F540.0 E34.0377
( Linear move to (31.02, 64.02, 0.58). )
G1 X31.02 Y64.02 Z0.58 F540.0 E34.1768
( Linear move to (34.9913, 64.02, 0.58). )
G1 X34.9913 Y64.02 Z0.58 F540.0 E34.2883
( Linear move to (34.9913, 65.8421, 0.58). )
G1 X34.9913 Y65.8421 Z0.58 F540.0 E34.3394
( Linear move to (43.0223, 65.8421, 0.58). )
G1 X43.0223 Y65.8421 Z0.58 F540.0 E34.5648
( Linear move to (43.0223, 64.02, 0.58). )
G1 X43.0223 Y64.02 Z0.58 F540.0 E34.6159
( Linear move to (44.6738, 63.9658, 0.58). )
G1 X44.6738 Y63.9658 Z0.58 F540.0 E34.6623
( Linear move to (44.4083, 64.7052, 0.58). )
G1 X44.4083 Y64.7052 Z0.58 F540.0 E34.6843
( Linear move to (44.4083, 64.7052, 0.58). )
G1 F1200.0
( Linear move to (44.4083, 64.7052, 0.58). )
G1 E33.6843
( Linear move to (44.4083, 64.7052, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (73.9814, 68.8012, 0.58). )
G1 X73.9814 Y68.8012 Z0.58 F6000.0
( Linear move to (73.9814, 68.8012, 0.58). )
G1 F1200.0
( Linear move to (73.9814, 68.8012, 0.58). )
G1 E34.6843
( Linear move to (73.9814, 68.8012, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (74.4728, 68.4728, 0.58). )
G1 X74.4728 Y68.4728 Z0.58 F540.0 E34.7009
( Linear move to (75.0776, 67.5677, 0.58). )
G1 X75.0776 Y67.5677 Z0.58 F540.0 E34.7314
( Linear move to (75.29, 66.5, 0.58). )
G1 X75.29 Y66.5 Z0.58 F540.0 E34.762
( Linear move to (75.0776, 65.4323, 0.58). )
G1 X75.0776 Y65.4323 Z0.58 F540.0 E34.7925
( Linear move to (74.7101, 64.8824, 0.58). )
G1 X74.7101 Y64.8824 Z0.58 F540.0 E34.8111
( Linear move to (75.0338, 64.02, 0.58). )
G1 X75.0338 Y64.02 Z0.58 F540.0 E34.8369
( Linear move to (76.9913, 64.02, 0.58). )
G1 X76.9913 Y64.02 Z0.58 F540.0 E34.8919
( Linear move to (76.9913, 65.8421, 0.58). )
G1 X76.9913 Y65.8421 Z0.58 F540.0 E34.943
( Linear move to (85.0223, 65.8421, 0.58). )
G1 X85.0223 Y65.8421 Z0.58 F540.0 E35.1683
( Linear move to (85.0223, 64.02, 0.58). )
G1 X85.0223 Y64.02 Z0.58 F540.0 E35.2195
( Linear move to (88.98, 64.02, 0.58). )
G1 X88.98 Y64.02 Z0.58 F540.0 E35.3305
( Linear move to (88.98, 78.98, 0.58). )
G1 X88.98 Y78.98 Z0.58 F540.0 E35.7503
( Linear move to (83.02, 78.98, 0.58). )
G1 X83.02 Y78.98 Z0.58 F540.0 E35.9176
( Linear move to (83.02, 68.98, 0.58). )
G1 X83.02 Y68.98 Z0.58 F540.0 E36.1982
( Linear move to (74.0071, 68.98, 0.58). )
G1 X74.0071 Y68.98 Z0.58 F540.0 E36.4511
( Linear move to (73.9814, 68.8012, 0.58). )
G1 X73.9814 Y68.8012 Z0.58 F540.0 E36.4561
( Linear move to (73.9814, 68.8012, 0.58). )
G1 F1200.0
( Linear move to (73.9814, 68.8012, 0.58). )
G1 E35.9598
( Linear move to (73.9814, 68.8012, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X76.9913 Y65.8421 Z0.38 </infillPoint>)
(<infillPoint> X85.0223 Y65.8421 Z0.38 </infillPoint>)
(<infillPoint> X85.0223 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X88.98 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X88.98 Y78.98 Z0.38 </infillPoint>)
(<infillPoint> X83.02 Y78.98 Z0.38 </infillPoint>)
(<infillPoint> X83.02 Y68.98 Z0.38 </infillPoint>)
(<infillPoint> X74.0071 Y68.98 Z0.38 </infillPoint>)
(<infillPoint> X73.9814 Y68.8012 Z0.38 </infillPoint>)
(<infillPoint> X74.4728 Y68.4728 Z0.38 </infillPoint>)
(<infillPoint> X75.0776 Y67.5677 Z0.38 </infillPoint>)
(<infillPoint> X75.29 Y66.5 Z0.38 </infillPoint>)
(<infillPoint> X75.0776 Y65.4323 Z0.38 </infillPoint>)
(<infillPoint> X74.7101 Y64.8824 Z0.38 </infillPoint>)
(<infillPoint> X75.0338 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X76.9913 Y64.02 Z0.38 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X70.0668 Y68.98 Z0.38 </infillPoint>)
(<infillPoint> X48.7787 Y68.98 Z0.38 </infillPoint>)
(<infillPoint> X48.6663 Y68.1832 Z0.38 </infillPoint>)
(<infillPoint> X49.0776 Y67.5677 Z0.38 </infillPoint>)
(<infillPoint> X49.29 Y66.5 Z0.38 </infillPoint>)
(<infillPoint> X49.0776 Y65.4323 Z0.38 </infillPoint>)
(<infillPoint> X48.6737 Y64.8278 Z0.38 </infillPoint>)
(<infillPoint> X48.8192 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X69.8541 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X70.2724 Y64.9085 Z0.38 </infillPoint>)
(<infillPoint> X69.9224 Y65.4323 Z0.38 </infillPoint>)
(<infillPoint> X69.71 Y66.5 Z0.38 </infillPoint>)
(<infillPoint> X69.9224 Y67.5677 Z0.38 </infillPoint>)
(<infillPoint> X70.3065 Y68.1424 Z0.38 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X44.5557 Y68.9868 Z0.38 </infillPoint>)
(<infillPoint> X31.02 Y68.98 Z0.38 </infillPoint>)
(<infillPoint> X31.02 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X34.9913 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X34.9913 Y65.8421 Z0.38 </infillPoint>)
(<infillPoint> X43.0223 Y65.8421 Z0.38 </infillPoint>)
(<infillPoint> X43.0223 Y64.02 Z0.38 </infillPoint>)
(<infillPoint> X44.6738 Y63.9658 Z0.38 </infillPoint>)
(<infillPoint> X44.4083 Y64.7052 Z0.38 </infillPoint>)
(<infillPoint> X43.9224 Y65.4323 Z0.38 </infillPoint>)
(<infillPoint> X43.71 Y66.5 Z0.38 </infillPoint>)
(<infillPoint> X43.9224 Y67.5677 Z0.38 </infillPoint>)
(<infillPoint> X44.3971 Y68.278 Z0.38 </infillPoint>)
(</infillBoundary>)
( Linear move to (75.4406, 68.47, 0.58). )
G1 X75.4406 Y68.47 Z0.58 F6000.0
( Linear move to (75.4406, 68.47, 0.58). )
G1 F1200.0
( Linear move to (75.4406, 68.47, 0.58). )
G1 E36.4561
( Linear move to (75.4406, 68.47, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (75.2292, 68.2587, 0.58). )
G1 X75.2292 Y68.2587 Z0.58 F540.0 E36.4645
( Linear move to (75.5626, 67.7435, 0.58). )
G1 X75.5626 Y67.7435 Z0.58 F540.0 E36.4817
( Linear move to (76.2891, 68.47, 0.58). )
G1 X76.2891 Y68.47 Z0.58 F540.0 E36.5106
( Linear move to (77.1376, 68.47, 0.58). )
G1 X77.1376 Y68.47 Z0.58 F540.0 E36.5344
( Linear move to (75.7034, 67.0358, 0.58). )
G1 X75.7034 Y67.0358 Z0.58 F540.0 E36.5913
( Linear move to (75.7588, 66.2426, 0.58). )
G1 X75.7588 Y66.2426 Z0.58 F540.0 E36.6136
( Linear move to (77.9861, 68.47, 0.58). )
G1 X77.9861 Y68.47 Z0.58 F540.0 E36.702
( Linear move to (78.8347, 68.47, 0.58). )
G1 X78.8347 Y68.47 Z0.58 F540.0 E36.7258
( Linear move to (75.4776, 65.1129, 0.58). )
G1 X75.4776 Y65.1129 Z0.58 F540.0 E36.859
( Linear move to (75.7839, 64.5707, 0.58). )
G1 X75.7839 Y64.5707 Z0.58 F540.0 E36.8765
( Linear move to (76.4813, 65.2681, 0.58). )
G1 X76.4813 Y65.2681 Z0.58 F540.0 E36.9042
( Linear move to (76.4813, 65.2681, 0.58). )
G1 F1200.0
( Linear move to (76.4813, 65.2681, 0.58). )
G1 E36.3712
( Linear move to (76.4813, 65.2681, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (77.5653, 66.3521, 0.58). )
G1 X77.5653 Y66.3521 Z0.58 F6000.0
( Linear move to (77.5653, 66.3521, 0.58). )
G1 F1200.0
( Linear move to (77.5653, 66.3521, 0.58). )
G1 E36.9042
( Linear move to (77.5653, 66.3521, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (79.6832, 68.47, 0.58). )
G1 X79.6832 Y68.47 Z0.58 F540.0 E36.9882
( Linear move to (80.5317, 68.47, 0.58). )
G1 X80.5317 Y68.47 Z0.58 F540.0 E37.012
( Linear move to (78.4138, 66.3521, 0.58). )
G1 X78.4138 Y66.3521 Z0.58 F540.0 E37.0961
( Linear move to (79.2624, 66.3521, 0.58). )
G1 X79.2624 Y66.3521 Z0.58 F540.0 E37.1199
( Linear move to (81.3803, 68.47, 0.58). )
G1 X81.3803 Y68.47 Z0.58 F540.0 E37.2039
( Linear move to (82.2288, 68.47, 0.58). )
G1 X82.2288 Y68.47 Z0.58 F540.0 E37.2277
( Linear move to (80.1109, 66.3521, 0.58). )
G1 X80.1109 Y66.3521 Z0.58 F540.0 E37.3118
( Linear move to (80.9594, 66.3521, 0.58). )
G1 X80.9594 Y66.3521 Z0.58 F540.0 E37.3356
( Linear move to (88.47, 73.8627, 0.58). )
G1 X88.47 Y73.8627 Z0.58 F540.0 E37.6336
( Linear move to (88.47, 73.0142, 0.58). )
G1 X88.47 Y73.0142 Z0.58 F540.0 E37.6575
( Linear move to (81.8079, 66.3521, 0.58). )
G1 X81.8079 Y66.3521 Z0.58 F540.0 E37.9218
( Linear move to (82.6565, 66.3521, 0.58). )
G1 X82.6565 Y66.3521 Z0.58 F540.0 E37.9456
( Linear move to (88.47, 72.1656, 0.58). )
G1 X88.47 Y72.1656 Z0.58 F540.0 E38.1763
( Linear move to (88.47, 71.3171, 0.58). )
G1 X88.47 Y71.3171 Z0.58 F540.0 E38.2001
( Linear move to (83.505, 66.3521, 0.58). )
G1 X83.505 Y66.3521 Z0.58 F540.0 E38.3972
( Linear move to (84.3535, 66.3521, 0.58). )
G1 X84.3535 Y66.3521 Z0.58 F540.0 E38.421
( Linear move to (88.47, 70.4686, 0.58). )
G1 X88.47 Y70.4686 Z0.58 F540.0 E38.5843
( Linear move to (88.47, 69.62, 0.58). )
G1 X88.47 Y69.62 Z0.58 F540.0 E38.6082
( Linear move to (85.2021, 66.3521, 0.58). )
G1 X85.2021 Y66.3521 Z0.58 F540.0 E38.7378
( Linear move to (85.5323, 65.8338, 0.58). )
G1 X85.5323 Y65.8338 Z0.58 F540.0 E38.7551
( Linear move to (88.47, 68.7715, 0.58). )
G1 X88.47 Y68.7715 Z0.58 F540.0 E38.8717
( Linear move to (88.47, 67.923, 0.58). )
G1 X88.47 Y67.923 Z0.58 F540.0 E38.8955
( Linear move to (85.5323, 64.9853, 0.58). )
G1 X85.5323 Y64.9853 Z0.58 F540.0 E39.012
( Linear move to (85.9365, 64.541, 0.58). )
G1 X85.9365 Y64.541 Z0.58 F540.0 E39.0289
( Linear move to (88.47, 67.0745, 0.58). )
G1 X88.47 Y67.0745 Z0.58 F540.0 E39.1294
( Linear move to (88.47, 66.2259, 0.58). )
G1 X88.47 Y66.2259 Z0.58 F540.0 E39.1532
( Linear move to (86.7741, 64.53, 0.58). )
G1 X86.7741 Y64.53 Z0.58 F540.0 E39.2205
( Linear move to (87.6226, 64.53, 0.58). )
G1 X87.6226 Y64.53 Z0.58 F540.0 E39.2444
( Linear move to (88.47, 65.3774, 0.58). )
G1 X88.47 Y65.3774 Z0.58 F540.0 E39.278
( Linear move to (88.47, 65.3774, 0.58). )
G1 F1200.0
( Linear move to (88.47, 65.3774, 0.58). )
G1 E38.278
( Linear move to (88.47, 65.3774, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (83.53, 69.7712, 0.58). )
G1 X83.53 Y69.7712 Z0.58 F6000.0
( Linear move to (83.53, 69.7712, 0.58). )
G1 F1200.0
( Linear move to (83.53, 69.7712, 0.58). )
G1 E39.278
( Linear move to (83.53, 69.7712, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (88.47, 74.7112, 0.58). )
G1 X88.47 Y74.7112 Z0.58 F540.0 E39.474
( Linear move to (88.47, 75.5597, 0.58). )
G1 X88.47 Y75.5597 Z0.58 F540.0 E39.4978
( Linear move to (83.53, 70.6197, 0.58). )
G1 X83.53 Y70.6197 Z0.58 F540.0 E39.6939
( Linear move to (83.53, 71.4683, 0.58). )
G1 X83.53 Y71.4683 Z0.58 F540.0 E39.7177
( Linear move to (88.47, 76.4083, 0.58). )
G1 X88.47 Y76.4083 Z0.58 F540.0 E39.9137
( Linear move to (88.47, 77.2568, 0.58). )
G1 X88.47 Y77.2568 Z0.58 F540.0 E39.9375
( Linear move to (83.53, 72.3168, 0.58). )
G1 X83.53 Y72.3168 Z0.58 F540.0 E40.1336
( Linear move to (83.53, 73.1653, 0.58). )
G1 X83.53 Y73.1653 Z0.58 F540.0 E40.1574
( Linear move to (88.4447, 78.08, 0.58). )
G1 X88.4447 Y78.08 Z0.58 F540.0 E40.3524
( Linear move to (87.9861, 78.47, 0.58). )
G1 X87.9861 Y78.47 Z0.58 F540.0 E40.3693
( Linear move to (83.53, 74.0139, 0.58). )
G1 X83.53 Y74.0139 Z0.58 F540.0 E40.5461
( Linear move to (83.53, 74.8624, 0.58). )
G1 X83.53 Y74.8624 Z0.58 F540.0 E40.5699
( Linear move to (87.1376, 78.47, 0.58). )
G1 X87.1376 Y78.47 Z0.58 F540.0 E40.7131
( Linear move to (86.2891, 78.47, 0.58). )
G1 X86.2891 Y78.47 Z0.58 F540.0 E40.7369
( Linear move to (83.53, 75.7109, 0.58). )
G1 X83.53 Y75.7109 Z0.58 F540.0 E40.8464
( Linear move to (83.53, 76.5594, 0.58). )
G1 X83.53 Y76.5594 Z0.58 F540.0 E40.8702
( Linear move to (85.4406, 78.47, 0.58). )
G1 X85.4406 Y78.47 Z0.58 F540.0 E40.946
( Linear move to (84.592, 78.47, 0.58). )
G1 X84.592 Y78.47 Z0.58 F540.0 E40.9698
( Linear move to (83.53, 77.408, 0.58). )
G1 X83.53 Y77.408 Z0.58 F540.0 E41.012
( Linear move to (83.53, 77.408, 0.58). )
G1 F1200.0
( Linear move to (83.53, 77.408, 0.58). )
G1 E40.012
( Linear move to (83.53, 77.408, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (49.4472, 67.9325, 0.58). )
G1 X49.4472 Y67.9325 Z0.58 F6000.0
( Linear move to (49.4472, 67.9325, 0.58). )
G1 F1200.0
( Linear move to (49.4472, 67.9325, 0.58). )
G1 E41.012
( Linear move to (49.4472, 67.9325, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (49.9847, 68.47, 0.58). )
G1 X49.9847 Y68.47 Z0.58 F540.0 E41.0333
( Linear move to (50.8332, 68.47, 0.58). )
G1 X50.8332 Y68.47 Z0.58 F540.0 E41.0571
( Linear move to (49.6529, 67.2897, 0.58). )
G1 X49.6529 Y67.2897 Z0.58 F540.0 E41.104
( Linear move to (49.7937, 66.5819, 0.58). )
G1 X49.7937 Y66.5819 Z0.58 F540.0 E41.1242
( Linear move to (51.6818, 68.47, 0.58). )
G1 X51.6818 Y68.47 Z0.58 F540.0 E41.1991
( Linear move to (52.5303, 68.47, 0.58). )
G1 X52.5303 Y68.47 Z0.58 F540.0 E41.2229
( Linear move to (49.6237, 65.5634, 0.58). )
G1 X49.6237 Y65.5634 Z0.58 F540.0 E41.3383
( Linear move to (49.5127, 64.6038, 0.58). )
G1 X49.5127 Y64.6038 Z0.58 F540.0 E41.3654
( Linear move to (53.3788, 68.47, 0.58). )
G1 X53.3788 Y68.47 Z0.58 F540.0 E41.5188
( Linear move to (54.2274, 68.47, 0.58). )
G1 X54.2274 Y68.47 Z0.58 F540.0 E41.5426
( Linear move to (50.2874, 64.53, 0.58). )
G1 X50.2874 Y64.53 Z0.58 F540.0 E41.699
( Linear move to (51.1359, 64.53, 0.58). )
G1 X51.1359 Y64.53 Z0.58 F540.0 E41.7228
( Linear move to (55.0759, 68.47, 0.58). )
G1 X55.0759 Y68.47 Z0.58 F540.0 E41.8791
( Linear move to (55.9244, 68.47, 0.58). )
G1 X55.9244 Y68.47 Z0.58 F540.0 E41.9029
( Linear move to (51.9844, 64.53, 0.58). )
G1 X51.9844 Y64.53 Z0.58 F540.0 E42.0593
( Linear move to (52.8329, 64.53, 0.58). )
G1 X52.8329 Y64.53 Z0.58 F540.0 E42.0831
( Linear move to (56.7729, 68.47, 0.58). )
G1 X56.7729 Y68.47 Z0.58 F540.0 E42.2395
( Linear move to (57.6215, 68.47, 0.58). )
G1 X57.6215 Y68.47 Z0.58 F540.0 E42.2633
( Linear move to (53.6815, 64.53, 0.58). )
G1 X53.6815 Y64.53 Z0.58 F540.0 E42.4196
( Linear move to (54.53, 64.53, 0.58). )
G1 X54.53 Y64.53 Z0.58 F540.0 E42.4434
( Linear move to (58.47, 68.47, 0.58). )
G1 X58.47 Y68.47 Z0.58 F540.0 E42.5998
( Linear move to (59.3185, 68.47, 0.58). )
G1 X59.3185 Y68.47 Z0.58 F540.0 E42.6236
( Linear move to (55.3785, 64.53, 0.58). )
G1 X55.3785 Y64.53 Z0.58 F540.0 E42.78
( Linear move to (56.2271, 64.53, 0.58). )
G1 X56.2271 Y64.53 Z0.58 F540.0 E42.8038
( Linear move to (60.1671, 68.47, 0.58). )
G1 X60.1671 Y68.47 Z0.58 F540.0 E42.9601
( Linear move to (61.0156, 68.47, 0.58). )
G1 X61.0156 Y68.47 Z0.58 F540.0 E42.9839
( Linear move to (57.0756, 64.53, 0.58). )
G1 X57.0756 Y64.53 Z0.58 F540.0 E43.1403
( Linear move to (57.9241, 64.53, 0.58). )
G1 X57.9241 Y64.53 Z0.58 F540.0 E43.1641
( Linear move to (61.8641, 68.47, 0.58). )
G1 X61.8641 Y68.47 Z0.58 F540.0 E43.3204
( Linear move to (62.7126, 68.47, 0.58). )
G1 X62.7126 Y68.47 Z0.58 F540.0 E43.3442
( Linear move to (58.7726, 64.53, 0.58). )
G1 X58.7726 Y64.53 Z0.58 F540.0 E43.5006
( Linear move to (59.6212, 64.53, 0.58). )
G1 X59.6212 Y64.53 Z0.58 F540.0 E43.5244
( Linear move to (63.5612, 68.47, 0.58). )
G1 X63.5612 Y68.47 Z0.58 F540.0 E43.6808
( Linear move to (64.4097, 68.47, 0.58). )
G1 X64.4097 Y68.47 Z0.58 F540.0 E43.7046
( Linear move to (60.4697, 64.53, 0.58). )
G1 X60.4697 Y64.53 Z0.58 F540.0 E43.8609
( Linear move to (61.3182, 64.53, 0.58). )
G1 X61.3182 Y64.53 Z0.58 F540.0 E43.8847
( Linear move to (65.2582, 68.47, 0.58). )
G1 X65.2582 Y68.47 Z0.58 F540.0 E44.0411
( Linear move to (66.1068, 68.47, 0.58). )
G1 X66.1068 Y68.47 Z0.58 F540.0 E44.0649
( Linear move to (62.1668, 64.53, 0.58). )
G1 X62.1668 Y64.53 Z0.58 F540.0 E44.2213
( Linear move to (63.0153, 64.53, 0.58). )
G1 X63.0153 Y64.53 Z0.58 F540.0 E44.2451
( Linear move to (66.9553, 68.47, 0.58). )
G1 X66.9553 Y68.47 Z0.58 F540.0 E44.4014
( Linear move to (67.8038, 68.47, 0.58). )
G1 X67.8038 Y68.47 Z0.58 F540.0 E44.4252
( Linear move to (63.8638, 64.53, 0.58). )
G1 X63.8638 Y64.53 Z0.58 F540.0 E44.5816
( Linear move to (64.7123, 64.53, 0.58). )
G1 X64.7123 Y64.53 Z0.58 F540.0 E44.6054
( Linear move to (68.6523, 68.47, 0.58). )
G1 X68.6523 Y68.47 Z0.58 F540.0 E44.7617
( Linear move to (69.4109, 68.3801, 0.58). )
G1 X69.4109 Y68.3801 Z0.58 F540.0 E44.7832
( Linear move to (65.5609, 64.53, 0.58). )
G1 X65.5609 Y64.53 Z0.58 F540.0 E44.936
( Linear move to (66.4094, 64.53, 0.58). )
G1 X66.4094 Y64.53 Z0.58 F540.0 E44.9598
( Linear move to (69.3913, 67.5119, 0.58). )
G1 X69.3913 Y67.5119 Z0.58 F540.0 E45.0781
( Linear move to (69.1963, 66.4684, 0.58). )
G1 X69.1963 Y66.4684 Z0.58 F540.0 E45.1079
( Linear move to (67.2579, 64.53, 0.58). )
G1 X67.2579 Y64.53 Z0.58 F540.0 E45.1848
( Linear move to (68.1065, 64.53, 0.58). )
G1 X68.1065 Y64.53 Z0.58 F540.0 E45.2086
( Linear move to (69.3371, 65.7606, 0.58). )
G1 X69.3371 Y65.7606 Z0.58 F540.0 E45.2575
( Linear move to (69.5286, 65.1036, 0.58). )
G1 X69.5286 Y65.1036 Z0.58 F540.0 E45.2767
( Linear move to (68.955, 64.53, 0.58). )
G1 X68.955 Y64.53 Z0.58 F540.0 E45.2994
( Linear move to (68.955, 64.53, 0.58). )
G1 F1200.0
( Linear move to (68.955, 64.53, 0.58). )
G1 E44.2994
( Linear move to (68.955, 64.53, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (43.2562, 66.8326, 0.58). )
G1 X43.2562 Y66.8326 Z0.58 F6000.0
( Linear move to (43.2562, 66.8326, 0.58). )
G1 F1200.0
( Linear move to (43.2562, 66.8326, 0.58). )
G1 E45.2994
( Linear move to (43.2562, 66.8326, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (42.7756, 66.3521, 0.58). )
G1 X42.7756 Y66.3521 Z0.58 F540.0 E45.3185
( Linear move to (41.9271, 66.3521, 0.58). )
G1 X41.9271 Y66.3521 Z0.58 F540.0 E45.3423
( Linear move to (43.6439, 68.0689, 0.58). )
G1 X43.6439 Y68.0689 Z0.58 F540.0 E45.4104
( Linear move to (43.2027, 68.4762, 0.58). )
G1 X43.2027 Y68.4762 Z0.58 F540.0 E45.4273
( Linear move to (41.0786, 66.3521, 0.58). )
G1 X41.0786 Y66.3521 Z0.58 F540.0 E45.5116
( Linear move to (40.2301, 66.3521, 0.58). )
G1 X40.2301 Y66.3521 Z0.58 F540.0 E45.5354
( Linear move to (42.3537, 68.4757, 0.58). )
G1 X42.3537 Y68.4757 Z0.58 F540.0 E45.6196
( Linear move to (41.5047, 68.4753, 0.58). )
G1 X41.5047 Y68.4753 Z0.58 F540.0 E45.6435
( Linear move to (39.3815, 66.3521, 0.58). )
G1 X39.3815 Y66.3521 Z0.58 F540.0 E45.7277
( Linear move to (38.533, 66.3521, 0.58). )
G1 X38.533 Y66.3521 Z0.58 F540.0 E45.7515
( Linear move to (40.6558, 68.4749, 0.58). )
G1 X40.6558 Y68.4749 Z0.58 F540.0 E45.8358
( Linear move to (39.8068, 68.4744, 0.58). )
G1 X39.8068 Y68.4744 Z0.58 F540.0 E45.8596
( Linear move to (37.6845, 66.3521, 0.58). )
G1 X37.6845 Y66.3521 Z0.58 F540.0 E45.9438
( Linear move to (36.836, 66.3521, 0.58). )
G1 X36.836 Y66.3521 Z0.58 F540.0 E45.9676
( Linear move to (38.9579, 68.474, 0.58). )
G1 X38.9579 Y68.474 Z0.58 F540.0 E46.0518
( Linear move to (38.1089, 68.4736, 0.58). )
G1 X38.1089 Y68.4736 Z0.58 F540.0 E46.0757
( Linear move to (35.9874, 66.3521, 0.58). )
G1 X35.9874 Y66.3521 Z0.58 F540.0 E46.1598
( Linear move to (35.1389, 66.3521, 0.58). )
G1 X35.1389 Y66.3521 Z0.58 F540.0 E46.1837
( Linear move to (37.26, 68.4732, 0.58). )
G1 X37.26 Y68.4732 Z0.58 F540.0 E46.2678
( Linear move to (36.411, 68.4727, 0.58). )
G1 X36.411 Y68.4727 Z0.58 F540.0 E46.2916
( Linear move to (32.4683, 64.53, 0.58). )
G1 X32.4683 Y64.53 Z0.58 F540.0 E46.4481
( Linear move to (33.3168, 64.53, 0.58). )
G1 X33.3168 Y64.53 Z0.58 F540.0 E46.4719
( Linear move to (34.4813, 65.6945, 0.58). )
G1 X34.4813 Y65.6945 Z0.58 F540.0 E46.5181
( Linear move to (34.4813, 65.6945, 0.58). )
G1 F1200.0
( Linear move to (34.4813, 65.6945, 0.58). )
G1 E45.5181
( Linear move to (34.4813, 65.6945, 0.58). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (35.562, 68.4723, 0.58). )
G1 X35.562 Y68.4723 Z0.58 F6000.0
( Linear move to (35.562, 68.4723, 0.58). )
G1 F1200.0
( Linear move to (35.562, 68.4723, 0.58). )
G1 E46.5181
( Linear move to (35.562, 68.4723, 0.58). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (31.7825, 64.6928, 0.58). )
G1 X31.7825 Y64.6928 Z0.58 F540.0 E46.6681
( Linear move to (31.53, 65.2888, 0.58). )
G1 X31.53 Y65.2888 Z0.58 F540.0 E46.6863
( Linear move to (34.7131, 68.4719, 0.58). )
G1 X34.7131 Y68.4719 Z0.58 F540.0 E46.8126
( Linear move to (33.8641, 68.4714, 0.58). )
G1 X33.8641 Y68.4714 Z0.58 F540.0 E46.8364
( Linear move to (31.53, 66.1373, 0.58). )
G1 X31.53 Y66.1373 Z0.58 F540.0 E46.929
( Linear move to (31.53, 66.9858, 0.58). )
G1 X31.53 Y66.9858 Z0.58 F540.0 E46.9528
( Linear move to (33.0152, 68.471, 0.58). )
G1 X33.0152 Y68.471 Z0.58 F540.0 E47.0118
( Linear move to (32.1662, 68.4706, 0.58). )
G1 X32.1662 Y68.4706 Z0.58 F540.0 E47.0356
( Linear move to (31.53, 67.8344, 0.58). )
G1 X31.53 Y67.8344 Z0.58 F540.0 E47.0609
( Linear move to (31.53, 67.8344, 0.58). )
G1 F1200.0
( Linear move to (31.53, 67.8344, 0.58). )
G1 E46.0609
( Linear move to (31.53, 67.8344, 0.58). )
G1 F540.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
( Set extruder speed to 18.75. )
M108 S18.75
(<layer> 0.98 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X42.0023 Y55.0984 Z0.98 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y55.0984 Z0.98 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y57.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X30.0 Y57.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X30.0 Y50.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X82.0 Y50.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X82.0 Y40.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X90.0 Y40.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X90.0 Y57.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y57.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y55.0984 Z0.98 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y55.0984 Z0.98 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y57.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y57.0 Z0.98 </boundaryPoint>)
(<edge> outer )
( Linear move to (30.36, 50.36, 0.98). )
G1 X30.36 Y50.36 Z0.98 F2627.7138
( Linear move to (30.36, 50.36, 0.98). )
G1 F1200.0
( Linear move to (30.36, 50.36, 0.98). )
G1 E47.0609
( Linear move to (30.36, 50.36, 0.98). )
G1 F2627.7138
( Extruder on, forward. )
M101
( Linear move to (82.36, 50.36, 0.98). )
G1 X82.36 Y50.36 Z0.98 F1350.0 E48.52
( Linear move to (82.36, 40.36, 0.98). )
G1 X82.36 Y40.36 Z0.98 F1350.0 E48.8006
( Linear move to (89.64, 40.36, 0.98). )
G1 X89.64 Y40.36 Z0.98 F1350.0 E49.0049
( Linear move to (89.64, 56.64, 0.98). )
G1 X89.64 Y56.64 Z0.98 F1350.0 E49.4617
( Linear move to (84.3623, 56.64, 0.98). )
G1 X84.3623 Y56.64 Z0.98 F1350.0 E49.6098
( Linear move to (84.3623, 54.7384, 0.98). )
G1 X84.3623 Y54.7384 Z0.98 F1350.0 E49.6632
( Linear move to (77.6513, 54.7384, 0.98). )
G1 X77.6513 Y54.7384 Z0.98 F1350.0 E49.8515
( Linear move to (77.6513, 56.64, 0.98). )
G1 X77.6513 Y56.64 Z0.98 F1350.0 E49.9048
( Linear move to (42.3623, 56.64, 0.98). )
G1 X42.3623 Y56.64 Z0.98 F1350.0 E50.8951
( Linear move to (42.3623, 54.7384, 0.98). )
G1 X42.3623 Y54.7384 Z0.98 F1350.0 E50.9484
( Linear move to (35.6513, 54.7384, 0.98). )
G1 X35.6513 Y54.7384 Z0.98 F1350.0 E51.1367
( Linear move to (35.6513, 56.64, 0.98). )
G1 X35.6513 Y56.64 Z0.98 F1350.0 E51.1901
( Linear move to (30.36, 56.64, 0.98). )
G1 X30.36 Y56.64 Z0.98 F1350.0 E51.3386
( Linear move to (30.36, 50.36, 0.98). )
G1 X30.36 Y50.36 Z0.98 F1350.0 E51.5148
( Linear move to (30.36, 50.36, 0.98). )
G1 F1200.0
( Linear move to (30.36, 50.36, 0.98). )
G1 E50.5148
( Linear move to (30.36, 50.36, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X47.1697 Y55.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y54.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y54.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.25 Y53.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y52.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y52.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y51.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X46.5 Y51.75 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y51.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y52.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y52.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.75 Y53.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y54.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y54.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y55.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X46.5 Y55.25 Z0.98 </boundaryPoint>)
(<edge> inner )
( Linear move to (44.4499, 53.1634, 0.98). )
G1 X44.4499 Y53.1634 Z0.98 F6000.0
( Linear move to (44.4499, 53.1634, 0.98). )
G1 F1200.0
( Linear move to (44.4499, 53.1634, 0.98). )
G1 E51.5148
( Linear move to (44.4499, 53.1634, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (44.3829, 53.5, 0.98). )
G1 X44.3829 Y53.5 Z0.98 F1350.0 E51.5244
( Linear move to (44.5441, 54.3102, 0.98). )
G1 X44.5441 Y54.3102 Z0.98 F1350.0 E51.5476
( Linear move to (45.0031, 54.9969, 0.98). )
G1 X45.0031 Y54.9969 Z0.98 F1350.0 E51.5708
( Linear move to (45.6898, 55.4559, 0.98). )
G1 X45.6898 Y55.4559 Z0.98 F1350.0 E51.5939
( Linear move to (46.5, 55.6171, 0.98). )
G1 X46.5 Y55.6171 Z0.98 F1350.0 E51.6171
( Linear move to (47.3102, 55.4559, 0.98). )
G1 X47.3102 Y55.4559 Z0.98 F1350.0 E51.6403
( Linear move to (47.9969, 54.9969, 0.98). )
G1 X47.9969 Y54.9969 Z0.98 F1350.0 E51.6635
( Linear move to (48.4559, 54.3102, 0.98). )
G1 X48.4559 Y54.3102 Z0.98 F1350.0 E51.6867
( Linear move to (48.6171, 53.5, 0.98). )
G1 X48.6171 Y53.5 Z0.98 F1350.0 E51.7098
( Linear move to (48.4559, 52.6898, 0.98). )
G1 X48.4559 Y52.6898 Z0.98 F1350.0 E51.733
( Linear move to (47.9969, 52.0031, 0.98). )
G1 X47.9969 Y52.0031 Z0.98 F1350.0 E51.7562
( Linear move to (47.3102, 51.5441, 0.98). )
G1 X47.3102 Y51.5441 Z0.98 F1350.0 E51.7794
( Linear move to (46.5, 51.3829, 0.98). )
G1 X46.5 Y51.3829 Z0.98 F1350.0 E51.8026
( Linear move to (45.6898, 51.5441, 0.98). )
G1 X45.6898 Y51.5441 Z0.98 F1350.0 E51.8257
( Linear move to (45.0031, 52.0031, 0.98). )
G1 X45.0031 Y52.0031 Z0.98 F1350.0 E51.8489
( Linear move to (44.5441, 52.6898, 0.98). )
G1 X44.5441 Y52.6898 Z0.98 F1350.0 E51.8721
( Linear move to (44.4499, 53.1634, 0.98). )
G1 X44.4499 Y53.1634 Z0.98 F1350.0 E51.8856
( Linear move to (44.4499, 53.1634, 0.98). )
G1 F1200.0
( Linear move to (44.4499, 53.1634, 0.98). )
G1 E50.8856
( Linear move to (44.4499, 53.1634, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X73.1697 Y51.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X72.5 Y51.75 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y51.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y52.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y52.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.75 Y53.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y54.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y54.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y55.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X72.5 Y55.25 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y55.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y54.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y54.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.25 Y53.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y52.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y52.2626 Z0.98 </boundaryPoint>)
(<edge> inner )
( Linear move to (70.3829, 53.5, 0.98). )
G1 X70.3829 Y53.5 Z0.98 F6000.0
( Linear move to (70.3829, 53.5, 0.98). )
G1 F1200.0
( Linear move to (70.3829, 53.5, 0.98). )
G1 E51.8856
( Linear move to (70.3829, 53.5, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (70.5441, 54.3102, 0.98). )
G1 X70.5441 Y54.3102 Z0.98 F1350.0 E51.9088
( Linear move to (71.0031, 54.9969, 0.98). )
G1 X71.0031 Y54.9969 Z0.98 F1350.0 E51.932
( Linear move to (71.6898, 55.4559, 0.98). )
G1 X71.6898 Y55.4559 Z0.98 F1350.0 E51.9552
( Linear move to (72.5, 55.6171, 0.98). )
G1 X72.5 Y55.6171 Z0.98 F1350.0 E51.9784
( Linear move to (73.3102, 55.4559, 0.98). )
G1 X73.3102 Y55.4559 Z0.98 F1350.0 E52.0015
( Linear move to (73.9969, 54.9969, 0.98). )
G1 X73.9969 Y54.9969 Z0.98 F1350.0 E52.0247
( Linear move to (74.4559, 54.3102, 0.98). )
G1 X74.4559 Y54.3102 Z0.98 F1350.0 E52.0479
( Linear move to (74.6171, 53.5, 0.98). )
G1 X74.6171 Y53.5 Z0.98 F1350.0 E52.0711
( Linear move to (74.4559, 52.6898, 0.98). )
G1 X74.4559 Y52.6898 Z0.98 F1350.0 E52.0942
( Linear move to (73.9969, 52.0031, 0.98). )
G1 X73.9969 Y52.0031 Z0.98 F1350.0 E52.1174
( Linear move to (73.3102, 51.5441, 0.98). )
G1 X73.3102 Y51.5441 Z0.98 F1350.0 E52.1406
( Linear move to (72.5, 51.3829, 0.98). )
G1 X72.5 Y51.3829 Z0.98 F1350.0 E52.1638
( Linear move to (71.6898, 51.5441, 0.98). )
G1 X71.6898 Y51.5441 Z0.98 F1350.0 E52.187
( Linear move to (71.0031, 52.0031, 0.98). )
G1 X71.0031 Y52.0031 Z0.98 F1350.0 E52.2101
( Linear move to (70.5441, 52.6898, 0.98). )
G1 X70.5441 Y52.6898 Z0.98 F1350.0 E52.2333
( Linear move to (70.3829, 53.5, 0.98). )
G1 X70.3829 Y53.5 Z0.98 F1350.0 E52.2565
( Linear move to (70.3829, 53.5, 0.98). )
G1 F1200.0
( Linear move to (70.3829, 53.5, 0.98). )
G1 E52.2565
( Linear move to (70.3829, 53.5, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<loop> outer )
( Set extruder speed to 25.0. )
M108 S25.0
( Linear move to (69.71, 53.5, 0.98). )
G1 X69.71 Y53.5 Z0.98 F6000.0
( Linear move to (69.71, 53.5, 0.98). )
G1 F1200.0
( Linear move to (69.71, 53.5, 0.98). )
G1 E52.2565
( Linear move to (69.71, 53.5, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (69.9224, 54.5677, 0.98). )
G1 X69.9224 Y54.5677 Z0.98 F1800.0 E52.287
( Linear move to (70.2724, 55.0915, 0.98). )
G1 X70.2724 Y55.0915 Z0.98 F1800.0 E52.3047
( Linear move to (69.8541, 55.98, 0.98). )
G1 X69.8541 Y55.98 Z0.98 F1800.0 E52.3323
( Linear move to (48.8192, 55.98, 0.98). )
G1 X48.8192 Y55.98 Z0.98 F1800.0 E52.9225
( Linear move to (48.6737, 55.1722, 0.98). )
G1 X48.6737 Y55.1722 Z0.98 F1800.0 E52.9456
( Linear move to (49.0776, 54.5677, 0.98). )
G1 X49.0776 Y54.5677 Z0.98 F1800.0 E52.966
( Linear move to (49.29, 53.5, 0.98). )
G1 X49.29 Y53.5 Z0.98 F1800.0 E52.9965
( Linear move to (49.0776, 52.4323, 0.98). )
G1 X49.0776 Y52.4323 Z0.98 F1800.0 E53.0271
( Linear move to (48.6663, 51.8168, 0.98). )
G1 X48.6663 Y51.8168 Z0.98 F1800.0 E53.0478
( Linear move to (48.7787, 51.02, 0.98). )
G1 X48.7787 Y51.02 Z0.98 F1800.0 E53.0704
( Linear move to (70.0668, 51.02, 0.98). )
G1 X70.0668 Y51.02 Z0.98 F1800.0 E53.6678
( Linear move to (70.3065, 51.8576, 0.98). )
G1 X70.3065 Y51.8576 Z0.98 F1800.0 E53.6922
( Linear move to (69.9224, 52.4323, 0.98). )
G1 X69.9224 Y52.4323 Z0.98 F1800.0 E53.7116
( Linear move to (69.71, 53.5, 0.98). )
G1 X69.71 Y53.5 Z0.98 F1800.0 E53.7421
( Linear move to (69.71, 53.5, 0.98). )
G1 F1200.0
( Linear move to (69.71, 53.5, 0.98). )
G1 E52.7421
( Linear move to (69.71, 53.5, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (73.9814, 51.1988, 0.98). )
G1 X73.9814 Y51.1988 Z0.98 F6000.0
( Linear move to (73.9814, 51.1988, 0.98). )
G1 F1200.0
( Linear move to (73.9814, 51.1988, 0.98). )
G1 E53.7421
( Linear move to (73.9814, 51.1988, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (74.0071, 51.02, 0.98). )
G1 X74.0071 Y51.02 Z0.98 F1800.0 E53.7472
( Linear move to (83.02, 51.02, 0.98). )
G1 X83.02 Y51.02 Z0.98 F1800.0 E54.0001
( Linear move to (83.02, 41.02, 0.98). )
G1 X83.02 Y41.02 Z0.98 F1800.0 E54.2807
( Linear move to (88.98, 41.02, 0.98). )
G1 X88.98 Y41.02 Z0.98 F1800.0 E54.448
( Linear move to (88.98, 55.98, 0.98). )
G1 X88.98 Y55.98 Z0.98 F1800.0 E54.8677
( Linear move to (85.0223, 55.98, 0.98). )
G1 X85.0223 Y55.98 Z0.98 F1800.0 E54.9788
( Linear move to (85.0223, 54.0784, 0.98). )
G1 X85.0223 Y54.0784 Z0.98 F1800.0 E55.0322
( Linear move to (76.9913, 54.0784, 0.98). )
G1 X76.9913 Y54.0784 Z0.98 F1800.0 E55.2575
( Linear move to (76.9913, 55.98, 0.98). )
G1 X76.9913 Y55.98 Z0.98 F1800.0 E55.3109
( Linear move to (75.0338, 55.98, 0.98). )
G1 X75.0338 Y55.98 Z0.98 F1800.0 E55.3658
( Linear move to (74.7101, 55.1176, 0.98). )
G1 X74.7101 Y55.1176 Z0.98 F1800.0 E55.3916
( Linear move to (75.0776, 54.5677, 0.98). )
G1 X75.0776 Y54.5677 Z0.98 F1800.0 E55.4102
( Linear move to (75.29, 53.5, 0.98). )
G1 X75.29 Y53.5 Z0.98 F1800.0 E55.4408
( Linear move to (75.0776, 52.4323, 0.98). )
G1 X75.0776 Y52.4323 Z0.98 F1800.0 E55.4713
( Linear move to (74.4728, 51.5272, 0.98). )
G1 X74.4728 Y51.5272 Z0.98 F1800.0 E55.5018
( Linear move to (73.9814, 51.1988, 0.98). )
G1 X73.9814 Y51.1988 Z0.98 F1800.0 E55.5184
( Linear move to (73.9814, 51.1988, 0.98). )
G1 F1200.0
( Linear move to (73.9814, 51.1988, 0.98). )
G1 E54.5184
( Linear move to (73.9814, 51.1988, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (44.5557, 51.0132, 0.98). )
G1 X44.5557 Y51.0132 Z0.98 F6000.0
( Linear move to (44.5557, 51.0132, 0.98). )
G1 F1200.0
( Linear move to (44.5557, 51.0132, 0.98). )
G1 E55.5184
( Linear move to (44.5557, 51.0132, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (44.3971, 51.722, 0.98). )
G1 X44.3971 Y51.722 Z0.98 F1800.0 E55.5388
( Linear move to (43.9224, 52.4323, 0.98). )
G1 X43.9224 Y52.4323 Z0.98 F1800.0 E55.5628
( Linear move to (43.71, 53.5, 0.98). )
G1 X43.71 Y53.5 Z0.98 F1800.0 E55.5933
( Linear move to (43.9224, 54.5677, 0.98). )
G1 X43.9224 Y54.5677 Z0.98 F1800.0 E55.6239
( Linear move to (44.4083, 55.2948, 0.98). )
G1 X44.4083 Y55.2948 Z0.98 F1800.0 E55.6484
( Linear move to (44.6738, 56.0342, 0.98). )
G1 X44.6738 Y56.0342 Z0.98 F1800.0 E55.6705
( Linear move to (43.0223, 55.98, 0.98). )
G1 X43.0223 Y55.98 Z0.98 F1800.0 E55.7168
( Linear move to (43.0223, 54.0784, 0.98). )
G1 X43.0223 Y54.0784 Z0.98 F1800.0 E55.7702
( Linear move to (34.9913, 54.0784, 0.98). )
G1 X34.9913 Y54.0784 Z0.98 F1800.0 E55.9955
( Linear move to (34.9913, 55.98, 0.98). )
G1 X34.9913 Y55.98 Z0.98 F1800.0 E56.0489
( Linear move to (31.02, 55.98, 0.98). )
G1 X31.02 Y55.98 Z0.98 F1800.0 E56.1603
( Linear move to (31.02, 51.02, 0.98). )
G1 X31.02 Y51.02 Z0.98 F1800.0 E56.2995
( Linear move to (44.5557, 51.0132, 0.98). )
G1 X44.5557 Y51.0132 Z0.98 F1800.0 E56.6793
( Linear move to (44.5557, 51.0132, 0.98). )
G1 F1200.0
( Linear move to (44.5557, 51.0132, 0.98). )
G1 E55.6793
( Linear move to (44.5557, 51.0132, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X43.0223 Y54.0784 Z0.78 </infillPoint>)
(<infillPoint> X34.9913 Y54.0784 Z0.78 </infillPoint>)
(<infillPoint> X34.9913 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X31.02 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X31.02 Y51.02 Z0.78 </infillPoint>)
(<infillPoint> X44.5557 Y51.0132 Z0.78 </infillPoint>)
(<infillPoint> X44.3971 Y51.722 Z0.78 </infillPoint>)
(<infillPoint> X43.9224 Y52.4323 Z0.78 </infillPoint>)
(<infillPoint> X43.71 Y53.5 Z0.78 </infillPoint>)
(<infillPoint> X43.9224 Y54.5677 Z0.78 </infillPoint>)
(<infillPoint> X44.4083 Y55.2948 Z0.78 </infillPoint>)
(<infillPoint> X44.6738 Y56.0342 Z0.78 </infillPoint>)
(<infillPoint> X43.0223 Y55.98 Z0.78 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X48.7787 Y51.02 Z0.78 </infillPoint>)
(<infillPoint> X70.0668 Y51.02 Z0.78 </infillPoint>)
(<infillPoint> X70.3065 Y51.8576 Z0.78 </infillPoint>)
(<infillPoint> X69.9224 Y52.4323 Z0.78 </infillPoint>)
(<infillPoint> X69.71 Y53.5 Z0.78 </infillPoint>)
(<infillPoint> X69.9224 Y54.5677 Z0.78 </infillPoint>)
(<infillPoint> X70.2724 Y55.0915 Z0.78 </infillPoint>)
(<infillPoint> X69.8541 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X48.8192 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X48.6737 Y55.1722 Z0.78 </infillPoint>)
(<infillPoint> X49.0776 Y54.5677 Z0.78 </infillPoint>)
(<infillPoint> X49.29 Y53.5 Z0.78 </infillPoint>)
(<infillPoint> X49.0776 Y52.4323 Z0.78 </infillPoint>)
(<infillPoint> X48.6663 Y51.8168 Z0.78 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X74.0071 Y51.02 Z0.78 </infillPoint>)
(<infillPoint> X83.02 Y51.02 Z0.78 </infillPoint>)
(<infillPoint> X83.02 Y41.02 Z0.78 </infillPoint>)
(<infillPoint> X88.98 Y41.02 Z0.78 </infillPoint>)
(<infillPoint> X88.98 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X85.0223 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X85.0223 Y54.0784 Z0.78 </infillPoint>)
(<infillPoint> X76.9913 Y54.0784 Z0.78 </infillPoint>)
(<infillPoint> X76.9913 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X75.0338 Y55.98 Z0.78 </infillPoint>)
(<infillPoint> X74.7101 Y55.1176 Z0.78 </infillPoint>)
(<infillPoint> X75.0776 Y54.5677 Z0.78 </infillPoint>)
(<infillPoint> X75.29 Y53.5 Z0.78 </infillPoint>)
(<infillPoint> X75.0776 Y52.4323 Z0.78 </infillPoint>)
(<infillPoint> X74.4728 Y51.5272 Z0.78 </infillPoint>)
(<infillPoint> X73.9814 Y51.1988 Z0.78 </infillPoint>)
(</infillBoundary>)
( Linear move to (32.3491, 55.47, 0.98). )
G1 X32.3491 Y55.47 Z0.98 F6000.0
( Linear move to (32.3491, 55.47, 0.98). )
G1 F1200.0
( Linear move to (32.3491, 55.47, 0.98). )
G1 E56.6793
( Linear move to (32.3491, 55.47, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (36.2918, 51.5273, 0.98). )
G1 X36.2918 Y51.5273 Z0.98 F1800.0 E56.8358
( Linear move to (37.1407, 51.5269, 0.98). )
G1 X37.1407 Y51.5269 Z0.98 F1800.0 E56.8596
( Linear move to (35.0992, 53.5684, 0.98). )
G1 X35.0992 Y53.5684 Z0.98 F1800.0 E56.9406
( Linear move to (35.9477, 53.5684, 0.98). )
G1 X35.9477 Y53.5684 Z0.98 F1800.0 E56.9644
( Linear move to (37.9897, 51.5265, 0.98). )
G1 X37.9897 Y51.5265 Z0.98 F1800.0 E57.0455
( Linear move to (38.8386, 51.526, 0.98). )
G1 X38.8386 Y51.526 Z0.98 F1800.0 E57.0693
( Linear move to (36.7963, 53.5684, 0.98). )
G1 X36.7963 Y53.5684 Z0.98 F1800.0 E57.1503
( Linear move to (37.6448, 53.5684, 0.98). )
G1 X37.6448 Y53.5684 Z0.98 F1800.0 E57.1741
( Linear move to (39.6876, 51.5256, 0.98). )
G1 X39.6876 Y51.5256 Z0.98 F1800.0 E57.2552
( Linear move to (40.5365, 51.5252, 0.98). )
G1 X40.5365 Y51.5252 Z0.98 F1800.0 E57.279
( Linear move to (38.4933, 53.5684, 0.98). )
G1 X38.4933 Y53.5684 Z0.98 F1800.0 E57.3601
( Linear move to (39.3419, 53.5684, 0.98). )
G1 X39.3419 Y53.5684 Z0.98 F1800.0 E57.3839
( Linear move to (41.3855, 51.5248, 0.98). )
G1 X41.3855 Y51.5248 Z0.98 F1800.0 E57.465
( Linear move to (42.2345, 51.5243, 0.98). )
G1 X42.2345 Y51.5243 Z0.98 F1800.0 E57.4888
( Linear move to (40.1904, 53.5684, 0.98). )
G1 X40.1904 Y53.5684 Z0.98 F1800.0 E57.57
( Linear move to (41.0389, 53.5684, 0.98). )
G1 X41.0389 Y53.5684 Z0.98 F1800.0 E57.5938
( Linear move to (43.0834, 51.5239, 0.98). )
G1 X43.0834 Y51.5239 Z0.98 F1800.0 E57.6749
( Linear move to (43.7424, 51.7135, 0.98). )
G1 X43.7424 Y51.7135 Z0.98 F1800.0 E57.6941
( Linear move to (41.8874, 53.5684, 0.98). )
G1 X41.8874 Y53.5684 Z0.98 F1800.0 E57.7678
( Linear move to (42.736, 53.5684, 0.98). )
G1 X42.736 Y53.5684 Z0.98 F1800.0 E57.7916
( Linear move to (43.2858, 53.0186, 0.98). )
G1 X43.2858 Y53.0186 Z0.98 F1800.0 E57.8134
( Linear move to (43.2858, 53.0186, 0.98). )
G1 F1200.0
( Linear move to (43.2858, 53.0186, 0.98). )
G1 E56.8134
( Linear move to (43.2858, 53.0186, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (49.3995, 51.9961, 0.98). )
G1 X49.3995 Y51.9961 Z0.98 F6000.0
( Linear move to (49.3995, 51.9961, 0.98). )
G1 F1200.0
( Linear move to (49.3995, 51.9961, 0.98). )
G1 E57.8134
( Linear move to (49.3995, 51.9961, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (49.8655, 51.53, 0.98). )
G1 X49.8655 Y51.53 Z0.98 F1800.0 E57.8319
( Linear move to (50.7141, 51.53, 0.98). )
G1 X50.7141 Y51.53 Z0.98 F1800.0 E57.8557
( Linear move to (49.6331, 52.6109, 0.98). )
G1 X49.6331 Y52.6109 Z0.98 F1800.0 E57.8986
( Linear move to (49.7739, 53.3187, 0.98). )
G1 X49.7739 Y53.3187 Z0.98 F1800.0 E57.9188
( Linear move to (51.5626, 51.53, 0.98). )
G1 X51.5626 Y51.53 Z0.98 F1800.0 E57.9898
( Linear move to (52.4111, 51.53, 0.98). )
G1 X52.4111 Y51.53 Z0.98 F1800.0 E58.0136
( Linear move to (49.6533, 54.2879, 0.98). )
G1 X49.6533 Y54.2879 Z0.98 F1800.0 E58.1231
( Linear move to (49.4339, 55.3557, 0.98). )
G1 X49.4339 Y55.3557 Z0.98 F1800.0 E58.1537
( Linear move to (53.2597, 51.53, 0.98). )
G1 X53.2597 Y51.53 Z0.98 F1800.0 E58.3055
( Linear move to (54.1082, 51.53, 0.98). )
G1 X54.1082 Y51.53 Z0.98 F1800.0 E58.3293
( Linear move to (50.1682, 55.47, 0.98). )
G1 X50.1682 Y55.47 Z0.98 F1800.0 E58.4856
( Linear move to (51.0167, 55.47, 0.98). )
G1 X51.0167 Y55.47 Z0.98 F1800.0 E58.5095
( Linear move to (54.9567, 51.53, 0.98). )
G1 X54.9567 Y51.53 Z0.98 F1800.0 E58.6658
( Linear move to (55.8052, 51.53, 0.98). )
G1 X55.8052 Y51.53 Z0.98 F1800.0 E58.6896
( Linear move to (51.8652, 55.47, 0.98). )
G1 X51.8652 Y55.47 Z0.98 F1800.0 E58.846
( Linear move to (52.7138, 55.47, 0.98). )
G1 X52.7138 Y55.47 Z0.98 F1800.0 E58.8698
( Linear move to (56.6538, 51.53, 0.98). )
G1 X56.6538 Y51.53 Z0.98 F1800.0 E59.0261
( Linear move to (57.5023, 51.53, 0.98). )
G1 X57.5023 Y51.53 Z0.98 F1800.0 E59.0499
( Linear move to (53.5623, 55.47, 0.98). )
G1 X53.5623 Y55.47 Z0.98 F1800.0 E59.2063
( Linear move to (54.4108, 55.47, 0.98). )
G1 X54.4108 Y55.47 Z0.98 F1800.0 E59.2301
( Linear move to (58.3508, 51.53, 0.98). )
G1 X58.3508 Y51.53 Z0.98 F1800.0 E59.3865
( Linear move to (59.1994, 51.53, 0.98). )
G1 X59.1994 Y51.53 Z0.98 F1800.0 E59.4103
( Linear move to (55.2594, 55.47, 0.98). )
G1 X55.2594 Y55.47 Z0.98 F1800.0 E59.5666
( Linear move to (56.1079, 55.47, 0.98). )
G1 X56.1079 Y55.47 Z0.98 F1800.0 E59.5904
( Linear move to (60.0479, 51.53, 0.98). )
G1 X60.0479 Y51.53 Z0.98 F1800.0 E59.7468
( Linear move to (60.8964, 51.53, 0.98). )
G1 X60.8964 Y51.53 Z0.98 F1800.0 E59.7706
( Linear move to (56.9564, 55.47, 0.98). )
G1 X56.9564 Y55.47 Z0.98 F1800.0 E59.9269
( Linear move to (57.8049, 55.47, 0.98). )
G1 X57.8049 Y55.47 Z0.98 F1800.0 E59.9507
( Linear move to (61.7449, 51.53, 0.98). )
G1 X61.7449 Y51.53 Z0.98 F1800.0 E60.1071
( Linear move to (62.5935, 51.53, 0.98). )
G1 X62.5935 Y51.53 Z0.98 F1800.0 E60.1309
( Linear move to (58.6535, 55.47, 0.98). )
G1 X58.6535 Y55.47 Z0.98 F1800.0 E60.2873
( Linear move to (59.502, 55.47, 0.98). )
G1 X59.502 Y55.47 Z0.98 F1800.0 E60.3111
( Linear move to (63.442, 51.53, 0.98). )
G1 X63.442 Y51.53 Z0.98 F1800.0 E60.4674
( Linear move to (64.2905, 51.53, 0.98). )
G1 X64.2905 Y51.53 Z0.98 F1800.0 E60.4912
( Linear move to (60.3505, 55.47, 0.98). )
G1 X60.3505 Y55.47 Z0.98 F1800.0 E60.6476
( Linear move to (61.199, 55.47, 0.98). )
G1 X61.199 Y55.47 Z0.98 F1800.0 E60.6714
( Linear move to (65.139, 51.53, 0.98). )
G1 X65.139 Y51.53 Z0.98 F1800.0 E60.8278
( Linear move to (65.9876, 51.53, 0.98). )
G1 X65.9876 Y51.53 Z0.98 F1800.0 E60.8516
( Linear move to (62.0476, 55.47, 0.98). )
G1 X62.0476 Y55.47 Z0.98 F1800.0 E61.0079
( Linear move to (62.8961, 55.47, 0.98). )
G1 X62.8961 Y55.47 Z0.98 F1800.0 E61.0317
( Linear move to (66.8361, 51.53, 0.98). )
G1 X66.8361 Y51.53 Z0.98 F1800.0 E61.1881
( Linear move to (67.6846, 51.53, 0.98). )
G1 X67.6846 Y51.53 Z0.98 F1800.0 E61.2119
( Linear move to (63.7446, 55.47, 0.98). )
G1 X63.7446 Y55.47 Z0.98 F1800.0 E61.3682
( Linear move to (64.5932, 55.47, 0.98). )
G1 X64.5932 Y55.47 Z0.98 F1800.0 E61.3921
( Linear move to (68.5332, 51.53, 0.98). )
G1 X68.5332 Y51.53 Z0.98 F1800.0 E61.5484
( Linear move to (69.3316, 51.5801, 0.98). )
G1 X69.3316 Y51.5801 Z0.98 F1800.0 E61.5709
( Linear move to (65.4417, 55.47, 0.98). )
G1 X65.4417 Y55.47 Z0.98 F1800.0 E61.7252
( Linear move to (66.2902, 55.47, 0.98). )
G1 X66.2902 Y55.47 Z0.98 F1800.0 E61.749
( Linear move to (69.4209, 52.3393, 0.98). )
G1 X69.4209 Y52.3393 Z0.98 F1800.0 E61.8733
( Linear move to (69.2102, 53.3985, 0.98). )
G1 X69.2102 Y53.3985 Z0.98 F1800.0 E61.9036
( Linear move to (67.1387, 55.47, 0.98). )
G1 X67.1387 Y55.47 Z0.98 F1800.0 E61.9858
( Linear move to (67.9873, 55.47, 0.98). )
G1 X67.9873 Y55.47 Z0.98 F1800.0 E62.0096
( Linear move to (69.3173, 54.14, 0.98). )
G1 X69.3173 Y54.14 Z0.98 F1800.0 E62.0624
( Linear move to (69.4809, 54.8249, 0.98). )
G1 X69.4809 Y54.8249 Z0.98 F1800.0 E62.0821
( Linear move to (68.8358, 55.47, 0.98). )
G1 X68.8358 Y55.47 Z0.98 F1800.0 E62.1077
( Linear move to (68.8358, 55.47, 0.98). )
G1 F1200.0
( Linear move to (68.8358, 55.47, 0.98). )
G1 E61.1077
( Linear move to (68.8358, 55.47, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (77.867, 51.53, 0.98). )
G1 X77.867 Y51.53 Z0.98 F6000.0
( Linear move to (77.867, 51.53, 0.98). )
G1 F1200.0
( Linear move to (77.867, 51.53, 0.98). )
G1 E62.1077
( Linear move to (77.867, 51.53, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (75.7884, 53.6086, 0.98). )
G1 X75.7884 Y53.6086 Z0.98 F1800.0 E62.1902
( Linear move to (75.6836, 52.8648, 0.98). )
G1 X75.6836 Y52.8648 Z0.98 F1800.0 E62.2113
( Linear move to (77.0184, 51.53, 0.98). )
G1 X77.0184 Y51.53 Z0.98 F1800.0 E62.2643
( Linear move to (76.1699, 51.53, 0.98). )
G1 X76.1699 Y51.53 Z0.98 F1800.0 E62.2881
( Linear move to (75.5214, 52.1785, 0.98). )
G1 X75.5214 Y52.1785 Z0.98 F1800.0 E62.3138
( Linear move to (75.1815, 51.6699, 0.98). )
G1 X75.1815 Y51.6699 Z0.98 F1800.0 E62.331
( Linear move to (75.3214, 51.53, 0.98). )
G1 X75.3214 Y51.53 Z0.98 F1800.0 E62.3365
( Linear move to (75.3214, 51.53, 0.98). )
G1 F1200.0
( Linear move to (75.3214, 51.53, 0.98). )
G1 E61.3365
( Linear move to (75.3214, 51.53, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (83.53, 42.4729, 0.98). )
G1 X83.53 Y42.4729 Z0.98 F6000.0
( Linear move to (83.53, 42.4729, 0.98). )
G1 F1200.0
( Linear move to (83.53, 42.4729, 0.98). )
G1 E62.3365
( Linear move to (83.53, 42.4729, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (84.4729, 41.53, 0.98). )
G1 X84.4729 Y41.53 Z0.98 F1800.0 E62.3739
( Linear move to (85.3214, 41.53, 0.98). )
G1 X85.3214 Y41.53 Z0.98 F1800.0 E62.3977
( Linear move to (83.53, 43.3214, 0.98). )
G1 X83.53 Y43.3214 Z0.98 F1800.0 E62.4688
( Linear move to (83.53, 44.1699, 0.98). )
G1 X83.53 Y44.1699 Z0.98 F1800.0 E62.4926
( Linear move to (86.1699, 41.53, 0.98). )
G1 X86.1699 Y41.53 Z0.98 F1800.0 E62.5974
( Linear move to (87.0184, 41.53, 0.98). )
G1 X87.0184 Y41.53 Z0.98 F1800.0 E62.6212
( Linear move to (83.53, 45.0184, 0.98). )
G1 X83.53 Y45.0184 Z0.98 F1800.0 E62.7596
( Linear move to (83.53, 45.867, 0.98). )
G1 X83.53 Y45.867 Z0.98 F1800.0 E62.7835
( Linear move to (87.867, 41.53, 0.98). )
G1 X87.867 Y41.53 Z0.98 F1800.0 E62.9556
( Linear move to (88.3851, 41.8604, 0.98). )
G1 X88.3851 Y41.8604 Z0.98 F1800.0 E62.9728
( Linear move to (83.53, 46.7155, 0.98). )
G1 X83.53 Y46.7155 Z0.98 F1800.0 E63.1655
( Linear move to (83.53, 47.564, 0.98). )
G1 X83.53 Y47.564 Z0.98 F1800.0 E63.1893
( Linear move to (88.47, 42.624, 0.98). )
G1 X88.47 Y42.624 Z0.98 F1800.0 E63.3853
( Linear move to (88.47, 43.4726, 0.98). )
G1 X88.47 Y43.4726 Z0.98 F1800.0 E63.4091
( Linear move to (83.53, 48.4126, 0.98). )
G1 X83.53 Y48.4126 Z0.98 F1800.0 E63.6052
( Linear move to (83.53, 49.2611, 0.98). )
G1 X83.53 Y49.2611 Z0.98 F1800.0 E63.629
( Linear move to (88.47, 44.3211, 0.98). )
G1 X88.47 Y44.3211 Z0.98 F1800.0 E63.825
( Linear move to (88.47, 45.1696, 0.98). )
G1 X88.47 Y45.1696 Z0.98 F1800.0 E63.8488
( Linear move to (83.53, 50.1096, 0.98). )
G1 X83.53 Y50.1096 Z0.98 F1800.0 E64.0448
( Linear move to (83.53, 50.9581, 0.98). )
G1 X83.53 Y50.9581 Z0.98 F1800.0 E64.0687
( Linear move to (88.47, 46.0181, 0.98). )
G1 X88.47 Y46.0181 Z0.98 F1800.0 E64.2647
( Linear move to (88.47, 46.8667, 0.98). )
G1 X88.47 Y46.8667 Z0.98 F1800.0 E64.2885
( Linear move to (81.7683, 53.5684, 0.98). )
G1 X81.7683 Y53.5684 Z0.98 F1800.0 E64.5545
( Linear move to (80.9197, 53.5684, 0.98). )
G1 X80.9197 Y53.5684 Z0.98 F1800.0 E64.5783
( Linear move to (82.9581, 51.53, 0.98). )
G1 X82.9581 Y51.53 Z0.98 F1800.0 E64.6592
( Linear move to (82.1096, 51.53, 0.98). )
G1 X82.1096 Y51.53 Z0.98 F1800.0 E64.683
( Linear move to (80.0712, 53.5684, 0.98). )
G1 X80.0712 Y53.5684 Z0.98 F1800.0 E64.7639
( Linear move to (79.2227, 53.5684, 0.98). )
G1 X79.2227 Y53.5684 Z0.98 F1800.0 E64.7877
( Linear move to (81.2611, 51.53, 0.98). )
G1 X81.2611 Y51.53 Z0.98 F1800.0 E64.8686
( Linear move to (80.4126, 51.53, 0.98). )
G1 X80.4126 Y51.53 Z0.98 F1800.0 E64.8924
( Linear move to (78.3742, 53.5684, 0.98). )
G1 X78.3742 Y53.5684 Z0.98 F1800.0 E64.9733
( Linear move to (77.5256, 53.5684, 0.98). )
G1 X77.5256 Y53.5684 Z0.98 F1800.0 E64.9971
( Linear move to (79.564, 51.53, 0.98). )
G1 X79.564 Y51.53 Z0.98 F1800.0 E65.078
( Linear move to (78.7155, 51.53, 0.98). )
G1 X78.7155 Y51.53 Z0.98 F1800.0 E65.1018
( Linear move to (75.5777, 54.6678, 0.98). )
G1 X75.5777 Y54.6678 Z0.98 F1800.0 E65.2263
( Linear move to (75.704, 55.39, 0.98). )
G1 X75.704 Y55.39 Z0.98 F1800.0 E65.2469
( Linear move to (76.4813, 54.6127, 0.98). )
G1 X76.4813 Y54.6127 Z0.98 F1800.0 E65.2777
( Linear move to (76.4813, 54.6127, 0.98). )
G1 F1200.0
( Linear move to (76.4813, 54.6127, 0.98). )
G1 E64.2777
( Linear move to (76.4813, 54.6127, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (88.47, 47.7152, 0.98). )
G1 X88.47 Y47.7152 Z0.98 F6000.0
( Linear move to (88.47, 47.7152, 0.98). )
G1 F1200.0
( Linear move to (88.47, 47.7152, 0.98). )
G1 E65.2777
( Linear move to (88.47, 47.7152, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (82.6168, 53.5684, 0.98). )
G1 X82.6168 Y53.5684 Z0.98 F1800.0 E65.51
( Linear move to (83.4653, 53.5684, 0.98). )
G1 X83.4653 Y53.5684 Z0.98 F1800.0 E65.5338
( Linear move to (88.47, 48.5637, 0.98). )
G1 X88.47 Y48.5637 Z0.98 F1800.0 E65.7324
( Linear move to (88.47, 49.4123, 0.98). )
G1 X88.47 Y49.4123 Z0.98 F1800.0 E65.7562
( Linear move to (84.3139, 53.5684, 0.98). )
G1 X84.3139 Y53.5684 Z0.98 F1800.0 E65.9211
( Linear move to (85.1624, 53.5684, 0.98). )
G1 X85.1624 Y53.5684 Z0.98 F1800.0 E65.9449
( Linear move to (88.47, 50.2608, 0.98). )
G1 X88.47 Y50.2608 Z0.98 F1800.0 E66.0762
( Linear move to (88.47, 51.1093, 0.98). )
G1 X88.47 Y51.1093 Z0.98 F1800.0 E66.1
( Linear move to (85.5323, 54.047, 0.98). )
G1 X85.5323 Y54.047 Z0.98 F1800.0 E66.2166
( Linear move to (85.5323, 54.8955, 0.98). )
G1 X85.5323 Y54.8955 Z0.98 F1800.0 E66.2404
( Linear move to (88.47, 51.9578, 0.98). )
G1 X88.47 Y51.9578 Z0.98 F1800.0 E66.357
( Linear move to (88.47, 52.8064, 0.98). )
G1 X88.47 Y52.8064 Z0.98 F1800.0 E66.3808
( Linear move to (85.877, 55.3994, 0.98). )
G1 X85.877 Y55.3994 Z0.98 F1800.0 E66.4837
( Linear move to (86.6549, 55.47, 0.98). )
G1 X86.6549 Y55.47 Z0.98 F1800.0 E66.5056
( Linear move to (88.47, 53.6549, 0.98). )
G1 X88.47 Y53.6549 Z0.98 F1800.0 E66.5776
( Linear move to (88.47, 54.5034, 0.98). )
G1 X88.47 Y54.5034 Z0.98 F1800.0 E66.6014
( Linear move to (87.5034, 55.47, 0.98). )
G1 X87.5034 Y55.47 Z0.98 F1800.0 E66.6398
( Linear move to (87.5034, 55.47, 0.98). )
G1 F1200.0
( Linear move to (87.5034, 55.47, 0.98). )
G1 E65.6398
( Linear move to (87.5034, 55.47, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (35.4428, 51.5278, 0.98). )
G1 X35.4428 Y51.5278 Z0.98 F6000.0
( Linear move to (35.4428, 51.5278, 0.98). )
G1 F1200.0
( Linear move to (35.4428, 51.5278, 0.98). )
G1 E66.6398
( Linear move to (35.4428, 51.5278, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (31.7229, 55.2477, 0.98). )
G1 X31.7229 Y55.2477 Z0.98 F1800.0 E66.7874
( Linear move to (31.53, 54.592, 0.98). )
G1 X31.53 Y54.592 Z0.98 F1800.0 E66.8066
( Linear move to (34.5938, 51.5282, 0.98). )
G1 X34.5938 Y51.5282 Z0.98 F1800.0 E66.9282
( Linear move to (33.7449, 51.5286, 0.98). )
G1 X33.7449 Y51.5286 Z0.98 F1800.0 E66.952
( Linear move to (31.53, 53.7435, 0.98). )
G1 X31.53 Y53.7435 Z0.98 F1800.0 E67.0399
( Linear move to (31.53, 52.895, 0.98). )
G1 X31.53 Y52.895 Z0.98 F1800.0 E67.0637
( Linear move to (32.8959, 51.5291, 0.98). )
G1 X32.8959 Y51.5291 Z0.98 F1800.0 E67.1179
( Linear move to (32.047, 51.5295, 0.98). )
G1 X32.047 Y51.5295 Z0.98 F1800.0 E67.1417
( Linear move to (31.53, 52.0465, 0.98). )
G1 X31.53 Y52.0465 Z0.98 F1800.0 E67.1622
( Linear move to (31.53, 52.0465, 0.98). )
G1 F1200.0
( Linear move to (31.53, 52.0465, 0.98). )
G1 E66.1622
( Linear move to (31.53, 52.0465, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (34.4813, 54.1863, 0.98). )
G1 X34.4813 Y54.1863 Z0.98 F6000.0
( Linear move to (34.4813, 54.1863, 0.98). )
G1 F1200.0
( Linear move to (34.4813, 54.1863, 0.98). )
G1 E67.1622
( Linear move to (34.4813, 54.1863, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (33.1976, 55.47, 0.98). )
G1 X33.1976 Y55.47 Z0.98 F1800.0 E67.2132
( Linear move to (34.0461, 55.47, 0.98). )
G1 X34.0461 Y55.47 Z0.98 F1800.0 E67.237
( Linear move to (34.4813, 55.0348, 0.98). )
G1 X34.4813 Y55.0348 Z0.98 F1800.0 E67.2543
( Linear move to (34.4813, 55.0348, 0.98). )
G1 F1200.0
( Linear move to (34.4813, 55.0348, 0.98). )
G1 E66.2543
( Linear move to (34.4813, 55.0348, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X78.0113 Y64.9016 Z0.98 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y64.9016 Z0.98 </boundaryPoint>)
(<boundaryPoint> X84.0023 Y63.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X90.0 Y63.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X82.0 Y80.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X82.0 Y70.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X30.0 Y70.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X30.0 Y63.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y63.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X36.0113 Y64.9016 Z0.98 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y64.9016 Z0.98 </boundaryPoint>)
(<boundaryPoint> X42.0023 Y63.0 Z0.98 </boundaryPoint>)
(<boundaryPoint> X78.0113 Y63.0 Z0.98 </boundaryPoint>)
(<edge> outer )
( Set extruder speed to 18.75. )
M108 S18.75
( Linear move to (34.4813, 63.36, 0.98). )
G1 X34.4813 Y63.36 Z0.98 F6000.0
( Linear move to (34.4813, 63.36, 0.98). )
G1 F1200.0
( Linear move to (34.4813, 63.36, 0.98). )
G1 E67.2543
( Linear move to (34.4813, 63.36, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (35.6513, 63.36, 0.98). )
G1 X35.6513 Y63.36 Z0.98 F1350.0 E67.2871
( Linear move to (35.6513, 65.2616, 0.98). )
G1 X35.6513 Y65.2616 Z0.98 F1350.0 E67.3405
( Linear move to (42.3623, 65.2616, 0.98). )
G1 X42.3623 Y65.2616 Z0.98 F1350.0 E67.5288
( Linear move to (42.3623, 63.36, 0.98). )
G1 X42.3623 Y63.36 Z0.98 F1350.0 E67.5821
( Linear move to (77.6513, 63.36, 0.98). )
G1 X77.6513 Y63.36 Z0.98 F1350.0 E68.5723
( Linear move to (77.6513, 65.2616, 0.98). )
G1 X77.6513 Y65.2616 Z0.98 F1350.0 E68.6257
( Linear move to (84.3623, 65.2616, 0.98). )
G1 X84.3623 Y65.2616 Z0.98 F1350.0 E68.814
( Linear move to (84.3623, 63.36, 0.98). )
G1 X84.3623 Y63.36 Z0.98 F1350.0 E68.8674
( Linear move to (89.64, 63.36, 0.98). )
G1 X89.64 Y63.36 Z0.98 F1350.0 E69.0155
( Linear move to (89.64, 79.64, 0.98). )
G1 X89.64 Y79.64 Z0.98 F1350.0 E69.4723
( Linear move to (82.36, 79.64, 0.98). )
G1 X82.36 Y79.64 Z0.98 F1350.0 E69.6766
( Linear move to (82.36, 69.64, 0.98). )
G1 X82.36 Y69.64 Z0.98 F1350.0 E69.9572
( Linear move to (30.36, 69.64, 0.98). )
G1 X30.36 Y69.64 Z0.98 F1350.0 E71.4163
( Linear move to (30.36, 63.36, 0.98). )
G1 X30.36 Y63.36 Z0.98 F1350.0 E71.5925
( Linear move to (34.4813, 63.36, 0.98). )
G1 X34.4813 Y63.36 Z0.98 F1350.0 E71.7082
( Linear move to (34.4813, 63.36, 0.98). )
G1 F1200.0
( Linear move to (34.4813, 63.36, 0.98). )
G1 E70.7082
( Linear move to (34.4813, 63.36, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X45.2626 Y65.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y65.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.75 Y66.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X44.8832 Y67.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.2626 Y67.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y68.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X46.5 Y68.25 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y68.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y67.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y67.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.25 Y66.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X48.1168 Y65.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.7374 Y65.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X47.1697 Y64.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X46.5 Y64.75 Z0.98 </boundaryPoint>)
(<boundaryPoint> X45.8303 Y64.8832 Z0.98 </boundaryPoint>)
(<edge> inner )
( Linear move to (44.5441, 65.6898, 0.98). )
G1 X44.5441 Y65.6898 Z0.98 F6000.0
( Linear move to (44.5441, 65.6898, 0.98). )
G1 F1200.0
( Linear move to (44.5441, 65.6898, 0.98). )
G1 E71.7082
( Linear move to (44.5441, 65.6898, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (44.3829, 66.5, 0.98). )
G1 X44.3829 Y66.5 Z0.98 F1350.0 E71.7314
( Linear move to (44.5441, 67.3102, 0.98). )
G1 X44.5441 Y67.3102 Z0.98 F1350.0 E71.7545
( Linear move to (45.0031, 67.9969, 0.98). )
G1 X45.0031 Y67.9969 Z0.98 F1350.0 E71.7777
( Linear move to (45.6898, 68.4559, 0.98). )
G1 X45.6898 Y68.4559 Z0.98 F1350.0 E71.8009
( Linear move to (46.5, 68.6171, 0.98). )
G1 X46.5 Y68.6171 Z0.98 F1350.0 E71.8241
( Linear move to (47.3102, 68.4559, 0.98). )
G1 X47.3102 Y68.4559 Z0.98 F1350.0 E71.8473
( Linear move to (47.9969, 67.9969, 0.98). )
G1 X47.9969 Y67.9969 Z0.98 F1350.0 E71.8704
( Linear move to (48.4559, 67.3102, 0.98). )
G1 X48.4559 Y67.3102 Z0.98 F1350.0 E71.8936
( Linear move to (48.6171, 66.5, 0.98). )
G1 X48.6171 Y66.5 Z0.98 F1350.0 E71.9168
( Linear move to (48.4559, 65.6898, 0.98). )
G1 X48.4559 Y65.6898 Z0.98 F1350.0 E71.94
( Linear move to (47.9969, 65.0031, 0.98). )
G1 X47.9969 Y65.0031 Z0.98 F1350.0 E71.9631
( Linear move to (47.3102, 64.5441, 0.98). )
G1 X47.3102 Y64.5441 Z0.98 F1350.0 E71.9863
( Linear move to (46.5, 64.3829, 0.98). )
G1 X46.5 Y64.3829 Z0.98 F1350.0 E72.0095
( Linear move to (45.6898, 64.5441, 0.98). )
G1 X45.6898 Y64.5441 Z0.98 F1350.0 E72.0327
( Linear move to (45.0031, 65.0031, 0.98). )
G1 X45.0031 Y65.0031 Z0.98 F1350.0 E72.0559
( Linear move to (44.5441, 65.6898, 0.98). )
G1 X44.5441 Y65.6898 Z0.98 F1350.0 E72.079
( Linear move to (44.5441, 65.6898, 0.98). )
G1 F1200.0
( Linear move to (44.5441, 65.6898, 0.98). )
G1 E71.079
( Linear move to (44.5441, 65.6898, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X72.5 Y64.75 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y64.8832 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y65.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y65.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.75 Y66.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X70.8832 Y67.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.2626 Y67.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X71.8303 Y68.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X72.5 Y68.25 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y68.1168 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y67.7374 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y67.1697 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.25 Y66.5 Z0.98 </boundaryPoint>)
(<boundaryPoint> X74.1168 Y65.8303 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.7374 Y65.2626 Z0.98 </boundaryPoint>)
(<boundaryPoint> X73.1697 Y64.8832 Z0.98 </boundaryPoint>)
(<edge> inner )
( Linear move to (70.3829, 66.5, 0.98). )
G1 X70.3829 Y66.5 Z0.98 F6000.0
( Linear move to (70.3829, 66.5, 0.98). )
G1 F1200.0
( Linear move to (70.3829, 66.5, 0.98). )
G1 E72.079
( Linear move to (70.3829, 66.5, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (70.5441, 67.3102, 0.98). )
G1 X70.5441 Y67.3102 Z0.98 F1350.0 E72.1022
( Linear move to (71.0031, 67.9969, 0.98). )
G1 X71.0031 Y67.9969 Z0.98 F1350.0 E72.1254
( Linear move to (71.6898, 68.4559, 0.98). )
G1 X71.6898 Y68.4559 Z0.98 F1350.0 E72.1486
( Linear move to (72.5, 68.6171, 0.98). )
G1 X72.5 Y68.6171 Z0.98 F1350.0 E72.1718
( Linear move to (73.3102, 68.4559, 0.98). )
G1 X73.3102 Y68.4559 Z0.98 F1350.0 E72.1949
( Linear move to (73.9969, 67.9969, 0.98). )
G1 X73.9969 Y67.9969 Z0.98 F1350.0 E72.2181
( Linear move to (74.4559, 67.3102, 0.98). )
G1 X74.4559 Y67.3102 Z0.98 F1350.0 E72.2413
( Linear move to (74.6171, 66.5, 0.98). )
G1 X74.6171 Y66.5 Z0.98 F1350.0 E72.2645
( Linear move to (74.4559, 65.6898, 0.98). )
G1 X74.4559 Y65.6898 Z0.98 F1350.0 E72.2877
( Linear move to (73.9969, 65.0031, 0.98). )
G1 X73.9969 Y65.0031 Z0.98 F1350.0 E72.3108
( Linear move to (73.3102, 64.5441, 0.98). )
G1 X73.3102 Y64.5441 Z0.98 F1350.0 E72.334
( Linear move to (72.5, 64.3829, 0.98). )
G1 X72.5 Y64.3829 Z0.98 F1350.0 E72.3572
( Linear move to (71.6898, 64.5441, 0.98). )
G1 X71.6898 Y64.5441 Z0.98 F1350.0 E72.3804
( Linear move to (71.0031, 65.0031, 0.98). )
G1 X71.0031 Y65.0031 Z0.98 F1350.0 E72.4035
( Linear move to (70.5441, 65.6898, 0.98). )
G1 X70.5441 Y65.6898 Z0.98 F1350.0 E72.4267
( Linear move to (70.3829, 66.5, 0.98). )
G1 X70.3829 Y66.5 Z0.98 F1350.0 E72.4499
( Linear move to (70.3829, 66.5, 0.98). )
G1 F1200.0
( Linear move to (70.3829, 66.5, 0.98). )
G1 E72.4499
( Linear move to (70.3829, 66.5, 0.98). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(</nestedRing>)
(<loop> outer )
( Set extruder speed to 25.0. )
M108 S25.0
( Linear move to (69.71, 66.5, 0.98). )
G1 X69.71 Y66.5 Z0.98 F6000.0
( Linear move to (69.71, 66.5, 0.98). )
G1 F1200.0
( Linear move to (69.71, 66.5, 0.98). )
G1 E72.4499
( Linear move to (69.71, 66.5, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (69.9224, 67.5677, 0.98). )
G1 X69.9224 Y67.5677 Z0.98 F1800.0 E72.4804
( Linear move to (70.3065, 68.1424, 0.98). )
G1 X70.3065 Y68.1424 Z0.98 F1800.0 E72.4998
( Linear move to (70.0668, 68.98, 0.98). )
G1 X70.0668 Y68.98 Z0.98 F1800.0 E72.5243
( Linear move to (48.7787, 68.98, 0.98). )
G1 X48.7787 Y68.98 Z0.98 F1800.0 E73.1216
( Linear move to (48.6663, 68.1832, 0.98). )
G1 X48.6663 Y68.1832 Z0.98 F1800.0 E73.1442
( Linear move to (49.0776, 67.5677, 0.98). )
G1 X49.0776 Y67.5677 Z0.98 F1800.0 E73.165
( Linear move to (49.29, 66.5, 0.98). )
G1 X49.29 Y66.5 Z0.98 F1800.0 E73.1955
( Linear move to (49.0776, 65.4323, 0.98). )
G1 X49.0776 Y65.4323 Z0.98 F1800.0 E73.2261
( Linear move to (48.6737, 64.8278, 0.98). )
G1 X48.6737 Y64.8278 Z0.98 F1800.0 E73.2465
( Linear move to (48.8192, 64.02, 0.98). )
G1 X48.8192 Y64.02 Z0.98 F1800.0 E73.2695
( Linear move to (69.8541, 64.02, 0.98). )
G1 X69.8541 Y64.02 Z0.98 F1800.0 E73.8598
( Linear move to (70.2724, 64.9085, 0.98). )
G1 X70.2724 Y64.9085 Z0.98 F1800.0 E73.8873
( Linear move to (69.9224, 65.4323, 0.98). )
G1 X69.9224 Y65.4323 Z0.98 F1800.0 E73.905
( Linear move to (69.71, 66.5, 0.98). )
G1 X69.71 Y66.5 Z0.98 F1800.0 E73.9356
( Linear move to (69.71, 66.5, 0.98). )
G1 F1200.0
( Linear move to (69.71, 66.5, 0.98). )
G1 E72.9356
( Linear move to (69.71, 66.5, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (73.9814, 68.8012, 0.98). )
G1 X73.9814 Y68.8012 Z0.98 F6000.0
( Linear move to (73.9814, 68.8012, 0.98). )
G1 F1200.0
( Linear move to (73.9814, 68.8012, 0.98). )
G1 E73.9356
( Linear move to (73.9814, 68.8012, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (74.4728, 68.4728, 0.98). )
G1 X74.4728 Y68.4728 Z0.98 F1800.0 E73.9521
( Linear move to (75.0776, 67.5677, 0.98). )
G1 X75.0776 Y67.5677 Z0.98 F1800.0 E73.9827
( Linear move to (75.29, 66.5, 0.98). )
G1 X75.29 Y66.5 Z0.98 F1800.0 E74.0132
( Linear move to (75.0776, 65.4323, 0.98). )
G1 X75.0776 Y65.4323 Z0.98 F1800.0 E74.0438
( Linear move to (74.7101, 64.8824, 0.98). )
G1 X74.7101 Y64.8824 Z0.98 F1800.0 E74.0623
( Linear move to (75.0338, 64.02, 0.98). )
G1 X75.0338 Y64.02 Z0.98 F1800.0 E74.0882
( Linear move to (76.9913, 64.02, 0.98). )
G1 X76.9913 Y64.02 Z0.98 F1800.0 E74.1431
( Linear move to (76.9913, 65.9216, 0.98). )
G1 X76.9913 Y65.9216 Z0.98 F1800.0 E74.1965
( Linear move to (85.0223, 65.9216, 0.98). )
G1 X85.0223 Y65.9216 Z0.98 F1800.0 E74.4218
( Linear move to (85.0223, 64.02, 0.98). )
G1 X85.0223 Y64.02 Z0.98 F1800.0 E74.4752
( Linear move to (88.98, 64.02, 0.98). )
G1 X88.98 Y64.02 Z0.98 F1800.0 E74.5862
( Linear move to (88.98, 78.98, 0.98). )
G1 X88.98 Y78.98 Z0.98 F1800.0 E75.006
( Linear move to (83.02, 78.98, 0.98). )
G1 X83.02 Y78.98 Z0.98 F1800.0 E75.1733
( Linear move to (83.02, 68.98, 0.98). )
G1 X83.02 Y68.98 Z0.98 F1800.0 E75.4539
( Linear move to (74.0071, 68.98, 0.98). )
G1 X74.0071 Y68.98 Z0.98 F1800.0 E75.7068
( Linear move to (73.9814, 68.8012, 0.98). )
G1 X73.9814 Y68.8012 Z0.98 F1800.0 E75.7118
( Linear move to (73.9814, 68.8012, 0.98). )
G1 F1200.0
( Linear move to (73.9814, 68.8012, 0.98). )
G1 E74.7118
( Linear move to (73.9814, 68.8012, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<loop> outer )
( Linear move to (44.5557, 68.9868, 0.98). )
G1 X44.5557 Y68.9868 Z0.98 F6000.0
( Linear move to (44.5557, 68.9868, 0.98). )
G1 F1200.0
( Linear move to (44.5557, 68.9868, 0.98). )
G1 E75.7118
( Linear move to (44.5557, 68.9868, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (31.02, 68.98, 0.98). )
G1 X31.02 Y68.98 Z0.98 F1800.0 E76.0917
( Linear move to (31.02, 64.02, 0.98). )
G1 X31.02 Y64.02 Z0.98 F1800.0 E76.2308
( Linear move to (34.9913, 64.02, 0.98). )
G1 X34.9913 Y64.02 Z0.98 F1800.0 E76.3423
( Linear move to (34.9913, 65.9216, 0.98). )
G1 X34.9913 Y65.9216 Z0.98 F1800.0 E76.3956
( Linear move to (43.0223, 65.9216, 0.98). )
G1 X43.0223 Y65.9216 Z0.98 F1800.0 E76.621
( Linear move to (43.0223, 64.02, 0.98). )
G1 X43.0223 Y64.02 Z0.98 F1800.0 E76.6743
( Linear move to (44.6738, 63.9658, 0.98). )
G1 X44.6738 Y63.9658 Z0.98 F1800.0 E76.7207
( Linear move to (44.4083, 64.7052, 0.98). )
G1 X44.4083 Y64.7052 Z0.98 F1800.0 E76.7428
( Linear move to (43.9224, 65.4323, 0.98). )
G1 X43.9224 Y65.4323 Z0.98 F1800.0 E76.7673
( Linear move to (43.71, 66.5, 0.98). )
G1 X43.71 Y66.5 Z0.98 F1800.0 E76.7978
( Linear move to (43.9224, 67.5677, 0.98). )
G1 X43.9224 Y67.5677 Z0.98 F1800.0 E76.8284
( Linear move to (44.3971, 68.278, 0.98). )
G1 X44.3971 Y68.278 Z0.98 F1800.0 E76.8524
( Linear move to (44.5557, 68.9868, 0.98). )
G1 X44.5557 Y68.9868 Z0.98 F1800.0 E76.8727
( Linear move to (44.5557, 68.9868, 0.98). )
G1 F1200.0
( Linear move to (44.5557, 68.9868, 0.98). )
G1 E75.8727
( Linear move to (44.5557, 68.9868, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X76.9913 Y65.9216 Z0.78 </infillPoint>)
(<infillPoint> X85.0223 Y65.9216 Z0.78 </infillPoint>)
(<infillPoint> X85.0223 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X88.98 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X88.98 Y78.98 Z0.78 </infillPoint>)
(<infillPoint> X83.02 Y78.98 Z0.78 </infillPoint>)
(<infillPoint> X83.02 Y68.98 Z0.78 </infillPoint>)
(<infillPoint> X74.0071 Y68.98 Z0.78 </infillPoint>)
(<infillPoint> X73.9814 Y68.8012 Z0.78 </infillPoint>)
(<infillPoint> X74.4728 Y68.4728 Z0.78 </infillPoint>)
(<infillPoint> X75.0776 Y67.5677 Z0.78 </infillPoint>)
(<infillPoint> X75.29 Y66.5 Z0.78 </infillPoint>)
(<infillPoint> X75.0776 Y65.4323 Z0.78 </infillPoint>)
(<infillPoint> X74.7101 Y64.8824 Z0.78 </infillPoint>)
(<infillPoint> X75.0338 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X76.9913 Y64.02 Z0.78 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X70.0668 Y68.98 Z0.78 </infillPoint>)
(<infillPoint> X48.7787 Y68.98 Z0.78 </infillPoint>)
(<infillPoint> X48.6663 Y68.1832 Z0.78 </infillPoint>)
(<infillPoint> X49.0776 Y67.5677 Z0.78 </infillPoint>)
(<infillPoint> X49.29 Y66.5 Z0.78 </infillPoint>)
(<infillPoint> X49.0776 Y65.4323 Z0.78 </infillPoint>)
(<infillPoint> X48.6737 Y64.8278 Z0.78 </infillPoint>)
(<infillPoint> X48.8192 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X69.8541 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X70.2724 Y64.9085 Z0.78 </infillPoint>)
(<infillPoint> X69.9224 Y65.4323 Z0.78 </infillPoint>)
(<infillPoint> X69.71 Y66.5 Z0.78 </infillPoint>)
(<infillPoint> X69.9224 Y67.5677 Z0.78 </infillPoint>)
(<infillPoint> X70.3065 Y68.1424 Z0.78 </infillPoint>)
(</infillBoundary>)
(<infillBoundary>)
(<infillPoint> X44.5557 Y68.9868 Z0.78 </infillPoint>)
(<infillPoint> X31.02 Y68.98 Z0.78 </infillPoint>)
(<infillPoint> X31.02 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X34.9913 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X34.9913 Y65.9216 Z0.78 </infillPoint>)
(<infillPoint> X43.0223 Y65.9216 Z0.78 </infillPoint>)
(<infillPoint> X43.0223 Y64.02 Z0.78 </infillPoint>)
(<infillPoint> X44.6738 Y63.9658 Z0.78 </infillPoint>)
(<infillPoint> X44.4083 Y64.7052 Z0.78 </infillPoint>)
(<infillPoint> X43.9224 Y65.4323 Z0.78 </infillPoint>)
(<infillPoint> X43.71 Y66.5 Z0.78 </infillPoint>)
(<infillPoint> X43.9224 Y67.5677 Z0.78 </infillPoint>)
(<infillPoint> X44.3971 Y68.278 Z0.78 </infillPoint>)
(</infillBoundary>)
( Linear move to (43.1692, 66.7116, 0.98). )
G1 X43.1692 Y66.7116 Z0.98 F6000.0
( Linear move to (43.1692, 66.7116, 0.98). )
G1 F1200.0
( Linear move to (43.1692, 66.7116, 0.98). )
G1 E76.8727
( Linear move to (43.1692, 66.7116, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (41.4056, 68.4752, 0.98). )
G1 X41.4056 Y68.4752 Z0.98 F1800.0 E76.9427
( Linear move to (42.2537, 68.4757, 0.98). )
G1 X42.2537 Y68.4757 Z0.98 F1800.0 E76.9665
( Linear move to (43.3625, 67.3669, 0.98). )
G1 X43.3625 Y67.3669 Z0.98 F1800.0 E77.0105
( Linear move to (43.5899, 67.988, 0.98). )
G1 X43.5899 Y67.988 Z0.98 F1800.0 E77.0291
( Linear move to (43.1018, 68.4761, 0.98). )
G1 X43.1018 Y68.4761 Z0.98 F1800.0 E77.0485
( Linear move to (43.1018, 68.4761, 0.98). )
G1 F1200.0
( Linear move to (43.1018, 68.4761, 0.98). )
G1 E76.0485
( Linear move to (43.1018, 68.4761, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (42.6007, 66.4316, 0.98). )
G1 X42.6007 Y66.4316 Z0.98 F6000.0
( Linear move to (42.6007, 66.4316, 0.98). )
G1 F1200.0
( Linear move to (42.6007, 66.4316, 0.98). )
G1 E77.0485
( Linear move to (42.6007, 66.4316, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (40.5575, 68.4748, 0.98). )
G1 X40.5575 Y68.4748 Z0.98 F1800.0 E77.1295
( Linear move to (39.7094, 68.4744, 0.98). )
G1 X39.7094 Y68.4744 Z0.98 F1800.0 E77.1533
( Linear move to (41.7522, 66.4316, 0.98). )
G1 X41.7522 Y66.4316 Z0.98 F1800.0 E77.2344
( Linear move to (40.9036, 66.4316, 0.98). )
G1 X40.9036 Y66.4316 Z0.98 F1800.0 E77.2582
( Linear move to (38.8613, 68.474, 0.98). )
G1 X38.8613 Y68.474 Z0.98 F1800.0 E77.3393
( Linear move to (38.0132, 68.4735, 0.98). )
G1 X38.0132 Y68.4735 Z0.98 F1800.0 E77.3631
( Linear move to (40.0551, 66.4316, 0.98). )
G1 X40.0551 Y66.4316 Z0.98 F1800.0 E77.4441
( Linear move to (39.2066, 66.4316, 0.98). )
G1 X39.2066 Y66.4316 Z0.98 F1800.0 E77.4679
( Linear move to (37.1651, 68.4731, 0.98). )
G1 X37.1651 Y68.4731 Z0.98 F1800.0 E77.5489
( Linear move to (36.317, 68.4727, 0.98). )
G1 X36.317 Y68.4727 Z0.98 F1800.0 E77.5727
( Linear move to (38.3581, 66.4316, 0.98). )
G1 X38.3581 Y66.4316 Z0.98 F1800.0 E77.6537
( Linear move to (37.5095, 66.4316, 0.98). )
G1 X37.5095 Y66.4316 Z0.98 F1800.0 E77.6775
( Linear move to (35.4689, 68.4722, 0.98). )
G1 X35.4689 Y68.4722 Z0.98 F1800.0 E77.7585
( Linear move to (34.6208, 68.4718, 0.98). )
G1 X34.6208 Y68.4718 Z0.98 F1800.0 E77.7823
( Linear move to (36.661, 66.4316, 0.98). )
G1 X36.661 Y66.4316 Z0.98 F1800.0 E77.8633
( Linear move to (35.8125, 66.4316, 0.98). )
G1 X35.8125 Y66.4316 Z0.98 F1800.0 E77.8871
( Linear move to (33.7727, 68.4714, 0.98). )
G1 X33.7727 Y68.4714 Z0.98 F1800.0 E77.968
( Linear move to (32.9246, 68.471, 0.98). )
G1 X32.9246 Y68.471 Z0.98 F1800.0 E77.9918
( Linear move to (34.9639, 66.4316, 0.98). )
G1 X34.9639 Y66.4316 Z0.98 F1800.0 E78.0727
( Linear move to (34.4813, 66.0657, 0.98). )
G1 X34.4813 Y66.0657 Z0.98 F1800.0 E78.0897
( Linear move to (32.0765, 68.4705, 0.98). )
G1 X32.0765 Y68.4705 Z0.98 F1800.0 E78.1852
( Linear move to (31.5868, 68.1117, 0.98). )
G1 X31.5868 Y68.1117 Z0.98 F1800.0 E78.2022
( Linear move to (34.4813, 65.2172, 0.98). )
G1 X34.4813 Y65.2172 Z0.98 F1800.0 E78.3171
( Linear move to (34.193, 64.657, 0.98). )
G1 X34.193 Y64.657 Z0.98 F1800.0 E78.3347
( Linear move to (31.53, 67.32, 0.98). )
G1 X31.53 Y67.32 Z0.98 F1800.0 E78.4404
( Linear move to (31.53, 66.4714, 0.98). )
G1 X31.53 Y66.4714 Z0.98 F1800.0 E78.4642
( Linear move to (33.4714, 64.53, 0.98). )
G1 X33.4714 Y64.53 Z0.98 F1800.0 E78.5413
( Linear move to (32.6229, 64.53, 0.98). )
G1 X32.6229 Y64.53 Z0.98 F1800.0 E78.5651
( Linear move to (31.53, 65.6229, 0.98). )
G1 X31.53 Y65.6229 Z0.98 F1800.0 E78.6084
( Linear move to (31.53, 65.6229, 0.98). )
G1 F1200.0
( Linear move to (31.53, 65.6229, 0.98). )
G1 E77.6084
( Linear move to (31.53, 65.6229, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (69.1096, 64.53, 0.98). )
G1 X69.1096 Y64.53 Z0.98 F6000.0
( Linear move to (69.1096, 64.53, 0.98). )
G1 F1200.0
( Linear move to (69.1096, 64.53, 0.98). )
G1 E78.6084
( Linear move to (69.1096, 64.53, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (65.1696, 68.47, 0.98). )
G1 X65.1696 Y68.47 Z0.98 F1800.0 E78.7648
( Linear move to (64.3211, 68.47, 0.98). )
G1 X64.3211 Y68.47 Z0.98 F1800.0 E78.7886
( Linear move to (68.2611, 64.53, 0.98). )
G1 X68.2611 Y64.53 Z0.98 F1800.0 E78.945
( Linear move to (67.4126, 64.53, 0.98). )
G1 X67.4126 Y64.53 Z0.98 F1800.0 E78.9688
( Linear move to (63.4726, 68.47, 0.98). )
G1 X63.4726 Y68.47 Z0.98 F1800.0 E79.1251
( Linear move to (62.624, 68.47, 0.98). )
G1 X62.624 Y68.47 Z0.98 F1800.0 E79.1489
( Linear move to (66.564, 64.53, 0.98). )
G1 X66.564 Y64.53 Z0.98 F1800.0 E79.3053
( Linear move to (65.7155, 64.53, 0.98). )
G1 X65.7155 Y64.53 Z0.98 F1800.0 E79.3291
( Linear move to (61.7755, 68.47, 0.98). )
G1 X61.7755 Y68.47 Z0.98 F1800.0 E79.4854
( Linear move to (60.927, 68.47, 0.98). )
G1 X60.927 Y68.47 Z0.98 F1800.0 E79.5093
( Linear move to (64.867, 64.53, 0.98). )
G1 X64.867 Y64.53 Z0.98 F1800.0 E79.6656
( Linear move to (64.0184, 64.53, 0.98). )
G1 X64.0184 Y64.53 Z0.98 F1800.0 E79.6894
( Linear move to (60.0784, 68.47, 0.98). )
G1 X60.0784 Y68.47 Z0.98 F1800.0 E79.8458
( Linear move to (59.2299, 68.47, 0.98). )
G1 X59.2299 Y68.47 Z0.98 F1800.0 E79.8696
( Linear move to (63.1699, 64.53, 0.98). )
G1 X63.1699 Y64.53 Z0.98 F1800.0 E80.0259
( Linear move to (62.3214, 64.53, 0.98). )
G1 X62.3214 Y64.53 Z0.98 F1800.0 E80.0497
( Linear move to (58.3814, 68.47, 0.98). )
G1 X58.3814 Y68.47 Z0.98 F1800.0 E80.2061
( Linear move to (57.5329, 68.47, 0.98). )
G1 X57.5329 Y68.47 Z0.98 F1800.0 E80.2299
( Linear move to (61.4729, 64.53, 0.98). )
G1 X61.4729 Y64.53 Z0.98 F1800.0 E80.3863
( Linear move to (60.6243, 64.53, 0.98). )
G1 X60.6243 Y64.53 Z0.98 F1800.0 E80.4101
( Linear move to (56.6843, 68.47, 0.98). )
G1 X56.6843 Y68.47 Z0.98 F1800.0 E80.5664
( Linear move to (55.8358, 68.47, 0.98). )
G1 X55.8358 Y68.47 Z0.98 F1800.0 E80.5902
( Linear move to (59.7758, 64.53, 0.98). )
G1 X59.7758 Y64.53 Z0.98 F1800.0 E80.7466
( Linear move to (58.9273, 64.53, 0.98). )
G1 X58.9273 Y64.53 Z0.98 F1800.0 E80.7704
( Linear move to (54.9873, 68.47, 0.98). )
G1 X54.9873 Y68.47 Z0.98 F1800.0 E80.9267
( Linear move to (54.1387, 68.47, 0.98). )
G1 X54.1387 Y68.47 Z0.98 F1800.0 E80.9506
( Linear move to (58.0787, 64.53, 0.98). )
G1 X58.0787 Y64.53 Z0.98 F1800.0 E81.1069
( Linear move to (57.2302, 64.53, 0.98). )
G1 X57.2302 Y64.53 Z0.98 F1800.0 E81.1307
( Linear move to (53.2902, 68.47, 0.98). )
G1 X53.2902 Y68.47 Z0.98 F1800.0 E81.2871
( Linear move to (52.4417, 68.47, 0.98). )
G1 X52.4417 Y68.47 Z0.98 F1800.0 E81.3109
( Linear move to (56.3817, 64.53, 0.98). )
G1 X56.3817 Y64.53 Z0.98 F1800.0 E81.4672
( Linear move to (55.5332, 64.53, 0.98). )
G1 X55.5332 Y64.53 Z0.98 F1800.0 E81.491
( Linear move to (51.5932, 68.47, 0.98). )
G1 X51.5932 Y68.47 Z0.98 F1800.0 E81.6474
( Linear move to (50.7446, 68.47, 0.98). )
G1 X50.7446 Y68.47 Z0.98 F1800.0 E81.6712
( Linear move to (54.6846, 64.53, 0.98). )
G1 X54.6846 Y64.53 Z0.98 F1800.0 E81.8276
( Linear move to (53.8361, 64.53, 0.98). )
G1 X53.8361 Y64.53 Z0.98 F1800.0 E81.8514
( Linear move to (49.8961, 68.47, 0.98). )
G1 X49.8961 Y68.47 Z0.98 F1800.0 E82.0077
( Linear move to (49.2416, 68.2759, 0.98). )
G1 X49.2416 Y68.2759 Z0.98 F1800.0 E82.0269
( Linear move to (52.9876, 64.53, 0.98). )
G1 X52.9876 Y64.53 Z0.98 F1800.0 E82.1755
( Linear move to (52.139, 64.53, 0.98). )
G1 X52.139 Y64.53 Z0.98 F1800.0 E82.1993
( Linear move to (49.7208, 66.9482, 0.98). )
G1 X49.7208 Y66.9482 Z0.98 F1800.0 E82.2953
( Linear move to (49.7288, 66.0917, 0.98). )
G1 X49.7288 Y66.0917 Z0.98 F1800.0 E82.3193
( Linear move to (51.2905, 64.53, 0.98). )
G1 X51.2905 Y64.53 Z0.98 F1800.0 E82.3813
( Linear move to (50.442, 64.53, 0.98). )
G1 X50.442 Y64.53 Z0.98 F1800.0 E82.4051
( Linear move to (49.588, 65.384, 0.98). )
G1 X49.588 Y65.384 Z0.98 F1800.0 E82.439
( Linear move to (49.3321, 64.7913, 0.98). )
G1 X49.3321 Y64.7913 Z0.98 F1800.0 E82.4571
( Linear move to (49.527, 64.5965, 0.98). )
G1 X49.527 Y64.5965 Z0.98 F1800.0 E82.4649
( Linear move to (49.527, 64.5965, 0.98). )
G1 F1200.0
( Linear move to (49.527, 64.5965, 0.98). )
G1 E81.4649
( Linear move to (49.527, 64.5965, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (69.6674, 64.8207, 0.98). )
G1 X69.6674 Y64.8207 Z0.98 F6000.0
( Linear move to (69.6674, 64.8207, 0.98). )
G1 F1200.0
( Linear move to (69.6674, 64.8207, 0.98). )
G1 E82.4649
( Linear move to (69.6674, 64.8207, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (66.0181, 68.47, 0.98). )
G1 X66.0181 Y68.47 Z0.98 F1800.0 E82.6097
( Linear move to (66.8667, 68.47, 0.98). )
G1 X66.8667 Y68.47 Z0.98 F1800.0 E82.6335
( Linear move to (69.2778, 66.0589, 0.98). )
G1 X69.2778 Y66.0589 Z0.98 F1800.0 E82.7292
( Linear move to (69.2722, 66.913, 0.98). )
G1 X69.2722 Y66.913 Z0.98 F1800.0 E82.7531
( Linear move to (67.7152, 68.47, 0.98). )
G1 X67.7152 Y68.47 Z0.98 F1800.0 E82.8149
( Linear move to (68.5637, 68.47, 0.98). )
G1 X68.5637 Y68.47 Z0.98 F1800.0 E82.8387
( Linear move to (69.4129, 67.6208, 0.98). )
G1 X69.4129 Y67.6208 Z0.98 F1800.0 E82.8724
( Linear move to (69.7118, 68.1705, 0.98). )
G1 X69.7118 Y68.1705 Z0.98 F1800.0 E82.89
( Linear move to (69.5942, 68.288, 0.98). )
G1 X69.5942 Y68.288 Z0.98 F1800.0 E82.8947
( Linear move to (69.5942, 68.288, 0.98). )
G1 F1200.0
( Linear move to (69.5942, 68.288, 0.98). )
G1 E81.8947
( Linear move to (69.5942, 68.288, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (84.1786, 66.4316, 0.98). )
G1 X84.1786 Y66.4316 Z0.98 F6000.0
( Linear move to (84.1786, 66.4316, 0.98). )
G1 F1200.0
( Linear move to (84.1786, 66.4316, 0.98). )
G1 E82.8947
( Linear move to (84.1786, 66.4316, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (82.1402, 68.47, 0.98). )
G1 X82.1402 Y68.47 Z0.98 F1800.0 E82.9755
( Linear move to (81.2916, 68.47, 0.98). )
G1 X81.2916 Y68.47 Z0.98 F1800.0 E82.9994
( Linear move to (83.33, 66.4316, 0.98). )
G1 X83.33 Y66.4316 Z0.98 F1800.0 E83.0802
( Linear move to (82.4815, 66.4316, 0.98). )
G1 X82.4815 Y66.4316 Z0.98 F1800.0 E83.1041
( Linear move to (80.4431, 68.47, 0.98). )
G1 X80.4431 Y68.47 Z0.98 F1800.0 E83.1849
( Linear move to (79.5946, 68.47, 0.98). )
G1 X79.5946 Y68.47 Z0.98 F1800.0 E83.2088
( Linear move to (81.633, 66.4316, 0.98). )
G1 X81.633 Y66.4316 Z0.98 F1800.0 E83.2896
( Linear move to (80.7845, 66.4316, 0.98). )
G1 X80.7845 Y66.4316 Z0.98 F1800.0 E83.3135
( Linear move to (78.7461, 68.47, 0.98). )
G1 X78.7461 Y68.47 Z0.98 F1800.0 E83.3943
( Linear move to (77.8975, 68.47, 0.98). )
G1 X77.8975 Y68.47 Z0.98 F1800.0 E83.4182
( Linear move to (79.9359, 66.4316, 0.98). )
G1 X79.9359 Y66.4316 Z0.98 F1800.0 E83.499
( Linear move to (79.0874, 66.4316, 0.98). )
G1 X79.0874 Y66.4316 Z0.98 F1800.0 E83.5229
( Linear move to (77.049, 68.47, 0.98). )
G1 X77.049 Y68.47 Z0.98 F1800.0 E83.6037
( Linear move to (76.2005, 68.47, 0.98). )
G1 X76.2005 Y68.47 Z0.98 F1800.0 E83.6276
( Linear move to (78.2389, 66.4316, 0.98). )
G1 X78.2389 Y66.4316 Z0.98 F1800.0 E83.7084
( Linear move to (77.3903, 66.4316, 0.98). )
G1 X77.3903 Y66.4316 Z0.98 F1800.0 E83.7323
( Linear move to (75.3519, 68.47, 0.98). )
G1 X75.3519 Y68.47 Z0.98 F1800.0 E83.8132
( Linear move to (75.6453, 67.3282, 0.98). )
G1 X75.6453 Y67.3282 Z0.98 F1800.0 E83.8462
( Linear move to (76.5418, 66.4316, 0.98). )
G1 X76.5418 Y66.4316 Z0.98 F1800.0 E83.8818
( Linear move to (75.7793, 66.3456, 0.98). )
G1 X75.7793 Y66.3456 Z0.98 F1800.0 E83.9033
( Linear move to (76.4813, 65.6436, 0.98). )
G1 X76.4813 Y65.6436 Z0.98 F1800.0 E83.9312
( Linear move to (76.4062, 64.8702, 0.98). )
G1 X76.4062 Y64.8702 Z0.98 F1800.0 E83.953
( Linear move to (75.6385, 65.6379, 0.98). )
G1 X75.6385 Y65.6379 Z0.98 F1800.0 E83.9835
( Linear move to (75.4124, 65.0154, 0.98). )
G1 X75.4124 Y65.0154 Z0.98 F1800.0 E84.0021
( Linear move to (75.8978, 64.53, 0.98). )
G1 X75.8978 Y64.53 Z0.98 F1800.0 E84.0213
( Linear move to (75.8978, 64.53, 0.98). )
G1 F1200.0
( Linear move to (75.8978, 64.53, 0.98). )
G1 E83.0213
( Linear move to (75.8978, 64.53, 0.98). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (88.47, 77.4137, 0.98). )
G1 X88.47 Y77.4137 Z0.98 F6000.0
( Linear move to (88.47, 77.4137, 0.98). )
G1 F1200.0
( Linear move to (88.47, 77.4137, 0.98). )
G1 E84.0213
( Linear move to (88.47, 77.4137, 0.98). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (87.4137, 78.47, 0.98). )
G1 X87.4137 Y78.47 Z0.98 F1800.0 E84.0632
( Linear move to (86.5652, 78.47, 0.98). )
G1 X86.5652 Y78.47 Z0.98 F1800.0 E84.087
( Linear move to (88.47, 76.5652, 0.98). )
G1 X88.47 Y76.5652 Z0.98 F1800.0 E84.1626
( Linear move to (88.47, 75.7166, 0.98). )
G1 X88.47 Y75.7166 Z0.98 F1800.0 E84.1864
( Linear move to (85.7166, 78.47, 0.98). )
G1 X85.7166 Y78.47 Z0.98 F1800.0 E84.2957
( Linear move to (84.8681, 78.47, 0.98). )
G1 X84.8681 Y78.47 Z0.98 F1800.0 E84.3195
( Linear move to (88.47, 74.8681, 0.98). )
G1 X88.47 Y74.8681 Z0.98 F1800.0 E84.4625
( Linear move to (88.47, 74.0196, 0.98). )
G1 X88.47 Y74.0196 Z0.98 F1800.0 E84.4863
( Linear move to (84.0196, 78.47, 0.98). )
G1 X84.0196 Y78.47 Z0.98 F1800.0 E84.6629
( Linear move to (83.5581, 78.0829, 0.98). )
G1 X83.5581 Y78.0829 Z0.98 F1800.0 E84.6798
( Linear move to (88.47, 73.171, 0.98). )
G1 X88.47 Y73.171 Z0.98 F1800.0 E84.8747
( Linear move to (88.47, 72.3225, 0.98). )
G1 X88.47 Y72.3225 Z0.98 F1800.0 E84.8985
( Linear move to (83.53, 77.2625, 0.98). )
G1 X83.53 Y77.2625 Z0.98 F1800.0 E85.0945
( Linear move to (83.53, 76.414, 0.98). )
G1 X83.53 Y76.414 Z0.98 F1800.0 E85.1183
( Linear move to (88.47, 71.474, 0.98). )
G1 X88.47 Y71.474 Z0.98 F1800.0 E85.3144
( Linear move to (88.47, 70.6255, 0.98). )
G1 X88.47 Y70.6255 Z0.98 F1800.0 E85.3382
( Linear move to (83.53, 75.5655, 0.98). )
G1 X83.53 Y75.5655 Z0.98 F1800.0 E85.5342
( Linear move to (83.53, 74.7169, 0.98). )
G1 X83.53 Y74.7169 Z0.98 F1800.0 E85.558
( Linear move to (88.47, 69.7769, 0.98). )
G1 X88.47 Y69.7769 Z0.98 F1800.0 E85.7541
( Linear move to (88.47, 68.9284, 0.98). )
G1 X88.47 Y68.9284 Z0.98 F1800.0 E85.7779
( Linear move to (83.53, 73.8684, 0.98). )
G1 X83.53 Y73.8684 Z0.98 F1800.0 E85.9739
( Linear move to (83.53, 73.0199, 0.98). )
G1 X83.53 Y73.0199 Z0.98 F1800.0 E85.9977
( Linear move to (88.47, 68.0799, 0.98). )
G1 X88.47 Y68.0799 Z0.98 F1800.0 E86.1938
( Linear move to (88.47, 67.2313, 0.98). )
G1 X88.47 Y67.2313 Z0.98 F1800.0 E86.2176
( Linear move to (83.53, 72.1713, 0.98). )
G1 X83.53 Y72.1713 Z0.98 F1800.0 E86.4136
( Linear move to (83.53, 71.3228, 0.98). )
G1 X83.53 Y71.3228 Z0.98 F1800.0 E86.4374
( Linear move to (88.47, 66.3828, 0.98). )
G1 X88.47 Y66.3828 Z0.98 F1800.0 E86.6335
( Linear move to (88.47, 65.5343, 0.98). )
G1 X88.47 Y65.5343 Z0.98 F1800.0 E86.6573
( Linear move to (83.53, 70.4743, 0.98). )
G1 X83.53 Y70.4743 Z0.98 F1800.0 E86.8533
( Linear move to (83.53, 69.6258, 0.98). )
G1 X83.53 Y69.6258 Z0.98 F1800.0 E86.8771
( Linear move to (88.3403, 64.8155, 0.98). )
G1 X88.3403 Y64.8155 Z0.98 F1800.0 E87.068
( Linear move to (87.7772, 64.53, 0.98). )
G1 X87.7772 Y64.53 Z0.98 F1800.0 E87.0857
( Linear move to (83.53, 68.7772, 0.98). )
G1 X83.53 Y68.7772 Z0.98 F1800.0 E87.2543
( Linear move to (82.9887, 68.47, 0.98). )
G1 X82.9887 Y68.47 Z0.98 F1800.0 E87.2717
( Linear move to (86.9287, 64.53, 0.98). )
G1 X86.9287 Y64.53 Z0.98 F1800.0 E87.4281
( Linear move to (86.0802, 64.53, 0.98). )
G1 X86.0802 Y64.53 Z0.98 F1800.0 E87.4519
( Linear move to (85.5323, 65.0779, 0.98). )
G1 X85.5323 Y65.0779 Z0.98 F1800.0 E87.4736
( Linear move to (85.5323, 65.0779, 0.98). )
G1 F1200.0
( Linear move to (85.5323, 65.0779, 0.98). )
G1 E86.4736
( Linear move to (85.5323, 65.0779, 0.98). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(<operatingLayerEnd> </operatingLayerEnd>)
(</crafting>)
( Linear move to (85.5323, 65.0779, 0.98). )
G1 F1200.0
( Linear move to (85.5323, 65.0779, 0.98). )
G1 E85.4736
( Linear move to (85.5323, 65.0779, 0.98). )
G1 F1800.0
( Extruder off. )
M103
M113 S0.0
( Turn fan off. )
M107
(<alteration>)
(<alterationFile>) endP1.gcode (</alterationFile>)
G91
G0 Z10
( Set positioning to absolute. )
G90
( Linear move to (85.5323, 110.0, 0.98). )
G1 Y110 F2000
M84
(</alteration>)
