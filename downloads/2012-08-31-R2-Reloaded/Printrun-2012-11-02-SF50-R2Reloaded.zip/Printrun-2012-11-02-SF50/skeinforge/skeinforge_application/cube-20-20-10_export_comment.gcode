(<alteration>)
(<alterationFile>) start.gcode (</alterationFile>)
( Set units to mm. )
G21 (Set units to mm)
( Set positioning to absolute. )
G90 (Absolute coordinates)
( Start at home. )
G28 (--Home all Axis ---)
G92 X0 Y0 Z0 E0 (-- Current position is 0,0,0 ---)
( Linear move to (0.0, 0.0, 5.0). )
G1 Z5.0 F300.0
( Linear move to (100.0, 100.0, 0.72). )
G1 X100 Y100 Z0.72 F2000.0
(</alteration>)
(<format> skeinforge gcode </format>)
(<version> 12.03.14 </version>)
(<created> 12.08.02|16:59 </created>)
(<extruderInitialization>)
( Set positioning to absolute. )
G90 ;set positioning to absolute
( Set units to mm. )
G21 ;set units to millimeters
( Extruder off. )
M103
(<craftTypeName> extrusion </craftTypeName>)
(<decimalPlacesCarried> 4 </decimalPlacesCarried>)
(<layerThickness> 0.4 </layerThickness>)
(<infillWidth> 0.6 </infillWidth>)
(<volumeFraction> 0.82 </volumeFraction>)
(<infillPerimeterOverlap> 0.15 </infillPerimeterOverlap>)
(<sharpestProduct> 0.866 </sharpestProduct>)
(<layerHeight> 0.4 </layerHeight>)
(<threadSequenceString> edge loops infill </threadSequenceString>)
(<maximumZFeedRatePerSecond> 1.0 </maximumZFeedRatePerSecond>)
(<objectFirstLayerFeedRateInfillMultiplier> 0.3 </objectFirstLayerFeedRateInfillMultiplier>)
(<operatingFeedRatePerSecond> 30.0 </operatingFeedRatePerSecond>)
(<objectFirstLayerFlowRateInfillMultiplier> 0.2 </objectFirstLayerFlowRateInfillMultiplier>)
(<operatingFlowRate> 22.0 </operatingFlowRate>)
(<orbitalFeedRatePerSecond> 15.0 </orbitalFeedRatePerSecond>)
(<travelFeedRatePerSecond> 100.0 </travelFeedRatePerSecond>)
(<skirtOutset> 2.52 </skirtOutset>)
( Turn fan on. )
M106
(<edgeWidth> 0.72 </edgeWidth>)
(<perimeterWidth> 0.72 </perimeterWidth>)
(<profileName> R2-Reloaded </profileName>)
(<settings>)
(<setting> alteration Activate_Alteration True </setting>)
(<setting> alteration Name_of_End_File: end.gcode </setting>)
(<setting> alteration Name_of_Start_File: start.gcode </setting>)
(<setting> alteration Remove_Redundant_Mcode True </setting>)
(<setting> alteration Replace_Variable_with_Setting True </setting>)
(<setting> bottom Activate_Bottom True </setting>)
(<setting> bottom Additional_Height_over_Layer_Thickness_(ratio): 0.0 </setting>)
(<setting> bottom Altitude_(mm): 0.0 </setting>)
(<setting> bottom SVG_Viewer: webbrowser </setting>)
(<setting> cool Activate_Cool True </setting>)
(<setting> cool Bridge_Cool_(Celcius): 1.0 </setting>)
(<setting> cool Orbit False </setting>)
(<setting> cool Slow_Down True </setting>)
(<setting> cool Maximum_Cool_(Celcius): 2.0 </setting>)
(<setting> cool Minimum_Layer_Time_(seconds): 15.0 </setting>)
(<setting> cool Minimum_Orbital_Radius_(millimeters): 10.0 </setting>)
(<setting> cool Name_of_Cool_End_File: cool_end.gcode </setting>)
(<setting> cool Name_of_Cool_Start_File: cool_start.gcode </setting>)
(<setting> cool Orbital_Outset_(millimeters): 2.0 </setting>)
(<setting> cool Turn_Fan_On_at_Beginning True </setting>)
(<setting> cool Turn_Fan_Off_at_Ending True </setting>)
(<setting> dimension Activate_Dimension True </setting>)
(<setting> dimension Absolute_Extrusion_Distance True </setting>)
(<setting> dimension Relative_Extrusion_Distance False </setting>)
(<setting> dimension Extruder_Retraction_Speed_(mm/s): 20.0 </setting>)
(<setting> dimension Filament_Diameter_(mm): 3.0 </setting>)
(<setting> dimension Filament_Packing_Density_(ratio): 1.0 </setting>)
(<setting> dimension Maximum_E_Value_before_Reset_(float): 91234.0 </setting>)
(<setting> dimension Minimum_Travel_for_Retraction_(millimeters): 1.0 </setting>)
(<setting> dimension Retract_Within_Island False </setting>)
(<setting> dimension Retraction_Distance_(millimeters): 1.0 </setting>)
(<setting> dimension Restart_Extra_Distance_(millimeters): 0.0 </setting>)
(<setting> export Activate_Export True </setting>)
(<setting> export Add_Descriptive_Extension False </setting>)
(<setting> export Add_Export_Suffix True </setting>)
(<setting> export Add_Profile_Extension False </setting>)
(<setting> export Add_Timestamp_Extension False </setting>)
(<setting> export Also_Send_Output_To:  </setting>)
(<setting> export Analyze_Gcode True </setting>)
(<setting> export Do_Not_Delete_Comments False </setting>)
(<setting> export Delete_Crafting_Comments False </setting>)
(<setting> export Delete_All_Comments True </setting>)
(<setting> export Do_Not_Change_Output False </setting>)
(<setting> export binary_16_byte False </setting>)
(<setting> export gcode_step False </setting>)
(<setting> export gcode_time_segment False </setting>)
(<setting> export gcode_small True </setting>)
(<setting> export File_Extension: gcode </setting>)
(<setting> export Name_of_Replace_File: replace.csv </setting>)
(<setting> export Save_Penultimate_Gcode False </setting>)
(<setting> fill Activate_Fill True </setting>)
(<setting> fill Diaphragm_Period_(layers): 100 </setting>)
(<setting> fill Diaphragm_Thickness_(layers): 0 </setting>)
(<setting> fill Extra_Shells_on_Alternating_Solid_Layer_(layers): 1 </setting>)
(<setting> fill Extra_Shells_on_Base_(layers): 1 </setting>)
(<setting> fill Extra_Shells_on_Sparse_Layer_(layers): 1 </setting>)
(<setting> fill Grid_Circle_Separation_over_Perimeter_Width_(ratio): 0.2 </setting>)
(<setting> fill Grid_Extra_Overlap_(ratio): 0.1 </setting>)
(<setting> fill Grid_Junction_Separation_Band_Height_(layers): 10 </setting>)
(<setting> fill Grid_Junction_Separation_over_Octogon_Radius_At_End_(ratio): 0.0 </setting>)
(<setting> fill Grid_Junction_Separation_over_Octogon_Radius_At_Middle_(ratio): 0.0 </setting>)
(<setting> fill Infill_Begin_Rotation_(degrees): 45.0 </setting>)
(<setting> fill Infill_Begin_Rotation_Repeat_(layers): 1 </setting>)
(<setting> fill Infill_Odd_Layer_Extra_Rotation_(degrees): 90.0 </setting>)
(<setting> fill Grid_Circular False </setting>)
(<setting> fill Grid_Hexagonal True </setting>)
(<setting> fill Grid_Rectangular False </setting>)
(<setting> fill Line False </setting>)
(<setting> fill Infill_Perimeter_Overlap_(ratio): 0.15 </setting>)
(<setting> fill Infill_Solidity_(ratio): 0.3 </setting>)
(<setting> fill Sharpest_Angle_(degrees): 60.0 </setting>)
(<setting> fill Solid_Surface_Thickness_(layers): 3 </setting>)
(<setting> fill Lower_Left True </setting>)
(<setting> fill Nearest False </setting>)
(<setting> fill Surrounding_Angle_(degrees): 60.0 </setting>)
(<setting> fill Infill_>_Loops_>_Perimeter False </setting>)
(<setting> fill Infill_>_Perimeter_>_Loops False </setting>)
(<setting> fill Loops_>_Infill_>_Perimeter False </setting>)
(<setting> fill Loops_>_Perimeter_>_Infill False </setting>)
(<setting> fill Perimeter_>_Infill_>_Loops False </setting>)
(<setting> fill Perimeter_>_Loops_>_Infill True </setting>)
(<setting> limit Activate_Limit True </setting>)
(<setting> limit Maximum_Initial_Feed_Rate_(mm/s): 20.0 </setting>)
(<setting> multiply Activate_Multiply True </setting>)
(<setting> multiply Center_X_(mm): 100.0 </setting>)
(<setting> multiply Center_Y_(mm): 90.0 </setting>)
(<setting> multiply Number_of_Columns_(integer): 1 </setting>)
(<setting> multiply Number_of_Rows_(integer): 1 </setting>)
(<setting> multiply Reverse_Sequence_every_Odd_Layer False </setting>)
(<setting> multiply Separation_over_Perimeter_Width_(ratio): 15.0 </setting>)
(<setting> raft Activate_Raft True </setting>)
(<setting> raft Add_Raft,_Elevate_Nozzle,_Orbit: True </setting>)
(<setting> raft Base_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Base_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Base_Infill_Density_(ratio): 0.5 </setting>)
(<setting> raft Base_Layer_Thickness_over_Layer_Thickness: 2.0 </setting>)
(<setting> raft Base_Layers_(integer): 0 </setting>)
(<setting> raft Base_Nozzle_Lift_over_Base_Layer_Thickness_(ratio): 0.4 </setting>)
(<setting> raft Initial_Circling: False </setting>)
(<setting> raft Infill_Overhang_over_Extrusion_Width_(ratio): 0.05 </setting>)
(<setting> raft Interface_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Interface_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> raft Interface_Infill_Density_(ratio): 0.5 </setting>)
(<setting> raft Interface_Layer_Thickness_over_Layer_Thickness: 1.0 </setting>)
(<setting> raft Interface_Layers_(integer): 0 </setting>)
(<setting> raft Interface_Nozzle_Lift_over_Interface_Layer_Thickness_(ratio): 0.45 </setting>)
(<setting> raft Name_of_Support_End_File: support_end.gcode </setting>)
(<setting> raft Name_of_Support_Start_File: support_start.gcode </setting>)
(<setting> raft Operating_Nozzle_Lift_over_Layer_Thickness_(ratio): 0.5 </setting>)
(<setting> raft Raft_Additional_Margin_over_Length_(%): 1.0 </setting>)
(<setting> raft Raft_Margin_(mm): 3.0 </setting>)
(<setting> raft Support_Cross_Hatch False </setting>)
(<setting> raft Support_Flow_Rate_over_Operating_Flow_Rate_(ratio): 1.0 </setting>)
(<setting> raft Support_Gap_over_Perimeter_Extrusion_Width_(ratio): 1.0 </setting>)
(<setting> raft None True </setting>)
(<setting> raft Empty_Layers_Only False </setting>)
(<setting> raft Everywhere False </setting>)
(<setting> raft Exterior_Only False </setting>)
(<setting> raft Support_Minimum_Angle_(degrees): 60.0 </setting>)
(<setting> skirt Activate_Skirt True </setting>)
(<setting> skirt Convex: True </setting>)
(<setting> skirt Gap_over_Perimeter_Width_(ratio): 3.0 </setting>)
(<setting> skirt Layers_To_(index): 1 </setting>)
(<setting> speed Activate_Speed True </setting>)
(<setting> speed Add_Flow_Rate: True </setting>)
(<setting> speed Bridge_Feed_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> speed Bridge_Flow_Rate_Multiplier_(ratio): 1.0 </setting>)
(<setting> speed Duty_Cyle_at_Beginning_(portion): 1.0 </setting>)
(<setting> speed Duty_Cyle_at_Ending_(portion): 0.0 </setting>)
(<setting> speed Feed_Rate_(mm/s): 30.0 </setting>)
(<setting> speed Flow_Rate_Setting_(float): 22.0 </setting>)
(<setting> speed Object_First_Layer_Feed_Rate_Infill_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Object_First_Layer_Feed_Rate_Perimeter_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Object_First_Layer_Flow_Rate_Infill_Multiplier_(ratio): 0.2 </setting>)
(<setting> speed Object_First_Layer_Flow_Rate_Perimeter_Multiplier_(ratio): 0.3 </setting>)
(<setting> speed Orbital_Feed_Rate_over_Operating_Feed_Rate_(ratio): 0.5 </setting>)
(<setting> speed Maximum_Z_Feed_Rate_(mm/s): 1.0 </setting>)
(<setting> speed Perimeter_Feed_Rate_Multiplier_(ratio): 0.75 </setting>)
(<setting> speed Perimeter_Flow_Rate_Multiplier_(ratio): 0.75 </setting>)
(<setting> speed Travel_Feed_Rate_(mm/s): 100.0 </setting>)
(</settings>)
(<timeStampPreface> 20120802_165956 </timeStampPreface>)
(<procedureName> carve </procedureName>)
(<procedureName> bottom </procedureName>)
(<procedureName> preface </procedureName>)
(<procedureName> inset </procedureName>)
(<procedureName> fill </procedureName>)
(<procedureName> multiply </procedureName>)
(<procedureName> speed </procedureName>)
(<procedureName> raft </procedureName>)
(<procedureName> skirt </procedureName>)
(<procedureName> cool </procedureName>)
(<procedureName> limit </procedureName>)
(<procedureName> dimension </procedureName>)
(<procedureName> alteration </procedureName>)
(</extruderInitialization>)
(<crafting>)
M113 S1.0
( Set extruder speed to 4.95. )
M108 S4.95
(<layer> 0.2 )
(<skirt>)
( Linear move to (87.48, 102.52, 0.2). )
G1 X87.48 Y102.52 Z0.2 F1200.0
( Linear move to (87.48, 102.52, 0.2). )
G1 F1200.0
( Linear move to (87.48, 102.52, 0.2). )
G1 E1.0
( Linear move to (87.48, 102.52, 0.2). )
G1 F1200.0
( Extruder on, forward. )
M101
( Linear move to (110.5835, 102.52, 0.2). )
G1 X110.5835 Y102.52 Z0.2 F405.0 E1.6903
( Linear move to (112.52, 100.3069, 0.2). )
G1 X112.52 Y100.3069 Z0.2 F405.0 E1.7782
( Linear move to (112.52, 79.6931, 0.2). )
G1 X112.52 Y79.6931 Z0.2 F405.0 E2.3941
( Linear move to (110.5835, 77.48, 0.2). )
G1 X110.5835 Y77.48 Z0.2 F405.0 E2.4819
( Linear move to (87.48, 77.48, 0.2). )
G1 X87.48 Y77.48 Z0.2 F405.0 E3.1722
( Linear move to (87.48, 102.52, 0.2). )
G1 X87.48 Y102.52 Z0.2 F405.0 E3.9204
( Linear move to (87.48, 102.52, 0.2). )
G1 F1200.0
( Linear move to (87.48, 102.52, 0.2). )
G1 E2.9204
( Linear move to (87.48, 102.52, 0.2). )
G1 F405.0
( Extruder off. )
M103
( Set extruder speed to 4.95. )
M108 S4.95
(</skirt>)
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z0.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z0.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z0.2 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z0.2 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 0.2). )
G1 X90.36 Y80.36 Z0.2 F6000.0
( Linear move to (90.36, 80.36, 0.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 0.2). )
G1 E3.9204
( Linear move to (90.36, 80.36, 0.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 0.2). )
G1 X109.64 Y80.36 Z0.2 F405.0 E4.4965
( Linear move to (109.64, 99.64, 0.2). )
G1 X109.64 Y99.64 Z0.2 F405.0 E5.0725
( Linear move to (90.36, 99.64, 0.2). )
G1 X90.36 Y99.64 Z0.2 F405.0 E5.6486
( Linear move to (90.36, 80.36, 0.2). )
G1 X90.36 Y80.36 Z0.2 F405.0 E6.2247
( Linear move to (90.36, 80.36, 0.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 0.2). )
G1 E6.2247
( Linear move to (90.36, 80.36, 0.2). )
G1 F405.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 4.4. )
M108 S4.4
( Linear move to (91.02, 81.02, 0.2). )
G1 X91.02 Y81.02 Z0.2 F6000.0
( Linear move to (91.02, 81.02, 0.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 0.2). )
G1 E6.2247
( Linear move to (91.02, 81.02, 0.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 0.2). )
G1 X108.98 Y81.02 Z0.2 F540.0 E6.5824
( Linear move to (108.98, 98.98, 0.2). )
G1 X108.98 Y98.98 Z0.2 F540.0 E6.9401
( Linear move to (91.02, 98.98, 0.2). )
G1 X91.02 Y98.98 Z0.2 F540.0 E7.2979
( Linear move to (91.02, 81.02, 0.2). )
G1 X91.02 Y81.02 Z0.2 F540.0 E7.6556
( Linear move to (91.02, 81.02, 0.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 0.2). )
G1 E7.6408
( Linear move to (91.02, 81.02, 0.2). )
G1 F540.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z0.0 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z0.0 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z0.0 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z0.0 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.7376, 81.7376, 0.2). )
G1 X91.7376 Y81.7376 Z0.2 F6000.0
( Linear move to (91.7376, 81.7376, 0.2). )
G1 F1200.0
( Linear move to (91.7376, 81.7376, 0.2). )
G1 E7.6556
( Linear move to (91.7376, 81.7376, 0.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.2624, 98.2624, 0.2). )
G1 X108.2624 Y98.2624 Z0.2 F540.0 E8.1211
( Linear move to (108.47, 97.6215, 0.2). )
G1 X108.47 Y97.6215 Z0.2 F540.0 E8.1346
( Linear move to (92.3785, 81.53, 0.2). )
G1 X92.3785 Y81.53 Z0.2 F540.0 E8.5879
( Linear move to (93.2271, 81.53, 0.2). )
G1 X93.2271 Y81.53 Z0.2 F540.0 E8.6048
( Linear move to (108.47, 96.7729, 0.2). )
G1 X108.47 Y96.7729 Z0.2 F540.0 E9.0342
( Linear move to (108.47, 95.9244, 0.2). )
G1 X108.47 Y95.9244 Z0.2 F540.0 E9.0511
( Linear move to (94.0756, 81.53, 0.2). )
G1 X94.0756 Y81.53 Z0.2 F540.0 E9.4565
( Linear move to (94.9241, 81.53, 0.2). )
G1 X94.9241 Y81.53 Z0.2 F540.0 E9.4734
( Linear move to (108.47, 95.0759, 0.2). )
G1 X108.47 Y95.0759 Z0.2 F540.0 E9.855
( Linear move to (108.47, 94.2274, 0.2). )
G1 X108.47 Y94.2274 Z0.2 F540.0 E9.8719
( Linear move to (95.7726, 81.53, 0.2). )
G1 X95.7726 Y81.53 Z0.2 F540.0 E10.2296
( Linear move to (96.6212, 81.53, 0.2). )
G1 X96.6212 Y81.53 Z0.2 F540.0 E10.2465
( Linear move to (108.47, 93.3788, 0.2). )
G1 X108.47 Y93.3788 Z0.2 F540.0 E10.5803
( Linear move to (108.47, 92.5303, 0.2). )
G1 X108.47 Y92.5303 Z0.2 F540.0 E10.5972
( Linear move to (97.4697, 81.53, 0.2). )
G1 X97.4697 Y81.53 Z0.2 F540.0 E10.9071
( Linear move to (98.3182, 81.53, 0.2). )
G1 X98.3182 Y81.53 Z0.2 F540.0 E10.924
( Linear move to (108.47, 91.6818, 0.2). )
G1 X108.47 Y91.6818 Z0.2 F540.0 E11.21
( Linear move to (108.47, 90.8332, 0.2). )
G1 X108.47 Y90.8332 Z0.2 F540.0 E11.2269
( Linear move to (99.1668, 81.53, 0.2). )
G1 X99.1668 Y81.53 Z0.2 F540.0 E11.4889
( Linear move to (100.0153, 81.53, 0.2). )
G1 X100.0153 Y81.53 Z0.2 F540.0 E11.5058
( Linear move to (108.47, 89.9847, 0.2). )
G1 X108.47 Y89.9847 Z0.2 F540.0 E11.744
( Linear move to (108.47, 89.1362, 0.2). )
G1 X108.47 Y89.1362 Z0.2 F540.0 E11.7609
( Linear move to (100.8638, 81.53, 0.2). )
G1 X100.8638 Y81.53 Z0.2 F540.0 E11.9752
( Linear move to (101.7123, 81.53, 0.2). )
G1 X101.7123 Y81.53 Z0.2 F540.0 E11.9921
( Linear move to (108.47, 88.2877, 0.2). )
G1 X108.47 Y88.2877 Z0.2 F540.0 E12.1824
( Linear move to (108.47, 87.4391, 0.2). )
G1 X108.47 Y87.4391 Z0.2 F540.0 E12.1993
( Linear move to (102.5609, 81.53, 0.2). )
G1 X102.5609 Y81.53 Z0.2 F540.0 E12.3658
( Linear move to (103.4094, 81.53, 0.2). )
G1 X103.4094 Y81.53 Z0.2 F540.0 E12.3827
( Linear move to (108.47, 86.5906, 0.2). )
G1 X108.47 Y86.5906 Z0.2 F540.0 E12.5253
( Linear move to (108.47, 85.7421, 0.2). )
G1 X108.47 Y85.7421 Z0.2 F540.0 E12.5422
( Linear move to (104.2579, 81.53, 0.2). )
G1 X104.2579 Y81.53 Z0.2 F540.0 E12.6608
( Linear move to (105.1065, 81.53, 0.2). )
G1 X105.1065 Y81.53 Z0.2 F540.0 E12.6777
( Linear move to (108.47, 84.8935, 0.2). )
G1 X108.47 Y84.8935 Z0.2 F540.0 E12.7725
( Linear move to (108.47, 84.045, 0.2). )
G1 X108.47 Y84.045 Z0.2 F540.0 E12.7894
( Linear move to (105.955, 81.53, 0.2). )
G1 X105.955 Y81.53 Z0.2 F540.0 E12.8602
( Linear move to (106.8035, 81.53, 0.2). )
G1 X106.8035 Y81.53 Z0.2 F540.0 E12.8771
( Linear move to (108.47, 83.1965, 0.2). )
G1 X108.47 Y83.1965 Z0.2 F540.0 E12.9241
( Linear move to (108.47, 82.348, 0.2). )
G1 X108.47 Y82.348 Z0.2 F540.0 E12.941
( Linear move to (107.652, 81.53, 0.2). )
G1 X107.652 Y81.53 Z0.2 F540.0 E12.964
( Linear move to (107.652, 81.53, 0.2). )
G1 F1200.0
( Linear move to (107.652, 81.53, 0.2). )
G1 E11.964
( Linear move to (107.652, 81.53, 0.2). )
G1 F540.0
( Extruder off. )
M103
( Linear move to (91.53, 82.3785, 0.2). )
G1 X91.53 Y82.3785 Z0.2 F6000.0
( Linear move to (91.53, 82.3785, 0.2). )
G1 F1200.0
( Linear move to (91.53, 82.3785, 0.2). )
G1 E12.964
( Linear move to (91.53, 82.3785, 0.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.6215, 98.47, 0.2). )
G1 X107.6215 Y98.47 Z0.2 F540.0 E13.4173
( Linear move to (106.7729, 98.47, 0.2). )
G1 X106.7729 Y98.47 Z0.2 F540.0 E13.4342
( Linear move to (91.53, 83.2271, 0.2). )
G1 X91.53 Y83.2271 Z0.2 F540.0 E13.8636
( Linear move to (91.53, 84.0756, 0.2). )
G1 X91.53 Y84.0756 Z0.2 F540.0 E13.8805
( Linear move to (105.9244, 98.47, 0.2). )
G1 X105.9244 Y98.47 Z0.2 F540.0 E14.286
( Linear move to (105.0759, 98.47, 0.2). )
G1 X105.0759 Y98.47 Z0.2 F540.0 E14.3029
( Linear move to (91.53, 84.9241, 0.2). )
G1 X91.53 Y84.9241 Z0.2 F540.0 E14.6845
( Linear move to (91.53, 85.7726, 0.2). )
G1 X91.53 Y85.7726 Z0.2 F540.0 E14.7014
( Linear move to (104.2274, 98.47, 0.2). )
G1 X104.2274 Y98.47 Z0.2 F540.0 E15.0591
( Linear move to (103.3788, 98.47, 0.2). )
G1 X103.3788 Y98.47 Z0.2 F540.0 E15.076
( Linear move to (91.53, 86.6212, 0.2). )
G1 X91.53 Y86.6212 Z0.2 F540.0 E15.4097
( Linear move to (91.53, 87.4697, 0.2). )
G1 X91.53 Y87.4697 Z0.2 F540.0 E15.4266
( Linear move to (102.5303, 98.47, 0.2). )
G1 X102.5303 Y98.47 Z0.2 F540.0 E15.7365
( Linear move to (101.6818, 98.47, 0.2). )
G1 X101.6818 Y98.47 Z0.2 F540.0 E15.7534
( Linear move to (91.53, 88.3182, 0.2). )
G1 X91.53 Y88.3182 Z0.2 F540.0 E16.0394
( Linear move to (91.53, 89.1668, 0.2). )
G1 X91.53 Y89.1668 Z0.2 F540.0 E16.0563
( Linear move to (100.8332, 98.47, 0.2). )
G1 X100.8332 Y98.47 Z0.2 F540.0 E16.3184
( Linear move to (99.9847, 98.47, 0.2). )
G1 X99.9847 Y98.47 Z0.2 F540.0 E16.3353
( Linear move to (91.53, 90.0153, 0.2). )
G1 X91.53 Y90.0153 Z0.2 F540.0 E16.5734
( Linear move to (91.53, 90.8638, 0.2). )
G1 X91.53 Y90.8638 Z0.2 F540.0 E16.5903
( Linear move to (99.1362, 98.47, 0.2). )
G1 X99.1362 Y98.47 Z0.2 F540.0 E16.8046
( Linear move to (98.2877, 98.47, 0.2). )
G1 X98.2877 Y98.47 Z0.2 F540.0 E16.8215
( Linear move to (91.53, 91.7123, 0.2). )
G1 X91.53 Y91.7123 Z0.2 F540.0 E17.0119
( Linear move to (91.53, 92.5609, 0.2). )
G1 X91.53 Y92.5609 Z0.2 F540.0 E17.0288
( Linear move to (97.4391, 98.47, 0.2). )
G1 X97.4391 Y98.47 Z0.2 F540.0 E17.1952
( Linear move to (96.5906, 98.47, 0.2). )
G1 X96.5906 Y98.47 Z0.2 F540.0 E17.2121
( Linear move to (91.53, 93.4094, 0.2). )
G1 X91.53 Y93.4094 Z0.2 F540.0 E17.3547
( Linear move to (91.53, 94.2579, 0.2). )
G1 X91.53 Y94.2579 Z0.2 F540.0 E17.3716
( Linear move to (95.7421, 98.47, 0.2). )
G1 X95.7421 Y98.47 Z0.2 F540.0 E17.4902
( Linear move to (94.8935, 98.47, 0.2). )
G1 X94.8935 Y98.47 Z0.2 F540.0 E17.5071
( Linear move to (91.53, 95.1065, 0.2). )
G1 X91.53 Y95.1065 Z0.2 F540.0 E17.6019
( Linear move to (91.53, 95.955, 0.2). )
G1 X91.53 Y95.955 Z0.2 F540.0 E17.6188
( Linear move to (94.045, 98.47, 0.2). )
G1 X94.045 Y98.47 Z0.2 F540.0 E17.6896
( Linear move to (93.1965, 98.47, 0.2). )
G1 X93.1965 Y98.47 Z0.2 F540.0 E17.7065
( Linear move to (91.53, 96.8035, 0.2). )
G1 X91.53 Y96.8035 Z0.2 F540.0 E17.7535
( Linear move to (91.53, 97.652, 0.2). )
G1 X91.53 Y97.652 Z0.2 F540.0 E17.7704
( Linear move to (92.348, 98.47, 0.2). )
G1 X92.348 Y98.47 Z0.2 F540.0 E17.7934
( Linear move to (92.348, 98.47, 0.2). )
G1 F1200.0
( Linear move to (92.348, 98.47, 0.2). )
G1 E16.7934
( Linear move to (92.348, 98.47, 0.2). )
G1 F540.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
( Set extruder speed to 16.5. )
M108 S16.5
(<layer> 0.6 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z0.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z0.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z0.6 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z0.6 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 0.6). )
G1 X90.36 Y80.36 Z0.6 F2733.4768
( Linear move to (90.36, 80.36, 0.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 0.6). )
G1 E17.7934
( Linear move to (90.36, 80.36, 0.6). )
G1 F2733.4768
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 0.6). )
G1 X109.64 Y80.36 Z0.6 F1350.0 E18.3695
( Linear move to (109.64, 99.64, 0.6). )
G1 X109.64 Y99.64 Z0.6 F1350.0 E18.9456
( Linear move to (90.36, 99.64, 0.6). )
G1 X90.36 Y99.64 Z0.6 F1350.0 E19.5216
( Linear move to (90.36, 80.36, 0.6). )
G1 X90.36 Y80.36 Z0.6 F1350.0 E20.0977
( Linear move to (90.36, 80.36, 0.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 0.6). )
G1 E20.0977
( Linear move to (90.36, 80.36, 0.6). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 22.0. )
M108 S22.0
( Linear move to (91.02, 81.02, 0.6). )
G1 X91.02 Y81.02 Z0.6 F6000.0
( Linear move to (91.02, 81.02, 0.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 0.6). )
G1 E20.0977
( Linear move to (91.02, 81.02, 0.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 0.6). )
G1 X108.98 Y81.02 Z0.6 F1800.0 E20.6343
( Linear move to (108.98, 98.98, 0.6). )
G1 X108.98 Y98.98 Z0.6 F1800.0 E21.1709
( Linear move to (91.02, 98.98, 0.6). )
G1 X91.02 Y98.98 Z0.6 F1800.0 E21.7075
( Linear move to (91.02, 81.02, 0.6). )
G1 X91.02 Y81.02 Z0.6 F1800.0 E22.2442
( Linear move to (91.02, 81.02, 0.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 0.6). )
G1 E21.2442
( Linear move to (91.02, 81.02, 0.6). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z0.4 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z0.4 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z0.4 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z0.4 </infillPoint>)
(</infillBoundary>)
( Linear move to (108.47, 97.9047, 0.6). )
G1 X108.47 Y97.9047 Z0.6 F6000.0
( Linear move to (108.47, 97.9047, 0.6). )
G1 F1200.0
( Linear move to (108.47, 97.9047, 0.6). )
G1 E22.2442
( Linear move to (108.47, 97.9047, 0.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.9047, 98.47, 0.6). )
G1 X107.9047 Y98.47 Z0.6 F1800.0 E22.2681
( Linear move to (107.0561, 98.47, 0.6). )
G1 X107.0561 Y98.47 Z0.6 F1800.0 E22.2934
( Linear move to (108.47, 97.0561, 0.6). )
G1 X108.47 Y97.0561 Z0.6 F1800.0 E22.3532
( Linear move to (108.47, 96.2076, 0.6). )
G1 X108.47 Y96.2076 Z0.6 F1800.0 E22.3785
( Linear move to (106.2076, 98.47, 0.6). )
G1 X106.2076 Y98.47 Z0.6 F1800.0 E22.4741
( Linear move to (105.3591, 98.47, 0.6). )
G1 X105.3591 Y98.47 Z0.6 F1800.0 E22.4995
( Linear move to (108.47, 95.3591, 0.6). )
G1 X108.47 Y95.3591 Z0.6 F1800.0 E22.6309
( Linear move to (108.47, 94.5106, 0.6). )
G1 X108.47 Y94.5106 Z0.6 F1800.0 E22.6563
( Linear move to (104.5106, 98.47, 0.6). )
G1 X104.5106 Y98.47 Z0.6 F1800.0 E22.8236
( Linear move to (103.662, 98.47, 0.6). )
G1 X103.662 Y98.47 Z0.6 F1800.0 E22.8489
( Linear move to (108.47, 93.662, 0.6). )
G1 X108.47 Y93.662 Z0.6 F1800.0 E23.0521
( Linear move to (108.47, 92.8135, 0.6). )
G1 X108.47 Y92.8135 Z0.6 F1800.0 E23.0774
( Linear move to (102.8135, 98.47, 0.6). )
G1 X102.8135 Y98.47 Z0.6 F1800.0 E23.3164
( Linear move to (101.965, 98.47, 0.6). )
G1 X101.965 Y98.47 Z0.6 F1800.0 E23.3418
( Linear move to (108.47, 91.965, 0.6). )
G1 X108.47 Y91.965 Z0.6 F1800.0 E23.6167
( Linear move to (108.47, 91.1164, 0.6). )
G1 X108.47 Y91.1164 Z0.6 F1800.0 E23.642
( Linear move to (101.1164, 98.47, 0.6). )
G1 X101.1164 Y98.47 Z0.6 F1800.0 E23.9527
( Linear move to (100.2679, 98.47, 0.6). )
G1 X100.2679 Y98.47 Z0.6 F1800.0 E23.9781
( Linear move to (108.47, 90.2679, 0.6). )
G1 X108.47 Y90.2679 Z0.6 F1800.0 E24.3247
( Linear move to (108.47, 89.4194, 0.6). )
G1 X108.47 Y89.4194 Z0.6 F1800.0 E24.35
( Linear move to (99.4194, 98.47, 0.6). )
G1 X99.4194 Y98.47 Z0.6 F1800.0 E24.7325
( Linear move to (98.5709, 98.47, 0.6). )
G1 X98.5709 Y98.47 Z0.6 F1800.0 E24.7578
( Linear move to (108.47, 88.5709, 0.6). )
G1 X108.47 Y88.5709 Z0.6 F1800.0 E25.1761
( Linear move to (108.47, 87.7223, 0.6). )
G1 X108.47 Y87.7223 Z0.6 F1800.0 E25.2014
( Linear move to (97.7223, 98.47, 0.6). )
G1 X97.7223 Y98.47 Z0.6 F1800.0 E25.6556
( Linear move to (96.8738, 98.47, 0.6). )
G1 X96.8738 Y98.47 Z0.6 F1800.0 E25.6809
( Linear move to (108.47, 86.8738, 0.6). )
G1 X108.47 Y86.8738 Z0.6 F1800.0 E26.1709
( Linear move to (108.47, 86.0253, 0.6). )
G1 X108.47 Y86.0253 Z0.6 F1800.0 E26.1963
( Linear move to (96.0253, 98.47, 0.6). )
G1 X96.0253 Y98.47 Z0.6 F1800.0 E26.7221
( Linear move to (95.1768, 98.47, 0.6). )
G1 X95.1768 Y98.47 Z0.6 F1800.0 E26.7475
( Linear move to (108.47, 85.1768, 0.6). )
G1 X108.47 Y85.1768 Z0.6 F1800.0 E27.3092
( Linear move to (108.47, 84.3282, 0.6). )
G1 X108.47 Y84.3282 Z0.6 F1800.0 E27.3346
( Linear move to (94.3282, 98.47, 0.6). )
G1 X94.3282 Y98.47 Z0.6 F1800.0 E27.9321
( Linear move to (93.4797, 98.47, 0.6). )
G1 X93.4797 Y98.47 Z0.6 F1800.0 E27.9575
( Linear move to (108.47, 83.4797, 0.6). )
G1 X108.47 Y83.4797 Z0.6 F1800.0 E28.5909
( Linear move to (108.47, 82.6312, 0.6). )
G1 X108.47 Y82.6312 Z0.6 F1800.0 E28.6162
( Linear move to (92.6312, 98.47, 0.6). )
G1 X92.6312 Y98.47 Z0.6 F1800.0 E29.2855
( Linear move to (91.8639, 98.3887, 0.6). )
G1 X91.8639 Y98.3887 Z0.6 F1800.0 E29.3085
( Linear move to (108.3887, 81.8639, 0.6). )
G1 X108.3887 Y81.8639 Z0.6 F1800.0 E30.0068
( Linear move to (107.8741, 81.53, 0.6). )
G1 X107.8741 Y81.53 Z0.6 F1800.0 E30.0251
( Linear move to (91.53, 97.8741, 0.6). )
G1 X91.53 Y97.8741 Z0.6 F1800.0 E30.7157
( Linear move to (91.53, 97.0256, 0.6). )
G1 X91.53 Y97.0256 Z0.6 F1800.0 E30.7411
( Linear move to (107.0256, 81.53, 0.6). )
G1 X107.0256 Y81.53 Z0.6 F1800.0 E31.3959
( Linear move to (106.1771, 81.53, 0.6). )
G1 X106.1771 Y81.53 Z0.6 F1800.0 E31.4212
( Linear move to (91.53, 96.1771, 0.6). )
G1 X91.53 Y96.1771 Z0.6 F1800.0 E32.0401
( Linear move to (91.53, 95.3285, 0.6). )
G1 X91.53 Y95.3285 Z0.6 F1800.0 E32.0655
( Linear move to (105.3285, 81.53, 0.6). )
G1 X105.3285 Y81.53 Z0.6 F1800.0 E32.6485
( Linear move to (104.48, 81.53, 0.6). )
G1 X104.48 Y81.53 Z0.6 F1800.0 E32.6739
( Linear move to (91.53, 94.48, 0.6). )
G1 X91.53 Y94.48 Z0.6 F1800.0 E33.2211
( Linear move to (91.53, 93.6315, 0.6). )
G1 X91.53 Y93.6315 Z0.6 F1800.0 E33.2464
( Linear move to (103.6315, 81.53, 0.6). )
G1 X103.6315 Y81.53 Z0.6 F1800.0 E33.7578
( Linear move to (102.7829, 81.53, 0.6). )
G1 X102.7829 Y81.53 Z0.6 F1800.0 E33.7831
( Linear move to (91.53, 92.7829, 0.6). )
G1 X91.53 Y92.7829 Z0.6 F1800.0 E34.2586
( Linear move to (91.53, 91.9344, 0.6). )
G1 X91.53 Y91.9344 Z0.6 F1800.0 E34.284
( Linear move to (101.9344, 81.53, 0.6). )
G1 X101.9344 Y81.53 Z0.6 F1800.0 E34.7236
( Linear move to (101.0859, 81.53, 0.6). )
G1 X101.0859 Y81.53 Z0.6 F1800.0 E34.749
( Linear move to (91.53, 91.0859, 0.6). )
G1 X91.53 Y91.0859 Z0.6 F1800.0 E35.1528
( Linear move to (91.53, 90.2374, 0.6). )
G1 X91.53 Y90.2374 Z0.6 F1800.0 E35.1781
( Linear move to (100.2374, 81.53, 0.6). )
G1 X100.2374 Y81.53 Z0.6 F1800.0 E35.546
( Linear move to (99.3888, 81.53, 0.6). )
G1 X99.3888 Y81.53 Z0.6 F1800.0 E35.5714
( Linear move to (91.53, 89.3888, 0.6). )
G1 X91.53 Y89.3888 Z0.6 F1800.0 E35.9035
( Linear move to (91.53, 88.5403, 0.6). )
G1 X91.53 Y88.5403 Z0.6 F1800.0 E35.9288
( Linear move to (98.5403, 81.53, 0.6). )
G1 X98.5403 Y81.53 Z0.6 F1800.0 E36.225
( Linear move to (97.6918, 81.53, 0.6). )
G1 X97.6918 Y81.53 Z0.6 F1800.0 E36.2504
( Linear move to (91.53, 87.6918, 0.6). )
G1 X91.53 Y87.6918 Z0.6 F1800.0 E36.5108
( Linear move to (91.53, 86.8432, 0.6). )
G1 X91.53 Y86.8432 Z0.6 F1800.0 E36.5361
( Linear move to (96.8432, 81.53, 0.6). )
G1 X96.8432 Y81.53 Z0.6 F1800.0 E36.7606
( Linear move to (95.9947, 81.53, 0.6). )
G1 X95.9947 Y81.53 Z0.6 F1800.0 E36.786
( Linear move to (91.53, 85.9947, 0.6). )
G1 X91.53 Y85.9947 Z0.6 F1800.0 E36.9746
( Linear move to (91.53, 85.1462, 0.6). )
G1 X91.53 Y85.1462 Z0.6 F1800.0 E37.0
( Linear move to (95.1462, 81.53, 0.6). )
G1 X95.1462 Y81.53 Z0.6 F1800.0 E37.1528
( Linear move to (94.2977, 81.53, 0.6). )
G1 X94.2977 Y81.53 Z0.6 F1800.0 E37.1781
( Linear move to (91.53, 84.2977, 0.6). )
G1 X91.53 Y84.2977 Z0.6 F1800.0 E37.2951
( Linear move to (91.53, 83.4491, 0.6). )
G1 X91.53 Y83.4491 Z0.6 F1800.0 E37.3204
( Linear move to (93.4491, 81.53, 0.6). )
G1 X93.4491 Y81.53 Z0.6 F1800.0 E37.4015
( Linear move to (92.6006, 81.53, 0.6). )
G1 X92.6006 Y81.53 Z0.6 F1800.0 E37.4269
( Linear move to (91.53, 82.6006, 0.6). )
G1 X91.53 Y82.6006 Z0.6 F1800.0 E37.4721
( Linear move to (91.53, 82.6006, 0.6). )
G1 F1200.0
( Linear move to (91.53, 82.6006, 0.6). )
G1 E36.4721
( Linear move to (91.53, 82.6006, 0.6). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(<operatingLayerEnd> </operatingLayerEnd>)
(<layer> 1.0 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z1.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z1.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z1.0 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z1.0 </boundaryPoint>)
(<edge> outer )
( Set extruder speed to 16.5. )
M108 S16.5
( Linear move to (90.36, 80.36, 1.0). )
G1 X90.36 Y80.36 Z1.0 F383.8707
( Linear move to (90.36, 80.36, 1.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.0). )
G1 E37.4721
( Linear move to (90.36, 80.36, 1.0). )
G1 F383.8707
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 1.0). )
G1 X109.64 Y80.36 Z1.0 F1350.0 E38.0482
( Linear move to (109.64, 99.64, 1.0). )
G1 X109.64 Y99.64 Z1.0 F1350.0 E38.6242
( Linear move to (90.36, 99.64, 1.0). )
G1 X90.36 Y99.64 Z1.0 F1350.0 E39.2003
( Linear move to (90.36, 80.36, 1.0). )
G1 X90.36 Y80.36 Z1.0 F1350.0 E39.7764
( Linear move to (90.36, 80.36, 1.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.0). )
G1 E39.7764
( Linear move to (90.36, 80.36, 1.0). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 22.0. )
M108 S22.0
( Linear move to (91.02, 81.02, 1.0). )
G1 X91.02 Y81.02 Z1.0 F6000.0
( Linear move to (91.02, 81.02, 1.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.0). )
G1 E39.7764
( Linear move to (91.02, 81.02, 1.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 1.0). )
G1 X108.98 Y81.02 Z1.0 F1800.0 E40.313
( Linear move to (108.98, 98.98, 1.0). )
G1 X108.98 Y98.98 Z1.0 F1800.0 E40.8496
( Linear move to (91.02, 98.98, 1.0). )
G1 X91.02 Y98.98 Z1.0 F1800.0 E41.3862
( Linear move to (91.02, 81.02, 1.0). )
G1 X91.02 Y81.02 Z1.0 F1800.0 E41.9228
( Linear move to (91.02, 81.02, 1.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.0). )
G1 E41.908
( Linear move to (91.02, 81.02, 1.0). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z0.8 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z0.8 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z0.8 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z0.8 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.7376, 81.7376, 1.0). )
G1 X91.7376 Y81.7376 Z1.0 F6000.0
( Linear move to (91.7376, 81.7376, 1.0). )
G1 F1200.0
( Linear move to (91.7376, 81.7376, 1.0). )
G1 E41.9228
( Linear move to (91.7376, 81.7376, 1.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.2624, 98.2624, 1.0). )
G1 X108.2624 Y98.2624 Z1.0 F1800.0 E42.6211
( Linear move to (108.47, 97.6215, 1.0). )
G1 X108.47 Y97.6215 Z1.0 F1800.0 E42.6412
( Linear move to (92.3785, 81.53, 1.0). )
G1 X92.3785 Y81.53 Z1.0 F1800.0 E43.3212
( Linear move to (93.2271, 81.53, 1.0). )
G1 X93.2271 Y81.53 Z1.0 F1800.0 E43.3465
( Linear move to (108.47, 96.7729, 1.0). )
G1 X108.47 Y96.7729 Z1.0 F1800.0 E43.9906
( Linear move to (108.47, 95.9244, 1.0). )
G1 X108.47 Y95.9244 Z1.0 F1800.0 E44.016
( Linear move to (94.0756, 81.53, 1.0). )
G1 X94.0756 Y81.53 Z1.0 F1800.0 E44.6242
( Linear move to (94.9241, 81.53, 1.0). )
G1 X94.9241 Y81.53 Z1.0 F1800.0 E44.6495
( Linear move to (108.47, 95.0759, 1.0). )
G1 X108.47 Y95.0759 Z1.0 F1800.0 E45.2219
( Linear move to (108.47, 94.2274, 1.0). )
G1 X108.47 Y94.2274 Z1.0 F1800.0 E45.2473
( Linear move to (95.7726, 81.53, 1.0). )
G1 X95.7726 Y81.53 Z1.0 F1800.0 E45.7838
( Linear move to (96.6212, 81.53, 1.0). )
G1 X96.6212 Y81.53 Z1.0 F1800.0 E45.8092
( Linear move to (108.47, 93.3788, 1.0). )
G1 X108.47 Y93.3788 Z1.0 F1800.0 E46.3098
( Linear move to (108.47, 92.5303, 1.0). )
G1 X108.47 Y92.5303 Z1.0 F1800.0 E46.3352
( Linear move to (97.4697, 81.53, 1.0). )
G1 X97.4697 Y81.53 Z1.0 F1800.0 E46.8
( Linear move to (98.3182, 81.53, 1.0). )
G1 X98.3182 Y81.53 Z1.0 F1800.0 E46.8254
( Linear move to (108.47, 91.6818, 1.0). )
G1 X108.47 Y91.6818 Z1.0 F1800.0 E47.2543
( Linear move to (108.47, 90.8332, 1.0). )
G1 X108.47 Y90.8332 Z1.0 F1800.0 E47.2797
( Linear move to (99.1668, 81.53, 1.0). )
G1 X99.1668 Y81.53 Z1.0 F1800.0 E47.6728
( Linear move to (100.0153, 81.53, 1.0). )
G1 X100.0153 Y81.53 Z1.0 F1800.0 E47.6981
( Linear move to (108.47, 89.9847, 1.0). )
G1 X108.47 Y89.9847 Z1.0 F1800.0 E48.0554
( Linear move to (108.47, 89.1362, 1.0). )
G1 X108.47 Y89.1362 Z1.0 F1800.0 E48.0807
( Linear move to (100.8638, 81.53, 1.0). )
G1 X100.8638 Y81.53 Z1.0 F1800.0 E48.4021
( Linear move to (101.7123, 81.53, 1.0). )
G1 X101.7123 Y81.53 Z1.0 F1800.0 E48.4275
( Linear move to (108.47, 88.2877, 1.0). )
G1 X108.47 Y88.2877 Z1.0 F1800.0 E48.713
( Linear move to (108.47, 87.4391, 1.0). )
G1 X108.47 Y87.4391 Z1.0 F1800.0 E48.7384
( Linear move to (102.5609, 81.53, 1.0). )
G1 X102.5609 Y81.53 Z1.0 F1800.0 E48.9881
( Linear move to (103.4094, 81.53, 1.0). )
G1 X103.4094 Y81.53 Z1.0 F1800.0 E49.0134
( Linear move to (108.47, 86.5906, 1.0). )
G1 X108.47 Y86.5906 Z1.0 F1800.0 E49.2273
( Linear move to (108.47, 85.7421, 1.0). )
G1 X108.47 Y85.7421 Z1.0 F1800.0 E49.2526
( Linear move to (104.2579, 81.53, 1.0). )
G1 X104.2579 Y81.53 Z1.0 F1800.0 E49.4306
( Linear move to (105.1065, 81.53, 1.0). )
G1 X105.1065 Y81.53 Z1.0 F1800.0 E49.4559
( Linear move to (108.47, 84.8935, 1.0). )
G1 X108.47 Y84.8935 Z1.0 F1800.0 E49.5981
( Linear move to (108.47, 84.045, 1.0). )
G1 X108.47 Y84.045 Z1.0 F1800.0 E49.6234
( Linear move to (105.955, 81.53, 1.0). )
G1 X105.955 Y81.53 Z1.0 F1800.0 E49.7297
( Linear move to (106.8035, 81.53, 1.0). )
G1 X106.8035 Y81.53 Z1.0 F1800.0 E49.755
( Linear move to (108.47, 83.1965, 1.0). )
G1 X108.47 Y83.1965 Z1.0 F1800.0 E49.8255
( Linear move to (108.47, 82.348, 1.0). )
G1 X108.47 Y82.348 Z1.0 F1800.0 E49.8508
( Linear move to (107.652, 81.53, 1.0). )
G1 X107.652 Y81.53 Z1.0 F1800.0 E49.8854
( Linear move to (107.652, 81.53, 1.0). )
G1 F1200.0
( Linear move to (107.652, 81.53, 1.0). )
G1 E48.8854
( Linear move to (107.652, 81.53, 1.0). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (91.53, 82.3785, 1.0). )
G1 X91.53 Y82.3785 Z1.0 F6000.0
( Linear move to (91.53, 82.3785, 1.0). )
G1 F1200.0
( Linear move to (91.53, 82.3785, 1.0). )
G1 E49.8854
( Linear move to (91.53, 82.3785, 1.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.6215, 98.47, 1.0). )
G1 X107.6215 Y98.47 Z1.0 F1800.0 E50.5653
( Linear move to (106.7729, 98.47, 1.0). )
G1 X106.7729 Y98.47 Z1.0 F1800.0 E50.5907
( Linear move to (91.53, 83.2271, 1.0). )
G1 X91.53 Y83.2271 Z1.0 F1800.0 E51.2348
( Linear move to (91.53, 84.0756, 1.0). )
G1 X91.53 Y84.0756 Z1.0 F1800.0 E51.2601
( Linear move to (105.9244, 98.47, 1.0). )
G1 X105.9244 Y98.47 Z1.0 F1800.0 E51.8683
( Linear move to (105.0759, 98.47, 1.0). )
G1 X105.0759 Y98.47 Z1.0 F1800.0 E51.8937
( Linear move to (91.53, 84.9241, 1.0). )
G1 X91.53 Y84.9241 Z1.0 F1800.0 E52.4661
( Linear move to (91.53, 85.7726, 1.0). )
G1 X91.53 Y85.7726 Z1.0 F1800.0 E52.4914
( Linear move to (104.2274, 98.47, 1.0). )
G1 X104.2274 Y98.47 Z1.0 F1800.0 E53.028
( Linear move to (103.3788, 98.47, 1.0). )
G1 X103.3788 Y98.47 Z1.0 F1800.0 E53.0533
( Linear move to (91.53, 86.6212, 1.0). )
G1 X91.53 Y86.6212 Z1.0 F1800.0 E53.554
( Linear move to (91.53, 87.4697, 1.0). )
G1 X91.53 Y87.4697 Z1.0 F1800.0 E53.5793
( Linear move to (102.5303, 98.47, 1.0). )
G1 X102.5303 Y98.47 Z1.0 F1800.0 E54.0442
( Linear move to (101.6818, 98.47, 1.0). )
G1 X101.6818 Y98.47 Z1.0 F1800.0 E54.0695
( Linear move to (91.53, 88.3182, 1.0). )
G1 X91.53 Y88.3182 Z1.0 F1800.0 E54.4985
( Linear move to (91.53, 89.1668, 1.0). )
G1 X91.53 Y89.1668 Z1.0 F1800.0 E54.5238
( Linear move to (100.8332, 98.47, 1.0). )
G1 X100.8332 Y98.47 Z1.0 F1800.0 E54.9169
( Linear move to (99.9847, 98.47, 1.0). )
G1 X99.9847 Y98.47 Z1.0 F1800.0 E54.9423
( Linear move to (91.53, 90.0153, 1.0). )
G1 X91.53 Y90.0153 Z1.0 F1800.0 E55.2995
( Linear move to (91.53, 90.8638, 1.0). )
G1 X91.53 Y90.8638 Z1.0 F1800.0 E55.3249
( Linear move to (99.1362, 98.47, 1.0). )
G1 X99.1362 Y98.47 Z1.0 F1800.0 E55.6463
( Linear move to (98.2877, 98.47, 1.0). )
G1 X98.2877 Y98.47 Z1.0 F1800.0 E55.6716
( Linear move to (91.53, 91.7123, 1.0). )
G1 X91.53 Y91.7123 Z1.0 F1800.0 E55.9572
( Linear move to (91.53, 92.5609, 1.0). )
G1 X91.53 Y92.5609 Z1.0 F1800.0 E55.9825
( Linear move to (97.4391, 98.47, 1.0). )
G1 X97.4391 Y98.47 Z1.0 F1800.0 E56.2322
( Linear move to (96.5906, 98.47, 1.0). )
G1 X96.5906 Y98.47 Z1.0 F1800.0 E56.2576
( Linear move to (91.53, 93.4094, 1.0). )
G1 X91.53 Y93.4094 Z1.0 F1800.0 E56.4714
( Linear move to (91.53, 94.2579, 1.0). )
G1 X91.53 Y94.2579 Z1.0 F1800.0 E56.4968
( Linear move to (95.7421, 98.47, 1.0). )
G1 X95.7421 Y98.47 Z1.0 F1800.0 E56.6747
( Linear move to (94.8935, 98.47, 1.0). )
G1 X94.8935 Y98.47 Z1.0 F1800.0 E56.7001
( Linear move to (91.53, 95.1065, 1.0). )
G1 X91.53 Y95.1065 Z1.0 F1800.0 E56.8422
( Linear move to (91.53, 95.955, 1.0). )
G1 X91.53 Y95.955 Z1.0 F1800.0 E56.8676
( Linear move to (94.045, 98.47, 1.0). )
G1 X94.045 Y98.47 Z1.0 F1800.0 E56.9738
( Linear move to (93.1965, 98.47, 1.0). )
G1 X93.1965 Y98.47 Z1.0 F1800.0 E56.9992
( Linear move to (91.53, 96.8035, 1.0). )
G1 X91.53 Y96.8035 Z1.0 F1800.0 E57.0696
( Linear move to (91.53, 97.652, 1.0). )
G1 X91.53 Y97.652 Z1.0 F1800.0 E57.095
( Linear move to (92.348, 98.47, 1.0). )
G1 X92.348 Y98.47 Z1.0 F1800.0 E57.1295
( Linear move to (92.348, 98.47, 1.0). )
G1 F1200.0
( Linear move to (92.348, 98.47, 1.0). )
G1 E56.1295
( Linear move to (92.348, 98.47, 1.0). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(<layer> 1.4 )
( Set extruder speed to 12.53. )
M108 S12.53
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z1.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z1.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z1.4 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z1.4 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 1.4). )
G1 X90.36 Y80.36 Z1.4 F2733.4768
( Linear move to (90.36, 80.36, 1.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.4). )
G1 E57.1295
( Linear move to (90.36, 80.36, 1.4). )
G1 F2733.4768
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 1.4). )
G1 X109.64 Y80.36 Z1.4 F1025.5193 E57.7054
( Linear move to (109.64, 99.64, 1.4). )
G1 X109.64 Y99.64 Z1.4 F1025.5193 E58.2813
( Linear move to (90.36, 99.64, 1.4). )
G1 X90.36 Y99.64 Z1.4 F1025.5193 E58.8571
( Linear move to (90.36, 80.36, 1.4). )
G1 X90.36 Y80.36 Z1.4 F1025.5193 E59.433
( Linear move to (90.36, 80.36, 1.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.4). )
G1 E59.433
( Linear move to (90.36, 80.36, 1.4). )
G1 F1025.5193
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 1.4). )
G1 X91.02 Y81.02 Z1.4 F6000.0
( Linear move to (91.02, 81.02, 1.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.4). )
G1 E59.433
( Linear move to (91.02, 81.02, 1.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 1.4). )
G1 X108.98 Y81.02 Z1.4 F1367.3591 E59.9696
( Linear move to (108.98, 98.98, 1.4). )
G1 X108.98 Y98.98 Z1.4 F1367.3591 E60.5061
( Linear move to (91.02, 98.98, 1.4). )
G1 X91.02 Y98.98 Z1.4 F1367.3591 E61.0427
( Linear move to (91.02, 81.02, 1.4). )
G1 X91.02 Y81.02 Z1.4 F1367.3591 E61.5792
( Linear move to (91.02, 81.02, 1.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.4). )
G1 E60.5792
( Linear move to (91.02, 81.02, 1.4). )
G1 F1367.3591
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z1.2 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z1.2 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z1.2 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z1.2 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 1.4). )
G1 X91.53 Y93.6315 Z1.4 F6000.0
( Linear move to (91.53, 93.6315, 1.4). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 1.4). )
G1 E61.5792
( Linear move to (91.53, 93.6315, 1.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 1.4). )
G1 X91.53 Y87.6918 Z1.4 F1367.3591 E61.7567
( Linear move to (93.3935, 87.9968, 1.4). )
G1 X93.3935 Y87.9968 Z1.4 F1367.3591 E61.8131
( Linear move to (93.7541, 87.6361, 1.4). )
G1 X93.7541 Y87.6361 Z1.4 F1367.3591 E61.8283
( Linear move to (93.8649, 85.6397, 1.4). )
G1 X93.8649 Y85.6397 Z1.4 F1367.3591 E61.8881
( Linear move to (94.2255, 85.2791, 1.4). )
G1 X94.2255 Y85.2791 Z1.4 F1367.3591 E61.9033
( Linear move to (96.2219, 85.1683, 1.4). )
G1 X96.2219 Y85.1683 Z1.4 F1367.3591 E61.963
( Linear move to (96.5825, 84.8077, 1.4). )
G1 X96.5825 Y84.8077 Z1.4 F1367.3591 E61.9783
( Linear move to (103.6315, 82.13, 1.4). )
G1 X103.6315 Y82.13 Z1.4 F1367.3591 E62.2035
( Linear move to (104.48, 81.53, 1.4). )
G1 X104.48 Y81.53 Z1.4 F1367.3591 E62.2346
( Linear move to (93.4491, 81.53, 1.4). )
G1 X93.4491 Y81.53 Z1.4 F1367.3591 E62.5641
( Linear move to (93.4491, 82.13, 1.4). )
G1 X93.4491 Y82.13 Z1.4 F1367.3591 E62.582
( Linear move to (92.13, 86.8432, 1.4). )
G1 X92.13 Y86.8432 Z1.4 F1367.3591 E62.7283
( Linear move to (91.53, 85.9947, 1.4). )
G1 X91.53 Y85.9947 Z1.4 F1367.3591 E62.7593
( Linear move to (91.53, 82.6006, 1.4). )
G1 X91.53 Y82.6006 Z1.4 F1367.3591 E62.8607
( Linear move to (92.6006, 81.53, 1.4). )
G1 X92.6006 Y81.53 Z1.4 F1367.3591 E62.9059
( Linear move to (92.6006, 81.53, 1.4). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 1.4). )
G1 E61.9059
( Linear move to (92.6006, 81.53, 1.4). )
G1 F1367.3591
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 1.4). )
G1 X108.47 Y97.0561 Z1.4 F6000.0
( Linear move to (108.47, 97.0561, 1.4). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 1.4). )
G1 E62.9059
( Linear move to (108.47, 97.0561, 1.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 1.4). )
G1 X108.47 Y97.9047 Z1.4 F1367.3591 E62.9313
( Linear move to (107.9047, 98.47, 1.4). )
G1 X107.9047 Y98.47 Z1.4 F1367.3591 E62.9552
( Linear move to (105.3591, 98.47, 1.4). )
G1 X105.3591 Y98.47 Z1.4 F1367.3591 E63.0312
( Linear move to (105.1786, 96.9534, 1.4). )
G1 X105.1786 Y96.9534 Z1.4 F1367.3591 E63.0769
( Linear move to (105.5392, 96.5928, 1.4). )
G1 X105.5392 Y96.5928 Z1.4 F1367.3591 E63.0921
( Linear move to (108.47, 96.2076, 1.4). )
G1 X108.47 Y96.2076 Z1.4 F1367.3591 E63.1804
( Linear move to (108.47, 89.4194, 1.4). )
G1 X108.47 Y89.4194 Z1.4 F1367.3591 E63.3832
( Linear move to (106.9534, 89.5217, 1.4). )
G1 X106.9534 Y89.5217 Z1.4 F1367.3591 E63.4286
( Linear move to (106.5928, 89.8824, 1.4). )
G1 X106.5928 Y89.8824 Z1.4 F1367.3591 E63.4438
( Linear move to (106.482, 91.8788, 1.4). )
G1 X106.482 Y91.8788 Z1.4 F1367.3591 E63.5036
( Linear move to (106.1214, 92.2394, 1.4). )
G1 X106.1214 Y92.2394 Z1.4 F1367.3591 E63.5188
( Linear move to (104.125, 92.3502, 1.4). )
G1 X104.125 Y92.3502 Z1.4 F1367.3591 E63.5785
( Linear move to (103.7644, 92.7108, 1.4). )
G1 X103.7644 Y92.7108 Z1.4 F1367.3591 E63.5938
( Linear move to (103.6536, 94.7072, 1.4). )
G1 X103.6536 Y94.7072 Z1.4 F1367.3591 E63.6535
( Linear move to (103.293, 95.0678, 1.4). )
G1 X103.293 Y95.0678 Z1.4 F1367.3591 E63.6687
( Linear move to (101.2966, 95.1786, 1.4). )
G1 X101.2966 Y95.1786 Z1.4 F1367.3591 E63.7285
( Linear move to (100.936, 95.5392, 1.4). )
G1 X100.936 Y95.5392 Z1.4 F1367.3591 E63.7437
( Linear move to (100.6449, 97.7159, 1.4). )
G1 X100.6449 Y97.7159 Z1.4 F1367.3591 E63.8093
( Linear move to (104.5106, 97.87, 1.4). )
G1 X104.5106 Y97.87 Z1.4 F1367.3591 E63.9249
( Linear move to (103.662, 98.47, 1.4). )
G1 X103.662 Y98.47 Z1.4 F1367.3591 E63.956
( Linear move to (98.5709, 98.47, 1.4). )
G1 X98.5709 Y98.47 Z1.4 F1367.3591 E64.108
( Linear move to (98.4682, 98.007, 1.4). )
G1 X98.4682 Y98.007 Z1.4 F1367.3591 E64.1222
( Linear move to (98.1075, 98.3676, 1.4). )
G1 X98.1075 Y98.3676 Z1.4 F1367.3591 E64.1375
( Linear move to (97.7223, 98.47, 1.4). )
G1 X97.7223 Y98.47 Z1.4 F1367.3591 E64.1494
( Linear move to (94.3282, 98.47, 1.4). )
G1 X94.3282 Y98.47 Z1.4 F1367.3591 E64.2508
( Linear move to (93.8649, 96.9534, 1.4). )
G1 X93.8649 Y96.9534 Z1.4 F1367.3591 E64.2981
( Linear move to (94.2255, 96.5928, 1.4). )
G1 X94.2255 Y96.5928 Z1.4 F1367.3591 E64.3134
( Linear move to (96.2219, 96.482, 1.4). )
G1 X96.2219 Y96.482 Z1.4 F1367.3591 E64.3731
( Linear move to (96.5825, 96.1214, 1.4). )
G1 X96.5825 Y96.1214 Z1.4 F1367.3591 E64.3883
( Linear move to (96.6933, 94.125, 1.4). )
G1 X96.6933 Y94.125 Z1.4 F1367.3591 E64.4481
( Linear move to (97.0539, 93.7644, 1.4). )
G1 X97.0539 Y93.7644 Z1.4 F1367.3591 E64.4633
( Linear move to (99.0503, 93.6536, 1.4). )
G1 X99.0503 Y93.6536 Z1.4 F1367.3591 E64.523
( Linear move to (99.411, 93.293, 1.4). )
G1 X99.411 Y93.293 Z1.4 F1367.3591 E64.5383
( Linear move to (99.5217, 91.2966, 1.4). )
G1 X99.5217 Y91.2966 Z1.4 F1367.3591 E64.598
( Linear move to (99.8824, 90.936, 1.4). )
G1 X99.8824 Y90.936 Z1.4 F1367.3591 E64.6132
( Linear move to (101.8788, 90.8252, 1.4). )
G1 X101.8788 Y90.8252 Z1.4 F1367.3591 E64.673
( Linear move to (102.2394, 90.4646, 1.4). )
G1 X102.2394 Y90.4646 Z1.4 F1367.3591 E64.6882
( Linear move to (102.3502, 88.4682, 1.4). )
G1 X102.3502 Y88.4682 Z1.4 F1367.3591 E64.748
( Linear move to (102.7108, 88.1075, 1.4). )
G1 X102.7108 Y88.1075 Z1.4 F1367.3591 E64.7632
( Linear move to (104.7072, 87.9968, 1.4). )
G1 X104.7072 Y87.9968 Z1.4 F1367.3591 E64.8229
( Linear move to (105.0678, 87.6361, 1.4). )
G1 X105.0678 Y87.6361 Z1.4 F1367.3591 E64.8382
( Linear move to (105.1786, 85.6397, 1.4). )
G1 X105.1786 Y85.6397 Z1.4 F1367.3591 E64.8979
( Linear move to (105.5392, 85.2791, 1.4). )
G1 X105.5392 Y85.2791 Z1.4 F1367.3591 E64.9131
( Linear move to (108.47, 88.5709, 1.4). )
G1 X108.47 Y88.5709 Z1.4 F1367.3591 E65.0448
( Linear move to (108.3887, 81.8639, 1.4). )
G1 X108.3887 Y81.8639 Z1.4 F1367.3591 E65.2452
( Linear move to (107.8741, 81.53, 1.4). )
G1 X107.8741 Y81.53 Z1.4 F1367.3591 E65.2635
( Linear move to (106.1771, 81.53, 1.4). )
G1 X106.1771 Y81.53 Z1.4 F1367.3591 E65.3142
( Linear move to (103.293, 83.7541, 1.4). )
G1 X103.293 Y83.7541 Z1.4 F1367.3591 E65.423
( Linear move to (101.2966, 83.8649, 1.4). )
G1 X101.2966 Y83.8649 Z1.4 F1367.3591 E65.4828
( Linear move to (100.936, 84.2255, 1.4). )
G1 X100.936 Y84.2255 Z1.4 F1367.3591 E65.498
( Linear move to (100.8252, 86.2219, 1.4). )
G1 X100.8252 Y86.2219 Z1.4 F1367.3591 E65.5577
( Linear move to (100.4646, 86.5825, 1.4). )
G1 X100.4646 Y86.5825 Z1.4 F1367.3591 E65.573
( Linear move to (98.4682, 86.6933, 1.4). )
G1 X98.4682 Y86.6933 Z1.4 F1367.3591 E65.6327
( Linear move to (98.1075, 87.0539, 1.4). )
G1 X98.1075 Y87.0539 Z1.4 F1367.3591 E65.6479
( Linear move to (97.9968, 89.0503, 1.4). )
G1 X97.9968 Y89.0503 Z1.4 F1367.3591 E65.7077
( Linear move to (97.6361, 89.411, 1.4). )
G1 X97.6361 Y89.411 Z1.4 F1367.3591 E65.7229
( Linear move to (95.6397, 89.5217, 1.4). )
G1 X95.6397 Y89.5217 Z1.4 F1367.3591 E65.7826
( Linear move to (95.2791, 89.8824, 1.4). )
G1 X95.2791 Y89.8824 Z1.4 F1367.3591 E65.7979
( Linear move to (95.1683, 91.8788, 1.4). )
G1 X95.1683 Y91.8788 Z1.4 F1367.3591 E65.8576
( Linear move to (94.8077, 92.2394, 1.4). )
G1 X94.8077 Y92.2394 Z1.4 F1367.3591 E65.8728
( Linear move to (92.8113, 92.3502, 1.4). )
G1 X92.8113 Y92.3502 Z1.4 F1367.3591 E65.9326
( Linear move to (92.4507, 92.7108, 1.4). )
G1 X92.4507 Y92.7108 Z1.4 F1367.3591 E65.9478
( Linear move to (91.53, 94.48, 1.4). )
G1 X91.53 Y94.48 Z1.4 F1367.3591 E66.0074
( Linear move to (92.3399, 94.7072, 1.4). )
G1 X92.3399 Y94.7072 Z1.4 F1367.3591 E66.0325
( Linear move to (91.9793, 95.0678, 1.4). )
G1 X91.9793 Y95.0678 Z1.4 F1367.3591 E66.0478
( Linear move to (91.53, 95.3285, 1.4). )
G1 X91.53 Y95.3285 Z1.4 F1367.3591 E66.0633
( Linear move to (91.53, 97.8741, 1.4). )
G1 X91.53 Y97.8741 Z1.4 F1367.3591 E66.1393
( Linear move to (91.8639, 98.3887, 1.4). )
G1 X91.8639 Y98.3887 Z1.4 F1367.3591 E66.1576
( Linear move to (93.4797, 98.47, 1.4). )
G1 X93.4797 Y98.47 Z1.4 F1367.3591 E66.206
( Linear move to (93.4797, 98.47, 1.4). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 1.4). )
G1 E65.206
( Linear move to (93.4797, 98.47, 1.4). )
G1 F1367.3591
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 1.8 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z1.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z1.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z1.8 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z1.8 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 1.8). )
G1 X90.36 Y80.36 Z1.8 F2757.1641
( Linear move to (90.36, 80.36, 1.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.8). )
G1 E66.206
( Linear move to (90.36, 80.36, 1.8). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 1.8). )
G1 X109.64 Y80.36 Z1.8 F1205.9536 E66.7821
( Linear move to (109.64, 99.64, 1.8). )
G1 X109.64 Y99.64 Z1.8 F1205.9536 E67.3581
( Linear move to (90.36, 99.64, 1.8). )
G1 X90.36 Y99.64 Z1.8 F1205.9536 E67.9342
( Linear move to (90.36, 80.36, 1.8). )
G1 X90.36 Y80.36 Z1.8 F1205.9536 E68.5103
( Linear move to (90.36, 80.36, 1.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 1.8). )
G1 E68.5103
( Linear move to (90.36, 80.36, 1.8). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 1.8). )
G1 X91.02 Y81.02 Z1.8 F6000.0
( Linear move to (91.02, 81.02, 1.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.8). )
G1 E68.5103
( Linear move to (91.02, 81.02, 1.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 1.8). )
G1 X108.98 Y81.02 Z1.8 F1607.9381 E69.0469
( Linear move to (108.98, 98.98, 1.8). )
G1 X108.98 Y98.98 Z1.8 F1607.9381 E69.5834
( Linear move to (91.02, 98.98, 1.8). )
G1 X91.02 Y98.98 Z1.8 F1607.9381 E70.12
( Linear move to (91.02, 81.02, 1.8). )
G1 X91.02 Y81.02 Z1.8 F1607.9381 E70.6565
( Linear move to (91.02, 81.02, 1.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 1.8). )
G1 E70.2054
( Linear move to (91.02, 81.02, 1.8). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z1.6 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z1.6 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z1.6 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z1.6 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 1.8). )
G1 X92.3785 Y81.53 Z1.8 F6000.0
( Linear move to (92.3785, 81.53, 1.8). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 1.8). )
G1 E70.6565
( Linear move to (92.3785, 81.53, 1.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 1.8). )
G1 X91.7376 Y81.7376 Z1.8 F1607.9381 E70.6766
( Linear move to (91.53, 82.3785, 1.8). )
G1 X91.53 Y82.3785 Z1.8 F1607.9381 E70.6968
( Linear move to (92.3219, 83.4115, 1.8). )
G1 X92.3219 Y83.4115 Z1.8 F1607.9381 E70.7357
( Linear move to (94.2075, 85.2971, 1.8). )
G1 X94.2075 Y85.2971 Z1.8 F1607.9381 E70.8153
( Linear move to (96.2399, 85.1503, 1.8). )
G1 X96.2399 Y85.1503 Z1.8 F1607.9381 E70.8762
( Linear move to (98.1256, 87.0359, 1.8). )
G1 X98.1256 Y87.0359 Z1.8 F1607.9381 E70.9559
( Linear move to (97.9787, 89.0684, 1.8). )
G1 X97.9787 Y89.0684 Z1.8 F1607.9381 E71.0167
( Linear move to (99.8643, 90.954, 1.8). )
G1 X99.8643 Y90.954 Z1.8 F1607.9381 E71.0964
( Linear move to (101.8968, 90.8071, 1.8). )
G1 X101.8968 Y90.8071 Z1.8 F1607.9381 E71.1573
( Linear move to (103.7824, 92.6928, 1.8). )
G1 X103.7824 Y92.6928 Z1.8 F1607.9381 E71.237
( Linear move to (103.6356, 94.7252, 1.8). )
G1 X103.6356 Y94.7252 Z1.8 F1607.9381 E71.2978
( Linear move to (107.6215, 98.47, 1.8). )
G1 X107.6215 Y98.47 Z1.8 F1607.9381 E71.4612
( Linear move to (108.2624, 98.2624, 1.8). )
G1 X108.2624 Y98.2624 Z1.8 F1607.9381 E71.4813
( Linear move to (108.47, 97.6215, 1.8). )
G1 X108.47 Y97.6215 Z1.8 F1607.9381 E71.5015
( Linear move to (108.47, 93.3788, 1.8). )
G1 X108.47 Y93.3788 Z1.8 F1607.9381 E71.6282
( Linear move to (106.1394, 92.2214, 1.8). )
G1 X106.1394 Y92.2214 Z1.8 F1607.9381 E71.706
( Linear move to (104.107, 92.3682, 1.8). )
G1 X104.107 Y92.3682 Z1.8 F1607.9381 E71.7668
( Linear move to (102.2214, 90.4826, 1.8). )
G1 X102.2214 Y90.4826 Z1.8 F1607.9381 E71.8465
( Linear move to (102.3682, 88.4501, 1.8). )
G1 X102.3682 Y88.4501 Z1.8 F1607.9381 E71.9074
( Linear move to (100.4826, 86.5645, 1.8). )
G1 X100.4826 Y86.5645 Z1.8 F1607.9381 E71.987
( Linear move to (98.4501, 86.7113, 1.8). )
G1 X98.4501 Y86.7113 Z1.8 F1607.9381 E72.0479
( Linear move to (93.2271, 81.53, 1.8). )
G1 X93.2271 Y81.53 Z1.8 F1607.9381 E72.2677
( Linear move to (97.4697, 81.53, 1.8). )
G1 X97.4697 Y81.53 Z1.8 F1607.9381 E72.3945
( Linear move to (96.8736, 82.631, 1.8). )
G1 X96.8736 Y82.631 Z1.8 F1607.9381 E72.4319
( Linear move to (98.6819, 82.0072, 1.8). )
G1 X98.6819 Y82.0072 Z1.8 F1607.9381 E72.489
( Linear move to (99.1668, 81.53, 1.8). )
G1 X99.1668 Y81.53 Z1.8 F1607.9381 E72.5093
( Linear move to (100.954, 84.2075, 1.8). )
G1 X100.954 Y84.2075 Z1.8 F1607.9381 E72.6055
( Linear move to (100.8071, 86.2399, 1.8). )
G1 X100.8071 Y86.2399 Z1.8 F1607.9381 E72.6664
( Linear move to (102.6928, 88.1256, 1.8). )
G1 X102.6928 Y88.1256 Z1.8 F1607.9381 E72.7461
( Linear move to (104.7252, 87.9787, 1.8). )
G1 X104.7252 Y87.9787 Z1.8 F1607.9381 E72.8069
( Linear move to (106.6108, 89.8643, 1.8). )
G1 X106.6108 Y89.8643 Z1.8 F1607.9381 E72.8866
( Linear move to (106.464, 91.8968, 1.8). )
G1 X106.464 Y91.8968 Z1.8 F1607.9381 E72.9475
( Linear move to (108.47, 92.5303, 1.8). )
G1 X108.47 Y92.5303 Z1.8 F1607.9381 E73.0103
( Linear move to (108.47, 88.2877, 1.8). )
G1 X108.47 Y88.2877 Z1.8 F1607.9381 E73.1371
( Linear move to (106.9354, 89.5398, 1.8). )
G1 X106.9354 Y89.5398 Z1.8 F1607.9381 E73.1962
( Linear move to (105.0498, 87.6542, 1.8). )
G1 X105.0498 Y87.6542 Z1.8 F1607.9381 E73.2759
( Linear move to (105.1966, 85.6217, 1.8). )
G1 X105.1966 Y85.6217 Z1.8 F1607.9381 E73.3368
( Linear move to (103.311, 83.7361, 1.8). )
G1 X103.311 Y83.7361 Z1.8 F1607.9381 E73.4164
( Linear move to (101.2786, 83.8829, 1.8). )
G1 X101.2786 Y83.8829 Z1.8 F1607.9381 E73.4773
( Linear move to (100.0153, 81.53, 1.8). )
G1 X100.0153 Y81.53 Z1.8 F1607.9381 E73.5571
( Linear move to (105.1065, 81.53, 1.8). )
G1 X105.1065 Y81.53 Z1.8 F1607.9381 E73.7092
( Linear move to (103.6356, 83.4115, 1.8). )
G1 X103.6356 Y83.4115 Z1.8 F1607.9381 E73.7805
( Linear move to (105.5212, 85.2971, 1.8). )
G1 X105.5212 Y85.2971 Z1.8 F1607.9381 E73.8602
( Linear move to (108.47, 87.4391, 1.8). )
G1 X108.47 Y87.4391 Z1.8 F1607.9381 E73.9691
( Linear move to (108.47, 83.1965, 1.8). )
G1 X108.47 Y83.1965 Z1.8 F1607.9381 E74.0958
( Linear move to (105.955, 81.53, 1.8). )
G1 X105.955 Y81.53 Z1.8 F1607.9381 E74.186
( Linear move to (107.652, 81.53, 1.8). )
G1 X107.652 Y81.53 Z1.8 F1607.9381 E74.2367
( Linear move to (108.47, 82.348, 1.8). )
G1 X108.47 Y82.348 Z1.8 F1607.9381 E74.2712
( Linear move to (108.47, 82.348, 1.8). )
G1 F1200.0
( Linear move to (108.47, 82.348, 1.8). )
G1 E73.2712
( Linear move to (108.47, 82.348, 1.8). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 1.8). )
G1 X106.7729 Y98.47 Z1.8 F6000.0
( Linear move to (106.7729, 98.47, 1.8). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 1.8). )
G1 E74.2712
( Linear move to (106.7729, 98.47, 1.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 1.8). )
G1 X105.0759 Y98.47 Z1.8 F1607.9381 E74.3219
( Linear move to (105.1966, 96.9354, 1.8). )
G1 X105.1966 Y96.9354 Z1.8 F1607.9381 E74.3679
( Linear move to (103.311, 95.0498, 1.8). )
G1 X103.311 Y95.0498 Z1.8 F1607.9381 E74.4476
( Linear move to (101.2786, 95.1966, 1.8). )
G1 X101.2786 Y95.1966 Z1.8 F1607.9381 E74.5085
( Linear move to (99.3929, 93.311, 1.8). )
G1 X99.3929 Y93.311 Z1.8 F1607.9381 E74.5881
( Linear move to (99.5398, 91.2786, 1.8). )
G1 X99.5398 Y91.2786 Z1.8 F1607.9381 E74.649
( Linear move to (97.6542, 89.3929, 1.8). )
G1 X97.6542 Y89.3929 Z1.8 F1607.9381 E74.7287
( Linear move to (95.6217, 89.5398, 1.8). )
G1 X95.6217 Y89.5398 Z1.8 F1607.9381 E74.7895
( Linear move to (93.7361, 87.6542, 1.8). )
G1 X93.7361 Y87.6542 Z1.8 F1607.9381 E74.8692
( Linear move to (93.8829, 85.6217, 1.8). )
G1 X93.8829 Y85.6217 Z1.8 F1607.9381 E74.9301
( Linear move to (91.53, 83.2271, 1.8). )
G1 X91.53 Y83.2271 Z1.8 F1607.9381 E75.0304
( Linear move to (91.53, 88.3182, 1.8). )
G1 X91.53 Y88.3182 Z1.8 F1607.9381 E75.1825
( Linear move to (93.4115, 87.9787, 1.8). )
G1 X93.4115 Y87.9787 Z1.8 F1607.9381 E75.2396
( Linear move to (95.2971, 89.8643, 1.8). )
G1 X95.2971 Y89.8643 Z1.8 F1607.9381 E75.3193
( Linear move to (95.1503, 91.8968, 1.8). )
G1 X95.1503 Y91.8968 Z1.8 F1607.9381 E75.3801
( Linear move to (97.0359, 93.7824, 1.8). )
G1 X97.0359 Y93.7824 Z1.8 F1607.9381 E75.4598
( Linear move to (99.0684, 93.6356, 1.8). )
G1 X99.0684 Y93.6356 Z1.8 F1607.9381 E75.5207
( Linear move to (100.954, 95.5212, 1.8). )
G1 X100.954 Y95.5212 Z1.8 F1607.9381 E75.6004
( Linear move to (100.8071, 97.5537, 1.8). )
G1 X100.8071 Y97.5537 Z1.8 F1607.9381 E75.6612
( Linear move to (103.3788, 97.87, 1.8). )
G1 X103.3788 Y97.87 Z1.8 F1607.9381 E75.7386
( Linear move to (104.2274, 98.47, 1.8). )
G1 X104.2274 Y98.47 Z1.8 F1607.9381 E75.7697
( Linear move to (99.9847, 98.47, 1.8). )
G1 X99.9847 Y98.47 Z1.8 F1607.9381 E75.8964
( Linear move to (100.4826, 97.8782, 1.8). )
G1 X100.4826 Y97.8782 Z1.8 F1607.9381 E75.9195
( Linear move to (99.3259, 97.9008, 1.8). )
G1 X99.3259 Y97.9008 Z1.8 F1607.9381 E75.9541
( Linear move to (98.2878, 98.1873, 1.8). )
G1 X98.2878 Y98.1873 Z1.8 F1607.9381 E75.9863
( Linear move to (96.5645, 96.1394, 1.8). )
G1 X96.5645 Y96.1394 Z1.8 F1607.9381 E76.0662
( Linear move to (96.7113, 94.107, 1.8). )
G1 X96.7113 Y94.107 Z1.8 F1607.9381 E76.1271
( Linear move to (94.8257, 92.2214, 1.8). )
G1 X94.8257 Y92.2214 Z1.8 F1607.9381 E76.2068
( Linear move to (92.7933, 92.3682, 1.8). )
G1 X92.7933 Y92.3682 Z1.8 F1607.9381 E76.2677
( Linear move to (92.13, 89.1668, 1.8). )
G1 X92.13 Y89.1668 Z1.8 F1607.9381 E76.3653
( Linear move to (91.53, 90.0153, 1.8). )
G1 X91.53 Y90.0153 Z1.8 F1607.9381 E76.3964
( Linear move to (91.53, 92.5609, 1.8). )
G1 X91.53 Y92.5609 Z1.8 F1607.9381 E76.4724
( Linear move to (92.4687, 92.6928, 1.8). )
G1 X92.4687 Y92.6928 Z1.8 F1607.9381 E76.5007
( Linear move to (91.53, 93.4094, 1.8). )
G1 X91.53 Y93.4094 Z1.8 F1607.9381 E76.536
( Linear move to (91.53, 95.1065, 1.8). )
G1 X91.53 Y95.1065 Z1.8 F1607.9381 E76.5867
( Linear move to (92.1596, 94.8875, 1.8). )
G1 X92.1596 Y94.8875 Z1.8 F1607.9381 E76.6066
( Linear move to (94.2075, 96.6108, 1.8). )
G1 X94.2075 Y96.6108 Z1.8 F1607.9381 E76.6866
( Linear move to (96.2399, 96.464, 1.8). )
G1 X96.2399 Y96.464 Z1.8 F1607.9381 E76.7475
( Linear move to (97.4391, 98.47, 1.8). )
G1 X97.4391 Y98.47 Z1.8 F1607.9381 E76.8173
( Linear move to (94.045, 98.47, 1.8). )
G1 X94.045 Y98.47 Z1.8 F1607.9381 E76.9187
( Linear move to (93.8829, 96.9354, 1.8). )
G1 X93.8829 Y96.9354 Z1.8 F1607.9381 E76.9648
( Linear move to (91.53, 95.955, 1.8). )
G1 X91.53 Y95.955 Z1.8 F1607.9381 E77.0409
( Linear move to (91.53, 97.652, 1.8). )
G1 X91.53 Y97.652 Z1.8 F1607.9381 E77.0916
( Linear move to (92.348, 98.47, 1.8). )
G1 X92.348 Y98.47 Z1.8 F1607.9381 E77.1262
( Linear move to (93.1965, 98.47, 1.8). )
G1 X93.1965 Y98.47 Z1.8 F1607.9381 E77.1515
( Linear move to (93.1965, 98.47, 1.8). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 1.8). )
G1 E76.1515
( Linear move to (93.1965, 98.47, 1.8). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 2.2 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z2.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z2.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z2.2 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z2.2 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 2.2). )
G1 X90.36 Y80.36 Z2.2 F2750.2729
( Linear move to (90.36, 80.36, 2.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 2.2). )
G1 E77.1515
( Linear move to (90.36, 80.36, 2.2). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 2.2). )
G1 X109.64 Y80.36 Z2.2 F1025.5987 E77.7278
( Linear move to (109.64, 99.64, 2.2). )
G1 X109.64 Y99.64 Z2.2 F1025.5987 E78.3041
( Linear move to (90.36, 99.64, 2.2). )
G1 X90.36 Y99.64 Z2.2 F1025.5987 E78.8804
( Linear move to (90.36, 80.36, 2.2). )
G1 X90.36 Y80.36 Z2.2 F1025.5987 E79.4567
( Linear move to (90.36, 80.36, 2.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 2.2). )
G1 E79.4567
( Linear move to (90.36, 80.36, 2.2). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 2.2). )
G1 X91.02 Y81.02 Z2.2 F6000.0
( Linear move to (91.02, 81.02, 2.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 2.2). )
G1 E79.4567
( Linear move to (91.02, 81.02, 2.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 2.2). )
G1 X108.98 Y81.02 Z2.2 F1367.465 E79.9932
( Linear move to (108.98, 98.98, 2.2). )
G1 X108.98 Y98.98 Z2.2 F1367.465 E80.5297
( Linear move to (91.02, 98.98, 2.2). )
G1 X91.02 Y98.98 Z2.2 F1367.465 E81.0662
( Linear move to (91.02, 81.02, 2.2). )
G1 X91.02 Y81.02 Z2.2 F1367.465 E81.6027
( Linear move to (91.02, 81.02, 2.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 2.2). )
G1 E80.6027
( Linear move to (91.02, 81.02, 2.2). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z2.0 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z2.0 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z2.0 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z2.0 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 2.2). )
G1 X91.53 Y93.6315 Z2.2 F6000.0
( Linear move to (91.53, 93.6315, 2.2). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 2.2). )
G1 E81.6027
( Linear move to (91.53, 93.6315, 2.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 2.2). )
G1 X91.53 Y87.6918 Z2.2 F1367.465 E81.7802
( Linear move to (93.3935, 87.9968, 2.2). )
G1 X93.3935 Y87.9968 Z2.2 F1367.465 E81.8366
( Linear move to (93.7541, 87.6361, 2.2). )
G1 X93.7541 Y87.6361 Z2.2 F1367.465 E81.8518
( Linear move to (93.8649, 85.6397, 2.2). )
G1 X93.8649 Y85.6397 Z2.2 F1367.465 E81.9115
( Linear move to (94.2255, 85.2791, 2.2). )
G1 X94.2255 Y85.2791 Z2.2 F1367.465 E81.9268
( Linear move to (96.2219, 85.1683, 2.2). )
G1 X96.2219 Y85.1683 Z2.2 F1367.465 E81.9865
( Linear move to (96.5825, 84.8077, 2.2). )
G1 X96.5825 Y84.8077 Z2.2 F1367.465 E82.0017
( Linear move to (103.6315, 82.13, 2.2). )
G1 X103.6315 Y82.13 Z2.2 F1367.465 E82.227
( Linear move to (104.48, 81.53, 2.2). )
G1 X104.48 Y81.53 Z2.2 F1367.465 E82.258
( Linear move to (93.4491, 81.53, 2.2). )
G1 X93.4491 Y81.53 Z2.2 F1367.465 E82.5876
( Linear move to (93.4491, 82.13, 2.2). )
G1 X93.4491 Y82.13 Z2.2 F1367.465 E82.6055
( Linear move to (92.13, 86.8432, 2.2). )
G1 X92.13 Y86.8432 Z2.2 F1367.465 E82.7517
( Linear move to (91.53, 85.9947, 2.2). )
G1 X91.53 Y85.9947 Z2.2 F1367.465 E82.7827
( Linear move to (91.53, 82.6006, 2.2). )
G1 X91.53 Y82.6006 Z2.2 F1367.465 E82.8841
( Linear move to (92.6006, 81.53, 2.2). )
G1 X92.6006 Y81.53 Z2.2 F1367.465 E82.9293
( Linear move to (92.6006, 81.53, 2.2). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 2.2). )
G1 E81.9293
( Linear move to (92.6006, 81.53, 2.2). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 2.2). )
G1 X108.47 Y97.0561 Z2.2 F6000.0
( Linear move to (108.47, 97.0561, 2.2). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 2.2). )
G1 E82.9293
( Linear move to (108.47, 97.0561, 2.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 2.2). )
G1 X108.47 Y97.9047 Z2.2 F1367.465 E82.9547
( Linear move to (107.9047, 98.47, 2.2). )
G1 X107.9047 Y98.47 Z2.2 F1367.465 E82.9786
( Linear move to (105.3591, 98.47, 2.2). )
G1 X105.3591 Y98.47 Z2.2 F1367.465 E83.0546
( Linear move to (105.1786, 96.9534, 2.2). )
G1 X105.1786 Y96.9534 Z2.2 F1367.465 E83.1002
( Linear move to (105.5392, 96.5928, 2.2). )
G1 X105.5392 Y96.5928 Z2.2 F1367.465 E83.1155
( Linear move to (108.47, 96.2076, 2.2). )
G1 X108.47 Y96.2076 Z2.2 F1367.465 E83.2038
( Linear move to (108.47, 89.4194, 2.2). )
G1 X108.47 Y89.4194 Z2.2 F1367.465 E83.4066
( Linear move to (106.9534, 89.5217, 2.2). )
G1 X106.9534 Y89.5217 Z2.2 F1367.465 E83.452
( Linear move to (106.5928, 89.8824, 2.2). )
G1 X106.5928 Y89.8824 Z2.2 F1367.465 E83.4672
( Linear move to (106.482, 91.8788, 2.2). )
G1 X106.482 Y91.8788 Z2.2 F1367.465 E83.5269
( Linear move to (106.1214, 92.2394, 2.2). )
G1 X106.1214 Y92.2394 Z2.2 F1367.465 E83.5422
( Linear move to (104.125, 92.3502, 2.2). )
G1 X104.125 Y92.3502 Z2.2 F1367.465 E83.6019
( Linear move to (103.7644, 92.7108, 2.2). )
G1 X103.7644 Y92.7108 Z2.2 F1367.465 E83.6171
( Linear move to (103.6536, 94.7072, 2.2). )
G1 X103.6536 Y94.7072 Z2.2 F1367.465 E83.6769
( Linear move to (103.293, 95.0678, 2.2). )
G1 X103.293 Y95.0678 Z2.2 F1367.465 E83.6921
( Linear move to (101.2966, 95.1786, 2.2). )
G1 X101.2966 Y95.1786 Z2.2 F1367.465 E83.7518
( Linear move to (100.936, 95.5392, 2.2). )
G1 X100.936 Y95.5392 Z2.2 F1367.465 E83.7671
( Linear move to (100.6449, 97.7159, 2.2). )
G1 X100.6449 Y97.7159 Z2.2 F1367.465 E83.8327
( Linear move to (104.5106, 97.87, 2.2). )
G1 X104.5106 Y97.87 Z2.2 F1367.465 E83.9482
( Linear move to (103.662, 98.47, 2.2). )
G1 X103.662 Y98.47 Z2.2 F1367.465 E83.9793
( Linear move to (98.5709, 98.47, 2.2). )
G1 X98.5709 Y98.47 Z2.2 F1367.465 E84.1314
( Linear move to (98.4682, 98.007, 2.2). )
G1 X98.4682 Y98.007 Z2.2 F1367.465 E84.1455
( Linear move to (98.1075, 98.3676, 2.2). )
G1 X98.1075 Y98.3676 Z2.2 F1367.465 E84.1608
( Linear move to (97.7223, 98.47, 2.2). )
G1 X97.7223 Y98.47 Z2.2 F1367.465 E84.1727
( Linear move to (94.3282, 98.47, 2.2). )
G1 X94.3282 Y98.47 Z2.2 F1367.465 E84.2741
( Linear move to (93.8649, 96.9534, 2.2). )
G1 X93.8649 Y96.9534 Z2.2 F1367.465 E84.3214
( Linear move to (94.2255, 96.5928, 2.2). )
G1 X94.2255 Y96.5928 Z2.2 F1367.465 E84.3367
( Linear move to (96.2219, 96.482, 2.2). )
G1 X96.2219 Y96.482 Z2.2 F1367.465 E84.3964
( Linear move to (96.5825, 96.1214, 2.2). )
G1 X96.5825 Y96.1214 Z2.2 F1367.465 E84.4116
( Linear move to (96.6933, 94.125, 2.2). )
G1 X96.6933 Y94.125 Z2.2 F1367.465 E84.4714
( Linear move to (97.0539, 93.7644, 2.2). )
G1 X97.0539 Y93.7644 Z2.2 F1367.465 E84.4866
( Linear move to (99.0503, 93.6536, 2.2). )
G1 X99.0503 Y93.6536 Z2.2 F1367.465 E84.5463
( Linear move to (99.411, 93.293, 2.2). )
G1 X99.411 Y93.293 Z2.2 F1367.465 E84.5616
( Linear move to (99.5217, 91.2966, 2.2). )
G1 X99.5217 Y91.2966 Z2.2 F1367.465 E84.6213
( Linear move to (99.8824, 90.936, 2.2). )
G1 X99.8824 Y90.936 Z2.2 F1367.465 E84.6365
( Linear move to (101.8788, 90.8252, 2.2). )
G1 X101.8788 Y90.8252 Z2.2 F1367.465 E84.6963
( Linear move to (102.2394, 90.4646, 2.2). )
G1 X102.2394 Y90.4646 Z2.2 F1367.465 E84.7115
( Linear move to (102.3502, 88.4682, 2.2). )
G1 X102.3502 Y88.4682 Z2.2 F1367.465 E84.7712
( Linear move to (102.7108, 88.1075, 2.2). )
G1 X102.7108 Y88.1075 Z2.2 F1367.465 E84.7865
( Linear move to (104.7072, 87.9968, 2.2). )
G1 X104.7072 Y87.9968 Z2.2 F1367.465 E84.8462
( Linear move to (105.0678, 87.6361, 2.2). )
G1 X105.0678 Y87.6361 Z2.2 F1367.465 E84.8614
( Linear move to (105.1786, 85.6397, 2.2). )
G1 X105.1786 Y85.6397 Z2.2 F1367.465 E84.9211
( Linear move to (105.5392, 85.2791, 2.2). )
G1 X105.5392 Y85.2791 Z2.2 F1367.465 E84.9364
( Linear move to (108.47, 88.5709, 2.2). )
G1 X108.47 Y88.5709 Z2.2 F1367.465 E85.068
( Linear move to (108.3887, 81.8639, 2.2). )
G1 X108.3887 Y81.8639 Z2.2 F1367.465 E85.2684
( Linear move to (107.8741, 81.53, 2.2). )
G1 X107.8741 Y81.53 Z2.2 F1367.465 E85.2867
( Linear move to (106.1771, 81.53, 2.2). )
G1 X106.1771 Y81.53 Z2.2 F1367.465 E85.3374
( Linear move to (103.293, 83.7541, 2.2). )
G1 X103.293 Y83.7541 Z2.2 F1367.465 E85.4462
( Linear move to (101.2966, 83.8649, 2.2). )
G1 X101.2966 Y83.8649 Z2.2 F1367.465 E85.506
( Linear move to (100.936, 84.2255, 2.2). )
G1 X100.936 Y84.2255 Z2.2 F1367.465 E85.5212
( Linear move to (100.8252, 86.2219, 2.2). )
G1 X100.8252 Y86.2219 Z2.2 F1367.465 E85.5809
( Linear move to (100.4646, 86.5825, 2.2). )
G1 X100.4646 Y86.5825 Z2.2 F1367.465 E85.5962
( Linear move to (98.4682, 86.6933, 2.2). )
G1 X98.4682 Y86.6933 Z2.2 F1367.465 E85.6559
( Linear move to (98.1075, 87.0539, 2.2). )
G1 X98.1075 Y87.0539 Z2.2 F1367.465 E85.6711
( Linear move to (97.9968, 89.0503, 2.2). )
G1 X97.9968 Y89.0503 Z2.2 F1367.465 E85.7308
( Linear move to (97.6361, 89.411, 2.2). )
G1 X97.6361 Y89.411 Z2.2 F1367.465 E85.7461
( Linear move to (95.6397, 89.5217, 2.2). )
G1 X95.6397 Y89.5217 Z2.2 F1367.465 E85.8058
( Linear move to (95.2791, 89.8824, 2.2). )
G1 X95.2791 Y89.8824 Z2.2 F1367.465 E85.8211
( Linear move to (95.1683, 91.8788, 2.2). )
G1 X95.1683 Y91.8788 Z2.2 F1367.465 E85.8808
( Linear move to (94.8077, 92.2394, 2.2). )
G1 X94.8077 Y92.2394 Z2.2 F1367.465 E85.896
( Linear move to (92.8113, 92.3502, 2.2). )
G1 X92.8113 Y92.3502 Z2.2 F1367.465 E85.9557
( Linear move to (92.4507, 92.7108, 2.2). )
G1 X92.4507 Y92.7108 Z2.2 F1367.465 E85.971
( Linear move to (91.53, 94.48, 2.2). )
G1 X91.53 Y94.48 Z2.2 F1367.465 E86.0306
( Linear move to (92.3399, 94.7072, 2.2). )
G1 X92.3399 Y94.7072 Z2.2 F1367.465 E86.0557
( Linear move to (91.9793, 95.0678, 2.2). )
G1 X91.9793 Y95.0678 Z2.2 F1367.465 E86.0709
( Linear move to (91.53, 95.3285, 2.2). )
G1 X91.53 Y95.3285 Z2.2 F1367.465 E86.0864
( Linear move to (91.53, 97.8741, 2.2). )
G1 X91.53 Y97.8741 Z2.2 F1367.465 E86.1625
( Linear move to (91.8639, 98.3887, 2.2). )
G1 X91.8639 Y98.3887 Z2.2 F1367.465 E86.1808
( Linear move to (93.4797, 98.47, 2.2). )
G1 X93.4797 Y98.47 Z2.2 F1367.465 E86.2291
( Linear move to (93.4797, 98.47, 2.2). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 2.2). )
G1 E85.2291
( Linear move to (93.4797, 98.47, 2.2). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 2.6 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z2.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z2.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z2.6 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z2.6 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 2.6). )
G1 X90.36 Y80.36 Z2.6 F2757.1641
( Linear move to (90.36, 80.36, 2.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 2.6). )
G1 E86.2291
( Linear move to (90.36, 80.36, 2.6). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 2.6). )
G1 X109.64 Y80.36 Z2.6 F1205.9536 E86.8052
( Linear move to (109.64, 99.64, 2.6). )
G1 X109.64 Y99.64 Z2.6 F1205.9536 E87.3813
( Linear move to (90.36, 99.64, 2.6). )
G1 X90.36 Y99.64 Z2.6 F1205.9536 E87.9574
( Linear move to (90.36, 80.36, 2.6). )
G1 X90.36 Y80.36 Z2.6 F1205.9536 E88.5335
( Linear move to (90.36, 80.36, 2.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 2.6). )
G1 E88.5335
( Linear move to (90.36, 80.36, 2.6). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 2.6). )
G1 X91.02 Y81.02 Z2.6 F6000.0
( Linear move to (91.02, 81.02, 2.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 2.6). )
G1 E88.5335
( Linear move to (91.02, 81.02, 2.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 2.6). )
G1 X108.98 Y81.02 Z2.6 F1607.9381 E89.07
( Linear move to (108.98, 98.98, 2.6). )
G1 X108.98 Y98.98 Z2.6 F1607.9381 E89.6066
( Linear move to (91.02, 98.98, 2.6). )
G1 X91.02 Y98.98 Z2.6 F1607.9381 E90.1431
( Linear move to (91.02, 81.02, 2.6). )
G1 X91.02 Y81.02 Z2.6 F1607.9381 E90.6797
( Linear move to (91.02, 81.02, 2.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 2.6). )
G1 E90.2286
( Linear move to (91.02, 81.02, 2.6). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z2.4 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z2.4 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z2.4 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z2.4 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 2.6). )
G1 X92.3785 Y81.53 Z2.6 F6000.0
( Linear move to (92.3785, 81.53, 2.6). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 2.6). )
G1 E90.6797
( Linear move to (92.3785, 81.53, 2.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 2.6). )
G1 X91.7376 Y81.7376 Z2.6 F1607.9381 E90.6998
( Linear move to (91.53, 82.3785, 2.6). )
G1 X91.53 Y82.3785 Z2.6 F1607.9381 E90.7199
( Linear move to (92.3219, 83.4115, 2.6). )
G1 X92.3219 Y83.4115 Z2.6 F1607.9381 E90.7588
( Linear move to (94.2075, 85.2971, 2.6). )
G1 X94.2075 Y85.2971 Z2.6 F1607.9381 E90.8385
( Linear move to (96.2399, 85.1503, 2.6). )
G1 X96.2399 Y85.1503 Z2.6 F1607.9381 E90.8993
( Linear move to (98.1256, 87.0359, 2.6). )
G1 X98.1256 Y87.0359 Z2.6 F1607.9381 E90.979
( Linear move to (97.9787, 89.0684, 2.6). )
G1 X97.9787 Y89.0684 Z2.6 F1607.9381 E91.0399
( Linear move to (99.8643, 90.954, 2.6). )
G1 X99.8643 Y90.954 Z2.6 F1607.9381 E91.1196
( Linear move to (101.8968, 90.8071, 2.6). )
G1 X101.8968 Y90.8071 Z2.6 F1607.9381 E91.1804
( Linear move to (103.7824, 92.6928, 2.6). )
G1 X103.7824 Y92.6928 Z2.6 F1607.9381 E91.2601
( Linear move to (103.6356, 94.7252, 2.6). )
G1 X103.6356 Y94.7252 Z2.6 F1607.9381 E91.321
( Linear move to (107.6215, 98.47, 2.6). )
G1 X107.6215 Y98.47 Z2.6 F1607.9381 E91.4844
( Linear move to (108.2624, 98.2624, 2.6). )
G1 X108.2624 Y98.2624 Z2.6 F1607.9381 E91.5045
( Linear move to (108.47, 97.6215, 2.6). )
G1 X108.47 Y97.6215 Z2.6 F1607.9381 E91.5246
( Linear move to (108.47, 93.3788, 2.6). )
G1 X108.47 Y93.3788 Z2.6 F1607.9381 E91.6514
( Linear move to (106.1394, 92.2214, 2.6). )
G1 X106.1394 Y92.2214 Z2.6 F1607.9381 E91.7291
( Linear move to (104.107, 92.3682, 2.6). )
G1 X104.107 Y92.3682 Z2.6 F1607.9381 E91.79
( Linear move to (102.2214, 90.4826, 2.6). )
G1 X102.2214 Y90.4826 Z2.6 F1607.9381 E91.8697
( Linear move to (102.3682, 88.4501, 2.6). )
G1 X102.3682 Y88.4501 Z2.6 F1607.9381 E91.9305
( Linear move to (100.4826, 86.5645, 2.6). )
G1 X100.4826 Y86.5645 Z2.6 F1607.9381 E92.0102
( Linear move to (98.4501, 86.7113, 2.6). )
G1 X98.4501 Y86.7113 Z2.6 F1607.9381 E92.0711
( Linear move to (93.2271, 81.53, 2.6). )
G1 X93.2271 Y81.53 Z2.6 F1607.9381 E92.2909
( Linear move to (97.4697, 81.53, 2.6). )
G1 X97.4697 Y81.53 Z2.6 F1607.9381 E92.4176
( Linear move to (96.8736, 82.631, 2.6). )
G1 X96.8736 Y82.631 Z2.6 F1607.9381 E92.455
( Linear move to (98.6819, 82.0072, 2.6). )
G1 X98.6819 Y82.0072 Z2.6 F1607.9381 E92.5122
( Linear move to (99.1668, 81.53, 2.6). )
G1 X99.1668 Y81.53 Z2.6 F1607.9381 E92.5325
( Linear move to (100.954, 84.2075, 2.6). )
G1 X100.954 Y84.2075 Z2.6 F1607.9381 E92.6287
( Linear move to (100.8071, 86.2399, 2.6). )
G1 X100.8071 Y86.2399 Z2.6 F1607.9381 E92.6895
( Linear move to (102.6928, 88.1256, 2.6). )
G1 X102.6928 Y88.1256 Z2.6 F1607.9381 E92.7692
( Linear move to (104.7252, 87.9787, 2.6). )
G1 X104.7252 Y87.9787 Z2.6 F1607.9381 E92.8301
( Linear move to (106.6108, 89.8643, 2.6). )
G1 X106.6108 Y89.8643 Z2.6 F1607.9381 E92.9097
( Linear move to (106.464, 91.8968, 2.6). )
G1 X106.464 Y91.8968 Z2.6 F1607.9381 E92.9706
( Linear move to (108.47, 92.5303, 2.6). )
G1 X108.47 Y92.5303 Z2.6 F1607.9381 E93.0335
( Linear move to (108.47, 88.2877, 2.6). )
G1 X108.47 Y88.2877 Z2.6 F1607.9381 E93.1602
( Linear move to (106.9354, 89.5398, 2.6). )
G1 X106.9354 Y89.5398 Z2.6 F1607.9381 E93.2194
( Linear move to (105.0498, 87.6542, 2.6). )
G1 X105.0498 Y87.6542 Z2.6 F1607.9381 E93.2991
( Linear move to (105.1966, 85.6217, 2.6). )
G1 X105.1966 Y85.6217 Z2.6 F1607.9381 E93.3599
( Linear move to (103.311, 83.7361, 2.6). )
G1 X103.311 Y83.7361 Z2.6 F1607.9381 E93.4396
( Linear move to (101.2786, 83.8829, 2.6). )
G1 X101.2786 Y83.8829 Z2.6 F1607.9381 E93.5005
( Linear move to (100.0153, 81.53, 2.6). )
G1 X100.0153 Y81.53 Z2.6 F1607.9381 E93.5803
( Linear move to (105.1065, 81.53, 2.6). )
G1 X105.1065 Y81.53 Z2.6 F1607.9381 E93.7324
( Linear move to (103.6356, 83.4115, 2.6). )
G1 X103.6356 Y83.4115 Z2.6 F1607.9381 E93.8037
( Linear move to (105.5212, 85.2971, 2.6). )
G1 X105.5212 Y85.2971 Z2.6 F1607.9381 E93.8834
( Linear move to (108.47, 87.4391, 2.6). )
G1 X108.47 Y87.4391 Z2.6 F1607.9381 E93.9922
( Linear move to (108.47, 83.1965, 2.6). )
G1 X108.47 Y83.1965 Z2.6 F1607.9381 E94.119
( Linear move to (105.955, 81.53, 2.6). )
G1 X105.955 Y81.53 Z2.6 F1607.9381 E94.2091
( Linear move to (107.652, 81.53, 2.6). )
G1 X107.652 Y81.53 Z2.6 F1607.9381 E94.2598
( Linear move to (108.47, 82.348, 2.6). )
G1 X108.47 Y82.348 Z2.6 F1607.9381 E94.2944
( Linear move to (108.47, 82.348, 2.6). )
G1 F1200.0
( Linear move to (108.47, 82.348, 2.6). )
G1 E93.2944
( Linear move to (108.47, 82.348, 2.6). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 2.6). )
G1 X106.7729 Y98.47 Z2.6 F6000.0
( Linear move to (106.7729, 98.47, 2.6). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 2.6). )
G1 E94.2944
( Linear move to (106.7729, 98.47, 2.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 2.6). )
G1 X105.0759 Y98.47 Z2.6 F1607.9381 E94.3451
( Linear move to (105.1966, 96.9354, 2.6). )
G1 X105.1966 Y96.9354 Z2.6 F1607.9381 E94.3911
( Linear move to (103.311, 95.0498, 2.6). )
G1 X103.311 Y95.0498 Z2.6 F1607.9381 E94.4707
( Linear move to (101.2786, 95.1966, 2.6). )
G1 X101.2786 Y95.1966 Z2.6 F1607.9381 E94.5316
( Linear move to (99.3929, 93.311, 2.6). )
G1 X99.3929 Y93.311 Z2.6 F1607.9381 E94.6113
( Linear move to (99.5398, 91.2786, 2.6). )
G1 X99.5398 Y91.2786 Z2.6 F1607.9381 E94.6722
( Linear move to (97.6542, 89.3929, 2.6). )
G1 X97.6542 Y89.3929 Z2.6 F1607.9381 E94.7518
( Linear move to (95.6217, 89.5398, 2.6). )
G1 X95.6217 Y89.5398 Z2.6 F1607.9381 E94.8127
( Linear move to (93.7361, 87.6542, 2.6). )
G1 X93.7361 Y87.6542 Z2.6 F1607.9381 E94.8924
( Linear move to (93.8829, 85.6217, 2.6). )
G1 X93.8829 Y85.6217 Z2.6 F1607.9381 E94.9532
( Linear move to (91.53, 83.2271, 2.6). )
G1 X91.53 Y83.2271 Z2.6 F1607.9381 E95.0535
( Linear move to (91.53, 88.3182, 2.6). )
G1 X91.53 Y88.3182 Z2.6 F1607.9381 E95.2056
( Linear move to (93.4115, 87.9787, 2.6). )
G1 X93.4115 Y87.9787 Z2.6 F1607.9381 E95.2628
( Linear move to (95.2971, 89.8643, 2.6). )
G1 X95.2971 Y89.8643 Z2.6 F1607.9381 E95.3424
( Linear move to (95.1503, 91.8968, 2.6). )
G1 X95.1503 Y91.8968 Z2.6 F1607.9381 E95.4033
( Linear move to (97.0359, 93.7824, 2.6). )
G1 X97.0359 Y93.7824 Z2.6 F1607.9381 E95.483
( Linear move to (99.0684, 93.6356, 2.6). )
G1 X99.0684 Y93.6356 Z2.6 F1607.9381 E95.5438
( Linear move to (100.954, 95.5212, 2.6). )
G1 X100.954 Y95.5212 Z2.6 F1607.9381 E95.6235
( Linear move to (100.8071, 97.5537, 2.6). )
G1 X100.8071 Y97.5537 Z2.6 F1607.9381 E95.6844
( Linear move to (103.3788, 97.87, 2.6). )
G1 X103.3788 Y97.87 Z2.6 F1607.9381 E95.7618
( Linear move to (104.2274, 98.47, 2.6). )
G1 X104.2274 Y98.47 Z2.6 F1607.9381 E95.7928
( Linear move to (99.9847, 98.47, 2.6). )
G1 X99.9847 Y98.47 Z2.6 F1607.9381 E95.9196
( Linear move to (100.4826, 97.8782, 2.6). )
G1 X100.4826 Y97.8782 Z2.6 F1607.9381 E95.9427
( Linear move to (99.3259, 97.9008, 2.6). )
G1 X99.3259 Y97.9008 Z2.6 F1607.9381 E95.9773
( Linear move to (98.2878, 98.1873, 2.6). )
G1 X98.2878 Y98.1873 Z2.6 F1607.9381 E96.0094
( Linear move to (96.5645, 96.1394, 2.6). )
G1 X96.5645 Y96.1394 Z2.6 F1607.9381 E96.0894
( Linear move to (96.7113, 94.107, 2.6). )
G1 X96.7113 Y94.107 Z2.6 F1607.9381 E96.1503
( Linear move to (94.8257, 92.2214, 2.6). )
G1 X94.8257 Y92.2214 Z2.6 F1607.9381 E96.2299
( Linear move to (92.7933, 92.3682, 2.6). )
G1 X92.7933 Y92.3682 Z2.6 F1607.9381 E96.2908
( Linear move to (92.13, 89.1668, 2.6). )
G1 X92.13 Y89.1668 Z2.6 F1607.9381 E96.3885
( Linear move to (91.53, 90.0153, 2.6). )
G1 X91.53 Y90.0153 Z2.6 F1607.9381 E96.4195
( Linear move to (91.53, 92.5609, 2.6). )
G1 X91.53 Y92.5609 Z2.6 F1607.9381 E96.4956
( Linear move to (92.4687, 92.6928, 2.6). )
G1 X92.4687 Y92.6928 Z2.6 F1607.9381 E96.5239
( Linear move to (91.53, 93.4094, 2.6). )
G1 X91.53 Y93.4094 Z2.6 F1607.9381 E96.5592
( Linear move to (91.53, 95.1065, 2.6). )
G1 X91.53 Y95.1065 Z2.6 F1607.9381 E96.6099
( Linear move to (92.1596, 94.8875, 2.6). )
G1 X92.1596 Y94.8875 Z2.6 F1607.9381 E96.6298
( Linear move to (94.2075, 96.6108, 2.6). )
G1 X94.2075 Y96.6108 Z2.6 F1607.9381 E96.7097
( Linear move to (96.2399, 96.464, 2.6). )
G1 X96.2399 Y96.464 Z2.6 F1607.9381 E96.7706
( Linear move to (97.4391, 98.47, 2.6). )
G1 X97.4391 Y98.47 Z2.6 F1607.9381 E96.8404
( Linear move to (94.045, 98.47, 2.6). )
G1 X94.045 Y98.47 Z2.6 F1607.9381 E96.9418
( Linear move to (93.8829, 96.9354, 2.6). )
G1 X93.8829 Y96.9354 Z2.6 F1607.9381 E96.9879
( Linear move to (91.53, 95.955, 2.6). )
G1 X91.53 Y95.955 Z2.6 F1607.9381 E97.0641
( Linear move to (91.53, 97.652, 2.6). )
G1 X91.53 Y97.652 Z2.6 F1607.9381 E97.1148
( Linear move to (92.348, 98.47, 2.6). )
G1 X92.348 Y98.47 Z2.6 F1607.9381 E97.1494
( Linear move to (93.1965, 98.47, 2.6). )
G1 X93.1965 Y98.47 Z2.6 F1607.9381 E97.1747
( Linear move to (93.1965, 98.47, 2.6). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 2.6). )
G1 E96.1747
( Linear move to (93.1965, 98.47, 2.6). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 3.0 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z3.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z3.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z3.0 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z3.0 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 3.0). )
G1 X90.36 Y80.36 Z3.0 F2750.2729
( Linear move to (90.36, 80.36, 3.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.0). )
G1 E97.1747
( Linear move to (90.36, 80.36, 3.0). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 3.0). )
G1 X109.64 Y80.36 Z3.0 F1025.5987 E97.751
( Linear move to (109.64, 99.64, 3.0). )
G1 X109.64 Y99.64 Z3.0 F1025.5987 E98.3273
( Linear move to (90.36, 99.64, 3.0). )
G1 X90.36 Y99.64 Z3.0 F1025.5987 E98.9036
( Linear move to (90.36, 80.36, 3.0). )
G1 X90.36 Y80.36 Z3.0 F1025.5987 E99.4798
( Linear move to (90.36, 80.36, 3.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.0). )
G1 E99.4798
( Linear move to (90.36, 80.36, 3.0). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 3.0). )
G1 X91.02 Y81.02 Z3.0 F6000.0
( Linear move to (91.02, 81.02, 3.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.0). )
G1 E99.4798
( Linear move to (91.02, 81.02, 3.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 3.0). )
G1 X108.98 Y81.02 Z3.0 F1367.465 E100.0164
( Linear move to (108.98, 98.98, 3.0). )
G1 X108.98 Y98.98 Z3.0 F1367.465 E100.5529
( Linear move to (91.02, 98.98, 3.0). )
G1 X91.02 Y98.98 Z3.0 F1367.465 E101.0894
( Linear move to (91.02, 81.02, 3.0). )
G1 X91.02 Y81.02 Z3.0 F1367.465 E101.6259
( Linear move to (91.02, 81.02, 3.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.0). )
G1 E100.6259
( Linear move to (91.02, 81.02, 3.0). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z2.8 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z2.8 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z2.8 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z2.8 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 3.0). )
G1 X91.53 Y93.6315 Z3.0 F6000.0
( Linear move to (91.53, 93.6315, 3.0). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 3.0). )
G1 E101.6259
( Linear move to (91.53, 93.6315, 3.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 3.0). )
G1 X91.53 Y87.6918 Z3.0 F1367.465 E101.8033
( Linear move to (93.3935, 87.9968, 3.0). )
G1 X93.3935 Y87.9968 Z3.0 F1367.465 E101.8597
( Linear move to (93.7541, 87.6361, 3.0). )
G1 X93.7541 Y87.6361 Z3.0 F1367.465 E101.875
( Linear move to (93.8649, 85.6397, 3.0). )
G1 X93.8649 Y85.6397 Z3.0 F1367.465 E101.9347
( Linear move to (94.2255, 85.2791, 3.0). )
G1 X94.2255 Y85.2791 Z3.0 F1367.465 E101.9499
( Linear move to (96.2219, 85.1683, 3.0). )
G1 X96.2219 Y85.1683 Z3.0 F1367.465 E102.0097
( Linear move to (96.5825, 84.8077, 3.0). )
G1 X96.5825 Y84.8077 Z3.0 F1367.465 E102.0249
( Linear move to (103.6315, 82.13, 3.0). )
G1 X103.6315 Y82.13 Z3.0 F1367.465 E102.2501
( Linear move to (104.48, 81.53, 3.0). )
G1 X104.48 Y81.53 Z3.0 F1367.465 E102.2812
( Linear move to (93.4491, 81.53, 3.0). )
G1 X93.4491 Y81.53 Z3.0 F1367.465 E102.6107
( Linear move to (93.4491, 82.13, 3.0). )
G1 X93.4491 Y82.13 Z3.0 F1367.465 E102.6286
( Linear move to (92.13, 86.8432, 3.0). )
G1 X92.13 Y86.8432 Z3.0 F1367.465 E102.7748
( Linear move to (91.53, 85.9947, 3.0). )
G1 X91.53 Y85.9947 Z3.0 F1367.465 E102.8059
( Linear move to (91.53, 82.6006, 3.0). )
G1 X91.53 Y82.6006 Z3.0 F1367.465 E102.9073
( Linear move to (92.6006, 81.53, 3.0). )
G1 X92.6006 Y81.53 Z3.0 F1367.465 E102.9525
( Linear move to (92.6006, 81.53, 3.0). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 3.0). )
G1 E101.9525
( Linear move to (92.6006, 81.53, 3.0). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 3.0). )
G1 X108.47 Y97.0561 Z3.0 F6000.0
( Linear move to (108.47, 97.0561, 3.0). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 3.0). )
G1 E102.9525
( Linear move to (108.47, 97.0561, 3.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 3.0). )
G1 X108.47 Y97.9047 Z3.0 F1367.465 E102.9778
( Linear move to (107.9047, 98.47, 3.0). )
G1 X107.9047 Y98.47 Z3.0 F1367.465 E103.0017
( Linear move to (105.3591, 98.47, 3.0). )
G1 X105.3591 Y98.47 Z3.0 F1367.465 E103.0778
( Linear move to (105.1786, 96.9534, 3.0). )
G1 X105.1786 Y96.9534 Z3.0 F1367.465 E103.1234
( Linear move to (105.5392, 96.5928, 3.0). )
G1 X105.5392 Y96.5928 Z3.0 F1367.465 E103.1386
( Linear move to (108.47, 96.2076, 3.0). )
G1 X108.47 Y96.2076 Z3.0 F1367.465 E103.2269
( Linear move to (108.47, 89.4194, 3.0). )
G1 X108.47 Y89.4194 Z3.0 F1367.465 E103.4297
( Linear move to (106.9534, 89.5217, 3.0). )
G1 X106.9534 Y89.5217 Z3.0 F1367.465 E103.4751
( Linear move to (106.5928, 89.8824, 3.0). )
G1 X106.5928 Y89.8824 Z3.0 F1367.465 E103.4904
( Linear move to (106.482, 91.8788, 3.0). )
G1 X106.482 Y91.8788 Z3.0 F1367.465 E103.5501
( Linear move to (106.1214, 92.2394, 3.0). )
G1 X106.1214 Y92.2394 Z3.0 F1367.465 E103.5653
( Linear move to (104.125, 92.3502, 3.0). )
G1 X104.125 Y92.3502 Z3.0 F1367.465 E103.6251
( Linear move to (103.7644, 92.7108, 3.0). )
G1 X103.7644 Y92.7108 Z3.0 F1367.465 E103.6403
( Linear move to (103.6536, 94.7072, 3.0). )
G1 X103.6536 Y94.7072 Z3.0 F1367.465 E103.7
( Linear move to (103.293, 95.0678, 3.0). )
G1 X103.293 Y95.0678 Z3.0 F1367.465 E103.7152
( Linear move to (101.2966, 95.1786, 3.0). )
G1 X101.2966 Y95.1786 Z3.0 F1367.465 E103.775
( Linear move to (100.936, 95.5392, 3.0). )
G1 X100.936 Y95.5392 Z3.0 F1367.465 E103.7902
( Linear move to (100.6449, 97.7159, 3.0). )
G1 X100.6449 Y97.7159 Z3.0 F1367.465 E103.8558
( Linear move to (104.5106, 97.87, 3.0). )
G1 X104.5106 Y97.87 Z3.0 F1367.465 E103.9714
( Linear move to (103.662, 98.47, 3.0). )
G1 X103.662 Y98.47 Z3.0 F1367.465 E104.0024
( Linear move to (98.5709, 98.47, 3.0). )
G1 X98.5709 Y98.47 Z3.0 F1367.465 E104.1545
( Linear move to (98.4682, 98.007, 3.0). )
G1 X98.4682 Y98.007 Z3.0 F1367.465 E104.1687
( Linear move to (98.1075, 98.3676, 3.0). )
G1 X98.1075 Y98.3676 Z3.0 F1367.465 E104.1839
( Linear move to (97.7223, 98.47, 3.0). )
G1 X97.7223 Y98.47 Z3.0 F1367.465 E104.1958
( Linear move to (94.3282, 98.47, 3.0). )
G1 X94.3282 Y98.47 Z3.0 F1367.465 E104.2972
( Linear move to (93.8649, 96.9534, 3.0). )
G1 X93.8649 Y96.9534 Z3.0 F1367.465 E104.3446
( Linear move to (94.2255, 96.5928, 3.0). )
G1 X94.2255 Y96.5928 Z3.0 F1367.465 E104.3598
( Linear move to (96.2219, 96.482, 3.0). )
G1 X96.2219 Y96.482 Z3.0 F1367.465 E104.4195
( Linear move to (96.5825, 96.1214, 3.0). )
G1 X96.5825 Y96.1214 Z3.0 F1367.465 E104.4348
( Linear move to (96.6933, 94.125, 3.0). )
G1 X96.6933 Y94.125 Z3.0 F1367.465 E104.4945
( Linear move to (97.0539, 93.7644, 3.0). )
G1 X97.0539 Y93.7644 Z3.0 F1367.465 E104.5097
( Linear move to (99.0503, 93.6536, 3.0). )
G1 X99.0503 Y93.6536 Z3.0 F1367.465 E104.5695
( Linear move to (99.411, 93.293, 3.0). )
G1 X99.411 Y93.293 Z3.0 F1367.465 E104.5847
( Linear move to (99.5217, 91.2966, 3.0). )
G1 X99.5217 Y91.2966 Z3.0 F1367.465 E104.6444
( Linear move to (99.8824, 90.936, 3.0). )
G1 X99.8824 Y90.936 Z3.0 F1367.465 E104.6597
( Linear move to (101.8788, 90.8252, 3.0). )
G1 X101.8788 Y90.8252 Z3.0 F1367.465 E104.7194
( Linear move to (102.2394, 90.4646, 3.0). )
G1 X102.2394 Y90.4646 Z3.0 F1367.465 E104.7346
( Linear move to (102.3502, 88.4682, 3.0). )
G1 X102.3502 Y88.4682 Z3.0 F1367.465 E104.7944
( Linear move to (102.7108, 88.1075, 3.0). )
G1 X102.7108 Y88.1075 Z3.0 F1367.465 E104.8096
( Linear move to (104.7072, 87.9968, 3.0). )
G1 X104.7072 Y87.9968 Z3.0 F1367.465 E104.8693
( Linear move to (105.0678, 87.6361, 3.0). )
G1 X105.0678 Y87.6361 Z3.0 F1367.465 E104.8846
( Linear move to (105.1786, 85.6397, 3.0). )
G1 X105.1786 Y85.6397 Z3.0 F1367.465 E104.9443
( Linear move to (105.5392, 85.2791, 3.0). )
G1 X105.5392 Y85.2791 Z3.0 F1367.465 E104.9595
( Linear move to (108.47, 88.5709, 3.0). )
G1 X108.47 Y88.5709 Z3.0 F1367.465 E105.0912
( Linear move to (108.3887, 81.8639, 3.0). )
G1 X108.3887 Y81.8639 Z3.0 F1367.465 E105.2916
( Linear move to (107.8741, 81.53, 3.0). )
G1 X107.8741 Y81.53 Z3.0 F1367.465 E105.3099
( Linear move to (106.1771, 81.53, 3.0). )
G1 X106.1771 Y81.53 Z3.0 F1367.465 E105.3606
( Linear move to (103.293, 83.7541, 3.0). )
G1 X103.293 Y83.7541 Z3.0 F1367.465 E105.4694
( Linear move to (101.2966, 83.8649, 3.0). )
G1 X101.2966 Y83.8649 Z3.0 F1367.465 E105.5291
( Linear move to (100.936, 84.2255, 3.0). )
G1 X100.936 Y84.2255 Z3.0 F1367.465 E105.5443
( Linear move to (100.8252, 86.2219, 3.0). )
G1 X100.8252 Y86.2219 Z3.0 F1367.465 E105.6041
( Linear move to (100.4646, 86.5825, 3.0). )
G1 X100.4646 Y86.5825 Z3.0 F1367.465 E105.6193
( Linear move to (98.4682, 86.6933, 3.0). )
G1 X98.4682 Y86.6933 Z3.0 F1367.465 E105.679
( Linear move to (98.1075, 87.0539, 3.0). )
G1 X98.1075 Y87.0539 Z3.0 F1367.465 E105.6943
( Linear move to (97.9968, 89.0503, 3.0). )
G1 X97.9968 Y89.0503 Z3.0 F1367.465 E105.754
( Linear move to (97.6361, 89.411, 3.0). )
G1 X97.6361 Y89.411 Z3.0 F1367.465 E105.7692
( Linear move to (95.6397, 89.5217, 3.0). )
G1 X95.6397 Y89.5217 Z3.0 F1367.465 E105.829
( Linear move to (95.2791, 89.8824, 3.0). )
G1 X95.2791 Y89.8824 Z3.0 F1367.465 E105.8442
( Linear move to (95.1683, 91.8788, 3.0). )
G1 X95.1683 Y91.8788 Z3.0 F1367.465 E105.9039
( Linear move to (94.8077, 92.2394, 3.0). )
G1 X94.8077 Y92.2394 Z3.0 F1367.465 E105.9192
( Linear move to (92.8113, 92.3502, 3.0). )
G1 X92.8113 Y92.3502 Z3.0 F1367.465 E105.9789
( Linear move to (92.4507, 92.7108, 3.0). )
G1 X92.4507 Y92.7108 Z3.0 F1367.465 E105.9941
( Linear move to (91.53, 94.48, 3.0). )
G1 X91.53 Y94.48 Z3.0 F1367.465 E106.0537
( Linear move to (92.3399, 94.7072, 3.0). )
G1 X92.3399 Y94.7072 Z3.0 F1367.465 E106.0788
( Linear move to (91.9793, 95.0678, 3.0). )
G1 X91.9793 Y95.0678 Z3.0 F1367.465 E106.0941
( Linear move to (91.53, 95.3285, 3.0). )
G1 X91.53 Y95.3285 Z3.0 F1367.465 E106.1096
( Linear move to (91.53, 97.8741, 3.0). )
G1 X91.53 Y97.8741 Z3.0 F1367.465 E106.1856
( Linear move to (91.8639, 98.3887, 3.0). )
G1 X91.8639 Y98.3887 Z3.0 F1367.465 E106.204
( Linear move to (93.4797, 98.47, 3.0). )
G1 X93.4797 Y98.47 Z3.0 F1367.465 E106.2523
( Linear move to (93.4797, 98.47, 3.0). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 3.0). )
G1 E105.2523
( Linear move to (93.4797, 98.47, 3.0). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 3.4 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z3.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z3.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z3.4 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z3.4 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 3.4). )
G1 X90.36 Y80.36 Z3.4 F2757.1641
( Linear move to (90.36, 80.36, 3.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.4). )
G1 E106.2523
( Linear move to (90.36, 80.36, 3.4). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 3.4). )
G1 X109.64 Y80.36 Z3.4 F1205.9536 E106.8284
( Linear move to (109.64, 99.64, 3.4). )
G1 X109.64 Y99.64 Z3.4 F1205.9536 E107.4045
( Linear move to (90.36, 99.64, 3.4). )
G1 X90.36 Y99.64 Z3.4 F1205.9536 E107.9805
( Linear move to (90.36, 80.36, 3.4). )
G1 X90.36 Y80.36 Z3.4 F1205.9536 E108.5566
( Linear move to (90.36, 80.36, 3.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.4). )
G1 E108.5566
( Linear move to (90.36, 80.36, 3.4). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 3.4). )
G1 X91.02 Y81.02 Z3.4 F6000.0
( Linear move to (91.02, 81.02, 3.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.4). )
G1 E108.5566
( Linear move to (91.02, 81.02, 3.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 3.4). )
G1 X108.98 Y81.02 Z3.4 F1607.9381 E109.0932
( Linear move to (108.98, 98.98, 3.4). )
G1 X108.98 Y98.98 Z3.4 F1607.9381 E109.6297
( Linear move to (91.02, 98.98, 3.4). )
G1 X91.02 Y98.98 Z3.4 F1607.9381 E110.1663
( Linear move to (91.02, 81.02, 3.4). )
G1 X91.02 Y81.02 Z3.4 F1607.9381 E110.7028
( Linear move to (91.02, 81.02, 3.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.4). )
G1 E110.2517
( Linear move to (91.02, 81.02, 3.4). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z3.2 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z3.2 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z3.2 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z3.2 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 3.4). )
G1 X92.3785 Y81.53 Z3.4 F6000.0
( Linear move to (92.3785, 81.53, 3.4). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 3.4). )
G1 E110.7028
( Linear move to (92.3785, 81.53, 3.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 3.4). )
G1 X91.7376 Y81.7376 Z3.4 F1607.9381 E110.7229
( Linear move to (91.53, 82.3785, 3.4). )
G1 X91.53 Y82.3785 Z3.4 F1607.9381 E110.7431
( Linear move to (92.3219, 83.4115, 3.4). )
G1 X92.3219 Y83.4115 Z3.4 F1607.9381 E110.782
( Linear move to (94.2075, 85.2971, 3.4). )
G1 X94.2075 Y85.2971 Z3.4 F1607.9381 E110.8616
( Linear move to (96.2399, 85.1503, 3.4). )
G1 X96.2399 Y85.1503 Z3.4 F1607.9381 E110.9225
( Linear move to (98.1256, 87.0359, 3.4). )
G1 X98.1256 Y87.0359 Z3.4 F1607.9381 E111.0022
( Linear move to (97.9787, 89.0684, 3.4). )
G1 X97.9787 Y89.0684 Z3.4 F1607.9381 E111.063
( Linear move to (99.8643, 90.954, 3.4). )
G1 X99.8643 Y90.954 Z3.4 F1607.9381 E111.1427
( Linear move to (101.8968, 90.8071, 3.4). )
G1 X101.8968 Y90.8071 Z3.4 F1607.9381 E111.2036
( Linear move to (103.7824, 92.6928, 3.4). )
G1 X103.7824 Y92.6928 Z3.4 F1607.9381 E111.2833
( Linear move to (103.6356, 94.7252, 3.4). )
G1 X103.6356 Y94.7252 Z3.4 F1607.9381 E111.3441
( Linear move to (107.6215, 98.47, 3.4). )
G1 X107.6215 Y98.47 Z3.4 F1607.9381 E111.5075
( Linear move to (108.2624, 98.2624, 3.4). )
G1 X108.2624 Y98.2624 Z3.4 F1607.9381 E111.5276
( Linear move to (108.47, 97.6215, 3.4). )
G1 X108.47 Y97.6215 Z3.4 F1607.9381 E111.5478
( Linear move to (108.47, 93.3788, 3.4). )
G1 X108.47 Y93.3788 Z3.4 F1607.9381 E111.6745
( Linear move to (106.1394, 92.2214, 3.4). )
G1 X106.1394 Y92.2214 Z3.4 F1607.9381 E111.7523
( Linear move to (104.107, 92.3682, 3.4). )
G1 X104.107 Y92.3682 Z3.4 F1607.9381 E111.8131
( Linear move to (102.2214, 90.4826, 3.4). )
G1 X102.2214 Y90.4826 Z3.4 F1607.9381 E111.8928
( Linear move to (102.3682, 88.4501, 3.4). )
G1 X102.3682 Y88.4501 Z3.4 F1607.9381 E111.9537
( Linear move to (100.4826, 86.5645, 3.4). )
G1 X100.4826 Y86.5645 Z3.4 F1607.9381 E112.0333
( Linear move to (98.4501, 86.7113, 3.4). )
G1 X98.4501 Y86.7113 Z3.4 F1607.9381 E112.0942
( Linear move to (93.2271, 81.53, 3.4). )
G1 X93.2271 Y81.53 Z3.4 F1607.9381 E112.314
( Linear move to (97.4697, 81.53, 3.4). )
G1 X97.4697 Y81.53 Z3.4 F1607.9381 E112.4408
( Linear move to (96.8736, 82.631, 3.4). )
G1 X96.8736 Y82.631 Z3.4 F1607.9381 E112.4782
( Linear move to (98.6819, 82.0072, 3.4). )
G1 X98.6819 Y82.0072 Z3.4 F1607.9381 E112.5353
( Linear move to (99.1668, 81.53, 3.4). )
G1 X99.1668 Y81.53 Z3.4 F1607.9381 E112.5556
( Linear move to (100.954, 84.2075, 3.4). )
G1 X100.954 Y84.2075 Z3.4 F1607.9381 E112.6518
( Linear move to (100.8071, 86.2399, 3.4). )
G1 X100.8071 Y86.2399 Z3.4 F1607.9381 E112.7127
( Linear move to (102.6928, 88.1256, 3.4). )
G1 X102.6928 Y88.1256 Z3.4 F1607.9381 E112.7924
( Linear move to (104.7252, 87.9787, 3.4). )
G1 X104.7252 Y87.9787 Z3.4 F1607.9381 E112.8532
( Linear move to (106.6108, 89.8643, 3.4). )
G1 X106.6108 Y89.8643 Z3.4 F1607.9381 E112.9329
( Linear move to (106.464, 91.8968, 3.4). )
G1 X106.464 Y91.8968 Z3.4 F1607.9381 E112.9938
( Linear move to (108.47, 92.5303, 3.4). )
G1 X108.47 Y92.5303 Z3.4 F1607.9381 E113.0566
( Linear move to (108.47, 88.2877, 3.4). )
G1 X108.47 Y88.2877 Z3.4 F1607.9381 E113.1834
( Linear move to (106.9354, 89.5398, 3.4). )
G1 X106.9354 Y89.5398 Z3.4 F1607.9381 E113.2425
( Linear move to (105.0498, 87.6542, 3.4). )
G1 X105.0498 Y87.6542 Z3.4 F1607.9381 E113.3222
( Linear move to (105.1966, 85.6217, 3.4). )
G1 X105.1966 Y85.6217 Z3.4 F1607.9381 E113.3831
( Linear move to (103.311, 83.7361, 3.4). )
G1 X103.311 Y83.7361 Z3.4 F1607.9381 E113.4627
( Linear move to (101.2786, 83.8829, 3.4). )
G1 X101.2786 Y83.8829 Z3.4 F1607.9381 E113.5236
( Linear move to (100.0153, 81.53, 3.4). )
G1 X100.0153 Y81.53 Z3.4 F1607.9381 E113.6034
( Linear move to (105.1065, 81.53, 3.4). )
G1 X105.1065 Y81.53 Z3.4 F1607.9381 E113.7555
( Linear move to (103.6356, 83.4115, 3.4). )
G1 X103.6356 Y83.4115 Z3.4 F1607.9381 E113.8269
( Linear move to (105.5212, 85.2971, 3.4). )
G1 X105.5212 Y85.2971 Z3.4 F1607.9381 E113.9065
( Linear move to (108.47, 87.4391, 3.4). )
G1 X108.47 Y87.4391 Z3.4 F1607.9381 E114.0154
( Linear move to (108.47, 83.1965, 3.4). )
G1 X108.47 Y83.1965 Z3.4 F1607.9381 E114.1421
( Linear move to (105.955, 81.53, 3.4). )
G1 X105.955 Y81.53 Z3.4 F1607.9381 E114.2323
( Linear move to (107.652, 81.53, 3.4). )
G1 X107.652 Y81.53 Z3.4 F1607.9381 E114.283
( Linear move to (108.47, 82.348, 3.4). )
G1 X108.47 Y82.348 Z3.4 F1607.9381 E114.3175
( Linear move to (108.47, 82.348, 3.4). )
G1 F1200.0
( Linear move to (108.47, 82.348, 3.4). )
G1 E113.3175
( Linear move to (108.47, 82.348, 3.4). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 3.4). )
G1 X106.7729 Y98.47 Z3.4 F6000.0
( Linear move to (106.7729, 98.47, 3.4). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 3.4). )
G1 E114.3175
( Linear move to (106.7729, 98.47, 3.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 3.4). )
G1 X105.0759 Y98.47 Z3.4 F1607.9381 E114.3682
( Linear move to (105.1966, 96.9354, 3.4). )
G1 X105.1966 Y96.9354 Z3.4 F1607.9381 E114.4142
( Linear move to (103.311, 95.0498, 3.4). )
G1 X103.311 Y95.0498 Z3.4 F1607.9381 E114.4939
( Linear move to (101.2786, 95.1966, 3.4). )
G1 X101.2786 Y95.1966 Z3.4 F1607.9381 E114.5548
( Linear move to (99.3929, 93.311, 3.4). )
G1 X99.3929 Y93.311 Z3.4 F1607.9381 E114.6344
( Linear move to (99.5398, 91.2786, 3.4). )
G1 X99.5398 Y91.2786 Z3.4 F1607.9381 E114.6953
( Linear move to (97.6542, 89.3929, 3.4). )
G1 X97.6542 Y89.3929 Z3.4 F1607.9381 E114.775
( Linear move to (95.6217, 89.5398, 3.4). )
G1 X95.6217 Y89.5398 Z3.4 F1607.9381 E114.8359
( Linear move to (93.7361, 87.6542, 3.4). )
G1 X93.7361 Y87.6542 Z3.4 F1607.9381 E114.9155
( Linear move to (93.8829, 85.6217, 3.4). )
G1 X93.8829 Y85.6217 Z3.4 F1607.9381 E114.9764
( Linear move to (91.53, 83.2271, 3.4). )
G1 X91.53 Y83.2271 Z3.4 F1607.9381 E115.0767
( Linear move to (91.53, 88.3182, 3.4). )
G1 X91.53 Y88.3182 Z3.4 F1607.9381 E115.2288
( Linear move to (93.4115, 87.9787, 3.4). )
G1 X93.4115 Y87.9787 Z3.4 F1607.9381 E115.2859
( Linear move to (95.2971, 89.8643, 3.4). )
G1 X95.2971 Y89.8643 Z3.4 F1607.9381 E115.3656
( Linear move to (95.1503, 91.8968, 3.4). )
G1 X95.1503 Y91.8968 Z3.4 F1607.9381 E115.4264
( Linear move to (97.0359, 93.7824, 3.4). )
G1 X97.0359 Y93.7824 Z3.4 F1607.9381 E115.5061
( Linear move to (99.0684, 93.6356, 3.4). )
G1 X99.0684 Y93.6356 Z3.4 F1607.9381 E115.567
( Linear move to (100.954, 95.5212, 3.4). )
G1 X100.954 Y95.5212 Z3.4 F1607.9381 E115.6467
( Linear move to (100.8071, 97.5537, 3.4). )
G1 X100.8071 Y97.5537 Z3.4 F1607.9381 E115.7075
( Linear move to (103.3788, 97.87, 3.4). )
G1 X103.3788 Y97.87 Z3.4 F1607.9381 E115.7849
( Linear move to (104.2274, 98.47, 3.4). )
G1 X104.2274 Y98.47 Z3.4 F1607.9381 E115.816
( Linear move to (99.9847, 98.47, 3.4). )
G1 X99.9847 Y98.47 Z3.4 F1607.9381 E115.9427
( Linear move to (100.4826, 97.8782, 3.4). )
G1 X100.4826 Y97.8782 Z3.4 F1607.9381 E115.9658
( Linear move to (99.3259, 97.9008, 3.4). )
G1 X99.3259 Y97.9008 Z3.4 F1607.9381 E116.0004
( Linear move to (98.2878, 98.1873, 3.4). )
G1 X98.2878 Y98.1873 Z3.4 F1607.9381 E116.0326
( Linear move to (96.5645, 96.1394, 3.4). )
G1 X96.5645 Y96.1394 Z3.4 F1607.9381 E116.1125
( Linear move to (96.7113, 94.107, 3.4). )
G1 X96.7113 Y94.107 Z3.4 F1607.9381 E116.1734
( Linear move to (94.8257, 92.2214, 3.4). )
G1 X94.8257 Y92.2214 Z3.4 F1607.9381 E116.2531
( Linear move to (92.7933, 92.3682, 3.4). )
G1 X92.7933 Y92.3682 Z3.4 F1607.9381 E116.314
( Linear move to (92.13, 89.1668, 3.4). )
G1 X92.13 Y89.1668 Z3.4 F1607.9381 E116.4116
( Linear move to (91.53, 90.0153, 3.4). )
G1 X91.53 Y90.0153 Z3.4 F1607.9381 E116.4427
( Linear move to (91.53, 92.5609, 3.4). )
G1 X91.53 Y92.5609 Z3.4 F1607.9381 E116.5187
( Linear move to (92.4687, 92.6928, 3.4). )
G1 X92.4687 Y92.6928 Z3.4 F1607.9381 E116.547
( Linear move to (91.53, 93.4094, 3.4). )
G1 X91.53 Y93.4094 Z3.4 F1607.9381 E116.5823
( Linear move to (91.53, 95.1065, 3.4). )
G1 X91.53 Y95.1065 Z3.4 F1607.9381 E116.633
( Linear move to (92.1596, 94.8875, 3.4). )
G1 X92.1596 Y94.8875 Z3.4 F1607.9381 E116.6529
( Linear move to (94.2075, 96.6108, 3.4). )
G1 X94.2075 Y96.6108 Z3.4 F1607.9381 E116.7329
( Linear move to (96.2399, 96.464, 3.4). )
G1 X96.2399 Y96.464 Z3.4 F1607.9381 E116.7938
( Linear move to (97.4391, 98.47, 3.4). )
G1 X97.4391 Y98.47 Z3.4 F1607.9381 E116.8636
( Linear move to (94.045, 98.47, 3.4). )
G1 X94.045 Y98.47 Z3.4 F1607.9381 E116.965
( Linear move to (93.8829, 96.9354, 3.4). )
G1 X93.8829 Y96.9354 Z3.4 F1607.9381 E117.0111
( Linear move to (91.53, 95.955, 3.4). )
G1 X91.53 Y95.955 Z3.4 F1607.9381 E117.0872
( Linear move to (91.53, 97.652, 3.4). )
G1 X91.53 Y97.652 Z3.4 F1607.9381 E117.1379
( Linear move to (92.348, 98.47, 3.4). )
G1 X92.348 Y98.47 Z3.4 F1607.9381 E117.1725
( Linear move to (93.1965, 98.47, 3.4). )
G1 X93.1965 Y98.47 Z3.4 F1607.9381 E117.1979
( Linear move to (93.1965, 98.47, 3.4). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 3.4). )
G1 E116.1979
( Linear move to (93.1965, 98.47, 3.4). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 3.8 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z3.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z3.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z3.8 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z3.8 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 3.8). )
G1 X90.36 Y80.36 Z3.8 F2750.2729
( Linear move to (90.36, 80.36, 3.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.8). )
G1 E117.1979
( Linear move to (90.36, 80.36, 3.8). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 3.8). )
G1 X109.64 Y80.36 Z3.8 F1025.5987 E117.7741
( Linear move to (109.64, 99.64, 3.8). )
G1 X109.64 Y99.64 Z3.8 F1025.5987 E118.3504
( Linear move to (90.36, 99.64, 3.8). )
G1 X90.36 Y99.64 Z3.8 F1025.5987 E118.9267
( Linear move to (90.36, 80.36, 3.8). )
G1 X90.36 Y80.36 Z3.8 F1025.5987 E119.503
( Linear move to (90.36, 80.36, 3.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 3.8). )
G1 E119.503
( Linear move to (90.36, 80.36, 3.8). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 3.8). )
G1 X91.02 Y81.02 Z3.8 F6000.0
( Linear move to (91.02, 81.02, 3.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.8). )
G1 E119.503
( Linear move to (91.02, 81.02, 3.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 3.8). )
G1 X108.98 Y81.02 Z3.8 F1367.465 E120.0395
( Linear move to (108.98, 98.98, 3.8). )
G1 X108.98 Y98.98 Z3.8 F1367.465 E120.576
( Linear move to (91.02, 98.98, 3.8). )
G1 X91.02 Y98.98 Z3.8 F1367.465 E121.1125
( Linear move to (91.02, 81.02, 3.8). )
G1 X91.02 Y81.02 Z3.8 F1367.465 E121.649
( Linear move to (91.02, 81.02, 3.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 3.8). )
G1 E120.649
( Linear move to (91.02, 81.02, 3.8). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z3.6 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z3.6 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z3.6 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z3.6 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 3.8). )
G1 X91.53 Y93.6315 Z3.8 F6000.0
( Linear move to (91.53, 93.6315, 3.8). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 3.8). )
G1 E121.649
( Linear move to (91.53, 93.6315, 3.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 3.8). )
G1 X91.53 Y87.6918 Z3.8 F1367.465 E121.8265
( Linear move to (93.3935, 87.9968, 3.8). )
G1 X93.3935 Y87.9968 Z3.8 F1367.465 E121.8829
( Linear move to (93.7541, 87.6361, 3.8). )
G1 X93.7541 Y87.6361 Z3.8 F1367.465 E121.8981
( Linear move to (93.8649, 85.6397, 3.8). )
G1 X93.8649 Y85.6397 Z3.8 F1367.465 E121.9578
( Linear move to (94.2255, 85.2791, 3.8). )
G1 X94.2255 Y85.2791 Z3.8 F1367.465 E121.9731
( Linear move to (96.2219, 85.1683, 3.8). )
G1 X96.2219 Y85.1683 Z3.8 F1367.465 E122.0328
( Linear move to (96.5825, 84.8077, 3.8). )
G1 X96.5825 Y84.8077 Z3.8 F1367.465 E122.048
( Linear move to (103.6315, 82.13, 3.8). )
G1 X103.6315 Y82.13 Z3.8 F1367.465 E122.2733
( Linear move to (104.48, 81.53, 3.8). )
G1 X104.48 Y81.53 Z3.8 F1367.465 E122.3043
( Linear move to (93.4491, 81.53, 3.8). )
G1 X93.4491 Y81.53 Z3.8 F1367.465 E122.6339
( Linear move to (93.4491, 82.13, 3.8). )
G1 X93.4491 Y82.13 Z3.8 F1367.465 E122.6518
( Linear move to (92.13, 86.8432, 3.8). )
G1 X92.13 Y86.8432 Z3.8 F1367.465 E122.798
( Linear move to (91.53, 85.9947, 3.8). )
G1 X91.53 Y85.9947 Z3.8 F1367.465 E122.829
( Linear move to (91.53, 82.6006, 3.8). )
G1 X91.53 Y82.6006 Z3.8 F1367.465 E122.9304
( Linear move to (92.6006, 81.53, 3.8). )
G1 X92.6006 Y81.53 Z3.8 F1367.465 E122.9756
( Linear move to (92.6006, 81.53, 3.8). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 3.8). )
G1 E121.9756
( Linear move to (92.6006, 81.53, 3.8). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 3.8). )
G1 X108.47 Y97.0561 Z3.8 F6000.0
( Linear move to (108.47, 97.0561, 3.8). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 3.8). )
G1 E122.9756
( Linear move to (108.47, 97.0561, 3.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 3.8). )
G1 X108.47 Y97.9047 Z3.8 F1367.465 E123.001
( Linear move to (107.9047, 98.47, 3.8). )
G1 X107.9047 Y98.47 Z3.8 F1367.465 E123.0249
( Linear move to (105.3591, 98.47, 3.8). )
G1 X105.3591 Y98.47 Z3.8 F1367.465 E123.1009
( Linear move to (105.1786, 96.9534, 3.8). )
G1 X105.1786 Y96.9534 Z3.8 F1367.465 E123.1465
( Linear move to (105.5392, 96.5928, 3.8). )
G1 X105.5392 Y96.5928 Z3.8 F1367.465 E123.1618
( Linear move to (108.47, 96.2076, 3.8). )
G1 X108.47 Y96.2076 Z3.8 F1367.465 E123.2501
( Linear move to (108.47, 89.4194, 3.8). )
G1 X108.47 Y89.4194 Z3.8 F1367.465 E123.4529
( Linear move to (106.9534, 89.5217, 3.8). )
G1 X106.9534 Y89.5217 Z3.8 F1367.465 E123.4983
( Linear move to (106.5928, 89.8824, 3.8). )
G1 X106.5928 Y89.8824 Z3.8 F1367.465 E123.5135
( Linear move to (106.482, 91.8788, 3.8). )
G1 X106.482 Y91.8788 Z3.8 F1367.465 E123.5732
( Linear move to (106.1214, 92.2394, 3.8). )
G1 X106.1214 Y92.2394 Z3.8 F1367.465 E123.5885
( Linear move to (104.125, 92.3502, 3.8). )
G1 X104.125 Y92.3502 Z3.8 F1367.465 E123.6482
( Linear move to (103.7644, 92.7108, 3.8). )
G1 X103.7644 Y92.7108 Z3.8 F1367.465 E123.6634
( Linear move to (103.6536, 94.7072, 3.8). )
G1 X103.6536 Y94.7072 Z3.8 F1367.465 E123.7232
( Linear move to (103.293, 95.0678, 3.8). )
G1 X103.293 Y95.0678 Z3.8 F1367.465 E123.7384
( Linear move to (101.2966, 95.1786, 3.8). )
G1 X101.2966 Y95.1786 Z3.8 F1367.465 E123.7981
( Linear move to (100.936, 95.5392, 3.8). )
G1 X100.936 Y95.5392 Z3.8 F1367.465 E123.8134
( Linear move to (100.6449, 97.7159, 3.8). )
G1 X100.6449 Y97.7159 Z3.8 F1367.465 E123.879
( Linear move to (104.5106, 97.87, 3.8). )
G1 X104.5106 Y97.87 Z3.8 F1367.465 E123.9945
( Linear move to (103.662, 98.47, 3.8). )
G1 X103.662 Y98.47 Z3.8 F1367.465 E124.0256
( Linear move to (98.5709, 98.47, 3.8). )
G1 X98.5709 Y98.47 Z3.8 F1367.465 E124.1777
( Linear move to (98.4682, 98.007, 3.8). )
G1 X98.4682 Y98.007 Z3.8 F1367.465 E124.1918
( Linear move to (98.1075, 98.3676, 3.8). )
G1 X98.1075 Y98.3676 Z3.8 F1367.465 E124.2071
( Linear move to (97.7223, 98.47, 3.8). )
G1 X97.7223 Y98.47 Z3.8 F1367.465 E124.219
( Linear move to (94.3282, 98.47, 3.8). )
G1 X94.3282 Y98.47 Z3.8 F1367.465 E124.3204
( Linear move to (93.8649, 96.9534, 3.8). )
G1 X93.8649 Y96.9534 Z3.8 F1367.465 E124.3677
( Linear move to (94.2255, 96.5928, 3.8). )
G1 X94.2255 Y96.5928 Z3.8 F1367.465 E124.383
( Linear move to (96.2219, 96.482, 3.8). )
G1 X96.2219 Y96.482 Z3.8 F1367.465 E124.4427
( Linear move to (96.5825, 96.1214, 3.8). )
G1 X96.5825 Y96.1214 Z3.8 F1367.465 E124.4579
( Linear move to (96.6933, 94.125, 3.8). )
G1 X96.6933 Y94.125 Z3.8 F1367.465 E124.5177
( Linear move to (97.0539, 93.7644, 3.8). )
G1 X97.0539 Y93.7644 Z3.8 F1367.465 E124.5329
( Linear move to (99.0503, 93.6536, 3.8). )
G1 X99.0503 Y93.6536 Z3.8 F1367.465 E124.5926
( Linear move to (99.411, 93.293, 3.8). )
G1 X99.411 Y93.293 Z3.8 F1367.465 E124.6079
( Linear move to (99.5217, 91.2966, 3.8). )
G1 X99.5217 Y91.2966 Z3.8 F1367.465 E124.6676
( Linear move to (99.8824, 90.936, 3.8). )
G1 X99.8824 Y90.936 Z3.8 F1367.465 E124.6828
( Linear move to (101.8788, 90.8252, 3.8). )
G1 X101.8788 Y90.8252 Z3.8 F1367.465 E124.7426
( Linear move to (102.2394, 90.4646, 3.8). )
G1 X102.2394 Y90.4646 Z3.8 F1367.465 E124.7578
( Linear move to (102.3502, 88.4682, 3.8). )
G1 X102.3502 Y88.4682 Z3.8 F1367.465 E124.8175
( Linear move to (102.7108, 88.1075, 3.8). )
G1 X102.7108 Y88.1075 Z3.8 F1367.465 E124.8328
( Linear move to (104.7072, 87.9968, 3.8). )
G1 X104.7072 Y87.9968 Z3.8 F1367.465 E124.8925
( Linear move to (105.0678, 87.6361, 3.8). )
G1 X105.0678 Y87.6361 Z3.8 F1367.465 E124.9077
( Linear move to (105.1786, 85.6397, 3.8). )
G1 X105.1786 Y85.6397 Z3.8 F1367.465 E124.9675
( Linear move to (105.5392, 85.2791, 3.8). )
G1 X105.5392 Y85.2791 Z3.8 F1367.465 E124.9827
( Linear move to (108.47, 88.5709, 3.8). )
G1 X108.47 Y88.5709 Z3.8 F1367.465 E125.1143
( Linear move to (108.3887, 81.8639, 3.8). )
G1 X108.3887 Y81.8639 Z3.8 F1367.465 E125.3147
( Linear move to (107.8741, 81.53, 3.8). )
G1 X107.8741 Y81.53 Z3.8 F1367.465 E125.333
( Linear move to (106.1771, 81.53, 3.8). )
G1 X106.1771 Y81.53 Z3.8 F1367.465 E125.3837
( Linear move to (103.293, 83.7541, 3.8). )
G1 X103.293 Y83.7541 Z3.8 F1367.465 E125.4925
( Linear move to (101.2966, 83.8649, 3.8). )
G1 X101.2966 Y83.8649 Z3.8 F1367.465 E125.5523
( Linear move to (100.936, 84.2255, 3.8). )
G1 X100.936 Y84.2255 Z3.8 F1367.465 E125.5675
( Linear move to (100.8252, 86.2219, 3.8). )
G1 X100.8252 Y86.2219 Z3.8 F1367.465 E125.6272
( Linear move to (100.4646, 86.5825, 3.8). )
G1 X100.4646 Y86.5825 Z3.8 F1367.465 E125.6425
( Linear move to (98.4682, 86.6933, 3.8). )
G1 X98.4682 Y86.6933 Z3.8 F1367.465 E125.7022
( Linear move to (98.1075, 87.0539, 3.8). )
G1 X98.1075 Y87.0539 Z3.8 F1367.465 E125.7174
( Linear move to (97.9968, 89.0503, 3.8). )
G1 X97.9968 Y89.0503 Z3.8 F1367.465 E125.7772
( Linear move to (97.6361, 89.411, 3.8). )
G1 X97.6361 Y89.411 Z3.8 F1367.465 E125.7924
( Linear move to (95.6397, 89.5217, 3.8). )
G1 X95.6397 Y89.5217 Z3.8 F1367.465 E125.8521
( Linear move to (95.2791, 89.8824, 3.8). )
G1 X95.2791 Y89.8824 Z3.8 F1367.465 E125.8674
( Linear move to (95.1683, 91.8788, 3.8). )
G1 X95.1683 Y91.8788 Z3.8 F1367.465 E125.9271
( Linear move to (94.8077, 92.2394, 3.8). )
G1 X94.8077 Y92.2394 Z3.8 F1367.465 E125.9423
( Linear move to (92.8113, 92.3502, 3.8). )
G1 X92.8113 Y92.3502 Z3.8 F1367.465 E126.002
( Linear move to (92.4507, 92.7108, 3.8). )
G1 X92.4507 Y92.7108 Z3.8 F1367.465 E126.0173
( Linear move to (91.53, 94.48, 3.8). )
G1 X91.53 Y94.48 Z3.8 F1367.465 E126.0769
( Linear move to (92.3399, 94.7072, 3.8). )
G1 X92.3399 Y94.7072 Z3.8 F1367.465 E126.102
( Linear move to (91.9793, 95.0678, 3.8). )
G1 X91.9793 Y95.0678 Z3.8 F1367.465 E126.1172
( Linear move to (91.53, 95.3285, 3.8). )
G1 X91.53 Y95.3285 Z3.8 F1367.465 E126.1327
( Linear move to (91.53, 97.8741, 3.8). )
G1 X91.53 Y97.8741 Z3.8 F1367.465 E126.2088
( Linear move to (91.8639, 98.3887, 3.8). )
G1 X91.8639 Y98.3887 Z3.8 F1367.465 E126.2271
( Linear move to (93.4797, 98.47, 3.8). )
G1 X93.4797 Y98.47 Z3.8 F1367.465 E126.2754
( Linear move to (93.4797, 98.47, 3.8). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 3.8). )
G1 E125.2754
( Linear move to (93.4797, 98.47, 3.8). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 4.2 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z4.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z4.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z4.2 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z4.2 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 4.2). )
G1 X90.36 Y80.36 Z4.2 F2757.1641
( Linear move to (90.36, 80.36, 4.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 4.2). )
G1 E126.2754
( Linear move to (90.36, 80.36, 4.2). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 4.2). )
G1 X109.64 Y80.36 Z4.2 F1205.9536 E126.8515
( Linear move to (109.64, 99.64, 4.2). )
G1 X109.64 Y99.64 Z4.2 F1205.9536 E127.4276
( Linear move to (90.36, 99.64, 4.2). )
G1 X90.36 Y99.64 Z4.2 F1205.9536 E128.0037
( Linear move to (90.36, 80.36, 4.2). )
G1 X90.36 Y80.36 Z4.2 F1205.9536 E128.5798
( Linear move to (90.36, 80.36, 4.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 4.2). )
G1 E128.5798
( Linear move to (90.36, 80.36, 4.2). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 4.2). )
G1 X91.02 Y81.02 Z4.2 F6000.0
( Linear move to (91.02, 81.02, 4.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 4.2). )
G1 E128.5798
( Linear move to (91.02, 81.02, 4.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 4.2). )
G1 X108.98 Y81.02 Z4.2 F1607.9381 E129.1163
( Linear move to (108.98, 98.98, 4.2). )
G1 X108.98 Y98.98 Z4.2 F1607.9381 E129.6529
( Linear move to (91.02, 98.98, 4.2). )
G1 X91.02 Y98.98 Z4.2 F1607.9381 E130.1894
( Linear move to (91.02, 81.02, 4.2). )
G1 X91.02 Y81.02 Z4.2 F1607.9381 E130.726
( Linear move to (91.02, 81.02, 4.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 4.2). )
G1 E130.2749
( Linear move to (91.02, 81.02, 4.2). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z4.0 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z4.0 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z4.0 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z4.0 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 4.2). )
G1 X92.3785 Y81.53 Z4.2 F6000.0
( Linear move to (92.3785, 81.53, 4.2). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 4.2). )
G1 E130.726
( Linear move to (92.3785, 81.53, 4.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 4.2). )
G1 X91.7376 Y81.7376 Z4.2 F1607.9381 E130.7461
( Linear move to (91.53, 82.3785, 4.2). )
G1 X91.53 Y82.3785 Z4.2 F1607.9381 E130.7662
( Linear move to (92.3219, 83.4115, 4.2). )
G1 X92.3219 Y83.4115 Z4.2 F1607.9381 E130.8051
( Linear move to (94.2075, 85.2971, 4.2). )
G1 X94.2075 Y85.2971 Z4.2 F1607.9381 E130.8848
( Linear move to (96.2399, 85.1503, 4.2). )
G1 X96.2399 Y85.1503 Z4.2 F1607.9381 E130.9457
( Linear move to (98.1256, 87.0359, 4.2). )
G1 X98.1256 Y87.0359 Z4.2 F1607.9381 E131.0253
( Linear move to (97.9787, 89.0684, 4.2). )
G1 X97.9787 Y89.0684 Z4.2 F1607.9381 E131.0862
( Linear move to (99.8643, 90.954, 4.2). )
G1 X99.8643 Y90.954 Z4.2 F1607.9381 E131.1659
( Linear move to (101.8968, 90.8071, 4.2). )
G1 X101.8968 Y90.8071 Z4.2 F1607.9381 E131.2267
( Linear move to (103.7824, 92.6928, 4.2). )
G1 X103.7824 Y92.6928 Z4.2 F1607.9381 E131.3064
( Linear move to (103.6356, 94.7252, 4.2). )
G1 X103.6356 Y94.7252 Z4.2 F1607.9381 E131.3673
( Linear move to (107.6215, 98.47, 4.2). )
G1 X107.6215 Y98.47 Z4.2 F1607.9381 E131.5307
( Linear move to (108.2624, 98.2624, 4.2). )
G1 X108.2624 Y98.2624 Z4.2 F1607.9381 E131.5508
( Linear move to (108.47, 97.6215, 4.2). )
G1 X108.47 Y97.6215 Z4.2 F1607.9381 E131.5709
( Linear move to (108.47, 93.3788, 4.2). )
G1 X108.47 Y93.3788 Z4.2 F1607.9381 E131.6977
( Linear move to (106.1394, 92.2214, 4.2). )
G1 X106.1394 Y92.2214 Z4.2 F1607.9381 E131.7754
( Linear move to (104.107, 92.3682, 4.2). )
G1 X104.107 Y92.3682 Z4.2 F1607.9381 E131.8363
( Linear move to (102.2214, 90.4826, 4.2). )
G1 X102.2214 Y90.4826 Z4.2 F1607.9381 E131.916
( Linear move to (102.3682, 88.4501, 4.2). )
G1 X102.3682 Y88.4501 Z4.2 F1607.9381 E131.9768
( Linear move to (100.4826, 86.5645, 4.2). )
G1 X100.4826 Y86.5645 Z4.2 F1607.9381 E132.0565
( Linear move to (98.4501, 86.7113, 4.2). )
G1 X98.4501 Y86.7113 Z4.2 F1607.9381 E132.1174
( Linear move to (93.2271, 81.53, 4.2). )
G1 X93.2271 Y81.53 Z4.2 F1607.9381 E132.3372
( Linear move to (97.4697, 81.53, 4.2). )
G1 X97.4697 Y81.53 Z4.2 F1607.9381 E132.4639
( Linear move to (96.8736, 82.631, 4.2). )
G1 X96.8736 Y82.631 Z4.2 F1607.9381 E132.5013
( Linear move to (98.6819, 82.0072, 4.2). )
G1 X98.6819 Y82.0072 Z4.2 F1607.9381 E132.5585
( Linear move to (99.1668, 81.53, 4.2). )
G1 X99.1668 Y81.53 Z4.2 F1607.9381 E132.5788
( Linear move to (100.954, 84.2075, 4.2). )
G1 X100.954 Y84.2075 Z4.2 F1607.9381 E132.675
( Linear move to (100.8071, 86.2399, 4.2). )
G1 X100.8071 Y86.2399 Z4.2 F1607.9381 E132.7358
( Linear move to (102.6928, 88.1256, 4.2). )
G1 X102.6928 Y88.1256 Z4.2 F1607.9381 E132.8155
( Linear move to (104.7252, 87.9787, 4.2). )
G1 X104.7252 Y87.9787 Z4.2 F1607.9381 E132.8764
( Linear move to (106.6108, 89.8643, 4.2). )
G1 X106.6108 Y89.8643 Z4.2 F1607.9381 E132.956
( Linear move to (106.464, 91.8968, 4.2). )
G1 X106.464 Y91.8968 Z4.2 F1607.9381 E133.0169
( Linear move to (108.47, 92.5303, 4.2). )
G1 X108.47 Y92.5303 Z4.2 F1607.9381 E133.0798
( Linear move to (108.47, 88.2877, 4.2). )
G1 X108.47 Y88.2877 Z4.2 F1607.9381 E133.2065
( Linear move to (106.9354, 89.5398, 4.2). )
G1 X106.9354 Y89.5398 Z4.2 F1607.9381 E133.2657
( Linear move to (105.0498, 87.6542, 4.2). )
G1 X105.0498 Y87.6542 Z4.2 F1607.9381 E133.3454
( Linear move to (105.1966, 85.6217, 4.2). )
G1 X105.1966 Y85.6217 Z4.2 F1607.9381 E133.4062
( Linear move to (103.311, 83.7361, 4.2). )
G1 X103.311 Y83.7361 Z4.2 F1607.9381 E133.4859
( Linear move to (101.2786, 83.8829, 4.2). )
G1 X101.2786 Y83.8829 Z4.2 F1607.9381 E133.5468
( Linear move to (100.0153, 81.53, 4.2). )
G1 X100.0153 Y81.53 Z4.2 F1607.9381 E133.6266
( Linear move to (105.1065, 81.53, 4.2). )
G1 X105.1065 Y81.53 Z4.2 F1607.9381 E133.7787
( Linear move to (103.6356, 83.4115, 4.2). )
G1 X103.6356 Y83.4115 Z4.2 F1607.9381 E133.85
( Linear move to (105.5212, 85.2971, 4.2). )
G1 X105.5212 Y85.2971 Z4.2 F1607.9381 E133.9297
( Linear move to (108.47, 87.4391, 4.2). )
G1 X108.47 Y87.4391 Z4.2 F1607.9381 E134.0386
( Linear move to (108.47, 83.1965, 4.2). )
G1 X108.47 Y83.1965 Z4.2 F1607.9381 E134.1653
( Linear move to (105.955, 81.53, 4.2). )
G1 X105.955 Y81.53 Z4.2 F1607.9381 E134.2554
( Linear move to (107.652, 81.53, 4.2). )
G1 X107.652 Y81.53 Z4.2 F1607.9381 E134.3061
( Linear move to (108.47, 82.348, 4.2). )
G1 X108.47 Y82.348 Z4.2 F1607.9381 E134.3407
( Linear move to (108.47, 82.348, 4.2). )
G1 F1200.0
( Linear move to (108.47, 82.348, 4.2). )
G1 E133.3407
( Linear move to (108.47, 82.348, 4.2). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 4.2). )
G1 X106.7729 Y98.47 Z4.2 F6000.0
( Linear move to (106.7729, 98.47, 4.2). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 4.2). )
G1 E134.3407
( Linear move to (106.7729, 98.47, 4.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 4.2). )
G1 X105.0759 Y98.47 Z4.2 F1607.9381 E134.3914
( Linear move to (105.1966, 96.9354, 4.2). )
G1 X105.1966 Y96.9354 Z4.2 F1607.9381 E134.4374
( Linear move to (103.311, 95.0498, 4.2). )
G1 X103.311 Y95.0498 Z4.2 F1607.9381 E134.517
( Linear move to (101.2786, 95.1966, 4.2). )
G1 X101.2786 Y95.1966 Z4.2 F1607.9381 E134.5779
( Linear move to (99.3929, 93.311, 4.2). )
G1 X99.3929 Y93.311 Z4.2 F1607.9381 E134.6576
( Linear move to (99.5398, 91.2786, 4.2). )
G1 X99.5398 Y91.2786 Z4.2 F1607.9381 E134.7185
( Linear move to (97.6542, 89.3929, 4.2). )
G1 X97.6542 Y89.3929 Z4.2 F1607.9381 E134.7981
( Linear move to (95.6217, 89.5398, 4.2). )
G1 X95.6217 Y89.5398 Z4.2 F1607.9381 E134.859
( Linear move to (93.7361, 87.6542, 4.2). )
G1 X93.7361 Y87.6542 Z4.2 F1607.9381 E134.9387
( Linear move to (93.8829, 85.6217, 4.2). )
G1 X93.8829 Y85.6217 Z4.2 F1607.9381 E134.9995
( Linear move to (91.53, 83.2271, 4.2). )
G1 X91.53 Y83.2271 Z4.2 F1607.9381 E135.0998
( Linear move to (91.53, 88.3182, 4.2). )
G1 X91.53 Y88.3182 Z4.2 F1607.9381 E135.2519
( Linear move to (93.4115, 87.9787, 4.2). )
G1 X93.4115 Y87.9787 Z4.2 F1607.9381 E135.3091
( Linear move to (95.2971, 89.8643, 4.2). )
G1 X95.2971 Y89.8643 Z4.2 F1607.9381 E135.3887
( Linear move to (95.1503, 91.8968, 4.2). )
G1 X95.1503 Y91.8968 Z4.2 F1607.9381 E135.4496
( Linear move to (97.0359, 93.7824, 4.2). )
G1 X97.0359 Y93.7824 Z4.2 F1607.9381 E135.5293
( Linear move to (99.0684, 93.6356, 4.2). )
G1 X99.0684 Y93.6356 Z4.2 F1607.9381 E135.5901
( Linear move to (100.954, 95.5212, 4.2). )
G1 X100.954 Y95.5212 Z4.2 F1607.9381 E135.6698
( Linear move to (100.8071, 97.5537, 4.2). )
G1 X100.8071 Y97.5537 Z4.2 F1607.9381 E135.7307
( Linear move to (103.3788, 97.87, 4.2). )
G1 X103.3788 Y97.87 Z4.2 F1607.9381 E135.8081
( Linear move to (104.2274, 98.47, 4.2). )
G1 X104.2274 Y98.47 Z4.2 F1607.9381 E135.8391
( Linear move to (99.9847, 98.47, 4.2). )
G1 X99.9847 Y98.47 Z4.2 F1607.9381 E135.9659
( Linear move to (100.4826, 97.8782, 4.2). )
G1 X100.4826 Y97.8782 Z4.2 F1607.9381 E135.989
( Linear move to (99.3259, 97.9008, 4.2). )
G1 X99.3259 Y97.9008 Z4.2 F1607.9381 E136.0236
( Linear move to (98.2878, 98.1873, 4.2). )
G1 X98.2878 Y98.1873 Z4.2 F1607.9381 E136.0557
( Linear move to (96.5645, 96.1394, 4.2). )
G1 X96.5645 Y96.1394 Z4.2 F1607.9381 E136.1357
( Linear move to (96.7113, 94.107, 4.2). )
G1 X96.7113 Y94.107 Z4.2 F1607.9381 E136.1966
( Linear move to (94.8257, 92.2214, 4.2). )
G1 X94.8257 Y92.2214 Z4.2 F1607.9381 E136.2762
( Linear move to (92.7933, 92.3682, 4.2). )
G1 X92.7933 Y92.3682 Z4.2 F1607.9381 E136.3371
( Linear move to (92.13, 89.1668, 4.2). )
G1 X92.13 Y89.1668 Z4.2 F1607.9381 E136.4348
( Linear move to (91.53, 90.0153, 4.2). )
G1 X91.53 Y90.0153 Z4.2 F1607.9381 E136.4658
( Linear move to (91.53, 92.5609, 4.2). )
G1 X91.53 Y92.5609 Z4.2 F1607.9381 E136.5419
( Linear move to (92.4687, 92.6928, 4.2). )
G1 X92.4687 Y92.6928 Z4.2 F1607.9381 E136.5702
( Linear move to (91.53, 93.4094, 4.2). )
G1 X91.53 Y93.4094 Z4.2 F1607.9381 E136.6055
( Linear move to (91.53, 95.1065, 4.2). )
G1 X91.53 Y95.1065 Z4.2 F1607.9381 E136.6562
( Linear move to (92.1596, 94.8875, 4.2). )
G1 X92.1596 Y94.8875 Z4.2 F1607.9381 E136.6761
( Linear move to (94.2075, 96.6108, 4.2). )
G1 X94.2075 Y96.6108 Z4.2 F1607.9381 E136.7561
( Linear move to (96.2399, 96.464, 4.2). )
G1 X96.2399 Y96.464 Z4.2 F1607.9381 E136.8169
( Linear move to (97.4391, 98.47, 4.2). )
G1 X97.4391 Y98.47 Z4.2 F1607.9381 E136.8867
( Linear move to (94.045, 98.47, 4.2). )
G1 X94.045 Y98.47 Z4.2 F1607.9381 E136.9881
( Linear move to (93.8829, 96.9354, 4.2). )
G1 X93.8829 Y96.9354 Z4.2 F1607.9381 E137.0342
( Linear move to (91.53, 95.955, 4.2). )
G1 X91.53 Y95.955 Z4.2 F1607.9381 E137.1104
( Linear move to (91.53, 97.652, 4.2). )
G1 X91.53 Y97.652 Z4.2 F1607.9381 E137.1611
( Linear move to (92.348, 98.47, 4.2). )
G1 X92.348 Y98.47 Z4.2 F1607.9381 E137.1957
( Linear move to (93.1965, 98.47, 4.2). )
G1 X93.1965 Y98.47 Z4.2 F1607.9381 E137.221
( Linear move to (93.1965, 98.47, 4.2). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 4.2). )
G1 E136.221
( Linear move to (93.1965, 98.47, 4.2). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 4.6 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z4.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z4.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z4.6 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z4.6 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 4.6). )
G1 X90.36 Y80.36 Z4.6 F2750.2729
( Linear move to (90.36, 80.36, 4.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 4.6). )
G1 E137.221
( Linear move to (90.36, 80.36, 4.6). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 4.6). )
G1 X109.64 Y80.36 Z4.6 F1025.5987 E137.7973
( Linear move to (109.64, 99.64, 4.6). )
G1 X109.64 Y99.64 Z4.6 F1025.5987 E138.3736
( Linear move to (90.36, 99.64, 4.6). )
G1 X90.36 Y99.64 Z4.6 F1025.5987 E138.9499
( Linear move to (90.36, 80.36, 4.6). )
G1 X90.36 Y80.36 Z4.6 F1025.5987 E139.5261
( Linear move to (90.36, 80.36, 4.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 4.6). )
G1 E139.5261
( Linear move to (90.36, 80.36, 4.6). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 4.6). )
G1 X91.02 Y81.02 Z4.6 F6000.0
( Linear move to (91.02, 81.02, 4.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 4.6). )
G1 E139.5261
( Linear move to (91.02, 81.02, 4.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 4.6). )
G1 X108.98 Y81.02 Z4.6 F1367.465 E140.0627
( Linear move to (108.98, 98.98, 4.6). )
G1 X108.98 Y98.98 Z4.6 F1367.465 E140.5992
( Linear move to (91.02, 98.98, 4.6). )
G1 X91.02 Y98.98 Z4.6 F1367.465 E141.1357
( Linear move to (91.02, 81.02, 4.6). )
G1 X91.02 Y81.02 Z4.6 F1367.465 E141.6722
( Linear move to (91.02, 81.02, 4.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 4.6). )
G1 E140.6722
( Linear move to (91.02, 81.02, 4.6). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z4.4 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z4.4 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z4.4 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z4.4 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 4.6). )
G1 X91.53 Y93.6315 Z4.6 F6000.0
( Linear move to (91.53, 93.6315, 4.6). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 4.6). )
G1 E141.6722
( Linear move to (91.53, 93.6315, 4.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 4.6). )
G1 X91.53 Y87.6918 Z4.6 F1367.465 E141.8496
( Linear move to (93.3935, 87.9968, 4.6). )
G1 X93.3935 Y87.9968 Z4.6 F1367.465 E141.906
( Linear move to (93.7541, 87.6361, 4.6). )
G1 X93.7541 Y87.6361 Z4.6 F1367.465 E141.9213
( Linear move to (93.8649, 85.6397, 4.6). )
G1 X93.8649 Y85.6397 Z4.6 F1367.465 E141.981
( Linear move to (94.2255, 85.2791, 4.6). )
G1 X94.2255 Y85.2791 Z4.6 F1367.465 E141.9962
( Linear move to (96.2219, 85.1683, 4.6). )
G1 X96.2219 Y85.1683 Z4.6 F1367.465 E142.056
( Linear move to (96.5825, 84.8077, 4.6). )
G1 X96.5825 Y84.8077 Z4.6 F1367.465 E142.0712
( Linear move to (103.6315, 82.13, 4.6). )
G1 X103.6315 Y82.13 Z4.6 F1367.465 E142.2964
( Linear move to (104.48, 81.53, 4.6). )
G1 X104.48 Y81.53 Z4.6 F1367.465 E142.3275
( Linear move to (93.4491, 81.53, 4.6). )
G1 X93.4491 Y81.53 Z4.6 F1367.465 E142.657
( Linear move to (93.4491, 82.13, 4.6). )
G1 X93.4491 Y82.13 Z4.6 F1367.465 E142.6749
( Linear move to (92.13, 86.8432, 4.6). )
G1 X92.13 Y86.8432 Z4.6 F1367.465 E142.8211
( Linear move to (91.53, 85.9947, 4.6). )
G1 X91.53 Y85.9947 Z4.6 F1367.465 E142.8522
( Linear move to (91.53, 82.6006, 4.6). )
G1 X91.53 Y82.6006 Z4.6 F1367.465 E142.9536
( Linear move to (92.6006, 81.53, 4.6). )
G1 X92.6006 Y81.53 Z4.6 F1367.465 E142.9988
( Linear move to (92.6006, 81.53, 4.6). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 4.6). )
G1 E141.9988
( Linear move to (92.6006, 81.53, 4.6). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 4.6). )
G1 X108.47 Y97.0561 Z4.6 F6000.0
( Linear move to (108.47, 97.0561, 4.6). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 4.6). )
G1 E142.9988
( Linear move to (108.47, 97.0561, 4.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 4.6). )
G1 X108.47 Y97.9047 Z4.6 F1367.465 E143.0242
( Linear move to (107.9047, 98.47, 4.6). )
G1 X107.9047 Y98.47 Z4.6 F1367.465 E143.048
( Linear move to (105.3591, 98.47, 4.6). )
G1 X105.3591 Y98.47 Z4.6 F1367.465 E143.1241
( Linear move to (105.1786, 96.9534, 4.6). )
G1 X105.1786 Y96.9534 Z4.6 F1367.465 E143.1697
( Linear move to (105.5392, 96.5928, 4.6). )
G1 X105.5392 Y96.5928 Z4.6 F1367.465 E143.1849
( Linear move to (108.47, 96.2076, 4.6). )
G1 X108.47 Y96.2076 Z4.6 F1367.465 E143.2732
( Linear move to (108.47, 89.4194, 4.6). )
G1 X108.47 Y89.4194 Z4.6 F1367.465 E143.476
( Linear move to (106.9534, 89.5217, 4.6). )
G1 X106.9534 Y89.5217 Z4.6 F1367.465 E143.5214
( Linear move to (106.5928, 89.8824, 4.6). )
G1 X106.5928 Y89.8824 Z4.6 F1367.465 E143.5367
( Linear move to (106.482, 91.8788, 4.6). )
G1 X106.482 Y91.8788 Z4.6 F1367.465 E143.5964
( Linear move to (106.1214, 92.2394, 4.6). )
G1 X106.1214 Y92.2394 Z4.6 F1367.465 E143.6116
( Linear move to (104.125, 92.3502, 4.6). )
G1 X104.125 Y92.3502 Z4.6 F1367.465 E143.6714
( Linear move to (103.7644, 92.7108, 4.6). )
G1 X103.7644 Y92.7108 Z4.6 F1367.465 E143.6866
( Linear move to (103.6536, 94.7072, 4.6). )
G1 X103.6536 Y94.7072 Z4.6 F1367.465 E143.7463
( Linear move to (103.293, 95.0678, 4.6). )
G1 X103.293 Y95.0678 Z4.6 F1367.465 E143.7616
( Linear move to (101.2966, 95.1786, 4.6). )
G1 X101.2966 Y95.1786 Z4.6 F1367.465 E143.8213
( Linear move to (100.936, 95.5392, 4.6). )
G1 X100.936 Y95.5392 Z4.6 F1367.465 E143.8365
( Linear move to (100.6449, 97.7159, 4.6). )
G1 X100.6449 Y97.7159 Z4.6 F1367.465 E143.9021
( Linear move to (104.5106, 97.87, 4.6). )
G1 X104.5106 Y97.87 Z4.6 F1367.465 E144.0177
( Linear move to (103.662, 98.47, 4.6). )
G1 X103.662 Y98.47 Z4.6 F1367.465 E144.0487
( Linear move to (98.5709, 98.47, 4.6). )
G1 X98.5709 Y98.47 Z4.6 F1367.465 E144.2008
( Linear move to (98.4682, 98.007, 4.6). )
G1 X98.4682 Y98.007 Z4.6 F1367.465 E144.215
( Linear move to (98.1075, 98.3676, 4.6). )
G1 X98.1075 Y98.3676 Z4.6 F1367.465 E144.2302
( Linear move to (97.7223, 98.47, 4.6). )
G1 X97.7223 Y98.47 Z4.6 F1367.465 E144.2421
( Linear move to (94.3282, 98.47, 4.6). )
G1 X94.3282 Y98.47 Z4.6 F1367.465 E144.3435
( Linear move to (93.8649, 96.9534, 4.6). )
G1 X93.8649 Y96.9534 Z4.6 F1367.465 E144.3909
( Linear move to (94.2255, 96.5928, 4.6). )
G1 X94.2255 Y96.5928 Z4.6 F1367.465 E144.4061
( Linear move to (96.2219, 96.482, 4.6). )
G1 X96.2219 Y96.482 Z4.6 F1367.465 E144.4659
( Linear move to (96.5825, 96.1214, 4.6). )
G1 X96.5825 Y96.1214 Z4.6 F1367.465 E144.4811
( Linear move to (96.6933, 94.125, 4.6). )
G1 X96.6933 Y94.125 Z4.6 F1367.465 E144.5408
( Linear move to (97.0539, 93.7644, 4.6). )
G1 X97.0539 Y93.7644 Z4.6 F1367.465 E144.556
( Linear move to (99.0503, 93.6536, 4.6). )
G1 X99.0503 Y93.6536 Z4.6 F1367.465 E144.6158
( Linear move to (99.411, 93.293, 4.6). )
G1 X99.411 Y93.293 Z4.6 F1367.465 E144.631
( Linear move to (99.5217, 91.2966, 4.6). )
G1 X99.5217 Y91.2966 Z4.6 F1367.465 E144.6907
( Linear move to (99.8824, 90.936, 4.6). )
G1 X99.8824 Y90.936 Z4.6 F1367.465 E144.706
( Linear move to (101.8788, 90.8252, 4.6). )
G1 X101.8788 Y90.8252 Z4.6 F1367.465 E144.7657
( Linear move to (102.2394, 90.4646, 4.6). )
G1 X102.2394 Y90.4646 Z4.6 F1367.465 E144.7809
( Linear move to (102.3502, 88.4682, 4.6). )
G1 X102.3502 Y88.4682 Z4.6 F1367.465 E144.8407
( Linear move to (102.7108, 88.1075, 4.6). )
G1 X102.7108 Y88.1075 Z4.6 F1367.465 E144.8559
( Linear move to (104.7072, 87.9968, 4.6). )
G1 X104.7072 Y87.9968 Z4.6 F1367.465 E144.9156
( Linear move to (105.0678, 87.6361, 4.6). )
G1 X105.0678 Y87.6361 Z4.6 F1367.465 E144.9309
( Linear move to (105.1786, 85.6397, 4.6). )
G1 X105.1786 Y85.6397 Z4.6 F1367.465 E144.9906
( Linear move to (105.5392, 85.2791, 4.6). )
G1 X105.5392 Y85.2791 Z4.6 F1367.465 E145.0058
( Linear move to (108.47, 88.5709, 4.6). )
G1 X108.47 Y88.5709 Z4.6 F1367.465 E145.1375
( Linear move to (108.3887, 81.8639, 4.6). )
G1 X108.3887 Y81.8639 Z4.6 F1367.465 E145.3379
( Linear move to (107.8741, 81.53, 4.6). )
G1 X107.8741 Y81.53 Z4.6 F1367.465 E145.3562
( Linear move to (106.1771, 81.53, 4.6). )
G1 X106.1771 Y81.53 Z4.6 F1367.465 E145.4069
( Linear move to (103.293, 83.7541, 4.6). )
G1 X103.293 Y83.7541 Z4.6 F1367.465 E145.5157
( Linear move to (101.2966, 83.8649, 4.6). )
G1 X101.2966 Y83.8649 Z4.6 F1367.465 E145.5754
( Linear move to (100.936, 84.2255, 4.6). )
G1 X100.936 Y84.2255 Z4.6 F1367.465 E145.5906
( Linear move to (100.8252, 86.2219, 4.6). )
G1 X100.8252 Y86.2219 Z4.6 F1367.465 E145.6504
( Linear move to (100.4646, 86.5825, 4.6). )
G1 X100.4646 Y86.5825 Z4.6 F1367.465 E145.6656
( Linear move to (98.4682, 86.6933, 4.6). )
G1 X98.4682 Y86.6933 Z4.6 F1367.465 E145.7253
( Linear move to (98.1075, 87.0539, 4.6). )
G1 X98.1075 Y87.0539 Z4.6 F1367.465 E145.7406
( Linear move to (97.9968, 89.0503, 4.6). )
G1 X97.9968 Y89.0503 Z4.6 F1367.465 E145.8003
( Linear move to (97.6361, 89.411, 4.6). )
G1 X97.6361 Y89.411 Z4.6 F1367.465 E145.8155
( Linear move to (95.6397, 89.5217, 4.6). )
G1 X95.6397 Y89.5217 Z4.6 F1367.465 E145.8753
( Linear move to (95.2791, 89.8824, 4.6). )
G1 X95.2791 Y89.8824 Z4.6 F1367.465 E145.8905
( Linear move to (95.1683, 91.8788, 4.6). )
G1 X95.1683 Y91.8788 Z4.6 F1367.465 E145.9502
( Linear move to (94.8077, 92.2394, 4.6). )
G1 X94.8077 Y92.2394 Z4.6 F1367.465 E145.9655
( Linear move to (92.8113, 92.3502, 4.6). )
G1 X92.8113 Y92.3502 Z4.6 F1367.465 E146.0252
( Linear move to (92.4507, 92.7108, 4.6). )
G1 X92.4507 Y92.7108 Z4.6 F1367.465 E146.0404
( Linear move to (91.53, 94.48, 4.6). )
G1 X91.53 Y94.48 Z4.6 F1367.465 E146.1
( Linear move to (92.3399, 94.7072, 4.6). )
G1 X92.3399 Y94.7072 Z4.6 F1367.465 E146.1251
( Linear move to (91.9793, 95.0678, 4.6). )
G1 X91.9793 Y95.0678 Z4.6 F1367.465 E146.1404
( Linear move to (91.53, 95.3285, 4.6). )
G1 X91.53 Y95.3285 Z4.6 F1367.465 E146.1559
( Linear move to (91.53, 97.8741, 4.6). )
G1 X91.53 Y97.8741 Z4.6 F1367.465 E146.2319
( Linear move to (91.8639, 98.3887, 4.6). )
G1 X91.8639 Y98.3887 Z4.6 F1367.465 E146.2503
( Linear move to (93.4797, 98.47, 4.6). )
G1 X93.4797 Y98.47 Z4.6 F1367.465 E146.2986
( Linear move to (93.4797, 98.47, 4.6). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 4.6). )
G1 E145.2986
( Linear move to (93.4797, 98.47, 4.6). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 5.0 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z5.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z5.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z5.0 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z5.0 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 5.0). )
G1 X90.36 Y80.36 Z5.0 F2757.1641
( Linear move to (90.36, 80.36, 5.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.0). )
G1 E146.2986
( Linear move to (90.36, 80.36, 5.0). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 5.0). )
G1 X109.64 Y80.36 Z5.0 F1205.9536 E146.8747
( Linear move to (109.64, 99.64, 5.0). )
G1 X109.64 Y99.64 Z5.0 F1205.9536 E147.4508
( Linear move to (90.36, 99.64, 5.0). )
G1 X90.36 Y99.64 Z5.0 F1205.9536 E148.0268
( Linear move to (90.36, 80.36, 5.0). )
G1 X90.36 Y80.36 Z5.0 F1205.9536 E148.6029
( Linear move to (90.36, 80.36, 5.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.0). )
G1 E148.6029
( Linear move to (90.36, 80.36, 5.0). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 5.0). )
G1 X91.02 Y81.02 Z5.0 F6000.0
( Linear move to (91.02, 81.02, 5.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.0). )
G1 E148.6029
( Linear move to (91.02, 81.02, 5.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 5.0). )
G1 X108.98 Y81.02 Z5.0 F1607.9381 E149.1395
( Linear move to (108.98, 98.98, 5.0). )
G1 X108.98 Y98.98 Z5.0 F1607.9381 E149.676
( Linear move to (91.02, 98.98, 5.0). )
G1 X91.02 Y98.98 Z5.0 F1607.9381 E150.2126
( Linear move to (91.02, 81.02, 5.0). )
G1 X91.02 Y81.02 Z5.0 F1607.9381 E150.7491
( Linear move to (91.02, 81.02, 5.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.0). )
G1 E150.298
( Linear move to (91.02, 81.02, 5.0). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z4.8 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z4.8 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z4.8 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z4.8 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 5.0). )
G1 X92.3785 Y81.53 Z5.0 F6000.0
( Linear move to (92.3785, 81.53, 5.0). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 5.0). )
G1 E150.7491
( Linear move to (92.3785, 81.53, 5.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 5.0). )
G1 X91.7376 Y81.7376 Z5.0 F1607.9381 E150.7693
( Linear move to (91.53, 82.3785, 5.0). )
G1 X91.53 Y82.3785 Z5.0 F1607.9381 E150.7894
( Linear move to (92.3219, 83.4115, 5.0). )
G1 X92.3219 Y83.4115 Z5.0 F1607.9381 E150.8283
( Linear move to (94.2075, 85.2971, 5.0). )
G1 X94.2075 Y85.2971 Z5.0 F1607.9381 E150.9079
( Linear move to (96.2399, 85.1503, 5.0). )
G1 X96.2399 Y85.1503 Z5.0 F1607.9381 E150.9688
( Linear move to (98.1256, 87.0359, 5.0). )
G1 X98.1256 Y87.0359 Z5.0 F1607.9381 E151.0485
( Linear move to (97.9787, 89.0684, 5.0). )
G1 X97.9787 Y89.0684 Z5.0 F1607.9381 E151.1093
( Linear move to (99.8643, 90.954, 5.0). )
G1 X99.8643 Y90.954 Z5.0 F1607.9381 E151.189
( Linear move to (101.8968, 90.8071, 5.0). )
G1 X101.8968 Y90.8071 Z5.0 F1607.9381 E151.2499
( Linear move to (103.7824, 92.6928, 5.0). )
G1 X103.7824 Y92.6928 Z5.0 F1607.9381 E151.3296
( Linear move to (103.6356, 94.7252, 5.0). )
G1 X103.6356 Y94.7252 Z5.0 F1607.9381 E151.3904
( Linear move to (107.6215, 98.47, 5.0). )
G1 X107.6215 Y98.47 Z5.0 F1607.9381 E151.5538
( Linear move to (108.2624, 98.2624, 5.0). )
G1 X108.2624 Y98.2624 Z5.0 F1607.9381 E151.574
( Linear move to (108.47, 97.6215, 5.0). )
G1 X108.47 Y97.6215 Z5.0 F1607.9381 E151.5941
( Linear move to (108.47, 93.3788, 5.0). )
G1 X108.47 Y93.3788 Z5.0 F1607.9381 E151.7208
( Linear move to (106.1394, 92.2214, 5.0). )
G1 X106.1394 Y92.2214 Z5.0 F1607.9381 E151.7986
( Linear move to (104.107, 92.3682, 5.0). )
G1 X104.107 Y92.3682 Z5.0 F1607.9381 E151.8594
( Linear move to (102.2214, 90.4826, 5.0). )
G1 X102.2214 Y90.4826 Z5.0 F1607.9381 E151.9391
( Linear move to (102.3682, 88.4501, 5.0). )
G1 X102.3682 Y88.4501 Z5.0 F1607.9381 E152.0
( Linear move to (100.4826, 86.5645, 5.0). )
G1 X100.4826 Y86.5645 Z5.0 F1607.9381 E152.0797
( Linear move to (98.4501, 86.7113, 5.0). )
G1 X98.4501 Y86.7113 Z5.0 F1607.9381 E152.1405
( Linear move to (93.2271, 81.53, 5.0). )
G1 X93.2271 Y81.53 Z5.0 F1607.9381 E152.3603
( Linear move to (97.4697, 81.53, 5.0). )
G1 X97.4697 Y81.53 Z5.0 F1607.9381 E152.4871
( Linear move to (96.8736, 82.631, 5.0). )
G1 X96.8736 Y82.631 Z5.0 F1607.9381 E152.5245
( Linear move to (98.6819, 82.0072, 5.0). )
G1 X98.6819 Y82.0072 Z5.0 F1607.9381 E152.5816
( Linear move to (99.1668, 81.53, 5.0). )
G1 X99.1668 Y81.53 Z5.0 F1607.9381 E152.6019
( Linear move to (100.954, 84.2075, 5.0). )
G1 X100.954 Y84.2075 Z5.0 F1607.9381 E152.6981
( Linear move to (100.8071, 86.2399, 5.0). )
G1 X100.8071 Y86.2399 Z5.0 F1607.9381 E152.759
( Linear move to (102.6928, 88.1256, 5.0). )
G1 X102.6928 Y88.1256 Z5.0 F1607.9381 E152.8387
( Linear move to (104.7252, 87.9787, 5.0). )
G1 X104.7252 Y87.9787 Z5.0 F1607.9381 E152.8995
( Linear move to (106.6108, 89.8643, 5.0). )
G1 X106.6108 Y89.8643 Z5.0 F1607.9381 E152.9792
( Linear move to (106.464, 91.8968, 5.0). )
G1 X106.464 Y91.8968 Z5.0 F1607.9381 E153.0401
( Linear move to (108.47, 92.5303, 5.0). )
G1 X108.47 Y92.5303 Z5.0 F1607.9381 E153.1029
( Linear move to (108.47, 88.2877, 5.0). )
G1 X108.47 Y88.2877 Z5.0 F1607.9381 E153.2297
( Linear move to (106.9354, 89.5398, 5.0). )
G1 X106.9354 Y89.5398 Z5.0 F1607.9381 E153.2888
( Linear move to (105.0498, 87.6542, 5.0). )
G1 X105.0498 Y87.6542 Z5.0 F1607.9381 E153.3685
( Linear move to (105.1966, 85.6217, 5.0). )
G1 X105.1966 Y85.6217 Z5.0 F1607.9381 E153.4294
( Linear move to (103.311, 83.7361, 5.0). )
G1 X103.311 Y83.7361 Z5.0 F1607.9381 E153.509
( Linear move to (101.2786, 83.8829, 5.0). )
G1 X101.2786 Y83.8829 Z5.0 F1607.9381 E153.5699
( Linear move to (100.0153, 81.53, 5.0). )
G1 X100.0153 Y81.53 Z5.0 F1607.9381 E153.6497
( Linear move to (105.1065, 81.53, 5.0). )
G1 X105.1065 Y81.53 Z5.0 F1607.9381 E153.8018
( Linear move to (103.6356, 83.4115, 5.0). )
G1 X103.6356 Y83.4115 Z5.0 F1607.9381 E153.8732
( Linear move to (105.5212, 85.2971, 5.0). )
G1 X105.5212 Y85.2971 Z5.0 F1607.9381 E153.9528
( Linear move to (108.47, 87.4391, 5.0). )
G1 X108.47 Y87.4391 Z5.0 F1607.9381 E154.0617
( Linear move to (108.47, 83.1965, 5.0). )
G1 X108.47 Y83.1965 Z5.0 F1607.9381 E154.1884
( Linear move to (105.955, 81.53, 5.0). )
G1 X105.955 Y81.53 Z5.0 F1607.9381 E154.2786
( Linear move to (107.652, 81.53, 5.0). )
G1 X107.652 Y81.53 Z5.0 F1607.9381 E154.3293
( Linear move to (108.47, 82.348, 5.0). )
G1 X108.47 Y82.348 Z5.0 F1607.9381 E154.3638
( Linear move to (108.47, 82.348, 5.0). )
G1 F1200.0
( Linear move to (108.47, 82.348, 5.0). )
G1 E153.3638
( Linear move to (108.47, 82.348, 5.0). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 5.0). )
G1 X106.7729 Y98.47 Z5.0 F6000.0
( Linear move to (106.7729, 98.47, 5.0). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 5.0). )
G1 E154.3638
( Linear move to (106.7729, 98.47, 5.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 5.0). )
G1 X105.0759 Y98.47 Z5.0 F1607.9381 E154.4145
( Linear move to (105.1966, 96.9354, 5.0). )
G1 X105.1966 Y96.9354 Z5.0 F1607.9381 E154.4605
( Linear move to (103.311, 95.0498, 5.0). )
G1 X103.311 Y95.0498 Z5.0 F1607.9381 E154.5402
( Linear move to (101.2786, 95.1966, 5.0). )
G1 X101.2786 Y95.1966 Z5.0 F1607.9381 E154.6011
( Linear move to (99.3929, 93.311, 5.0). )
G1 X99.3929 Y93.311 Z5.0 F1607.9381 E154.6807
( Linear move to (99.5398, 91.2786, 5.0). )
G1 X99.5398 Y91.2786 Z5.0 F1607.9381 E154.7416
( Linear move to (97.6542, 89.3929, 5.0). )
G1 X97.6542 Y89.3929 Z5.0 F1607.9381 E154.8213
( Linear move to (95.6217, 89.5398, 5.0). )
G1 X95.6217 Y89.5398 Z5.0 F1607.9381 E154.8822
( Linear move to (93.7361, 87.6542, 5.0). )
G1 X93.7361 Y87.6542 Z5.0 F1607.9381 E154.9618
( Linear move to (93.8829, 85.6217, 5.0). )
G1 X93.8829 Y85.6217 Z5.0 F1607.9381 E155.0227
( Linear move to (91.53, 83.2271, 5.0). )
G1 X91.53 Y83.2271 Z5.0 F1607.9381 E155.123
( Linear move to (91.53, 88.3182, 5.0). )
G1 X91.53 Y88.3182 Z5.0 F1607.9381 E155.2751
( Linear move to (93.4115, 87.9787, 5.0). )
G1 X93.4115 Y87.9787 Z5.0 F1607.9381 E155.3322
( Linear move to (95.2971, 89.8643, 5.0). )
G1 X95.2971 Y89.8643 Z5.0 F1607.9381 E155.4119
( Linear move to (95.1503, 91.8968, 5.0). )
G1 X95.1503 Y91.8968 Z5.0 F1607.9381 E155.4727
( Linear move to (97.0359, 93.7824, 5.0). )
G1 X97.0359 Y93.7824 Z5.0 F1607.9381 E155.5524
( Linear move to (99.0684, 93.6356, 5.0). )
G1 X99.0684 Y93.6356 Z5.0 F1607.9381 E155.6133
( Linear move to (100.954, 95.5212, 5.0). )
G1 X100.954 Y95.5212 Z5.0 F1607.9381 E155.693
( Linear move to (100.8071, 97.5537, 5.0). )
G1 X100.8071 Y97.5537 Z5.0 F1607.9381 E155.7538
( Linear move to (103.3788, 97.87, 5.0). )
G1 X103.3788 Y97.87 Z5.0 F1607.9381 E155.8312
( Linear move to (104.2274, 98.47, 5.0). )
G1 X104.2274 Y98.47 Z5.0 F1607.9381 E155.8623
( Linear move to (99.9847, 98.47, 5.0). )
G1 X99.9847 Y98.47 Z5.0 F1607.9381 E155.989
( Linear move to (100.4826, 97.8782, 5.0). )
G1 X100.4826 Y97.8782 Z5.0 F1607.9381 E156.0121
( Linear move to (99.3259, 97.9008, 5.0). )
G1 X99.3259 Y97.9008 Z5.0 F1607.9381 E156.0467
( Linear move to (98.2878, 98.1873, 5.0). )
G1 X98.2878 Y98.1873 Z5.0 F1607.9381 E156.0789
( Linear move to (96.5645, 96.1394, 5.0). )
G1 X96.5645 Y96.1394 Z5.0 F1607.9381 E156.1588
( Linear move to (96.7113, 94.107, 5.0). )
G1 X96.7113 Y94.107 Z5.0 F1607.9381 E156.2197
( Linear move to (94.8257, 92.2214, 5.0). )
G1 X94.8257 Y92.2214 Z5.0 F1607.9381 E156.2994
( Linear move to (92.7933, 92.3682, 5.0). )
G1 X92.7933 Y92.3682 Z5.0 F1607.9381 E156.3603
( Linear move to (92.13, 89.1668, 5.0). )
G1 X92.13 Y89.1668 Z5.0 F1607.9381 E156.4579
( Linear move to (91.53, 90.0153, 5.0). )
G1 X91.53 Y90.0153 Z5.0 F1607.9381 E156.489
( Linear move to (91.53, 92.5609, 5.0). )
G1 X91.53 Y92.5609 Z5.0 F1607.9381 E156.565
( Linear move to (92.4687, 92.6928, 5.0). )
G1 X92.4687 Y92.6928 Z5.0 F1607.9381 E156.5933
( Linear move to (91.53, 93.4094, 5.0). )
G1 X91.53 Y93.4094 Z5.0 F1607.9381 E156.6286
( Linear move to (91.53, 95.1065, 5.0). )
G1 X91.53 Y95.1065 Z5.0 F1607.9381 E156.6793
( Linear move to (92.1596, 94.8875, 5.0). )
G1 X92.1596 Y94.8875 Z5.0 F1607.9381 E156.6992
( Linear move to (94.2075, 96.6108, 5.0). )
G1 X94.2075 Y96.6108 Z5.0 F1607.9381 E156.7792
( Linear move to (96.2399, 96.464, 5.0). )
G1 X96.2399 Y96.464 Z5.0 F1607.9381 E156.8401
( Linear move to (97.4391, 98.47, 5.0). )
G1 X97.4391 Y98.47 Z5.0 F1607.9381 E156.9099
( Linear move to (94.045, 98.47, 5.0). )
G1 X94.045 Y98.47 Z5.0 F1607.9381 E157.0113
( Linear move to (93.8829, 96.9354, 5.0). )
G1 X93.8829 Y96.9354 Z5.0 F1607.9381 E157.0574
( Linear move to (91.53, 95.955, 5.0). )
G1 X91.53 Y95.955 Z5.0 F1607.9381 E157.1335
( Linear move to (91.53, 97.652, 5.0). )
G1 X91.53 Y97.652 Z5.0 F1607.9381 E157.1842
( Linear move to (92.348, 98.47, 5.0). )
G1 X92.348 Y98.47 Z5.0 F1607.9381 E157.2188
( Linear move to (93.1965, 98.47, 5.0). )
G1 X93.1965 Y98.47 Z5.0 F1607.9381 E157.2442
( Linear move to (93.1965, 98.47, 5.0). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 5.0). )
G1 E156.2442
( Linear move to (93.1965, 98.47, 5.0). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 5.4 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z5.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z5.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z5.4 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z5.4 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 5.4). )
G1 X90.36 Y80.36 Z5.4 F2750.2729
( Linear move to (90.36, 80.36, 5.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.4). )
G1 E157.2442
( Linear move to (90.36, 80.36, 5.4). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 5.4). )
G1 X109.64 Y80.36 Z5.4 F1025.5987 E157.8204
( Linear move to (109.64, 99.64, 5.4). )
G1 X109.64 Y99.64 Z5.4 F1025.5987 E158.3967
( Linear move to (90.36, 99.64, 5.4). )
G1 X90.36 Y99.64 Z5.4 F1025.5987 E158.973
( Linear move to (90.36, 80.36, 5.4). )
G1 X90.36 Y80.36 Z5.4 F1025.5987 E159.5493
( Linear move to (90.36, 80.36, 5.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.4). )
G1 E159.5493
( Linear move to (90.36, 80.36, 5.4). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 5.4). )
G1 X91.02 Y81.02 Z5.4 F6000.0
( Linear move to (91.02, 81.02, 5.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.4). )
G1 E159.5493
( Linear move to (91.02, 81.02, 5.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 5.4). )
G1 X108.98 Y81.02 Z5.4 F1367.465 E160.0858
( Linear move to (108.98, 98.98, 5.4). )
G1 X108.98 Y98.98 Z5.4 F1367.465 E160.6223
( Linear move to (91.02, 98.98, 5.4). )
G1 X91.02 Y98.98 Z5.4 F1367.465 E161.1588
( Linear move to (91.02, 81.02, 5.4). )
G1 X91.02 Y81.02 Z5.4 F1367.465 E161.6953
( Linear move to (91.02, 81.02, 5.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.4). )
G1 E160.6953
( Linear move to (91.02, 81.02, 5.4). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z5.2 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z5.2 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z5.2 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z5.2 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 5.4). )
G1 X91.53 Y93.6315 Z5.4 F6000.0
( Linear move to (91.53, 93.6315, 5.4). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 5.4). )
G1 E161.6953
( Linear move to (91.53, 93.6315, 5.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 5.4). )
G1 X91.53 Y87.6918 Z5.4 F1367.465 E161.8728
( Linear move to (93.3935, 87.9968, 5.4). )
G1 X93.3935 Y87.9968 Z5.4 F1367.465 E161.9292
( Linear move to (93.7541, 87.6361, 5.4). )
G1 X93.7541 Y87.6361 Z5.4 F1367.465 E161.9444
( Linear move to (93.8649, 85.6397, 5.4). )
G1 X93.8649 Y85.6397 Z5.4 F1367.465 E162.0041
( Linear move to (94.2255, 85.2791, 5.4). )
G1 X94.2255 Y85.2791 Z5.4 F1367.465 E162.0194
( Linear move to (96.2219, 85.1683, 5.4). )
G1 X96.2219 Y85.1683 Z5.4 F1367.465 E162.0791
( Linear move to (96.5825, 84.8077, 5.4). )
G1 X96.5825 Y84.8077 Z5.4 F1367.465 E162.0943
( Linear move to (103.6315, 82.13, 5.4). )
G1 X103.6315 Y82.13 Z5.4 F1367.465 E162.3196
( Linear move to (104.48, 81.53, 5.4). )
G1 X104.48 Y81.53 Z5.4 F1367.465 E162.3506
( Linear move to (93.4491, 81.53, 5.4). )
G1 X93.4491 Y81.53 Z5.4 F1367.465 E162.6802
( Linear move to (93.4491, 82.13, 5.4). )
G1 X93.4491 Y82.13 Z5.4 F1367.465 E162.6981
( Linear move to (92.13, 86.8432, 5.4). )
G1 X92.13 Y86.8432 Z5.4 F1367.465 E162.8443
( Linear move to (91.53, 85.9947, 5.4). )
G1 X91.53 Y85.9947 Z5.4 F1367.465 E162.8753
( Linear move to (91.53, 82.6006, 5.4). )
G1 X91.53 Y82.6006 Z5.4 F1367.465 E162.9767
( Linear move to (92.6006, 81.53, 5.4). )
G1 X92.6006 Y81.53 Z5.4 F1367.465 E163.022
( Linear move to (92.6006, 81.53, 5.4). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 5.4). )
G1 E162.022
( Linear move to (92.6006, 81.53, 5.4). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 5.4). )
G1 X108.47 Y97.0561 Z5.4 F6000.0
( Linear move to (108.47, 97.0561, 5.4). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 5.4). )
G1 E163.022
( Linear move to (108.47, 97.0561, 5.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 5.4). )
G1 X108.47 Y97.9047 Z5.4 F1367.465 E163.0473
( Linear move to (107.9047, 98.47, 5.4). )
G1 X107.9047 Y98.47 Z5.4 F1367.465 E163.0712
( Linear move to (105.3591, 98.47, 5.4). )
G1 X105.3591 Y98.47 Z5.4 F1367.465 E163.1472
( Linear move to (105.1786, 96.9534, 5.4). )
G1 X105.1786 Y96.9534 Z5.4 F1367.465 E163.1929
( Linear move to (105.5392, 96.5928, 5.4). )
G1 X105.5392 Y96.5928 Z5.4 F1367.465 E163.2081
( Linear move to (108.47, 96.2076, 5.4). )
G1 X108.47 Y96.2076 Z5.4 F1367.465 E163.2964
( Linear move to (108.47, 89.4194, 5.4). )
G1 X108.47 Y89.4194 Z5.4 F1367.465 E163.4992
( Linear move to (106.9534, 89.5217, 5.4). )
G1 X106.9534 Y89.5217 Z5.4 F1367.465 E163.5446
( Linear move to (106.5928, 89.8824, 5.4). )
G1 X106.5928 Y89.8824 Z5.4 F1367.465 E163.5598
( Linear move to (106.482, 91.8788, 5.4). )
G1 X106.482 Y91.8788 Z5.4 F1367.465 E163.6195
( Linear move to (106.1214, 92.2394, 5.4). )
G1 X106.1214 Y92.2394 Z5.4 F1367.465 E163.6348
( Linear move to (104.125, 92.3502, 5.4). )
G1 X104.125 Y92.3502 Z5.4 F1367.465 E163.6945
( Linear move to (103.7644, 92.7108, 5.4). )
G1 X103.7644 Y92.7108 Z5.4 F1367.465 E163.7097
( Linear move to (103.6536, 94.7072, 5.4). )
G1 X103.6536 Y94.7072 Z5.4 F1367.465 E163.7695
( Linear move to (103.293, 95.0678, 5.4). )
G1 X103.293 Y95.0678 Z5.4 F1367.465 E163.7847
( Linear move to (101.2966, 95.1786, 5.4). )
G1 X101.2966 Y95.1786 Z5.4 F1367.465 E163.8444
( Linear move to (100.936, 95.5392, 5.4). )
G1 X100.936 Y95.5392 Z5.4 F1367.465 E163.8597
( Linear move to (100.6449, 97.7159, 5.4). )
G1 X100.6449 Y97.7159 Z5.4 F1367.465 E163.9253
( Linear move to (104.5106, 97.87, 5.4). )
G1 X104.5106 Y97.87 Z5.4 F1367.465 E164.0408
( Linear move to (103.662, 98.47, 5.4). )
G1 X103.662 Y98.47 Z5.4 F1367.465 E164.0719
( Linear move to (98.5709, 98.47, 5.4). )
G1 X98.5709 Y98.47 Z5.4 F1367.465 E164.224
( Linear move to (98.4682, 98.007, 5.4). )
G1 X98.4682 Y98.007 Z5.4 F1367.465 E164.2381
( Linear move to (98.1075, 98.3676, 5.4). )
G1 X98.1075 Y98.3676 Z5.4 F1367.465 E164.2534
( Linear move to (97.7223, 98.47, 5.4). )
G1 X97.7223 Y98.47 Z5.4 F1367.465 E164.2653
( Linear move to (94.3282, 98.47, 5.4). )
G1 X94.3282 Y98.47 Z5.4 F1367.465 E164.3667
( Linear move to (93.8649, 96.9534, 5.4). )
G1 X93.8649 Y96.9534 Z5.4 F1367.465 E164.414
( Linear move to (94.2255, 96.5928, 5.4). )
G1 X94.2255 Y96.5928 Z5.4 F1367.465 E164.4293
( Linear move to (96.2219, 96.482, 5.4). )
G1 X96.2219 Y96.482 Z5.4 F1367.465 E164.489
( Linear move to (96.5825, 96.1214, 5.4). )
G1 X96.5825 Y96.1214 Z5.4 F1367.465 E164.5042
( Linear move to (96.6933, 94.125, 5.4). )
G1 X96.6933 Y94.125 Z5.4 F1367.465 E164.564
( Linear move to (97.0539, 93.7644, 5.4). )
G1 X97.0539 Y93.7644 Z5.4 F1367.465 E164.5792
( Linear move to (99.0503, 93.6536, 5.4). )
G1 X99.0503 Y93.6536 Z5.4 F1367.465 E164.6389
( Linear move to (99.411, 93.293, 5.4). )
G1 X99.411 Y93.293 Z5.4 F1367.465 E164.6542
( Linear move to (99.5217, 91.2966, 5.4). )
G1 X99.5217 Y91.2966 Z5.4 F1367.465 E164.7139
( Linear move to (99.8824, 90.936, 5.4). )
G1 X99.8824 Y90.936 Z5.4 F1367.465 E164.7291
( Linear move to (101.8788, 90.8252, 5.4). )
G1 X101.8788 Y90.8252 Z5.4 F1367.465 E164.7889
( Linear move to (102.2394, 90.4646, 5.4). )
G1 X102.2394 Y90.4646 Z5.4 F1367.465 E164.8041
( Linear move to (102.3502, 88.4682, 5.4). )
G1 X102.3502 Y88.4682 Z5.4 F1367.465 E164.8638
( Linear move to (102.7108, 88.1075, 5.4). )
G1 X102.7108 Y88.1075 Z5.4 F1367.465 E164.8791
( Linear move to (104.7072, 87.9968, 5.4). )
G1 X104.7072 Y87.9968 Z5.4 F1367.465 E164.9388
( Linear move to (105.0678, 87.6361, 5.4). )
G1 X105.0678 Y87.6361 Z5.4 F1367.465 E164.954
( Linear move to (105.1786, 85.6397, 5.4). )
G1 X105.1786 Y85.6397 Z5.4 F1367.465 E165.0138
( Linear move to (105.5392, 85.2791, 5.4). )
G1 X105.5392 Y85.2791 Z5.4 F1367.465 E165.029
( Linear move to (108.47, 88.5709, 5.4). )
G1 X108.47 Y88.5709 Z5.4 F1367.465 E165.1606
( Linear move to (108.3887, 81.8639, 5.4). )
G1 X108.3887 Y81.8639 Z5.4 F1367.465 E165.361
( Linear move to (107.8741, 81.53, 5.4). )
G1 X107.8741 Y81.53 Z5.4 F1367.465 E165.3793
( Linear move to (106.1771, 81.53, 5.4). )
G1 X106.1771 Y81.53 Z5.4 F1367.465 E165.43
( Linear move to (103.293, 83.7541, 5.4). )
G1 X103.293 Y83.7541 Z5.4 F1367.465 E165.5388
( Linear move to (101.2966, 83.8649, 5.4). )
G1 X101.2966 Y83.8649 Z5.4 F1367.465 E165.5986
( Linear move to (100.936, 84.2255, 5.4). )
G1 X100.936 Y84.2255 Z5.4 F1367.465 E165.6138
( Linear move to (100.8252, 86.2219, 5.4). )
G1 X100.8252 Y86.2219 Z5.4 F1367.465 E165.6735
( Linear move to (100.4646, 86.5825, 5.4). )
G1 X100.4646 Y86.5825 Z5.4 F1367.465 E165.6888
( Linear move to (98.4682, 86.6933, 5.4). )
G1 X98.4682 Y86.6933 Z5.4 F1367.465 E165.7485
( Linear move to (98.1075, 87.0539, 5.4). )
G1 X98.1075 Y87.0539 Z5.4 F1367.465 E165.7637
( Linear move to (97.9968, 89.0503, 5.4). )
G1 X97.9968 Y89.0503 Z5.4 F1367.465 E165.8235
( Linear move to (97.6361, 89.411, 5.4). )
G1 X97.6361 Y89.411 Z5.4 F1367.465 E165.8387
( Linear move to (95.6397, 89.5217, 5.4). )
G1 X95.6397 Y89.5217 Z5.4 F1367.465 E165.8984
( Linear move to (95.2791, 89.8824, 5.4). )
G1 X95.2791 Y89.8824 Z5.4 F1367.465 E165.9137
( Linear move to (95.1683, 91.8788, 5.4). )
G1 X95.1683 Y91.8788 Z5.4 F1367.465 E165.9734
( Linear move to (94.8077, 92.2394, 5.4). )
G1 X94.8077 Y92.2394 Z5.4 F1367.465 E165.9886
( Linear move to (92.8113, 92.3502, 5.4). )
G1 X92.8113 Y92.3502 Z5.4 F1367.465 E166.0484
( Linear move to (92.4507, 92.7108, 5.4). )
G1 X92.4507 Y92.7108 Z5.4 F1367.465 E166.0636
( Linear move to (91.53, 94.48, 5.4). )
G1 X91.53 Y94.48 Z5.4 F1367.465 E166.1232
( Linear move to (92.3399, 94.7072, 5.4). )
G1 X92.3399 Y94.7072 Z5.4 F1367.465 E166.1483
( Linear move to (91.9793, 95.0678, 5.4). )
G1 X91.9793 Y95.0678 Z5.4 F1367.465 E166.1635
( Linear move to (91.53, 95.3285, 5.4). )
G1 X91.53 Y95.3285 Z5.4 F1367.465 E166.179
( Linear move to (91.53, 97.8741, 5.4). )
G1 X91.53 Y97.8741 Z5.4 F1367.465 E166.2551
( Linear move to (91.8639, 98.3887, 5.4). )
G1 X91.8639 Y98.3887 Z5.4 F1367.465 E166.2734
( Linear move to (93.4797, 98.47, 5.4). )
G1 X93.4797 Y98.47 Z5.4 F1367.465 E166.3217
( Linear move to (93.4797, 98.47, 5.4). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 5.4). )
G1 E165.3217
( Linear move to (93.4797, 98.47, 5.4). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 5.8 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z5.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z5.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z5.8 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z5.8 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 5.8). )
G1 X90.36 Y80.36 Z5.8 F2757.1641
( Linear move to (90.36, 80.36, 5.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.8). )
G1 E166.3217
( Linear move to (90.36, 80.36, 5.8). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 5.8). )
G1 X109.64 Y80.36 Z5.8 F1205.9536 E166.8978
( Linear move to (109.64, 99.64, 5.8). )
G1 X109.64 Y99.64 Z5.8 F1205.9536 E167.4739
( Linear move to (90.36, 99.64, 5.8). )
G1 X90.36 Y99.64 Z5.8 F1205.9536 E168.05
( Linear move to (90.36, 80.36, 5.8). )
G1 X90.36 Y80.36 Z5.8 F1205.9536 E168.6261
( Linear move to (90.36, 80.36, 5.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 5.8). )
G1 E168.6261
( Linear move to (90.36, 80.36, 5.8). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 5.8). )
G1 X91.02 Y81.02 Z5.8 F6000.0
( Linear move to (91.02, 81.02, 5.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.8). )
G1 E168.6261
( Linear move to (91.02, 81.02, 5.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 5.8). )
G1 X108.98 Y81.02 Z5.8 F1607.9381 E169.1626
( Linear move to (108.98, 98.98, 5.8). )
G1 X108.98 Y98.98 Z5.8 F1607.9381 E169.6992
( Linear move to (91.02, 98.98, 5.8). )
G1 X91.02 Y98.98 Z5.8 F1607.9381 E170.2357
( Linear move to (91.02, 81.02, 5.8). )
G1 X91.02 Y81.02 Z5.8 F1607.9381 E170.7723
( Linear move to (91.02, 81.02, 5.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 5.8). )
G1 E170.3212
( Linear move to (91.02, 81.02, 5.8). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z5.6 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z5.6 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z5.6 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z5.6 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 5.8). )
G1 X92.3785 Y81.53 Z5.8 F6000.0
( Linear move to (92.3785, 81.53, 5.8). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 5.8). )
G1 E170.7723
( Linear move to (92.3785, 81.53, 5.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 5.8). )
G1 X91.7376 Y81.7376 Z5.8 F1607.9381 E170.7924
( Linear move to (91.53, 82.3785, 5.8). )
G1 X91.53 Y82.3785 Z5.8 F1607.9381 E170.8125
( Linear move to (92.3219, 83.4115, 5.8). )
G1 X92.3219 Y83.4115 Z5.8 F1607.9381 E170.8514
( Linear move to (94.2075, 85.2971, 5.8). )
G1 X94.2075 Y85.2971 Z5.8 F1607.9381 E170.9311
( Linear move to (96.2399, 85.1503, 5.8). )
G1 X96.2399 Y85.1503 Z5.8 F1607.9381 E170.992
( Linear move to (98.1256, 87.0359, 5.8). )
G1 X98.1256 Y87.0359 Z5.8 F1607.9381 E171.0716
( Linear move to (97.9787, 89.0684, 5.8). )
G1 X97.9787 Y89.0684 Z5.8 F1607.9381 E171.1325
( Linear move to (99.8643, 90.954, 5.8). )
G1 X99.8643 Y90.954 Z5.8 F1607.9381 E171.2122
( Linear move to (101.8968, 90.8071, 5.8). )
G1 X101.8968 Y90.8071 Z5.8 F1607.9381 E171.273
( Linear move to (103.7824, 92.6928, 5.8). )
G1 X103.7824 Y92.6928 Z5.8 F1607.9381 E171.3527
( Linear move to (103.6356, 94.7252, 5.8). )
G1 X103.6356 Y94.7252 Z5.8 F1607.9381 E171.4136
( Linear move to (107.6215, 98.47, 5.8). )
G1 X107.6215 Y98.47 Z5.8 F1607.9381 E171.577
( Linear move to (108.2624, 98.2624, 5.8). )
G1 X108.2624 Y98.2624 Z5.8 F1607.9381 E171.5971
( Linear move to (108.47, 97.6215, 5.8). )
G1 X108.47 Y97.6215 Z5.8 F1607.9381 E171.6172
( Linear move to (108.47, 93.3788, 5.8). )
G1 X108.47 Y93.3788 Z5.8 F1607.9381 E171.744
( Linear move to (106.1394, 92.2214, 5.8). )
G1 X106.1394 Y92.2214 Z5.8 F1607.9381 E171.8217
( Linear move to (104.107, 92.3682, 5.8). )
G1 X104.107 Y92.3682 Z5.8 F1607.9381 E171.8826
( Linear move to (102.2214, 90.4826, 5.8). )
G1 X102.2214 Y90.4826 Z5.8 F1607.9381 E171.9623
( Linear move to (102.3682, 88.4501, 5.8). )
G1 X102.3682 Y88.4501 Z5.8 F1607.9381 E172.0231
( Linear move to (100.4826, 86.5645, 5.8). )
G1 X100.4826 Y86.5645 Z5.8 F1607.9381 E172.1028
( Linear move to (98.4501, 86.7113, 5.8). )
G1 X98.4501 Y86.7113 Z5.8 F1607.9381 E172.1637
( Linear move to (93.2271, 81.53, 5.8). )
G1 X93.2271 Y81.53 Z5.8 F1607.9381 E172.3835
( Linear move to (97.4697, 81.53, 5.8). )
G1 X97.4697 Y81.53 Z5.8 F1607.9381 E172.5102
( Linear move to (96.8736, 82.631, 5.8). )
G1 X96.8736 Y82.631 Z5.8 F1607.9381 E172.5476
( Linear move to (98.6819, 82.0072, 5.8). )
G1 X98.6819 Y82.0072 Z5.8 F1607.9381 E172.6048
( Linear move to (99.1668, 81.53, 5.8). )
G1 X99.1668 Y81.53 Z5.8 F1607.9381 E172.6251
( Linear move to (100.954, 84.2075, 5.8). )
G1 X100.954 Y84.2075 Z5.8 F1607.9381 E172.7213
( Linear move to (100.8071, 86.2399, 5.8). )
G1 X100.8071 Y86.2399 Z5.8 F1607.9381 E172.7821
( Linear move to (102.6928, 88.1256, 5.8). )
G1 X102.6928 Y88.1256 Z5.8 F1607.9381 E172.8618
( Linear move to (104.7252, 87.9787, 5.8). )
G1 X104.7252 Y87.9787 Z5.8 F1607.9381 E172.9227
( Linear move to (106.6108, 89.8643, 5.8). )
G1 X106.6108 Y89.8643 Z5.8 F1607.9381 E173.0023
( Linear move to (106.464, 91.8968, 5.8). )
G1 X106.464 Y91.8968 Z5.8 F1607.9381 E173.0632
( Linear move to (108.47, 92.5303, 5.8). )
G1 X108.47 Y92.5303 Z5.8 F1607.9381 E173.1261
( Linear move to (108.47, 88.2877, 5.8). )
G1 X108.47 Y88.2877 Z5.8 F1607.9381 E173.2528
( Linear move to (106.9354, 89.5398, 5.8). )
G1 X106.9354 Y89.5398 Z5.8 F1607.9381 E173.312
( Linear move to (105.0498, 87.6542, 5.8). )
G1 X105.0498 Y87.6542 Z5.8 F1607.9381 E173.3917
( Linear move to (105.1966, 85.6217, 5.8). )
G1 X105.1966 Y85.6217 Z5.8 F1607.9381 E173.4525
( Linear move to (103.311, 83.7361, 5.8). )
G1 X103.311 Y83.7361 Z5.8 F1607.9381 E173.5322
( Linear move to (101.2786, 83.8829, 5.8). )
G1 X101.2786 Y83.8829 Z5.8 F1607.9381 E173.5931
( Linear move to (100.0153, 81.53, 5.8). )
G1 X100.0153 Y81.53 Z5.8 F1607.9381 E173.6729
( Linear move to (105.1065, 81.53, 5.8). )
G1 X105.1065 Y81.53 Z5.8 F1607.9381 E173.825
( Linear move to (103.6356, 83.4115, 5.8). )
G1 X103.6356 Y83.4115 Z5.8 F1607.9381 E173.8963
( Linear move to (105.5212, 85.2971, 5.8). )
G1 X105.5212 Y85.2971 Z5.8 F1607.9381 E173.976
( Linear move to (108.47, 87.4391, 5.8). )
G1 X108.47 Y87.4391 Z5.8 F1607.9381 E174.0849
( Linear move to (108.47, 83.1965, 5.8). )
G1 X108.47 Y83.1965 Z5.8 F1607.9381 E174.2116
( Linear move to (105.955, 81.53, 5.8). )
G1 X105.955 Y81.53 Z5.8 F1607.9381 E174.3017
( Linear move to (107.652, 81.53, 5.8). )
G1 X107.652 Y81.53 Z5.8 F1607.9381 E174.3524
( Linear move to (108.47, 82.348, 5.8). )
G1 X108.47 Y82.348 Z5.8 F1607.9381 E174.387
( Linear move to (108.47, 82.348, 5.8). )
G1 F1200.0
( Linear move to (108.47, 82.348, 5.8). )
G1 E173.387
( Linear move to (108.47, 82.348, 5.8). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 5.8). )
G1 X106.7729 Y98.47 Z5.8 F6000.0
( Linear move to (106.7729, 98.47, 5.8). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 5.8). )
G1 E174.387
( Linear move to (106.7729, 98.47, 5.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 5.8). )
G1 X105.0759 Y98.47 Z5.8 F1607.9381 E174.4377
( Linear move to (105.1966, 96.9354, 5.8). )
G1 X105.1966 Y96.9354 Z5.8 F1607.9381 E174.4837
( Linear move to (103.311, 95.0498, 5.8). )
G1 X103.311 Y95.0498 Z5.8 F1607.9381 E174.5633
( Linear move to (101.2786, 95.1966, 5.8). )
G1 X101.2786 Y95.1966 Z5.8 F1607.9381 E174.6242
( Linear move to (99.3929, 93.311, 5.8). )
G1 X99.3929 Y93.311 Z5.8 F1607.9381 E174.7039
( Linear move to (99.5398, 91.2786, 5.8). )
G1 X99.5398 Y91.2786 Z5.8 F1607.9381 E174.7648
( Linear move to (97.6542, 89.3929, 5.8). )
G1 X97.6542 Y89.3929 Z5.8 F1607.9381 E174.8444
( Linear move to (95.6217, 89.5398, 5.8). )
G1 X95.6217 Y89.5398 Z5.8 F1607.9381 E174.9053
( Linear move to (93.7361, 87.6542, 5.8). )
G1 X93.7361 Y87.6542 Z5.8 F1607.9381 E174.985
( Linear move to (93.8829, 85.6217, 5.8). )
G1 X93.8829 Y85.6217 Z5.8 F1607.9381 E175.0459
( Linear move to (91.53, 83.2271, 5.8). )
G1 X91.53 Y83.2271 Z5.8 F1607.9381 E175.1461
( Linear move to (91.53, 88.3182, 5.8). )
G1 X91.53 Y88.3182 Z5.8 F1607.9381 E175.2982
( Linear move to (93.4115, 87.9787, 5.8). )
G1 X93.4115 Y87.9787 Z5.8 F1607.9381 E175.3554
( Linear move to (95.2971, 89.8643, 5.8). )
G1 X95.2971 Y89.8643 Z5.8 F1607.9381 E175.435
( Linear move to (95.1503, 91.8968, 5.8). )
G1 X95.1503 Y91.8968 Z5.8 F1607.9381 E175.4959
( Linear move to (97.0359, 93.7824, 5.8). )
G1 X97.0359 Y93.7824 Z5.8 F1607.9381 E175.5756
( Linear move to (99.0684, 93.6356, 5.8). )
G1 X99.0684 Y93.6356 Z5.8 F1607.9381 E175.6364
( Linear move to (100.954, 95.5212, 5.8). )
G1 X100.954 Y95.5212 Z5.8 F1607.9381 E175.7161
( Linear move to (100.8071, 97.5537, 5.8). )
G1 X100.8071 Y97.5537 Z5.8 F1607.9381 E175.777
( Linear move to (103.3788, 97.87, 5.8). )
G1 X103.3788 Y97.87 Z5.8 F1607.9381 E175.8544
( Linear move to (104.2274, 98.47, 5.8). )
G1 X104.2274 Y98.47 Z5.8 F1607.9381 E175.8854
( Linear move to (99.9847, 98.47, 5.8). )
G1 X99.9847 Y98.47 Z5.8 F1607.9381 E176.0122
( Linear move to (100.4826, 97.8782, 5.8). )
G1 X100.4826 Y97.8782 Z5.8 F1607.9381 E176.0353
( Linear move to (99.3259, 97.9008, 5.8). )
G1 X99.3259 Y97.9008 Z5.8 F1607.9381 E176.0699
( Linear move to (98.2878, 98.1873, 5.8). )
G1 X98.2878 Y98.1873 Z5.8 F1607.9381 E176.102
( Linear move to (96.5645, 96.1394, 5.8). )
G1 X96.5645 Y96.1394 Z5.8 F1607.9381 E176.182
( Linear move to (96.7113, 94.107, 5.8). )
G1 X96.7113 Y94.107 Z5.8 F1607.9381 E176.2429
( Linear move to (94.8257, 92.2214, 5.8). )
G1 X94.8257 Y92.2214 Z5.8 F1607.9381 E176.3225
( Linear move to (92.7933, 92.3682, 5.8). )
G1 X92.7933 Y92.3682 Z5.8 F1607.9381 E176.3834
( Linear move to (92.13, 89.1668, 5.8). )
G1 X92.13 Y89.1668 Z5.8 F1607.9381 E176.4811
( Linear move to (91.53, 90.0153, 5.8). )
G1 X91.53 Y90.0153 Z5.8 F1607.9381 E176.5121
( Linear move to (91.53, 92.5609, 5.8). )
G1 X91.53 Y92.5609 Z5.8 F1607.9381 E176.5882
( Linear move to (92.4687, 92.6928, 5.8). )
G1 X92.4687 Y92.6928 Z5.8 F1607.9381 E176.6165
( Linear move to (91.53, 93.4094, 5.8). )
G1 X91.53 Y93.4094 Z5.8 F1607.9381 E176.6518
( Linear move to (91.53, 95.1065, 5.8). )
G1 X91.53 Y95.1065 Z5.8 F1607.9381 E176.7025
( Linear move to (92.1596, 94.8875, 5.8). )
G1 X92.1596 Y94.8875 Z5.8 F1607.9381 E176.7224
( Linear move to (94.2075, 96.6108, 5.8). )
G1 X94.2075 Y96.6108 Z5.8 F1607.9381 E176.8024
( Linear move to (96.2399, 96.464, 5.8). )
G1 X96.2399 Y96.464 Z5.8 F1607.9381 E176.8632
( Linear move to (97.4391, 98.47, 5.8). )
G1 X97.4391 Y98.47 Z5.8 F1607.9381 E176.933
( Linear move to (94.045, 98.47, 5.8). )
G1 X94.045 Y98.47 Z5.8 F1607.9381 E177.0344
( Linear move to (93.8829, 96.9354, 5.8). )
G1 X93.8829 Y96.9354 Z5.8 F1607.9381 E177.0805
( Linear move to (91.53, 95.955, 5.8). )
G1 X91.53 Y95.955 Z5.8 F1607.9381 E177.1567
( Linear move to (91.53, 97.652, 5.8). )
G1 X91.53 Y97.652 Z5.8 F1607.9381 E177.2074
( Linear move to (92.348, 98.47, 5.8). )
G1 X92.348 Y98.47 Z5.8 F1607.9381 E177.242
( Linear move to (93.1965, 98.47, 5.8). )
G1 X93.1965 Y98.47 Z5.8 F1607.9381 E177.2673
( Linear move to (93.1965, 98.47, 5.8). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 5.8). )
G1 E176.2673
( Linear move to (93.1965, 98.47, 5.8). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 6.2 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z6.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z6.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z6.2 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z6.2 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 6.2). )
G1 X90.36 Y80.36 Z6.2 F2750.2729
( Linear move to (90.36, 80.36, 6.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 6.2). )
G1 E177.2673
( Linear move to (90.36, 80.36, 6.2). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 6.2). )
G1 X109.64 Y80.36 Z6.2 F1025.5987 E177.8436
( Linear move to (109.64, 99.64, 6.2). )
G1 X109.64 Y99.64 Z6.2 F1025.5987 E178.4199
( Linear move to (90.36, 99.64, 6.2). )
G1 X90.36 Y99.64 Z6.2 F1025.5987 E178.9962
( Linear move to (90.36, 80.36, 6.2). )
G1 X90.36 Y80.36 Z6.2 F1025.5987 E179.5725
( Linear move to (90.36, 80.36, 6.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 6.2). )
G1 E179.5725
( Linear move to (90.36, 80.36, 6.2). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 6.2). )
G1 X91.02 Y81.02 Z6.2 F6000.0
( Linear move to (91.02, 81.02, 6.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 6.2). )
G1 E179.5725
( Linear move to (91.02, 81.02, 6.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 6.2). )
G1 X108.98 Y81.02 Z6.2 F1367.465 E180.109
( Linear move to (108.98, 98.98, 6.2). )
G1 X108.98 Y98.98 Z6.2 F1367.465 E180.6455
( Linear move to (91.02, 98.98, 6.2). )
G1 X91.02 Y98.98 Z6.2 F1367.465 E181.182
( Linear move to (91.02, 81.02, 6.2). )
G1 X91.02 Y81.02 Z6.2 F1367.465 E181.7185
( Linear move to (91.02, 81.02, 6.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 6.2). )
G1 E180.7185
( Linear move to (91.02, 81.02, 6.2). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z6.0 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z6.0 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z6.0 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z6.0 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 6.2). )
G1 X91.53 Y93.6315 Z6.2 F6000.0
( Linear move to (91.53, 93.6315, 6.2). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 6.2). )
G1 E181.7185
( Linear move to (91.53, 93.6315, 6.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 6.2). )
G1 X91.53 Y87.6918 Z6.2 F1367.465 E181.8959
( Linear move to (93.3935, 87.9968, 6.2). )
G1 X93.3935 Y87.9968 Z6.2 F1367.465 E181.9523
( Linear move to (93.7541, 87.6361, 6.2). )
G1 X93.7541 Y87.6361 Z6.2 F1367.465 E181.9676
( Linear move to (93.8649, 85.6397, 6.2). )
G1 X93.8649 Y85.6397 Z6.2 F1367.465 E182.0273
( Linear move to (94.2255, 85.2791, 6.2). )
G1 X94.2255 Y85.2791 Z6.2 F1367.465 E182.0425
( Linear move to (96.2219, 85.1683, 6.2). )
G1 X96.2219 Y85.1683 Z6.2 F1367.465 E182.1023
( Linear move to (96.5825, 84.8077, 6.2). )
G1 X96.5825 Y84.8077 Z6.2 F1367.465 E182.1175
( Linear move to (103.6315, 82.13, 6.2). )
G1 X103.6315 Y82.13 Z6.2 F1367.465 E182.3427
( Linear move to (104.48, 81.53, 6.2). )
G1 X104.48 Y81.53 Z6.2 F1367.465 E182.3738
( Linear move to (93.4491, 81.53, 6.2). )
G1 X93.4491 Y81.53 Z6.2 F1367.465 E182.7033
( Linear move to (93.4491, 82.13, 6.2). )
G1 X93.4491 Y82.13 Z6.2 F1367.465 E182.7212
( Linear move to (92.13, 86.8432, 6.2). )
G1 X92.13 Y86.8432 Z6.2 F1367.465 E182.8674
( Linear move to (91.53, 85.9947, 6.2). )
G1 X91.53 Y85.9947 Z6.2 F1367.465 E182.8985
( Linear move to (91.53, 82.6006, 6.2). )
G1 X91.53 Y82.6006 Z6.2 F1367.465 E182.9999
( Linear move to (92.6006, 81.53, 6.2). )
G1 X92.6006 Y81.53 Z6.2 F1367.465 E183.0451
( Linear move to (92.6006, 81.53, 6.2). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 6.2). )
G1 E182.0451
( Linear move to (92.6006, 81.53, 6.2). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 6.2). )
G1 X108.47 Y97.0561 Z6.2 F6000.0
( Linear move to (108.47, 97.0561, 6.2). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 6.2). )
G1 E183.0451
( Linear move to (108.47, 97.0561, 6.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 6.2). )
G1 X108.47 Y97.9047 Z6.2 F1367.465 E183.0705
( Linear move to (107.9047, 98.47, 6.2). )
G1 X107.9047 Y98.47 Z6.2 F1367.465 E183.0943
( Linear move to (105.3591, 98.47, 6.2). )
G1 X105.3591 Y98.47 Z6.2 F1367.465 E183.1704
( Linear move to (105.1786, 96.9534, 6.2). )
G1 X105.1786 Y96.9534 Z6.2 F1367.465 E183.216
( Linear move to (105.5392, 96.5928, 6.2). )
G1 X105.5392 Y96.5928 Z6.2 F1367.465 E183.2312
( Linear move to (108.47, 96.2076, 6.2). )
G1 X108.47 Y96.2076 Z6.2 F1367.465 E183.3195
( Linear move to (108.47, 89.4194, 6.2). )
G1 X108.47 Y89.4194 Z6.2 F1367.465 E183.5223
( Linear move to (106.9534, 89.5217, 6.2). )
G1 X106.9534 Y89.5217 Z6.2 F1367.465 E183.5677
( Linear move to (106.5928, 89.8824, 6.2). )
G1 X106.5928 Y89.8824 Z6.2 F1367.465 E183.583
( Linear move to (106.482, 91.8788, 6.2). )
G1 X106.482 Y91.8788 Z6.2 F1367.465 E183.6427
( Linear move to (106.1214, 92.2394, 6.2). )
G1 X106.1214 Y92.2394 Z6.2 F1367.465 E183.6579
( Linear move to (104.125, 92.3502, 6.2). )
G1 X104.125 Y92.3502 Z6.2 F1367.465 E183.7177
( Linear move to (103.7644, 92.7108, 6.2). )
G1 X103.7644 Y92.7108 Z6.2 F1367.465 E183.7329
( Linear move to (103.6536, 94.7072, 6.2). )
G1 X103.6536 Y94.7072 Z6.2 F1367.465 E183.7926
( Linear move to (103.293, 95.0678, 6.2). )
G1 X103.293 Y95.0678 Z6.2 F1367.465 E183.8079
( Linear move to (101.2966, 95.1786, 6.2). )
G1 X101.2966 Y95.1786 Z6.2 F1367.465 E183.8676
( Linear move to (100.936, 95.5392, 6.2). )
G1 X100.936 Y95.5392 Z6.2 F1367.465 E183.8828
( Linear move to (100.6449, 97.7159, 6.2). )
G1 X100.6449 Y97.7159 Z6.2 F1367.465 E183.9484
( Linear move to (104.5106, 97.87, 6.2). )
G1 X104.5106 Y97.87 Z6.2 F1367.465 E184.064
( Linear move to (103.662, 98.47, 6.2). )
G1 X103.662 Y98.47 Z6.2 F1367.465 E184.095
( Linear move to (98.5709, 98.47, 6.2). )
G1 X98.5709 Y98.47 Z6.2 F1367.465 E184.2471
( Linear move to (98.4682, 98.007, 6.2). )
G1 X98.4682 Y98.007 Z6.2 F1367.465 E184.2613
( Linear move to (98.1075, 98.3676, 6.2). )
G1 X98.1075 Y98.3676 Z6.2 F1367.465 E184.2765
( Linear move to (97.7223, 98.47, 6.2). )
G1 X97.7223 Y98.47 Z6.2 F1367.465 E184.2884
( Linear move to (94.3282, 98.47, 6.2). )
G1 X94.3282 Y98.47 Z6.2 F1367.465 E184.3898
( Linear move to (93.8649, 96.9534, 6.2). )
G1 X93.8649 Y96.9534 Z6.2 F1367.465 E184.4372
( Linear move to (94.2255, 96.5928, 6.2). )
G1 X94.2255 Y96.5928 Z6.2 F1367.465 E184.4524
( Linear move to (96.2219, 96.482, 6.2). )
G1 X96.2219 Y96.482 Z6.2 F1367.465 E184.5122
( Linear move to (96.5825, 96.1214, 6.2). )
G1 X96.5825 Y96.1214 Z6.2 F1367.465 E184.5274
( Linear move to (96.6933, 94.125, 6.2). )
G1 X96.6933 Y94.125 Z6.2 F1367.465 E184.5871
( Linear move to (97.0539, 93.7644, 6.2). )
G1 X97.0539 Y93.7644 Z6.2 F1367.465 E184.6024
( Linear move to (99.0503, 93.6536, 6.2). )
G1 X99.0503 Y93.6536 Z6.2 F1367.465 E184.6621
( Linear move to (99.411, 93.293, 6.2). )
G1 X99.411 Y93.293 Z6.2 F1367.465 E184.6773
( Linear move to (99.5217, 91.2966, 6.2). )
G1 X99.5217 Y91.2966 Z6.2 F1367.465 E184.737
( Linear move to (99.8824, 90.936, 6.2). )
G1 X99.8824 Y90.936 Z6.2 F1367.465 E184.7523
( Linear move to (101.8788, 90.8252, 6.2). )
G1 X101.8788 Y90.8252 Z6.2 F1367.465 E184.812
( Linear move to (102.2394, 90.4646, 6.2). )
G1 X102.2394 Y90.4646 Z6.2 F1367.465 E184.8272
( Linear move to (102.3502, 88.4682, 6.2). )
G1 X102.3502 Y88.4682 Z6.2 F1367.465 E184.887
( Linear move to (102.7108, 88.1075, 6.2). )
G1 X102.7108 Y88.1075 Z6.2 F1367.465 E184.9022
( Linear move to (104.7072, 87.9968, 6.2). )
G1 X104.7072 Y87.9968 Z6.2 F1367.465 E184.9619
( Linear move to (105.0678, 87.6361, 6.2). )
G1 X105.0678 Y87.6361 Z6.2 F1367.465 E184.9772
( Linear move to (105.1786, 85.6397, 6.2). )
G1 X105.1786 Y85.6397 Z6.2 F1367.465 E185.0369
( Linear move to (105.5392, 85.2791, 6.2). )
G1 X105.5392 Y85.2791 Z6.2 F1367.465 E185.0521
( Linear move to (108.47, 88.5709, 6.2). )
G1 X108.47 Y88.5709 Z6.2 F1367.465 E185.1838
( Linear move to (108.3887, 81.8639, 6.2). )
G1 X108.3887 Y81.8639 Z6.2 F1367.465 E185.3842
( Linear move to (107.8741, 81.53, 6.2). )
G1 X107.8741 Y81.53 Z6.2 F1367.465 E185.4025
( Linear move to (106.1771, 81.53, 6.2). )
G1 X106.1771 Y81.53 Z6.2 F1367.465 E185.4532
( Linear move to (103.293, 83.7541, 6.2). )
G1 X103.293 Y83.7541 Z6.2 F1367.465 E185.562
( Linear move to (101.2966, 83.8649, 6.2). )
G1 X101.2966 Y83.8649 Z6.2 F1367.465 E185.6217
( Linear move to (100.936, 84.2255, 6.2). )
G1 X100.936 Y84.2255 Z6.2 F1367.465 E185.6369
( Linear move to (100.8252, 86.2219, 6.2). )
G1 X100.8252 Y86.2219 Z6.2 F1367.465 E185.6967
( Linear move to (100.4646, 86.5825, 6.2). )
G1 X100.4646 Y86.5825 Z6.2 F1367.465 E185.7119
( Linear move to (98.4682, 86.6933, 6.2). )
G1 X98.4682 Y86.6933 Z6.2 F1367.465 E185.7716
( Linear move to (98.1075, 87.0539, 6.2). )
G1 X98.1075 Y87.0539 Z6.2 F1367.465 E185.7869
( Linear move to (97.9968, 89.0503, 6.2). )
G1 X97.9968 Y89.0503 Z6.2 F1367.465 E185.8466
( Linear move to (97.6361, 89.411, 6.2). )
G1 X97.6361 Y89.411 Z6.2 F1367.465 E185.8618
( Linear move to (95.6397, 89.5217, 6.2). )
G1 X95.6397 Y89.5217 Z6.2 F1367.465 E185.9216
( Linear move to (95.2791, 89.8824, 6.2). )
G1 X95.2791 Y89.8824 Z6.2 F1367.465 E185.9368
( Linear move to (95.1683, 91.8788, 6.2). )
G1 X95.1683 Y91.8788 Z6.2 F1367.465 E185.9965
( Linear move to (94.8077, 92.2394, 6.2). )
G1 X94.8077 Y92.2394 Z6.2 F1367.465 E186.0118
( Linear move to (92.8113, 92.3502, 6.2). )
G1 X92.8113 Y92.3502 Z6.2 F1367.465 E186.0715
( Linear move to (92.4507, 92.7108, 6.2). )
G1 X92.4507 Y92.7108 Z6.2 F1367.465 E186.0867
( Linear move to (91.53, 94.48, 6.2). )
G1 X91.53 Y94.48 Z6.2 F1367.465 E186.1463
( Linear move to (92.3399, 94.7072, 6.2). )
G1 X92.3399 Y94.7072 Z6.2 F1367.465 E186.1714
( Linear move to (91.9793, 95.0678, 6.2). )
G1 X91.9793 Y95.0678 Z6.2 F1367.465 E186.1867
( Linear move to (91.53, 95.3285, 6.2). )
G1 X91.53 Y95.3285 Z6.2 F1367.465 E186.2022
( Linear move to (91.53, 97.8741, 6.2). )
G1 X91.53 Y97.8741 Z6.2 F1367.465 E186.2782
( Linear move to (91.8639, 98.3887, 6.2). )
G1 X91.8639 Y98.3887 Z6.2 F1367.465 E186.2966
( Linear move to (93.4797, 98.47, 6.2). )
G1 X93.4797 Y98.47 Z6.2 F1367.465 E186.3449
( Linear move to (93.4797, 98.47, 6.2). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 6.2). )
G1 E185.3449
( Linear move to (93.4797, 98.47, 6.2). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 6.6 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z6.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z6.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z6.6 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z6.6 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 6.6). )
G1 X90.36 Y80.36 Z6.6 F2757.1641
( Linear move to (90.36, 80.36, 6.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 6.6). )
G1 E186.3449
( Linear move to (90.36, 80.36, 6.6). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 6.6). )
G1 X109.64 Y80.36 Z6.6 F1205.9536 E186.921
( Linear move to (109.64, 99.64, 6.6). )
G1 X109.64 Y99.64 Z6.6 F1205.9536 E187.4971
( Linear move to (90.36, 99.64, 6.6). )
G1 X90.36 Y99.64 Z6.6 F1205.9536 E188.0731
( Linear move to (90.36, 80.36, 6.6). )
G1 X90.36 Y80.36 Z6.6 F1205.9536 E188.6492
( Linear move to (90.36, 80.36, 6.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 6.6). )
G1 E188.6492
( Linear move to (90.36, 80.36, 6.6). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 6.6). )
G1 X91.02 Y81.02 Z6.6 F6000.0
( Linear move to (91.02, 81.02, 6.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 6.6). )
G1 E188.6492
( Linear move to (91.02, 81.02, 6.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 6.6). )
G1 X108.98 Y81.02 Z6.6 F1607.9381 E189.1858
( Linear move to (108.98, 98.98, 6.6). )
G1 X108.98 Y98.98 Z6.6 F1607.9381 E189.7223
( Linear move to (91.02, 98.98, 6.6). )
G1 X91.02 Y98.98 Z6.6 F1607.9381 E190.2589
( Linear move to (91.02, 81.02, 6.6). )
G1 X91.02 Y81.02 Z6.6 F1607.9381 E190.7954
( Linear move to (91.02, 81.02, 6.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 6.6). )
G1 E190.3444
( Linear move to (91.02, 81.02, 6.6). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z6.4 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z6.4 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z6.4 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z6.4 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 6.6). )
G1 X92.3785 Y81.53 Z6.6 F6000.0
( Linear move to (92.3785, 81.53, 6.6). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 6.6). )
G1 E190.7954
( Linear move to (92.3785, 81.53, 6.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 6.6). )
G1 X91.7376 Y81.7376 Z6.6 F1607.9381 E190.8156
( Linear move to (91.53, 82.3785, 6.6). )
G1 X91.53 Y82.3785 Z6.6 F1607.9381 E190.8357
( Linear move to (92.3219, 83.4115, 6.6). )
G1 X92.3219 Y83.4115 Z6.6 F1607.9381 E190.8746
( Linear move to (94.2075, 85.2971, 6.6). )
G1 X94.2075 Y85.2971 Z6.6 F1607.9381 E190.9542
( Linear move to (96.2399, 85.1503, 6.6). )
G1 X96.2399 Y85.1503 Z6.6 F1607.9381 E191.0151
( Linear move to (98.1256, 87.0359, 6.6). )
G1 X98.1256 Y87.0359 Z6.6 F1607.9381 E191.0948
( Linear move to (97.9787, 89.0684, 6.6). )
G1 X97.9787 Y89.0684 Z6.6 F1607.9381 E191.1557
( Linear move to (99.8643, 90.954, 6.6). )
G1 X99.8643 Y90.954 Z6.6 F1607.9381 E191.2353
( Linear move to (101.8968, 90.8071, 6.6). )
G1 X101.8968 Y90.8071 Z6.6 F1607.9381 E191.2962
( Linear move to (103.7824, 92.6928, 6.6). )
G1 X103.7824 Y92.6928 Z6.6 F1607.9381 E191.3759
( Linear move to (103.6356, 94.7252, 6.6). )
G1 X103.6356 Y94.7252 Z6.6 F1607.9381 E191.4367
( Linear move to (107.6215, 98.47, 6.6). )
G1 X107.6215 Y98.47 Z6.6 F1607.9381 E191.6001
( Linear move to (108.2624, 98.2624, 6.6). )
G1 X108.2624 Y98.2624 Z6.6 F1607.9381 E191.6203
( Linear move to (108.47, 97.6215, 6.6). )
G1 X108.47 Y97.6215 Z6.6 F1607.9381 E191.6404
( Linear move to (108.47, 93.3788, 6.6). )
G1 X108.47 Y93.3788 Z6.6 F1607.9381 E191.7671
( Linear move to (106.1394, 92.2214, 6.6). )
G1 X106.1394 Y92.2214 Z6.6 F1607.9381 E191.8449
( Linear move to (104.107, 92.3682, 6.6). )
G1 X104.107 Y92.3682 Z6.6 F1607.9381 E191.9057
( Linear move to (102.2214, 90.4826, 6.6). )
G1 X102.2214 Y90.4826 Z6.6 F1607.9381 E191.9854
( Linear move to (102.3682, 88.4501, 6.6). )
G1 X102.3682 Y88.4501 Z6.6 F1607.9381 E192.0463
( Linear move to (100.4826, 86.5645, 6.6). )
G1 X100.4826 Y86.5645 Z6.6 F1607.9381 E192.126
( Linear move to (98.4501, 86.7113, 6.6). )
G1 X98.4501 Y86.7113 Z6.6 F1607.9381 E192.1868
( Linear move to (93.2271, 81.53, 6.6). )
G1 X93.2271 Y81.53 Z6.6 F1607.9381 E192.4066
( Linear move to (97.4697, 81.53, 6.6). )
G1 X97.4697 Y81.53 Z6.6 F1607.9381 E192.5334
( Linear move to (96.8736, 82.631, 6.6). )
G1 X96.8736 Y82.631 Z6.6 F1607.9381 E192.5708
( Linear move to (98.6819, 82.0072, 6.6). )
G1 X98.6819 Y82.0072 Z6.6 F1607.9381 E192.6279
( Linear move to (99.1668, 81.53, 6.6). )
G1 X99.1668 Y81.53 Z6.6 F1607.9381 E192.6482
( Linear move to (100.954, 84.2075, 6.6). )
G1 X100.954 Y84.2075 Z6.6 F1607.9381 E192.7444
( Linear move to (100.8071, 86.2399, 6.6). )
G1 X100.8071 Y86.2399 Z6.6 F1607.9381 E192.8053
( Linear move to (102.6928, 88.1256, 6.6). )
G1 X102.6928 Y88.1256 Z6.6 F1607.9381 E192.885
( Linear move to (104.7252, 87.9787, 6.6). )
G1 X104.7252 Y87.9787 Z6.6 F1607.9381 E192.9458
( Linear move to (106.6108, 89.8643, 6.6). )
G1 X106.6108 Y89.8643 Z6.6 F1607.9381 E193.0255
( Linear move to (106.464, 91.8968, 6.6). )
G1 X106.464 Y91.8968 Z6.6 F1607.9381 E193.0864
( Linear move to (108.47, 92.5303, 6.6). )
G1 X108.47 Y92.5303 Z6.6 F1607.9381 E193.1492
( Linear move to (108.47, 88.2877, 6.6). )
G1 X108.47 Y88.2877 Z6.6 F1607.9381 E193.276
( Linear move to (106.9354, 89.5398, 6.6). )
G1 X106.9354 Y89.5398 Z6.6 F1607.9381 E193.3351
( Linear move to (105.0498, 87.6542, 6.6). )
G1 X105.0498 Y87.6542 Z6.6 F1607.9381 E193.4148
( Linear move to (105.1966, 85.6217, 6.6). )
G1 X105.1966 Y85.6217 Z6.6 F1607.9381 E193.4757
( Linear move to (103.311, 83.7361, 6.6). )
G1 X103.311 Y83.7361 Z6.6 F1607.9381 E193.5554
( Linear move to (101.2786, 83.8829, 6.6). )
G1 X101.2786 Y83.8829 Z6.6 F1607.9381 E193.6162
( Linear move to (100.0153, 81.53, 6.6). )
G1 X100.0153 Y81.53 Z6.6 F1607.9381 E193.696
( Linear move to (105.1065, 81.53, 6.6). )
G1 X105.1065 Y81.53 Z6.6 F1607.9381 E193.8481
( Linear move to (103.6356, 83.4115, 6.6). )
G1 X103.6356 Y83.4115 Z6.6 F1607.9381 E193.9195
( Linear move to (105.5212, 85.2971, 6.6). )
G1 X105.5212 Y85.2971 Z6.6 F1607.9381 E193.9991
( Linear move to (108.47, 87.4391, 6.6). )
G1 X108.47 Y87.4391 Z6.6 F1607.9381 E194.108
( Linear move to (108.47, 83.1965, 6.6). )
G1 X108.47 Y83.1965 Z6.6 F1607.9381 E194.2348
( Linear move to (105.955, 81.53, 6.6). )
G1 X105.955 Y81.53 Z6.6 F1607.9381 E194.3249
( Linear move to (107.652, 81.53, 6.6). )
G1 X107.652 Y81.53 Z6.6 F1607.9381 E194.3756
( Linear move to (108.47, 82.348, 6.6). )
G1 X108.47 Y82.348 Z6.6 F1607.9381 E194.4101
( Linear move to (108.47, 82.348, 6.6). )
G1 F1200.0
( Linear move to (108.47, 82.348, 6.6). )
G1 E193.4101
( Linear move to (108.47, 82.348, 6.6). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 6.6). )
G1 X106.7729 Y98.47 Z6.6 F6000.0
( Linear move to (106.7729, 98.47, 6.6). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 6.6). )
G1 E194.4101
( Linear move to (106.7729, 98.47, 6.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 6.6). )
G1 X105.0759 Y98.47 Z6.6 F1607.9381 E194.4608
( Linear move to (105.1966, 96.9354, 6.6). )
G1 X105.1966 Y96.9354 Z6.6 F1607.9381 E194.5068
( Linear move to (103.311, 95.0498, 6.6). )
G1 X103.311 Y95.0498 Z6.6 F1607.9381 E194.5865
( Linear move to (101.2786, 95.1966, 6.6). )
G1 X101.2786 Y95.1966 Z6.6 F1607.9381 E194.6474
( Linear move to (99.3929, 93.311, 6.6). )
G1 X99.3929 Y93.311 Z6.6 F1607.9381 E194.727
( Linear move to (99.5398, 91.2786, 6.6). )
G1 X99.5398 Y91.2786 Z6.6 F1607.9381 E194.7879
( Linear move to (97.6542, 89.3929, 6.6). )
G1 X97.6542 Y89.3929 Z6.6 F1607.9381 E194.8676
( Linear move to (95.6217, 89.5398, 6.6). )
G1 X95.6217 Y89.5398 Z6.6 F1607.9381 E194.9285
( Linear move to (93.7361, 87.6542, 6.6). )
G1 X93.7361 Y87.6542 Z6.6 F1607.9381 E195.0081
( Linear move to (93.8829, 85.6217, 6.6). )
G1 X93.8829 Y85.6217 Z6.6 F1607.9381 E195.069
( Linear move to (91.53, 83.2271, 6.6). )
G1 X91.53 Y83.2271 Z6.6 F1607.9381 E195.1693
( Linear move to (91.53, 88.3182, 6.6). )
G1 X91.53 Y88.3182 Z6.6 F1607.9381 E195.3214
( Linear move to (93.4115, 87.9787, 6.6). )
G1 X93.4115 Y87.9787 Z6.6 F1607.9381 E195.3785
( Linear move to (95.2971, 89.8643, 6.6). )
G1 X95.2971 Y89.8643 Z6.6 F1607.9381 E195.4582
( Linear move to (95.1503, 91.8968, 6.6). )
G1 X95.1503 Y91.8968 Z6.6 F1607.9381 E195.5191
( Linear move to (97.0359, 93.7824, 6.6). )
G1 X97.0359 Y93.7824 Z6.6 F1607.9381 E195.5987
( Linear move to (99.0684, 93.6356, 6.6). )
G1 X99.0684 Y93.6356 Z6.6 F1607.9381 E195.6596
( Linear move to (100.954, 95.5212, 6.6). )
G1 X100.954 Y95.5212 Z6.6 F1607.9381 E195.7393
( Linear move to (100.8071, 97.5537, 6.6). )
G1 X100.8071 Y97.5537 Z6.6 F1607.9381 E195.8001
( Linear move to (103.3788, 97.87, 6.6). )
G1 X103.3788 Y97.87 Z6.6 F1607.9381 E195.8775
( Linear move to (104.2274, 98.47, 6.6). )
G1 X104.2274 Y98.47 Z6.6 F1607.9381 E195.9086
( Linear move to (99.9847, 98.47, 6.6). )
G1 X99.9847 Y98.47 Z6.6 F1607.9381 E196.0353
( Linear move to (100.4826, 97.8782, 6.6). )
G1 X100.4826 Y97.8782 Z6.6 F1607.9381 E196.0585
( Linear move to (99.3259, 97.9008, 6.6). )
G1 X99.3259 Y97.9008 Z6.6 F1607.9381 E196.093
( Linear move to (98.2878, 98.1873, 6.6). )
G1 X98.2878 Y98.1873 Z6.6 F1607.9381 E196.1252
( Linear move to (96.5645, 96.1394, 6.6). )
G1 X96.5645 Y96.1394 Z6.6 F1607.9381 E196.2051
( Linear move to (96.7113, 94.107, 6.6). )
G1 X96.7113 Y94.107 Z6.6 F1607.9381 E196.266
( Linear move to (94.8257, 92.2214, 6.6). )
G1 X94.8257 Y92.2214 Z6.6 F1607.9381 E196.3457
( Linear move to (92.7933, 92.3682, 6.6). )
G1 X92.7933 Y92.3682 Z6.6 F1607.9381 E196.4066
( Linear move to (92.13, 89.1668, 6.6). )
G1 X92.13 Y89.1668 Z6.6 F1607.9381 E196.5042
( Linear move to (91.53, 90.0153, 6.6). )
G1 X91.53 Y90.0153 Z6.6 F1607.9381 E196.5353
( Linear move to (91.53, 92.5609, 6.6). )
G1 X91.53 Y92.5609 Z6.6 F1607.9381 E196.6113
( Linear move to (92.4687, 92.6928, 6.6). )
G1 X92.4687 Y92.6928 Z6.6 F1607.9381 E196.6396
( Linear move to (91.53, 93.4094, 6.6). )
G1 X91.53 Y93.4094 Z6.6 F1607.9381 E196.6749
( Linear move to (91.53, 95.1065, 6.6). )
G1 X91.53 Y95.1065 Z6.6 F1607.9381 E196.7256
( Linear move to (92.1596, 94.8875, 6.6). )
G1 X92.1596 Y94.8875 Z6.6 F1607.9381 E196.7455
( Linear move to (94.2075, 96.6108, 6.6). )
G1 X94.2075 Y96.6108 Z6.6 F1607.9381 E196.8255
( Linear move to (96.2399, 96.464, 6.6). )
G1 X96.2399 Y96.464 Z6.6 F1607.9381 E196.8864
( Linear move to (97.4391, 98.47, 6.6). )
G1 X97.4391 Y98.47 Z6.6 F1607.9381 E196.9562
( Linear move to (94.045, 98.47, 6.6). )
G1 X94.045 Y98.47 Z6.6 F1607.9381 E197.0576
( Linear move to (93.8829, 96.9354, 6.6). )
G1 X93.8829 Y96.9354 Z6.6 F1607.9381 E197.1037
( Linear move to (91.53, 95.955, 6.6). )
G1 X91.53 Y95.955 Z6.6 F1607.9381 E197.1799
( Linear move to (91.53, 97.652, 6.6). )
G1 X91.53 Y97.652 Z6.6 F1607.9381 E197.2305
( Linear move to (92.348, 98.47, 6.6). )
G1 X92.348 Y98.47 Z6.6 F1607.9381 E197.2651
( Linear move to (93.1965, 98.47, 6.6). )
G1 X93.1965 Y98.47 Z6.6 F1607.9381 E197.2905
( Linear move to (93.1965, 98.47, 6.6). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 6.6). )
G1 E196.2905
( Linear move to (93.1965, 98.47, 6.6). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 7.0 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z7.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z7.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z7.0 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z7.0 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 7.0). )
G1 X90.36 Y80.36 Z7.0 F2750.2729
( Linear move to (90.36, 80.36, 7.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.0). )
G1 E197.2905
( Linear move to (90.36, 80.36, 7.0). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 7.0). )
G1 X109.64 Y80.36 Z7.0 F1025.5987 E197.8667
( Linear move to (109.64, 99.64, 7.0). )
G1 X109.64 Y99.64 Z7.0 F1025.5987 E198.443
( Linear move to (90.36, 99.64, 7.0). )
G1 X90.36 Y99.64 Z7.0 F1025.5987 E199.0193
( Linear move to (90.36, 80.36, 7.0). )
G1 X90.36 Y80.36 Z7.0 F1025.5987 E199.5956
( Linear move to (90.36, 80.36, 7.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.0). )
G1 E199.5956
( Linear move to (90.36, 80.36, 7.0). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 7.0). )
G1 X91.02 Y81.02 Z7.0 F6000.0
( Linear move to (91.02, 81.02, 7.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.0). )
G1 E199.5956
( Linear move to (91.02, 81.02, 7.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 7.0). )
G1 X108.98 Y81.02 Z7.0 F1367.465 E200.1321
( Linear move to (108.98, 98.98, 7.0). )
G1 X108.98 Y98.98 Z7.0 F1367.465 E200.6686
( Linear move to (91.02, 98.98, 7.0). )
G1 X91.02 Y98.98 Z7.0 F1367.465 E201.2051
( Linear move to (91.02, 81.02, 7.0). )
G1 X91.02 Y81.02 Z7.0 F1367.465 E201.7416
( Linear move to (91.02, 81.02, 7.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.0). )
G1 E200.7416
( Linear move to (91.02, 81.02, 7.0). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z6.8 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z6.8 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z6.8 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z6.8 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 7.0). )
G1 X91.53 Y93.6315 Z7.0 F6000.0
( Linear move to (91.53, 93.6315, 7.0). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 7.0). )
G1 E201.7416
( Linear move to (91.53, 93.6315, 7.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 7.0). )
G1 X91.53 Y87.6918 Z7.0 F1367.465 E201.9191
( Linear move to (93.3935, 87.9968, 7.0). )
G1 X93.3935 Y87.9968 Z7.0 F1367.465 E201.9755
( Linear move to (93.7541, 87.6361, 7.0). )
G1 X93.7541 Y87.6361 Z7.0 F1367.465 E201.9907
( Linear move to (93.8649, 85.6397, 7.0). )
G1 X93.8649 Y85.6397 Z7.0 F1367.465 E202.0504
( Linear move to (94.2255, 85.2791, 7.0). )
G1 X94.2255 Y85.2791 Z7.0 F1367.465 E202.0657
( Linear move to (96.2219, 85.1683, 7.0). )
G1 X96.2219 Y85.1683 Z7.0 F1367.465 E202.1254
( Linear move to (96.5825, 84.8077, 7.0). )
G1 X96.5825 Y84.8077 Z7.0 F1367.465 E202.1406
( Linear move to (103.6315, 82.13, 7.0). )
G1 X103.6315 Y82.13 Z7.0 F1367.465 E202.3659
( Linear move to (104.48, 81.53, 7.0). )
G1 X104.48 Y81.53 Z7.0 F1367.465 E202.3969
( Linear move to (93.4491, 81.53, 7.0). )
G1 X93.4491 Y81.53 Z7.0 F1367.465 E202.7265
( Linear move to (93.4491, 82.13, 7.0). )
G1 X93.4491 Y82.13 Z7.0 F1367.465 E202.7444
( Linear move to (92.13, 86.8432, 7.0). )
G1 X92.13 Y86.8432 Z7.0 F1367.465 E202.8906
( Linear move to (91.53, 85.9947, 7.0). )
G1 X91.53 Y85.9947 Z7.0 F1367.465 E202.9216
( Linear move to (91.53, 82.6006, 7.0). )
G1 X91.53 Y82.6006 Z7.0 F1367.465 E203.023
( Linear move to (92.6006, 81.53, 7.0). )
G1 X92.6006 Y81.53 Z7.0 F1367.465 E203.0683
( Linear move to (92.6006, 81.53, 7.0). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 7.0). )
G1 E202.0683
( Linear move to (92.6006, 81.53, 7.0). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 7.0). )
G1 X108.47 Y97.0561 Z7.0 F6000.0
( Linear move to (108.47, 97.0561, 7.0). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 7.0). )
G1 E203.0683
( Linear move to (108.47, 97.0561, 7.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 7.0). )
G1 X108.47 Y97.9047 Z7.0 F1367.465 E203.0936
( Linear move to (107.9047, 98.47, 7.0). )
G1 X107.9047 Y98.47 Z7.0 F1367.465 E203.1175
( Linear move to (105.3591, 98.47, 7.0). )
G1 X105.3591 Y98.47 Z7.0 F1367.465 E203.1935
( Linear move to (105.1786, 96.9534, 7.0). )
G1 X105.1786 Y96.9534 Z7.0 F1367.465 E203.2392
( Linear move to (105.5392, 96.5928, 7.0). )
G1 X105.5392 Y96.5928 Z7.0 F1367.465 E203.2544
( Linear move to (108.47, 96.2076, 7.0). )
G1 X108.47 Y96.2076 Z7.0 F1367.465 E203.3427
( Linear move to (108.47, 89.4194, 7.0). )
G1 X108.47 Y89.4194 Z7.0 F1367.465 E203.5455
( Linear move to (106.9534, 89.5217, 7.0). )
G1 X106.9534 Y89.5217 Z7.0 F1367.465 E203.5909
( Linear move to (106.5928, 89.8824, 7.0). )
G1 X106.5928 Y89.8824 Z7.0 F1367.465 E203.6061
( Linear move to (106.482, 91.8788, 7.0). )
G1 X106.482 Y91.8788 Z7.0 F1367.465 E203.6658
( Linear move to (106.1214, 92.2394, 7.0). )
G1 X106.1214 Y92.2394 Z7.0 F1367.465 E203.6811
( Linear move to (104.125, 92.3502, 7.0). )
G1 X104.125 Y92.3502 Z7.0 F1367.465 E203.7408
( Linear move to (103.7644, 92.7108, 7.0). )
G1 X103.7644 Y92.7108 Z7.0 F1367.465 E203.756
( Linear move to (103.6536, 94.7072, 7.0). )
G1 X103.6536 Y94.7072 Z7.0 F1367.465 E203.8158
( Linear move to (103.293, 95.0678, 7.0). )
G1 X103.293 Y95.0678 Z7.0 F1367.465 E203.831
( Linear move to (101.2966, 95.1786, 7.0). )
G1 X101.2966 Y95.1786 Z7.0 F1367.465 E203.8907
( Linear move to (100.936, 95.5392, 7.0). )
G1 X100.936 Y95.5392 Z7.0 F1367.465 E203.906
( Linear move to (100.6449, 97.7159, 7.0). )
G1 X100.6449 Y97.7159 Z7.0 F1367.465 E203.9716
( Linear move to (104.5106, 97.87, 7.0). )
G1 X104.5106 Y97.87 Z7.0 F1367.465 E204.0871
( Linear move to (103.662, 98.47, 7.0). )
G1 X103.662 Y98.47 Z7.0 F1367.465 E204.1182
( Linear move to (98.5709, 98.47, 7.0). )
G1 X98.5709 Y98.47 Z7.0 F1367.465 E204.2703
( Linear move to (98.4682, 98.007, 7.0). )
G1 X98.4682 Y98.007 Z7.0 F1367.465 E204.2844
( Linear move to (98.1075, 98.3676, 7.0). )
G1 X98.1075 Y98.3676 Z7.0 F1367.465 E204.2997
( Linear move to (97.7223, 98.47, 7.0). )
G1 X97.7223 Y98.47 Z7.0 F1367.465 E204.3116
( Linear move to (94.3282, 98.47, 7.0). )
G1 X94.3282 Y98.47 Z7.0 F1367.465 E204.413
( Linear move to (93.8649, 96.9534, 7.0). )
G1 X93.8649 Y96.9534 Z7.0 F1367.465 E204.4603
( Linear move to (94.2255, 96.5928, 7.0). )
G1 X94.2255 Y96.5928 Z7.0 F1367.465 E204.4756
( Linear move to (96.2219, 96.482, 7.0). )
G1 X96.2219 Y96.482 Z7.0 F1367.465 E204.5353
( Linear move to (96.5825, 96.1214, 7.0). )
G1 X96.5825 Y96.1214 Z7.0 F1367.465 E204.5505
( Linear move to (96.6933, 94.125, 7.0). )
G1 X96.6933 Y94.125 Z7.0 F1367.465 E204.6103
( Linear move to (97.0539, 93.7644, 7.0). )
G1 X97.0539 Y93.7644 Z7.0 F1367.465 E204.6255
( Linear move to (99.0503, 93.6536, 7.0). )
G1 X99.0503 Y93.6536 Z7.0 F1367.465 E204.6852
( Linear move to (99.411, 93.293, 7.0). )
G1 X99.411 Y93.293 Z7.0 F1367.465 E204.7005
( Linear move to (99.5217, 91.2966, 7.0). )
G1 X99.5217 Y91.2966 Z7.0 F1367.465 E204.7602
( Linear move to (99.8824, 90.936, 7.0). )
G1 X99.8824 Y90.936 Z7.0 F1367.465 E204.7754
( Linear move to (101.8788, 90.8252, 7.0). )
G1 X101.8788 Y90.8252 Z7.0 F1367.465 E204.8352
( Linear move to (102.2394, 90.4646, 7.0). )
G1 X102.2394 Y90.4646 Z7.0 F1367.465 E204.8504
( Linear move to (102.3502, 88.4682, 7.0). )
G1 X102.3502 Y88.4682 Z7.0 F1367.465 E204.9101
( Linear move to (102.7108, 88.1075, 7.0). )
G1 X102.7108 Y88.1075 Z7.0 F1367.465 E204.9254
( Linear move to (104.7072, 87.9968, 7.0). )
G1 X104.7072 Y87.9968 Z7.0 F1367.465 E204.9851
( Linear move to (105.0678, 87.6361, 7.0). )
G1 X105.0678 Y87.6361 Z7.0 F1367.465 E205.0003
( Linear move to (105.1786, 85.6397, 7.0). )
G1 X105.1786 Y85.6397 Z7.0 F1367.465 E205.0601
( Linear move to (105.5392, 85.2791, 7.0). )
G1 X105.5392 Y85.2791 Z7.0 F1367.465 E205.0753
( Linear move to (108.47, 88.5709, 7.0). )
G1 X108.47 Y88.5709 Z7.0 F1367.465 E205.207
( Linear move to (108.3887, 81.8639, 7.0). )
G1 X108.3887 Y81.8639 Z7.0 F1367.465 E205.4073
( Linear move to (107.8741, 81.53, 7.0). )
G1 X107.8741 Y81.53 Z7.0 F1367.465 E205.4256
( Linear move to (106.1771, 81.53, 7.0). )
G1 X106.1771 Y81.53 Z7.0 F1367.465 E205.4763
( Linear move to (103.293, 83.7541, 7.0). )
G1 X103.293 Y83.7541 Z7.0 F1367.465 E205.5851
( Linear move to (101.2966, 83.8649, 7.0). )
G1 X101.2966 Y83.8649 Z7.0 F1367.465 E205.6449
( Linear move to (100.936, 84.2255, 7.0). )
G1 X100.936 Y84.2255 Z7.0 F1367.465 E205.6601
( Linear move to (100.8252, 86.2219, 7.0). )
G1 X100.8252 Y86.2219 Z7.0 F1367.465 E205.7198
( Linear move to (100.4646, 86.5825, 7.0). )
G1 X100.4646 Y86.5825 Z7.0 F1367.465 E205.7351
( Linear move to (98.4682, 86.6933, 7.0). )
G1 X98.4682 Y86.6933 Z7.0 F1367.465 E205.7948
( Linear move to (98.1075, 87.0539, 7.0). )
G1 X98.1075 Y87.0539 Z7.0 F1367.465 E205.81
( Linear move to (97.9968, 89.0503, 7.0). )
G1 X97.9968 Y89.0503 Z7.0 F1367.465 E205.8698
( Linear move to (97.6361, 89.411, 7.0). )
G1 X97.6361 Y89.411 Z7.0 F1367.465 E205.885
( Linear move to (95.6397, 89.5217, 7.0). )
G1 X95.6397 Y89.5217 Z7.0 F1367.465 E205.9447
( Linear move to (95.2791, 89.8824, 7.0). )
G1 X95.2791 Y89.8824 Z7.0 F1367.465 E205.96
( Linear move to (95.1683, 91.8788, 7.0). )
G1 X95.1683 Y91.8788 Z7.0 F1367.465 E206.0197
( Linear move to (94.8077, 92.2394, 7.0). )
G1 X94.8077 Y92.2394 Z7.0 F1367.465 E206.0349
( Linear move to (92.8113, 92.3502, 7.0). )
G1 X92.8113 Y92.3502 Z7.0 F1367.465 E206.0947
( Linear move to (92.4507, 92.7108, 7.0). )
G1 X92.4507 Y92.7108 Z7.0 F1367.465 E206.1099
( Linear move to (91.53, 94.48, 7.0). )
G1 X91.53 Y94.48 Z7.0 F1367.465 E206.1695
( Linear move to (92.3399, 94.7072, 7.0). )
G1 X92.3399 Y94.7072 Z7.0 F1367.465 E206.1946
( Linear move to (91.9793, 95.0678, 7.0). )
G1 X91.9793 Y95.0678 Z7.0 F1367.465 E206.2098
( Linear move to (91.53, 95.3285, 7.0). )
G1 X91.53 Y95.3285 Z7.0 F1367.465 E206.2253
( Linear move to (91.53, 97.8741, 7.0). )
G1 X91.53 Y97.8741 Z7.0 F1367.465 E206.3014
( Linear move to (91.8639, 98.3887, 7.0). )
G1 X91.8639 Y98.3887 Z7.0 F1367.465 E206.3197
( Linear move to (93.4797, 98.47, 7.0). )
G1 X93.4797 Y98.47 Z7.0 F1367.465 E206.368
( Linear move to (93.4797, 98.47, 7.0). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 7.0). )
G1 E205.368
( Linear move to (93.4797, 98.47, 7.0). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 7.4 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z7.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z7.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z7.4 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z7.4 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 7.4). )
G1 X90.36 Y80.36 Z7.4 F2757.1641
( Linear move to (90.36, 80.36, 7.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.4). )
G1 E206.368
( Linear move to (90.36, 80.36, 7.4). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 7.4). )
G1 X109.64 Y80.36 Z7.4 F1205.9536 E206.9441
( Linear move to (109.64, 99.64, 7.4). )
G1 X109.64 Y99.64 Z7.4 F1205.9536 E207.5202
( Linear move to (90.36, 99.64, 7.4). )
G1 X90.36 Y99.64 Z7.4 F1205.9536 E208.0963
( Linear move to (90.36, 80.36, 7.4). )
G1 X90.36 Y80.36 Z7.4 F1205.9536 E208.6724
( Linear move to (90.36, 80.36, 7.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.4). )
G1 E208.6724
( Linear move to (90.36, 80.36, 7.4). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 7.4). )
G1 X91.02 Y81.02 Z7.4 F6000.0
( Linear move to (91.02, 81.02, 7.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.4). )
G1 E208.6724
( Linear move to (91.02, 81.02, 7.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 7.4). )
G1 X108.98 Y81.02 Z7.4 F1607.9381 E209.2089
( Linear move to (108.98, 98.98, 7.4). )
G1 X108.98 Y98.98 Z7.4 F1607.9381 E209.7455
( Linear move to (91.02, 98.98, 7.4). )
G1 X91.02 Y98.98 Z7.4 F1607.9381 E210.282
( Linear move to (91.02, 81.02, 7.4). )
G1 X91.02 Y81.02 Z7.4 F1607.9381 E210.8186
( Linear move to (91.02, 81.02, 7.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.4). )
G1 E210.3675
( Linear move to (91.02, 81.02, 7.4). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z7.2 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z7.2 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z7.2 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z7.2 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 7.4). )
G1 X92.3785 Y81.53 Z7.4 F6000.0
( Linear move to (92.3785, 81.53, 7.4). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 7.4). )
G1 E210.8186
( Linear move to (92.3785, 81.53, 7.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 7.4). )
G1 X91.7376 Y81.7376 Z7.4 F1607.9381 E210.8387
( Linear move to (91.53, 82.3785, 7.4). )
G1 X91.53 Y82.3785 Z7.4 F1607.9381 E210.8588
( Linear move to (92.3219, 83.4115, 7.4). )
G1 X92.3219 Y83.4115 Z7.4 F1607.9381 E210.8977
( Linear move to (94.2075, 85.2971, 7.4). )
G1 X94.2075 Y85.2971 Z7.4 F1607.9381 E210.9774
( Linear move to (96.2399, 85.1503, 7.4). )
G1 X96.2399 Y85.1503 Z7.4 F1607.9381 E211.0383
( Linear move to (98.1256, 87.0359, 7.4). )
G1 X98.1256 Y87.0359 Z7.4 F1607.9381 E211.1179
( Linear move to (97.9787, 89.0684, 7.4). )
G1 X97.9787 Y89.0684 Z7.4 F1607.9381 E211.1788
( Linear move to (99.8643, 90.954, 7.4). )
G1 X99.8643 Y90.954 Z7.4 F1607.9381 E211.2585
( Linear move to (101.8968, 90.8071, 7.4). )
G1 X101.8968 Y90.8071 Z7.4 F1607.9381 E211.3193
( Linear move to (103.7824, 92.6928, 7.4). )
G1 X103.7824 Y92.6928 Z7.4 F1607.9381 E211.399
( Linear move to (103.6356, 94.7252, 7.4). )
G1 X103.6356 Y94.7252 Z7.4 F1607.9381 E211.4599
( Linear move to (107.6215, 98.47, 7.4). )
G1 X107.6215 Y98.47 Z7.4 F1607.9381 E211.6233
( Linear move to (108.2624, 98.2624, 7.4). )
G1 X108.2624 Y98.2624 Z7.4 F1607.9381 E211.6434
( Linear move to (108.47, 97.6215, 7.4). )
G1 X108.47 Y97.6215 Z7.4 F1607.9381 E211.6635
( Linear move to (108.47, 93.3788, 7.4). )
G1 X108.47 Y93.3788 Z7.4 F1607.9381 E211.7903
( Linear move to (106.1394, 92.2214, 7.4). )
G1 X106.1394 Y92.2214 Z7.4 F1607.9381 E211.868
( Linear move to (104.107, 92.3682, 7.4). )
G1 X104.107 Y92.3682 Z7.4 F1607.9381 E211.9289
( Linear move to (102.2214, 90.4826, 7.4). )
G1 X102.2214 Y90.4826 Z7.4 F1607.9381 E212.0086
( Linear move to (102.3682, 88.4501, 7.4). )
G1 X102.3682 Y88.4501 Z7.4 F1607.9381 E212.0694
( Linear move to (100.4826, 86.5645, 7.4). )
G1 X100.4826 Y86.5645 Z7.4 F1607.9381 E212.1491
( Linear move to (98.4501, 86.7113, 7.4). )
G1 X98.4501 Y86.7113 Z7.4 F1607.9381 E212.21
( Linear move to (93.2271, 81.53, 7.4). )
G1 X93.2271 Y81.53 Z7.4 F1607.9381 E212.4298
( Linear move to (97.4697, 81.53, 7.4). )
G1 X97.4697 Y81.53 Z7.4 F1607.9381 E212.5565
( Linear move to (96.8736, 82.631, 7.4). )
G1 X96.8736 Y82.631 Z7.4 F1607.9381 E212.5939
( Linear move to (98.6819, 82.0072, 7.4). )
G1 X98.6819 Y82.0072 Z7.4 F1607.9381 E212.6511
( Linear move to (99.1668, 81.53, 7.4). )
G1 X99.1668 Y81.53 Z7.4 F1607.9381 E212.6714
( Linear move to (100.954, 84.2075, 7.4). )
G1 X100.954 Y84.2075 Z7.4 F1607.9381 E212.7676
( Linear move to (100.8071, 86.2399, 7.4). )
G1 X100.8071 Y86.2399 Z7.4 F1607.9381 E212.8284
( Linear move to (102.6928, 88.1256, 7.4). )
G1 X102.6928 Y88.1256 Z7.4 F1607.9381 E212.9081
( Linear move to (104.7252, 87.9787, 7.4). )
G1 X104.7252 Y87.9787 Z7.4 F1607.9381 E212.969
( Linear move to (106.6108, 89.8643, 7.4). )
G1 X106.6108 Y89.8643 Z7.4 F1607.9381 E213.0487
( Linear move to (106.464, 91.8968, 7.4). )
G1 X106.464 Y91.8968 Z7.4 F1607.9381 E213.1095
( Linear move to (108.47, 92.5303, 7.4). )
G1 X108.47 Y92.5303 Z7.4 F1607.9381 E213.1724
( Linear move to (108.47, 88.2877, 7.4). )
G1 X108.47 Y88.2877 Z7.4 F1607.9381 E213.2991
( Linear move to (106.9354, 89.5398, 7.4). )
G1 X106.9354 Y89.5398 Z7.4 F1607.9381 E213.3583
( Linear move to (105.0498, 87.6542, 7.4). )
G1 X105.0498 Y87.6542 Z7.4 F1607.9381 E213.438
( Linear move to (105.1966, 85.6217, 7.4). )
G1 X105.1966 Y85.6217 Z7.4 F1607.9381 E213.4988
( Linear move to (103.311, 83.7361, 7.4). )
G1 X103.311 Y83.7361 Z7.4 F1607.9381 E213.5785
( Linear move to (101.2786, 83.8829, 7.4). )
G1 X101.2786 Y83.8829 Z7.4 F1607.9381 E213.6394
( Linear move to (100.0153, 81.53, 7.4). )
G1 X100.0153 Y81.53 Z7.4 F1607.9381 E213.7192
( Linear move to (105.1065, 81.53, 7.4). )
G1 X105.1065 Y81.53 Z7.4 F1607.9381 E213.8713
( Linear move to (103.6356, 83.4115, 7.4). )
G1 X103.6356 Y83.4115 Z7.4 F1607.9381 E213.9426
( Linear move to (105.5212, 85.2971, 7.4). )
G1 X105.5212 Y85.2971 Z7.4 F1607.9381 E214.0223
( Linear move to (108.47, 87.4391, 7.4). )
G1 X108.47 Y87.4391 Z7.4 F1607.9381 E214.1312
( Linear move to (108.47, 83.1965, 7.4). )
G1 X108.47 Y83.1965 Z7.4 F1607.9381 E214.2579
( Linear move to (105.955, 81.53, 7.4). )
G1 X105.955 Y81.53 Z7.4 F1607.9381 E214.348
( Linear move to (107.652, 81.53, 7.4). )
G1 X107.652 Y81.53 Z7.4 F1607.9381 E214.3987
( Linear move to (108.47, 82.348, 7.4). )
G1 X108.47 Y82.348 Z7.4 F1607.9381 E214.4333
( Linear move to (108.47, 82.348, 7.4). )
G1 F1200.0
( Linear move to (108.47, 82.348, 7.4). )
G1 E213.4333
( Linear move to (108.47, 82.348, 7.4). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 7.4). )
G1 X106.7729 Y98.47 Z7.4 F6000.0
( Linear move to (106.7729, 98.47, 7.4). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 7.4). )
G1 E214.4333
( Linear move to (106.7729, 98.47, 7.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 7.4). )
G1 X105.0759 Y98.47 Z7.4 F1607.9381 E214.484
( Linear move to (105.1966, 96.9354, 7.4). )
G1 X105.1966 Y96.9354 Z7.4 F1607.9381 E214.53
( Linear move to (103.311, 95.0498, 7.4). )
G1 X103.311 Y95.0498 Z7.4 F1607.9381 E214.6096
( Linear move to (101.2786, 95.1966, 7.4). )
G1 X101.2786 Y95.1966 Z7.4 F1607.9381 E214.6705
( Linear move to (99.3929, 93.311, 7.4). )
G1 X99.3929 Y93.311 Z7.4 F1607.9381 E214.7502
( Linear move to (99.5398, 91.2786, 7.4). )
G1 X99.5398 Y91.2786 Z7.4 F1607.9381 E214.8111
( Linear move to (97.6542, 89.3929, 7.4). )
G1 X97.6542 Y89.3929 Z7.4 F1607.9381 E214.8907
( Linear move to (95.6217, 89.5398, 7.4). )
G1 X95.6217 Y89.5398 Z7.4 F1607.9381 E214.9516
( Linear move to (93.7361, 87.6542, 7.4). )
G1 X93.7361 Y87.6542 Z7.4 F1607.9381 E215.0313
( Linear move to (93.8829, 85.6217, 7.4). )
G1 X93.8829 Y85.6217 Z7.4 F1607.9381 E215.0922
( Linear move to (91.53, 83.2271, 7.4). )
G1 X91.53 Y83.2271 Z7.4 F1607.9381 E215.1924
( Linear move to (91.53, 88.3182, 7.4). )
G1 X91.53 Y88.3182 Z7.4 F1607.9381 E215.3445
( Linear move to (93.4115, 87.9787, 7.4). )
G1 X93.4115 Y87.9787 Z7.4 F1607.9381 E215.4017
( Linear move to (95.2971, 89.8643, 7.4). )
G1 X95.2971 Y89.8643 Z7.4 F1607.9381 E215.4813
( Linear move to (95.1503, 91.8968, 7.4). )
G1 X95.1503 Y91.8968 Z7.4 F1607.9381 E215.5422
( Linear move to (97.0359, 93.7824, 7.4). )
G1 X97.0359 Y93.7824 Z7.4 F1607.9381 E215.6219
( Linear move to (99.0684, 93.6356, 7.4). )
G1 X99.0684 Y93.6356 Z7.4 F1607.9381 E215.6827
( Linear move to (100.954, 95.5212, 7.4). )
G1 X100.954 Y95.5212 Z7.4 F1607.9381 E215.7624
( Linear move to (100.8071, 97.5537, 7.4). )
G1 X100.8071 Y97.5537 Z7.4 F1607.9381 E215.8233
( Linear move to (103.3788, 97.87, 7.4). )
G1 X103.3788 Y97.87 Z7.4 F1607.9381 E215.9007
( Linear move to (104.2274, 98.47, 7.4). )
G1 X104.2274 Y98.47 Z7.4 F1607.9381 E215.9317
( Linear move to (99.9847, 98.47, 7.4). )
G1 X99.9847 Y98.47 Z7.4 F1607.9381 E216.0585
( Linear move to (100.4826, 97.8782, 7.4). )
G1 X100.4826 Y97.8782 Z7.4 F1607.9381 E216.0816
( Linear move to (99.3259, 97.9008, 7.4). )
G1 X99.3259 Y97.9008 Z7.4 F1607.9381 E216.1162
( Linear move to (98.2878, 98.1873, 7.4). )
G1 X98.2878 Y98.1873 Z7.4 F1607.9381 E216.1483
( Linear move to (96.5645, 96.1394, 7.4). )
G1 X96.5645 Y96.1394 Z7.4 F1607.9381 E216.2283
( Linear move to (96.7113, 94.107, 7.4). )
G1 X96.7113 Y94.107 Z7.4 F1607.9381 E216.2892
( Linear move to (94.8257, 92.2214, 7.4). )
G1 X94.8257 Y92.2214 Z7.4 F1607.9381 E216.3688
( Linear move to (92.7933, 92.3682, 7.4). )
G1 X92.7933 Y92.3682 Z7.4 F1607.9381 E216.4297
( Linear move to (92.13, 89.1668, 7.4). )
G1 X92.13 Y89.1668 Z7.4 F1607.9381 E216.5274
( Linear move to (91.53, 90.0153, 7.4). )
G1 X91.53 Y90.0153 Z7.4 F1607.9381 E216.5584
( Linear move to (91.53, 92.5609, 7.4). )
G1 X91.53 Y92.5609 Z7.4 F1607.9381 E216.6345
( Linear move to (92.4687, 92.6928, 7.4). )
G1 X92.4687 Y92.6928 Z7.4 F1607.9381 E216.6628
( Linear move to (91.53, 93.4094, 7.4). )
G1 X91.53 Y93.4094 Z7.4 F1607.9381 E216.6981
( Linear move to (91.53, 95.1065, 7.4). )
G1 X91.53 Y95.1065 Z7.4 F1607.9381 E216.7488
( Linear move to (92.1596, 94.8875, 7.4). )
G1 X92.1596 Y94.8875 Z7.4 F1607.9381 E216.7687
( Linear move to (94.2075, 96.6108, 7.4). )
G1 X94.2075 Y96.6108 Z7.4 F1607.9381 E216.8487
( Linear move to (96.2399, 96.464, 7.4). )
G1 X96.2399 Y96.464 Z7.4 F1607.9381 E216.9095
( Linear move to (97.4391, 98.47, 7.4). )
G1 X97.4391 Y98.47 Z7.4 F1607.9381 E216.9794
( Linear move to (94.045, 98.47, 7.4). )
G1 X94.045 Y98.47 Z7.4 F1607.9381 E217.0808
( Linear move to (93.8829, 96.9354, 7.4). )
G1 X93.8829 Y96.9354 Z7.4 F1607.9381 E217.1269
( Linear move to (91.53, 95.955, 7.4). )
G1 X91.53 Y95.955 Z7.4 F1607.9381 E217.203
( Linear move to (91.53, 97.652, 7.4). )
G1 X91.53 Y97.652 Z7.4 F1607.9381 E217.2537
( Linear move to (92.348, 98.47, 7.4). )
G1 X92.348 Y98.47 Z7.4 F1607.9381 E217.2883
( Linear move to (93.1965, 98.47, 7.4). )
G1 X93.1965 Y98.47 Z7.4 F1607.9381 E217.3136
( Linear move to (93.1965, 98.47, 7.4). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 7.4). )
G1 E216.3136
( Linear move to (93.1965, 98.47, 7.4). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 7.8 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z7.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z7.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z7.8 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z7.8 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 7.8). )
G1 X90.36 Y80.36 Z7.8 F2750.2729
( Linear move to (90.36, 80.36, 7.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.8). )
G1 E217.3136
( Linear move to (90.36, 80.36, 7.8). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 7.8). )
G1 X109.64 Y80.36 Z7.8 F1025.5987 E217.8899
( Linear move to (109.64, 99.64, 7.8). )
G1 X109.64 Y99.64 Z7.8 F1025.5987 E218.4662
( Linear move to (90.36, 99.64, 7.8). )
G1 X90.36 Y99.64 Z7.8 F1025.5987 E219.0425
( Linear move to (90.36, 80.36, 7.8). )
G1 X90.36 Y80.36 Z7.8 F1025.5987 E219.6188
( Linear move to (90.36, 80.36, 7.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 7.8). )
G1 E219.6188
( Linear move to (90.36, 80.36, 7.8). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 7.8). )
G1 X91.02 Y81.02 Z7.8 F6000.0
( Linear move to (91.02, 81.02, 7.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.8). )
G1 E219.6188
( Linear move to (91.02, 81.02, 7.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 7.8). )
G1 X108.98 Y81.02 Z7.8 F1367.465 E220.1553
( Linear move to (108.98, 98.98, 7.8). )
G1 X108.98 Y98.98 Z7.8 F1367.465 E220.6918
( Linear move to (91.02, 98.98, 7.8). )
G1 X91.02 Y98.98 Z7.8 F1367.465 E221.2283
( Linear move to (91.02, 81.02, 7.8). )
G1 X91.02 Y81.02 Z7.8 F1367.465 E221.7648
( Linear move to (91.02, 81.02, 7.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 7.8). )
G1 E220.7648
( Linear move to (91.02, 81.02, 7.8). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z7.6 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z7.6 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z7.6 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z7.6 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 7.8). )
G1 X91.53 Y93.6315 Z7.8 F6000.0
( Linear move to (91.53, 93.6315, 7.8). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 7.8). )
G1 E221.7648
( Linear move to (91.53, 93.6315, 7.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 7.8). )
G1 X91.53 Y87.6918 Z7.8 F1367.465 E221.9422
( Linear move to (93.3935, 87.9968, 7.8). )
G1 X93.3935 Y87.9968 Z7.8 F1367.465 E221.9986
( Linear move to (93.7541, 87.6361, 7.8). )
G1 X93.7541 Y87.6361 Z7.8 F1367.465 E222.0139
( Linear move to (93.8649, 85.6397, 7.8). )
G1 X93.8649 Y85.6397 Z7.8 F1367.465 E222.0736
( Linear move to (94.2255, 85.2791, 7.8). )
G1 X94.2255 Y85.2791 Z7.8 F1367.465 E222.0888
( Linear move to (96.2219, 85.1683, 7.8). )
G1 X96.2219 Y85.1683 Z7.8 F1367.465 E222.1486
( Linear move to (96.5825, 84.8077, 7.8). )
G1 X96.5825 Y84.8077 Z7.8 F1367.465 E222.1638
( Linear move to (103.6315, 82.13, 7.8). )
G1 X103.6315 Y82.13 Z7.8 F1367.465 E222.3891
( Linear move to (104.48, 81.53, 7.8). )
G1 X104.48 Y81.53 Z7.8 F1367.465 E222.4201
( Linear move to (93.4491, 81.53, 7.8). )
G1 X93.4491 Y81.53 Z7.8 F1367.465 E222.7496
( Linear move to (93.4491, 82.13, 7.8). )
G1 X93.4491 Y82.13 Z7.8 F1367.465 E222.7675
( Linear move to (92.13, 86.8432, 7.8). )
G1 X92.13 Y86.8432 Z7.8 F1367.465 E222.9137
( Linear move to (91.53, 85.9947, 7.8). )
G1 X91.53 Y85.9947 Z7.8 F1367.465 E222.9448
( Linear move to (91.53, 82.6006, 7.8). )
G1 X91.53 Y82.6006 Z7.8 F1367.465 E223.0462
( Linear move to (92.6006, 81.53, 7.8). )
G1 X92.6006 Y81.53 Z7.8 F1367.465 E223.0914
( Linear move to (92.6006, 81.53, 7.8). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 7.8). )
G1 E222.0914
( Linear move to (92.6006, 81.53, 7.8). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 7.8). )
G1 X108.47 Y97.0561 Z7.8 F6000.0
( Linear move to (108.47, 97.0561, 7.8). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 7.8). )
G1 E223.0914
( Linear move to (108.47, 97.0561, 7.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 7.8). )
G1 X108.47 Y97.9047 Z7.8 F1367.465 E223.1168
( Linear move to (107.9047, 98.47, 7.8). )
G1 X107.9047 Y98.47 Z7.8 F1367.465 E223.1406
( Linear move to (105.3591, 98.47, 7.8). )
G1 X105.3591 Y98.47 Z7.8 F1367.465 E223.2167
( Linear move to (105.1786, 96.9534, 7.8). )
G1 X105.1786 Y96.9534 Z7.8 F1367.465 E223.2623
( Linear move to (105.5392, 96.5928, 7.8). )
G1 X105.5392 Y96.5928 Z7.8 F1367.465 E223.2775
( Linear move to (108.47, 96.2076, 7.8). )
G1 X108.47 Y96.2076 Z7.8 F1367.465 E223.3658
( Linear move to (108.47, 89.4194, 7.8). )
G1 X108.47 Y89.4194 Z7.8 F1367.465 E223.5686
( Linear move to (106.9534, 89.5217, 7.8). )
G1 X106.9534 Y89.5217 Z7.8 F1367.465 E223.614
( Linear move to (106.5928, 89.8824, 7.8). )
G1 X106.5928 Y89.8824 Z7.8 F1367.465 E223.6293
( Linear move to (106.482, 91.8788, 7.8). )
G1 X106.482 Y91.8788 Z7.8 F1367.465 E223.689
( Linear move to (106.1214, 92.2394, 7.8). )
G1 X106.1214 Y92.2394 Z7.8 F1367.465 E223.7042
( Linear move to (104.125, 92.3502, 7.8). )
G1 X104.125 Y92.3502 Z7.8 F1367.465 E223.764
( Linear move to (103.7644, 92.7108, 7.8). )
G1 X103.7644 Y92.7108 Z7.8 F1367.465 E223.7792
( Linear move to (103.6536, 94.7072, 7.8). )
G1 X103.6536 Y94.7072 Z7.8 F1367.465 E223.8389
( Linear move to (103.293, 95.0678, 7.8). )
G1 X103.293 Y95.0678 Z7.8 F1367.465 E223.8542
( Linear move to (101.2966, 95.1786, 7.8). )
G1 X101.2966 Y95.1786 Z7.8 F1367.465 E223.9139
( Linear move to (100.936, 95.5392, 7.8). )
G1 X100.936 Y95.5392 Z7.8 F1367.465 E223.9291
( Linear move to (100.6449, 97.7159, 7.8). )
G1 X100.6449 Y97.7159 Z7.8 F1367.465 E223.9947
( Linear move to (104.5106, 97.87, 7.8). )
G1 X104.5106 Y97.87 Z7.8 F1367.465 E224.1103
( Linear move to (103.662, 98.47, 7.8). )
G1 X103.662 Y98.47 Z7.8 F1367.465 E224.1413
( Linear move to (98.5709, 98.47, 7.8). )
G1 X98.5709 Y98.47 Z7.8 F1367.465 E224.2934
( Linear move to (98.4682, 98.007, 7.8). )
G1 X98.4682 Y98.007 Z7.8 F1367.465 E224.3076
( Linear move to (98.1075, 98.3676, 7.8). )
G1 X98.1075 Y98.3676 Z7.8 F1367.465 E224.3228
( Linear move to (97.7223, 98.47, 7.8). )
G1 X97.7223 Y98.47 Z7.8 F1367.465 E224.3347
( Linear move to (94.3282, 98.47, 7.8). )
G1 X94.3282 Y98.47 Z7.8 F1367.465 E224.4361
( Linear move to (93.8649, 96.9534, 7.8). )
G1 X93.8649 Y96.9534 Z7.8 F1367.465 E224.4835
( Linear move to (94.2255, 96.5928, 7.8). )
G1 X94.2255 Y96.5928 Z7.8 F1367.465 E224.4987
( Linear move to (96.2219, 96.482, 7.8). )
G1 X96.2219 Y96.482 Z7.8 F1367.465 E224.5585
( Linear move to (96.5825, 96.1214, 7.8). )
G1 X96.5825 Y96.1214 Z7.8 F1367.465 E224.5737
( Linear move to (96.6933, 94.125, 7.8). )
G1 X96.6933 Y94.125 Z7.8 F1367.465 E224.6334
( Linear move to (97.0539, 93.7644, 7.8). )
G1 X97.0539 Y93.7644 Z7.8 F1367.465 E224.6487
( Linear move to (99.0503, 93.6536, 7.8). )
G1 X99.0503 Y93.6536 Z7.8 F1367.465 E224.7084
( Linear move to (99.411, 93.293, 7.8). )
G1 X99.411 Y93.293 Z7.8 F1367.465 E224.7236
( Linear move to (99.5217, 91.2966, 7.8). )
G1 X99.5217 Y91.2966 Z7.8 F1367.465 E224.7833
( Linear move to (99.8824, 90.936, 7.8). )
G1 X99.8824 Y90.936 Z7.8 F1367.465 E224.7986
( Linear move to (101.8788, 90.8252, 7.8). )
G1 X101.8788 Y90.8252 Z7.8 F1367.465 E224.8583
( Linear move to (102.2394, 90.4646, 7.8). )
G1 X102.2394 Y90.4646 Z7.8 F1367.465 E224.8735
( Linear move to (102.3502, 88.4682, 7.8). )
G1 X102.3502 Y88.4682 Z7.8 F1367.465 E224.9333
( Linear move to (102.7108, 88.1075, 7.8). )
G1 X102.7108 Y88.1075 Z7.8 F1367.465 E224.9485
( Linear move to (104.7072, 87.9968, 7.8). )
G1 X104.7072 Y87.9968 Z7.8 F1367.465 E225.0082
( Linear move to (105.0678, 87.6361, 7.8). )
G1 X105.0678 Y87.6361 Z7.8 F1367.465 E225.0235
( Linear move to (105.1786, 85.6397, 7.8). )
G1 X105.1786 Y85.6397 Z7.8 F1367.465 E225.0832
( Linear move to (105.5392, 85.2791, 7.8). )
G1 X105.5392 Y85.2791 Z7.8 F1367.465 E225.0984
( Linear move to (108.47, 88.5709, 7.8). )
G1 X108.47 Y88.5709 Z7.8 F1367.465 E225.2301
( Linear move to (108.3887, 81.8639, 7.8). )
G1 X108.3887 Y81.8639 Z7.8 F1367.465 E225.4305
( Linear move to (107.8741, 81.53, 7.8). )
G1 X107.8741 Y81.53 Z7.8 F1367.465 E225.4488
( Linear move to (106.1771, 81.53, 7.8). )
G1 X106.1771 Y81.53 Z7.8 F1367.465 E225.4995
( Linear move to (103.293, 83.7541, 7.8). )
G1 X103.293 Y83.7541 Z7.8 F1367.465 E225.6083
( Linear move to (101.2966, 83.8649, 7.8). )
G1 X101.2966 Y83.8649 Z7.8 F1367.465 E225.668
( Linear move to (100.936, 84.2255, 7.8). )
G1 X100.936 Y84.2255 Z7.8 F1367.465 E225.6833
( Linear move to (100.8252, 86.2219, 7.8). )
G1 X100.8252 Y86.2219 Z7.8 F1367.465 E225.743
( Linear move to (100.4646, 86.5825, 7.8). )
G1 X100.4646 Y86.5825 Z7.8 F1367.465 E225.7582
( Linear move to (98.4682, 86.6933, 7.8). )
G1 X98.4682 Y86.6933 Z7.8 F1367.465 E225.8179
( Linear move to (98.1075, 87.0539, 7.8). )
G1 X98.1075 Y87.0539 Z7.8 F1367.465 E225.8332
( Linear move to (97.9968, 89.0503, 7.8). )
G1 X97.9968 Y89.0503 Z7.8 F1367.465 E225.8929
( Linear move to (97.6361, 89.411, 7.8). )
G1 X97.6361 Y89.411 Z7.8 F1367.465 E225.9081
( Linear move to (95.6397, 89.5217, 7.8). )
G1 X95.6397 Y89.5217 Z7.8 F1367.465 E225.9679
( Linear move to (95.2791, 89.8824, 7.8). )
G1 X95.2791 Y89.8824 Z7.8 F1367.465 E225.9831
( Linear move to (95.1683, 91.8788, 7.8). )
G1 X95.1683 Y91.8788 Z7.8 F1367.465 E226.0428
( Linear move to (94.8077, 92.2394, 7.8). )
G1 X94.8077 Y92.2394 Z7.8 F1367.465 E226.0581
( Linear move to (92.8113, 92.3502, 7.8). )
G1 X92.8113 Y92.3502 Z7.8 F1367.465 E226.1178
( Linear move to (92.4507, 92.7108, 7.8). )
G1 X92.4507 Y92.7108 Z7.8 F1367.465 E226.133
( Linear move to (91.53, 94.48, 7.8). )
G1 X91.53 Y94.48 Z7.8 F1367.465 E226.1926
( Linear move to (92.3399, 94.7072, 7.8). )
G1 X92.3399 Y94.7072 Z7.8 F1367.465 E226.2177
( Linear move to (91.9793, 95.0678, 7.8). )
G1 X91.9793 Y95.0678 Z7.8 F1367.465 E226.233
( Linear move to (91.53, 95.3285, 7.8). )
G1 X91.53 Y95.3285 Z7.8 F1367.465 E226.2485
( Linear move to (91.53, 97.8741, 7.8). )
G1 X91.53 Y97.8741 Z7.8 F1367.465 E226.3245
( Linear move to (91.8639, 98.3887, 7.8). )
G1 X91.8639 Y98.3887 Z7.8 F1367.465 E226.3429
( Linear move to (93.4797, 98.47, 7.8). )
G1 X93.4797 Y98.47 Z7.8 F1367.465 E226.3912
( Linear move to (93.4797, 98.47, 7.8). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 7.8). )
G1 E225.3912
( Linear move to (93.4797, 98.47, 7.8). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 14.74. )
M108 S14.74
(</layer>)
(<layer> 8.2 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z8.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z8.2 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z8.2 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z8.2 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 8.2). )
G1 X90.36 Y80.36 Z8.2 F2757.1641
( Linear move to (90.36, 80.36, 8.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 8.2). )
G1 E226.3912
( Linear move to (90.36, 80.36, 8.2). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 8.2). )
G1 X109.64 Y80.36 Z8.2 F1205.9536 E226.9673
( Linear move to (109.64, 99.64, 8.2). )
G1 X109.64 Y99.64 Z8.2 F1205.9536 E227.5434
( Linear move to (90.36, 99.64, 8.2). )
G1 X90.36 Y99.64 Z8.2 F1205.9536 E228.1194
( Linear move to (90.36, 80.36, 8.2). )
G1 X90.36 Y80.36 Z8.2 F1205.9536 E228.6955
( Linear move to (90.36, 80.36, 8.2). )
G1 F1200.0
( Linear move to (90.36, 80.36, 8.2). )
G1 E228.6955
( Linear move to (90.36, 80.36, 8.2). )
G1 F1205.9536
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 19.65. )
M108 S19.65
( Linear move to (91.02, 81.02, 8.2). )
G1 X91.02 Y81.02 Z8.2 F6000.0
( Linear move to (91.02, 81.02, 8.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 8.2). )
G1 E228.6955
( Linear move to (91.02, 81.02, 8.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 8.2). )
G1 X108.98 Y81.02 Z8.2 F1607.9381 E229.2321
( Linear move to (108.98, 98.98, 8.2). )
G1 X108.98 Y98.98 Z8.2 F1607.9381 E229.7686
( Linear move to (91.02, 98.98, 8.2). )
G1 X91.02 Y98.98 Z8.2 F1607.9381 E230.3052
( Linear move to (91.02, 81.02, 8.2). )
G1 X91.02 Y81.02 Z8.2 F1607.9381 E230.8417
( Linear move to (91.02, 81.02, 8.2). )
G1 F1200.0
( Linear move to (91.02, 81.02, 8.2). )
G1 E230.3907
( Linear move to (91.02, 81.02, 8.2). )
G1 F1607.9381
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z8.0 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z8.0 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z8.0 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z8.0 </infillPoint>)
(</infillBoundary>)
( Linear move to (92.3785, 81.53, 8.2). )
G1 X92.3785 Y81.53 Z8.2 F6000.0
( Linear move to (92.3785, 81.53, 8.2). )
G1 F1200.0
( Linear move to (92.3785, 81.53, 8.2). )
G1 E230.8417
( Linear move to (92.3785, 81.53, 8.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.7376, 81.7376, 8.2). )
G1 X91.7376 Y81.7376 Z8.2 F1607.9381 E230.8619
( Linear move to (91.53, 82.3785, 8.2). )
G1 X91.53 Y82.3785 Z8.2 F1607.9381 E230.882
( Linear move to (92.3219, 83.4115, 8.2). )
G1 X92.3219 Y83.4115 Z8.2 F1607.9381 E230.9209
( Linear move to (94.2075, 85.2971, 8.2). )
G1 X94.2075 Y85.2971 Z8.2 F1607.9381 E231.0005
( Linear move to (96.2399, 85.1503, 8.2). )
G1 X96.2399 Y85.1503 Z8.2 F1607.9381 E231.0614
( Linear move to (98.1256, 87.0359, 8.2). )
G1 X98.1256 Y87.0359 Z8.2 F1607.9381 E231.1411
( Linear move to (97.9787, 89.0684, 8.2). )
G1 X97.9787 Y89.0684 Z8.2 F1607.9381 E231.202
( Linear move to (99.8643, 90.954, 8.2). )
G1 X99.8643 Y90.954 Z8.2 F1607.9381 E231.2816
( Linear move to (101.8968, 90.8071, 8.2). )
G1 X101.8968 Y90.8071 Z8.2 F1607.9381 E231.3425
( Linear move to (103.7824, 92.6928, 8.2). )
G1 X103.7824 Y92.6928 Z8.2 F1607.9381 E231.4222
( Linear move to (103.6356, 94.7252, 8.2). )
G1 X103.6356 Y94.7252 Z8.2 F1607.9381 E231.483
( Linear move to (107.6215, 98.47, 8.2). )
G1 X107.6215 Y98.47 Z8.2 F1607.9381 E231.6464
( Linear move to (108.2624, 98.2624, 8.2). )
G1 X108.2624 Y98.2624 Z8.2 F1607.9381 E231.6666
( Linear move to (108.47, 97.6215, 8.2). )
G1 X108.47 Y97.6215 Z8.2 F1607.9381 E231.6867
( Linear move to (108.47, 93.3788, 8.2). )
G1 X108.47 Y93.3788 Z8.2 F1607.9381 E231.8134
( Linear move to (106.1394, 92.2214, 8.2). )
G1 X106.1394 Y92.2214 Z8.2 F1607.9381 E231.8912
( Linear move to (104.107, 92.3682, 8.2). )
G1 X104.107 Y92.3682 Z8.2 F1607.9381 E231.952
( Linear move to (102.2214, 90.4826, 8.2). )
G1 X102.2214 Y90.4826 Z8.2 F1607.9381 E232.0317
( Linear move to (102.3682, 88.4501, 8.2). )
G1 X102.3682 Y88.4501 Z8.2 F1607.9381 E232.0926
( Linear move to (100.4826, 86.5645, 8.2). )
G1 X100.4826 Y86.5645 Z8.2 F1607.9381 E232.1723
( Linear move to (98.4501, 86.7113, 8.2). )
G1 X98.4501 Y86.7113 Z8.2 F1607.9381 E232.2331
( Linear move to (93.2271, 81.53, 8.2). )
G1 X93.2271 Y81.53 Z8.2 F1607.9381 E232.4529
( Linear move to (97.4697, 81.53, 8.2). )
G1 X97.4697 Y81.53 Z8.2 F1607.9381 E232.5797
( Linear move to (96.8736, 82.631, 8.2). )
G1 X96.8736 Y82.631 Z8.2 F1607.9381 E232.6171
( Linear move to (98.6819, 82.0072, 8.2). )
G1 X98.6819 Y82.0072 Z8.2 F1607.9381 E232.6742
( Linear move to (99.1668, 81.53, 8.2). )
G1 X99.1668 Y81.53 Z8.2 F1607.9381 E232.6945
( Linear move to (100.954, 84.2075, 8.2). )
G1 X100.954 Y84.2075 Z8.2 F1607.9381 E232.7907
( Linear move to (100.8071, 86.2399, 8.2). )
G1 X100.8071 Y86.2399 Z8.2 F1607.9381 E232.8516
( Linear move to (102.6928, 88.1256, 8.2). )
G1 X102.6928 Y88.1256 Z8.2 F1607.9381 E232.9313
( Linear move to (104.7252, 87.9787, 8.2). )
G1 X104.7252 Y87.9787 Z8.2 F1607.9381 E232.9921
( Linear move to (106.6108, 89.8643, 8.2). )
G1 X106.6108 Y89.8643 Z8.2 F1607.9381 E233.0718
( Linear move to (106.464, 91.8968, 8.2). )
G1 X106.464 Y91.8968 Z8.2 F1607.9381 E233.1327
( Linear move to (108.47, 92.5303, 8.2). )
G1 X108.47 Y92.5303 Z8.2 F1607.9381 E233.1955
( Linear move to (108.47, 88.2877, 8.2). )
G1 X108.47 Y88.2877 Z8.2 F1607.9381 E233.3223
( Linear move to (106.9354, 89.5398, 8.2). )
G1 X106.9354 Y89.5398 Z8.2 F1607.9381 E233.3814
( Linear move to (105.0498, 87.6542, 8.2). )
G1 X105.0498 Y87.6542 Z8.2 F1607.9381 E233.4611
( Linear move to (105.1966, 85.6217, 8.2). )
G1 X105.1966 Y85.6217 Z8.2 F1607.9381 E233.522
( Linear move to (103.311, 83.7361, 8.2). )
G1 X103.311 Y83.7361 Z8.2 F1607.9381 E233.6017
( Linear move to (101.2786, 83.8829, 8.2). )
G1 X101.2786 Y83.8829 Z8.2 F1607.9381 E233.6625
( Linear move to (100.0153, 81.53, 8.2). )
G1 X100.0153 Y81.53 Z8.2 F1607.9381 E233.7423
( Linear move to (105.1065, 81.53, 8.2). )
G1 X105.1065 Y81.53 Z8.2 F1607.9381 E233.8944
( Linear move to (103.6356, 83.4115, 8.2). )
G1 X103.6356 Y83.4115 Z8.2 F1607.9381 E233.9658
( Linear move to (105.5212, 85.2971, 8.2). )
G1 X105.5212 Y85.2971 Z8.2 F1607.9381 E234.0454
( Linear move to (108.47, 87.4391, 8.2). )
G1 X108.47 Y87.4391 Z8.2 F1607.9381 E234.1543
( Linear move to (108.47, 83.1965, 8.2). )
G1 X108.47 Y83.1965 Z8.2 F1607.9381 E234.2811
( Linear move to (105.955, 81.53, 8.2). )
G1 X105.955 Y81.53 Z8.2 F1607.9381 E234.3712
( Linear move to (107.652, 81.53, 8.2). )
G1 X107.652 Y81.53 Z8.2 F1607.9381 E234.4219
( Linear move to (108.47, 82.348, 8.2). )
G1 X108.47 Y82.348 Z8.2 F1607.9381 E234.4564
( Linear move to (108.47, 82.348, 8.2). )
G1 F1200.0
( Linear move to (108.47, 82.348, 8.2). )
G1 E233.4564
( Linear move to (108.47, 82.348, 8.2). )
G1 F1607.9381
( Extruder off. )
M103
( Linear move to (106.7729, 98.47, 8.2). )
G1 X106.7729 Y98.47 Z8.2 F6000.0
( Linear move to (106.7729, 98.47, 8.2). )
G1 F1200.0
( Linear move to (106.7729, 98.47, 8.2). )
G1 E234.4564
( Linear move to (106.7729, 98.47, 8.2). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (105.0759, 98.47, 8.2). )
G1 X105.0759 Y98.47 Z8.2 F1607.9381 E234.5071
( Linear move to (105.1966, 96.9354, 8.2). )
G1 X105.1966 Y96.9354 Z8.2 F1607.9381 E234.5531
( Linear move to (103.311, 95.0498, 8.2). )
G1 X103.311 Y95.0498 Z8.2 F1607.9381 E234.6328
( Linear move to (101.2786, 95.1966, 8.2). )
G1 X101.2786 Y95.1966 Z8.2 F1607.9381 E234.6937
( Linear move to (99.3929, 93.311, 8.2). )
G1 X99.3929 Y93.311 Z8.2 F1607.9381 E234.7733
( Linear move to (99.5398, 91.2786, 8.2). )
G1 X99.5398 Y91.2786 Z8.2 F1607.9381 E234.8342
( Linear move to (97.6542, 89.3929, 8.2). )
G1 X97.6542 Y89.3929 Z8.2 F1607.9381 E234.9139
( Linear move to (95.6217, 89.5398, 8.2). )
G1 X95.6217 Y89.5398 Z8.2 F1607.9381 E234.9748
( Linear move to (93.7361, 87.6542, 8.2). )
G1 X93.7361 Y87.6542 Z8.2 F1607.9381 E235.0544
( Linear move to (93.8829, 85.6217, 8.2). )
G1 X93.8829 Y85.6217 Z8.2 F1607.9381 E235.1153
( Linear move to (91.53, 83.2271, 8.2). )
G1 X91.53 Y83.2271 Z8.2 F1607.9381 E235.2156
( Linear move to (91.53, 88.3182, 8.2). )
G1 X91.53 Y88.3182 Z8.2 F1607.9381 E235.3677
( Linear move to (93.4115, 87.9787, 8.2). )
G1 X93.4115 Y87.9787 Z8.2 F1607.9381 E235.4248
( Linear move to (95.2971, 89.8643, 8.2). )
G1 X95.2971 Y89.8643 Z8.2 F1607.9381 E235.5045
( Linear move to (95.1503, 91.8968, 8.2). )
G1 X95.1503 Y91.8968 Z8.2 F1607.9381 E235.5654
( Linear move to (97.0359, 93.7824, 8.2). )
G1 X97.0359 Y93.7824 Z8.2 F1607.9381 E235.645
( Linear move to (99.0684, 93.6356, 8.2). )
G1 X99.0684 Y93.6356 Z8.2 F1607.9381 E235.7059
( Linear move to (100.954, 95.5212, 8.2). )
G1 X100.954 Y95.5212 Z8.2 F1607.9381 E235.7856
( Linear move to (100.8071, 97.5537, 8.2). )
G1 X100.8071 Y97.5537 Z8.2 F1607.9381 E235.8464
( Linear move to (103.3788, 97.87, 8.2). )
G1 X103.3788 Y97.87 Z8.2 F1607.9381 E235.9239
( Linear move to (104.2274, 98.47, 8.2). )
G1 X104.2274 Y98.47 Z8.2 F1607.9381 E235.9549
( Linear move to (99.9847, 98.47, 8.2). )
G1 X99.9847 Y98.47 Z8.2 F1607.9381 E236.0816
( Linear move to (100.4826, 97.8782, 8.2). )
G1 X100.4826 Y97.8782 Z8.2 F1607.9381 E236.1048
( Linear move to (99.3259, 97.9008, 8.2). )
G1 X99.3259 Y97.9008 Z8.2 F1607.9381 E236.1393
( Linear move to (98.2878, 98.1873, 8.2). )
G1 X98.2878 Y98.1873 Z8.2 F1607.9381 E236.1715
( Linear move to (96.5645, 96.1394, 8.2). )
G1 X96.5645 Y96.1394 Z8.2 F1607.9381 E236.2514
( Linear move to (96.7113, 94.107, 8.2). )
G1 X96.7113 Y94.107 Z8.2 F1607.9381 E236.3123
( Linear move to (94.8257, 92.2214, 8.2). )
G1 X94.8257 Y92.2214 Z8.2 F1607.9381 E236.392
( Linear move to (92.7933, 92.3682, 8.2). )
G1 X92.7933 Y92.3682 Z8.2 F1607.9381 E236.4529
( Linear move to (92.13, 89.1668, 8.2). )
G1 X92.13 Y89.1668 Z8.2 F1607.9381 E236.5505
( Linear move to (91.53, 90.0153, 8.2). )
G1 X91.53 Y90.0153 Z8.2 F1607.9381 E236.5816
( Linear move to (91.53, 92.5609, 8.2). )
G1 X91.53 Y92.5609 Z8.2 F1607.9381 E236.6576
( Linear move to (92.4687, 92.6928, 8.2). )
G1 X92.4687 Y92.6928 Z8.2 F1607.9381 E236.686
( Linear move to (91.53, 93.4094, 8.2). )
G1 X91.53 Y93.4094 Z8.2 F1607.9381 E236.7212
( Linear move to (91.53, 95.1065, 8.2). )
G1 X91.53 Y95.1065 Z8.2 F1607.9381 E236.7719
( Linear move to (92.1596, 94.8875, 8.2). )
G1 X92.1596 Y94.8875 Z8.2 F1607.9381 E236.7918
( Linear move to (94.2075, 96.6108, 8.2). )
G1 X94.2075 Y96.6108 Z8.2 F1607.9381 E236.8718
( Linear move to (96.2399, 96.464, 8.2). )
G1 X96.2399 Y96.464 Z8.2 F1607.9381 E236.9327
( Linear move to (97.4391, 98.47, 8.2). )
G1 X97.4391 Y98.47 Z8.2 F1607.9381 E237.0025
( Linear move to (94.045, 98.47, 8.2). )
G1 X94.045 Y98.47 Z8.2 F1607.9381 E237.1039
( Linear move to (93.8829, 96.9354, 8.2). )
G1 X93.8829 Y96.9354 Z8.2 F1607.9381 E237.15
( Linear move to (91.53, 95.955, 8.2). )
G1 X91.53 Y95.955 Z8.2 F1607.9381 E237.2262
( Linear move to (91.53, 97.652, 8.2). )
G1 X91.53 Y97.652 Z8.2 F1607.9381 E237.2769
( Linear move to (92.348, 98.47, 8.2). )
G1 X92.348 Y98.47 Z8.2 F1607.9381 E237.3114
( Linear move to (93.1965, 98.47, 8.2). )
G1 X93.1965 Y98.47 Z8.2 F1607.9381 E237.3368
( Linear move to (93.1965, 98.47, 8.2). )
G1 F1200.0
( Linear move to (93.1965, 98.47, 8.2). )
G1 E236.3368
( Linear move to (93.1965, 98.47, 8.2). )
G1 F1607.9381
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 12.54. )
M108 S12.54
(</layer>)
(<layer> 8.6 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z8.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z8.6 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z8.6 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z8.6 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 8.6). )
G1 X90.36 Y80.36 Z8.6 F2750.2729
( Linear move to (90.36, 80.36, 8.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 8.6). )
G1 E237.3368
( Linear move to (90.36, 80.36, 8.6). )
G1 F2750.2729
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 8.6). )
G1 X109.64 Y80.36 Z8.6 F1025.5987 E237.913
( Linear move to (109.64, 99.64, 8.6). )
G1 X109.64 Y99.64 Z8.6 F1025.5987 E238.4893
( Linear move to (90.36, 99.64, 8.6). )
G1 X90.36 Y99.64 Z8.6 F1025.5987 E239.0656
( Linear move to (90.36, 80.36, 8.6). )
G1 X90.36 Y80.36 Z8.6 F1025.5987 E239.6419
( Linear move to (90.36, 80.36, 8.6). )
G1 F1200.0
( Linear move to (90.36, 80.36, 8.6). )
G1 E239.6419
( Linear move to (90.36, 80.36, 8.6). )
G1 F1025.5987
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 16.71. )
M108 S16.71
( Linear move to (91.02, 81.02, 8.6). )
G1 X91.02 Y81.02 Z8.6 F6000.0
( Linear move to (91.02, 81.02, 8.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 8.6). )
G1 E239.6419
( Linear move to (91.02, 81.02, 8.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 8.6). )
G1 X108.98 Y81.02 Z8.6 F1367.465 E240.1784
( Linear move to (108.98, 98.98, 8.6). )
G1 X108.98 Y98.98 Z8.6 F1367.465 E240.7149
( Linear move to (91.02, 98.98, 8.6). )
G1 X91.02 Y98.98 Z8.6 F1367.465 E241.2514
( Linear move to (91.02, 81.02, 8.6). )
G1 X91.02 Y81.02 Z8.6 F1367.465 E241.7879
( Linear move to (91.02, 81.02, 8.6). )
G1 F1200.0
( Linear move to (91.02, 81.02, 8.6). )
G1 E240.7879
( Linear move to (91.02, 81.02, 8.6). )
G1 F1367.465
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z8.4 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z8.4 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z8.4 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z8.4 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.53, 93.6315, 8.6). )
G1 X91.53 Y93.6315 Z8.6 F6000.0
( Linear move to (91.53, 93.6315, 8.6). )
G1 F1200.0
( Linear move to (91.53, 93.6315, 8.6). )
G1 E241.7879
( Linear move to (91.53, 93.6315, 8.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (91.53, 87.6918, 8.6). )
G1 X91.53 Y87.6918 Z8.6 F1367.465 E241.9654
( Linear move to (93.3935, 87.9968, 8.6). )
G1 X93.3935 Y87.9968 Z8.6 F1367.465 E242.0218
( Linear move to (93.7541, 87.6361, 8.6). )
G1 X93.7541 Y87.6361 Z8.6 F1367.465 E242.037
( Linear move to (93.8649, 85.6397, 8.6). )
G1 X93.8649 Y85.6397 Z8.6 F1367.465 E242.0968
( Linear move to (94.2255, 85.2791, 8.6). )
G1 X94.2255 Y85.2791 Z8.6 F1367.465 E242.112
( Linear move to (96.2219, 85.1683, 8.6). )
G1 X96.2219 Y85.1683 Z8.6 F1367.465 E242.1717
( Linear move to (96.5825, 84.8077, 8.6). )
G1 X96.5825 Y84.8077 Z8.6 F1367.465 E242.1869
( Linear move to (103.6315, 82.13, 8.6). )
G1 X103.6315 Y82.13 Z8.6 F1367.465 E242.4122
( Linear move to (104.48, 81.53, 8.6). )
G1 X104.48 Y81.53 Z8.6 F1367.465 E242.4432
( Linear move to (93.4491, 81.53, 8.6). )
G1 X93.4491 Y81.53 Z8.6 F1367.465 E242.7728
( Linear move to (93.4491, 82.13, 8.6). )
G1 X93.4491 Y82.13 Z8.6 F1367.465 E242.7907
( Linear move to (92.13, 86.8432, 8.6). )
G1 X92.13 Y86.8432 Z8.6 F1367.465 E242.9369
( Linear move to (91.53, 85.9947, 8.6). )
G1 X91.53 Y85.9947 Z8.6 F1367.465 E242.9679
( Linear move to (91.53, 82.6006, 8.6). )
G1 X91.53 Y82.6006 Z8.6 F1367.465 E243.0693
( Linear move to (92.6006, 81.53, 8.6). )
G1 X92.6006 Y81.53 Z8.6 F1367.465 E243.1146
( Linear move to (92.6006, 81.53, 8.6). )
G1 F1200.0
( Linear move to (92.6006, 81.53, 8.6). )
G1 E242.1146
( Linear move to (92.6006, 81.53, 8.6). )
G1 F1367.465
( Extruder off. )
M103
( Linear move to (108.47, 97.0561, 8.6). )
G1 X108.47 Y97.0561 Z8.6 F6000.0
( Linear move to (108.47, 97.0561, 8.6). )
G1 F1200.0
( Linear move to (108.47, 97.0561, 8.6). )
G1 E243.1146
( Linear move to (108.47, 97.0561, 8.6). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.47, 97.9047, 8.6). )
G1 X108.47 Y97.9047 Z8.6 F1367.465 E243.1399
( Linear move to (107.9047, 98.47, 8.6). )
G1 X107.9047 Y98.47 Z8.6 F1367.465 E243.1638
( Linear move to (105.3591, 98.47, 8.6). )
G1 X105.3591 Y98.47 Z8.6 F1367.465 E243.2398
( Linear move to (105.1786, 96.9534, 8.6). )
G1 X105.1786 Y96.9534 Z8.6 F1367.465 E243.2855
( Linear move to (105.5392, 96.5928, 8.6). )
G1 X105.5392 Y96.5928 Z8.6 F1367.465 E243.3007
( Linear move to (108.47, 96.2076, 8.6). )
G1 X108.47 Y96.2076 Z8.6 F1367.465 E243.389
( Linear move to (108.47, 89.4194, 8.6). )
G1 X108.47 Y89.4194 Z8.6 F1367.465 E243.5918
( Linear move to (106.9534, 89.5217, 8.6). )
G1 X106.9534 Y89.5217 Z8.6 F1367.465 E243.6372
( Linear move to (106.5928, 89.8824, 8.6). )
G1 X106.5928 Y89.8824 Z8.6 F1367.465 E243.6524
( Linear move to (106.482, 91.8788, 8.6). )
G1 X106.482 Y91.8788 Z8.6 F1367.465 E243.7121
( Linear move to (106.1214, 92.2394, 8.6). )
G1 X106.1214 Y92.2394 Z8.6 F1367.465 E243.7274
( Linear move to (104.125, 92.3502, 8.6). )
G1 X104.125 Y92.3502 Z8.6 F1367.465 E243.7871
( Linear move to (103.7644, 92.7108, 8.6). )
G1 X103.7644 Y92.7108 Z8.6 F1367.465 E243.8023
( Linear move to (103.6536, 94.7072, 8.6). )
G1 X103.6536 Y94.7072 Z8.6 F1367.465 E243.8621
( Linear move to (103.293, 95.0678, 8.6). )
G1 X103.293 Y95.0678 Z8.6 F1367.465 E243.8773
( Linear move to (101.2966, 95.1786, 8.6). )
G1 X101.2966 Y95.1786 Z8.6 F1367.465 E243.937
( Linear move to (100.936, 95.5392, 8.6). )
G1 X100.936 Y95.5392 Z8.6 F1367.465 E243.9523
( Linear move to (100.6449, 97.7159, 8.6). )
G1 X100.6449 Y97.7159 Z8.6 F1367.465 E244.0179
( Linear move to (104.5106, 97.87, 8.6). )
G1 X104.5106 Y97.87 Z8.6 F1367.465 E244.1334
( Linear move to (103.662, 98.47, 8.6). )
G1 X103.662 Y98.47 Z8.6 F1367.465 E244.1645
( Linear move to (98.5709, 98.47, 8.6). )
G1 X98.5709 Y98.47 Z8.6 F1367.465 E244.3166
( Linear move to (98.4682, 98.007, 8.6). )
G1 X98.4682 Y98.007 Z8.6 F1367.465 E244.3307
( Linear move to (98.1075, 98.3676, 8.6). )
G1 X98.1075 Y98.3676 Z8.6 F1367.465 E244.346
( Linear move to (97.7223, 98.47, 8.6). )
G1 X97.7223 Y98.47 Z8.6 F1367.465 E244.3579
( Linear move to (94.3282, 98.47, 8.6). )
G1 X94.3282 Y98.47 Z8.6 F1367.465 E244.4593
( Linear move to (93.8649, 96.9534, 8.6). )
G1 X93.8649 Y96.9534 Z8.6 F1367.465 E244.5066
( Linear move to (94.2255, 96.5928, 8.6). )
G1 X94.2255 Y96.5928 Z8.6 F1367.465 E244.5219
( Linear move to (96.2219, 96.482, 8.6). )
G1 X96.2219 Y96.482 Z8.6 F1367.465 E244.5816
( Linear move to (96.5825, 96.1214, 8.6). )
G1 X96.5825 Y96.1214 Z8.6 F1367.465 E244.5968
( Linear move to (96.6933, 94.125, 8.6). )
G1 X96.6933 Y94.125 Z8.6 F1367.465 E244.6566
( Linear move to (97.0539, 93.7644, 8.6). )
G1 X97.0539 Y93.7644 Z8.6 F1367.465 E244.6718
( Linear move to (99.0503, 93.6536, 8.6). )
G1 X99.0503 Y93.6536 Z8.6 F1367.465 E244.7315
( Linear move to (99.411, 93.293, 8.6). )
G1 X99.411 Y93.293 Z8.6 F1367.465 E244.7468
( Linear move to (99.5217, 91.2966, 8.6). )
G1 X99.5217 Y91.2966 Z8.6 F1367.465 E244.8065
( Linear move to (99.8824, 90.936, 8.6). )
G1 X99.8824 Y90.936 Z8.6 F1367.465 E244.8217
( Linear move to (101.8788, 90.8252, 8.6). )
G1 X101.8788 Y90.8252 Z8.6 F1367.465 E244.8815
( Linear move to (102.2394, 90.4646, 8.6). )
G1 X102.2394 Y90.4646 Z8.6 F1367.465 E244.8967
( Linear move to (102.3502, 88.4682, 8.6). )
G1 X102.3502 Y88.4682 Z8.6 F1367.465 E244.9564
( Linear move to (102.7108, 88.1075, 8.6). )
G1 X102.7108 Y88.1075 Z8.6 F1367.465 E244.9717
( Linear move to (104.7072, 87.9968, 8.6). )
G1 X104.7072 Y87.9968 Z8.6 F1367.465 E245.0314
( Linear move to (105.0678, 87.6361, 8.6). )
G1 X105.0678 Y87.6361 Z8.6 F1367.465 E245.0466
( Linear move to (105.1786, 85.6397, 8.6). )
G1 X105.1786 Y85.6397 Z8.6 F1367.465 E245.1064
( Linear move to (105.5392, 85.2791, 8.6). )
G1 X105.5392 Y85.2791 Z8.6 F1367.465 E245.1216
( Linear move to (108.47, 88.5709, 8.6). )
G1 X108.47 Y88.5709 Z8.6 F1367.465 E245.2533
( Linear move to (108.3887, 81.8639, 8.6). )
G1 X108.3887 Y81.8639 Z8.6 F1367.465 E245.4536
( Linear move to (107.8741, 81.53, 8.6). )
G1 X107.8741 Y81.53 Z8.6 F1367.465 E245.4719
( Linear move to (106.1771, 81.53, 8.6). )
G1 X106.1771 Y81.53 Z8.6 F1367.465 E245.5226
( Linear move to (103.293, 83.7541, 8.6). )
G1 X103.293 Y83.7541 Z8.6 F1367.465 E245.6314
( Linear move to (101.2966, 83.8649, 8.6). )
G1 X101.2966 Y83.8649 Z8.6 F1367.465 E245.6912
( Linear move to (100.936, 84.2255, 8.6). )
G1 X100.936 Y84.2255 Z8.6 F1367.465 E245.7064
( Linear move to (100.8252, 86.2219, 8.6). )
G1 X100.8252 Y86.2219 Z8.6 F1367.465 E245.7661
( Linear move to (100.4646, 86.5825, 8.6). )
G1 X100.4646 Y86.5825 Z8.6 F1367.465 E245.7814
( Linear move to (98.4682, 86.6933, 8.6). )
G1 X98.4682 Y86.6933 Z8.6 F1367.465 E245.8411
( Linear move to (98.1075, 87.0539, 8.6). )
G1 X98.1075 Y87.0539 Z8.6 F1367.465 E245.8563
( Linear move to (97.9968, 89.0503, 8.6). )
G1 X97.9968 Y89.0503 Z8.6 F1367.465 E245.9161
( Linear move to (97.6361, 89.411, 8.6). )
G1 X97.6361 Y89.411 Z8.6 F1367.465 E245.9313
( Linear move to (95.6397, 89.5217, 8.6). )
G1 X95.6397 Y89.5217 Z8.6 F1367.465 E245.991
( Linear move to (95.2791, 89.8824, 8.6). )
G1 X95.2791 Y89.8824 Z8.6 F1367.465 E246.0063
( Linear move to (95.1683, 91.8788, 8.6). )
G1 X95.1683 Y91.8788 Z8.6 F1367.465 E246.066
( Linear move to (94.8077, 92.2394, 8.6). )
G1 X94.8077 Y92.2394 Z8.6 F1367.465 E246.0812
( Linear move to (92.8113, 92.3502, 8.6). )
G1 X92.8113 Y92.3502 Z8.6 F1367.465 E246.141
( Linear move to (92.4507, 92.7108, 8.6). )
G1 X92.4507 Y92.7108 Z8.6 F1367.465 E246.1562
( Linear move to (91.53, 94.48, 8.6). )
G1 X91.53 Y94.48 Z8.6 F1367.465 E246.2158
( Linear move to (92.3399, 94.7072, 8.6). )
G1 X92.3399 Y94.7072 Z8.6 F1367.465 E246.2409
( Linear move to (91.9793, 95.0678, 8.6). )
G1 X91.9793 Y95.0678 Z8.6 F1367.465 E246.2561
( Linear move to (91.53, 95.3285, 8.6). )
G1 X91.53 Y95.3285 Z8.6 F1367.465 E246.2716
( Linear move to (91.53, 97.8741, 8.6). )
G1 X91.53 Y97.8741 Z8.6 F1367.465 E246.3477
( Linear move to (91.8639, 98.3887, 8.6). )
G1 X91.8639 Y98.3887 Z8.6 F1367.465 E246.366
( Linear move to (93.4797, 98.47, 8.6). )
G1 X93.4797 Y98.47 Z8.6 F1367.465 E246.4143
( Linear move to (93.4797, 98.47, 8.6). )
G1 F1200.0
( Linear move to (93.4797, 98.47, 8.6). )
G1 E245.4143
( Linear move to (93.4797, 98.47, 8.6). )
G1 F1367.465
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
( Set extruder speed to 16.5. )
M108 S16.5
(</layer>)
(<layer> 9.0 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z9.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z9.0 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z9.0 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z9.0 </boundaryPoint>)
(<edge> outer )
( Linear move to (90.36, 80.36, 9.0). )
G1 X90.36 Y80.36 Z9.0 F2757.1641
( Linear move to (90.36, 80.36, 9.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.0). )
G1 E246.4143
( Linear move to (90.36, 80.36, 9.0). )
G1 F2757.1641
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 9.0). )
G1 X109.64 Y80.36 Z9.0 F1350.0 E246.9904
( Linear move to (109.64, 99.64, 9.0). )
G1 X109.64 Y99.64 Z9.0 F1350.0 E247.5665
( Linear move to (90.36, 99.64, 9.0). )
G1 X90.36 Y99.64 Z9.0 F1350.0 E248.1425
( Linear move to (90.36, 80.36, 9.0). )
G1 X90.36 Y80.36 Z9.0 F1350.0 E248.7186
( Linear move to (90.36, 80.36, 9.0). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.0). )
G1 E248.7186
( Linear move to (90.36, 80.36, 9.0). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 22.0. )
M108 S22.0
( Linear move to (91.02, 81.02, 9.0). )
G1 X91.02 Y81.02 Z9.0 F6000.0
( Linear move to (91.02, 81.02, 9.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.0). )
G1 E248.7186
( Linear move to (91.02, 81.02, 9.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 9.0). )
G1 X108.98 Y81.02 Z9.0 F1800.0 E249.2552
( Linear move to (108.98, 98.98, 9.0). )
G1 X108.98 Y98.98 Z9.0 F1800.0 E249.7918
( Linear move to (91.02, 98.98, 9.0). )
G1 X91.02 Y98.98 Z9.0 F1800.0 E250.3285
( Linear move to (91.02, 81.02, 9.0). )
G1 X91.02 Y81.02 Z9.0 F1800.0 E250.8651
( Linear move to (91.02, 81.02, 9.0). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.0). )
G1 E250.8502
( Linear move to (91.02, 81.02, 9.0). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z8.8 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z8.8 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z8.8 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z8.8 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.7376, 81.7376, 9.0). )
G1 X91.7376 Y81.7376 Z9.0 F6000.0
( Linear move to (91.7376, 81.7376, 9.0). )
G1 F1200.0
( Linear move to (91.7376, 81.7376, 9.0). )
G1 E250.8651
( Linear move to (91.7376, 81.7376, 9.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.2624, 98.2624, 9.0). )
G1 X108.2624 Y98.2624 Z9.0 F1800.0 E251.5633
( Linear move to (108.47, 97.6215, 9.0). )
G1 X108.47 Y97.6215 Z9.0 F1800.0 E251.5835
( Linear move to (92.3785, 81.53, 9.0). )
G1 X92.3785 Y81.53 Z9.0 F1800.0 E252.2634
( Linear move to (93.2271, 81.53, 9.0). )
G1 X93.2271 Y81.53 Z9.0 F1800.0 E252.2888
( Linear move to (108.47, 96.7729, 9.0). )
G1 X108.47 Y96.7729 Z9.0 F1800.0 E252.9328
( Linear move to (108.47, 95.9244, 9.0). )
G1 X108.47 Y95.9244 Z9.0 F1800.0 E252.9582
( Linear move to (94.0756, 81.53, 9.0). )
G1 X94.0756 Y81.53 Z9.0 F1800.0 E253.5664
( Linear move to (94.9241, 81.53, 9.0). )
G1 X94.9241 Y81.53 Z9.0 F1800.0 E253.5918
( Linear move to (108.47, 95.0759, 9.0). )
G1 X108.47 Y95.0759 Z9.0 F1800.0 E254.1642
( Linear move to (108.47, 94.2274, 9.0). )
G1 X108.47 Y94.2274 Z9.0 F1800.0 E254.1895
( Linear move to (95.7726, 81.53, 9.0). )
G1 X95.7726 Y81.53 Z9.0 F1800.0 E254.726
( Linear move to (96.6212, 81.53, 9.0). )
G1 X96.6212 Y81.53 Z9.0 F1800.0 E254.7514
( Linear move to (108.47, 93.3788, 9.0). )
G1 X108.47 Y93.3788 Z9.0 F1800.0 E255.2521
( Linear move to (108.47, 92.5303, 9.0). )
G1 X108.47 Y92.5303 Z9.0 F1800.0 E255.2774
( Linear move to (97.4697, 81.53, 9.0). )
G1 X97.4697 Y81.53 Z9.0 F1800.0 E255.7422
( Linear move to (98.3182, 81.53, 9.0). )
G1 X98.3182 Y81.53 Z9.0 F1800.0 E255.7676
( Linear move to (108.47, 91.6818, 9.0). )
G1 X108.47 Y91.6818 Z9.0 F1800.0 E256.1965
( Linear move to (108.47, 90.8332, 9.0). )
G1 X108.47 Y90.8332 Z9.0 F1800.0 E256.2219
( Linear move to (99.1668, 81.53, 9.0). )
G1 X99.1668 Y81.53 Z9.0 F1800.0 E256.615
( Linear move to (100.0153, 81.53, 9.0). )
G1 X100.0153 Y81.53 Z9.0 F1800.0 E256.6404
( Linear move to (108.47, 89.9847, 9.0). )
G1 X108.47 Y89.9847 Z9.0 F1800.0 E256.9976
( Linear move to (108.47, 89.1362, 9.0). )
G1 X108.47 Y89.1362 Z9.0 F1800.0 E257.023
( Linear move to (100.8638, 81.53, 9.0). )
G1 X100.8638 Y81.53 Z9.0 F1800.0 E257.3444
( Linear move to (101.7123, 81.53, 9.0). )
G1 X101.7123 Y81.53 Z9.0 F1800.0 E257.3697
( Linear move to (108.47, 88.2877, 9.0). )
G1 X108.47 Y88.2877 Z9.0 F1800.0 E257.6553
( Linear move to (108.47, 87.4391, 9.0). )
G1 X108.47 Y87.4391 Z9.0 F1800.0 E257.6806
( Linear move to (102.5609, 81.53, 9.0). )
G1 X102.5609 Y81.53 Z9.0 F1800.0 E257.9303
( Linear move to (103.4094, 81.53, 9.0). )
G1 X103.4094 Y81.53 Z9.0 F1800.0 E257.9557
( Linear move to (108.47, 86.5906, 9.0). )
G1 X108.47 Y86.5906 Z9.0 F1800.0 E258.1695
( Linear move to (108.47, 85.7421, 9.0). )
G1 X108.47 Y85.7421 Z9.0 F1800.0 E258.1948
( Linear move to (104.2579, 81.53, 9.0). )
G1 X104.2579 Y81.53 Z9.0 F1800.0 E258.3728
( Linear move to (105.1065, 81.53, 9.0). )
G1 X105.1065 Y81.53 Z9.0 F1800.0 E258.3982
( Linear move to (108.47, 84.8935, 9.0). )
G1 X108.47 Y84.8935 Z9.0 F1800.0 E258.5403
( Linear move to (108.47, 84.045, 9.0). )
G1 X108.47 Y84.045 Z9.0 F1800.0 E258.5657
( Linear move to (105.955, 81.53, 9.0). )
G1 X105.955 Y81.53 Z9.0 F1800.0 E258.6719
( Linear move to (106.8035, 81.53, 9.0). )
G1 X106.8035 Y81.53 Z9.0 F1800.0 E258.6973
( Linear move to (108.47, 83.1965, 9.0). )
G1 X108.47 Y83.1965 Z9.0 F1800.0 E258.7677
( Linear move to (108.47, 82.348, 9.0). )
G1 X108.47 Y82.348 Z9.0 F1800.0 E258.793
( Linear move to (107.652, 81.53, 9.0). )
G1 X107.652 Y81.53 Z9.0 F1800.0 E258.8276
( Linear move to (107.652, 81.53, 9.0). )
G1 F1200.0
( Linear move to (107.652, 81.53, 9.0). )
G1 E257.8276
( Linear move to (107.652, 81.53, 9.0). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (91.53, 82.3785, 9.0). )
G1 X91.53 Y82.3785 Z9.0 F6000.0
( Linear move to (91.53, 82.3785, 9.0). )
G1 F1200.0
( Linear move to (91.53, 82.3785, 9.0). )
G1 E258.8276
( Linear move to (91.53, 82.3785, 9.0). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.6215, 98.47, 9.0). )
G1 X107.6215 Y98.47 Z9.0 F1800.0 E259.5076
( Linear move to (106.7729, 98.47, 9.0). )
G1 X106.7729 Y98.47 Z9.0 F1800.0 E259.5329
( Linear move to (91.53, 83.2271, 9.0). )
G1 X91.53 Y83.2271 Z9.0 F1800.0 E260.177
( Linear move to (91.53, 84.0756, 9.0). )
G1 X91.53 Y84.0756 Z9.0 F1800.0 E260.2023
( Linear move to (105.9244, 98.47, 9.0). )
G1 X105.9244 Y98.47 Z9.0 F1800.0 E260.8106
( Linear move to (105.0759, 98.47, 9.0). )
G1 X105.0759 Y98.47 Z9.0 F1800.0 E260.8359
( Linear move to (91.53, 84.9241, 9.0). )
G1 X91.53 Y84.9241 Z9.0 F1800.0 E261.4083
( Linear move to (91.53, 85.7726, 9.0). )
G1 X91.53 Y85.7726 Z9.0 F1800.0 E261.4337
( Linear move to (104.2274, 98.47, 9.0). )
G1 X104.2274 Y98.47 Z9.0 F1800.0 E261.9702
( Linear move to (103.3788, 98.47, 9.0). )
G1 X103.3788 Y98.47 Z9.0 F1800.0 E261.9955
( Linear move to (91.53, 86.6212, 9.0). )
G1 X91.53 Y86.6212 Z9.0 F1800.0 E262.4962
( Linear move to (91.53, 87.4697, 9.0). )
G1 X91.53 Y87.4697 Z9.0 F1800.0 E262.5216
( Linear move to (102.5303, 98.47, 9.0). )
G1 X102.5303 Y98.47 Z9.0 F1800.0 E262.9864
( Linear move to (101.6818, 98.47, 9.0). )
G1 X101.6818 Y98.47 Z9.0 F1800.0 E263.0117
( Linear move to (91.53, 88.3182, 9.0). )
G1 X91.53 Y88.3182 Z9.0 F1800.0 E263.4407
( Linear move to (91.53, 89.1668, 9.0). )
G1 X91.53 Y89.1668 Z9.0 F1800.0 E263.4661
( Linear move to (100.8332, 98.47, 9.0). )
G1 X100.8332 Y98.47 Z9.0 F1800.0 E263.8592
( Linear move to (99.9847, 98.47, 9.0). )
G1 X99.9847 Y98.47 Z9.0 F1800.0 E263.8845
( Linear move to (91.53, 90.0153, 9.0). )
G1 X91.53 Y90.0153 Z9.0 F1800.0 E264.2418
( Linear move to (91.53, 90.8638, 9.0). )
G1 X91.53 Y90.8638 Z9.0 F1800.0 E264.2671
( Linear move to (99.1362, 98.47, 9.0). )
G1 X99.1362 Y98.47 Z9.0 F1800.0 E264.5885
( Linear move to (98.2877, 98.47, 9.0). )
G1 X98.2877 Y98.47 Z9.0 F1800.0 E264.6139
( Linear move to (91.53, 91.7123, 9.0). )
G1 X91.53 Y91.7123 Z9.0 F1800.0 E264.8994
( Linear move to (91.53, 92.5609, 9.0). )
G1 X91.53 Y92.5609 Z9.0 F1800.0 E264.9248
( Linear move to (97.4391, 98.47, 9.0). )
G1 X97.4391 Y98.47 Z9.0 F1800.0 E265.1745
( Linear move to (96.5906, 98.47, 9.0). )
G1 X96.5906 Y98.47 Z9.0 F1800.0 E265.1998
( Linear move to (91.53, 93.4094, 9.0). )
G1 X91.53 Y93.4094 Z9.0 F1800.0 E265.4136
( Linear move to (91.53, 94.2579, 9.0). )
G1 X91.53 Y94.2579 Z9.0 F1800.0 E265.439
( Linear move to (95.7421, 98.47, 9.0). )
G1 X95.7421 Y98.47 Z9.0 F1800.0 E265.617
( Linear move to (94.8935, 98.47, 9.0). )
G1 X94.8935 Y98.47 Z9.0 F1800.0 E265.6423
( Linear move to (91.53, 95.1065, 9.0). )
G1 X91.53 Y95.1065 Z9.0 F1800.0 E265.7845
( Linear move to (91.53, 95.955, 9.0). )
G1 X91.53 Y95.955 Z9.0 F1800.0 E265.8098
( Linear move to (94.045, 98.47, 9.0). )
G1 X94.045 Y98.47 Z9.0 F1800.0 E265.9161
( Linear move to (93.1965, 98.47, 9.0). )
G1 X93.1965 Y98.47 Z9.0 F1800.0 E265.9414
( Linear move to (91.53, 96.8035, 9.0). )
G1 X91.53 Y96.8035 Z9.0 F1800.0 E266.0118
( Linear move to (91.53, 97.652, 9.0). )
G1 X91.53 Y97.652 Z9.0 F1800.0 E266.0372
( Linear move to (92.348, 98.47, 9.0). )
G1 X92.348 Y98.47 Z9.0 F1800.0 E266.0718
( Linear move to (92.348, 98.47, 9.0). )
G1 F1200.0
( Linear move to (92.348, 98.47, 9.0). )
G1 E265.0718
( Linear move to (92.348, 98.47, 9.0). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(<layer> 9.4 )
(<rotation> (-0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z9.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z9.4 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z9.4 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z9.4 </boundaryPoint>)
(<edge> outer )
( Set extruder speed to 16.5. )
M108 S16.5
( Linear move to (90.36, 80.36, 9.4). )
G1 X90.36 Y80.36 Z9.4 F2733.4768
( Linear move to (90.36, 80.36, 9.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.4). )
G1 E266.0718
( Linear move to (90.36, 80.36, 9.4). )
G1 F2733.4768
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 9.4). )
G1 X109.64 Y80.36 Z9.4 F1350.0 E266.6478
( Linear move to (109.64, 99.64, 9.4). )
G1 X109.64 Y99.64 Z9.4 F1350.0 E267.2239
( Linear move to (90.36, 99.64, 9.4). )
G1 X90.36 Y99.64 Z9.4 F1350.0 E267.7999
( Linear move to (90.36, 80.36, 9.4). )
G1 X90.36 Y80.36 Z9.4 F1350.0 E268.376
( Linear move to (90.36, 80.36, 9.4). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.4). )
G1 E268.376
( Linear move to (90.36, 80.36, 9.4). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 22.0. )
M108 S22.0
( Linear move to (91.02, 81.02, 9.4). )
G1 X91.02 Y81.02 Z9.4 F6000.0
( Linear move to (91.02, 81.02, 9.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.4). )
G1 E268.376
( Linear move to (91.02, 81.02, 9.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 9.4). )
G1 X108.98 Y81.02 Z9.4 F1800.0 E268.9126
( Linear move to (108.98, 98.98, 9.4). )
G1 X108.98 Y98.98 Z9.4 F1800.0 E269.4493
( Linear move to (91.02, 98.98, 9.4). )
G1 X91.02 Y98.98 Z9.4 F1800.0 E269.9859
( Linear move to (91.02, 81.02, 9.4). )
G1 X91.02 Y81.02 Z9.4 F1800.0 E270.5225
( Linear move to (91.02, 81.02, 9.4). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.4). )
G1 E269.5225
( Linear move to (91.02, 81.02, 9.4). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z9.2 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z9.2 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z9.2 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z9.2 </infillPoint>)
(</infillBoundary>)
( Linear move to (108.47, 97.9047, 9.4). )
G1 X108.47 Y97.9047 Z9.4 F6000.0
( Linear move to (108.47, 97.9047, 9.4). )
G1 F1200.0
( Linear move to (108.47, 97.9047, 9.4). )
G1 E270.5225
( Linear move to (108.47, 97.9047, 9.4). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.9047, 98.47, 9.4). )
G1 X107.9047 Y98.47 Z9.4 F1800.0 E270.5464
( Linear move to (107.0561, 98.47, 9.4). )
G1 X107.0561 Y98.47 Z9.4 F1800.0 E270.5717
( Linear move to (108.47, 97.0561, 9.4). )
G1 X108.47 Y97.0561 Z9.4 F1800.0 E270.6315
( Linear move to (108.47, 96.2076, 9.4). )
G1 X108.47 Y96.2076 Z9.4 F1800.0 E270.6568
( Linear move to (106.2076, 98.47, 9.4). )
G1 X106.2076 Y98.47 Z9.4 F1800.0 E270.7524
( Linear move to (105.3591, 98.47, 9.4). )
G1 X105.3591 Y98.47 Z9.4 F1800.0 E270.7778
( Linear move to (108.47, 95.3591, 9.4). )
G1 X108.47 Y95.3591 Z9.4 F1800.0 E270.9092
( Linear move to (108.47, 94.5106, 9.4). )
G1 X108.47 Y94.5106 Z9.4 F1800.0 E270.9346
( Linear move to (104.5106, 98.47, 9.4). )
G1 X104.5106 Y98.47 Z9.4 F1800.0 E271.1019
( Linear move to (103.662, 98.47, 9.4). )
G1 X103.662 Y98.47 Z9.4 F1800.0 E271.1272
( Linear move to (108.47, 93.662, 9.4). )
G1 X108.47 Y93.662 Z9.4 F1800.0 E271.3304
( Linear move to (108.47, 92.8135, 9.4). )
G1 X108.47 Y92.8135 Z9.4 F1800.0 E271.3558
( Linear move to (102.8135, 98.47, 9.4). )
G1 X102.8135 Y98.47 Z9.4 F1800.0 E271.5948
( Linear move to (101.965, 98.47, 9.4). )
G1 X101.965 Y98.47 Z9.4 F1800.0 E271.6201
( Linear move to (108.47, 91.965, 9.4). )
G1 X108.47 Y91.965 Z9.4 F1800.0 E271.895
( Linear move to (108.47, 91.1164, 9.4). )
G1 X108.47 Y91.1164 Z9.4 F1800.0 E271.9203
( Linear move to (101.1164, 98.47, 9.4). )
G1 X101.1164 Y98.47 Z9.4 F1800.0 E272.2311
( Linear move to (100.2679, 98.47, 9.4). )
G1 X100.2679 Y98.47 Z9.4 F1800.0 E272.2564
( Linear move to (108.47, 90.2679, 9.4). )
G1 X108.47 Y90.2679 Z9.4 F1800.0 E272.603
( Linear move to (108.47, 89.4194, 9.4). )
G1 X108.47 Y89.4194 Z9.4 F1800.0 E272.6284
( Linear move to (99.4194, 98.47, 9.4). )
G1 X99.4194 Y98.47 Z9.4 F1800.0 E273.0108
( Linear move to (98.5709, 98.47, 9.4). )
G1 X98.5709 Y98.47 Z9.4 F1800.0 E273.0361
( Linear move to (108.47, 88.5709, 9.4). )
G1 X108.47 Y88.5709 Z9.4 F1800.0 E273.4544
( Linear move to (108.47, 87.7223, 9.4). )
G1 X108.47 Y87.7223 Z9.4 F1800.0 E273.4798
( Linear move to (97.7223, 98.47, 9.4). )
G1 X97.7223 Y98.47 Z9.4 F1800.0 E273.9339
( Linear move to (96.8738, 98.47, 9.4). )
G1 X96.8738 Y98.47 Z9.4 F1800.0 E273.9593
( Linear move to (108.47, 86.8738, 9.4). )
G1 X108.47 Y86.8738 Z9.4 F1800.0 E274.4493
( Linear move to (108.47, 86.0253, 9.4). )
G1 X108.47 Y86.0253 Z9.4 F1800.0 E274.4746
( Linear move to (96.0253, 98.47, 9.4). )
G1 X96.0253 Y98.47 Z9.4 F1800.0 E275.0005
( Linear move to (95.1768, 98.47, 9.4). )
G1 X95.1768 Y98.47 Z9.4 F1800.0 E275.0258
( Linear move to (108.47, 85.1768, 9.4). )
G1 X108.47 Y85.1768 Z9.4 F1800.0 E275.5875
( Linear move to (108.47, 84.3282, 9.4). )
G1 X108.47 Y84.3282 Z9.4 F1800.0 E275.6129
( Linear move to (94.3282, 98.47, 9.4). )
G1 X94.3282 Y98.47 Z9.4 F1800.0 E276.2104
( Linear move to (93.4797, 98.47, 9.4). )
G1 X93.4797 Y98.47 Z9.4 F1800.0 E276.2358
( Linear move to (108.47, 83.4797, 9.4). )
G1 X108.47 Y83.4797 Z9.4 F1800.0 E276.8692
( Linear move to (108.47, 82.6312, 9.4). )
G1 X108.47 Y82.6312 Z9.4 F1800.0 E276.8946
( Linear move to (92.6312, 98.47, 9.4). )
G1 X92.6312 Y98.47 Z9.4 F1800.0 E277.5638
( Linear move to (91.8639, 98.3887, 9.4). )
G1 X91.8639 Y98.3887 Z9.4 F1800.0 E277.5869
( Linear move to (108.3887, 81.8639, 9.4). )
G1 X108.3887 Y81.8639 Z9.4 F1800.0 E278.2851
( Linear move to (107.8741, 81.53, 9.4). )
G1 X107.8741 Y81.53 Z9.4 F1800.0 E278.3035
( Linear move to (91.53, 97.8741, 9.4). )
G1 X91.53 Y97.8741 Z9.4 F1800.0 E278.9941
( Linear move to (91.53, 97.0256, 9.4). )
G1 X91.53 Y97.0256 Z9.4 F1800.0 E279.0194
( Linear move to (107.0256, 81.53, 9.4). )
G1 X107.0256 Y81.53 Z9.4 F1800.0 E279.6742
( Linear move to (106.1771, 81.53, 9.4). )
G1 X106.1771 Y81.53 Z9.4 F1800.0 E279.6995
( Linear move to (91.53, 96.1771, 9.4). )
G1 X91.53 Y96.1771 Z9.4 F1800.0 E280.3185
( Linear move to (91.53, 95.3285, 9.4). )
G1 X91.53 Y95.3285 Z9.4 F1800.0 E280.3438
( Linear move to (105.3285, 81.53, 9.4). )
G1 X105.3285 Y81.53 Z9.4 F1800.0 E280.9269
( Linear move to (104.48, 81.53, 9.4). )
G1 X104.48 Y81.53 Z9.4 F1800.0 E280.9522
( Linear move to (91.53, 94.48, 9.4). )
G1 X91.53 Y94.48 Z9.4 F1800.0 E281.4994
( Linear move to (91.53, 93.6315, 9.4). )
G1 X91.53 Y93.6315 Z9.4 F1800.0 E281.5248
( Linear move to (103.6315, 81.53, 9.4). )
G1 X103.6315 Y81.53 Z9.4 F1800.0 E282.0361
( Linear move to (102.7829, 81.53, 9.4). )
G1 X102.7829 Y81.53 Z9.4 F1800.0 E282.0615
( Linear move to (91.53, 92.7829, 9.4). )
G1 X91.53 Y92.7829 Z9.4 F1800.0 E282.537
( Linear move to (91.53, 91.9344, 9.4). )
G1 X91.53 Y91.9344 Z9.4 F1800.0 E282.5623
( Linear move to (101.9344, 81.53, 9.4). )
G1 X101.9344 Y81.53 Z9.4 F1800.0 E283.0019
( Linear move to (101.0859, 81.53, 9.4). )
G1 X101.0859 Y81.53 Z9.4 F1800.0 E283.0273
( Linear move to (91.53, 91.0859, 9.4). )
G1 X91.53 Y91.0859 Z9.4 F1800.0 E283.4311
( Linear move to (91.53, 90.2374, 9.4). )
G1 X91.53 Y90.2374 Z9.4 F1800.0 E283.4564
( Linear move to (100.2374, 81.53, 9.4). )
G1 X100.2374 Y81.53 Z9.4 F1800.0 E283.8244
( Linear move to (99.3888, 81.53, 9.4). )
G1 X99.3888 Y81.53 Z9.4 F1800.0 E283.8497
( Linear move to (91.53, 89.3888, 9.4). )
G1 X91.53 Y89.3888 Z9.4 F1800.0 E284.1818
( Linear move to (91.53, 88.5403, 9.4). )
G1 X91.53 Y88.5403 Z9.4 F1800.0 E284.2071
( Linear move to (98.5403, 81.53, 9.4). )
G1 X98.5403 Y81.53 Z9.4 F1800.0 E284.5034
( Linear move to (97.6918, 81.53, 9.4). )
G1 X97.6918 Y81.53 Z9.4 F1800.0 E284.5287
( Linear move to (91.53, 87.6918, 9.4). )
G1 X91.53 Y87.6918 Z9.4 F1800.0 E284.7891
( Linear move to (91.53, 86.8432, 9.4). )
G1 X91.53 Y86.8432 Z9.4 F1800.0 E284.8144
( Linear move to (96.8432, 81.53, 9.4). )
G1 X96.8432 Y81.53 Z9.4 F1800.0 E285.0389
( Linear move to (95.9947, 81.53, 9.4). )
G1 X95.9947 Y81.53 Z9.4 F1800.0 E285.0643
( Linear move to (91.53, 85.9947, 9.4). )
G1 X91.53 Y85.9947 Z9.4 F1800.0 E285.2529
( Linear move to (91.53, 85.1462, 9.4). )
G1 X91.53 Y85.1462 Z9.4 F1800.0 E285.2783
( Linear move to (95.1462, 81.53, 9.4). )
G1 X95.1462 Y81.53 Z9.4 F1800.0 E285.4311
( Linear move to (94.2977, 81.53, 9.4). )
G1 X94.2977 Y81.53 Z9.4 F1800.0 E285.4565
( Linear move to (91.53, 84.2977, 9.4). )
G1 X91.53 Y84.2977 Z9.4 F1800.0 E285.5734
( Linear move to (91.53, 83.4491, 9.4). )
G1 X91.53 Y83.4491 Z9.4 F1800.0 E285.5988
( Linear move to (93.4491, 81.53, 9.4). )
G1 X93.4491 Y81.53 Z9.4 F1800.0 E285.6798
( Linear move to (92.6006, 81.53, 9.4). )
G1 X92.6006 Y81.53 Z9.4 F1800.0 E285.7052
( Linear move to (91.53, 82.6006, 9.4). )
G1 X91.53 Y82.6006 Z9.4 F1800.0 E285.7504
( Linear move to (91.53, 82.6006, 9.4). )
G1 F1200.0
( Linear move to (91.53, 82.6006, 9.4). )
G1 E284.7504
( Linear move to (91.53, 82.6006, 9.4). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(<layer> 9.8 )
(<rotation> (0.707106781187+0.707106781187j) )
(<nestedRing>)
(<boundaryPerimeter>)
(<boundaryPoint> X110.0 Y100.0 Z9.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y100.0 Z9.8 </boundaryPoint>)
(<boundaryPoint> X90.0 Y80.0 Z9.8 </boundaryPoint>)
(<boundaryPoint> X110.0 Y80.0 Z9.8 </boundaryPoint>)
(<edge> outer )
( Set extruder speed to 16.5. )
M108 S16.5
( Linear move to (90.36, 80.36, 9.8). )
G1 X90.36 Y80.36 Z9.8 F383.8707
( Linear move to (90.36, 80.36, 9.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.8). )
G1 E285.7504
( Linear move to (90.36, 80.36, 9.8). )
G1 F383.8707
( Extruder on, forward. )
M101
( Linear move to (109.64, 80.36, 9.8). )
G1 X109.64 Y80.36 Z9.8 F1350.0 E286.3265
( Linear move to (109.64, 99.64, 9.8). )
G1 X109.64 Y99.64 Z9.8 F1350.0 E286.9026
( Linear move to (90.36, 99.64, 9.8). )
G1 X90.36 Y99.64 Z9.8 F1350.0 E287.4786
( Linear move to (90.36, 80.36, 9.8). )
G1 X90.36 Y80.36 Z9.8 F1350.0 E288.0547
( Linear move to (90.36, 80.36, 9.8). )
G1 F1200.0
( Linear move to (90.36, 80.36, 9.8). )
G1 E288.0547
( Linear move to (90.36, 80.36, 9.8). )
G1 F1350.0
( Extruder off. )
M103
(</edge>)
(</boundaryPerimeter>)
(<loop> outer )
( Set extruder speed to 22.0. )
M108 S22.0
( Linear move to (91.02, 81.02, 9.8). )
G1 X91.02 Y81.02 Z9.8 F6000.0
( Linear move to (91.02, 81.02, 9.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.8). )
G1 E288.0547
( Linear move to (91.02, 81.02, 9.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.98, 81.02, 9.8). )
G1 X108.98 Y81.02 Z9.8 F1800.0 E288.5913
( Linear move to (108.98, 98.98, 9.8). )
G1 X108.98 Y98.98 Z9.8 F1800.0 E289.1279
( Linear move to (91.02, 98.98, 9.8). )
G1 X91.02 Y98.98 Z9.8 F1800.0 E289.6645
( Linear move to (91.02, 81.02, 9.8). )
G1 X91.02 Y81.02 Z9.8 F1800.0 E290.2012
( Linear move to (91.02, 81.02, 9.8). )
G1 F1200.0
( Linear move to (91.02, 81.02, 9.8). )
G1 E290.1863
( Linear move to (91.02, 81.02, 9.8). )
G1 F1800.0
( Extruder off. )
M103
(</loop>)
(<infill>)
(<infillBoundary>)
(<infillPoint> X108.98 Y98.98 Z9.6 </infillPoint>)
(<infillPoint> X91.02 Y98.98 Z9.6 </infillPoint>)
(<infillPoint> X91.02 Y81.02 Z9.6 </infillPoint>)
(<infillPoint> X108.98 Y81.02 Z9.6 </infillPoint>)
(</infillBoundary>)
( Linear move to (91.7376, 81.7376, 9.8). )
G1 X91.7376 Y81.7376 Z9.8 F6000.0
( Linear move to (91.7376, 81.7376, 9.8). )
G1 F1200.0
( Linear move to (91.7376, 81.7376, 9.8). )
G1 E290.2012
( Linear move to (91.7376, 81.7376, 9.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (108.2624, 98.2624, 9.8). )
G1 X108.2624 Y98.2624 Z9.8 F1800.0 E290.8994
( Linear move to (108.47, 97.6215, 9.8). )
G1 X108.47 Y97.6215 Z9.8 F1800.0 E290.9196
( Linear move to (92.3785, 81.53, 9.8). )
G1 X92.3785 Y81.53 Z9.8 F1800.0 E291.5995
( Linear move to (93.2271, 81.53, 9.8). )
G1 X93.2271 Y81.53 Z9.8 F1800.0 E291.6248
( Linear move to (108.47, 96.7729, 9.8). )
G1 X108.47 Y96.7729 Z9.8 F1800.0 E292.2689
( Linear move to (108.47, 95.9244, 9.8). )
G1 X108.47 Y95.9244 Z9.8 F1800.0 E292.2943
( Linear move to (94.0756, 81.53, 9.8). )
G1 X94.0756 Y81.53 Z9.8 F1800.0 E292.9025
( Linear move to (94.9241, 81.53, 9.8). )
G1 X94.9241 Y81.53 Z9.8 F1800.0 E292.9279
( Linear move to (108.47, 95.0759, 9.8). )
G1 X108.47 Y95.0759 Z9.8 F1800.0 E293.5003
( Linear move to (108.47, 94.2274, 9.8). )
G1 X108.47 Y94.2274 Z9.8 F1800.0 E293.5256
( Linear move to (95.7726, 81.53, 9.8). )
G1 X95.7726 Y81.53 Z9.8 F1800.0 E294.0621
( Linear move to (96.6212, 81.53, 9.8). )
G1 X96.6212 Y81.53 Z9.8 F1800.0 E294.0875
( Linear move to (108.47, 93.3788, 9.8). )
G1 X108.47 Y93.3788 Z9.8 F1800.0 E294.5882
( Linear move to (108.47, 92.5303, 9.8). )
G1 X108.47 Y92.5303 Z9.8 F1800.0 E294.6135
( Linear move to (97.4697, 81.53, 9.8). )
G1 X97.4697 Y81.53 Z9.8 F1800.0 E295.0783
( Linear move to (98.3182, 81.53, 9.8). )
G1 X98.3182 Y81.53 Z9.8 F1800.0 E295.1037
( Linear move to (108.47, 91.6818, 9.8). )
G1 X108.47 Y91.6818 Z9.8 F1800.0 E295.5326
( Linear move to (108.47, 90.8332, 9.8). )
G1 X108.47 Y90.8332 Z9.8 F1800.0 E295.558
( Linear move to (99.1668, 81.53, 9.8). )
G1 X99.1668 Y81.53 Z9.8 F1800.0 E295.9511
( Linear move to (100.0153, 81.53, 9.8). )
G1 X100.0153 Y81.53 Z9.8 F1800.0 E295.9765
( Linear move to (108.47, 89.9847, 9.8). )
G1 X108.47 Y89.9847 Z9.8 F1800.0 E296.3337
( Linear move to (108.47, 89.1362, 9.8). )
G1 X108.47 Y89.1362 Z9.8 F1800.0 E296.3591
( Linear move to (100.8638, 81.53, 9.8). )
G1 X100.8638 Y81.53 Z9.8 F1800.0 E296.6805
( Linear move to (101.7123, 81.53, 9.8). )
G1 X101.7123 Y81.53 Z9.8 F1800.0 E296.7058
( Linear move to (108.47, 88.2877, 9.8). )
G1 X108.47 Y88.2877 Z9.8 F1800.0 E296.9914
( Linear move to (108.47, 87.4391, 9.8). )
G1 X108.47 Y87.4391 Z9.8 F1800.0 E297.0167
( Linear move to (102.5609, 81.53, 9.8). )
G1 X102.5609 Y81.53 Z9.8 F1800.0 E297.2664
( Linear move to (103.4094, 81.53, 9.8). )
G1 X103.4094 Y81.53 Z9.8 F1800.0 E297.2917
( Linear move to (108.47, 86.5906, 9.8). )
G1 X108.47 Y86.5906 Z9.8 F1800.0 E297.5056
( Linear move to (108.47, 85.7421, 9.8). )
G1 X108.47 Y85.7421 Z9.8 F1800.0 E297.5309
( Linear move to (104.2579, 81.53, 9.8). )
G1 X104.2579 Y81.53 Z9.8 F1800.0 E297.7089
( Linear move to (105.1065, 81.53, 9.8). )
G1 X105.1065 Y81.53 Z9.8 F1800.0 E297.7343
( Linear move to (108.47, 84.8935, 9.8). )
G1 X108.47 Y84.8935 Z9.8 F1800.0 E297.8764
( Linear move to (108.47, 84.045, 9.8). )
G1 X108.47 Y84.045 Z9.8 F1800.0 E297.9017
( Linear move to (105.955, 81.53, 9.8). )
G1 X105.955 Y81.53 Z9.8 F1800.0 E298.008
( Linear move to (106.8035, 81.53, 9.8). )
G1 X106.8035 Y81.53 Z9.8 F1800.0 E298.0334
( Linear move to (108.47, 83.1965, 9.8). )
G1 X108.47 Y83.1965 Z9.8 F1800.0 E298.1038
( Linear move to (108.47, 82.348, 9.8). )
G1 X108.47 Y82.348 Z9.8 F1800.0 E298.1291
( Linear move to (107.652, 81.53, 9.8). )
G1 X107.652 Y81.53 Z9.8 F1800.0 E298.1637
( Linear move to (107.652, 81.53, 9.8). )
G1 F1200.0
( Linear move to (107.652, 81.53, 9.8). )
G1 E297.1637
( Linear move to (107.652, 81.53, 9.8). )
G1 F1800.0
( Extruder off. )
M103
( Linear move to (91.53, 82.3785, 9.8). )
G1 X91.53 Y82.3785 Z9.8 F6000.0
( Linear move to (91.53, 82.3785, 9.8). )
G1 F1200.0
( Linear move to (91.53, 82.3785, 9.8). )
G1 E298.1637
( Linear move to (91.53, 82.3785, 9.8). )
G1 F6000.0
( Extruder on, forward. )
M101
( Linear move to (107.6215, 98.47, 9.8). )
G1 X107.6215 Y98.47 Z9.8 F1800.0 E298.8436
( Linear move to (106.7729, 98.47, 9.8). )
G1 X106.7729 Y98.47 Z9.8 F1800.0 E298.869
( Linear move to (91.53, 83.2271, 9.8). )
G1 X91.53 Y83.2271 Z9.8 F1800.0 E299.5131
( Linear move to (91.53, 84.0756, 9.8). )
G1 X91.53 Y84.0756 Z9.8 F1800.0 E299.5384
( Linear move to (105.9244, 98.47, 9.8). )
G1 X105.9244 Y98.47 Z9.8 F1800.0 E300.1467
( Linear move to (105.0759, 98.47, 9.8). )
G1 X105.0759 Y98.47 Z9.8 F1800.0 E300.172
( Linear move to (91.53, 84.9241, 9.8). )
G1 X91.53 Y84.9241 Z9.8 F1800.0 E300.7444
( Linear move to (91.53, 85.7726, 9.8). )
G1 X91.53 Y85.7726 Z9.8 F1800.0 E300.7698
( Linear move to (104.2274, 98.47, 9.8). )
G1 X104.2274 Y98.47 Z9.8 F1800.0 E301.3063
( Linear move to (103.3788, 98.47, 9.8). )
G1 X103.3788 Y98.47 Z9.8 F1800.0 E301.3316
( Linear move to (91.53, 86.6212, 9.8). )
G1 X91.53 Y86.6212 Z9.8 F1800.0 E301.8323
( Linear move to (91.53, 87.4697, 9.8). )
G1 X91.53 Y87.4697 Z9.8 F1800.0 E301.8577
( Linear move to (102.5303, 98.47, 9.8). )
G1 X102.5303 Y98.47 Z9.8 F1800.0 E302.3225
( Linear move to (101.6818, 98.47, 9.8). )
G1 X101.6818 Y98.47 Z9.8 F1800.0 E302.3478
( Linear move to (91.53, 88.3182, 9.8). )
G1 X91.53 Y88.3182 Z9.8 F1800.0 E302.7768
( Linear move to (91.53, 89.1668, 9.8). )
G1 X91.53 Y89.1668 Z9.8 F1800.0 E302.8021
( Linear move to (100.8332, 98.47, 9.8). )
G1 X100.8332 Y98.47 Z9.8 F1800.0 E303.1953
( Linear move to (99.9847, 98.47, 9.8). )
G1 X99.9847 Y98.47 Z9.8 F1800.0 E303.2206
( Linear move to (91.53, 90.0153, 9.8). )
G1 X91.53 Y90.0153 Z9.8 F1800.0 E303.5779
( Linear move to (91.53, 90.8638, 9.8). )
G1 X91.53 Y90.8638 Z9.8 F1800.0 E303.6032
( Linear move to (99.1362, 98.47, 9.8). )
G1 X99.1362 Y98.47 Z9.8 F1800.0 E303.9246
( Linear move to (98.2877, 98.47, 9.8). )
G1 X98.2877 Y98.47 Z9.8 F1800.0 E303.95
( Linear move to (91.53, 91.7123, 9.8). )
G1 X91.53 Y91.7123 Z9.8 F1800.0 E304.2355
( Linear move to (91.53, 92.5609, 9.8). )
G1 X91.53 Y92.5609 Z9.8 F1800.0 E304.2609
( Linear move to (97.4391, 98.47, 9.8). )
G1 X97.4391 Y98.47 Z9.8 F1800.0 E304.5105
( Linear move to (96.5906, 98.47, 9.8). )
G1 X96.5906 Y98.47 Z9.8 F1800.0 E304.5359
( Linear move to (91.53, 93.4094, 9.8). )
G1 X91.53 Y93.4094 Z9.8 F1800.0 E304.7497
( Linear move to (91.53, 94.2579, 9.8). )
G1 X91.53 Y94.2579 Z9.8 F1800.0 E304.7751
( Linear move to (95.7421, 98.47, 9.8). )
G1 X95.7421 Y98.47 Z9.8 F1800.0 E304.9531
( Linear move to (94.8935, 98.47, 9.8). )
G1 X94.8935 Y98.47 Z9.8 F1800.0 E304.9784
( Linear move to (91.53, 95.1065, 9.8). )
G1 X91.53 Y95.1065 Z9.8 F1800.0 E305.1205
( Linear move to (91.53, 95.955, 9.8). )
G1 X91.53 Y95.955 Z9.8 F1800.0 E305.1459
( Linear move to (94.045, 98.47, 9.8). )
G1 X94.045 Y98.47 Z9.8 F1800.0 E305.2522
( Linear move to (93.1965, 98.47, 9.8). )
G1 X93.1965 Y98.47 Z9.8 F1800.0 E305.2775
( Linear move to (91.53, 96.8035, 9.8). )
G1 X91.53 Y96.8035 Z9.8 F1800.0 E305.3479
( Linear move to (91.53, 97.652, 9.8). )
G1 X91.53 Y97.652 Z9.8 F1800.0 E305.3733
( Linear move to (92.348, 98.47, 9.8). )
G1 X92.348 Y98.47 Z9.8 F1800.0 E305.4079
( Linear move to (92.348, 98.47, 9.8). )
G1 F1200.0
( Linear move to (92.348, 98.47, 9.8). )
G1 E304.4079
( Linear move to (92.348, 98.47, 9.8). )
G1 F1800.0
( Extruder off. )
M103
(</infill>)
(</nestedRing>)
(</rotation>)
(</layer>)
(</crafting>)
( Linear move to (92.348, 98.47, 9.8). )
G1 F1200.0
( Linear move to (92.348, 98.47, 9.8). )
G1 E303.4079
( Linear move to (92.348, 98.47, 9.8). )
G1 F1800.0
( Extruder off. )
M103
M113 S0.0
( Turn fan off. )
M107
(<alteration>)
(<alterationFile>) end.gcode (</alterationFile>)
G91
G0 Z10
( Set positioning to absolute. )
G90
( Linear move to (92.348, 180.0, 9.8). )
G1 Y180 F2000
M84
(</alteration>)
