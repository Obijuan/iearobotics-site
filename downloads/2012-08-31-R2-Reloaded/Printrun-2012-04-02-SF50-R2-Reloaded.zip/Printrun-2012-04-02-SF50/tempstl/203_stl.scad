translate([100, 100, -0.0]) rotate([0, 0, -15]) import_stl("smallgearmod_fixed.stl");
