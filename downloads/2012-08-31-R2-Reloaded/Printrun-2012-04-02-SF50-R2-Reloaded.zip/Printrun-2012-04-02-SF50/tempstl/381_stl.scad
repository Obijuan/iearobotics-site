translate([99, 128, 0]) rotate([0, 0, 0]) import_stl("three.stl");
translate([60, 127, 0]) rotate([0, 0, 0]) import_stl("one.stl");
