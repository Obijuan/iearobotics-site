#define stepPin 15
#define dirPin 18
#define enablePin 19
#define minPin 20
#define maxPin 21
#define PS_ON_PIN 14

void setup()
{
  Serial.begin(19200);
  Serial.println("Starting stepper exerciser.");

  pinMode(PS_ON_PIN, OUTPUT);
  digitalWrite(PS_ON_PIN, LOW);
  delay(2000); //wait for PSU to actually turn on.
  
  Serial.println("Power supply on!");

  pinMode(stepPin, OUTPUT);
  pinMode(dirPin, OUTPUT);
  pinMode(enablePin, OUTPUT);
  pinMode(minPin, INPUT);
  pinMode(maxPin, INPUT);
  digitalWrite(minPin, HIGH); //turn on internal pullup
  digitalWrite(maxPin, HIGH); //other pullup

  digitalWrite(dirPin, HIGH);
  digitalWrite(stepPin, LOW);
  digitalWrite(enablePin, HIGH); //disable

  calculate_tones();
}

void loop()
{
  Serial.println("Forward!");
  digitalWrite(dirPin, HIGH);
  play_song(maxPin);

  delay(500);

  Serial.println("Reverse!");
  digitalWrite(dirPin, LOW);
  play_song(minPin);

  delay(500);
}

boolean at_switch(byte pin)
{
  return !digitalRead(pin); 
}

#define TONE_COUNT 16

float frequencies[TONE_COUNT] = {
  196.00, //G    0
  207.65, //G#   1
  220.00, //A    2
  233.08, //B-   3
  246.94, //B    4
  261.63, //C    5
  277.18, //C#   6
  293.66, //D    7
  311.13, //D#   8
  329.63, //E    9
  349.23, //F    10
  392.00, //G    11
  440.00, //A    12
  466.16, //B-   13
  493.88, //B    14
  523.25, //C    15
};


int tones[TONE_COUNT];

#define NOTE_COUNT 25
int notes[] = {
  5, 5, 7, 5, 10, 9, 5, 5, 7, 5, 11, 10, 5, 5, 15, 12, 10, 9, 7, 13, 13, 12, 10, 11, 10
};

void calculate_tones()
{
  for (byte i=0; i<TONE_COUNT; i++)
    tones[i] = (int)(1000000.0/ (2.0 * frequencies[i]));
}

void play_song(byte switchPin)
{
  digitalWrite(enablePin, LOW); //enable

  for (byte i=0; i<NOTE_COUNT; i++)
  {
    if (!at_switch(switchPin))
    {
      play_note(tones[notes[i]], 300000);
      delay(10); 
    }
  }
  digitalWrite(enablePin, HIGH); //disable
}

void play_note(int note, long time)
{
  int count = round(time / note);

  for (int i=0; i<count; i++)
  {
    digitalWrite(stepPin, HIGH);
    delayMicroseconds(note);
    digitalWrite(stepPin, LOW); 
    delayMicroseconds(note);
  }
}
