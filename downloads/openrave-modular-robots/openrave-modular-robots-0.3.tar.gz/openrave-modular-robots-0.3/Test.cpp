#include <openrave-core.h>
#include <vector>
#include <cstring>
#include <sstream>
#include <math.h>

#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>

using namespace OpenRAVE;
using namespace std;


void SetViewer(EnvironmentBasePtr penv, const string& viewername)
{
    RaveViewerBasePtr viewer = penv->CreateViewer(viewername);
    BOOST_ASSERT(!!viewer);

    // attach it to the environment:
    penv->AttachViewer(viewer);

    // finally you call the viewer's infinite loop (this is why you need a separate thread):
    bool showgui = true;
    viewer->main(showgui);

}

//-- The reference position are in degrees
void servo_update(ControllerBasePtr pcontroller, std::vector<KinBody::JointPtr> joints,
                  std::vector<dReal>ref_pos)
{
  stringstream is;
  stringstream os;
  std::vector<dReal> angle;
  std::vector<dReal> error(joints.size());
  std::vector<dReal> velocity(joints.size());
  const dReal KP = 8.3;

  is << "setvelocity ";

  for (unsigned int i=0; i<joints.size(); i++) {
    //-- Get the current angle
    joints[i]->GetValues(angle);

    error[i] = angle[0] - ref_pos[i]*PI/180.0;
    velocity[i] = -error[i]*KP;

    //-- The velocity should be limited to the maximum
    dReal Maxvel = joints[i]->GetMaxVel();

    if (velocity[i] > Maxvel) velocity[i] = Maxvel;
    if (velocity[i] < -Maxvel) velocity[i] = -Maxvel;

    is << velocity[i] << " ";
  }

  pcontroller->SendCommand(os,is);

}

int main(int argc, char ** argv)
{
   string envfile;

   if (argc==1)
     //-- Default file
     envfile="./Test-y1.xml";
   else
     envfile = argv[1];

    // create the main environment
    EnvironmentBasePtr penv = CreateEnvironment(true);

    boost::thread thviewer(boost::bind(SetViewer,penv,"qtcoin"));
    {
        // lock the environment to prevent changes
        EnvironmentMutex::scoped_lock lock(penv->GetMutex());

        // load the scene
        penv->Load(envfile);
    }

    //-- Get the robot
    std::vector<RobotBasePtr> robots;
    penv->GetRobots(robots);

    //-- Robot 0
    RobotBasePtr probot = robots[0];
    cout << "Robot: " << probot->GetName() << endl;

    //-- Load the controller
    ControllerBasePtr pcontroller = penv->CreateController("odevelocity");
    probot->SetController(pcontroller,"");


    penv->StopSimulation();

    //-- KinBody
    std::vector<KinBodyPtr> bodies;
    penv->GetBodies(bodies);

    //-- Joints
    std::vector<KinBody::JointPtr> joints = bodies[0]->GetJoints();

     //-- Constants
    const dReal T=1.5;
    const int N=20;
    const dReal p = T/N;
    const dReal A0 = 60;
    const dReal A1 = 60;
    const dReal phase_ini0 = 0;
    const dReal phase_ini1 = -120;
    const dReal STEP = 0.002;

    int sample_count=0;
    dReal phase;
    int simticks=p/STEP;
    std::vector<dReal>ref_pos(joints.size());

    cout << "Sampling period in ticks: " << simticks << endl;

    char tecla;

    cout << "PRESS A KEY TO START THE SIMULATION!" << endl;
    cin >> tecla;


    do {
      phase = 2*PI/N * sample_count;
      sample_count=(sample_count + 1)%N;
      ref_pos[0] = A0 * sin(phase + phase_ini0*PI/180.0);
      ref_pos[1] = A1 * sin(phase + phase_ini1*PI/180.0);

      for (int count=0; count<simticks; count++) {
        servo_update(pcontroller, joints, ref_pos);
        penv->StepSimulation(STEP);
        usleep(STEP*1000*1000);
      }

    } while(1);

    penv->Destroy(); // destroy
    return 0;
}





