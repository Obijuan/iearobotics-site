//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Operadores booleanos (III): Diferencia

//-- Ejemplo de diferencia: Taladros

difference() {
  //-- Cuerpo a taladrar. Una "moneda"
  cylinder(r = 30/2, h = 3, center=true, $fn=50);

  //-- Cilindro que hace de "broca", para taladrar el cuerpo
  cylinder(r = 4/2, h = 50, center=true, $fn=20);
}