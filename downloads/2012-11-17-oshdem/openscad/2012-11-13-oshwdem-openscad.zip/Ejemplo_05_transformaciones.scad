//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Transformaciones: Rotaciones y translaciones

//-- Enseñar como funcionan las rotaciones y traslaciones
//-- Mostrar que rotacion y traslacion NO SON CONMUTATIVAS
//-- Siempre actuan referidas al sistema absoluto
//-- Se muestra como sacar objetos de diferentes colores para resaltarlos


//-- Cubo en el centro
cube([20, 20, 10], center=true);

//-- Cubo Rojo: rotado 45 grados y luego trasladado
color("red")
translate([40, 0, 0])
  rotate([0,0,45])
    cube([20, 20, 10], center=true);


//-- Cube verde: Trasladado y luego rotado 45
 color("green")
  rotate([0, 0, 45])
  translate([40, 0, 0])
    cube([20, 20, 10], center=true);
