//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Ejemplo de biblioteca de piezas

module triangulo_hueco(re, ri, grosor) 
{

 //-- Triangulo hueco
  difference() {

    //-- Triangulo exterior
    cylinder(r = re, h = grosor, center=true, $fn=3);

     //-- Vaciado triangular interior
     cylinder(r = ri, h = grosor + 10, center=true, $fn=3);
  }

}

module estrella_david (re = 30 / 2, ri = 20/2, grosor = 3)
{

  triangulo_hueco(re = re, ri = ri, grosor = grosor);

  rotate([0, 0, 180])
    triangulo_hueco(re, ri, grosor);
}



//-- Ejemplo de uso
estrella_david(grosor = 10);

