//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Operadores booleanos (II): Union

//-- Un ejemplo sencillo para practicar: una estrella de 6 puntas
//-- mediante la union de 2 triángulos
//-- equiláteros, uno rotado 180 grados alrededor del otro


cylinder(r = 30/2, h = 3, center=true, $fn=3);

rotate([0, 0, 180])
  cylinder(r = 30/2, h = 3, center=true, $fn=3);