//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Primer contacto con Openscad. Haciendo todo el proceso: desde un cubo
//--  3D "virtual" hasta el cubo 3D físico


//-- Cubo "Hola mundo"
//-- Unidades en mm
//-- Aprieta F5 para visualizar
//-- (Renderizado rápido)

//-- Para imprimir:
//--   Aprita F6: Renderizado "pata negra"
//--  Exporta a fichero STL (design/export as STL)
//-- Abre el fichero STL con el programa de impresión
//--  (típicamente pronterface)

cube([20,20,10]);
