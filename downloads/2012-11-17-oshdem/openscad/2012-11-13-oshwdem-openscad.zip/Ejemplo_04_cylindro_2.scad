//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Objetos primitivos: el cilindro (II)
//-- Como generar conos, tetraedros y piramides de base poligonal


//-- Descomentar los siguientes ejemplos para verlos

//-- Cono, baja resolucion
cylinder(r1 = 20, r2 = 1, h = 30, center = true);


//-- Cono truncado. Alta resolucion
//cylinder(r1 = 20, r2 = 10, h = 30, center = true, $fn=100);

//-- Pirámide (base cuadrada)
//cylinder(r1 = 20, r2 = 1, h = 30, center = true, $fn=4);


//-- Tetraedro
//cylinder(r1 = 30, r2 = 1, h = 40, center = true, $fn=3);
