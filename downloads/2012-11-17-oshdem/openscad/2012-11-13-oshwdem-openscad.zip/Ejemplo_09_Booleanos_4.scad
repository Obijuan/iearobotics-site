//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Operadores booleanos (IV): Diferencia

//-- Ejemplo de "vaciado"

//-- Ejemplo: Estrella de david



 //-- Triangulo vaciado
  difference() {
    cylinder(r = 30/2, h = 3, center=true, $fn=3);

     color("Red")
     cylinder(r = 20/2, h = 20, center=true, $fn=3);
  }

//-- Mismo triangulo vaciado rotado 180 grados
//-- Hemos hecho un "copy&paste". Esto funciona... pero no es una
//-- buena técnica de diseño. Si ahora queremos cambiar el tamaño de
//-- la estrella hay que modificar en muchos sitios. O si hacemos un 
//-- cambio en los triangulos vaciados habrá que hacerlo por duplicado
//-- Esto nos da pie a la introducción de los módulos!!
rotate([0, 0, 180])
difference() {
    cylinder(r = 30/2, h = 3, center=true, $fn=3);

     color("Red")
     cylinder(r = 20/2, h = 20, center=true, $fn=3);
  }
