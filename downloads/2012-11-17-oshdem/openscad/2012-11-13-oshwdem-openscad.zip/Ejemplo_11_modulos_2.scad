//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Ejemplo de uso de una biblioteca de piezas

use <oshwdem_lib.scad>

//-- Al "usar" la biblioteca podemos obtener directamente piezas
//-- como si fueran objetos primitivos

//-- Ejemplo de uso
estrella_david();

//-- Y por supuesto podemos aplicar todas las transformaciones y operadores
//-- que ya conocemos...

translate([50, 0, 0])
  estrella_david();

