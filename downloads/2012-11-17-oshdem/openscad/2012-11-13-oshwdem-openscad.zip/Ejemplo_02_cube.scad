//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Objetos primitivos: el cubo 
//--


//-- Activar los ejes de coordenadas
//--  view/Show axes
//-- Con boton izquierdo pulsado y moviendo raton: cambiamos
//--   el punto de vista

//-- Con la rueda hacemos zoom

//-- Con botón derecho pulsado desplazamos la cámara

cube([20, 20, 10], center=true);

