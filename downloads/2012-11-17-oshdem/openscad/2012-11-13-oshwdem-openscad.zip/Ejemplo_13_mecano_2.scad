//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Generando mas piezas de mecano
//-- Ejemplo de uso de la bibloteca mecanolib

use <mecanolib.scad>

//-- Ejemplo de pieza en "L" plana

mecano_lineal(n=2);

rotate([0,0,90])
mecano_lineal(n=4);


//-- Ejemplo de pieza bidimensional

translate([30, 0, 0]) {
  mecano_lineal(n=5);

  translate([0, 10, 0])
    mecano_lineal(n=5);
}