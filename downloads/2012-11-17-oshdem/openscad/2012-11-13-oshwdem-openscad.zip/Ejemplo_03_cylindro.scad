//-------------------------------------------------------------------------
//-- Taller OpenScad.   OSHWDEM, Coruña, Nov-2012  
//--  By Obijuan  (Juan Gonzalez, juan@iearobotics.com)
//-------------------------------------------------------------------------
// GPL LICENSE
//-------------------------------------------------------------------------
//-- Objetos primitivos: el cilindro (I)
//-- Como generar cilindros y cualquier poligono regular

//--- Diferentes ejemplos. Descomentarlos para verlos


//-- Cilindro de radio 5mm, altura 50mm, centrado en origen
cylinder(r = 5, h = 50, center = true);


//-- Mismo cilindro "suavizado"
//-- El parametro $fn determina el numero de puntos de la
//--   circunferencia 
//cylinder(r = 5, h = 50, center = true, $fn = 100);


//-- Poniendo valores bajos en $fn conseguimos hacer
//-- Prismas de base poligonal: triangulo, cuadradado
//-- Ej. Prisa de base triangular
//cylinder(r = 5, h = 50, center = true, $fn = 3);

//-- Ejemplo: Un pentagono
//cylinder( r = 30/2, h = 3, center=true, $fn=5);

//-- Ejemplo: Un Octógono (la base para hacer el logo de la iniciativa Dharma ;-)
//cylinder( r = 40/2, h = 3, center=true, $fn=8);