void sci_conf();
unsigned char sci_read();
void sci_write(unsigned char dato);
void sci_cad(unsigned char *cad);
