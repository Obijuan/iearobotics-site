#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

#----------------------------------------------------------------------------
#  (C)2012 Juan Gonzalez (Obijuan)
#  LICENCIA GPL
#----------------------------------------------------------------------------

import serial
import time;

#-- Cadena de pruebas a enviar
Cadena = """
  G91
  G1 X50 F3000
  G1 Y50
  G1 X-50
  G1 Y-50
"""
s = serial.Serial("/dev/ttyACM0", 115200)  
time.sleep(1);

s.write(Cadena);

time.sleep(5);

#-- Cerrar puerto serie
s.close()
