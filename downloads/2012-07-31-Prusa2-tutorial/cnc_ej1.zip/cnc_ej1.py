#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-
#----------------------------------------------------------------------------
#  (C)2012 Juan Gonzalez (Obijuan)
#  LICENCIA GPL
#----------------------------------------------------------------------------
#
import serial
import time

s = serial.Serial("/dev/ttyACM0", 115200) 
time.sleep(3);
 
s.write("G91\n G1 X10\n");

time.sleep(1);

#-- Cerrar puerto serie
s.close()
