#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Colored bash out in Python
# Copyright (C) 2006 by Rafael Trevi�o Men�ndez
# Author: Rafael Trevi�o Men�ndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from os import system
import string

# Color dictionary (english and spanish)
colors = {

	# English
	'red'    : '\e[0;31m',
	'RED'    : '\e[1;31m',
	'blue'   : '\e[0;34m',
	'BLUE'   : '\e[1;34m',
	'cyan'   : '\e[0;36m',
	'CYAN'   : '\e[1;36m',
	'white'  : '\e[1;37m',
	'black'  : '\e[0;30m',
	'grey'   : '\e[1;30m',
	'GREY'   : '\e[0;37m',
	'green'  : '\e[0;32m',
	'GREEN'  : '\e[1;32m',
	'purple' : '\e[0;35m',
	'PURPLE' : '\e[1;35m',
	'brown'  : '\e[0;33m',
	'yellow' : '\e[1;33m',

	# Spanish
	'rojo'   : '\e[0;31m',
	'ROJO'   : '\e[1;31m',
	'azul'   : '\e[0;34m',
	'AZUL'   : '\e[1;34m',
	'cyan'   : '\e[0;36m',
	'CYAN'   : '\e[1;36m',
	'blanco' : '\e[1;37m',
	'negro'  : '\e[0;30m',
	'gris'   : '\e[1;30m',
	'GRIS'   : '\e[0;37m',
	'verde'  : '\e[0;32m',
	'VERDE'  : '\e[1;32m',
	'morado' : '\e[0;35m',
	'MORADO' : '\e[1;35m',
	'marron' : '\e[0;33m',
	'amarillo' : '\e[1;33m',
	
	# No color
	'NoCol'  : '\e[0m'	
}

def msg (L):
	"""L is a tuple list that has a color and a string, prints out all the colored strings with whitespace between them."""
	
	# Final string
	final = []

	# Color code
	code = '\e[0m'
	for (col, str) in L:

		# Search the color (default No color)
		cod = colors.get (col, '\e[0m')

		# Check if the color has changed (for eficiency)
		if cod != code:
			tmp = cod
		else:
			tmp = ''
		code = cod

		# Concat the strings
		tmp += str

		# Append the string the the final
		final.append (tmp)

	# Create the command and add whitespace
	final = string.replace (' '.join (final), '"', '\\"')
	cmd = 'echo -e "' + final + '\e[0m"'

	# Exec the command to display the final string
	system (cmd)

# Unit test of the module
if __name__ == '__main__':
	print 'Unit test of bashcolor.py\n'
	for k in colors.keys ():
		msg ([(k, k)])
