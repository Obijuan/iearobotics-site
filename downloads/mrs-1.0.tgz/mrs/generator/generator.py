#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# generator.py, Generator of Robot Movements
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys			# System variables like argv
import step			# Basic library for stepper
import bashcolor		# Module for nice color messages

# All output formats supported
formats = {'mrs'    : 1,
	   'c'      : 2,
	   'octave' : 3}

# List of mandatory arguments
notOptionArgs = []

# Optional arguments
format = 'mrs'		# Output format, by default, MRS
samples = 10		# Number of samples

def parseArgs (args):
	"""Function that examines the command line arguments without modifications."""
	global notOptionArgs, format, samples
	# Loop the arguments without first (program name)
	for arg in args [1:]:
		# Option argument
		if arg [0] == '-':
			arg = arg [1:]
			if arg [0] == 's':
				try:
					samples = int (arg [1:])
					bashcolor.msg ([('VERDE', 'generator:'),
							('morado', 'Note:'),
							('cyan', '%d samples.' % samples)])
				except:
					bashcolor.msg ([('VERDE', 'generator:'),
							('amarillo', 'Warning:'),
							('cyan', 'argument for %s invalid.' % arg)])
			# Output option
			elif arg == 'mrs' or arg == 'c' or arg == 'octave':
				format = arg
				bashcolor.msg ([('VERDE', 'generator:'),
						('morado', 'Note:'),
						('cyan', '%s output.' % arg)])
			# Invalid option
			else:
				bashcolor.msg ([('VERDE', 'generator:'),
							('amarillo', 'Warning:'),
							('cyan', 'invalid option %s.' % arg)])
				
			# TODO: Switch for option values and actions
		# Not option argument
		else:
			notOptionArgs.append (arg)

if __name__ == '__main__':
	# Parse the argument list for options and data
	parseArgs (sys.argv)

	# Check if required arguments are present (1 file)
	notOptionCount = len (notOptionArgs)
	if notOptionCount > 2 or notOptionCount < 1:
		bashcolor.msg ([('VERDE', 'generator:'),
				('amarillo', 'Use:'),
				('cyan', '%s <input file> [output file] [options]' % sys.argv [0]),
				('cyan', '\n\toptions: -s<samples> | ( -c | -mrs | -octave )')])
		sys.exit (-1)
	
	# Append a.out if no sequence
	if notOptionCount < 2:
		bashcolor.msg ([('VERDE', 'generator:'),
				('amarillo', 'Warning:'),
				('cyan', 'No output file. Using default.')])
		notOptionArgs.append ('sequence.mvm')

	# Create the sequence
	try:
		l = step.parseFile (notOptionArgs [0])
		s = step.generateMatrix (l, samples)
	except:
		import traceback
		traceback.print_exc ()
		bashcolor.msg ([('VERDE', 'generator:'),
				('rojo', 'Error:'),
				('cyan', 'Invalid arguments.')])
		sys.exit (-1)

	# Select and generate the output
	out = formats [format]

	fd = open (notOptionArgs [1], 'w')

	if out == 1:
		step.mrsOutput (s, fd)
	elif out == 2:
		step.cOutput (s, fd)
	elif out == 3:
		step.octaveOutput (s, fd)
	else:
		bashcolor.msg ([('VERDE', 'mrstepper:'),
				('rojo', 'Error:'),
				('cyan', 'Invalid output value.')])
	fd.close ()
