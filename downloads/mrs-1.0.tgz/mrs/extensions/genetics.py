#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# test1.py, Prueba de evaluaciones de secuencias
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys
from simulator import bashcolor, simulation
from generator import step
from math import sqrt, sin, pi
import genyal2

# Samples is implicit, not variable for optimizing

f = lambda A, Phi, t: int (A * sin ((2 * pi * t) / 10 + pi / 180.0 * Phi))

def fitness (chromo):
	a = 20
	func = f
	cpgs = [(func, [a, d * 5]) for d in chromo]
	
	seq = step.generateMatrix (cpgs, 10)
	simulation.initSim (['quad.rbt'], [seq])
	simulation.simulationLoop (sys.argv, 100, 0)
	
	initPos = simulation.getRobotInitPosition ()
	lastPos = simulation.getRobotLastPosition ()

	xdiff = lastPos [0] - initPos [0]
	ydiff = lastPos [1] - initPos [1]
	
	distance = sqrt (xdiff * xdiff + ydiff * ydiff)
	return distance

if __name__ == '__main__':
	ga = genyal2.Genyal (8, range (72), 9, fitness, True)
	n = 100
	while ga.generation < 100:
		st = ga.statics ()
		print 'gen %d: mean -> %2.3f, best -> %2.3f' % st
		print ga.bestIndividual ()
		ga.nextGen ()
	ga.histoDump ('salida')
	print 'The best individual is:'
	print ga.bestIndividual ()
