#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# designer.py, Designer of Robot Structures
# Copyright (C) 2006 por Rafael Trevi�o Men�ndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys
import time
import glSelector
import design
from OpenGL.GL import *
from OpenGL.GLUT import *
from math import pi, cos, sin, tan
from libs import drawstuff

#****************************************************************#
#* Funcion de retrollamada de comienzo de la simulacion         *#
#* Se utiliza principalmente para establecer el punto de vista  *#
#* inicial (posicion de la camara en el universo)               *#
#****************************************************************#
def start ():
	# print 'Llamada a start ()'
	##-- Esta es la posicion de la camara. Se pasan las coordenadas x,y,z
	xyz = (-6.0, 0.3, 2.0)
	
	##-- Esta es la orientacion de la camara.
	##-- Las componentes son Pan, Tilt (inclinacion) y Roll
	##-- El valor (0,0,0) indica que la camara esta apuntando en 
	##-- direccion positiva de las X, paralelamente al suelo.
	hpr = (0.0, -19.0, 0.0)
	
	##-- Establecer la posicion de la camara
	drawstuff.dsSetViewpoint (xyz, hpr)

#*********************************************#
#* FUNCION DE RETROLLAMADA.                  *#
#* Se invoca cuando se pulsa una tecla       *#
#*********************************************#
def command (cmd):
	global selected, nodes, modelFile
	# print 'Llamada a command ()'
	if cmd == 'w':
		design.writeRobot (nodes, modelFile)
	if cmd == 'a':
		if selected:
			design.appendNode (nodes, selected [0], 0)
	if cmd == 'b':
		if selected:
			design.appendNode (nodes, selected [0], 1)

#***********************************************************************#
#* Realizar un paso de simulacion. Primero se comprueba colisiones. Si *#
#* hay alguna, se crean automaticamente (por medio de la funcion       *#
#* nearCallback, puntos de contactos que en realidad son articulaciones*#
#* Despues se realiza un paso de la simulacion. Los objetos rotaran en *#
#* contacto rotaran sobre los nuevos puntos de contacto creados.       *#
#* Finalmente se eliminan. Si esta en pausa solo de dibuja el universo.*#
#***********************************************************************#
def step (pause):
	# Draw it!
	drawModel (True)

	# Small pause for not overload the CPU
	time.sleep (0.01)

# mode es bot�n/es pulsado/s y x e y las coordenadas
def mouse (mode, x, y):
	global selected

	glSelector.start (x, y)

	drawModel (False)

	buffer = glSelector.end ()
	selected = [i [2][0] for i in buffer]

def initSim ():
	global modelFile, dModule, wire
	# TODO: Leer el fichero si se da

def drawModel (renderMode):
	"""Draw the total scene for render or selection mode"""
	global nodes, selected, L

	if not renderMode:
		s = drawstuff.dsSetShadows (0)

	# Coords of the first node (0)
	coords = {0 : (0.0, 0.0, 1.0, 0.0, 0.0)}

	nextName = 0
	for i, modules in nodes.iteritems ():
		n = len (modules)
		if i == 0:
			delta = 2 * pi / n
		else:
			delta = 2 * pi / (n + 1)
		xorigen, yorigen, zorigen, rho, dist = coords [i]
		if i == 0 and len (modules) > 1:
			rho = pi
		rho += delta + pi
		if not renderMode:
			glLoadName (nextName)
		else:
			if nextName in selected:
				drawstuff.dsSetColor (1.0, 0.0, 0.0)
			else:
				drawstuff.dsSetColor (0.75, 0.75, 0.75)
		# It must be here
		nextName += 1
		R = [cos (rho), -sin (rho), 0.0,
		     sin (rho),  cos (rho), 0.0,
		     0.0,         0.0,        1.0]
		drawstuff.dsDrawBox ((xorigen, yorigen, zorigen), R, (.3, .3, .3))
		for module in modules:
			R = [cos (rho), -sin (rho), 0.0,
		    	 sin (rho),  cos (rho), 0.0,
			     0.0,         0.0,        1.0]
			xorig, yorig, zorig = (xorigen + cos (rho) * (.5 * L + dist), yorigen + sin (rho) * (.5 * L + dist), zorigen)
			xdest, ydest, zdest = (xorig + cos (rho) * L, yorig + sin (rho) * L, zorig)
			if renderMode:
				if module [0] == 'V':
					vertical = 1
				else:
					vertical = 0
				drawstuff.dsDrawY1 ((xorig, yorig, zorig), R, (.5, .5, .5), 0, vertical, 0)
				drawstuff.dsDrawY1 ((xdest, ydest, zdest), R, (.5, .5, .5), 1, vertical, 0)
				drawstuff.dsSetColor (0.75, 0.75, 0.75)
				drawstuff.dsDrawLine ((xorig, yorig, zorig),
						      (xdest, ydest, zdest))
			
			theta = pi / (len (nodes [module [3]]) + 1)
			if theta >= pi / 2:
				distance = 0.0
				xdest, ydest, zdest = (xorig + cos (rho) * 1.5 * L, yorig + sin (rho) * 1.5 * L, zorig)
			else:
				distance = D / tan (theta)
				xdest, ydest, zdest = (xorig + cos (rho) * (1.5 * L + distance), yorig + sin (rho) * (1.5 * L + distance), zorig)
			coords [module [3]] = (xdest, ydest, zdest, rho, distance)
			rho += delta
	if not renderMode:
		drawstuff.dsSetShadows (s)

################
### Begining ###
################

# Optional arguments
modelFile = None
dModule = 0
wire = 0

### GLOBAL DATA ###
# Initialize the userInfo module
# ui = userInfo.userInfo (7, GLUT_BITMAP_HELVETICA_12, 12, 800, 600, 1)
# Node list
# Each element is one node and all the paths from him
# Initial state
nodes = {0 : [('V', 'N', 'N', 1)], 1 : []}

# Variable of selected nodes
selected = []

# Length between nodes
L = 0.52
D = 0.26

def parseArgs (args):
	"""Function that examines the command line arguments without modifications."""
	global modelFile, dModule, wire
	# Loop the arguments without first (program name)
	for arg in args [1:]:
		# Option argument
		if arg [0] == '-':
			arg = arg [1:]
			if arg == 'm':
				dModule = 1
			if arg == 'w':
				wire = 1
			# TODO: Switch for option values and actions
		# Not option argument
		else:
			modelFile = arg

if __name__ == '__main__':
	# Parse the argument list for options and data
	parseArgs (sys.argv)

	# Initialize the simulation (list of models, list of sequences)
	# Dummy function TODO: do it
	# initSim ()

	# Initialize the functions vector with default values
	fn = (2, start, step, command, mouse, None, './textures')

	# Initialize glSelector
	glSelector.init (400, 300)

	# Call the real magic function
	drawstuff.dsSimulationLoop (len (sys.argv), sys.argv, 400, 300, fn, 1)
