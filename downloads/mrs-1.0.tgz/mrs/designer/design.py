#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# designer.py, Designer of Robot Structures
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael TreviÃ±o MenÃ©ndez <skasi.7@gmail.com>

# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

def appendNode (nodes, sel, type):
	if nodes == [] or nodes == {} or nodes == None:
		nodes = {0 : [('V', 'N', 'N', 1)], 1 : []}
	
	nextOne = len (nodes)
	if type == 0:
		nodes [sel].append (('V', 'N', 'N', len (nodes)))
	elif type == 1:
		nodes [sel].append (('H', 'N', 'N', len (nodes)))
	nodes [nextOne] = []

def writeRobot (nodes, modelFile):
	if not modelFile:
		modelFile = 'robot.rbt'
	
	print 'Config. escrita en "%s"' % modelFile

	fd = open (modelFile, 'w')
	for i, modules in nodes.iteritems ():
		for module in modules:
			print >> fd, i, module [0] + module [1] + module [2], module [3]
	fd.close ()

if __name__ == '__main__':
	print 'Autotesting...'
	nodes = {0 : [('V', 'N', 'N', 1)], 1 : []}
	print 'Module added'
	appendNode (nodes, 0, 0)
	print 'Module type 0 added at node 0'
	appendNode (nodes, 0, 1)
	print 'Module type 1 added at node 0'
	appendNode (nodes, 1, 1)
	print 'Module type 1 added at node 1'
	appendNode (nodes, 1, 1)
	print 'Module type 1 added at node 1'
	appendNode (nodes, 2, 1)
	print 'Module type 1 added at node 2'
	appendNode (nodes, 3, 0)
	print 'Module type 0 added at node 3'
	appendNode (nodes, 5, 0)
	print 'Module type 1 added at node 1'
	writeRobot (nodes, 'test.rbt')
	print 'Robot writed at "test.rbt"'
