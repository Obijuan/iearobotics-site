#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# glSelector.py, OpenGL Selection Module
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from OpenGL.GL import *
from OpenGL.GLU import *

w = None
h = None

def init (width, height):
	global w, h
	w = 1.0 * width
	h = 1.0 * height

def start (x, y):
	"""Inicia la selección de elementos en el punto dado por los parámetros."""
	global w, h
	### INIT ###
	# set the selection buffer size
	glSelectBuffer (256)
	# Enter selection mode
	glRenderMode (GL_SELECT)

	# Set the projection
	glMatrixMode (GL_PROJECTION)
	glPushMatrix ()
	glLoadIdentity ()

	viewport = glGetIntegerv (GL_VIEWPORT)
	# 5, 5 is the selection volume
	gluPickMatrix (x, viewport [3] - y, 5.0, 5.0, viewport)
	
	vnear = 0.1
	vfar = 100.0
	k = 0.8
	if w >= h:
		k2 = h / w
		glFrustum (-vnear * k, vnear * k, -vnear * k * k2, vnear * k * k2, vnear, vfar)
	else:
		k2 = w / h
		glFrustum (-vnear * k * k2, vnear * k * k2, -vnear * k, vnear * k, vnear, vfar);
	
	# gluPerspective (50, 1.0, 0.1, 100.0)
	# gluPerspective (45.0, viewport [2] / viewport [3], 0.1, 1000.0)
	glMatrixMode (GL_MODELVIEW)
	glInitNames ()

	glPushName (0)

def end ():
	"""Devuelve la lista de elementos dentro de la proyección del ratón tras haber renderizado todo lo que se quería detectar."""
	### END ###
	# Restore matrix
	glMatrixMode (GL_PROJECTION)
	glPopMatrix ()
	glMatrixMode (GL_MODELVIEW)
	glFlush ()

	# Process hits
	return glRenderMode (GL_RENDER)
	###
