#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# simulator.py, Simulator
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys			# Module for system operations (get arguments)
import simulation		# Module for simulating robot and sequence together
import bashcolor		# Module for nice color messages

# List of mandatory arguments
notOptionArgs = []

# Optional arguments
nRobots = 1
dModule = 0
wire = 0
time = None
render = 1
serial = None

def parseArgs (args):
	"""Function that examines the command line arguments without modifications."""
	global notOptionArgs, nRobots, dModule, wire, time, render, serial
	# Loop the arguments without first (program name)
	for arg in args [1:]:
		# Option argument
		if arg [0] == '-':
			arg = arg [1:]
			if arg [0] == 't':
				try:
					time = int (arg [1:])
					bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', '%d seconds.' % time)])
				except:
					bashcolor.msg ([('VERDE', 'mrs:'),
							('amarillo', 'Warning:'),
							('cyan', 'argument for %s option invalid.' % arg)])
			elif arg [0] == 'n':
				try:
					nRobots = int (arg [1:])
					bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', '%d robots.' % nRobots)])
				except:
					bashcolor.msg ([('VERDE', 'mrs:'),
							('amarillo', 'Warning:'),
							('cyan', 'argument for %s option invalid.' % arg)])
			elif arg [0] == 'd':
				serial = arg [1:]
				bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', 'using "%s" as dev.' % serial)])
			elif arg == 'm':
				dModule = 1
				bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', 'using Y1 modules.')])
			elif arg == 'w':
				wire = 1
				bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', 'using wires.')])
			elif arg == 's':
				render = 0
				bashcolor.msg ([('VERDE', 'mrs:'),
							('morado', 'Note:'),
							('cyan', 'without rendering.')])
			else:
				bashcolor.msg ([('VERDE', 'mrs:'),
							('amarillo', 'Warning:'),
							('cyan', 'unknown option "-%s".' % arg)])
			# TODO: Switch for option values and actions
		# Not option argument
		else:
			notOptionArgs.append (arg)

if __name__ == '__main__':
	# Parse the argument list for options and data
	parseArgs (sys.argv)

	# Check if required arguments are present (1 model and 1 sequence)
	notOptionCount = len (notOptionArgs)
	if notOptionCount < 1:
		bashcolor.msg ([('VERDE', 'mrs:'),
				('amarillo', 'Use:'),
				('cyan', '%s [options] <robot_file> [movement_files]' % sys.argv [0]),
				('cyan', '\n\toptions: -t<seconds> | -n<#robots> | -d<serial dev> | -m | -w | -s')])
		sys.exit (-1)
	
	# Append None if no sequence
	if notOptionCount < 2:
		bashcolor.msg ([('VERDE', 'mrs:'),
				('amarillo', 'Warning:'),
				('cyan', 'No movement file.')])
		notOptionArgs.append (None)

	# Sequences supplied
	sequences = notOptionArgs [1:]

	# Initialize the simulation (list of models, list of sequences)
	simulation.initSim (nRobots * len (sequences) * [notOptionArgs [0]],
			    nRobots * sequences,
			    dModule, wire, serial)

	# Begin the simulation!
	simulation.simulationLoop (sys.argv, time, render)
