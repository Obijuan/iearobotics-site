;-- Clone wars
;-- Example for testing the Prusa Mendel
;-- It prints a fake Cube:  All the motors are moved but
;-- the extruder and heated bed are not enabled
;-- Cube size: 2x2x2 cm
;-- First a Raft is added

G21 (Set units to mm)
G90 (Absolute coordinates)
G28 (--Home all Axis ---)
G92 X0 Y0 Z0 E0 (-- Current position is 0,0,0 ---)
M103 (Turn all extruders off)
M113 S1.0 (Set extruder PWM)
M108 S18.0
M108 S45.0 (Set extruder vel)
G1 Z5.0 F300.0
G1 X100 Y100 Z0.72 F300.0
G1 F900.0
G1 E1.1
G1 F300.0
M101 (Turn extruder fordward)
;----(Print the perimeter)
G1 X116.87 Y105.896 Z0.72 F675.0 E6.0351


