import libStargate.Servos8

#-- Open the connection with the servo server
s=libStargate.Servos8.Open_session("/dev/ttyUSB0")
    
#-- Enable all the servos
s.enable(0xff);

#-- Set all the servos to their initial pos
s[1]=0;
s[2]=0;
s[3]=0;
s[4]=0;
s[5]=0;
s[6]=0;
s[7]=0;


