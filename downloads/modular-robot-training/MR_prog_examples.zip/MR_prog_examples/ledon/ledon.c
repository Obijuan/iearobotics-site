/*******************************************************************/
/** ledon.c                                                        */
/**----------------------------------------------------------------*/
/** Hello world program. It just turn on the green led on the      */
/** Skycube board                                                  */
/**----------------------------------------------------------------*/
/** (c) Dr. Juan Gonzalez-Gomez. Feb-2011                          */
/**----------------------------------------------------------------*/
/** GPL license                                                    */
/*******************************************************************/

//-- Specify the PIC micro-controller used in the Skycube board
#include <pic16f876a.h>

//-- Definitions
#define OUTPUT  0

//-- The green led in the Skycube board is located on bit RB1
#define LED RB1

//-- Define the on state
#define ON   1

void main(void)
{
  //-- Configure the Port B bit 1 as an output
  TRISB1 = OUTPUT;

  //-- Turn the LED on!
  LED = ON;

  //-- Infinity loop. Finish the program.
  while(1);
}

