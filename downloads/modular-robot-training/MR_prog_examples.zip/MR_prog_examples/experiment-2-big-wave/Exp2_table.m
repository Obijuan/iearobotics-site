#-- Calculations for thex Experiment 2


#--Wave's k parameter
k=[0 0.5 1 2 3 4 5 10];

#-- Number of modules
M=30;

#-- Phase difference between virtual module 2 and 1
P12 = 360*k/M

#-- Phase difference between virtual module 3 and 1
P13 = 2*P12


#-- Phase of virtual module 1
for i=1:10
  P1 = rem(3*(i-1)*360*k/M,360)
endfor


