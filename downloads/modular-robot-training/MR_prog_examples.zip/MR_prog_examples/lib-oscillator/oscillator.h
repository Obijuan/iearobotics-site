/********************************************************************/
/** Oscillator module                                               */
/**-----------------------------------------------------------------*/
/** (c) Dr. Juan Gonzalez-Gomez.                                    */
/** Feb/2011                                                        */
/**-----------------------------------------------------------------*/
/** GPL license                                                     */
/********************************************************************/

#ifndef OSCILLATOR_H
#define OSCILLATOR_H

void oscillator_init();
void oscillator_pos();
void oscillator_set_params(unsigned char m);

#endif
