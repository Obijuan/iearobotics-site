/*************************************************************************** */
/* skypad-test.c                                                             */
/*---------------------------------------------------------------------------*/
/* Ejemplo para la tarjeta SKYPIC                                            */
/*---------------------------------------------------------------------------*/
/* Conectar la skypads al puerto C de la skypic y la freeleds al puerto B    */
/* El estado de los 8 pulsadores de la skypad se podra ver en los leds de    */
/* la freeleds.                                                              */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

#include <pic16f876a.h>

#define LED RB1

void main(void)
{
  
  //-- Configurar puerto C para entrada
  TRISC = 0xFF;

  //-- Configurar puerto B para salida
  TRISB=0x00;

  while(1) {
    //-- Sacar por el puerto B todo lo leido por el puerto C
    PORTB=~PORTC;
  }

}

