@echo off
cd %~dp0
set CLASSPATH=%CLASSPATH%;
set CLASSPATH=%CLASSPATH%;lib/GiovynetDriver.jar
set CLASSPATH=%CLASSPATH%;bin
@echo on
java -Djava.library.path=./native/windows robot.gui.RobotMain
pause
