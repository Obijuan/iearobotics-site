package serial;

import giovynet.serial.Com;

/**
 * Interface que proporciona los métodos para implementar el patrón Observer.
 */
public interface SerialPortObserver{
	
	/**
	 * Método que notifica que el estado del puerto serie ha cambiado.
	 * 
	 * @param com Nuevo estado del puerto serie.
	 */
	public void notifySerialPortStateChange( Com com );
}
