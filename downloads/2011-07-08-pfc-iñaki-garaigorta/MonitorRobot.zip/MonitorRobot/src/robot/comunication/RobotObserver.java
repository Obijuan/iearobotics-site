package robot.comunication;

import robot.EstadoRobot;

/**
 * Interface que proporciona los métodos para implementar el patrón Observer.
 */
public interface RobotObserver{
	
	/**
	 * Método que notifica que el estado del robot ha cambiado.
	 * 
	 * @param estado Nuevo estado del robot.
	 */
	public void notifyRobotStateChange( EstadoRobot estado );
}
