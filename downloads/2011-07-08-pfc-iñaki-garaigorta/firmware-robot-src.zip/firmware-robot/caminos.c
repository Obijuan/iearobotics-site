#include "caminos.h"



/**********************/
/* Inicializa camino  */
/**********************/
void Inicializa( unsigned char camino, Estado* estado)
{
  switch (camino)
    //Realizamos la inicializaci�n de los valores seg�n el camino seleccionado
    {
  case CAMINO_IZQ:
    estado->camino = CAMINO_IZQ;
    estado->saltosIda = 3;//numero saltos q debo dar a la ida
    estado->saltosVuelta = 3;//numero saltos q debo dar a la vuelta
    estado->saltosRestantes = estado->saltosIda;//numero de saltos que me faltan por dar. Se inicializa con la ida
    estado->realizandoSalto = FALSO;//inicializamos el flag para que cuente salto
    estado->volviendo = FALSO;//inicializamos el flag de vuelta como falso(ida)
    estado->home = FALSO;//en cuanto nos movemos quitamos el estado de home a falso
		estado->automatico = VERDADERO;//distinguimos el modo automatico
		break;
  
	case CAMINO_RECTO:
    estado->camino = CAMINO_RECTO;
    estado->saltosIda = 2;//numero saltos q debo dar a la ida 
    estado->saltosVuelta = 2;//numero saltos q debo dar a la vuelta
    estado->saltosRestantes = estado->saltosIda;//numero de saltos que me faltan por dar. Se inicializa con la ida
    estado->realizandoSalto = FALSO;//inicialiamos el flag para que cuente salto
    estado->volviendo = FALSO;//inicializamos el flag de vuelta como falso (ida)
    estado->home = FALSO;//en cuanto nos movemos quitamos el estado de home a falso
		estado->automatico = VERDADERO;//distinguimos el modo automatico
		break;
  
	case CAMINO_DER:
    estado->camino =CAMINO_DER;
    estado->saltosIda = 3;//numero saltos q debo dar a la ida 
    estado->saltosVuelta = 3;//numero saltos q debo dar a la vuelta
    estado->saltosRestantes = estado->saltosIda;//numero de saltos que me faltan por dar. Se inicializa con la ida
    estado->realizandoSalto = FALSO;//inicialiamos el flag para que cuente salto
    estado->volviendo = FALSO;//inicializamos el flag de vuelta como falso (ida)
    estado->home = FALSO;//en cuanto nos movemos quitamos el estado de home a falso
		estado->automatico = VERDADERO;//distinguimos el modo automatico
		break;
  
	default:
    estado->camino = 0;
    estado->saltosIda = 0;//numero saltos q debo dar a la ida 
    estado->saltosVuelta = 0;//numero saltos q debo dar a la vuelta
    estado->saltosRestantes = 0;//numero de saltos que me faltan por dar. Se inicializa con la ida
    estado->realizandoSalto = FALSO;//inicializamos el flag para que cuente salto
    estado->volviendo = FALSO;//inicializamos el flag de vuelta como falso(ida)
    estado->home = VERDADERO;//en cuanto nos movemos quitamos el estado de home a falso
		estado->automatico = FALSO;//distinguimos el modo automatico
		break;
    }
}


/**************/
/*Camino Izq  */
/**************/
void Camino_Izq(Estado* estado)
{
  //Condicion simpre cierta para evitar el Warning por no usar el par�metro
  if (Estado_Sensores() == 3 && estado->saltosRestantes == 0)
    {
      if (estado->volviendo)//legamos al final del trayecto
        {
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          Inicializa( 0, estado );
        }
      else //llegada a destino
        {
          Parar();
          PausaTiempo(4, 0);//dejamos que descargue
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          estado->saltosRestantes = estado->saltosVuelta;//inicializamos el contador de saltos para la vuelta
          estado->volviendo = VERDADERO;//marcamos al robot en modo vuelta
        }
    }
  else
    {
			if (Estado_Sensores () == 3 && estado->volviendo )
				{
					if(estado->saltosRestantes == 1)
					 {
						Cambiar_Orientacion(GIRAR_DER);//luego giramos para colocarnos en el camino de la Izquierda
						estado->saltosRestantes--;
					 }
				}	 

      else if (Estado_Sensores() == 3 && estado->saltosRestantes == 2)//estamos en la marca de giro 
				{
					Cambiar_Orientacion(GIRAR_IZQ);//luego giramos para colocarnos en el camino de la derecha
					estado->saltosRestantes--;
				}
				
	  
	  //miramos si estan los sensores 1 y 2 a negro y no ha comenzado un salto
      if (Estado_Sensores() == 3 && !estado->realizandoSalto)
        estado->realizandoSalto = VERDADERO;
      //miramos si estan los sensores 1 y 2 a blanco y debe completar un salto
      else if (Estado_Sensores() == 0 && estado->realizandoSalto)
        {
          estado->realizandoSalto = FALSO;//quitamos la marca de salto
          estado->saltosRestantes--;//contamos el salto
        }
      Seguir_Linea();
    }
}

/**************/
/*Camino recto*/
/**************/
void Camino_Recto(Estado* estado)
{
  if (Estado_Sensores() == 3 && estado->saltosRestantes == 0)
    {
      if (estado->volviendo)//legamos al final del trayecto
        {
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          Inicializa( 0, estado );
        }
      else //legada a destino
        {
          Parar();
          PausaTiempo(4, 0);//dejamos que descargue
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          estado->saltosRestantes = estado->saltosVuelta;//inicializamos el contador de saltos para la vuelta
          estado->volviendo = VERDADERO;//marcamos al robot en modo vuelta
					estado->carga = FALSO;
        }
    }
  else
    {
      //miramos si estan los sensores 1 y 2 a negro y no ha comenzado un salto
      if (Estado_Sensores() == 3 && !estado->realizandoSalto)
        estado->realizandoSalto = VERDADERO;
      //miramos si estan los sensores 1 y 2 a blanco y debe completar un salto
      else if (Estado_Sensores() == 0 && estado->realizandoSalto)
        {
          estado->realizandoSalto = FALSO;//quitamos la marca de salto
          estado->saltosRestantes--;//contamos el salto
        }
      Seguir_Linea();
    }
}

/**************/
/*Camino Der  */
/**************/
void Camino_Der(Estado* estado)
{
  //Condicion simpre cierta para evitar el Warning por no usar el par�metro
  if (Estado_Sensores() == 3 && estado->saltosRestantes == 0)
    {
      if (estado->volviendo)//legamos al final del trayecto
        {
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          Inicializa( 0, estado );
        }
      else //llegada a destino
        {
          Parar();
          PausaTiempo(4, 0);//dejamos que descargue
          Cambiar_Orientacion(GIRAR_IZQ);//luego giramos
          estado->saltosRestantes = estado->saltosVuelta;//inicializamos el contador de saltos para la vuelta
          estado->volviendo = VERDADERO;//marcamos al robot en modo vuelta
        }
    }
  else
    {
			if (Estado_Sensores () == 3 && estado->volviendo )
				{
					if(estado->saltosRestantes == 1)
					 {
						Cambiar_Orientacion(GIRAR_IZQ);//luego giramos para colocarnos en el camino de la derecha
						estado->saltosRestantes--;
					 }
				}	 

      else if (Estado_Sensores() == 3 && estado->saltosRestantes == 2)//estamos en la marca de giro 
				{
					Cambiar_Orientacion(GIRAR_DER);//luego giramos para colocarnos en el camino de la derecha
					estado->saltosRestantes--;
				}
				
	  
	  //miramos si estan los sensores 1 y 2 a negro y no ha comenzado un salto
      if (Estado_Sensores() == 3 && !estado->realizandoSalto)
        estado->realizandoSalto = VERDADERO;
      //miramos si estan los sensores 1 y 2 a blanco y debe completar un salto
      else if (Estado_Sensores() == 0 && estado->realizandoSalto)
        {
          estado->realizandoSalto = FALSO;//quitamos la marca de salto
          estado->saltosRestantes--;//contamos el salto
        }
      Seguir_Linea();
    }
}


