/****************************************************/
/*  comunicacion_skybot.h 						    */
/*cabecera para la comunicacion pc-skybot           */
/****************************************************/
/* Depende de las cabeceras:                        */
/* 			-funciones_skybot.h                     */
/*										        	*/
/*     Creado por i�aki garaigorta zarzuela         */
/****************************************************/

//cabeceras
#ifndef _COMUNICACION_SKYBOT
#define _COMUNICACION_SKYBOT
#define _16f876a
#include "libreria_skybot.h"

//Constantes para la configuraci�n del puerto serie
#define B9600_4MHZ   0x19
#define B9600_20MHZ  0x81


//---------------------------------------------
//-- CONSTANTES MODIFICABLES POR EL USUARIO
//---------------------------------------------
//-- Establecer la velocidad para un cristal de 20MHZ
//-- La skypic lleva 20Mhz
#define B9600 B9600_20MHZ






/****************************************************/
/* Configurar el puerto serie a N81 y 9600 Baudios  */
/****************************************************/
void sci_conf(void);



/******************************************/
/* Recibir un caracter por el SCI         */
/*----------------------------------------*/
/* ENTRADAS:                              */
/*		-*dato(puntero a la variable dato)*/
/* DEVUELVE:                              */
/*      -0 (no hay lectura)               */
/*      -1 (si hay lectura)               */
/******************************************/
unsigned char sci_read(unsigned char *dato);


/*****************************************/
/* Transmitir un caracter por el SCI     */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*   -car: Caracter a enviar             */
/*****************************************/
unsigned char sci_write(unsigned char car);

#endif
