/*****Libreria donde tenemos los sensores *****/



#include "chequeo.h"

/*****************************************/
/* Mira el estado de los sensores        */
/*---------------------------------------*/
/* ENTRADAS:NINGUNA                      */
/*****************************************/
unsigned char Chequea_Estado (Estado* estado)
{
  //inicializamos el dato a enviar
  unsigned char estado_robot = 0;
  
  //comprobamos si se cambiaron los bits de los estados
  if (estado->emergencia)
    estado_robot |= EMERGENCIA_MASK;
  
  if (estado->carga)
    estado_robot |= CARGA_MASK;
  
  if (estado->home)
    estado_robot |= CONTROL_HOME;
  else if (estado-> automatico){
		estado_robot |= CONTROL_AUTO;
		//mascaras de camino 
	
		if (estado->camino == CAMINO_IZQ)//izquierda
			estado_robot |= 0x01;
		if (estado->camino == CAMINO_RECTO)//recto
			estado_robot |= 0x02;
		if (estado->camino == CAMINO_DER)//derecho
			estado_robot |= 0x03;
	 

	 //aplicamos la m�scara de ida o vuelta despues del camino para corregir el bit de orden
		
		if (estado->volviendo)
			estado_robot |= SENTIDO_VUELTA;
		else
			estado_robot |= SENTIDO_IDA;
		//estado_robot |= SENTIDO_INDEFINIDO;
	}
	else
	{
		estado_robot |= CONTROL_MANUAL;
		estado_robot |= estado->orden_manual & MOVIMIENTO_MASK;
	}
  return estado_robot; 
}

/*****************************************/
/* Mira el estado de los sensores        */
/*---------------------------------------*/
/* ENTRADAS:NINGUNA                      */
/*****************************************/
void enviar(Estado* estado, Paquete* paquete)
{
   
  if (paquete->bytes_enviados < 0)
    {
      if (!sci_write(CABECERA))
        return;
      paquete->bytes_enviados++;
    }
  if (paquete->bytes_enviados == 0)
    {
      if (!sci_write(PORTA))
        return;
			paquete->bytes_enviados++;
			paquete->portA = PORTA;
			paquete->portB = PORTB;
			paquete->state = Chequea_Estado(estado);
    }
  if (paquete->bytes_enviados == 1)
    {
      if (!sci_write( paquete->portB ))
        return;
     paquete->bytes_enviados++;
    }
  if (paquete->bytes_enviados == 2)
    {
		 if (!sci_write( paquete->state ) )
				return;
     paquete->bytes_enviados++;
    }
  if (paquete->bytes_enviados == 3)
    {
     if (!sci_write( 0x0F ) )
        return;
     paquete->bytes_enviados = -1;
    }
}




