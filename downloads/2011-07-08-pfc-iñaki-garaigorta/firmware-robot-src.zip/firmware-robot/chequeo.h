#ifndef _CHEQUEO
#define _CHEQUEO

#include "funciones_skybot.h"
#include "comunicacion_skybot.h"
#include "definiciones.h"


//registro donde guardamos el estado del robot
typedef struct
{
  unsigned char saltosIda;
  unsigned char saltosVuelta;
  unsigned char saltosRestantes;
  unsigned char realizandoSalto;  
  
	
	unsigned char camino;
  unsigned char volviendo;
  unsigned char emergencia;
  unsigned char carga;
  unsigned char home;
  unsigned char automatico;
  unsigned char sentido;
  
	unsigned char orden_manual;

} Estado;


//registro donde guardamos los valores de los registros del robot
typedef struct
{
  int bytes_enviados; //esta variable nos permite saber cuantos paquetes hemos enviados 
  unsigned char portA; //registro A
  unsigned char portB; //registro B
  unsigned char state; // el estado del robot 
} Paquete;


/*aplica la m�scara al estado del robot */
unsigned char Chequea_Estado (Estado* estado);

/*envia el estado del robot*/
void enviar(Estado* estado, Paquete* paquete);




#endif