/****************************************************/
/*  comunicacion_skybot.c 						    */
/*Librer�a para la comunicacion pc-skybot           */
/****************************************************/
/* Depende de las cabeceras:                        */
/* 			-libreria_skybot.h                      */
/*										        	*/
/*     Creado por i�aki garaigorta zarzuela         */
/****************************************************/


//cabeceras

#include "comunicacion_skybot.h"
#include "libreria_skybot.h"

/****************************************************/
/* Configurar el puerto serie a N81 y 9600 Baudios  */
/****************************************************/
void sci_conf(void)
{
  SPBRG = 0x81;  //-- 9600 baudios (con cristal de 20MHz)
  TXSTA = 0x24;  //-- Configurar transmisor
  RCSTA = 0x90;  //-- Configurar receptor 
}


/******************************************/
/* Recibir un caracter por el SCI         */
/*----------------------------------------*/
/* ENTRADAS:                              */
/*		-*dato(puntero a la variable dato)*/
/* DEVUELVE:                              */
/*      -0 (no hay lectura)               */
/*      -1 (si hay lectura)               */
/******************************************/
unsigned char sci_read(unsigned char *dato)
{
  
  //Vigila el buffer de entrada
  if(RCIF){
     *dato = RCREG;//devuelve  el registro donde se guarda el contenido del buffer
	 return 1;
  }
  return 0;   
}


/*****************************************/
/* Transmitir un caracter por el SCI     */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*   -car: Caracter a enviar             */
/*****************************************/
unsigned char sci_write(unsigned char car)
{
  //mira si el Flag de listo para transmitir est� activado
  if (TXIF)
    {
      TXREG = car;//-- Hacer la transmision
      return VERDADERO;
    }
  return FALSO;
}

