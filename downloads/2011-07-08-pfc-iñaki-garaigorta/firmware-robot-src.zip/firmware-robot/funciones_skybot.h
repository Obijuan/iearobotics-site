/****************************************************/
/*  funciones_skybot.h                              */
/*Cabecera de la libreria de las funcionesavanzadas */
/****************************************************/
/* Depende de las cabeceras:                        */
/*     -libreria_skybot.h                           */
/*                                                  */
/*     Creado por i�aki garaigorta zarzuela         */
/****************************************************/

#ifndef _FUNCIONES_SKYBOT
#define _FUNCIONES_SKYBOT

#include "libreria_skybot.h"

//Definiciones usadas en las funciones

//--Estado de la carga
#define DESCARGADO 0
#define CARGADO    1

//--Sentido de giros
#define GIRAR_IZQ  0
#define GIRAR_DER  1


/*****************************************/
/*Avanza el robot buscando la linea negra*/
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -NINGUNA                         */
/* SALIDAS:                              */
/*      -NINGUNA                         */
/*****************************************/

void Seguir_Linea(void);



/*****************************************/
/*Gira el robot sobre la linea negra     */  
/*en el sentido dado (I)zq/(D)er         */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -giro (I/D)                      */
/* SALIDAS:                              */
/*      -Devuelve:                       */
/*        -1 Cuando el giro este completo*/
/*        -0 Si surgem problemas         */       
/*****************************************/

void Cambiar_Orientacion (unsigned char giro);


/*****************************************/
/*Funci�n que lee los sensores 1 y 2     */
/*Devolvemos que sensores estan en NEGRO */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -NINGUNA                         */
/* SALIDAS:                              */
/*      -Devuelve:                       */
/*        -0(Todos los sensores BLANCO)  */
/*        -1(sensor IZQUIERDO en NEGRO)  */
/*        -2(sensor DERECHO en NEGRO)    */
/*        -3(Todos los sensores NEGRO)   */
/*****************************************/

unsigned char Estado_Sensores(void);


#endif

