/****************************************************/
/*  funciones_skybot.c                              */
/*Librer�a de las funciones avanzadas para el skybot*/
/****************************************************/
/* Depende de las cabeceras:                        */
/*     -funciones_skybot.h                          */
/*                                                  */
/*     Creado por i�aki garaigorta zarzuela         */
/****************************************************/

#include "funciones_skybot.h"




/*****************************************/
/*Avanza el robot buscando la linea negra*/
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -NINGUNA                         */
/* SALIDAS:                              */
/*      -NINGUNA                         */
/*****************************************/
void
Seguir_Linea(void)
{

  //Comprovamos que los dos sensores lean negro
  if (SensorIR_Izq_Lee_Negro() && SensorIR_Der_Lee_Negro())
    {
      Avanzar();
    }
  else if (SensorIR_Izq_Lee_Negro())
    {
      GirarIzq();
    }
  else if (SensorIR_Der_Lee_Negro())
    {

      GirarDer();
    }
  else//si ningun sensor lee negro paramos
    {
      Parar();
    }
}

/*****************************************/
/*Gira el robot sobre la linea negra     */
/*en el sentido dado (I)zq/(D)er         */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -giro (I/D)                      */
/* SALIDAS:                              */
/*	-Devuelve:                       */
/*        -1 Cuando el giro este completo*/
/*        -0 Si surgen problemas         */
/*****************************************/

void
Cambiar_Orientacion(unsigned char giro) //falta introducir un contador que si se sobre pasa significa q algo va mal y devuelva 0
{
  unsigned char completo = FALSO;//Variable que nos servir� como flag. Cuando est� a uno el cambio de sentido se habr� terminado
  unsigned char fmitad = FALSO;//variable que nos servir� para indicar que el giro a comenzado y falta un poco mas de la mitad del recorrido

  //realizamos el giro 
  if (giro == GIRAR_IZQ)//giro hacia la izquierda
    {
      GirarIzq();//comenzamos a girar
      while (!completo)//y no paramos hasta que este completo
        {
          if (SensorIR_Der_Lee_Blanco() && !fmitad)
            fmitad = VERDADERO;
          if (SensorIR_Der_Lee_Negro() && fmitad)
            completo = VERDADERO;
        }
      Parar();
    }
  else//giro hacia la derecha
    {
      GirarDer();//comenzamos a girar
      while (!completo)//y no paramos hasta que este completo
        {
          if (SensorIR_Izq_Lee_Blanco() && !fmitad)
            fmitad = VERDADERO;
          if (SensorIR_Izq_Lee_Negro() && fmitad)
            completo = VERDADERO;
        }
      Parar();
    }
}

/******************************************/
/*Funci�n que lee los sensores 1 y 2      */
/*Devolvemos que sensores estan en NEGRO  */
/*----------------------------------------*/
/* ENTRADAS:                              */
/*      -NINGUNA                          */
/* SALIDAS:                               */
/*	                                  */
/*  sensor IZQUIERDO sensor DERECHO Valor */
/*       BLANCO          BLANCO       0   */
/*       NEGRO           BLANCO       1   */
/*       BLANCO          NEGRO        2   */
/*       NEGRO           NEGRO        3   */
/******************************************/

unsigned char
Estado_Sensores()
{
  unsigned char estado = 0x00;
  if (LeerSensor1() == NEGRO)
    estado |= 0x01;
  if (LeerSensor2() == NEGRO)
    estado |= 0x02;
  return estado;
}
