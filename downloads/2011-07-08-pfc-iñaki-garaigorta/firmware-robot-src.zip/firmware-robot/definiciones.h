#ifndef DEFICINICIONES_H_
#define DEFICINICIONES_H_


#define CABECERA            0xF0

/**
 *   Emergencia | Carga | Control | ..................
 *   -----------+-------+---------+-------------------
 *      1 Bit   | 1 Bit | 2 Bits  |  xxxxxxxxxxxxxxxxx
 *   -----------+-------+---------+-------------------
 *              |       |  HOME   |  xxxxxxxxxxxxxxxxx
 *   -----------+-------+---------+----------+--------
 *              |       |  AUTO   | Sentido  |  Ruta
 *   -----------+-------+---------+----------+--------
 *              |       |         |  2 Bits  | 2 Bits
 *   -----------+-------+---------+----------+--------
 *              |       |  MANUAL |        Orden
 *   -----------+-------+---------+-------------------
 *              |       |         |        4 Bits
 */

#define EMERGENCIA_MASK     0x80
#define CARGA_MASK          0x40

#define CONTROL_MASK        0x30
#define CONTROL_HOME        0x30
#define CONTROL_AUTO        0x20
#define CONTROL_MANUAL      0x10

#define SENTIDO_MASK        0x0C
#define SENTIDO_IDA         0x08
#define SENTIDO_VUELTA      0x04
#define SENTIDO_INDEFINIDO  0x0C

#define RUTA_MASK           0x03

#define MOVIMIENTO_MASK     0x0F

#define MOVIMIENTO_ADELANTE 0x09
#define MOVIMIENTO_ATRAS    0x0A
#define MOVIMIENTO_GIRO_IZQ 0x0B
#define MOVIMIENTO_GIRO_DER 0x0C
#define MOVIMIENTO_PARAR    0x0D

//Manuales
#define ORD_HOME       0x30
#define ORD_ADELANTE   0x19
#define ORD_ATRAS      0x1a
#define ORD_GIRO_IZQ   0x1b
#define ORD_GIRO_DER   0x1c
#define ORD_PARAR      0x1d

//Manuales Especiales
#define ORD_CARGA_DESCARGA 0x40

//Orden parada de emergencia
#define ORD_EMERGENCIA 0x80

//Rutas Automaticas
#define CAMINO_IZQ     0x21
#define CAMINO_RECTO   0x22
#define CAMINO_DER     0x23




#endif /* DEFICINICIONES_H_ */
