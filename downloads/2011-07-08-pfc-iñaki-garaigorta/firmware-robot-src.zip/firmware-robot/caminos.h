#ifndef _CAMINOS
#define _CAMINOS

#include "chequeo.h"

/*Funcion que inicializa el estado */
void Inicializa( unsigned char camino, Estado* estado);

//Funciones para cada uno de los caminos
void Camino_Izq(Estado* estado);

void Camino_Recto(Estado* estado);

void Camino_Der(Estado* estado);


#endif
