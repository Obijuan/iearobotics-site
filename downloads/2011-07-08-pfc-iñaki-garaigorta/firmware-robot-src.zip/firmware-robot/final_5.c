/////*version de caminos con registro de caminos*/


#include "caminos.h"




/*Funciones*/







/************************/
/*Parada de emergencia  */
/************************/

void Parada_Emergencia(Estado* estado, Paquete* paquete)
{
  unsigned char memoria = TRISB; //guardamos el valor del registro del puerto B
  Parar();//realizamos una parada 
  estado->emergencia = VERDADERO;//cambiamos el estado del robot a emergencia 
  while ((!RCIF) || (RCREG != ORD_EMERGENCIA))//mientras no tengamos una orden de emergencia  estaremos parados 
		enviar(estado, paquete);//enviamos los datos del estado del robot
  TRISB = memoria;//restauramos los valores del registro 
	estado->emergencia = FALSO;//quitamos el estado de emergencia en el robot
}




/*****************************************/
/*Interpreta  el caracter a modo de orden*/
/*---------------------------------------*/
/* ENTRADAS:                             */
/*      -orden                           */
/*****************************************/
void Interpreta_Orden(Estado* estado,unsigned char orden)
{
  
	switch (orden)
    {
			case ORD_ADELANTE:
				Avanzar();
				break;
			case ORD_ATRAS:
				Retroceder();
				break;
			case ORD_GIRO_IZQ:
				GirarIzq();
				break;
			case ORD_GIRO_DER:
				GirarDer();
				break;
			case ORD_PARAR:
				Parar();
				break;
			case ORD_CARGA_DESCARGA:
				if (estado->orden_manual == ORD_PARAR )
					estado->carga= !estado->carga;
				break;
			default:
				Parar();
				break;
   }  
	 estado->orden_manual = orden;
}

/****************************************/
/* Control Manual                       */
/****************************************/
/****************************************/
/* Con esta funci�n pasamos al control  */
/* manual                               */
/****************************************/

void Control_Manual(Estado* estado, Paquete* paquete)
{
  unsigned char orden = 0;
  
	while (orden != ORD_HOME)
    {
      if (RCIF)
        {
          orden = RCREG;
          if (orden == ORD_EMERGENCIA)
						Parada_Emergencia(estado,paquete);
					else
						Interpreta_Orden(estado,orden);
        }
      enviar(estado, paquete);
    }
  estado->home = VERDADERO;
	Parar();
}

/****************************************/
/* Caminos                              */
/****************************************/
/* Con esta funci�n lo que haremos es   */
/* elejir la funci�n de camino que hemos*/
/* seleccionado                         */
/****************************************/
void Caminos(Estado* estado)
{
  //Seleccionamos el camino a realizar 
	switch (estado->camino)
    {
  case CAMINO_IZQ:
    Camino_Izq(estado);
    break;
  case CAMINO_RECTO:
    Camino_Recto(estado);
    break;
  case CAMINO_DER:
    Camino_Der(estado);
    break;
  default:
    Parar();
		
    break;
    }
}

void main(void)
{
  //Declaracion de variables 
	Estado estado;
  Paquete paquete;
  unsigned char dato ;

  //configuraciones
  ConfigurarSkybot();//Inicia
  sci_conf();
  
	//Inicializacion de los registros y camino
	Inicializa( 0, &estado );
  paquete.bytes_enviados = -1;
  estado.emergencia = FALSO;
	estado.carga = FALSO;
  estado.automatico = FALSO;	

  

  //proceso principal
  for (;;)
    {
      
			//comprobamos si alg�n bumper a sido pulsado 
			if( (Bumper_Izq_esta_apretado()) || (Bumper_Der_esta_apretado()))
			 {
			  Parada_Emergencia(&estado, &paquete);// si alg�n bumper pulsado activamos la parada de emergencia 
			 }
			
			if (RCIF) //comprobamos si hemos recivido dato 
			 {
				dato = RCREG;//Guardamos el dato recivido
        
				switch (dato) //y seleccionamos la opci�n seg�n el dato
          {
						//ejecuci�n de orden de emergencia 
						case ORD_EMERGENCIA:
							Parada_Emergencia(&estado, &paquete);
							break;
						
						//ejecuci�n de orden manual 
						case ORD_PARAR:
							estado.home = FALSO;
							estado.automatico = FALSO;
							Control_Manual(&estado, &paquete);
							Inicializa(dato, &estado);
							break;
						
						//Quitar la carga o poner carga
						case ORD_CARGA_DESCARGA:
							if(estado.home)
								estado.carga= !estado.carga;
							break;	
						
						//configuramos un camino
						default:
							//if (((dato & CONTROL_MASK) == CONTROL_AUTO ) )
								Inicializa(dato, &estado);
							break;
          }
			 }
      enviar(&estado, &paquete);//enviamos el estado del robot
			Caminos(&estado);//realizamos el ciclo de instrucciones que debo seguir
    }
		
}
