Copy this folder into replicatorg-0020/skein_engines/skeinforge-0006/prefs

It has been obtained from cupcake-mk5-abs profile and added the followings changes:

* fill/

  Extra Shells on Alternating Solid Layer (layers):	1
  Extra Shells on Base (layers):	2
  Extra Shells on Sparse Layer (layers):	2


