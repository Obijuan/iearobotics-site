//-- U Piece
//-- This piece has no drills!
//
//-- (c) Juan Gonzalez-Gomez (Obijuan) Nov-2010
//-- GPL License

//---------------------------------------
//-- Parameters:
//--   l : Length
//--   w : width
//--   h : height
//--   thick
//---------------------------------------
module U_piece(l, w, h, thick, bottom_thick=3) {

  h2 = h + bottom_thick;
  l2 = l + 2*thick;

  translate([0,0,h/2])
  difference() {
    cube([w,l2,h2],center=true);
    translate ([0,0,bottom_thick]) cube([2*w,l,h2],center=true);
  }
}

//-- Example of use
U_piece(l=53, w=10, h=20, thick=3, bottom_thick=3);
