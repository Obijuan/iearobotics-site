//-- Mini-Skybot rear piece
//-- (c) Juan Gonzalez-Gomez (Obijuan) Nov-2010
//-- GPL License

use <futaba_U_union_2.scad>

//-- Render the piece
translate([0,-20,0])
rotate([0,0,90])
rotate([0,90,0])
  Futaba_U_union2(h=38);
