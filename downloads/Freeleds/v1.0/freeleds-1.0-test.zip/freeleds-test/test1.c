/*************************************************************************** */
/* test1.c                                                                   */
/*---------------------------------------------------------------------------*/
/* Ejemplo de pruebas de la Freeleds con la Skypic                           */
/* Conectar la Freeleds al PUERTO B de la Skypic                             */
/*---------------------------------------------------------------------------*/
/* Se saca un valor por el puerto B, y se muestra en la freeleds             */
/*---------------------------------------------------------------------------*/
/* (c) Juan Gonzalez 2009                                                    */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

#include <pic16f876a.h>

void main(void)
{
  //-- Configurar todos los bits del puerto B como salida
  TRISB=0x00;

  //-- Sacar un valor de 8 bits por el puerto
  PORTB = 0xAA;

  //-- Bucle infinito
  while(1);
}

