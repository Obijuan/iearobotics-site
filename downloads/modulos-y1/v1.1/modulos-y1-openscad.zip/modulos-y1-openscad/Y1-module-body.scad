use <part-B1.scad>
use <part-F.scad>
use <part-FE.scad>

//-- Y1 module. Body
module y1_module_body(M) {
  xF = B1_get_parameter("xF");
  xFE=B1_get_parameter("xFE");
  yg = FE_get_parameter("yg");
  xg = FE_get_parameter("xg");
  W=3;

  union() {
    part_B1();

    //-- Part F
    translate([xF+W/2,0,26+W/2])
    rotate(a=-90, v=[0,0,1]) 
    rotate(a=90, v=[1,0,0]) part_F();

    //-- Part FE
    translate ([-xFE-W/2,xg,yg+W/2])
    rotate([0,-90,0])
    rotate([0,0,-90])
    part_FE();
  };
}

W=3;

translate([0,0,W/2])
y1_module_body(W);


  
 

