use <part-B2.scad>
use <part-E.scad>
use <part-FE.scad>

//-- Y1 module. Head
module y1_module_head(M) {
  xE = B2_get_parameter("xE");
  xFE=B2_get_parameter("xFE");
  yge = E_get_parameter("yg");
  xge = E_get_parameter("xg");
  yg = FE_get_parameter("yg");
  xg = FE_get_parameter("xg");
  W=3;

  union() {
    part_B2();

    //-- Part E
    translate([xE+W/2,-xge,yge+W/2])
    rotate(a=90, v=[0,1,0]) 
    rotate(a=90, v=[0,0,1])
    part_E();

    //-- Part FE
    //translate ([-xFE-W/2,xg,yg+W/2])
    translate([-xFE+W/2,-xg,yg+W/2])
    rotate([0,90,0])
    rotate([0,0,90])
    part_FE();
  };
}

W=3;

translate([0,0,W/2])
y1_module_head(W);


  
 

