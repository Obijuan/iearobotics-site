
difference () {
cylinder(r=15, h=10, $fn=100);
cylinder(r=5, h=50, center=true, $fn=100);

rotate_extrude (a=[0,90,0]) translate (v= [10,10,0]) circle(r=2, $fn=100);

rotate_extrude (a=[0,90,0]) translate (v= [10,0,0]) circle(r=2, $fn=100);

}

