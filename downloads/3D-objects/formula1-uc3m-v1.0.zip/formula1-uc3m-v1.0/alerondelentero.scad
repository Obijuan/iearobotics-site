translate ([-25,0,0])
union (){
cube (size=[70,10,2]);
translate ([0,0,-2]) cube (size=[2,10,6]);
translate ([70,0,-2]) cube (size=[2,10,6]);
translate ([31,0,0]) cube (size=[10,6,6]);
}