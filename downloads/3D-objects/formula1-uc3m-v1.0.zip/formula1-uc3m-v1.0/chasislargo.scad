//Eje correcto
translate([40,0,0])
rotate (a=[0,-90,0])

union () {

difference () {

union(){

//Chasis
cylinder(r=28, h=80, $fn=100);

//Refrigeracion
translate ([10,-20,20]) cylinder(r1=7, r2=10,h=25, $fn=100);
translate ([10,20,20]) cylinder(r1=7, r2=10,h=25, $fn=100);
}

//Solo parte de arriba
translate ([-50,0, 0]) cube (size=[100, 100, 200], center=true);

//Transmision
translate ([8,8,8]) rotate (a=[90,0,0]) cylinder(r=5, h=100, center=true, $fn=100);
translate ([8,8,72]) rotate (a=[90,0,0]) cylinder(r=5, h=100, center=true, $fn=100);

//Copkit
translate ([15,0,51]) rotate (a=[0,90,0]) cylinder(r=15, h=40, $fn=100);
translate ([15,0,55]) rotate (a=[0,90,0]) cylinder(r=15, h=40, $fn=100);
translate ([15,0,59]) rotate (a=[0,90,0]) cylinder(r=15, h=40, $fn=100);
//translate ([18,0,72]) cube(size=[6,15,15], center=true);
}


//Toma de aire
translate ([29,0,0]) cylinder(r1=5, r2=10,h=30, $fn=100);

//Asiento
translate ([20,0, 37]) cube (size=[20, 15, 2], center=true);

}

