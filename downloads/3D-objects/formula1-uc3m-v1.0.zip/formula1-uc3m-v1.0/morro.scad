//Eje correcto
rotate (a=[0,-90,0])

difference () {

union(){

//Morro
cylinder(r1=28, r2=10,h=50, $fn=100);
translate ([0,0,50]) sphere(r=10, $fn=100);

}

//Solo parte de arriba
translate ([-50,0, 0]) cube (size=[100, 100, 200], center=true);
}
