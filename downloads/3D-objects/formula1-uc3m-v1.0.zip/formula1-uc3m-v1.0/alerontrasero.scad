translate ([-25,0,0])
union (){
cube (size=[70,10,2]);
translate ([0,0,-2]) cube (size=[2,10,6]);
translate ([70,0,-2]) cube (size=[2,10,6]);
translate ([25,0,-25]) cube (size=[2,10,25]);
translate ([45,0,-25]) cube (size=[2,10,25]);
translate ([25,10,-25]) cube (size=[22,2,10]);

}