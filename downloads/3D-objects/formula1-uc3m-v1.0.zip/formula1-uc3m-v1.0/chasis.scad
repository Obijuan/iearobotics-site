//Eje correcto
rotate (a=[0,-90,0])

union () {

difference () {

union(){

//Chasis
cylinder(r=28, h=50, $fn=100);
translate ([0,0,50]) cylinder(r1=28, r2=10,h=25, $fn=100);
translate ([0,0,74]) sphere(r=10, $fn=100);

//Refrigeracion
translate ([9,-28,16]) cylinder(r1=5, r2=9,h=22, $fn=100);
translate ([9,28,16]) cylinder(r1=5, r2=9,h=22, $fn=100);
}

//Solo parte de arriba
translate ([-50,0, 0]) cube (size=[100, 100, 200], center=true);

//Transmision
translate ([8,8,8]) rotate (a=[90,0,0]) cylinder(r=5, h=100, center=true, $fn=100);
translate ([8,8,45]) rotate (a=[90,0,0]) cylinder(r=5, h=100, center=true, $fn=100);

//Copkit
translate ([15,0,30]) rotate (a=[0,90,0]) cylinder(r=15, h=40, $fn=100);
translate ([15,0,34]) rotate (a=[0,90,0]) cylinder(r=15, h=40, $fn=100);
translate ([18,0,46]) cube(size=[6,15,15], center=true);
}

//Velocimetro y volante
translate ([28,1,47]) rotate (a=[0,0,0]) cylinder(r=3, h=2, $fn=100);
translate ([28,-1,47]) rotate (a=[0,0,0]) cylinder(r=3, h=2, $fn=100);
translate ([24,0,43]) rotate (a=[0,0,0]) cylinder(r=1, h=8, $fn=100);
translate ([24,0,43]) rotate (a=[0,0,0]) cylinder(r=4, h=2, $fn=100);

//Toma de aire
translate ([30,0,0]) cylinder(r1=5, r2=10,h=15, $fn=100);

}

