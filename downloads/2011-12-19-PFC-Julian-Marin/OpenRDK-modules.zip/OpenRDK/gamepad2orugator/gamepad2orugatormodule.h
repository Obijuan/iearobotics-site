#ifndef RDK_MODULE_GAMEPAD2ORUGATORMODULE
#define RDK_MODULE_GAMEPAD2ORUGATORMODULE

#include <rdkcore/modules/module.h>

namespace RDK2 { namespace RAgent {

#define EVENT_HANDLER_CLASS GamePad2OrugatorModule

class GamePad2OrugatorModule : public Module {
public:
	GamePad2OrugatorModule() { }
	virtual ~GamePad2OrugatorModule() { }

	bool initConfigurationProperties();
	// bool initInterfaceProperties();
	bool init();
	void exec();
	void modeControl1(void);
	void modeControl2(void);
	void modeControl3(void);
	int mode; // 1=mode1; 2=mode2; 3=mode3;
	// void exitRequested();
	// void cleanup();
	// void asyncAgentCmd(cstr cmd);
};

}} // namespace

#endif
