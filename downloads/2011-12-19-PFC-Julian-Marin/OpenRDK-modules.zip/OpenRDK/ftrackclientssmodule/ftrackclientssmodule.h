#ifndef RDK_MODULE_FTRACKCLIENTSSMODULE
#define RDK_MODULE_FTRACKCLIENTSSMODULE

#include <rdkcore/modules/module.h>
#include "skymegaclient.h"

namespace RDK2 { namespace RAgent {

#define EVENT_HANDLER_CLASS FTrackClientSSModule

class FTrackClientSSModule : public Module {
public:
	FTrackClientSSModule() { }
	virtual ~FTrackClientSSModule() { }

	bool initConfigurationProperties();
	// bool initInterfaceProperties();
	bool init();
	void exec();
	
	SkyMegaClient* ftrack;
	
	// void exitRequested();
	void cleanup();
	// void asyncAgentCmd(cstr cmd);
};

}} // namespace

#endif
