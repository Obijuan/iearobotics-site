#ifndef RDK_MODULE_GAMEPADREADERMODULE
#define RDK_MODULE_GAMEPADREADERMODULE

#include <rdkcore/modules/module.h>

#include "joystick.h"

namespace RDK2 { namespace RAgent {

#define EVENT_HANDLER_CLASS gamepadReaderModule

class gamepadReaderModule : public Module {
public:
	gamepadReaderModule() { }
	virtual ~gamepadReaderModule() { }

	bool initConfigurationProperties();
	// bool initInterfaceProperties();
	bool init();
	void exec();
	
	double normv(int, int, int, int, int);
	Joystick* gpad;
	
	// void exitRequested();
	void cleanup();
	// void asyncAgentCmd(cstr cmd);
};

}} // namespace

#endif
