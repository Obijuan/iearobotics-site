#ifndef RDK_MODULE_GAMEPAD2FTRACKMODULE
#define RDK_MODULE_GAMEPAD2FTRACKMODULE

#include <rdkcore/modules/module.h>

namespace RDK2 { namespace RAgent {

#define EVENT_HANDLER_CLASS GamePad2FTrackModule

class GamePad2FTrackModule : public Module {
public:
	GamePad2FTrackModule() { }
	virtual ~GamePad2FTrackModule() { }

	bool initConfigurationProperties();
	// bool initInterfaceProperties();
	bool init();
	void exec();
	void setDataServos(int pos[]);
	void modeControl1(int pos[]);
	void modeControl2(int pos[]);
	void modeControl3(int pos[]);
	void modeControl4(int pos[]);
	int mode; // 1=mode1; 2=mode2; 3=mode3; 4=mode4
	int position[4];
	// void exitRequested();
	// void cleanup();
	// void asyncAgentCmd(cstr cmd);
};

}} // namespace

#endif
