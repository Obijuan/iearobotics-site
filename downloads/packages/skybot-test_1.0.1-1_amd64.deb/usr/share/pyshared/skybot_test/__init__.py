#! /usr/bin/python
# -*- coding: iso-8859-15 -*-

#-- Skybot-test

""" 
  Pruebas de funcionamiento del robot Skybot


"""

#-- Version
VERSION = 1.0
