VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Acerca de MiApl"
   ClientHeight    =   2760
   ClientLeft      =   4590
   ClientTop       =   3915
   ClientWidth     =   5940
   ClipControls    =   0   'False
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1905.001
   ScaleMode       =   0  'User
   ScaleWidth      =   5577.967
   ShowInTaskbar   =   0   'False
   Begin VB.PictureBox picIcon 
      AutoSize        =   -1  'True
      ClipControls    =   0   'False
      Height          =   525
      Left            =   240
      ScaleHeight     =   326.585
      ScaleMode       =   0  'User
      ScaleWidth      =   389.795
      TabIndex        =   1
      Top             =   240
      Width           =   615
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "Aceptar"
      Default         =   -1  'True
      Height          =   345
      Left            =   4320
      TabIndex        =   0
      Top             =   2145
      Width           =   1500
   End
   Begin VB.Label Label1 
      Caption         =   "Este programa se distribuye bajo la Licencia GPL v2.0"
      Height          =   255
      Left            =   240
      TabIndex        =   6
      Top             =   2400
      Width           =   3855
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      BorderStyle     =   6  'Inside Solid
      Index           =   1
      X1              =   84.515
      X2              =   5309.398
      Y1              =   1356.278
      Y2              =   1356.278
   End
   Begin VB.Label lblDescription 
      Caption         =   $"frmAbout.frx":0000
      ForeColor       =   &H00000000&
      Height          =   570
      Left            =   1080
      TabIndex        =   2
      Top             =   1200
      Width           =   3885
   End
   Begin VB.Label lblTitle 
      Caption         =   "T�tulo de la aplicaci�n"
      ForeColor       =   &H00000000&
      Height          =   480
      Left            =   1050
      TabIndex        =   4
      Top             =   240
      Width           =   3885
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      BorderWidth     =   2
      Index           =   0
      X1              =   98.6
      X2              =   5309.398
      Y1              =   1366.631
      Y2              =   1366.631
   End
   Begin VB.Label lblVersion 
      Caption         =   "Versi�n"
      Height          =   225
      Left            =   1050
      TabIndex        =   5
      Top             =   780
      Width           =   3885
   End
   Begin VB.Label lblDisclaimer 
      Caption         =   "Licencia:"
      ForeColor       =   &H00000000&
      Height          =   225
      Left            =   240
      TabIndex        =   3
      Top             =   2145
      Width           =   1215
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdOK_Click()
  Unload Me
End Sub

Private Sub Form_Load()
    Me.Caption = "Acerca de " & App.Title
    lblVersion.Caption = "Versi�n " & App.Major & "." & App.Minor & "." & App.Revision
    lblTitle.Caption = App.Title
    frmprincipal.Enabled = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmprincipal.Enabled = True
End Sub
