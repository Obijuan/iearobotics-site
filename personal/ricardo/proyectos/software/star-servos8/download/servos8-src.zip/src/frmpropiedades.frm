VERSION 5.00
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form frmpropiedades 
   Caption         =   "Propiedades"
   ClientHeight    =   4185
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5850
   LinkTopic       =   "Form1"
   ScaleHeight     =   4185
   ScaleWidth      =   5850
   StartUpPosition =   3  'Windows Default
   Begin TabDlg.SSTab SSTab1 
      Height          =   3975
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   5655
      _ExtentX        =   9975
      _ExtentY        =   7011
      _Version        =   393216
      Tabs            =   2
      TabHeight       =   520
      TabCaption(0)   =   "Puerto Serie"
      TabPicture(0)   =   "frmpropiedades.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Label1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).Control(1)=   "cmdCancel"
      Tab(0).Control(1).Enabled=   0   'False
      Tab(0).Control(2)=   "Frame1"
      Tab(0).Control(2).Enabled=   0   'False
      Tab(0).Control(3)=   "fraConnection"
      Tab(0).Control(3).Enabled=   0   'False
      Tab(0).Control(4)=   "cboPuerto"
      Tab(0).Control(4).Enabled=   0   'False
      Tab(0).Control(5)=   "cmdOK"
      Tab(0).Control(5).Enabled=   0   'False
      Tab(0).Control(6)=   "Frame7"
      Tab(0).Control(6).Enabled=   0   'False
      Tab(0).Control(7)=   "Frame5"
      Tab(0).Control(7).Enabled=   0   'False
      Tab(0).ControlCount=   8
      TabCaption(1)   =   "Hardware"
      TabPicture(1)   =   "frmpropiedades.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).ControlCount=   0
      Begin VB.Frame Frame5 
         Caption         =   "&Control de Flujo"
         Height          =   1770
         Left            =   2655
         TabIndex        =   16
         Top             =   2085
         Width           =   1620
         Begin VB.OptionButton optFlow 
            Caption         =   "Xon/RTS"
            Height          =   255
            Index           =   3
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   20
            Top             =   1245
            Width           =   1155
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "RTS"
            Height          =   255
            Index           =   2
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   19
            Top             =   945
            Width           =   735
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "Xon/Xoff"
            Height          =   255
            Index           =   1
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   18
            Top             =   645
            Width           =   1095
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "None"
            Height          =   255
            Index           =   0
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   17
            Top             =   345
            Width           =   855
         End
      End
      Begin VB.Frame Frame7 
         Caption         =   "&Echo"
         Height          =   870
         Left            =   2655
         TabIndex        =   13
         Top             =   1080
         Width           =   1590
         Begin VB.OptionButton optEcho 
            Caption         =   "On"
            Height          =   195
            Index           =   1
            Left            =   795
            MaskColor       =   &H00000000&
            TabIndex        =   15
            Top             =   420
            Width           =   555
         End
         Begin VB.OptionButton optEcho 
            Caption         =   "Off"
            Height          =   315
            Index           =   0
            Left            =   135
            MaskColor       =   &H00000000&
            TabIndex        =   14
            Top             =   360
            Width           =   615
         End
      End
      Begin VB.CommandButton cmdOK 
         Caption         =   "OK"
         Default         =   -1  'True
         Height          =   300
         Left            =   4395
         MaskColor       =   &H00000000&
         TabIndex        =   12
         Top             =   1155
         Width           =   1080
      End
      Begin VB.ComboBox cboPuerto 
         Height          =   315
         Left            =   960
         Style           =   2  'Dropdown List
         TabIndex        =   11
         Top             =   600
         Width           =   1425
      End
      Begin VB.Frame fraConnection 
         Caption         =   "Preferencias de conexi�n"
         Height          =   1770
         Left            =   240
         TabIndex        =   4
         Top             =   2085
         Width           =   2325
         Begin VB.ComboBox cboBitsDatos 
            Height          =   315
            Left            =   1050
            Style           =   2  'Dropdown List
            TabIndex        =   7
            Top             =   330
            Width           =   1140
         End
         Begin VB.ComboBox cboParidad 
            Height          =   315
            Left            =   1050
            Style           =   2  'Dropdown List
            TabIndex        =   6
            Top             =   810
            Width           =   1140
         End
         Begin VB.ComboBox cboStopBits 
            Height          =   315
            Left            =   1050
            Style           =   2  'Dropdown List
            TabIndex        =   5
            Top             =   1260
            Width           =   1140
         End
         Begin VB.Label Label3 
            Caption         =   "Data Bits:"
            Height          =   285
            Left            =   180
            TabIndex        =   10
            Top             =   375
            Width           =   825
         End
         Begin VB.Label Label4 
            Caption         =   "Parity:"
            Height          =   285
            Left            =   180
            TabIndex        =   9
            Top             =   855
            Width           =   615
         End
         Begin VB.Label Label5 
            Caption         =   "Stop Bits:"
            Height          =   285
            Left            =   180
            TabIndex        =   8
            Top             =   1320
            Width           =   885
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "Velocidad M�xima"
         Height          =   870
         Left            =   240
         TabIndex        =   2
         Top             =   1080
         Width           =   2340
         Begin VB.ComboBox cboVelocidad 
            Height          =   315
            Left            =   375
            Style           =   2  'Dropdown List
            TabIndex        =   3
            Top             =   330
            Width           =   1695
         End
      End
      Begin VB.CommandButton cmdCancel 
         Caption         =   "Cancelar"
         Height          =   300
         Left            =   4395
         TabIndex        =   1
         Top             =   1515
         Width           =   1080
      End
      Begin VB.Label Label1 
         Caption         =   "Puerto:"
         Height          =   315
         Left            =   390
         TabIndex        =   21
         Top             =   630
         Width           =   495
      End
   End
End
Attribute VB_Name = "frmpropiedades"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
