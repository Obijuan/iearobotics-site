VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form frmprincipal 
   Caption         =   "Form1"
   ClientHeight    =   4125
   ClientLeft      =   4800
   ClientTop       =   3465
   ClientWidth     =   5370
   LinkTopic       =   "Form1"
   ScaleHeight     =   4125
   ScaleWidth      =   5370
   Begin VB.Timer Timer 
      Interval        =   1000
      Left            =   120
      Top             =   0
   End
   Begin MSCommLib.MSComm MSComm 
      Left            =   4680
      Top             =   3480
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   7
      Left            =   4560
      TabIndex        =   24
      Text            =   "0"
      Top             =   3120
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   6
      Left            =   4560
      TabIndex        =   23
      Text            =   "0"
      Top             =   2760
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   5
      Left            =   4560
      TabIndex        =   22
      Text            =   "0"
      Top             =   2400
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   4
      Left            =   4560
      TabIndex        =   21
      Text            =   "0"
      Top             =   2040
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   3
      Left            =   4560
      TabIndex        =   20
      Text            =   "0"
      Top             =   1680
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   2
      Left            =   4560
      TabIndex        =   19
      Text            =   "0"
      Top             =   1320
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   1
      Left            =   4560
      TabIndex        =   18
      Text            =   "0"
      Top             =   960
      Width           =   615
   End
   Begin VB.TextBox Text1 
      Alignment       =   1  'Right Justify
      Height          =   285
      Index           =   0
      Left            =   4560
      TabIndex        =   17
      Text            =   "0"
      Top             =   600
      Width           =   615
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 8"
      Height          =   255
      Index           =   7
      Left            =   120
      TabIndex        =   15
      Top             =   3120
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 7"
      Height          =   255
      Index           =   6
      Left            =   120
      TabIndex        =   14
      Top             =   2760
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 6"
      Height          =   255
      Index           =   5
      Left            =   120
      TabIndex        =   13
      Top             =   2400
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 5"
      Height          =   255
      Index           =   4
      Left            =   120
      TabIndex        =   12
      Top             =   2040
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 4"
      Height          =   255
      Index           =   3
      Left            =   120
      TabIndex        =   11
      Top             =   1680
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 3"
      Height          =   255
      Index           =   2
      Left            =   120
      TabIndex        =   10
      Top             =   1320
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 2"
      Height          =   255
      Index           =   1
      Left            =   120
      TabIndex        =   9
      Top             =   960
      Width           =   975
   End
   Begin VB.CheckBox Check1 
      Caption         =   "Servo 1"
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   8
      Top             =   600
      Width           =   975
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   7
      Left            =   1200
      Max             =   232
      TabIndex        =   7
      Top             =   3120
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   6
      Left            =   1200
      Max             =   232
      TabIndex        =   6
      Top             =   2760
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   5
      Left            =   1200
      Max             =   232
      TabIndex        =   5
      Top             =   2400
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   4
      Left            =   1200
      Max             =   240
      TabIndex        =   4
      Top             =   2040
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   3
      Left            =   1200
      Max             =   232
      TabIndex        =   3
      Top             =   1680
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   2
      Left            =   1200
      Max             =   232
      TabIndex        =   2
      Top             =   1320
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   1
      Left            =   1200
      Max             =   232
      TabIndex        =   1
      Top             =   960
      Width           =   3135
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Index           =   0
      Left            =   1200
      Max             =   240
      TabIndex        =   0
      Top             =   600
      Width           =   3135
   End
   Begin ComctlLib.StatusBar StatusBar 
      Align           =   2  'Align Bottom
      Height          =   315
      Left            =   0
      TabIndex        =   26
      Top             =   3810
      Width           =   5370
      _ExtentX        =   9472
      _ExtentY        =   556
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   3
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   2
            Text            =   "Status:"
            TextSave        =   "Status:"
            Key             =   "Status"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Communications Port Status"
         EndProperty
         BeginProperty Panel2 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   1
            Object.Width           =   5161
            MinWidth        =   2
            Text            =   "Settings:"
            TextSave        =   "Settings:"
            Key             =   "Settings"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Communications Port Settings"
         EndProperty
         BeginProperty Panel3 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   2
            Object.Width           =   1244
            MinWidth        =   1244
            Key             =   "ConnectTime"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Connect Time"
         EndProperty
      EndProperty
   End
   Begin VB.Label Label2 
      Caption         =   "ACK"
      Height          =   255
      Left            =   4560
      TabIndex        =   25
      Top             =   120
      Width           =   375
   End
   Begin VB.Shape Shape 
      BackColor       =   &H0080FF80&
      FillColor       =   &H0080FF80&
      FillStyle       =   0  'Solid
      Height          =   195
      Left            =   4080
      Shape           =   3  'Circle
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Control 8 servos"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   16
      Top             =   0
      Width           =   3735
   End
   Begin VB.Menu archivo 
      Caption         =   "&Archivo"
      Begin VB.Menu mnuabrir 
         Caption         =   "Abrir puerto"
      End
      Begin VB.Menu espacio01 
         Caption         =   "-"
      End
      Begin VB.Menu mnusalir 
         Caption         =   "&Salir"
      End
   End
   Begin VB.Menu mnuconf 
      Caption         =   "&Configuracion"
      Begin VB.Menu mnupropiedades 
         Caption         =   "&Propiedades COM"
      End
      Begin VB.Menu mnuservo 
         Caption         =   "Tipo &servo"
      End
   End
   Begin VB.Menu ayuda 
      Caption         =   "Ay&uda"
      Begin VB.Menu mnucontenido 
         Caption         =   "&Contenido"
      End
      Begin VB.Menu mnuacerca 
         Caption         =   "&Acerca de picserie..."
      End
   End
End
Attribute VB_Name = "frmprincipal"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Check1_Click(Index As Integer)
Dim i As Integer
Dim mascara As Byte
    mascara = 0
    For i = 7 To 0 Step -1
        'rotacion mascara
        mascara = mascara * (2 ^ 1)
        If Check1(i) Then
            mascara = mascara + 1
            HScroll1(i).Enabled = True
            Text1(i).Enabled = True
        Else
            HScroll1(i).Enabled = False
            HScroll1(i).Value = 0
            Text1(i).Text = 0
            Text1(i).Enabled = False
        End If
    Next i
If MSComm.PortOpen Then
    MSComm.Output = Chr(&H45)
    MSComm.Output = Chr(mascara)
End If
End Sub

Private Sub Form_Load()
Dim CommPort As String
Dim Handshaking As String
Dim Settings As String
Dim i As Byte
Dim sSeccion As String
Dim sClave As String
Dim sValor As String


'On Error Resume Next

For i = 0 To 7
    HScroll1(i).Enabled = False
    Check1(i).Enabled = False
    Text1(i).Enabled = False
Next i

'T�tulo de la aplicacion
App.Title = "Servos8"

'Fichero ini con las configuraciones
fichini = Trim(App.Path + "\servos8.ini")

'Carga configuracion fichero ini
sSeccion = "hardware"
sClave = "max"
sValor = IniGet(fichini, sSeccion, sClave)
For i = 0 To 7
    Me.HScroll1(i).Max = sValor
Next i

'Carga configuracion registro
'Settings = GetSetting(App.Title, "Propiedades", "Settings", "")
Settings = ""
'If Settings <> "" Then
'    MSComm.Settings = Settings
'    If Err Then
'        MsgBox Error$, 48
'        Exit Sub
'    End If
'End If
'CommPort = GetSetting(App.Title, "Propiedades", "CommPort", "")
CommPort = ""
'If CommPort <> "" Then MSComm.CommPort = CommPort
    
'Handshaking = GetSetting(App.Title, "Propiedades", "Handshaking", "")
Handshaking = ""
'If Handshaking <> "" Then
'    MSComm.Handshaking = Handshaking
'    If Err Then
'        MsgBox Error$, 48
'        Exit Sub
'    End If
'End If
    
'Echo = GetSetting(App.Title, "Properties", "Echo", "")
Shape.Visible = True
Label2.Visible = True
'On Error GoTo 0

End Sub

Private Sub Form_Unload(Cancel As Integer)
If MSComm.PortOpen Then
    MSComm.PortOpen = 0
End If
'SaveSetting App.Title, "Propiedades", "Principal_Width", principal.CurrentX
'SaveSetting App.Title, "Propiedades", "Principal_Height", (Screen.Height - Height) / 2
End Sub

Private Sub HScroll1_Change(Index As Integer)
If MSComm.PortOpen Then
    Text1(Index) = HScroll1(Index).Value
    MSComm.Output = Chr(&H57) 'mover servo
    MSComm.Output = Chr(Index + 1) 'numero de servo
    MSComm.Output = Chr(HScroll1(Index).Value) 'posicion
Else
    HScroll1(Index).Value = 0
    Text1(Index) = 0
End If
End Sub

Private Sub mnuabrir_Click()
On Error Resume Next
Dim OpenFlag
Dim i As Byte

MSComm.PortOpen = Not MSComm.PortOpen
If Err Then MsgBox Error$, 48
    
OpenFlag = MSComm.PortOpen
    
mnuabrir.Checked = OpenFlag
        

If MSComm.PortOpen Then
    Shape.Visible = True
    Shape.FillColor = vbGreen
    Label2.Visible = True
    StatusBar.Panels("Settings").Text = "Settings: " & MSComm.Settings
    For i = 0 To 7
        Check1(i).Enabled = True
        HScroll1(i).Enabled = True
        HScroll1(i).Value = 0
        Text1(i).Enabled = True
        Text1(i).Text = 0
    Next i
    MSComm.DTREnable = False
Else
    Shape.FillColor = vbRed
    For i = 0 To 7
        HScroll1(i).Enabled = False
        Check1(i).Enabled = False
        Text1(i).Enabled = False
    Next i
    StatusBar.Panels("Settings").Text = "Settings: "
End If
End Sub

Private Sub mnuacerca_Click()
frmAbout.Show
End Sub

Private Sub mnucontenido_Click()
Dim res As VbMsgBoxResult
Dim info As String

info = "Lo sentimos, la ayuda no esta disponible en esta version."

res = MsgBox(info, vbInformation, "Mensaje")

End Sub

Private Sub mnupropiedades_Click()
frmProps.Show
End Sub

Private Sub mnusalir_Click()
Unload Me
End Sub

Private Sub mnuservo_Click()
frmhardware.Show
End Sub

Private Sub Timer_Timer()
Dim buffer As Variant
If MSComm.PortOpen Then
    MSComm.Output = Chr(&H50)
    buffer = MSComm.Input
    If buffer = Chr(&H4F) Then
        Shape.FillColor = vbGreen
    Else
        Shape.FillColor = vbRed
    End If
Else
    Shape.FillColor = vbRed
End If
End Sub
