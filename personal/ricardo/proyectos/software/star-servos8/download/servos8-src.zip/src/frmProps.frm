VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmProps 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Propiedades del Puerto Serie"
   ClientHeight    =   4260
   ClientLeft      =   4410
   ClientTop       =   3345
   ClientWidth     =   6135
   Icon            =   "frmProps.frx":0000
   LinkTopic       =   "Form3"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4260
   ScaleWidth      =   6135
   ShowInTaskbar   =   0   'False
   Begin VB.Frame fraSettings 
      BorderStyle     =   0  'None
      Height          =   3495
      Left            =   240
      TabIndex        =   1
      Top             =   570
      Width           =   5565
      Begin VB.CommandButton cmdCancel 
         Caption         =   "Cancelar"
         Height          =   300
         Left            =   4455
         TabIndex        =   22
         Top             =   1065
         Width           =   1080
      End
      Begin VB.Frame Frame1 
         Caption         =   "Velocidad m�xima"
         Height          =   870
         Left            =   180
         TabIndex        =   20
         Top             =   630
         Width           =   2565
         Begin VB.ComboBox cboSpeed 
            Height          =   315
            Left            =   375
            Style           =   2  'Dropdown List
            TabIndex        =   21
            Top             =   330
            Width           =   1695
         End
      End
      Begin VB.Frame fraConnection 
         Caption         =   "Preferencias de la conexi�n"
         Height          =   1770
         Left            =   180
         TabIndex        =   12
         Top             =   1635
         Width           =   2565
         Begin VB.ComboBox cboStopBits 
            Height          =   315
            Left            =   1305
            Style           =   2  'Dropdown List
            TabIndex        =   16
            Top             =   1260
            Width           =   1140
         End
         Begin VB.ComboBox cboParity 
            Height          =   315
            Left            =   1305
            Style           =   2  'Dropdown List
            TabIndex        =   15
            Top             =   810
            Width           =   1140
         End
         Begin VB.ComboBox cboDataBits 
            Height          =   315
            Left            =   1305
            Style           =   2  'Dropdown List
            TabIndex        =   14
            Top             =   330
            Width           =   1140
         End
         Begin VB.Label Label5 
            Caption         =   "Bits de parada:"
            Height          =   285
            Left            =   180
            TabIndex        =   19
            Top             =   1320
            Width           =   1155
         End
         Begin VB.Label Label4 
            Caption         =   "Paridad:"
            Height          =   285
            Left            =   180
            TabIndex        =   18
            Top             =   855
            Width           =   615
         End
         Begin VB.Label Label3 
            Caption         =   "Bits de datos:"
            Height          =   285
            Left            =   180
            TabIndex        =   17
            Top             =   375
            Width           =   1170
         End
      End
      Begin VB.ComboBox cboPort 
         Height          =   315
         Left            =   900
         Style           =   2  'Dropdown List
         TabIndex        =   11
         Top             =   150
         Width           =   1425
      End
      Begin VB.CommandButton cmdOK 
         Caption         =   "Aceptar"
         Default         =   -1  'True
         Height          =   300
         Left            =   4455
         MaskColor       =   &H00000000&
         TabIndex        =   10
         Top             =   705
         Width           =   1080
      End
      Begin VB.Frame Frame7 
         Caption         =   "&Eco"
         Height          =   870
         Left            =   2835
         TabIndex        =   7
         Top             =   630
         Width           =   1530
         Begin VB.OptionButton optEcho 
            Caption         =   "Desactivado"
            Height          =   255
            Index           =   0
            Left            =   120
            MaskColor       =   &H00000000&
            TabIndex        =   9
            Top             =   300
            Width           =   1320
         End
         Begin VB.OptionButton optEcho 
            Caption         =   "Activado"
            Height          =   195
            Index           =   1
            Left            =   135
            MaskColor       =   &H00000000&
            TabIndex        =   8
            Top             =   585
            Width           =   1155
         End
      End
      Begin VB.Frame Frame5 
         Caption         =   "Control de &flujo"
         Height          =   1770
         Left            =   2835
         TabIndex        =   2
         Top             =   1635
         Width           =   1530
         Begin VB.OptionButton optFlow 
            Caption         =   "Ninguno"
            Height          =   255
            Index           =   0
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   6
            Top             =   345
            Width           =   1035
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "Xon/Xoff"
            Height          =   255
            Index           =   1
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   5
            Top             =   645
            Width           =   1035
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "RTS"
            Height          =   255
            Index           =   2
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   4
            Top             =   945
            Width           =   735
         End
         Begin VB.OptionButton optFlow 
            Caption         =   "Xon/RTS"
            Height          =   255
            Index           =   3
            Left            =   180
            MaskColor       =   &H00000000&
            TabIndex        =   3
            Top             =   1245
            Width           =   1050
         End
      End
      Begin VB.Label Label1 
         Caption         =   "Puerto:"
         Height          =   315
         Left            =   330
         TabIndex        =   13
         Top             =   180
         Width           =   495
      End
   End
   Begin MSComctlLib.TabStrip tabSettings 
      Height          =   4065
      Left            =   90
      TabIndex        =   0
      Top             =   105
      Width           =   5925
      _ExtentX        =   10451
      _ExtentY        =   7170
      _Version        =   393216
      BeginProperty Tabs {1EFB6598-857C-11D1-B16A-00C0F0283628} 
         NumTabs         =   1
         BeginProperty Tab1 {1EFB659A-857C-11D1-B16A-00C0F0283628} 
            Caption         =   "Propiedades"
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmProps"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private iFlow As Integer, iTempEcho As Boolean


Sub LoadPropertySettings()
Dim i As Integer, Settings As String, Offset As Integer

' Carga las configuraciones de puerto
For i = 1 To 16
    cboPort.AddItem "Com" & Trim$(Str$(i))
Next i

' Carga las configuraciones de velocidad
cboSpeed.AddItem "110"
cboSpeed.AddItem "300"
cboSpeed.AddItem "600"
cboSpeed.AddItem "1200"
cboSpeed.AddItem "2400"
cboSpeed.AddItem "4800"
cboSpeed.AddItem "9600"
cboSpeed.AddItem "14400"
cboSpeed.AddItem "19200"
cboSpeed.AddItem "28800"
cboSpeed.AddItem "38400"
cboSpeed.AddItem "56000"
cboSpeed.AddItem "57600"
cboSpeed.AddItem "115200"
cboSpeed.AddItem "128000"
cboSpeed.AddItem "256000"

' Carga las configuraciones de bits de datos
cboDataBits.AddItem "4"
cboDataBits.AddItem "5"
cboDataBits.AddItem "6"
cboDataBits.AddItem "7"
cboDataBits.AddItem "8"

' Carga las configuraciones de paridad
cboParity.AddItem "Even"
cboParity.AddItem "Odd"
cboParity.AddItem "None"
cboParity.AddItem "Mark"
cboParity.AddItem "Space"

' Carga las configuraciones de bits de parada
cboStopBits.AddItem "1"
cboStopBits.AddItem "1.5"
cboStopBits.AddItem "2"

' Establece la configuraci�n predeterminada

Settings = frmprincipal.MSComm.Settings

' En todos los casos, el componente m�s a la derecha de Settings
' ser� un solo car�cter, excepto cuando haya 1,5 bits de parada.
If InStr(Settings, ".") > 0 Then
    Offset = 2
Else
    Offset = 0
End If

cboSpeed.Text = Left$(Settings, Len(Settings) - 6 - Offset)
Select Case Mid$(Settings, Len(Settings) - 4 - Offset, 1)
Case "e"
    cboParity.ListIndex = 0
Case "m"
    cboParity.ListIndex = 1
Case "n"
    cboParity.ListIndex = 2
Case "o"
    cboParity.ListIndex = 3
Case "s"
    cboParity.ListIndex = 4
End Select

cboDataBits.Text = Mid$(Settings, Len(Settings) - 2 - Offset, 1)
cboStopBits.Text = Right$(Settings, 1 + Offset)
    
cboPort.ListIndex = frmprincipal.MSComm.CommPort - 1

optFlow(frmprincipal.MSComm.Handshaking).Value = True
If Echo Then
    optEcho(1).Value = True
Else
    optEcho(0).Value = True
End If

End Sub


Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdOK_Click()
Dim OldPort As Integer
Dim ReOpen As Boolean
Dim sSeccion As String
Dim sClave As String
Dim sValor As String

On Error Resume Next

sSeccion = "serie"  'Seccion del fichero ini

Echo = iTempEcho
OldPort = frmprincipal.MSComm.PortOpen
NewPort = cboPort.ListIndex + 1

If NewPort <> OldPort Then    ' Si cambia el n�mero de puerto, cierra el antiguo.
    If frmprincipal.MSComm.PortOpen Then
           frmprincipal.MSComm.PortOpen = False
           ReOpen = True
    End If

    frmprincipal.MSComm.CommPort = NewPort     ' Establece el nuevo n�mero de puerto.
    
    If Err = 0 Then
        If ReOpen Then
            frmprincipal.MSComm.PortOpen = True
            'frmprincipal.mnuOpen.Checked = frmTerminal.MSComm1.PortOpen
            'frmTerminal.mnuSendText.Enabled = frmTerminal.MSComm1.PortOpen
            'frmprincipal.tbrToolBar.Buttons("TransmitTextFile").Enabled = frmTerminal.MSComm1.PortOpen
        End If
    End If
        
    If Err Then
        MsgBox Error$, 48
        frmprincipal.MSComm.CommPort = OldPort
        Exit Sub
    End If
End If


frmprincipal.MSComm.Settings = Trim$(cboSpeed.Text) & "," & Left$(cboParity.Text, 1) _
    & "," & Trim$(cboDataBits.Text) & "," & Trim$(cboStopBits.Text)

If Err Then
    MsgBox Error$, 48
    Exit Sub
End If

frmprincipal.MSComm.Handshaking = iFlow
If Err Then
    MsgBox Error$, 48
    Exit Sub
End If

'Guardamos la configuracion en el fichero ini
sClave = "settings"
sValor = Trim$(frmprincipal.MSComm.Settings)
IniWrite fichini, sSeccion, sClave, sValor
sClave = "commport"
sValor = Trim$(frmprincipal.MSComm.CommPort)
IniWrite fichini, sSeccion, sClave, sValor
sClave = "handshaking"
sValor = Trim$(frmprincipal.MSComm.Handshaking)
IniWrite fichini, sSeccion, sClave, sValor
sClave = "echo"
sValor = Trim$(Echo)
IniWrite fichini, sSeccion, sClave, sValor


Unload Me

End Sub

Private Sub Form_Load()
frmprincipal.Enabled = False
' Establece el tama�o del formulario
Me.Left = (Screen.Width - Me.Width) / 2
Me.Top = (Screen.Height - Me.Height) / 2

' Ajusta el tama�o del marco al control tabstrip
fraSettings.Move tabSettings.ClientLeft, tabSettings.ClientTop

' Se asegura de que el marco sea el control situado encima
fraSettings.ZOrder

' Carga la configuraci�n actual de las propiedades
LoadPropertySettings

End Sub

Private Sub Form_Unload(Cancel As Integer)
frmprincipal.Enabled = True
End Sub

Private Sub optEcho_Click(Index As Integer)
If Index = 1 Then
    iTempEcho = True
Else
    iTempEcho = False
End If
End Sub

Private Sub optFlow_Click(Index As Integer)
iFlow = Index
End Sub


