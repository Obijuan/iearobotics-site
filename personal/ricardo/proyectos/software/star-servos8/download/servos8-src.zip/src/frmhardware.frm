VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Begin VB.Form frmhardware 
   Caption         =   "hardware"
   ClientHeight    =   3195
   ClientLeft      =   5175
   ClientTop       =   4305
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   Begin VB.Frame Frame1 
      Caption         =   "Tipo servo"
      Height          =   1215
      Left            =   360
      TabIndex        =   1
      Top             =   960
      Width           =   1095
      Begin VB.OptionButton Option 
         Caption         =   "Futaba"
         Height          =   375
         Index           =   1
         Left            =   120
         TabIndex        =   3
         Top             =   720
         Width           =   855
      End
      Begin VB.OptionButton Option 
         Caption         =   "Hitec"
         Height          =   255
         Index           =   0
         Left            =   120
         TabIndex        =   2
         Top             =   360
         Width           =   855
      End
   End
   Begin ComctlLib.TabStrip TabStrip1 
      Height          =   3015
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4455
      _ExtentX        =   7858
      _ExtentY        =   5318
      _Version        =   327682
      BeginProperty Tabs {0713E432-850A-101B-AFC0-4210102A8DA7} 
         NumTabs         =   1
         BeginProperty Tab1 {0713F341-850A-101B-AFC0-4210102A8DA7} 
            Caption         =   "Hardware"
            Object.Tag             =   ""
            ImageVarType    =   2
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmhardware"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Form_Load()
    frmprincipal.Enabled = False
    
    ' Leer del fichero INI
    Dim sSeccion As String
    Dim sClave As String
    Dim sValor As String
    Dim i As Integer
        
    sSeccion = "hardware"   'Seccion del fichero ini
    sClave = "servo"        'Clave a buscar
        
    sValor = IniGet(fichini, sSeccion, sClave, sValor)
    If sValor = 0 Then
        Me.Option(0).Value = True
    Else
        Me.Option(1).Value = True
    End If
    
    sClave = "max"          'Clave a buscar
    
    sValor = IniGet(fichini, sSeccion, sClave)
    For i = 0 To 7
        frmprincipal.HScroll1(i).Max = sValor
    Next i
        
End Sub

Private Sub Form_Unload(Cancel As Integer)
    frmprincipal.Enabled = True
End Sub

Private Sub Option_Click(Index As Integer)
Dim i As Integer

    ' A�adir la secci�n, clave y/o valor
    Dim sSeccion As String
    Dim sClave As String
    Dim sValor As String
    
    sSeccion = "hardware"
    
If Index = 0 Then
    For i = 0 To 7
        frmprincipal.HScroll1(i).Max = 240
    Next i
    sClave = "servo"
    sValor = Index
    IniWrite fichini, sSeccion, sClave, sValor
    sClave = "max"
    sValor = 240
    IniWrite fichini, sSeccion, sClave, sValor
Else
    For i = 0 To 7
        frmprincipal.HScroll1(i).Max = 232
    Next i
    sClave = "servo"
    sValor = Index
    IniWrite fichini, sSeccion, sClave, sValor
    sClave = "max"
    sValor = 232
    IniWrite fichini, sSeccion, sClave, sValor
End If
End Sub
