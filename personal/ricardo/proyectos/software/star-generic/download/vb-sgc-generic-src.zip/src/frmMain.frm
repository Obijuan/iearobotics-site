VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "COMCTL32.OCX"
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "g-gsc-generic"
   ClientHeight    =   1980
   ClientLeft      =   2925
   ClientTop       =   2040
   ClientWidth     =   5145
   ForeColor       =   &H00000000&
   Icon            =   "frmMain.frx":0000
   LinkMode        =   1  'Source
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   1980
   ScaleWidth      =   5145
   Begin VB.Frame Frame1 
      Caption         =   "Estado"
      Height          =   735
      Left            =   240
      TabIndex        =   5
      Top             =   720
      Width           =   4455
      Begin VB.TextBox Text1 
         Height          =   285
         Left            =   120
         TabIndex        =   6
         Top             =   240
         Width           =   3615
      End
      Begin VB.Image Image1 
         Height          =   495
         Left            =   3840
         Top             =   165
         Width           =   495
      End
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   1080
      TabIndex        =   4
      Top             =   210
      Width           =   855
   End
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   2520
      TabIndex        =   3
      Top             =   210
      Width           =   615
   End
   Begin VB.CommandButton Command 
      Caption         =   "Load"
      Height          =   255
      Index           =   0
      Left            =   3240
      TabIndex        =   2
      Top             =   240
      Width           =   735
   End
   Begin VB.CommandButton Command 
      Caption         =   "Store"
      Height          =   255
      Index           =   1
      Left            =   3960
      TabIndex        =   1
      Top             =   240
      Width           =   735
   End
   Begin MSCommLib.MSComm MSComm1 
      Left            =   4440
      Top             =   960
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
      NullDiscard     =   -1  'True
      RThreshold      =   1
      RTSEnable       =   -1  'True
      SThreshold      =   1
      InputMode       =   1
   End
   Begin ComctlLib.StatusBar sbrStatus 
      Align           =   2  'Align Bottom
      Height          =   315
      Left            =   0
      TabIndex        =   0
      Top             =   1665
      Width           =   5145
      _ExtentX        =   9075
      _ExtentY        =   556
      SimpleText      =   ""
      _Version        =   327682
      BeginProperty Panels {0713E89E-850A-101B-AFC0-4210102A8DA7} 
         NumPanels       =   3
         BeginProperty Panel1 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   2
            Text            =   "Status:"
            TextSave        =   "Status:"
            Key             =   "Status"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Communications Port Status"
         EndProperty
         BeginProperty Panel2 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   1
            Object.Width           =   5214
            MinWidth        =   2
            Text            =   "Settings:"
            TextSave        =   "Settings:"
            Key             =   "Settings"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Communications Port Settings"
         EndProperty
         BeginProperty Panel3 {0713E89F-850A-101B-AFC0-4210102A8DA7} 
            AutoSize        =   2
            Object.Width           =   1244
            MinWidth        =   1244
            Key             =   "ConnectTime"
            Object.Tag             =   ""
            Object.ToolTipText     =   "Connect Time"
         EndProperty
      EndProperty
   End
   Begin VB.Timer Timer2 
      Enabled         =   0   'False
      Interval        =   500
      Left            =   4560
      Top             =   480
   End
   Begin VB.Timer Timer1 
      Interval        =   1000
      Left            =   4560
      Top             =   0
   End
   Begin VB.Label Label2 
      Caption         =   "Valor"
      Height          =   255
      Left            =   2040
      TabIndex        =   8
      Top             =   240
      Width           =   495
   End
   Begin VB.Line Line1 
      X1              =   120
      X2              =   4800
      Y1              =   120
      Y2              =   120
   End
   Begin VB.Line Line2 
      X1              =   4800
      X2              =   4800
      Y1              =   600
      Y2              =   120
   End
   Begin VB.Line Line3 
      X1              =   120
      X2              =   120
      Y1              =   600
      Y2              =   120
   End
   Begin VB.Line Line4 
      X1              =   4800
      X2              =   120
      Y1              =   600
      Y2              =   600
   End
   Begin VB.Label Label1 
      Caption         =   "Direcci�n"
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   240
      Width           =   735
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuPort 
      Caption         =   "&CommPort"
      Begin VB.Menu mnuOpen 
         Caption         =   "Port &Open"
      End
      Begin VB.Menu mnureset 
         Caption         =   "&Reset"
      End
      Begin VB.Menu MBar1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuProperties 
         Caption         =   "Properties..."
      End
   End
   Begin VB.Menu mnuayuda 
      Caption         =   "A&yuda"
      Begin VB.Menu mnuabout 
         Caption         =   "&Acerca de..."
      End
   End
   Begin VB.Menu mnuleds 
      Caption         =   "leds"
      Begin VB.Menu mnuverde 
         Caption         =   "verde"
      End
      Begin VB.Menu mnurojo 
         Caption         =   "rojo"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    ' Set Title
    App.Title = "vb-sgc-generic"
    
    ' Center Form
    frmMain.Move (Screen.Width - Width) / 2, (Screen.Height - Height) / 2
    sw = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
If MSComm1.PortOpen Then
    MSComm1.PortOpen = 0
End If
End Sub

Private Sub mnuabout_Click()
frmAbout.Show
End Sub

Private Sub mnuFileExit_Click()
Unload Me
End Sub


Private Sub mnuProperties_Click()
  ' Show the CommPort properties form
  frmProperties.Show vbModal
  
End Sub

' Toggles the state of the port (open or closed).
Private Sub mnuOpen_Click()
    On Error Resume Next
    Dim OpenFlag

    MSComm1.PortOpen = Not MSComm1.PortOpen
    If Err Then MsgBox Error$, 48
    
    OpenFlag = MSComm1.PortOpen
        
    mnuOpen.Checked = OpenFlag
        
    If MSComm1.PortOpen Then
        sbrStatus.Panels("Settings").Text = "Settings: Com " & MSComm1.CommPort & " " & MSComm1.Settings
        MSComm1.DTREnable = False
    Else
        sbrStatus.Panels("Settings").Text = "Settings: "
        sbrStatus.Panels("Status").Text = "Status: OFF-LINE"
        Image1.Picture = LoadPicture("off.bmp")
        Text1.Enabled = False
    End If
    
    
End Sub

Private Sub mnureset_Click()
If MSComm1.PortOpen Then
    MSComm1.DTREnable = True
    MSComm1.DTREnable = False
End If
End Sub

Private Sub mnurojo_Click()
If MSComm1.PortOpen Then
    MSComm1.Output = Chr(&H4D)
End If
End Sub

Private Sub mnuverde_Click()
If MSComm1.PortOpen Then
        MSComm1.Output = Chr(&H4C)
End If
End Sub

Private Sub Timer1_Timer()
If MSComm1.PortOpen Then
    If sw Then
        MSComm1.Output = Chr(&H50)
        esta = False
        Timer1.Enabled = False
        Timer2.Enabled = True
    Else
        MSComm1.Output = Chr(&H49)
        Timer1.Enabled = False
        Timer2.Enabled = True
    End If
    sw = Not sw
End If
End Sub

Private Sub Timer2_Timer()
Dim buffer As Variant

If esta And MSComm1.PortOpen Then
    MSComm1.InputLen = 1
    buffer = MSComm1.Input
    If StrConv(buffer, vbUnicode) = Chr(&H49) Then
        Text2.Enabled = False
        Text3.Enabled = False
        Command(0).Enabled = False
        Command(1).Enabled = False
        Call identificacion
    End If
    Timer2.Enabled = False
    Timer1.Enabled = True
ElseIf MSComm1.InBufferCount = 0 Then
    sbrStatus.Panels(1).Text = "Status: OFF-LINE"
    Text1.Enabled = False
    Image1.Picture = LoadPicture("off.bmp")
    Timer2.Enabled = False
    Timer1.Enabled = True
Else
    buffer = MSComm1.Input
    If StrConv(buffer, vbUnicode) = Chr(&H4F) Then
        sbrStatus.Panels(1).Text = "Status: ON-LINE"
        Text1.Enabled = True
        Image1.Picture = LoadPicture("on.bmp")
        esta = True
        Timer2.Enabled = False
        Timer1.Enabled = True
    Else
        Timer2.Enabled = False
        Timer1.Enabled = True
        MSComm1.InBufferCount = 0
    End If
End If
End Sub
