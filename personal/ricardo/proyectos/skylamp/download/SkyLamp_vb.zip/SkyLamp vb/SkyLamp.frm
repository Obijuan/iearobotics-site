VERSION 5.00
Object = "{648A5603-2C6E-101B-82B6-000000000014}#1.1#0"; "MSCOMM32.OCX"
Begin VB.Form SkyLamp 
   Caption         =   "Control SkyLamp v1.0"
   ClientHeight    =   1785
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   1785
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox TxtPuerto 
      Alignment       =   1  'Right Justify
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Left            =   2010
      TabIndex        =   5
      Text            =   "1"
      Top             =   675
      Width           =   405
   End
   Begin VB.CommandButton BtnConectar 
      Caption         =   "Conectar la SkyLamp"
      Height          =   525
      Left            =   60
      TabIndex        =   3
      Top             =   1200
      Width           =   2250
   End
   Begin VB.CommandButton BtnApagar 
      Caption         =   "Apagar"
      Height          =   510
      Left            =   2625
      TabIndex        =   2
      Top             =   105
      Width           =   1950
   End
   Begin VB.CommandButton BtnEncender 
      Caption         =   "Encender"
      Height          =   525
      Left            =   2625
      TabIndex        =   1
      Top             =   645
      Width           =   1950
   End
   Begin VB.CommandButton BtnDesconectar 
      Caption         =   "Desconectar la SkyLamp"
      Height          =   525
      Left            =   2325
      TabIndex        =   0
      Top             =   1200
      Width           =   2250
   End
   Begin MSCommLib.MSComm Comm 
      Left            =   4110
      Top             =   1215
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      DTREnable       =   -1  'True
   End
   Begin VB.Label Label2 
      Caption         =   "Control SkyLamp"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   540
      Left            =   120
      TabIndex        =   6
      Top             =   150
      Width           =   2400
   End
   Begin VB.Label Label1 
      Caption         =   "N� puerto serie"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   405
      Left            =   150
      TabIndex        =   4
      Top             =   720
      Width           =   1890
   End
End
Attribute VB_Name = "SkyLamp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub BtnApagar_Click()
Comm.DTREnable = False
End Sub

Private Sub BtnConectar_Click()
Comm.CommPort = Val(TxtPuerto.Text)
Comm.PortOpen = True
End Sub

Private Sub BtnDesconectar_Click()
Comm.PortOpen = False
End Sub

Private Sub BtnEncender_Click()
Comm.DTREnable = True
End Sub

