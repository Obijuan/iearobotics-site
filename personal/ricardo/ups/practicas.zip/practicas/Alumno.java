/**
 * @(#)Alumno.java
 *
 *
 * @author Ricardo G�mez Gonz�lez
 * @version 1.00 2006/11/22
 */


public class Alumno {
	private String expediente;
	private int DNI;
	private char letraNIF;
	private String nombre;
	private String direccion;
	private String telefono;
	
	//Constructores de la clase
    public Alumno(String exp, int DNI) {
    	this.expediente = exp;
    	this.DNI = DNI;    
    }

	//Redefinimos "toString" para mostrar
	//por pantalla el objecto    
    public String toString() {
    	return expediente + " " + DNI;
    }

	//M�todos GET    
    public String getExpediente() {
    	return this.expediente;
    }

    public int getDNI() {
    	return this.DNI;
    }

    public char getLetraNIF() {
    	return this.letraNIF;
    }

    public String getDireccion() {
    	return this.direccion;
    }

    public String getTelefono() {
    	return this.telefono;
    }

	//M�todos SET
    public void setExpediente(String exp) {
    	this.expediente = exp;
    }

    public void setDNI(int numeroDNI) {
    	this.DNI = numeroDNI;
    }

    public void setLetraNIF(char NIF) {
    	this.letraNIF = NIF;
    }

    public void setDireccion(String Dir) {
    	this.direccion = Dir;
    }

    public void setTelefono(String Telf) {
    	this.telefono = Telf;
    }
    
    //M�todos p�blicos de la clase
    public boolean equals(Alumno al) {
    	return this.DNI == al.getDNI();
    }
}