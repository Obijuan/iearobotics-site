/**
 * @(#)DatosAlumnos.java
 *
 *
 * @author Ricardo G�mez (ricardo@eagleman.org)
 * @author http://www.iearobotics.com/personal/ricardo
 * @version 1.00 2006/11/22
 */
import java.util.Date;
import java.util.Calendar;
import java.text.SimpleDateFormat;

public class DatosAlumnos {
        
    /**
     * Creates a new instance of <code>DatosAlumnos</code>.
     */
    public DatosAlumnos() {
    }
    
    /**
     * Helper utility used to print a String to STDOUT.
     * @param s String that will be printed to STDOUT.
    */
    private static void prt(Object obj) {
        System.out.println(obj);
    }

    private static void prt(String s) {
        System.out.println(s);
    }

    private static void prt() {
        System.out.println();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int i;
        
        Date Hoy = Calendar.getInstance().getTime();
        prt("La fecha y hora de hoy es: " + Hoy);
        
        Calendar now = Calendar.getInstance();
        Calendar working;
       	SimpleDateFormat formatter = new SimpleDateFormat("E yyyy.MM.dd 'at' hh:mm:ss a zzz");

        working = (Calendar) now.clone();
        working.add(Calendar.DAY_OF_YEAR, - (365 * 2));
        prt("Two years ago it was: " + formatter.format(working.getTime()));

        working = (Calendar) now.clone();
        working.add(Calendar.DAY_OF_YEAR, + 5);
        prt("In five days it will be: " + formatter.format(working.getTime()));

        prt();        
        
        //Definimos el array
        Alumno[] Datos;
        //Reservamos el array de objetos
        Datos = new Alumno[5];
        //Rellenamos el array con los objetos
        Datos[0] = new Alumno("020202", 97979797);
        Datos[1] = new Alumno("030303", 07070707);
        Datos[2] = new Alumno("030303", 07070707);
        Datos[3] = new Alumno("040404", 17171717);
        Datos[4] = new Alumno("727272", 27272727);
        
        for(i=0;i<5;i++)
        	prt(Datos[i]);
        
        prt("Comprobamos si dos objetos son iguales.");
        
        if (Datos[1].equals(Datos[2]))
        	prt("Los objetos son iguales");
        else
        	prt("Los objetos no son iguales");
    }
}
