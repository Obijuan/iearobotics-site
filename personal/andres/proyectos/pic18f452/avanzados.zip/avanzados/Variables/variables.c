/* 
	Programa: Ejemplo de localizaci�n de variables
	Empresa:  Ifara Tecnolog�as S.L.
	Autor:    Andr�s Prieto-Moreno
	Fecha:    20-junio-2003
*/

/*	
	=========================
	Localizaci�n de variables
	=========================
	
	a) Globales -> secci�n GPR0 (0x80): primera posici�n libre despu�s del accessbank
				-> depende si compilamos con NEAR o con FAR
	
	b) Locales ->
		overlay (far)  -> 0x400
		static, extern -> 0x80 / 0x00  ( near esta desactivado / activado ) (-Oa- / -Oa+ )
		auto           -> 0x500 ( se guardan en la PILA que se define en ese Banco )
		
		* Si compilamos con la opci�n NEAR (-Oa+) las variables se situan en el Acess Bank
		y tendremos que poner el identificador FAR para aquellas que hayamos fijado en otros
		bancos !!!
*/


/* 
	Definimos un tipo nuevo
*/
typedef unsigned char BYTE;   

/*
	Declaraci�n de variables 'auto', el compilador la coloca seg�n su criterio, definido
	en el Linker-script.
*/

BYTE var_global = 0x5;   

/*
	Otra forma de situar variables en posiciones conocidas de memoria.
	En este caso se ha modificado el linker script a�adiendo una nueva 
	secci�n que hemos llamado "mis_datos"

	// a�adido para crear una nueva secci�n de datos	
	DATABANK   NAME=mi_seccion  START=0x125          END=0x2FF
	SECTION NAME=mis_datos RAM=mi_seccion
*/

#pragma	idata  mis_datos
far BYTE var_global2=0x30;         // variable global auto
#pragma idata


/*
	C�digo que coloca mis variables en la posicion 0x250 de
	la memoria de datos

	Tengo que vigilar que en la zona de memoria seleccionada se 
	permitan variables de usuario. (linker script)
*/

#pragma	 udata  var_pos=0x200   // seccion absoluta en RAM
far BYTE var_global3;                   // variable global auto
#pragma  udata


/*
	Forma de situar el c�digo de la funci�n en una zona conocida
*/
#pragma code mi_codigo=0x1000

void main(void) {
	// declaraci�n de variables
	extern int var_externa;            //  declarada externa	 
	BYTE var_local_auto       = 0x40;  //  variable local auto
	static  BYTE var_estatica = 0x50;  //  variable local est�tica

	// programa principal
	for (;;) {
		var_local_auto++;  // 0x500 ( PILA )
		var_estatica++  ;  // 0x8x / con NEAR Ox0x
		var_global++    ;  // 0x8x / con NEAR 0x0x
		var_global2++   ;  // var_pos = 0x250
		var_global3++   ;  // mis datos 0x125
		var_externa++   ;  // 0x8x / con NEAR 0x0x

		if (var_estatica==0x60) {
			break;
		}
	}
}

// Ejemplo de declaraci�n de una variable extern
unsigned int var_externa;
