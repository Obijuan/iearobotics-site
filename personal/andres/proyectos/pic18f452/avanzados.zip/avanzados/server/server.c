/* 
	Programa servidor de aplicaciones
*/

#include <p18f452.h>
#include <usart.h>
#include <stdlib.h>
#include <timers.h>


// variable global donde guardo la trama recibida
unsigned char trama[4];

/*
	Configuraci�n de la interrupci�n del TIMER para el 
	Zumbador
*/

void low_isr(void);

// configuro el vector de interrupci�n
#pragma code low_vector=0x18
void low_interrupt(void) {
	_asm
		goto low_isr
	_endasm
}
#pragma code

// Rutina de Interrupci�n del Timer
#pragma interruptlow low_isr
void low_isr(void) {
	// tengo que determinar quien ha interrumpido
	PORTCbits.RC2 = !PORTCbits.RC2;
	WriteTimer1(0xF700);
	PIR1bits.TMR1IF=0;
}


void configura_timer(void) {
	OpenTimer1( TIMER_INT_ON  &
				T1_16BIT_RW   &
				T1_SOURCE_EXT &
				T1_PS_1_1     &
				T1_OSC1EN_ON  &
				T1_SYNC_EXT_ON );
	WriteTimer1(0xF700);
}


/*
=========================================
*/

/* 
	Subrutinas de la aplicaci�n
*/
void configura_usart(void) {
	// Configuramos el puerto serie
	OpenUSART( USART_TX_INT_OFF  &
			   USART_RX_INT_OFF  &
 			   USART_ASYNCH_MODE &
               USART_EIGHT_BIT   &
               USART_CONT_RX     &
               USART_BRGH_HIGH,
               25 );	
}

void retorno_carro(void) {
	// retorno de carro
	WriteUSART(13);
	WriteUSART(10);
}

void activa_zumbador(void) {
	INTCONbits.GIE =1;  // SI permite interrupciones
}

void apaga_zumbador(void) {
	INTCONbits.GIE =0;  // NO permite interrupciones
}


void envia_pulsador(void) {
	if ( PORTAbits.RA4 == 0 ) {
		putrsUSART("on");
	} else {	
		putrsUSART("off");
	}
	retorno_carro();
}

void representa_leds( unsigned char car) {
	if ( car>='0' && car<='7') {
		PORTB = car<<1;
	}
}

void leer_memoria(unsigned char da, unsigned char db, unsigned char dc) {
	unsigned int dir;

}
		

void recibir_trama(void) {
	unsigned char car;
	unsigned char i=0;

	PORTBbits.RB0=1;
	
	for (i; i<4; i++) {
		while ( !DataRdyUSART() ); // Espera a que haya un dato listo
		trama[i] = getcUSART();           // Lee el caracter nuevo
		PORTBbits.RB0=0;
		//WriteUSART(trama[i]);           // Manda el caracter recibido
	}
	retorno_carro();
}

void procesa_trama(void) {
	switch  ( trama[0] ) {
		case 'a': activa_zumbador();
				  break;
		case 'e': apaga_zumbador();
				  break;
		case 'b': envia_pulsador();
				  break;
		case 'c': representa_leds(trama[1]);
				  break;
		case 'd': leer_memoria(trama[1],trama[2],trama[3]);
				  break;
	}
}

/* 
	Programa principal
*/

void main(void) {
	unsigned char car;

	// configuro puerto B 
	TRISB=0;  
	PORTB=0;

	// RC2 de salida
	TRISC = TRISC & 0xFB;

	// configuro pulsador de entrada
	TRISA=0x10;

	// configuro el puerto serie
	configura_usart();

	// configura TIMER 1
	configura_timer();
	
	// configura interrupciones
	RCONbits.IPEN  =0;  // m�todo cl�sico, sin prioridades
	INTCONbits.PEIE=1;  // permito interrupciones de los perifericos

	while (1) {
		// esperamos a recibir la trama
		recibir_trama();
		// procesamos la trama
		procesa_trama();
	}
	CloseUSART();
}
