/*
	Programa que hace parpadear el LED RB1 por interrupciones 
	y apaga el LED RB0 al pulsar RA4

	Empresa: Ifara Tecnolog�as
	Autor: Andr�s Prieto-Moreno Torres
*/

#include <p18f452.h>
#include <timers.h>

void low_isr(void);

// configuro el vector de interrupci�n
#pragma code low_vector=0x18
void low_interrupt(void) {
	_asm
		goto low_isr
	_endasm
}
#pragma code

// Rutina de Interrupci�n del Timer
#pragma interruptlow low_isr
void low_isr(void) {
	// tengo que determinar quien ha interrumpido
	PORTBbits.RB1 = !PORTBbits.RB1;
	WriteTimer1(0xC000);
	PIR1bits.TMR1IF=0;
}


void configura_timer(void) {
	OpenTimer1( TIMER_INT_ON  &
				T1_16BIT_RW   &
				T1_SOURCE_EXT &
				T1_PS_1_1     &
				T1_OSC1EN_ON  &
				T1_SYNC_EXT_ON );
	WriteTimer1(0xC000);
}


void main(void) {
	int result;

	// configura Puerto B	
	TRISB=0;
	PORTB=0x01;

	// configura Puerto A
	TRISA=0x10;
	
	// configura TIMER 1
	configura_timer();
	
	// configura interrupciones
	RCONbits.IPEN  =0;  // m�todo cl�sico, sin prioridades
	INTCONbits.PEIE=1;  // permito interrupciones de los perifericos
	INTCONbits.GIE =1;  // permite interrupciones

	// bucle principal	

	while (1) {
		if ( PORTAbits.RA4==0) {
			PORTBbits.RB0=0;
		}
		else {
			PORTBbits.RB0=1;
		}
	}
	CloseTimer1();
}
