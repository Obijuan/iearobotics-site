/*
Programa 3 : Efecto �ptico y zumbador
Ejemplo de programa que hace un efecto luminoso con los LEDS a la
vez que hace sonar el zumbador al apretar el pulsador.

Zumbador -> RC2
LED      -> RB3:RB0
Pulsador -> RA4

Autor: Andr�s Prieto-Moreno
*/

#include <p18f452.h>

void main(void) {
	// configuramos los puertos
	TRISB = 0;    // puerto B configurado como salida
	TRISA = 0xFF; // puerto A configurado como entrada
	TRISC = 0;    // puerto C configurado como salida

	// valor inicial puertos
	PORTA=0;
	PORTB=0;
	
	// bucle principal
	
	if ( PORTA != 0x10 ) {
		PORTB = ( PORTB + 1 ) % 16; 
		PORTC = 0xff;  
	}
}
