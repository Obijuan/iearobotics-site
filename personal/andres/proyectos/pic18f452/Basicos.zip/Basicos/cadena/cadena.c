/*
Ejemplo de tratamiento de cadenas en RAM y ROM
*/

#include <string.h>

// almaceno mi cadena en ROM
#pragma romdata rom_variables=0x200
const rom unsigned char micadena[]="hola mundo";
#pragma romdata

#pragma udata ram_variables=0x200
char strbuffer[21];
#pragma udata

void main(void) {
	// correcto
	//strcpypgm2ram(strbuffer, micadena);
	// incorrecto 
	strcpy(strbuffer,micadena);
	for (;;);
}
