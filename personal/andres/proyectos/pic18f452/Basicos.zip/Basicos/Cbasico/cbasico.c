/*
Programa1  : El Hola Mundo de los micros
Descripci�n: Ejemplo de programa que enciende el LED RB0
Empresa    : Ifara Tecnolog�as S.L.
Autor      : Andr�s Prieto-Moreno
*/

void main(void) {
	// definimos dos punteros para acceder a los registros 
	unsigned char *puerto_b;
	unsigned char *dir_puerto_b;

	// asignamos las direcciones correctas a los punteros
	puerto_b = (unsigned char *) 0xF81;
	dir_puerto_b = (unsigned char *) 0xF93;

	// ponemos el valor adecuado en el contenido apuntado
	*dir_puerto_b = 0;  // puerto B configurado de salida
	*puerto_b =  1;     // enciende el bit cero del puerto B
}
