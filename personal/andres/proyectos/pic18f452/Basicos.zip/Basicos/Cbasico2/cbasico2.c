/*
Programa 2 : Entradas y salidas
Ejemplo de programa que apaga el LED al pulsar el pulsador RA4

Autor: Andr�s Prieto-Moreno
*/

// localizaci�n de los puertos
#define  puerto_a      *((near unsigned char *)0xF80)
#define  puerto_b      *((near unsigned char *)0xF81)
#define  dir_puerto_a  *((near unsigned char *)0xF92)
#define  dir_puerto_b  *((near unsigned char *)0xF93)

void main(void) {

	// configuramos los puertos
	dir_puerto_b = 0;    // puerto B configurado de salida
	dir_puerto_a = 0xFF; // puerto A configurado como entrada

	while (1) {
		//if ( puerto_a == 0x10 ) {   // No pulsado -> nivel alto
		if ( puerto_a:4 == 0 ) {
			puerto_b =  1;     // enciende el bit cero del puerto B
		}
		else {   // pulsado -> nivel bajo
			puerto_b = 0;     
		}
	}
}
