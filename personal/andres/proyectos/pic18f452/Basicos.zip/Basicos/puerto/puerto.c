/*
	Ejemplo de declaracion variable tipo puerto, es decir
	con acceso independiente a los bits.
*/


#pragma idata mi_posicion=0x200
union tbyte {
	unsigned char valor;
	struct {	
		unsigned bit0:1;
		unsigned bit1:1;
		unsigned bit2:1;
		unsigned bit3:1;
		unsigned bit4:1;
		unsigned bit5:1;
		unsigned bit6:1;
		unsigned bit7:1;
	};
	struct {
		unsigned nibblel:4;
		unsigned nibbleh:4;
	};
};

#pragma idata



void main(void) {
	// acceso a una direcci�n ya declarada
	union tbyte *puerto;
	union tbyte *dirpuerto;
	
	dirpuerto = (union tbyte *) 0xF93;
	dirpuerto.valor=0x0;

	puerto = (union tbyte *) 0xF81;

	(*puerto).valor=0;
	(*puerto).bit0=1;
}
