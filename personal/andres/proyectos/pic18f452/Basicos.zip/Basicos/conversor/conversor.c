/* 
Programa ejemplo de utilizaci�n del conversor
Mostramos los 4 bits m�s significativos de la conversi�n en los leds

Empresa: Ifara Tecnolog�as S.L.
Autor  : Andr�s Prieto-Moreno Torres
*/

#include <p18f452.h>

void main(void) {
	// Puerto B de salida
	TRISB = 0x0;

	// configuramos el conversor
	ADCON1 = 0x0E;
	ADCON0 = 0x85; 
		
	while (1) {
		// esperamos a que termine la conversi�n en curso
		while ( (ADCON0 & 0x04) != 0 );
		
		// activamos la siguiente conversi�n	
		ADCON0 = ADCON0 | 0x04;      
		// activamos los LEDS
		PORTB=ADRESH>>4;   // vemos los m�s significativos
	}
}

