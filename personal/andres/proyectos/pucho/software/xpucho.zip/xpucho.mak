#Definicion del compilador y los parametros de compilacion
CC=		gcc
CFLAGS=		-O2 

#
# Fichero objeto, fuente y .H

OFILES=		panel.o xpucho.o
HFILES=         panel.h xpucho.h
CFILES=		panel.c xpucho.c

xpucho:		$(OFILES)
		$(CC) -o xpucho $(OFILES) -L/usr/X11R6/lib -lforms -lcts -lX11 -lm

.c.o:	
		$(CC) $(CFLAGS) -c $<

clean:
		rm -f $(OFILES) xpucho


