/** Header file generated with fdesign on Tue Jun 27 01:24:22 2000.**/

#ifndef FD_panel_h_
#define FD_panel_h_

/** Callbacks, globals and object handlers **/
extern void poner_ojo(FL_OBJECT *, long);
extern void boton_pulsado(FL_OBJECT *, long);
extern void menu_pulsado(FL_OBJECT *, long);
extern void posicionar_futaba(FL_OBJECT *, long);
extern void apaga_motor(FL_OBJECT *, long);
extern void camara_lenta(FL_OBJECT *, long);
extern void poner_posicion(FL_OBJECT *, long);


/**** Forms and Objects ****/
typedef struct {
	FL_FORM *panel;
	void *vdata;
	char *cdata;
	long  ldata;
	FL_OBJECT *ojo_b2;
	FL_OBJECT *b_grabar;
	FL_OBJECT *b_borrar;
	FL_OBJECT *b_parar;
	FL_OBJECT *boton_tiempo;
	FL_OBJECT *opcion;
	FL_OBJECT *b_off;
	FL_OBJECT *b_on;
	FL_OBJECT *boton_pasos;
	FL_OBJECT *b_atras;
	FL_OBJECT *b_repro;
	FL_OBJECT *motor_a2;
	FL_OBJECT *motor_b2;
	FL_OBJECT *motor_b3;
	FL_OBJECT *MC3;
	FL_OBJECT *motor_c3;
	FL_OBJECT *motor_c2;
	FL_OBJECT *MA4;
	FL_OBJECT *MB3;
	FL_OBJECT *MA3;
	FL_OBJECT *MB2;
	FL_OBJECT *MB4;
	FL_OBJECT *MC2;
	FL_OBJECT *MA2;
	FL_OBJECT *motor_a4;
	FL_OBJECT *b_insertar;
	FL_OBJECT *b_ciclo;
	FL_OBJECT *ojo_b7;
	FL_OBJECT *ojo_b4;
	FL_OBJECT *ojo_b3;
	FL_OBJECT *ojo_b5;
	FL_OBJECT *ojo_b6;
	FL_OBJECT *ojo_b8;
	FL_OBJECT *ojo_b1;
	FL_OBJECT *ojo_a7;
	FL_OBJECT *ojo_a4;
	FL_OBJECT *ojo_a3;
	FL_OBJECT *ojo_a5;
	FL_OBJECT *ojo_a6;
	FL_OBJECT *ojo_a2;
	FL_OBJECT *ojo_a8;
	FL_OBJECT *ojo_a1;
	FL_OBJECT *levantado;
	FL_OBJECT *sentado;
	FL_OBJECT *tumbado;
	FL_OBJECT *equilibrio_a;
	FL_OBJECT *equilibrio_b;
	FL_OBJECT *equilibrio_c;
	FL_OBJECT *equilibrio_d;
	FL_OBJECT *motor_c1;
	FL_OBJECT *motor_a1;
	FL_OBJECT *MC1;
	FL_OBJECT *MC4;
	FL_OBJECT *MA1;
	FL_OBJECT *MB1;
	FL_OBJECT *motor_b1;
	FL_OBJECT *motor_a3;
	FL_OBJECT *motor_b4;
	FL_OBJECT *motor_c4;
} FD_panel;

extern FD_panel * create_form_panel(void);

#endif /* FD_panel_h_ */
