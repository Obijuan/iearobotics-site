library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity gpr is
	generic (w : integer);
	port(
		wren : in std_logic;
		clk : in std_logic;
		nrst : in std_logic;
		din : in std_logic_vector(w-1 downto 0);
		rs1 : in std_logic_vector(2 downto 0);
		rs2 : in std_logic_vector(2 downto 0);
		rd : in std_logic_vector(2 downto 0);
		qs1 : out std_logic_vector(w-1 downto 0);
		qs2 : out std_logic_vector(w-1 downto 0);
		
		index : in std_logic_vector(1 downto 0);
		qindex : out std_logic_vector(w-1 downto 0)
		);
end gpr;

architecture test of gpr is
	
	type t_registros is array (7 downto 0) of std_logic_vector (w-1 downto 0);
	signal registros : t_registros;		 
	
begin
	
	-- lectura de registros combinacional
	qs1 <= registros(conv_integer(rs1));
	qs2 <= registros(conv_integer(rs2));	 
	qindex <= (registros(conv_integer("1"&index)));
	
	escritura : process(clk, nrst)
	begin
		if(nrst = '0') then
			-- inicializar todos los registros a 0
			for i in 0 to 7 loop
				registros(i) <= (others => '0');
			end loop;
		elsif(clk'event and clk = '1') then
			if(wren = '1' and (not (rd = "100"))) then			
				-- escritura es s�ncrona
				-- hay que escribir en el registro destino 
				-- excepto el registro R0 ("100")
				registros(conv_integer(rd)) <= din;
			end if;
		end if;
	end process;
	
end test;
