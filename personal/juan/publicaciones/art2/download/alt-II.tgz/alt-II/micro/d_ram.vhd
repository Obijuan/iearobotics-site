library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all; 

entity d_ram is
	generic (
		l : integer;
		w : integer
		);
	port (
		addr: in  std_logic_vector(l-1 downto 0);
		we : in  std_logic;	  
		d_req : in std_logic;
		clk : in  std_logic;
		datain : in  std_logic_vector(w-1 downto 0);
		dataout : out std_logic_vector(w-1 downto 0)
		);
end d_ram;

architecture test of d_ram is 
	
	--	type mem_type is array ((2**l)-1 downto 0) of std_logic_vector(w-1 downto 0); 
	type mem_type is array (0 to 62) of std_logic_vector(w-1 downto 0); 
	
	signal mem : mem_type := (
      X"9851",
	   X"6B9B",
      X"9D56",
	   X"629D",
      X"9B61",
	   X"599D",                   
      X"9B67",
	   X"549A",
      X"9970",
	   X"4D98",
      X"947A",
	   X"4A90",
      X"9081",
	   X"4A88",
      X"8888",
	   X"4883",
      X"8190",
	   X"4A7A",       -- 16
      X"7A94",
	   X"4D73",
      X"7398",
	   X"5368",
      X"689D",
	   X"5662",
      X"619B",
	   X"5F5B",                   
      X"599B",
	   X"6754",
      X"5399",
	   X"704F",
      X"4D94",
	   X"7A4A",
      X"488F",
	   X"8348",
      X"4A84",
	   X"8C48",
      X"4A7E",
	   X"924B",                   
      X"4C75",
	   X"984D",
      X"516B",
	   X"9B55",
      X"5D5D",
	   X"9D62",
      X"6455",
	   X"9B6B",
      X"6B51",
	   X"9873",
      X"734D",
	   X"937D",
      X"7D48",
	   X"8F83",
      X"844A",
	   X"868A",
      X"8C4A",
	   X"7E91",
      X"934C",
	   X"7596",
      X"934C",
	   X"7596",  
		X"0000",	-- Constante 0
		X"0001",	-- Constante 1
		X"F000"		-- hasta donde cuenta
	);	
	


	signal internal_addr : std_logic_vector(6 downto 0);
	signal enable : std_logic;
	
begin 
	
	internal_addr <= addr(6 downto 0);
	enable <= not addr(7);
	
	process(clk) 
	begin 
		if (clk = '0' and clk'event) then 
			if(enable = '1' and d_req = '1') then
				if (we = '1') then 
					mem(conv_integer(internal_addr)) <= datain; 
				end if;
			end if;
		end if; 
	end process; 		
	
	dataout <= mem(conv_integer(internal_addr)) when (d_req = '1' and enable = '1') 
				else (others => '0'); 
	
end test; 