library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_signed.all;
		   
entity alu is
	generic (w: integer);
	port(
		d0 : in std_logic_vector(w-1 downto 0);
		d1 : in std_logic_vector(w-1 downto 0);
		op : in std_logic_vector(1 downto 0);
		f : out std_logic;
		q : out std_logic_vector(w-1 downto 0)
		);
end alu;

architecture test of alu is
	
	signal d1n : std_logic_vector(w-1 downto 0);
	signal q1 : std_logic_vector(w-1 downto 0);
	signal c : std_logic;
	signal z: std_logic;
	
begin
	
	selec_op : process(d1, op)
	begin				  
		-- SUMA
		if(op = "00") then 
			d1n <= d1;
		-- RESTA
		else
			-- complemento a 2 del segundo operando
			d1n <= -d1;
		end if;
	end process;
	
	suma_resta : process (d0, d1n)
	   	variable a, b, suma, zero: std_logic_vector(w downto 0); 
		begin
			-- extender signo
			a(w-1 downto 0) := d0;
			a(w) := d0(w-1);
			b(w-1 downto 0) := d1n;
			b(w) := d1n(w-1);
		
			-- suma
			suma := a + b;
		
			-- resultado
			q <= suma(w-1 downto 0);
			
			-- C tiene el acarreo
			c <= suma(w);
		
			-- Z es 1 si el resultado de la suma es 0
			zero := (others=>'0');
			if(suma = zero) then
				z <= '1';
			else
				z <= '0';
			end if;
	end process;	
	
	flags : process(z, c, op)
	BEGIN	  
		-- CMP
		if(op = "01") then
			-- f es 1 si el resultado es 0
			f <= z;
		else
			-- Otras operaciones: el f es 1 si hay acarreo
			f <= c;
		end if;
	end process;

end test;
