library ieee;
use ieee.std_logic_1164.all; 
use ieee.std_logic_signed.all;

entity cpu is
	port(
		p_wait : in std_logic;
		d_wait : in std_logic;
		clk : in std_logic;
		nrst : in std_logic;
		p_datain : in std_logic_vector(15 downto 0);
		d_datain : in std_logic_vector(15 downto 0);
		p_req : out std_logic;
		d_wr : out std_logic;
		d_req : out std_logic;
		p_addr : out std_logic_vector(7 downto 0);
		d_addr : out std_logic_vector(7 downto 0);
		d_dataout : out std_logic_vector(15 downto 0)
		);
end cpu;

architecture test of cpu is

 	-- registros de prop�sito general
	component gpr is
		generic (w : integer);
		port(
			wren : in std_logic;
			clk : in std_logic;
			nrst : in std_logic;
			din : in std_logic_vector(w-1 downto 0);
			rs1 : in std_logic_vector(2 downto 0);
			rs2 : in std_logic_vector(2 downto 0);
			rd : in std_logic_vector(2 downto 0);
			qs1 : out std_logic_vector(w-1 downto 0);
			qs2 : out std_logic_vector(w-1 downto 0);
		 	index : in std_logic_vector(1 downto 0);
		 	qindex : out std_logic_vector(w-1 downto 0)			
			);
	end component;
	
 	-- registros intermedios	
	component reg is
		generic (w : integer);
		port(
			load : in std_logic;
			clk : in std_logic;
			nrst : in std_logic;
			d : in std_logic_vector(w-1 downto 0);
			q : out std_logic_vector(w-1 downto 0)
			);
	end component;
	
	-- ALU
	component alu is
		generic (w : integer);
		port(
			d0 : in std_logic_vector(w-1 downto 0);
			d1 : in std_logic_vector(w-1 downto 0);
			op : in std_logic_vector(1 downto 0);
			f : out std_logic;
			q : out std_logic_vector(w-1 downto 0)
			);
	end component;
	
	-- unidad de control	
	component control is
		port(
			clk : in std_logic;
			nrst : in std_logic;
			d_wait : in std_logic;
			flag : in std_logic;
			p_wait : in std_logic;
			ir : in std_logic_vector(15 downto 0);
			d_req : out std_logic;
			d_wr : out std_logic;
			flag_en : out std_logic;
			is_load : out std_logic;
			load_ir : out std_logic;
			load_pc : out std_logic;
			load_reg : out std_logic;
			load_res : out std_logic;
			p_req : out std_logic;
			sel_off : out std_logic;
			sel_op2 : out std_logic;
			d_addr : out std_logic_vector(7 downto 0)
			);
	end component;
	
	-- se�ales internas
	signal q_result: std_logic_vector(15 downto 0);
	signal is_load: std_logic;
	signal q_datain: std_logic_vector(15 downto 0);
	signal loadreg: std_logic;
	signal rd: std_logic_vector(2 downto 0);
	signal qs2: std_logic_vector(15 downto 0);
	signal sel_op2 : std_logic;
	signal alu_in1 : std_logic_vector(15 downto 0);
	signal alu_in2 : std_logic_vector(15 downto 0);
	signal alu_out : std_logic_vector(15 downto 0);
	signal d_flag : std_logic_vector(0 downto 0);
	signal q_flag : std_logic_vector(0 downto 0);
	signal flag_en : std_logic;
	signal loadres : std_logic;
	signal load_ir : std_logic;
	signal q_ir : std_logic_vector(15 downto 0);
	signal sel_off : std_logic;
	signal d_offset : std_logic_vector(15 downto 0);
	signal q_offset : std_logic_vector(15 downto 0);
	signal d_pc : std_logic_vector(15 downto 0);
	signal q_pc : std_logic_vector(15 downto 0);
	signal load_pc : std_logic;	 
	signal d_ram_ir : std_logic_vector(7 downto 0);
	signal d_ram_offset : std_logic_vector(15 downto 0); 
	
	
begin
	-- multiplexor de la entrada de datos
	--(selecciona entre el bus de datos o el registro de resultados) 
	q_datain <= d_datain when is_load = '1' else q_result;
	
	-- multiplexor de registro de destino
	-- (selecciona entre rd o rs1, 
	-- ya que en instrucciones LOAD el destino est� especificado en rs1)
	rd <= q_ir(2 downto 0) when is_load = '1' else q_ir(8 downto 6);

	--bloque de registros de prop�sito general
	bloque_registros : gpr generic map (w => 16)
	port map
		(
		wren => loadreg,
		clk => clk,
		nrst => nrst,
		din => q_datain,
		rs1 => q_ir(2 downto 0),
		rs2 => q_ir(5 downto 3),
		rd => rd,
		qs1 => alu_in1,
		qs2 => qs2,
		index => q_ir(12 downto 11),
		qindex => d_ram_offset
		);

	-- multiplexor para el segundo operador de la ALU
	-- (selecciona entre 0 o la segunda salida de los registros)
	alu_in2 <= (others => '0') when sel_op2 = '1' else qs2;
	
	-- ALU del procesador
	alu_cpu : alu generic map (w => 16)
	port map
		(
		d0 => alu_in1,
		d1 => alu_in2,
		op => q_ir (12 downto 11),
		f => d_flag(0),
		q => alu_out
		);
	
	-- registro para el FLAG (1 bit)
	f : reg generic map (w => 1)
	port map
		(
		load => flag_en,
		clk => clk,
		nrst => nrst,
		d => d_flag,
		q => q_flag
		);
	
	-- registro para los resultados de la ALU
	result : reg generic map (w => 16)
	port map
		(
		load => loadres,
		clk => clk,
		nrst => nrst,
		d => alu_out,
		q => q_result
		);			 
	
	-- la salida de este registro se conecta directamente con el bus de datos
	d_dataout <= q_result;
	
	-- registro de captura de instrucciones
	ir : reg generic map (w => 16)
	port map
		(
		load => load_ir,
		clk => clk,
		nrst => nrst,
		d => p_datain,
		q => q_ir
		);

	-- calculo del offset
	-- (extiende el signo del dato de entrada, de 11 bits, para la salida de 16 bits)
	d_offset(10 downto 0) <= q_ir(10 downto 0);
	d_offset(15 downto 11) <= (others => q_ir(10));
	
	-- multiplexor del offset para saltos
	--(selecciona entre 1, para instrucciones secuenciales,
	-- o la salida del calculador del offset, para saltos efectivos)
	q_offset <= d_offset when sel_off = '1' else "0000000000000001";
	
	-- sumador del contador de programa
	-- (suma el PC actual a la salida del multiplexor offsetmux)
	d_pc <= q_pc + q_offset;

	--registro contador de programa
	pc : reg generic map (w => 16)
	port map
		(
		load => load_pc,
		clk => clk,
		nrst => nrst,
		d => d_pc,
		q => q_pc
		);

	-- la direcci�n solicitada a la memoria de instrucciones sale 
	-- directamente del registro PC
	p_addr <= q_pc(7 downto 0);
	
	-- la direccion solicitada a la memoria de datos sale de
	-- la instruccion y se suma el registro indice
	d_addr <= d_ram_ir + d_ram_offset(7 downto 0); 	
	
	-- Unidad de Control del procesador
	UC : control 
	port map
		(
		clk => clk,
		nrst => nrst,
		flag => q_flag(0),
		d_wait => d_wait,
		p_wait => p_wait,
		ir => q_ir,
		d_req => d_req,
		d_wr => d_wr,
		flag_en => flag_en,
		is_load => is_load,
		load_ir => load_ir,
		load_pc => load_pc,
		load_reg => loadreg,
		load_res => loadres,
		p_req => p_req,
		sel_off => sel_off,
		sel_op2 => sel_op2,
		d_addr => d_ram_ir
		);
	
end test;
