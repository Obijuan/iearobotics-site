library ieee;
use ieee.std_logic_1164.all;

entity reg is
	generic (w : integer);
	port(
		load : in std_logic;
		clk : in std_logic;
		nrst : in std_logic;
		d : in std_logic_vector(w-1 downto 0);
		q : out std_logic_vector(w-1 downto 0)
		);
end reg;

architecture test of reg is
	begin
	
	process(clk, nrst)
	begin
		if(nrst = '0') then
			q <= (others => '0');
		elsif(clk'event and clk = '1') then
			if(load = '1') then
				q <= d;
			end if;			
		end if;
	end process;
	
end test;
