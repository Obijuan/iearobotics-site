library ieee; 
use ieee.std_logic_1164.all; 
use ieee.std_logic_unsigned.all; 

entity p_ram is
	generic (
		l : integer;
		w : integer
		);
	port (
		addr : in std_logic_vector(l-1 downto 0);  
		dataout : out std_logic_vector(w-1 downto 0)
		);
end P_RAM;

architecture test of p_ram is
	
	--	type mem_type is array ((2**l) - 1 downto 0) of std_logic_vector(w-1 downto 0); 
	type mem_type is array (0 to 19) of std_logic_vector(w-1 downto 0); 
	
	signal mem : mem_type := ( 
		x"008D",
		x"0096",
		x"0810",
		x"1011",
		x"2400",
		x"2409",
		x"0088",
		x"0091",
		x"009A",
		x"8008",
		x"8810",
		x"D7FE",
		x"8025",
		x"8008",
		x"8148",
		x"8026",
		x"8008",
		x"8188",
		x"E7F0",
		x"E7ED"
	);
	
begin 
	
	dataout <= mem(conv_integer(addr)); 
	
end test; 
