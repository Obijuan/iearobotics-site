library ieee;
use ieee.std_logic_1164.all;

entity control is
	port(
		clk : in std_logic;
		nrst : in std_logic;
		d_wait : in std_logic;
		flag : in std_logic;
		p_wait : in std_logic;
		ir : in std_logic_vector(15 downto 0);
		d_req : out std_logic;
		d_wr : out std_logic;
		flag_en : out std_logic;
		is_load : out std_logic;
		load_ir : out std_logic;
		load_pc : out std_logic;
		load_reg : out std_logic;
		load_res : out std_logic;
		p_req : out std_logic;
		sel_off : out std_logic;
		sel_op2 : out std_logic;
		d_addr: out std_logic_vector(7 downto 0)
		);
end control;

architecture test of control is

	type estado_fsm is (CAPTURA, EJECUCION, ESCRITURA);
	signal estado : estado_fsm;
	
begin
	
	control_fsm : process(clk, nrst)	
	begin
		if(nrst = '0') then
			-- empezamos en el estado de captura
			estado <= CAPTURA;
		elsif(clk'event and clk = '1') then
			if(estado = CAPTURA and p_wait = '0') then
				-- pasar al estado de ejecuci�n
				estado <= EJECUCION;
			elsif(estado = EJECUCION) then
				-- pasar al estado de escritura
				estado <= ESCRITURA;
			elsif(estado = ESCRITURA and d_wait = '0') then
				-- volver al estado de captura
				estado <= CAPTURA;
			end if;
		end if;
	end process;
	
	fsm : process(estado, ir, flag)
	begin						 
		
		-- inicializamos las se�ales
		is_load <= '0';
		load_reg <= '0';
		sel_op2 <= '0';
		d_wr <= '0';
		d_req <= '0';
		flag_en <= '0';
		load_pc <= '0';
		sel_off <= '0';
		load_ir <= '0';
		p_req <= '0';
		load_res <= '0';

		-- direccion de escritura en memoria
		d_addr <= ir(10 downto 3);
		
		-- CAPTURA
		if(estado = CAPTURA) then
			-- solicitamos una instrucci�n
			p_req <= '1';
			load_ir <= '1';
			
		-- EJECUCION	
		elsif(estado = EJECUCION) then
			-- decodificamos la instrucci�n obtenida
			-- LOAD
			-- no tenemos que hacer nada en esta fase.
			
			-- STORE
			if(ir(15 downto 13) = "001") then
				-- la ALU solo tiene que pasar el operador 1 sin tocarlo
				sel_op2 <= '1';
				-- preparamos el registro result para guardar el resultado de la ALU
				load_res <= '1';
				
			-- ALU	
			elsif(ir(15 downto 13) = "100") then
				-- MOVE
				if(ir(5) = '1') then
					-- la ALU solo tiene que pasar el operador 1 sin tocarlo
					sel_op2 <= '1';
					-- preparamos el registro result para guardar el resultado de la ALU
					load_res <= '1';
				-- CMP
				elsif(ir(12 downto 11) = "01") then
					-- solo nos interesa guardar el flag
					flag_en <= '1';
				-- ADD / SUB
				else
					-- nos interesa guardar el flag
					flag_en <= '1';
					-- preparamos el registro result para guardar el resultado de la ALU
					load_res <= '1';
				end if;
				
			-- BF / BNF	
			elsif(ir(15 downto 13) = "110") then
				-- si el flag coincide con c (c es el bit 12 de la instrucci�n),
				-- el sumador del PC debe sumar el offset dado en la instrucci�n
				-- si no, debe sumar 1
				sel_off <= flag xor ir(12);
				
			-- JMP
			elsif(ir(15 downto 13) = "111") then
				-- el sumador del PC debe sumar el offset dado en la instrucci�n siempre
				sel_off <= '1';
			end if;
			
			-- en cualquier caso, debemos cargar el contador de programa con la 
			-- siguiente instrucci�n a ejecutar.
			load_pc <= '1';
			
		-- ESCRITURA
		elsif(estado = ESCRITURA) then
			
			-- LOAD
			if(ir(15 downto 13) = "000") then
				-- indicamos a los registros que es una operaci�n LOAD
				is_load <= '1';
				-- activamos la escritura en el registro destino
				load_reg <= '1';
				-- solicitamos el dato a la memoria
				d_req <= '1';
				
			-- STORE
			elsif(ir(15 downto 13) = "001") then
				-- solicitamos la escritura a la memoria 
				-- (el dato a escribir ya est� en el bus)
				d_req <= '1';
				d_wr <= '1';
			
			-- ALU
			elsif(ir(15 downto 13) = "100") then
				-- MOVE				
				if(ir(5) = '1') then
					-- s�lo debemos escribir en el registro destino
					load_reg <= '1';	 
				-- ADD / SUB
				elsif(ir(12 downto 11) /= "01") then
					-- s�lo debemos escribir en el registro destino
					load_reg <= '1';
				end if;
			end if;
		end if;
	end process;   
	
end test;
