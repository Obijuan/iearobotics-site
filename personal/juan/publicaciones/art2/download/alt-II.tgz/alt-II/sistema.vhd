library ieee;
use ieee.std_logic_1164.all;

entity SISTEMA is
	port(
		--se�ales necesarias
		CLK : in STD_LOGIC;
		NRST : in STD_LOGIC;

		--led de activacion
		led : out std_logic;

		pine : out std_logic;
		
		--- pwm
		pwm_1  : out std_logic;
		pwm_2  : out std_logic;
		pwm_3  : out std_logic;
		pwm_4  : out std_logic);
end SISTEMA;

architecture PRACTICA of SISTEMA is
	--componentes utilizados
	
	--Los componentes para las memorias ya est�n definidos en un package 
	--  en la unidad memorias.vhd
	
	--CPU
	component CPU is
		port(
			P_WAIT : in STD_LOGIC;
			D_WAIT : in STD_LOGIC;
			CLK : in STD_LOGIC;
			NRST : in STD_LOGIC;
			P_DATAIN : in STD_LOGIC_VECTOR(15 downto 0);
			D_DATAIN : in STD_LOGIC_VECTOR(15 downto 0);
			P_REQ : out STD_LOGIC;
			D_WR : out STD_LOGIC;
			D_REQ : out STD_LOGIC;
			P_ADDR : out STD_LOGIC_VECTOR(7 downto 0);
			D_ADDR : out STD_LOGIC_VECTOR(7 downto 0);
			D_DATAOUT : out STD_LOGIC_VECTOR(15 downto 0)
			);
	end component;	  
	
	component p_ram is
		generic (
			l : integer;
			w : integer
			);
		port (
			addr : in std_logic_vector(l-1 downto 0); 
			dataout : out std_logic_vector(w-1 downto 0)
			);
	end component;
	
	component d_ram is
		generic (
			l : integer;
			w : integer
			);
		port (
			addr: in  std_logic_vector(l-1 downto 0);
			we : in  std_logic;	 
			d_req : in std_logic;
			clk : in  std_logic;
			datain : in  std_logic_vector(w-1 downto 0);
			dataout : out std_logic_vector(w-1 downto 0)
			);
	end component;	
	
	component pwm4 is
		port (
			clk    : in  std_logic;          -- Reloj
			reset  : in  std_logic;					   
			
			addr   : in  std_logic_vector(7 downto 0);  -- Bus de direcciones
			data   : in  std_logic_vector(15 downto 0); -- Bus de datos		
			d_req  : in  std_logic;                     -- Indicador de enable de bus 
			we     : in  std_logic;                     -- Indicador de escritura
			
			pwm_1  : out std_logic;          -- pwm1
			pwm_2  : out std_logic;          -- pwm2
			pwm_3  : out std_logic;          -- pwm3
			pwm_4  : out std_logic);         -- pwm4
	end component;
	
	component presmod50
  	port (clk     : in std_logic; -- Reloj
        	clear   : in std_logic;
        	q       : out std_logic); --Salida         
	end component;
	
	component BUFG 
   	port (O : out STD_ULOGIC; 
      	   I : in STD_ULOGIC); 
	end component; 
	
	--se�ales internas
	signal P_DATAIN : STD_LOGIC_VECTOR(15 downto 0);
	signal D_DATAIN : STD_LOGIC_VECTOR(15 downto 0);
	signal P_REQ : STD_LOGIC;
	signal D_WR_I : STD_LOGIC;
	signal D_REQ_I : STD_LOGIC;
	signal P_ADDR : STD_LOGIC_VECTOR(7 downto 0);
	signal D_ADDR :  STD_LOGIC_VECTOR(7 downto 0);
	signal D_DATAOUT_I : STD_LOGIC_VECTOR(15 downto 0);

	signal inv_reset : std_logic;
	signal clk50      : std_logic;
	
begin
	
	-- Led de actividad
	led <= not nrst;

   -- BUFG
	-- El pulsador pone un 1 cuando se pulsa
	reloj_buf : bufg
	port map(
		i => not nrst,
		o => inv_reset);

	PRES1 : presmod50 port map (
         clk   => clk,
         clear => inv_reset,
         q     => clk50);

	--instanciaci�n de componentes
	--procesador
	PROCESADOR: CPU
	port map(
		P_ADDR=> P_ADDR,
		P_DATAIN=> P_DATAIN,
		P_REQ=>P_REQ,
		P_WAIT=> '0', 
		D_WR=>D_WR_I,
		D_DATAIN=>D_DATAIN,
		D_DATAOUT=> D_DATAOUT_I,
		D_REQ=> D_REQ_I,
		D_WAIT=> '0', 
		D_ADDR=> D_ADDR,
		CLK=> clk50,
		nRST=> inv_reset
		);		
	
	code_ram : p_ram 
	generic map (
		l => 8,
		w => 16
		)
	port map (
		addr => p_addr,	 
		dataout => p_datain
		);
	
	data_ram : d_ram
	generic map (
		l => 8,
		w => 16
		)
	port map (
		addr => d_addr,
		we => d_wr_i,	   
		d_req => d_req_i,
		clk => clk50,
		datain => d_dataout_i,
		dataout => d_datain
		);
	
   pine <= d_addr(7);

	cuatro_pwm : pwm4
	port map(
		clk => clk50,
		reset => inv_reset,
		
		addr => d_addr,
		data => d_dataout_i,
		d_req => d_req_i,
		we => d_wr_i,	 
		
		pwm_1 => pwm_1,
		pwm_2 => pwm_2,
		pwm_3 => pwm_3,
		pwm_4 => pwm_4);
	
end PRACTICA;
