-------------------------------------------------------------------------------
-- pwm1.vhd. Juan Gonzalez. Mayo-2003
-------------------------------------------------------------------------------
-- Licencia GPL
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity pwm1 is
  
  port (
    clk   : in  std_logic;                -- Reloj
    reset : in  std_logic;
    pwm   : out std_logic);               -- pwm

end pwm1;

architecture test of pwm1 is

  component comparador
    port (
    opa : in  std_logic_vector(10 downto 0);  -- Operador A
    opb : in  std_logic_vector(7 downto 0);   -- Operador B
    o   : out std_logic);                     -- Salida pwm
  end component;

  component presmod10 
    port (clk     : in std_logic; -- Reloj
          clear   : in std_logic;
          q       : out std_logic); --Salida         
  end component;

  component contador
    port (clk   : in std_logic; -- Reloj
	  reset : in std_logic;
	  q     : out std_logic_vector (10 downto 0)); --Salida          
  end component;

signal ntics     : std_logic_vector(10 downto 0);
signal servo_pos : std_logic_vector(7 downto 0);
signal clk10     : std_logic;

  
begin  -- test

PRES1 : presmod10 port map (
          clk   => clk,
          clear => reset,
          q     => clk10);

CONT1 : contador port map (
          clk   => clk10,
          reset => reset,
          q     => ntics);

        -- Comparador
COMP1 : comparador port map (
          opa => ntics,
          opb => servo_pos,
          o   => pwm);


  -- Posicion del servo
  servo_pos <= "10000000";
  
end test;

