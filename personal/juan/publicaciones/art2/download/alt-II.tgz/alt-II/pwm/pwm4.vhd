-------------------------------------------------------------------------------
-- pwm4.vhd. Juan Gonzalez. Mayo-2003
-------------------------------------------------------------------------------
-- Licencia GPL
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity pwm4 is
	
	port (
		clk    : in  std_logic;          -- Reloj
		reset  : in  std_logic;					   
		
		addr   : in  std_logic_vector(7 downto 0);  -- Bus de direcciones
		data   : in  std_logic_vector(15 downto 0); -- Bus de datos		
		d_req  : in  std_logic;                     -- Indicador de enable de bus 
		we     : in  std_logic;                     -- Indicador de escritura
		
		pwm_1  : out std_logic;          -- pwm1
		pwm_2  : out std_logic;          -- pwm2
		pwm_3  : out std_logic;          -- pwm3
		pwm_4  : out std_logic);         -- pwm4
	
end pwm4;

architecture test of pwm4 is
	
	component comparador
		port (
			opa : in  std_logic_vector(10 downto 0);  -- Operador A
			opb : in  std_logic_vector(7 downto 0);   -- Operador B
			o   : out std_logic);                     -- Salida pwm
	end component;

	component presmod10 
		port (clk     : in std_logic; -- Reloj
			clear   : in std_logic;
			q       : out std_logic); --Salida         
	end component;
	
	component contador
		port (clk   : in std_logic; -- Reloj
			reset : in std_logic;
			q     : out std_logic_vector (10 downto 0)); --Salida          
	end component;
	
	signal ntics      : std_logic_vector(10 downto 0);
	signal servo1_pos : std_logic_vector(7 downto 0);
	signal servo2_pos : std_logic_vector(7 downto 0);
	signal servo3_pos : std_logic_vector(7 downto 0);
	signal servo4_pos : std_logic_vector(7 downto 0);
	signal clk10      : std_logic;
	
	signal internal_addr : std_logic_vector(6 downto 0);
	signal enable : std_logic;  
	
	
begin  -- test

	PRES1 : presmod10 port map (
		clk   => clk,
		clear => reset,
		q     => clk10);
	
	CONT1 : contador port map (
		clk   => clk10,
		reset => reset,
		q     => ntics);
	
	-- Comparador
	COMP1 : comparador port map (
		opa => ntics,
		opb => servo1_pos,
		o   => pwm_1);
	
	COMP2 : comparador port map (
		opa => ntics,
		opb => servo2_pos,
		o   => pwm_2);
	
	COMP3 : comparador port map (
		opa => ntics,
		opb => servo3_pos,
		o   => pwm_3);
	
	COMP4 : comparador port map (
		opa => ntics,
		opb => servo4_pos,
		o   => pwm_4);
	
	internal_addr <= addr(6 downto 0);
	enable <= addr(7);
	
	-- Posicion del servo	   
	
	process(reset, clk) 
	begin 		 
		if(reset = '1') then
			servo1_pos <= (others => '0');
			servo2_pos <= (others => '0');
			servo3_pos <= (others => '0');
			servo4_pos <= (others => '0');
		elsif (clk = '0' and clk'event) then 
			if(enable = '1' and d_req = '1') then
				if (we = '1') then 			
					if(internal_addr = "0000000") then
						servo1_pos <= data(7 downto 0);
						servo2_pos <= data(15 downto 8);
					elsif(internal_addr = "0000001") then
						servo3_pos <= data(7 downto 0);
						servo4_pos <= data(15 downto 8);
					end if;
				end if;
			end if;
		end if; 
	end process; 	
	
end test;

