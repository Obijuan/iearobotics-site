--------------------------------------------------------
-- cont5.vhdl.  Juan Gonzalez. Mayo-2003              --
-- Licencia GPL.                                      --
--------------------------------------------------------
-- Contador de 5 bits                                 --
--------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity cont5 is
  port (clk   : in std_logic; -- Reloj
        clear : in std_logic;
        q     : out std_logic_vector (4 downto 0)); --Salida         
end cont5;

architecture beh of cont5 is
signal cuenta : std_logic_vector (4 downto 0);

begin
  output: process(clk,clear)
  begin
    if (clear='0') then
      cuenta<="00000";
    elsif (clk'event and clk='1') then
      if cuenta="11100" then
         cuenta<="00000";
      else
        cuenta<=(cuenta+1);
      end if;
    end if; 
  end process;

  q<=cuenta;
  
end beh;
