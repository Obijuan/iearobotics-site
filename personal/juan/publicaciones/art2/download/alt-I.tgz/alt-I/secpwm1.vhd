-------------------------------------------------------------------------------
-- secpwm1.  Juan Gonzalez. Mayo-2003
-------------------------------------------------------------------------------
-- Licencia GPL
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity secpwm1 is
  
  port (
    clk   : in  std_logic;
    reset : in  std_logic;
    pwm   : out std_logic);

end secpwm1;

architecture test of secpwm1 is

component comparador
  port (opa : in std_logic_vector(10 downto 0);  -- Operador A
        opb : in std_logic_vector(7 downto 0);   -- Operador B
	o   : out std_logic);                    -- Salida pwm         
end component;

component contador
  port (clk   : in std_logic; -- Reloj
       	reset : in std_logic;
       	q     : out std_logic_vector (10 downto 0)); --Salida         
end component;

component presmod10
  port (clk     : in std_logic; -- Reloj
        clear   : in std_logic;
        q       : out std_logic); --Salida         
end component;

component sec8
  port (clk   : in  std_logic;
        reset : in  std_logic;
        data  : out std_logic_vector(4 downto 0));
end component;

component prescaler20
  port (pres_clk  : in std_logic;
        pres_reset: in std_logic;
        pres_q    : out std_logic);  
end component;

signal cuenta : std_logic_vector(10 downto 0);
signal posicion : std_logic_vector(7 downto 0);
signal posicion32 : std_logic_vector(31 downto 0);
signal clk10 : std_logic;
signal clk20 : std_logic;

begin  -- test

COMP1: comparador port map (
         opa => cuenta,
         opb => posicion,
         o   => pwm);

CONT1: contador port map (
         clk   => clk10,
         reset => reset,
         q     => cuenta);

PRES1 : presmod10 port map (
         clk   => clk,
         clear => reset,
         q     => clk10);

SEC1 : sec8 port map (
         clk   => clk20,
         reset => reset,
         data  => posicion32);

  posicion<=posicion32(31 downto 24); 

PRES2 : prescaler20 port map (
          pres_clk   => clk,
          pres_reset => reset,
          pres_q     => clk20);
  
end test;


