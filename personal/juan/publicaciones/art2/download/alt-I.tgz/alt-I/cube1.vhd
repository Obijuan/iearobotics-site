-------------------------------------------------------------------------------
-- cube1.  Juan Gonzalez. Mayo-2003
-------------------------------------------------------------------------------
-- Licencia GPL
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity cube1 is
  
  port (
    clk   : in  std_logic;
    reset : in  std_logic;
    sel   : in  std_logic_vector(2 downto 0);
    pwm1   : out std_logic;
    pwm2   : out std_logic;
    pwm3   : out std_logic;
    pwm4   : out std_logic);

end cube1;

architecture test of cube1 is

component comparador
  port (opa : in std_logic_vector(10 downto 0);  -- Operador A
        opb : in std_logic_vector(7 downto 0);   -- Operador B
	o   : out std_logic);                    -- Salida pwm         
end component;

component contador
  port (clk   : in std_logic; -- Reloj
       	reset : in std_logic;
       	q     : out std_logic_vector (10 downto 0)); --Salida         
end component;

component presmod10
  port (clk     : in std_logic; -- Reloj
        clear   : in std_logic;
        q       : out std_logic); --Salida         
end component;

component sec8
  port (clk   : in  std_logic;
        reset : in  std_logic;
        data  : out std_logic_vector(4 downto 0));
end component;

component prescaler20
  port (pres_clk  : in std_logic;
        pres_reset: in std_logic;
        pres_q    : out std_logic_vector(7 downto 0));  
end component;

signal cuenta : std_logic_vector(10 downto 0);
signal posicion1 : std_logic_vector(7 downto 0);
signal posicion2 : std_logic_vector(7 downto 0);
signal posicion3 : std_logic_vector(7 downto 0);
signal posicion4 : std_logic_vector(7 downto 0);
signal posicion32 : std_logic_vector(31 downto 0);
signal relojes : std_logic_vector(7 downto 0);
signal clk10 : std_logic;
signal clk20 : std_logic;

begin  -- test

     -- PWM 1
COMP1: comparador port map (
         opa => cuenta,
         opb => posicion1,
         o   => pwm1);

     -- PWM2
COMP2: comparador port map (
         opa => cuenta,
         opb => posicion2,
         o   => pwm2);

     -- PWM 3
COMP3: comparador port map (
         opa => cuenta,
         opb => posicion3,
         o   => pwm3);

     -- PWM 4
COMP4: comparador port map (
         opa => cuenta,
         opb => posicion4,
         o   => pwm4);

CONT1: contador port map (
         clk   => clk10,
         reset => reset,
         q     => cuenta);

PRES1 : presmod10 port map (
         clk   => clk,
         clear => reset,
         q     => clk10);

SEC1 : sec8 port map (
         clk   => clk20,
         reset => reset,
         data  => posicion32);

  posicion1<=posicion32(31 downto 24);
  posicion2<=posicion32(23 downto 16);
  posicion3<=posicion32(15 downto 8);
  posicion4<=posicion32(7  downto 0);

  clk20<=relojes(0) when sel="000" else
         relojes(1) when sel="001" else
         relojes(2) when sel="010" else
         relojes(3) when sel="011" else
         relojes(4) when sel="100" else
         relojes(5) when sel="101" else
         relojes(6) when sel="110" else
         relojes(7) when sel="111" else '0';

PRES2 : prescaler20 port map (
          pres_clk   => clk,
          pres_reset => reset,
          pres_q     => relojes);
  
end test;

