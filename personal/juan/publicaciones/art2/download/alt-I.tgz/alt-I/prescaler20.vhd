------------------------------------------------------------
-- prescaler20.vhd.  Juan Gonzalez. Mayo-2003             --
-- Licencia GPL.                                          --
-----------------------------------------------------------------
-- Prescaler de 20 bits                                        --
--                                                             --
-- Entradas: pres_clk   : Reloj                                --
--           pres_reset : Puesta a cero asíncrona             --
-- Salidas:                                                    --
--           pres_q : Salida                                   --
-----------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;

entity prescaler20 is
  port (pres_clk  : in std_logic;
        pres_reset: in std_logic;
        pres_q    : out std_logic_vector(7 downto 0));  
end prescaler20;

architecture beh of prescaler20 is

  signal cuenta : std_logic_vector(19 downto 0);

begin
  output: process(pres_clk,pres_reset)
  begin
    -- Actualizar la cuenta
    if (pres_reset='0') then
      cuenta<=(others=>'0');
    elsif (pres_clk'event and pres_clk='1') then
      cuenta<=(cuenta+1);
    end if;
  end process;

  pres_q<=cuenta(19 downto 12);
  
end beh;

