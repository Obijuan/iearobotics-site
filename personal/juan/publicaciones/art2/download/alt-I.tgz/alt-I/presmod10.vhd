--------------------------------------------------------
-- presmod10.vhdl.  Juan Gonzalez. Mayo-2003          --
-- Licencia GPL.                                      --
--------------------------------------------------------
-- Prescaler modulo 10 (divide se�al por 10)          --
--                                                    --
-- Entradas: clk : Senal de reloj                     --
--           clear: Puesta a cero asincrona (NB)      --
-- Salidas:                                           --
--      -q: Se�al de salida                           --
--------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;


entity presmod10 is
  port (clk     : in std_logic; -- Reloj
        clear   : in std_logic;
        q       : out std_logic); --Salida         
end presmod10;

architecture beh of presmod10 is
signal cuenta : std_logic_vector (3 downto 0);

begin
  output: process(clk,clear)
  begin
    if (clear='0') then
      q<='0';
      cuenta<="0000";
    elsif (clk'event and clk='1') then
      if cuenta="1001" then
        cuenta<="0000";
        q<='0';
      else
        cuenta<=(cuenta+1);
        q<=cuenta(3);
      end if;
    end if; 
  end process;
end beh;


