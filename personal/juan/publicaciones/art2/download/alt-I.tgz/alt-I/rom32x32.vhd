library ieee;
use ieee.std_logic_1164.all;

entity rom32x32 is
  port (
    abus : in  std_logic_vector(4 downto 0);   -- Direccion
    dbus : out std_logic_vector(31 downto 0));  -- Datos
end rom32x32;

architecture test of rom32x32 is

begin  -- test
 process (abus) 
 begin 
   case abus is 
     when "00000" => dbus <= X"98516B9B";
     when "00001" => dbus <= X"9D56629D";
     when "00010" => dbus <= X"9B61599D";                   
     when "00011" => dbus <= X"9B67549A";
     when "00100" => dbus <= X"99704D98";
     when "00101" => dbus <= X"947A4A90";
     when "00110" => dbus <= X"90814A88";
     when "00111" => dbus <= X"88884883";
                     
     when "01000" => dbus <= X"81904A7A";       -- 16
     when "01001" => dbus <= X"7A944D73";
     when "01010" => dbus <= X"73985368";
     when "01011" => dbus <= X"689D5662";
     when "01100" => dbus <= X"619B5F5B";                   
     when "01101" => dbus <= X"599B6754";
     when "01110" => dbus <= X"5399704F";
     when "01111" => dbus <= X"4D947A4A";

     when "10000" => dbus <= X"488F8348";       -- 24
     when "10001" => dbus <= X"4A848C48";
     when "10010" => dbus <= X"4A7E924B";                   
     when "10011" => dbus <= X"4C75984D";
     when "10100" => dbus <= X"516B9B55";
     when "10101" => dbus <= X"5D5D9D62";
     when "10110" => dbus <= X"64559B6B";
     when "10111" => dbus <= X"6B519873";
                     
     when "11000" => dbus <= X"734D937D";       -- 32
     when "11001" => dbus <= X"7D488F83";
     when "11010" => dbus <= X"844A868A";
     when "11011" => dbus <= X"8C4A7E91";
     when "11100" => dbus <= X"934C7596";                   
     when others => dbus <=X"00000000";
   end case; 
end process; 
end test;











