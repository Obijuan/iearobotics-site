-------------------------------------------------------------------------------
-- sec8.vhd. Juan Gonzalez. Mayo-2003
-------------------------------------------------------------------------------
-- Secuenciador de 8 posiciones. (contador + memoria rom)
-------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;


entity sec8 is
  port (clk   : in  std_logic;
        reset : in  std_logic;
        data  : out std_logic_vector(31 downto 0));
end sec8;

architecture test of sec8 is

  component rom32x32
    port (
      abus : in  std_logic_vector(2 downto 0);   -- Direccion
      dbus : out std_logic_vector(7 downto 0));  -- Datos
  end component;

 component cont5
    port (clk   : in std_logic; -- Reloj
        clear : in std_logic;
        q     : out std_logic_vector (2 downto 0)); --Salida         
 end component;
  
  signal dir : std_logic_vector(4 downto 0);
  
begin  -- test of tb_rom8x8

  -- Contador de acceso a la memoria
  CONT1 : cont5 port map (
            clk   => clk,
            clear => reset,
            q     => dir);

  -- Memoria
  ROM1 : rom32x32 port map (
           abus => dir,
           dbus => data);
  
end test;

