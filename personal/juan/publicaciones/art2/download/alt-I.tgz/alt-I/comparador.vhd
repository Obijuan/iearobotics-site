------------------------------------------------------
-- comparador.vhdl.  Juan Gonzalez. Mayo-2003       --
-- Licencia GPL.                                    --
------------------------------------------------------
-- PROYECTO CUBE-FPGA                               --
------------------------------------------------------
-- Comparador para la implementacion de una unidad  --
-- de PWM.                                          --
------------------------------------------------------
-- Comparador de 8 bits                             --
------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

entity comparador is
  port (opa : in std_logic_vector(10 downto 0);  -- Operador A
        opb : in std_logic_vector(7 downto 0);   -- Operador B
	o   : out std_logic);                    -- Salida pwm         
end comparador;

architecture beh of comparador is

signal sg  : std_logic;
signal pos : std_logic_vector(7 downto 0);
signal msb : std_logic_vector(2 downto 0);

begin

 -- Obtener los 8 bits menos significativos de la entrada a
 -- (la posicion en la que se quiere poner el servo)
  pos<=opa(7 downto 0);

 -- Este es el comparador
  process (pos, opb)
  begin
    if (pos<opb) then
      sg <= '0'; 
    else
      sg <= '1';
    end if;
  end process;

  
  -- Se�al PWM de salida
  o<= (not opa(8)) and (not opa(9)) and (not opa(10)) 
           and (not sg);

end beh;


