/*********************************************************/
/* Angulo.cs   (c) Juan Gonzalez Gomez.  Junio 2004      */
/*-------------------------------------------------------*/
/* Clase Angulo. Manipulacion de angulos, en grados y    */
/* radianes                                              */
/*-------------------------------------------------------*/
/* LICENCIA GPL                                          */
/*********************************************************/
/*-------------------------------------------------------------------------
 $Id: Angulo.cs,v 1.1 2005/01/23 22:37:59 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/Angulo.cs,v $
---------------------------------------------------------------------------*/

using System;

/*! \example test-Angulo.cs
    Programa para hacer pruebas de la clase Angulo
*/


//-------------------------------------------------------------
/*! Esta clase permite trabajar con angulos con independencia    
    de las unidades empleadas (grados o radianes). Una vez       
    creados los objetos Angulo, se pueden hacer operaciones con
    ellos. Por defecto, siempre que se emplee un valor numerico,
    se considerara que esta en grados.                           
 \brief  Trabajar con angulos de una forma abstracta,
         independientemente de si esta en radianes o grados      */
//-----------------------------------------------------------------
public class Angulo {

  /*----------------*/
  /* CONSTRUCTORES  */
  /*----------------*/
	
  /*! Constructor por defecto. Se crea un angulo inicializado a 0 
      \brief Crear un angulo nuevo inicializado a 0 
  */
	public Angulo() {
	  this.AngRad=0.0;
	}
	
  /*! CONSTRUCTOR. Se crea un angulo en grados  
        @param ang Valor del angulo en grados
      \brief Crear un angulo nuevo en grados  
  */
  public Angulo(double ang) {
    //-- Internamente el angulo se guarda en radianes
	  this.AngRad=(Math.PI*ang)/180.0;
	}
	
	/*! COPY CONSTRUCTOR. Copiar un angulo. Se crea un angulo nuevo, que es 
     una copia el angulo pasado
     @param ang Angulo                                           
     \brief Copiar un angulo
  */
	public Angulo(Angulo ang) {
	  this.AngRad=ang.Rad;
	}

  /*--------------------*/
	/* METODOS ESTATICOS  */
	/*--------------------*/

  /*--------------*/
  /*- PROPIEDADES */
  /*--------------*/
  /*! Leer o establecer el angulo en radianes
      \brief Angulo en Radianes [get, set]
  */       
  public double Rad {
    get {
	    return this.AngRad;
  	}
	  set {
	    this.AngRad=value;
	  }
  }

  /*! Leer o establecer el angulo en grados
      \brief Angulo en Grados [get, set]
  */
  public double Grad {
    get {
	    return (180*this.AngRad)/Math.PI;
	  }
    set {
	    this.AngRad=(Math.PI*value)/180;
	  }
  }  

  /*------------------------*/
  /* METODOS SOBRECARGADOS  */
  /*------------------------*/
  /*!  Metodo para poder imprimir el angulo en grados. Esto permite
       hacer cosas del tipo: Console.WriteLine("Angulo: {0}",ang),
       siendo 'ang' un objeto de tipo Angulo.
       \brief Convertir el angulo a una cadena
  */     
  public override string ToString() {
    String s = String.Format("{0:f3}",this.Grad);
    return s;
  }

  /*----------------------------*/
	/* SOBRECARGA DE OPERADORES   */
	/*----------------------------*/
	
	/*! Operador ==. Devuelve true si los angulos son iguales.
      Ejemplo: if (a==b) ..
      \brief IGUALDAD de angulos
  */
	public static bool operator == (Angulo a, Angulo b) {
	  return a.Rad == b.Rad;
	}
	
	/*! Operador !=. Devuelve true si los angulos son diferentes
      Ejemplo: if (a!=b) ..
      \brief DESIGUALDAD de angulos
  */
	public static bool operator != (Angulo a, Angulo b) {
	  return a.Rad != b.Rad;
	}
	
	//-- Igualdad
	public override bool Equals(object o) {
	  if (!(o is Angulo)) {
		  return false;
		}
		return this == (Angulo) o;
	}
	
	//-- Esto no lo entiendo muy bien... hay que ponerlo para
	//-- que no salga un warning al compilar...
	public override int GetHashCode() {
    return 1;
  }
	
	/*! Operador +. Ejemplo: a = b + c 
      \brief SUMA de dos angulos. 
  */
	public static Angulo operator + (Angulo a, Angulo b) {
    Angulo resultado = new Angulo();
    resultado.Rad=a.Rad + b.Rad;
	  return resultado;
	}

  /*! Operador - binario. Ejemplo: a = b - c 
      \brief RESTA de dos angulos
  */
	public static Angulo operator - (Angulo a, Angulo b) {
    Angulo resultado = new Angulo();
    resultado.Rad=a.Rad - b.Rad;
	  return resultado;
	}
	
	/*! Operacion "-" unaria. Ejemplo: a = -b
     \brief  Cambiar de signo el angulo.
  */
	public static Angulo operator - (Angulo a) {
    Angulo resultado = new Angulo();
    resultado.Rad=-a.Rad;
	  return resultado;
	}
	
	/*! Operacion Angulo * constante. Ejemplo: b = a * 4.3 .
      Esta operacion es conmutativa. Tambien se puede
      realizar la operacion cte*a
      \brief Multiplicacion por constante
  */
	public static Angulo operator * (Angulo a, double cte) {
    Angulo resultado = new Angulo();
    resultado.Rad = a.Rad * cte;
	  return resultado;
	}
	
	//-- Para que la operacion Angulo*cte sea conmutativa.
	public static Angulo operator * (double cte, Angulo a) {
	  return a*cte;
	}

  /*-------------------------*/
  /* PROPIEDADES PRIVADAS    */
  /*-------------------------*/
  double AngRad;    //-- Angulo en radianes

}
