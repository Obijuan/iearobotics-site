//********************************************************************
//* test-Funcion.cs   (c) Juan Gonzalez.  Marzo 2005                 *
//*------------------------------------------------------------------*
//*  Pruebas de la clase Funcion                                     *
//*------------------------------------------------------------------*
//* Licencia GPL                                                     *
//********************************************************************
/*-------------------------------------------------------------------------
 $Id: test-Funcion.cs,v 1.1 2005/03/20 23:25:45 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-Funcion.cs,v $
---------------------------------------------------------------------------*/

using System;

class Test_Funcion
{
  static void Main()
  {
    //--------------------------------------------------------
    //-- Pruebas de construccion de las funciones primitivas  
    //--------------------------------------------------------
    Console.WriteLine("Prueba de la clase Funcion");
    Console.WriteLine("Construccion de funciones:");
    
    //-- Crear dos funciones constantes
    FuncionCte f1 = new FuncionCte(5);
    FuncionCte f2 = new FuncionCte(6);
    
    //-- Crear funcion sinusoidal
    FuncionSin f3 = new FuncionSin(15,100,0,5);
    
    //-- Crear funcion semisinusoidal
    FuncionSemiSin f4 = new FuncionSemiSin(15,37,277,8);
    
    //-- Crear funcion cuadrada
    FuncionCuadrada f5 = new FuncionCuadrada(10,20,40,5);
    
    //-- Imprimir las funciones
    Console.WriteLine("f1: {0}",f1);
    Console.WriteLine("f2: {0}",f2);
    Console.WriteLine("f3: {0}",f3);
    Console.WriteLine("f4: {0}",f4);
    Console.WriteLine("f5: {0}",f5);
    Console.WriteLine("f1(0,0)={0}",f1.Valor(0,0));
    Console.WriteLine("f2(0,0)={0}",f2.Valor(0,0));
    
   
    //----------------------------------------
    //-- Pruebas de combinacion de funciones
    //----------------------------------------
    Console.WriteLine("\nOperaciones con funciones:");
    Funcion f6 = 2*f2-f1;
    Console.WriteLine("f6: {0}",f6);
    Console.WriteLine("f6(0,0)={0}",f6.Valor(0,0));
    
    Funcion f7 = f4 + f3 + 7;
    Console.WriteLine("f7: {0}",f7);
    Console.WriteLine("f7(1,0)={0}",f7.Valor(1,0));
    
  }
}
