//*******************************************************************
//* test-GGusano.cs   (c) Juan Gonzalez.  Marzo 2005                *
//*-----------------------------------------------------------------*
//* Ejemplo de prueba de la clase GGusano                           *
//* Para dibujar se utiliza un doble buffer                         *
//*-----------------------------------------------------------------*
//* Licencia GPL                                                    *
//*******************************************************************
/*-------------------------------------------------------------------------
 $Id: test-GGusano.cs,v 1.1 2005/03/21 12:47:48 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-GGusano.cs,v $
---------------------------------------------------------------------------*/
using Gtk;
using System;

class Test_GGusano
{
  /*-----------------------------*/
  /*  PROPIEDADES                */
  /*-----------------------------*/
  //-- Buffer donde dibujar
  static Gdk.Pixmap pixmap;
  
  //-- Area de dibujo
  static Gtk.DrawingArea darea;
  
  //-- Funcion a dibujar
  static GGusano gg1;
  
  //-- Colores
  static Gdk.GC pen_rojo;
  static Gdk.GC pen_azul;
  
  /*------------------------------*/
  /*  METODOS                     */
  /*------------------------------*/
  public static void Main (string[] args)
  {
    new Test_GGusano (args);
  }

  public Test_GGusano (string[] args)
  {
    //-- Inicializar las GTK
    Application.Init();
    
    //-- Crear el interfaz: una ventana y un "Drawing Area"
    Window window = new Window ("Test-GGusano");
    window.DeleteEvent += new DeleteEventHandler (OnWindowDeleteEvent);
    darea = new DrawingArea();
    window.Add(darea);
    window.SetDefaultSize (400, 200);
    window.ShowAll();
    
    //-- Funciones de retro-llamada del "Drawing Area"
    darea.ConfigureEvent+=new ConfigureEventHandler (on_configure_event);
    darea.ExposeEvent+=new ExposeEventHandler (on_expose_event);  
    darea.SetSizeRequest (200, 200);
    
    //-- Configurar los pinceles
    configurar_colores();
    
    //-- Crear el gusano
    gg1 = new GGusano(darea, new Gusano(8));
    gg1.Origen=new Vector(100,100);
    gg1.Origen_panel=new Vector(10,40);
    gg1.Radio = 4;
    gg1.Gusano.Lseg = 15.0;
    gg1.Ejex_visible=true;
    gg1.Narts_visibles=true;
    gg1.Panel_visible=true;
    gg1.Art_Color = pen_rojo;
    gg1.Seg_Color = pen_azul;
    
    //-- Que comience la fiesta!!
    Application.Run();
  }

  /**********************************/
  /* Configurar las colores a usar  */
  /**********************************/
  static void configurar_colores()
  {
    //-- Configurar los colores
    Gdk.Color rojo = new Gdk.Color(0xff,0,0);
    Gdk.Color azul  = new Gdk.Color(0,0,0xff);
    
    Gdk.Colormap colormap = Gdk.Colormap.System;        
    colormap.AllocColor (ref rojo, true, true);
    colormap.AllocColor (ref azul,true,true);
    
    //-- Configurar los contextos graficos (pinceles)
    pen_rojo = new Gdk.GC(darea.GdkWindow);
    pen_azul = new Gdk.GC(darea.GdkWindow);
    
    pen_rojo.Foreground = rojo;
    pen_azul.Foreground = azul;
    pen_azul.SetLineAttributes (2, Gdk.LineStyle.Solid,
                                Gdk.CapStyle.Butt,
                                Gdk.JoinStyle.Round);
  }

  //----------------------------------------------------
  //-- Funcion de retrollamada para salir de las GTK
  //----------------------------------------------------
  void OnWindowDeleteEvent (object o, DeleteEventArgs args) 
  {
    Application.Quit ();
    args.RetVal = true;
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada de cambio de tamaño
  //-- Si el area de dibujo tiene un tamano fijo, no se invocara
  //---------------------------------------------------------------
  public void on_configure_event(object o, 
                                              ConfigureEventArgs args)
  {
		Gdk.EventConfigure ev = args.Event;
		Gdk.Window window = ev.Window;
		Gdk.Rectangle allocation = darea.Allocation;

    //-- Crear un pixmap nuevo, con las nuevas dimensiones
		pixmap = new Gdk.Pixmap (window, allocation.Width, allocation.Height, -1);
		
		//-- Borrar el pixmap
		pixmap.DrawRectangle (darea.Style.WhiteGC, true, 0, 0,
					                allocation.Width, allocation.Height);
		    
    //-- Dibujar la funcion
    gg1.Render(pixmap);
    
    //-- Solicitar refresco
    darea.QueueDraw(); 

		args.RetVal = true;
  }                                            
  
  //---------------------------------------------------------------------
  //-- Funcion de retrollamada invocada cada vez que hay que dibujar
  //---------------------------------------------------------------------
  public void on_expose_event(object o, ExposeEventArgs args)
  {
    //-- Llevar el buffer pixmap al area de dibujo
		Gdk.Rectangle area = args.Event.Area;
		args.Event.Window.DrawDrawable (
		          darea.Style.BlackGC,
							pixmap,
							area.X, area.Y,
							area.X, area.Y,
							area.Width, area.Height);

		args.RetVal = false;  
  }
  
  
}
