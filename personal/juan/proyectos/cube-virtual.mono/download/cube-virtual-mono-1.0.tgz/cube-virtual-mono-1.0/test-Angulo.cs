/***********************************************************/
/* test-Angulo.cs.  (c) Juan Gonzalez Gomez. Junio 2004    */
/*---------------------------------------------------------*/
/* Prueba de la clase Angulo                               */
/*---------------------------------------------------------*/
/* LICENCIA GPL                                            */
/***********************************************************/
/*-------------------------------------------------------------------------
 $Id: test-Angulo.cs,v 1.1 2005/01/23 22:37:59 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-Angulo.cs,v $
---------------------------------------------------------------------------*/

using System;

class Test_Angulo
{
  static void Main() {
  
    //-- Pruebas de construccion
		Angulo a1 = new Angulo();
		Angulo a2 = new Angulo(180);
		Angulo a3 = new Angulo(90);
		
		//-- Imprimir los angulos. Por defecto se sacan en grados
		Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3: {2}",
		                  a1, a2, a3);
											
		a1 = new Angulo(20);
		a2 = new Angulo(30);
		a3 = new Angulo(40);
    //-- Si se imprime un angulo se obtiene su valor en grados
		Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3: {2}",
		                  a1, a2, a3);
					
	  //-- Asignacion de angulos;					
		a1 = new Angulo(a2);
		Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3: {2}",
		                  a1.Rad, a2.Rad, a3.Rad);
    Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3: {2}",
		                  a1, a2, a3);
		
		//-- Prueba de las propiedades Rad y Grad
		a1.Grad=180;
		Console.WriteLine("Grados: {0}, Radianes: {1}",a1.Grad, a1.Rad);
		
		a1.Rad=Math.PI;
		Console.WriteLine("Grados: {0}, Radianes: {1}",a1.Grad, a1.Rad);
	 
	  a1.Grad=90;
		Console.WriteLine("Grados: {0}, Radianes: {1}",a1.Grad, a1.Rad);
		
		a1.Rad=Math.PI/2;
		Console.WriteLine("Grados: {0}, Radianes: {1}",a1.Grad, a1.Rad);
		
		//-- Pruebas de la sobrecarga de operadores
		a1.Grad=45;
		a2.Grad=45;
		a3 = a1 + a2;
		Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3=Ang1+Ang2: {2}",
		                   a1.Grad, a2.Grad, a3.Grad);						 
		a1.Rad=Math.PI;
		a2.Grad=30;
		a3 = a1 - a2;
		Console.WriteLine("Ang1: {0}, Ang2: {1}, Ang3=Ang1-Ang2: {2}",
		                  a1.Grad, a2.Grad, (a1-a2).Grad);
		a1.Grad=30;
    a2 = -a1;
    a3 = a1*2;
		Console.WriteLine("Ang1: {0}, Ang2=-Ang1: {1}, Ang3=2*Ang1: {2}",
		                  a1.Grad, a2.Grad, a3.Grad);
											
		//-- Prueba de la igualdad
		a1.Grad=50;
		a2.Grad=50;
		if (a1 == a2) {
		  Console.WriteLine("Ang1: {0}, Ang2: {1}. IGUALES",
		                  a1.Grad, a2.Grad);
		}
		
		//-- Prueba de desigualdad
		a2.Grad=60;
		if (a1 != a2) {
		  Console.WriteLine("Ang1: {0}, Ang2=: {1}. DISTINTOS",
		                  a1.Grad, a2.Grad);
		}
		
	}
}
