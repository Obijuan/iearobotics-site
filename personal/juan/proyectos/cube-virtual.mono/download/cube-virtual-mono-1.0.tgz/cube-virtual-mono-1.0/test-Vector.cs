/***********************************************************/
/* test-Vector.cs.  (c) Juan Gonzalez Gomez. Junio 2004    */
/*---------------------------------------------------------*/
/* Prueba de la clase Vector                               */
/*---------------------------------------------------------*/
/* LICENCIA GPL                                            */
/***********************************************************/
/*-------------------------------------------------------------------------
 $Id: test-Vector.cs,v 1.1 2005/01/23 22:37:59 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-Vector.cs,v $
---------------------------------------------------------------------------*/

using System;

class Test_Vector
{
  static void Main()
  {	
    Console.WriteLine("Pruebas de la clase Vector\n");
  
    /*--------------------------*/
    /* Pruebas de construccion  */
    /*--------------------------*/
    //-- Constructor normal
    Vector v1 = new Vector();
    
    //-- Construccion en cartesianas
    Vector v2 = new Vector(10,20);
    
    //-- Construccion a partir de otro vector
    Vector v3 = new Vector(v2);
    
    //-- Construccion del tipo modulo-argumento
    Vector v4 = new Vector(20,new Angulo(60));
        
    //-- Mostrar los resultados
    Console.WriteLine("Pruebas construccion:");
    Console.WriteLine("v1={0}, v2={1}, v3={2}, v4={3}\n",v1,v2,v3,v4);
    
    /*-----------------------------*/
    /* Pruebas de las propiedades  */
    /*-----------------------------*/
    Console.WriteLine("Pruebas Propiedades:");
    v1=new Vector(10,20);
    Console.WriteLine("Vector v1={0}",v1);
    Console.WriteLine("  -Coordenada x:{0}",v1.x);
    Console.WriteLine("  -Coordenada y:{0}",v1.y);
    v1.x=3;
    v1.y=4;
    Console.WriteLine("Nuevo vector v1={0}",v1);
    Console.WriteLine("  -Modulo: {0}",v1.Modulo);
    Console.WriteLine("  -Arg:    {0}",v1.Arg);
    v1=new Vector(1,1);
    Console.WriteLine("Nuevo Vector v1={0}",v1);
    Console.WriteLine("  -Modulo: {0}",v1.Modulo);
    Console.WriteLine("  -Arg:    {0}",v1.Arg);
    
    //-- Pruebas de asignacion de modulo y argumento
    v1=new Vector(10,new Angulo(60));
    Console.WriteLine("Nuevo vector v1={0}",v1);
    Console.WriteLine("  -Modulo: {0}",v1.Modulo);
    Console.WriteLine("  -Arg:    {0}",v1.Arg);
    
    //-- Cambiamos modulo, dejando argumento
    v1.Modulo=20;
    Console.WriteLine("Nuevo vector v1={0}",v1);
    Console.WriteLine("  -Modulo: {0}",v1.Modulo);
    Console.WriteLine("  -Arg:    {0}",v1.Arg);
    
    //-- Cambiamos argumento, dejando modulo
    v1.Arg=new Angulo(30);
    Console.WriteLine("Nuevo vector v1={0}",v1);
    Console.WriteLine("  -Modulo: {0}",v1.Modulo);
    Console.WriteLine("  -Arg:    {0}",v1.Arg);
    
    /*--------------------------------*/
    /* Pruebas de los metodos         */
    /*--------------------------------*/
    Console.WriteLine();
    Console.WriteLine("Pruebas de METODOS:");
    
    //-- Angulo entre vectores
    v1=new Vector(1,new Angulo(90));
    v2=new Vector(1,new Angulo(45));
    Console.WriteLine("Angulo entre v1 y v2: {0}",v1.Distancia_Angular(v2));
    Console.WriteLine("Angulo entre v2 y v1: {0}",v2.Distancia_Angular(v1));
   
    //-- Vectores Unitarios
    v1=new Vector(20,new Angulo(50));
    v2=v1.Unitario();
    Console.WriteLine("Vector Unitarios: {0}",v2);
    Console.WriteLine("  -Modulo: {0}",v2.Modulo);
    Console.WriteLine("  -Arg:    {0}",v2.Arg);
    
    /*--------------------------------*/
    /* Pruebas de operaciones         */
    /*--------------------------------*/
    Console.WriteLine();
    Console.WriteLine("Pruebas de OPERACIONES:");
    
    v1 = new Vector(10,20);
    v2 = new Vector(1,2);
    //-- Suma
    Console.WriteLine("{0} + {1} = {2}",v1,v2,v1+v2);
    //-- Resta
    Console.WriteLine("{0} - {1} = {2}",v1,v2,v1-v2);
    //-- Combinacion lineal
    Console.WriteLine("2*{0} + 3*{1} = {2}",v1,v2,2*v1+3*v2);
    Console.WriteLine("{0}/2 + {1}/4 = {2}",v1,v2,v1/2 + v2/4);
    //-- Producto Escalar
    Console.WriteLine("{0} * {1} = {2}",v1,v2,v1*v2);
    
    /*---------------------------------*/
    /* Pruebas de igualdad             */
    /*---------------------------------*/
    Console.WriteLine();
    Console.WriteLine("Pruebas de Igualdad");
    
    v1 = new Vector(2,2);
    v2 = new Vector (Math.Sqrt(8),new Angulo(45));
    v3 = new Vector (2.1,2.1);
    Console.WriteLine("{0},{1},{2}",v1,v2,v3);
    if (v1==v2) {
      Console.WriteLine("{0} y {1} son IGUALES",v1,v2);
    }
    if (v1!=v3) {
      Console.WriteLine("{0} y {1} son DIFERENTES",v1,v3);
    }
	}
}
