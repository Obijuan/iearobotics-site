/***********************************************************/
/* Clase Gusano.   (c) Juan Gonzalez Gomez. Enero 2005     */
/*---------------------------------------------------------*/
/* Clase para operar con Gusanos unidimensionales          */
/***********************************************************/
using System;

/*! \example test-Gusano.cs
    Programa para hacer pruebas de la clase Gusano
*/

//----------------------------------------------------------------------
/*! Esta clase permite definir gusanos y trabajar con ellos. Los gusanos
    son en 2D y estan constituidos por articulaciones (Clase Articulacion)
    unidas mediante segmentos. En el mundo real, cada articulacion se
    corresponde con un servo. En el modelo virtual del gusano, es util
    considerar tambien como articulaciones tanto la cola como la cabeza
    <br><br>
    <b>Numeracion de las articulaciones</b><br>
    Las articulaciones se numeran comenzando por la cola (0) y terminado
    con la cabeza (numero de modulos + 1). Asi por ejemplo, un gusano
    con 2 modulos (2 servos) tendra en total 4 articulaciones: <br>
    ---*---*---<br>
    Los  asteriscos son los modulos, que se numeran como 1 y 2. El extermo
    izquierdo es la cola (articulacion 0) y el extremo derecho es la
    cabeza (articulacion 3)<br><br>
    <b>Angulo de las ariculaciones</b>
    Las articulaciones solo pueden tener un angulo interno comprendido 
    entre [-90,90]<br><br>
    <b>Origen de coordenadas</b><br>
    El origen de coordenadas del gusano se toma en la cola.
    El valor (0,0) se corresponde con la posicion inicial de la cola, 
    cuando el gusano esta apoyado completamente sobre el eje x
    \brief  Clase para el manejo de gusanos                           */
//----------------------------------------------------------------------

class Gusano
{
  /******************************/
  /* CONSTRUCTORES              */
  /******************************/
  
  //-------------------------------------------------------------------
  /*! Constructor por defecto. Si no se especifica, se crea uno
      de 8 articulaciones (las que tiene Cube Revolutions)
      \brief CONSTRUCTOR. Crear un gusano                            */
  //------------------------------------------------------------------
  public Gusano() {
    new Gusano(8);
  }
  
  //-------------------------------------------------------------------
  /*! Se crea un gusano nuevo con nmod modulos. El numero minimo de
      modulos es 1 (una articulacion)
      \brief CONSTRUCTOR. Crear un gusano con un numero de modulos   */
  //------------------------------------------------------------------
  public Gusano(int nmod) {
  
    //--Establecer numero de modulos 
    this.nmod=nmod;
    
    //-- Construir el gusano
    Crear_gusano();
  }
  
  //------------------------------------------------------------------
  /*! Constructor de Copia. Crear una copia a partir de un original
      @param g Objeto de tipo Gusano a copiar
      \brief Crear un gusano nuevo, copia de otro                    */
  //------------------------------------------------------------------
  public Gusano(Gusano g) 
  {
    this.nmod = g.nmod;
    this.lseg=g.lseg;
    
    //-- Copiar las articulaciones
    //-- Crear el array
    this.art = new Articulacion[nmod+2];
    
    //-- Copiar todos los elementos
    for (int i=0; i<nmod+2; i++) {
      this.art[i]=new Articulacion(g.art[i]);
    }
   
  }

  //------------------------------------------------------------------
  /*! Especificar el sentido de giro al rotar: DERECHA o IZQUIERDA
      \brief Sentido de giro de rotacion                            */
  //------------------------------------------------------------------    
  public enum Sentido : int
  {
    /*! Sentido.IZQUIERDA */
    IZQUIERDA = 0,
    
    /*! Sentido.DERECHA  */
    DERECHA   = 1,
  }

  /*************************************************************************/
  /*                       METODOS PUBLICOS                                */
  /*************************************************************************/

  //--------------------------------------------------------------------------
  /*! Con este metodo se especifica el angulo de la articulacion
      indicada. Se puede aplicar a cualquier articulacion, incluidas
      la cola y la cabeza. Al rotar la articulacion, se rotan tambien
      todos los elementos que estan conectados. El parametro sentido
      especifica cual de los dos brazos de la articulacion es sobre el
      que se actua. Si se especifica sentido=DERECHA, se mueve el 
      brazo derecho de la articualcion y todo lo que esta conectado.
      <br>
      Si el angulo interno de la articulacion supera alguno de los valores
      extremos (-90,90), se establece el valor tope, de manera que nunca se
      supere esta restriccion
      @param centro Articulacion a rotar. Esta articulacion permanece fija,
                    ya que es el centro de la rotacion
      @param ang    Angulo a rotar la articulacion. Este valor es relativo
                    a la posicion actual. Si se especifica un angulo de 10
                    grados, significa que la articulacion se rotara 10 grados,
                    es decir, que su angulo interno se incrementara en 10,
                    siempre y cuando no supere el tope de 90
      @param sentido Especificar el brazo de la articulacion a rotar. Los
                     valores pueden ser Sentido.DERECHA, Sentido.IZQUIERDA.
     \brief Rotar una articulacion en el sentido especificado              */
  //-------------------------------------------------------------------------   
  public void Rotar(int centro, Angulo ang, Sentido sentido)
  {
  
    //-- Comprobar si el numero de articulacion pasado es correcto
    if (centro<0 || centro>this.nmod+1) {
      Console.WriteLine(
        "Warning: Se intenta rotar un articulacion inexistente");
      return;
    }
  
    //-- Modificar el angulo de posicion de la articulacion
    art[centro].Angulo+=ang;
    
    // ¡¡RESTRICCION!! El angulo de posicion debe estar comprendido 
    // entre -90 y 90 grados. Si se sobrepasa hay que recortar      
  
    if (art[centro].Angulo.Grad>90) {
      // Calcular angulo de giro para que no se sobrepasen los 90 grados 
      ang -= (art[centro].Angulo - new Angulo(90));
      art[centro].Angulo=new Angulo(90);
    }  
    if (art[centro].Angulo.Grad<-90) {
      // Calcular angulo de giro para no sobrepasar los -90 grados    
      ang += new Angulo(Math.Abs(art[centro].Angulo.Grad - 90));
      art[centro].Angulo=new Angulo(-90);
    }  
  
    // Determinar el sentido de rotacion 
    if (sentido==Sentido.DERECHA) {  //-- derecha
    
      // Actualizar desde el centro a la derecha 
      for (int i=centro+1; i<this.nmod+2; i++)
      
        //-- Rotar los puntos
        this.art[i].Vector.Rotar(this.art[centro].Vector,ang);
    }
    else {
      // Actualizar desde centro a la izquierda 
      for (int i=centro-1; i>=0; i--) {
      
        //-- Rotar los puntos
        this.art[i].Vector.Rotar(this.art[centro].Vector,-ang);
      }  
    }    
  }
  
  //------------------------------------------------------------------------
  /*! La articulacion devuelta es una <b>COPIA</b>, de manera que solo puede
      usar para leer datos, no para modificarlos. Si por ejemplo se 
      cambia el angulo de posicion de la articulacion devuelta, no se
      vera afectada la articulacion original
      @param art Numero de articulacion a obtener. El valor
                 debe estar comprendido entre 0 (cola) y Nmod+1, siendo
                 Nmod el numero de modulos del gusano
      \brief Devolver la articulacion solicitada                          */
  //------------------------------------------------------------------------
  public Articulacion Art(int art)
  {
    //-- Comprobar si el numero de articulacion pasado es correcto
    if (art<0 || art>this.nmod+1) {
      Console.WriteLine(
        "Warning: Se intenta acceder a una articulacion inexistente");
  
      //-- Devolver una articulacion inicializada a 0;  
      return new Articulacion();
    }
    return new Articulacion(this.art[art]);
  }
  
  //---------------------------------------------------------------------
  /*! Establecer el estado interno de una articulacion. El metodo Rotar
      hace una rotacion relativa a la posicion actual de la articulacion,
      incrementando o decrementando el angulo interno. El metodo Set_Art
      establece un valor para el angulo.
      @param art Numero de articulacion a modificar. El valor debe estar
                 comprendeido entre 0 (cola) y Nmod+1 (cabeza), siendo
                 Nmod el numero de modulos del gusano
      @param ang Nuevo angulo para la articulacion
      @param sentido El brazo de la articulacion a rotar. Puede ser el
                     derecho o el izquierdo
      \brief Establecer el angulo de una articulacion                   */
  //---------------------------------------------------------------------
  public void Set_Art(int art, Angulo ang, Sentido sentido)
  {
    //-- Comprobar si el numero de articulacion pasado es correcto
    if (art<0 || art>this.nmod+1) {
      Console.WriteLine(
        "Warning: Se intenta acceder a una articulacion inexistente");
      return;
    }
  
    //-- Obtener la posicion actual
    Angulo fi_actual = this.art[art].Angulo;
   
    Rotar(art, ang-fi_actual, sentido);
  }
  
  //-------------------------------------------------------------------------
  /*! Ajustar el gusano sifnifica calcular los angulos de las articulaciones
      de manera que cumplan la ecuacion de la funcion de onda en ese
      instante. Se comienza situando la articulacion de la cola sobre la
      funcion y se van ajustando el resto de articulaciones de izquierda
      a derecha (desde la cola a la cabeza)    
      @param contorno Funcion de contorno a la que ajustar el gusano
      @param t Instante de tiempo para el ajuste      
      \brief Ajustar el gusano a la funcion de contorno                     */
  //--------------------------------------------------------------------------
  public void Ajustar(Funcion contorno, double t)
  {
    double x,y;
    double error_ini;
    double error_fin;
    int ciclos=0;
  
    //-- Primero hay que situar la cola del gusano sobre la funcion
      //-- Coordenada x de la cola
      x=this.art[0].Vector.x;
    
      //-- Valor de la Funcion de contorno f(x,t)
      y=contorno.Valor(x,t);
    
      //-- Mover el gusano a (x,f(x))
      this.Set_Vector(0,new Vector(x,y));
    
    //-- Recorrer las articulaciones, ajustandolas hacia la DERECHA
    for (int i=1; i<=this.nmod+1; i++) {
    
      //-- Primero se realizan algunas iteraciones sobre el angulo 
      //-- de aproximacion, para que converja mas rapidamente
      this.Rotar_aprox(i,contorno,t);
      ciclos=0;
      do {
        error_ini= this.Error_aprox(i,contorno,t);
        this.Rotar_aprox(i,contorno,t);
        error_fin= this.Error_aprox(i,contorno,t);
        ciclos++;
      } while (error_fin<error_ini && ciclos<6);
      
      //-- Despues se ajusta la articulacion
      this.Ajustar_art(i,contorno,t);
    }
    
  }
  
  //-----------------------------------------------------------------
  /*! Devolver una cadena con el vector de posicion angular, que 
       contiene todos los angulos de las articulaciones
       \brief Obtener la cadena con el estado internos (angulos de los
        modulos                                                          */
  //---------------------------------------------------------------------
  public string Cadena_estado()
  {
    String s="";
    
    s+="[";
    for (int i=1; i<=this.nmod; i++) {
      s+= String.Format("{0:f0}",this.art[i].Angulo.Grad);
      if (i<this.nmod) s+=" ";
    }
    s+="]";
    
    return s;
  }
  
  //-----------------------------------------------------------------
  /*! Devolver una cadena con el vector de posicion angular, que 
       contiene todos los angulos de las articulaciones. Solo se devuelve
       el estado desde la articulacion 1 hasta Narts. Si el gusano tiene
       menos de Narts articulaciones, se devuelve 0 en las no existentes
       @param Narts Numero de articulaciones a incluir en la cadena
       \brief Obtener la cadena con el estado internos (angulos de los
        modulos                                                          */
  //---------------------------------------------------------------------
  public string Cadena_estado(int Narts)
  {
    String s="";
    int min;
    
    //-- Obtener el minimo y el maximo entre Narts y this.nmod
    if (Narts<this.nmod) {
      min=Narts;
    }  
    else {
      min=this.nmod;
    }  
    
    //-- Obtener el estado
    s+="[";
    for (int i=1; i<=min; i++) {
      s+= String.Format("{0:f0}",this.art[i].Angulo.Grad);
      if (i<min) s+=" ";
    }
    
    //-- Rellenar con ceros
    for (int i=min+1; i<=Narts; i++) {
      s+= " 0";
      if (i<Narts) s+=" ";
    }
    
    s+="]";
    return s;
  }
  
  //----------------------------------------------------------------------
  /*! Metodo para imprimir. Se obtiene el vector de estado interno
      \brief Obtener la cadena con el estado interno (angulos 
             de los modulos)                                             */
  //-----------------------------------------------------------------------
  public override string ToString() {
    String s="";
    
    s+="[";
    for (int i=1; i<=this.nmod; i++) {
      s+= String.Format("{0:f0}",this.art[i].Angulo.Grad);
      if (i<this.nmod) s+=" ";
    }
    s+="]";
    return s;
  }
  
  //----------------------------------------------------------------------
  /*! Metodo para imprimir el vector con las coordenas X's. Se incluyen
      la cabeza y la cola.
      \brief Obtener la cadena con el vector de coordenadas X            */
  //----------------------------------------------------------------------
  public string XToString() {
    String s="";
    s+="[";
    for (int i=0; i<this.nmod+2; i++) {
      s+= String.Format("{0:f0}",this.art[i].Vector.x);
      if (i<this.nmod+2) s+=" ";
    }
    s+="]";
    return s;
  }
  
  //---------------------------------------------------------------------
  /*! Metodo para imprimir el vector con las coordenadas Y's. Se
      incluyen la cola y la cabeza                                      
      \brief Obtener la cadena con el vector de coordenadas Y          */
  //---------------------------------------------------------------------
  public string YToString() {
    String s="";
    s+="[";
    for (int i=0; i<this.nmod+2; i++) {
      s+= String.Format("{0:f0}",this.art[i].Vector.y);
      if (i<this.nmod+2) s+=" ";
    }
    s+="]";
    return s;
  }
  
  /************************************************************************/
  /*          P R O P I E D A D E S       P U B L I C A S                 */
  /************************************************************************/
  
  //------------------------------------------------------------------------
  /*! Devolver el numero de modulos del gusano. No se incluye la cabeza
      y la cabeza, que no son modulos                                     
      \brief Numero de modulos del gusano (get)                            */
  //------------------------------------------------------------------------    
  public int Nmod {
    get {
      return this.nmod;
    }
  }
  
  //-------------------------------------------------------------------------
  /*! Leer/establecer la longitud del segmento de las articulaciones.
      Cada articulacion tiene dos segmentos, el derecho y el izquierdo.
      El parametro Lseg define la longitud de estos brazos. Si hay dos
      articulaciones unidas, la distancia de sepacion entre ellas sera de
      2*Lseg. <br>
      Al establecer un nuevo valor (SET), se recalcula el gusano. Se 
      respeta el estado interno (angulo de las articulaciones) y la
      cola se deja en la posicion en la que estaba. El resto de coordenadas
      (x,y) de las otras articulaciones seran recalculadas
       \brief Longitud del segmento de las articulaciones                   */
  //--------------------------------------------------------------------------
  public double Lseg {
    get {
      return this.lseg;
    }
    set {
      this.lseg=value;
      //--Obtener angulo alfa (el que forma articulacion 0 con ejex)
      Angulo alfa = this.Angulo_alfa();
      
      //--Hacer copia del estado interno
      estado_interno = new Angulo[nmod+2];
      for (int i=1; i<=nmod; i++) {
        this.estado_interno[i]=new Angulo(this.art[i].Angulo);
      }
      
      //-- Crear un gusano apoyado en eje x
      Crear_gusano();
      
      //-- Establecer el estado interno anterior
      this.Rotar(0,alfa,Sentido.DERECHA);
      for (int i=1; i<=nmod; i++) {
        this.Rotar(i,estado_interno[i],Sentido.DERECHA);
      }
    }
  }
  
  
  //------------------------------------------------------------------------
  //--        M E T O D O S   P R I V A D O S    
  //------------------------------------------------------------------------
  
  /***************************************************************************/
  /* Situar la articulacion especificada en el angulo de aproximacion        */
  /*                                                                         */
  /* SOLO SE HACE UNA ITERACION                                              */
  /*                                                                         */
  /* ENTRADA:                                                                */
  /*   -art : Numero de articulacion sobre la que actuar.                    */
  /*   -t   : Insante de tiempo donde evaluar la funcion de contorno         */
  /*                                                                         */
  /* SALIDA:                                                                 */
  /*  - Se actualizan las coordenadas desde la articulacion pasada como      */
  /*    argumento hasta un extremo.                                          */
  /*  - Se actualiza el angulo de posicion de la articulacion centro         */
  /***************************************************************************/
  private void Rotar_aprox(int art, Funcion contorno, double t)
  {
    int centro;  //-- Articulacion centro de rotacion
    
    //-- La cola no hay que ajustarla
    if (art==0) return;
    
    //-- Si hay que ajustar la articulacion art, el centro de rotacion
    //-- es la articulacion situada a la izquierda
    centro = art - 1;
  
    //-- Vectores de posicion de la articulacion centro y extremo
    Vector vcentro = this.art[centro].Vector;
    Vector vextremo= this.art[art].Vector;
    
    //-- Vector segmento, que une el centro con el extremo
    Vector vseg = vextremo-vcentro;
    
    //-- Vector del punto de aproximacion
    Vector vaprox  = new Vector(vextremo.x,contorno.Valor(vextremo.x,t));
  
    //-- Radio vector. El argumento de este vector, define el angulo
    //-- de aproximacion
    Vector radio = vaprox - vcentro;
    
    //-- Hay que rotar la articulacion un angulo radio.Arg - vseg.Arg
    this.Rotar(centro,radio.Arg - vseg.Arg,Gusano.Sentido.DERECHA);
  }
  
  //----------------------------------------------------------------------
  //-- Obtener el error de aproximacion, aplicado a la articulacion art  
  //-- Este error viene dado por la expresion:
  //--    e(x)=ABS(x^2 + (F(x))^2) - L^2)
  //--    Donde x es la coordenada x del extremo, tomando como origen
  //--    la articulacion centro (la anterior) y L es la longitud
  //--    del segmento que une las articulaciones
  //--    Se devuelve esta funcion NORMALIZADA, para lo que se divide
  //--    entre L^2. El valor devuelto esta multiplicado por 100
  //--- ENTRADAS:
  //--    - extremo: Vector de posicion de la articulacion a calcular
  //--               el error
  //--    - centro : Vector de posicion de la articulacion centro
  //--    - t      : Instante de tiempo donde evaluar la funcion
  //-----------------------------------------------------------------------
  private double Error_aprox(Vector centro, Vector extremo, 
                             Funcion contorno, double t)
  {
    double error;
    
    //-- Calcular el radio vector, el vector que une la articulacion
    //-- centro con la extremo
    Vector radio = extremo-centro;
    
    //-- Valor de la funcion de contorno F(x)
    double F = contorno.Valor(extremo.x,t);
    
    //-- Longitud del segmento al cuadrado
    double L2 = Math.Pow(radio.Modulo,2);
    
    //-- Calcular el error normalizado
    error = Math.Abs(Math.Pow(radio.x,2) + Math.Pow(F,2))/L2 - 1;
    
    return error*100.0;
  }
  
  //------------------------------------------------------------------
  //-  Misma funcion, pero se especifica la articulacion por su
  //-  numero, en vez de por su vector de posicion y el de la 
  //-  articulacion centro
  //-  ENTRADAS:
  //-    -art: Numero de articulacion
  //-    -t  : Instante donde evaluar la funcion
  //-------------------------------------------------------------------
  private double Error_aprox(int art, Funcion contorno, double t)
  {
    if (art==0) return 0.0;
    
    Vector centro = this.art[art-1].Vector;
    Vector extremo= this.art[art].Vector;
    
    return this.Error_aprox(centro,extremo,contorno,t);
  }
   
  /****************************************************************************/
  /* Aplicar el algoritmo de ajuste a la articulacion especificada, respecto  */
  /* de la funcion de contorno                                                */
  /*                                                                          */
  /*  Se aplica el algoritmo sobre la articulacion SIN CALCULAR EL ANGULO     */
  /*  DE APROXIMACION.                                                        */
  /*                                                                          */
  /*  ENTRADA:                                                                */
  /*    -Numero de articulacion sobre la que aplicar el algoritmo             */
  /*    -Funcion de contorno
  /*    -t : Instante de tiempo donde evaluar la funcion de contorno          */
  /*                                                                          */
  /*  SALIDA:                                                                 */
  /*    -Se rota la articulacion centro y se propaga hacia la derecha         */
  /****************************************************************************/
  private void Ajustar_art(int art, Funcion contorno, double t)
 
  {
    Angulo teta=new Angulo();
    int centro;
    double error_ini;
    double error_rot;
  
    //-- La cola no se puede ajustar
    if (art==0) return;
    
    //-- Calcular articulacion centro
    centro = art - 1;
    
    //-- Calcular vectores extremo y centro
    Vector vextremo = new Vector(this.art[art].Vector);
    Vector vcentro  = new Vector(this.art[centro].Vector);
    
    do {
    
      double sentido = contorno.Valor(vextremo.x,t) - vextremo.y;
      sentido = (sentido>0) ? 1 : -1;
      
      //Calcular el error actual 
      error_ini=this.Error_aprox(vcentro,vextremo,contorno,t);
      
      // Rotar 
      vextremo.Rotar(vcentro,new Angulo(sentido*1));
      error_rot = Error_aprox(vcentro,vextremo,contorno,t);
      
      // Se incrementa el angulo a girar solo si se reduce el error
      if (error_rot<=error_ini) teta+= new Angulo((sentido)*1);
      
    }  while (error_rot<=error_ini); 
    
    // Rotar la articulacion extremo para ajustarla 
    this.Rotar(centro,teta,Gusano.Sentido.DERECHA);
    
  }
  
  /***********************************************************/
  /* Establecer las coordenadas x,y de la articulacion       */
  /* especificada del gusano. Automaticamente se re-calculan */
  /* las coordenadas de las demas articulaciones             */
  /***********************************************************/
  private void Set_Vector(int art, Vector v)
  {
    Vector incremento;
    
    //-- Calcular vector de incremento
    incremento = v - this.art[art].Vector;
    
    //-- Calcular los nuevos vectores de posicion de las coordenadas
    for (int i=0; i<this.nmod+2; i++) {
      this.art[i].Vector+=incremento;
    }
  }
  
//-----------------------------------------------------------------  
  
  
  //---------------------------------------------
  //-- Establecer el estado interno del gusano
  //---------------------------------------------
  private void Estado_Interno(Angulo[] ang)
  {
    for (int i=0; i<this.nmod; i++) {
      this.Rotar(i+1,ang[i],Sentido.DERECHA);
    }
  }
  
  /****************************************************************/
  /* Modificar estado externo para que al menos haya un punto de  */
  /* apoyo. El criterio seguido es calcular la coordenada Y minima*/
  /* partiendo de la cola del gusano. En caso de que haya dos     */
  /* articulaciones con la mismo Y, se tomara la situada mas      */
  /* cerca de la cola (la mas izquierda)                          */
  /* DEVUELVE:                                                    */
  /*   -La articulacion apoyada sobre el eje X                    */
  /****************************************************************/
  private int Estabilizar1()
  {
    int art_ymin;
    
    //-- Obtener la articulacion con la Y minima, partiendo de la cola
    //-- hacia la izquierda
    art_ymin=this.Art_Ymin(0,1);
    
    //-- Apoyarla sobre el eje X
    this.Apoyar_art(art_ymin);
    
    return art_ymin;
  }
  
  /**************************************************************/
  /* Devolver la articulacion que tiene la coordenada Y mas     */
  /* pequena. Se recorre el gusano desde la art especificada    */
  /* hacia el sentido especificado                              */
  /**************************************************************/
  private int Art_Ymin(int art, int sentido)
  {
    double ymin;
	  int art_ymin;
	  double y;
	
	  //-- Inicialmente tomamos como minima la articulacion pasada
	  ymin=this.art[art].Vector.y;
	  art_ymin=art;
	
 	  if (sentido==1) { 
	    //-- Recorrer el gusano hacia la derecha
	    for (int i=art+1; i<this.nmod+2; i++) {
	  	  y=this.art[i].Vector.y;
	    	if (y<ymin) { //-- La articulacion actual tiene una Y menor
	  	  	ymin=y;
	  		  art_ymin=i;
	  	  }	
	    }
		  return art_ymin;
	  }

    //-- Recorrer gusano hacian la izquierda
    for (int i=art-1; i>=0; i--) {
	  	y=this.art[i].Vector.y;
		  if (y<ymin) {
			  ymin=y;
			  art_ymin=i;
		  }
	  }		
	
  	return art_ymin;
  }
  
  /*******************************************************************/
  /* Hacer que la articulacion especificada se apoye sobre el eje X  */
  /* Todo el gusano se desplaza                                      */
  /* Pero el estado sigue siendo el mismo                            */
  /* ENTRADAS:                                                       */
  /*   art: Numero de articulacion a apoyar en el suelo              */
  /*******************************************************************/
  private void Apoyar_art(int art)
  {
    Vector v;
    
    //-- Obtener las coordenada x,y de la articulacion
    v=this.Get_Vector(art);
    v.y=0;
    
    //-- Situarla con y=0
    this.Set_Vector(art,v);
    
  }
  
 
  
  /******************************************************/
  /* Devolver el vector de posicon de una articulacion  */
  /******************************************************/
  private Vector Get_Vector(int art)
  {
    return new Vector(this.art[art].Vector);
  }
  
  //-- Devolver el angulo alfa, que es el que forma la articualcion 0
  //-- con el eje x
  private Angulo Angulo_alfa()
  {
    Vector radio;
    
    //-- Obtener el radio vector que une la articulacion 0 con la 1
    radio = this.art[1].Vector - this.art[0].Vector;
    
    return radio.Arg;
  }
  
  //-- Crear un gusano, con el numero de articulaciones indicadas
  private void Crear_gusano() {
    double x=0;
  
    //-- Crear el array de articulaciones. Incluye los modulos 
    //-- mas la cabeza y la cola
    art = new Articulacion[nmod+2];
     
    //-- Crear la cola
    art[0]=new Articulacion(new Angulo(0), new Vector(x,0));
    
    //-- Crear los modulos
    for (int i=1; i<=nmod; i++) {
      x+=lseg;
      art[i]=new Articulacion(new Angulo(0), new Vector(x,0));
      x+=lseg;
    }
    
    //-- Crear la cabeza
    art[nmod+1]=new Articulacion(new Angulo(0), new Vector(x,0));
 
  }
  
  /*----------------------------------------------------------------------*/
  /*       P R O P I E D A D E S     P R I V A D A S                      */
  /*----------------------------------------------------------------------*/
  //-- Numero de modulos que componen el gusano
  private int nmod;
  
  //-- Un gusano es un array de articulaciones. Las articulaciones son
  //-- los modulos mas la cola y la cabeza, en total nmod+2
  private Articulacion[] art;
  
  //-- Copia del estado interno (sin contar cola y cabeza)
  private Angulo[] estado_interno;
  
  //-- Longitud del segmento de cada articulacion
  private double lseg=15;
  
}
