/***************************************************/
/* Clase Articulacion.  Juan Gonzalez. Enero 2005  */
/*-------------------------------------------------*/
/* Clase para modelar las articulaciones de Cube   */
/***************************************************/
using System;

/*! \example test-Articulacion.cs
    Programa para hacer pruebas de la clase Articulacion
*/

//----------------------------------------------------------------------
/*! Los gusanos estan compuestos por articulaciones unidas mediante
    segmentos. Las articulaciones tienen un angulo (fi) que define
    el angulo entre las dos partes moviles de la articulacion. Tambien
    tienen un vector de posicion.
 \brief  Clase para modelar las articulaciones de los gusanos         */
//----------------------------------------------------------------------
public class Articulacion
{

  /********************/
  /* CONSTRUCTORES    */
  /********************/
  //---------------------------------------------------------------------
  /*! CONSTRUCTOR. Se crea una nueva articulacion con el vector y el   
      angulo inicializados a cero.
      \brief Crear una articulacion                                     */
  //---------------------------------------------------------------------
  public Articulacion() {
    this.fi=new Angulo(0);
    this.pos=new Vector(0,0);
  }
  
  //------------------------------------------------------------------------
  /*! CONSTRUCTOR. Se crea una nueva articulacion, a partir de otra ya
      creada.
      @param art Articulacion original
      \brief Crear una articulacion a partir de otra                       */
  //-------------------------------------------------------------------------
	public Articulacion(Articulacion art) {
	  this.fi=new Angulo(art.Angulo);
	  this.pos=new Vector(art.Vector);
	}
	
  //-------------------------------------------------------------------------
  /*! CONSTRUCTOR. Se crea una nueva articulacion con el angulo y 
      vector pasados como argumentos
      @param ang Angulo
      @param v   Vector de posicion
      \brief Crear una articulacion a partir de un angulo y un vector       */
  //-------------------------------------------------------------------------
	public Articulacion(Angulo ang, Vector v) {
	  this.fi=ang;
	  this.pos=v;
	}
  
  /****************************/
  /* PROPIEDADES              */
  /****************************/

  //----------------------------------------------------------------------
  /*! Establecer/leer el angulo de estado de la articulacion
      \brief Angulo de estado de la articulacion                         */
  //----------------------------------------------------------------------
  public Angulo Angulo {
    get {
      return this.fi;
    }
    set {
      fi=value;
    }
  }
  
  //-----------------------------------------------------------------------
  /*! Establecer/leer el vector de posicion de la articulacion
      \brief Vector de posicion de la articulacion                        */
  //------------------------------------------------------------------------
  public Vector Vector {
    get {
      return this.pos;
    }
    set {
      pos=value;
    }
  }
  
  //-- Para hacer pruebas
  public static void test()
  {
    
  }
  
  /*------------------------*/
  /* METODOS SOBRECARGADOS  */
  /*------------------------*/

  //----------------------------------------------------------------
  /*!  Metodo para imprimir la articulacion.
       \brief Convertir la articulacion a una cadena               */
  //----------------------------------------------------------------       
  public override string ToString() {
    String s = String.Format("{0:f3}; {1:f3}",this.pos, this.fi.Grad);
    return s;
  }
  
  /*****************************/
  /* PROPIEDADES PRIVADAS      */
  /*****************************/
  private Angulo fi;   // Angulo de posicion de la articulacion
  private Vector pos;  // Vector de posicion (coordenadas 2d)
}
