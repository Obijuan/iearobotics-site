//*******************************************************************
//* cube-virtual.mono   (c) Juan Gonzalez.  Enero 2005              *
//*-----------------------------------------------------------------*
//* Licencia GPL                                                    *
//*******************************************************************
using System;
using System.IO;
using Gtk;
using Glade;
using Pango;

class GladeApp
{
  /*-----------------------------*/
  /*  PROPIEDADES                */
  /*-----------------------------*/
  //-- Buffer donde dibujar
  Gdk.Pixmap pixmap;
  
  //-- Area de dibujo
  Gtk.DrawingArea darea;
  
  //-- Funciones
  GFuncion       gf1;
  FuncionSin     Sin;    //-- Funcion de Seno
  FuncionSemiSin Semi;   //-- Funcion Semisinusoidal
  Funcion        Comb;   //-- Funcion compuesta (combinacion lineal)
  FuncionSin     Comb1;  //-- Primera funcion a componer
  FuncionSin     Comb2;  //-- Segunda funcion a componer  
  
  //-- Colores
  Gdk.GC pen_rojo;
  Gdk.GC pen_azul;
  Gdk.GC pen_negro;
  Gdk.GC pen_blanco;
  
  //-- Gusano y sus parametros
  GGusano gg1; 
  Vector origen = new Vector(50,130);
  int t=0;
  
  //-- Widgets utilizados en la aplicacion y definidos con Glade
  
  //-- Seleccion de Onda activa
  [Widget] RadioButton radiobutton_SIN;
  [Widget] RadioButton radiobutton_SEMI;
  [Widget] RadioButton radiobutton_COMB;
  
  //-- Visibilidad de la onda
  [Widget] CheckButton checkbutton_onda_visible;
  
  //-- Parametros de las ondas
  //-- Onda SINUSOIDAL
  [Widget] SpinButton  spinbutton_Sin_amplitud;
  [Widget] SpinButton  spinbutton_SIN_freq;
  [Widget] SpinButton  spinbutton_Sin_fase_ini;
  [Widget] SpinButton  spinbutton_Sin_long_onda;
    
  //-- Onda SEMISINUSOIDAL
  [Widget] SpinButton  spinbutton_SEMI_pe;
  [Widget] SpinButton  spinbutton_SEMI_anchura;
  [Widget] SpinButton  spinbutton_SEMI_amplitud;
    
  //-- Onda COMBINACION LINEAL
  [Widget] SpinButton  spinbutton_COMB1_amplitud;
  [Widget] SpinButton  spinbutton_COMB2_amplitud;
  [Widget] SpinButton  spinbutton_COMB1_long_onda;
  [Widget] SpinButton  spinbutton_COMB2_long_onda;
  [Widget] SpinButton  spinbutton_COMB1_fase_ini;
  [Widget] SpinButton  spinbutton_COMB2_fase_ini; 
  
  //-- Gusano
  [Widget] SpinButton spinbutton_radio;
  [Widget] SpinButton spinbutton_lseg;
  [Widget] SpinButton spinbutton_narts;
  
  //-- Botones
  [Widget] Button stop_button;
  [Widget] Button play_button;
  
  //-- Otros
  //-- Instante de tiempo
  [Widget] SpinButton  spinbutton_t;
  
  //-- Notebook de configuracion de las ondas
  [Widget] Notebook    notebook_conf_ondas;
  
  //-- Si gusano esta enganchado a la onda o no
  [Widget] CheckButton checkbutton_enganchar;
  
  //-- Lectura del interfaz con Glade
  Glade.XML gxml;
  
  //-- Temporizador para la reproduccion
  uint play_timer=0;
  

  /*------------------------------*/
  /*  METODOS                     */
  /*------------------------------*/
  public static void Main (string[] args)
  {
    new GladeApp (args);
  }

  public GladeApp (string[] args)
  {
    
    //-- Inicializar las GTK
    Application.Init();

    //-- Crear interfaz, con Glade
    gxml = new Glade.XML ("cube-virtual.glade",
                          "main_window", null);
    gxml.Autoconnect (this);
    
    //-- Configurar area de dibujo. Esto es importante para que
    //-- Se genere el evento Configure y se inicialice
    darea=(DrawingArea)gxml.GetWidget("drawingarea1");
    darea.SetSizeRequest (300, 100);
     
    //-- Configurar los colores
    configurar_colores(); 
    
    //-- Crear y configuar el gusano
    configurar_gusano();
    
    //-- Crear y configurar las funciones de contorno
    configurar_ondas();
    
    //-- Retrolla
    
    //-- Que comience la fiesta!!
    Application.Run();
  }

  /************************************/
  /* Crear y configurar el gusano     */
  /************************************/
  void configurar_gusano()
  {
    //--------------------------
    //-- Crear gusano 
    //--------------------------
    //-- El numero de articulaciones se toman del interfaz
    gg1 = new GGusano(darea, new Gusano((int)spinbutton_narts.Value));
 
    //-- Establecer el origen
    gg1.Origen=origen;
    gg1.Origen_panel=new Vector(10,40);
    
    //-- Radio de las articulaciones
    gg1.Radio = (int)spinbutton_radio.Value;
    
    //-- Longitud de los segmentos
    gg1.Gusano.Lseg = spinbutton_lseg.Value;
    
    //-- Tomar la visibilidad del ejex
    CheckButton check = (CheckButton)gxml.GetWidget("checkbutton_ejex");
    gg1.Ejex_visible=check.Active;
    
    //-- Tomar la visibilidad del numero de las articulaciones
    check = (CheckButton)gxml.GetWidget("checkbutton_numeros");
    gg1.Narts_visibles=check.Active;
    
    //-- Tomar la visibilidad del panel de datos
    check = (CheckButton)gxml.GetWidget("checkbutton_panel");
    gg1.Panel_visible=check.Active;
    
    //-- Tomar la visibilidad global
    check = (CheckButton)gxml.GetWidget("checkbutton_gusano");
    gg1.Visible=check.Active;
    
    //-- Colores
    gg1.Art_Color = pen_rojo;
    gg1.Seg_Color = pen_azul;
  }

  /**********************************/
  /* Crear y configurar las ondas   */
  /**********************************/
  void configurar_ondas()
  {
    double A,A1,A2;           //-- Amplitud
    double lo,lo1,lo2;        //-- Longitud de onda
    double fase,fase1,fase2;  //-- Fase inicial
    double freq;               //-- Frecuencia
    double anchura;           //-- Anchura
    double pe;                //-- Periodo espacial
    
    //-- ONDA SINUSOIDAL
    A    = spinbutton_Sin_amplitud.Value;
    lo   = spinbutton_Sin_long_onda.Value;
    fase = spinbutton_Sin_fase_ini.Value;
    freq = spinbutton_SIN_freq.Value;
    Sin  = new FuncionSin(A,lo,fase,freq);
    
    //-- ONDA SEMISINUSOIDAL
    A       = spinbutton_SEMI_amplitud.Value;
    anchura = spinbutton_SEMI_anchura.Value;
    pe      = spinbutton_SEMI_pe.Value;
    Semi    = new FuncionSemiSin(A,anchura,pe,5);
    
    //-- COMBINACION LINEAL
    A1 = spinbutton_COMB1_amplitud.Value;
    A2 = spinbutton_COMB2_amplitud.Value;
    lo1= spinbutton_COMB1_long_onda.Value;
    lo2= spinbutton_COMB2_long_onda.Value;
    fase1 = spinbutton_COMB1_fase_ini.Value;
    fase2 = spinbutton_COMB2_fase_ini.Value;
    Comb1 = new FuncionSin(A1,lo1,fase1,5);
    Comb2 = new FuncionSin(A2,lo2,fase2,5);
    Comb = Comb1 + Comb2;
  
    //-- Crear la Grafica
    gf1         = new GFuncion(darea);
    gf1.Origen  = origen;
    gf1.Color   = pen_negro;
    gf1.Func    = Sin;
    gf1.Visible = checkbutton_onda_visible.Active;
  }

  /**********************************/
  /* Configurar las colores a usar  */
  /**********************************/
  void configurar_colores()
  {
    //-- Configurar los colores
    Gdk.Color rojo = new Gdk.Color(0xff,0,0);
    Gdk.Color azul  = new Gdk.Color(0,0,0xff);
    Gdk.Color negro = new Gdk.Color(0,0,0);
    Gdk.Color blanco = new Gdk.Color(0xff,0xff,0xff);
    
    Gdk.Colormap colormap = Gdk.Colormap.System;        
    colormap.AllocColor (ref rojo, true, true);
    colormap.AllocColor (ref azul,true,true);
    colormap.AllocColor (ref negro,true,true);
    colormap.AllocColor (ref blanco,true,true);
    
    //-- Configurar los contextos graficos (pinceles)
    pen_rojo = new Gdk.GC(darea.GdkWindow);
    pen_azul = new Gdk.GC(darea.GdkWindow);
    pen_negro = new Gdk.GC(darea.GdkWindow);
    pen_blanco= new Gdk.GC(darea.GdkWindow);
    
    pen_rojo.Foreground = rojo;
    pen_azul.Foreground = azul;
    pen_azul.SetLineAttributes (2, Gdk.LineStyle.Solid,
                                Gdk.CapStyle.Butt,
                                Gdk.JoinStyle.Round);
    pen_negro.Foreground = negro;
    pen_blanco.Foreground = blanco;
  }

  //---------------------------------------------------------
  //-- Dibujar todos los objetos en el drawing area
  //---------------------------------------------------------
  public void Render()
  {
    //-- Borrar el pixmap
		pixmap.DrawRectangle (darea.Style.WhiteGC, true, 0, 0,
					                darea.Allocation.Width, darea.Allocation.Height);
   
    //-- Dibujar los objetos
    gf1.Render(pixmap,t);
    gg1.Render(pixmap);
    
    //-- Solicitar refresco
    darea.QueueDraw(); 
  }


  //--------------------------------------------------
  //-- Funcion de retrollamada cuando se termina el programa
  //--------------------------------------------------
  public void OnWindowDeleteEvent (object o, DeleteEventArgs args) 
  {
    Application.Quit ();
    args.RetVal = true;
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada del temporizador para la reproduccion
  //--------------------------------------------------------------------
  public bool Test()
  {
    spinbutton_t.Value+=1;
    return true;
  }
  
  //-----------------------------------------------------------
  //-- F U N C I O N E S    D E    G E N E R A C I O N
  //-----------------------------------------------------------
  
  //------------------------------------------------
  //-- Funcion de retrollamada del boton de play
  //------------------------------------------------
  public void on_play_button_clicked(object o, EventArgs args)
  {
    spinbutton_t.Value=0;
    checkbutton_enganchar.Active=true;
    
    play_timer=GLib.Timeout.Add(100,new GLib.TimeoutHandler (Test));
    play_button.Sensitive=false;
    stop_button.Sensitive=true;
  }
  
  //----------------------------------------------
  //-- Funcion de retrollamada del boton de stop
  //----------------------------------------------
  public void on_stop_button_clicked(object o, EventArgs args)
  {
    play_button.Sensitive=true;
    stop_button.Sensitive=false;
    GLib.Source.Remove(play_timer);
  }
  
  //-------------------------------------------------
  //-- Funcion de retrollamada del boton de Grabar
  //-------------------------------------------------
  public void on_save_button_clicked(object o, EventArgs args)
  {
    //-- De momento solo se graba con ondas sinusoidales y semi
    //-- Con ondas combinadas se retorna
    if (radiobutton_COMB.Active) {
      Console.WriteLine(
        "La Grabacion de ondas combinadas no esta implementada");
      return;
    } 
    
    double periodo=0;
    
    //---------------------------------------
    //-- Calcular m: Numero de snapshots
    //---------------------------------------
    //-- Leer el periodo
    if (radiobutton_SIN.Active) {
      periodo=((FuncionSin)gf1.Func).Periodo;
    }  
    else { 
      periodo=((FuncionSemiSin)gf1.Func).Periodo;
    }  
      
    //-- m es el periodo en instantes discretos  
    int m = (int)Math.Round(periodo); 
  
    //-- Obtener el nombre del fichero
    String fich_name = String.Format("{0}.f8",gf1.Func);
  
    //---------------------------------
    //-- Crear fichero en formato .f8
    //---------------------------------
    TextWriter writer = File.CreateText(fich_name);
    writer.WriteLine("NSERVOS=8");
    
    //-- Calcular la tabla de control y guardarla en el fichero
    for (int i=0; i<m; i++) {
      //-- Ajustar
      gg1.Gusano.Ajustar(gf1.Func,i);
      writer.WriteLine("{0},0;",gg1.Gusano.Cadena_estado(8));
    }
    
    Console.WriteLine("Fichero creado: {0}",fich_name);
    writer.Close();
    
  }
 
 
  //----------------------------------------------------------
  //--  F U N C I O N E S    G E N E R A L E S
  //----------------------------------------------------------
  
  //------------------------------------------------------
  //-- Funcion de retrollamada del menu de Acerca de
  //------------------------------------------------------
  public void on_acerca_de1_activate(object obj, EventArgs args)
  {
    //-- Crear interfaz, con Glade
    Glade.XML gxml = new Glade.XML ("./cube-virtual.glade",
                          "about", null);
    gxml.Autoconnect (this);
  }
  
  public void on_cerrar_about_clicked(object obj, EventArgs args)
  {
    Widget win = (Widget) obj;
    
    win.Toplevel.Destroy();
    Console.WriteLine("Cerrar!!!");
  }
  
  //----------------------------------------------------
  //-- Funcion de retrollamada del boton de enganchar  
  //----------------------------------------------------
  public void on_checkbutton_enganchar_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    
    if (check.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  

  //----------------------------------------------------------------
  //-- Funcion de retrollamada del tiempo
  //----------------------------------------------------------------
  public void on_spinbutton_t_value_changed(object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    
    //-- Incrementar el tiempo
    t = (int)item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada del boton de Reset para el tiempo
  //---------------------------------------------------------------
  public void on_Reset_time_clicked (object o, EventArgs args)
  {
    spinbutton_t.Value=0.0;          
  }

  //-------------------------------------------------------------------
  //-- Funcion de retrollamada para ajustar el gusano a la onda activa
  //-------------------------------------------------------------------
  public void on_ajustar_clicked (object o, EventArgs args)
  {
    gg1.Gusano.Ajustar(gf1.Func,t);
    Render();            
  }


  //----------------------------------------------------------
  //--  F U N C I O N E S    D E    C O N T O R N O 
  //----------------------------------------------------------
  
  //--------------------------------------------------------------
  //-- Funcion de retrollamada de la visibilidad de la funcion
  //--------------------------------------------------------------
  public void on_checkbutton_onda_visible_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    gf1.Visible=check.Active;
    
    Render();
  }
  
  //-------------------------------------------------------------
  //-- Funcion de retrollamada para la seleccion de onda COMB
  //-------------------------------------------------------------
  public void on_radiobutton_COMB_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    if (check.Active) {
      gf1.Func=Comb;
      
      //-- Seleccionar la hoja correspondiente para la configuracion
      notebook_conf_ondas.CurrentPage=2;
      
      //-- Si gusano "enganchado", ajustar
      if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
        gg1.Gusano.Ajustar(gf1.Func,t);
        
      Render();
    }
  }
  
  //-------------------------------------------------------------
  //-- Funcion de retrollamada para la seleccion de onda SEMI
  //-------------------------------------------------------------
  public void on_radiobutton_SEMI_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    if (check.Active) {
      gf1.Func=Semi;
      
      //-- Seleccionar la hoja correspondiente para la configuracion
      notebook_conf_ondas.CurrentPage=1;
      
      //-- Si gusano "enganchado", ajustar
      if (checkbutton_enganchar.Active && radiobutton_SEMI.Active)
        gg1.Gusano.Ajustar(gf1.Func,t);
        
      Render();
    }
  }
  
  //----------------------------------------------------------------
  //-- Funcion de retrollamada para la seleccion de onda SINUSOIDAL
  //----------------------------------------------------------------
  public void on_radiobutton_SIN_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    if (check.Active) {
      gf1.Func=Sin;
      
      //-- Seleccionar la hoja correspondiente para la configuracion
      notebook_conf_ondas.CurrentPage=0;
      
      //-- Si gusano "enganchado", ajustar
      if (checkbutton_enganchar.Active)
        gg1.Gusano.Ajustar(gf1.Func,t);
        
      Render();
    }
  }
  
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para la amplitud de la COMB1
  //---------------------------------------------------------------
  public void on_spinbutton_COMB1_amplitud_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb1.Amplitud= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para la amplitud de la COMB2
  //---------------------------------------------------------------
  public void on_spinbutton_COMB2_amplitud_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb2.Amplitud= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la longitud de onda de la COMB1
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB1_long_onda_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb1.Long_onda= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la longitud de onda de la COMB2
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB2_long_onda_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb2.Long_onda= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la fase inicial de la COMB1
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB1_fase_ini_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb1.Fase_ini= new Angulo(item.Value).Rad;
    
    Console.WriteLine("Comb1: fase_ini: {0}",Comb1.Fase_ini);
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la fase inicial de la COMB2
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB2_fase_ini_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb2.Fase_ini= new Angulo(item.Value).Rad;
    
    Console.WriteLine("Comb2: fase_ini: {0}",Comb2.Fase_ini);
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la frecuencia de la COMB1
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB1_freq_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb1.Frec=item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la frecuencia de la COMB2
  //--------------------------------------------------------------------
  public void  on_spinbutton_COMB2_freq_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Comb2.Frec=item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para la amplitud de la SEMI
  //---------------------------------------------------------------
  public void on_spinbutton_SEMI_amplitud_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Semi.Amplitud= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para la anchura de la SEMI
  //---------------------------------------------------------------
  public void on_spinbutton_SEMI_anchura_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Semi.Anchura= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_SEMI.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para el periodo espacial de SEMI
  //---------------------------------------------------------------
  public void on_spinbutton_SEMI_pe_value_changed
              (object obj, EventArgs args)
  {
    Console.WriteLine("Cambio!");
    SpinButton item = (SpinButton) obj;
    Semi.Periodo_espacial= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_SEMI.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la frecuencia de la SEMI
  //--------------------------------------------------------------------
  public void  on_spinbutton_SEMI_freq_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Semi.Frec=item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la fase inicial de la SINUIDAL
  //--------------------------------------------------------------------
  public void  on_spinbutton_Sin_fase_ini_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Sin.Fase_ini= new Angulo(item.Value).Rad;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la longitud de onda de la SINUIDAL
  //--------------------------------------------------------------------
  public void  on_spinbutton_Sin_long_onda_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Sin.Long_onda= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
   
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para la amplitud de la SINUIDAL
  //---------------------------------------------------------------
  public void on_spinbutton_Sin_amplitud_value_changed 
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Sin.Amplitud= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_SIN.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //--------------------------------------------------------------------
  //-- Funcion de retrollamada para la frecuencia de la SINUSOIDAL
  //--------------------------------------------------------------------
  public void  on_spinbutton_SIN_freq_value_changed
              (object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    Sin.Frec= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active && radiobutton_COMB.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //------------------------------------------------------------------
  //--  F U N C I O N E S    D E L    G U S A N O 
  //------------------------------------------------------------------
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para el numero de articulaciones
  //---------------------------------------------------------------
  public void on_spinbutton_narts_value_changed(object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    int narts= (int)item.Value;
    gg1.Gusano=new Gusano(narts);
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada para el radio
  //---------------------------------------------------------------
  public void on_spinbutton_radio_value_changed(object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    gg1.Radio= (int)item.Value;
    
    Render();
  }
  
  //-----------------------------------------------------------------
  //--- Funcion de retrollamada para el tamano de los segmentos 
  //-----------------------------------------------------------------
  public void on_spinbutton_lseg_value_changed(object obj, EventArgs args)
  {
    SpinButton item = (SpinButton) obj;
    gg1.Gusano.Lseg= item.Value;
    
    //-- Si gusano "enganchado", ajustar
    if (checkbutton_enganchar.Active)
      gg1.Gusano.Ajustar(gf1.Func,t);
    
    Render();
  }
  
  //----------------------------------------------------------------------
  //-- Funcion de retrollamada del checkbutton de visibilidad del gusano
  //----------------------------------------------------------------------
  public void on_checkbutton_gusano_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    gg1.Visible=check.Active;
    
    Render();
  }
  
  //----------------------------------------------------------------------
  //-- Funcion de retrollamada del checkbutton de visibilidad del panel
  //----------------------------------------------------------------------
  public void on_checkbutton_panel_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    gg1.Panel_visible=check.Active;
    
    Render();
  }
  
  //--------------------------------------------------------------------------
  //-- Funcion de retrollamada del checkbutton de los numeros de articulacion
  //--------------------------------------------------------------------------
  public void on_checkbutton_numeros_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    gg1.Narts_visibles=check.Active;
    
    Render();
  }
  
  //------------------------------------------------------------------
  //-- Funcion de retrollamada del checkbutton del ejex
  //------------------------------------------------------------------
  public void on_checkbutton_ejex_toggled(object obj, EventArgs args)
  {
    CheckButton check = (CheckButton) obj;
    gg1.Ejex_visible=check.Active;
    
    Render();
  }
  
  //--------------------------------------------------------
  //-- Funcion de retrollamada para terminar 
  //--------------------------------------------------------  
  public void on_main_window_delete_event (object o, EventArgs args)
  {
    Console.WriteLine("Fin...");
    Application.Quit();
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada de cambio de tamaño
  //-- Si el area de dibujo tiene un tamaño fijo, no se invocará
  //---------------------------------------------------------------
  public void on_drawingarea1_configure_event(object o, 
                                              ConfigureEventArgs args)
  {
		Gdk.EventConfigure ev = args.Event;
		Gdk.Window window = ev.Window;
		Gdk.Rectangle allocation = darea.Allocation;

    //-- Crear un pixmap nuevo, con las nuevas dimensiones
		pixmap = new Gdk.Pixmap (window, allocation.Width, allocation.Height, -1);
		
		//-- Borrar el pixmap
		pixmap.DrawRectangle (darea.Style.WhiteGC, true, 0, 0,
					                allocation.Width, allocation.Height);
		    
	  //-- Aqui habria que dibujar los objetos existentes
    Render();

		args.RetVal = true;
  }                                            
  
  //---------------------------------------------------------------------
  //-- Funcion de retrollamada invocada cada vez que hay que dibujar
  //---------------------------------------------------------------------
  public void on_drawingarea1_expose_event(object o, ExposeEventArgs args)
  {
    //-- Llevar el buffer pixmap al area de dibujo
		Gdk.Rectangle area = args.Event.Area;
		args.Event.Window.DrawDrawable (
		          darea.Style.BlackGC,
							pixmap,
							area.X, area.Y,
							area.X, area.Y,
							area.Width, area.Height);

		args.RetVal = false;  
  }
  
  
}
