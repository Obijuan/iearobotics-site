//********************************************************************
//* GFuncion.cs   (c) Juan Gonzalez.  Enero 2005                     *
//*------------------------------------------------------------------*
//*  Clase para Dibujo de funciones                                  *
//*------------------------------------------------------------------*
//* Licencia GPL                                                     *
//********************************************************************
using System;
using Gdk;
using Gtk;

/*! \example test-GFuncion.cs
    Programa para hacer pruebas de la clase GFuncion
*/

//----------------------------------------------------------------------
/*! Esta clase permite con Funciones graficas. El metodo principal es 
    Render(), dibujar la grafica de la funcion sobre un drawable. Tambien
    se pueden establecer sus atributos graficos, como el origen en pantalla.
    \brief  Visualizacion de funciones y gestion de sus atributos graficos  */
//----------------------------------------------------------------------------
public class GFuncion 
{
  //-----------------------
  //- CONSTRUCTOR
  //-----------------------
  
  //------------------------------------------------------------------------
  /*! CONSTRUCTOR. Se crea una GFuncion nueva. Hay que especificar el
      Drawing area asociado. Por defecto, la funcion establacecida es la
      nula.
        @param darea Drawing area donde se dibujara la funcion
      \brief Crear una GFuncion nueva                                      */
  //------------------------------------------------------------------------    
  public GFuncion(Gtk.DrawingArea darea)
  {
    this.darea=darea;
    
    //-- Establecer color por defecto: Negro
    this.pen_funcion=darea.Style.BlackGC;
    
    //-- Origen de coordenadas por defecto
    this.origen=new Vector(0,0);
    
    //-- Por defecto la funcion asociada es la nula
    this.func = new FuncionCte(0);
    
    //-- Por defecto la funcion es visible
    this.func_visible = true;
  }
  
  //----------------------------------------------------------------------
  /*! Constructor de copia. Se crea una GFuncion nueva, copia de la 
      original.
      @param gf Objeto GFuncion a copiar
      \brief Crear una GFuncion nueva, a partir de otra                  */
  //----------------------------------------------------------------------
  public GFuncion(GFuncion gf)
  {
    this.func = gf.func.Clonar(); 
    this.pen_funcion= new Gdk.GC(gf.darea.GdkWindow);
    this.pen_funcion.Copy(gf.pen_funcion);
    this.origen = new Vector(gf.origen);
    this.func_visible = gf.Visible;
    this.darea = gf.darea;
  }  
  
  //-------------------------
  //-- METODOS
  //-------------------------

  //------------------------------------------------------------------------
  /*! Funcion principal de la clase GFuncion. Se dibuja la funcion,
      teniendo en cuenta el resto de atributos graficos.<br>
      Lo normal es dibujarlo sobre un pixmap y que se lleve al 
      Drawing area cuando ocurra la funcion de retrollamada expose_event.
      La grafica se dibuja de forma que ocupa todo el ancho del drawable
      <br>
      Las funciones de la clase Funcion tienen dos parametros: x,t. La x
      es el parametro espacial y la t el temporal. Al dibujar hay que 
      especificar el parametro t. Si es 0, se toma la funcion en el 
      instante inicial
      @param drawable Elemento donde dibujar la grafica
      @param t        Instante en el que dibujar la grafica
      
      \brief Dibujar la grafica en un drawable                           */
  //----------------------------------------------------------------------
  public void Render(Gdk.Drawable drawable, double t)
  {
  
    //-- Solo se dibuja la grafica si es visible
    if (this.func_visible==false) return;
    
    //-- Obtener las dimensiones del drawable
    int anchura;
    int altura;
    drawable.GetSize(out anchura, out altura);
    
    //-- Pintar la grafica
    Point[] point = new Point[anchura];
    
    //-- En total hay "anchura" puntos. La varible i los indexa
    //-- La variable x toma valores en el rango 
    //-- [-origen.x,anchura-origen.x], para que se dibuje la funcion
    //-- todo lo ancho que es el drawable
    double x;
    for (int i = 0; i<anchura; i++) {
      x = i-origen.x;
      Vector resultante = new Vector(x,this.func.Valor(x,t)) + this.origen;
      point[i]=new Point((int)resultante.x,
                       altura-(int)resultante.y);
    }    
    drawable.DrawLines(this.pen_funcion,point);
  }
  
  //-------------------------
  //-- PROPIEDADES
  //-------------------------

  //----------------------------------------------------------------
  /*! Esta propiedad devuelve una referencia a la funcion asociada,
      para realizar cualquier modificacion. O bien permite 
      especificar otra nueva.
      \brief Acceder a la funcion asociada (Get, Set)             */
  //----------------------------------------------------------------    
  public Funcion Func 
  {
    set {
      this.func=value;
    }
    get {
      return this.func;
    }
  }
  
  //---------------------------------------------------------------
  /*!  Leer o establecer el origen de la grafica.
       En un drawable, el origen esta en la <b>esquina
       inferior izquierda</b>, con valor (0,0). Esta propiedad permite
       situarlo en cualquier otra posicion
       \brief Origen para el dibujo de la grafica                 */
  //----------------------------------------------------------------
  public Vector Origen {
    set {
      this.origen=value;
    }
    get {
      return this.origen;
    }
  }
  
  //---------------------------------------------------------------------
  /*!  Leer o establecer la visibilidad de la grafica. Si esta a true,
       la grafica se pinta al invocar el metodo Render. Si esta a
       false no.
       \brief Atributo de visibilidad de la funcion (Get,Set)           */
  //---------------------------------------------------------------------
  public bool Visible
  {
    set {
      this.func_visible=value;
    }
    get {
      return this.func_visible;
    }
  }
  
  //---------------------------------------------------------------------
  /*! Establecer o leer el color de grafica
      \brief Color de la grafica (Get,Set)                              */
  //---------------------------------------------------------------------
  public Gdk.GC Color
  {
    set {
      this.pen_funcion=value;
    }
    get {
      return this.pen_funcion;
    }
  }
  
  
  //-------------------------
  //- PROPIEDADES PRIVADAS
  //-------------------------
  //-- Funcion asociada
  private Funcion func;
  
  //-- Color de la grafica
  private Gdk.GC pen_funcion;
  
  //-- Origen de coordenadas
  private Vector origen;
  
  //-- Indica si la funcion es visible o no
  private bool func_visible=true;
  
  //-- Area de Dibujo
  private Gtk.DrawingArea darea;
}
