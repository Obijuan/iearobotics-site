/***********************************************************/
/* Clase GGusano.   (c) Juan Gonzalez Gomez. Enero 2005    */
/*---------------------------------------------------------*/
/* Clase para gestionar los "Gusanos graficos"             */
/***********************************************************/
using System;
using Gdk;
using Gtk;
using Pango;

/*! \example test-GGusano.cs
    Programa para hacer pruebas de la clase GGusano
*/

//----------------------------------------------------------------------
/*! Esta clase permite trabajar con "gusanos graficos". 
    La funcion principal es la de dibujar el gusano en un 
    objeto del tipo Gdk.Drawable. Permite
    establecer los atributos para la visualizacion de cualquier
    objeto de la clase Gusano, como el color de las articulaciones,
    de los segmentos, etc y establecer que partes son visibles y 
    cuales no. 
 \brief  Visualizacion de gusanos y gestion de sus atributos graficos  */
//----------------------------------------------------------------------
class GGusano
{
  /******************************/
  /* CONSTRUCTORES              */
  /******************************/
  
  /*! CONSTRUCTOR. Se crea un GGusano nuevo y se le asigna 
      el gusano g. Hay que especificar el Drawing area asociado,
      que solo se usa para inicializar los colores.      
        @param darea Drawing area donde se dibujara el GGusano
        @param gusano El gusano que se quiere dibujar
      \brief Crear un GGusano nuevo  
  */
  public GGusano(Gtk.DrawingArea darea, Gusano gusano) {
    this.darea=darea;
    this.origen = new Vector(0,0);
    this.origen_panel = new Vector(0,0);
    this.gusano = gusano;
    
    //-- Inicializar colores
    this.pen_art=darea.Style.BlackGC;
    this.pen_seg=darea.Style.BlackGC;
  }
  
  //------------------------------------------------------------------------
  /*! Constructor de copia. 
      @param gg Objeto del tipo GGusano a copiar
      \brief Crear un nuevo GGusano, a partir de otro                      */
  //------------------------------------------------------------------------
  public GGusano(GGusano gg)
  {
    this.gusano = new Gusano(gg.gusano);
    this.radio=gg.radio;
    this.pen_art= new Gdk.GC (gg.darea.GdkWindow);
    this.pen_art.Copy(gg.pen_art);
    this.pen_seg= new Gdk.GC (gg.darea.GdkWindow);
    this.pen_seg.Copy(gg.pen_seg);
    this.darea = gg.darea;
    this.origen = new Vector(gg.origen);
    this.origen_panel = new Vector(gg.origen_panel);
    this.ejex_visible=gg.ejex_visible;
    this.narts_visibles=gg.narts_visibles;
    this.panel_visible=gg.panel_visible;
  }
  
  /********************************/
  /* METODOS PUBLICOS             */
  /********************************/
  //------------------------------------------------------------------------
  /*! Funcion principal de la clase GGusano. Se dibuja el gusano,
      teniendo en cuenta el resto de atributos graficos, como los
      colores de las articulaciones, de los segmentos, los elementos
      visibles, etc.<br>
      Lo normal es dibujarlo sobre un pixmap y que se lleve al 
      Drawing area cuando ocurra la funcion de retrollamada expose_event.
      @param drawable Elemento donde dibujar el gusano
      
      \brief Dibujar el gusano en un "drawable"                          */
  //----------------------------------------------------------------------
  public void Render(Gdk.Drawable drawable)
  {    
    
    //-- Si visibilidad global no establecida, no dibujar nada
    if (this.visible==false) return;
    
    //-- Obtener las dimensiones del drawable
    int anchura;
    int altura;
    drawable.GetSize(out anchura, out altura);
    
    //-- Dibujar eje x
    if (this.ejex_visible)
      drawable.DrawLine(pen_art, 0,
                        altura-(int)this.origen.y, 
                        anchura,
                        altura-(int)this.origen.y);
    
    //--Calcular todos los puntos
    Point[] point = new Point[this.Gusano.Nmod+2];
    
    //-- Cola
    Vector resultante;
    resultante = this.Gusano.Art(0).Vector + this.origen;
    point[0]=new Point((int)Math.Round(resultante.x),
                       altura-(int)Math.Round(resultante.y));
    
    //-- Puntos intermedios
    for (int i=1; i<=this.Gusano.Nmod; i++) {
      resultante = this.Gusano.Art(i).Vector + this.origen;
      point[i]=new Point((int)Math.Round(resultante.x),
                         altura-(int)Math.Round(resultante.y));                    
    }
    
    //-- Cabeza
    resultante = this.Gusano.Art(this.Gusano.Nmod+1).Vector+this.origen;
    point[this.Gusano.Nmod+1]=new Point((int)Math.Round(resultante.x),
                                 altura-(int)Math.Round(resultante.y));
    
    //-- Dibujar el gusano
    //-- 1) Dibujar todos los segmentos
    drawable.DrawLines(pen_seg,point);
    
    //-- 2) Dibujar articulaciones
    //-- Dibujar articulaciones
    
    Pango.Layout layout = new Pango.Layout (darea.PangoContext);
    layout.Wrap = Pango.WrapMode.Word;
    layout.FontDescription = FontDescription.FromString ("Courier 8");
    
    for (int i=1; i<=this.Gusano.Nmod; i++) {
      drawable.DrawArc(pen_art,true,
                       point[i].X-this.radio,
                       point[i].Y-this.radio,
                       this.radio*2,
                       this.radio*2,
                       0,360*64);
                       
      //-- Dibujar el numero de articulacion
      if (this.narts_visibles) {
        layout.SetMarkup (i.ToString());
        drawable.DrawLayout (darea.Style.TextGC (StateType.Normal),
                           point[i].X, 
                           point[i].Y, layout); 
      }
    }
    //-- Dibujar el panel de datos
    if (this.panel_visible) {
      Vector dato_angulos  = this.origen_panel;
      Vector dato_xs       = this.origen_panel + new Vector(0,-10);
      Vector dato_ys       = this.origen_panel + new Vector(0,-20);
    
      //-- Angulos...
      layout.SetMarkup(this.Gusano.ToString());
      drawable.DrawLayout (darea.Style.TextGC (StateType.Normal),
                            (int)dato_angulos.x, 
                            altura - (int)dato_angulos.y,
                            layout);
      //-- Coordenadas X's
      layout.SetMarkup("X:"+this.Gusano.XToString());
      drawable.DrawLayout(darea.Style.TextGC (StateType.Normal),
                          (int)dato_xs.x,
                          altura-(int)dato_xs.y,
                          layout);
    
      //-- Coordenas Y's
      layout.SetMarkup("Y:"+this.Gusano.YToString());
      drawable.DrawLayout(darea.Style.TextGC (StateType.Normal),
                          (int)dato_ys.x, 
                          altura-(int)dato_ys.y,
                          layout);
   }
  }
  
  
  /***************************/
  /* PROPIEDADES             */
  /***************************/
  //----------------------------------------------------------------
  /*! Esta propiedad devuelve una referencia al gusano asociado,
      para realizar cualquier modificacion. O bien permite 
      especificar otro gusano.
      
      \brief Acceder al Gusano asociado (GET,SET)                 */
  //----------------------------------------------------------------    
  public Gusano Gusano {
    set {
      this.gusano = value;
    }
    get {
      return this.gusano;
    }
  }
  
  //------------------------------------------------------------
  /*! Leer o establecer el radio de las articulaciones
      \brief Radio de las articulaciones                      */
  //------------------------------------------------------------
  public int Radio {
    get {
      return this.radio;
    }
    set {
      this.radio=value;
    }
  }
  
  //---------------------------------------------------------
  /*!  Leer o establecer el color de las articualciones
       \brief Color de las articulaciones                   */
  //----------------------------------------------------------
  public Gdk.GC Art_Color {
    set {
      this.pen_art=value;
    }
  }
  
  //------------------------------------------------------------
  /*!  Leer o establecer el color de los segmentos
       \brief Color de los segmentos                           */
  //------------------------------------------------------------
  public Gdk.GC Seg_Color {
    set {
      this.pen_seg=value;
    }
  }
  
  //---------------------------------------------------------------
  /*!  Leer o establecer el origen del gusano, donde se dibujara
       el gusano. En un drawable, el origen esta en la <b>esquina
       inferior izquierda</b>, con valor (0,0). Esta propiedad permite
       situarlo en cualquier otra posicion
       \brief Origen para el dibujo del gusano                    */
  //----------------------------------------------------------------
  public Vector Origen {
    set {
      this.origen=value;
    }
    get {
      return this.origen;
    }
  }
  
  //--------------------------------------------------------------------
  /*!  Leer o establecer el origen del panel de datos del gusano. En 
       este panel se muestra el estado interno (angulos de las 
       articulaciones), coordenadas x,y, etc...
       \brief Origen del panel de datos del gusano                     */
  //--------------------------------------------------------------------
  public Vector Origen_panel {
    set {
      this.origen_panel=value;
    }
    get {
      return this.origen_panel;
    }
  }
  
  //-----------------------------------------------------------------------
  /*! Establecer o leer la visibilidad global del gusano. Si esta a true,
      se dibuja el gusano. El resto de elementos dependen de su visibilidad.
      Si esta a false, no se visualiza ni el gusano ni ningun otro elemento
      \brief Visibilidad global del gusano                                */
  //-----------------------------------------------------------------------
  public bool Visible
  {
    set {
      this.visible=value;
    }
    get {
      return this.visible;
    }
  }
  
  //---------------------------------------------------------------------
  /*!  Establecer o leer la visibilidad del eje x. Si esta a true, al 
       invocar el metodo Render(), se dibuja el eje x, con una anchura 
       igual al del drawable donde se dibuja. Si esta a false, no se
       dibujara.
       \brief Visibilidad del eje x                                     */
  //---------------------------------------------------------------------
  public bool Ejex_visible {
    set {
      this.ejex_visible=value;
    }
    get {
      return this.ejex_visible;
    }
  }
  
  //--------------------------------------------------------------------
  /*!  Establecer o leer la visibilidad de los numeros de las 
       articulaciones. Si esta a true, se dibujan los numeros de las
       articulaciones, al invocar al metodo Render(). Si esta a 
       false, se dibujan sin numero.
       \brief Visibilidad del numero de las articulaciones             */
  //--------------------------------------------------------------------
  public bool Narts_visibles {
    set {
      this.narts_visibles=value;
    }
    get {
      return this.narts_visibles;
    }
  }
  
  //-- Indica si el panel de datos es visible o no
  //-----------------------------------------------------------------------
  /*! Establecer o leer la visibilidad del panel de datos. Si esta a 
      true, se dibuja el panel al invocar al metodo Render(). Si esta a 
      false, no se dibuja.
      \brief Visibilidad del panel de datos del gusano                    */
  //-----------------------------------------------------------------------
  public bool Panel_visible {
    set {
      this.panel_visible=value;
    }
    get {
      return this.panel_visible;
    }
  }
  
  
  /****************************/
  /* METODOS SOBRECARGADOS    */
  /****************************/
  
  /************************************/
  /* METODOS PRIVADOS                 */
  /************************************/
  
  
  /*--------------------------*/
  /* PROPIEDADES PRIVADAS     */
  /*--------------------------*/
  //-- Gusano asociado
  private Gusano gusano;
  
  //-- Radio de dibujo de las articulaciones
  private int radio=4;
  
  //-- Color de las articulaciones
  private Gdk.GC pen_art;
  
  //--Color de los segmentos
  private Gdk.GC pen_seg;
  
  //-- Area de dibujo asociada
  private Gtk.DrawingArea darea;
  
  //-- Origen de coordenadas del gusano
  private Vector origen;
  
  //-- Esquina superior izquierda del panel de datos
  private Vector origen_panel;
  
  //-- Atributo de visualizacion global
  private bool visible=true;
  
  //-- Indica si el ejex es visible o no
  private bool ejex_visible=false;
  
  //-- Indica si los numeros de las articulaciones son visibles o no
  private bool narts_visibles=false;
  
  //-- Indica si el panel de datos es visible o no
  private bool panel_visible=false;
}
