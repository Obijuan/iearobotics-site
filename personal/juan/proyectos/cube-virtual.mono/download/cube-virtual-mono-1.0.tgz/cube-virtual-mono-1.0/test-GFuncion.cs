//*******************************************************************
//* test-GFuncion.cs   (c) Juan Gonzalez.  Marzo 2005               *
//*-----------------------------------------------------------------*
//* Ejemplo de prueba de la clase GFuncion                          *
//* Para dibujar se utiliza un doble buffer                         *
//*-----------------------------------------------------------------*
//* Licencia GPL                                                    *
//*******************************************************************
/*-------------------------------------------------------------------------
 $Id: test-GFuncion.cs,v 1.1 2005/03/21 12:18:51 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-GFuncion.cs,v $
---------------------------------------------------------------------------*/
using Gtk;
using System;

class Test_GFuncion
{
  /*-----------------------------*/
  /*  PROPIEDADES                */
  /*-----------------------------*/
  //-- Buffer donde dibujar
  static Gdk.Pixmap pixmap;
  
  //-- Area de dibujo
  static Gtk.DrawingArea darea;
  
  //-- Funcion a dibujar
  static GFuncion gf1;

  /*------------------------------*/
  /*  METODOS                     */
  /*------------------------------*/
  public static void Main (string[] args)
  {
    new Test_GFuncion (args);
  }

  public Test_GFuncion (string[] args)
  {
    //-- Inicializar las GTK
    Application.Init();
    
    //-- Crear el interfaz: una ventana y un "Drawing Area"
    Window window = new Window ("Test-GFuncion");
    window.DeleteEvent += new DeleteEventHandler (OnWindowDeleteEvent);
    darea = new DrawingArea();
    window.Add(darea);
    window.ShowAll();
    
    //-- Funciones de retro-llamada del "Drawing Area"
    darea.ConfigureEvent+=new ConfigureEventHandler (on_configure_event);
    darea.ExposeEvent+=new ExposeEventHandler (on_expose_event);  
    darea.SetSizeRequest (200, 200);
   
    //-- Crear la GFuncion
    gf1 = new GFuncion(darea);
    gf1.Origen=new Vector(50,100);
    gf1.Func = new FuncionSin(15,100,0,5);
    
    //-- Que comience la fiesta!!
    Application.Run();
  }

  //----------------------------------------------------
  //-- Funcion de retrollamada para salir de las GTK
  //----------------------------------------------------
  void OnWindowDeleteEvent (object o, DeleteEventArgs args) 
  {
    Application.Quit ();
    args.RetVal = true;
  }
  
  //---------------------------------------------------------------
  //-- Funcion de retrollamada de cambio de tamaño
  //-- Si el area de dibujo tiene un tamano fijo, no se invocara
  //---------------------------------------------------------------
  public void on_configure_event(object o, 
                                              ConfigureEventArgs args)
  {
		Gdk.EventConfigure ev = args.Event;
		Gdk.Window window = ev.Window;
		Gdk.Rectangle allocation = darea.Allocation;

    //-- Crear un pixmap nuevo, con las nuevas dimensiones
		pixmap = new Gdk.Pixmap (window, allocation.Width, allocation.Height, -1);
		
		//-- Borrar el pixmap
		pixmap.DrawRectangle (darea.Style.WhiteGC, true, 0, 0,
					                allocation.Width, allocation.Height);
		    
    //-- Dibujar la funcion
    gf1.Render(pixmap,0);
    
    //-- Solicitar refresco
    darea.QueueDraw(); 

		args.RetVal = true;
  }                                            
  
  //---------------------------------------------------------------------
  //-- Funcion de retrollamada invocada cada vez que hay que dibujar
  //---------------------------------------------------------------------
  public void on_expose_event(object o, ExposeEventArgs args)
  {
    //-- Llevar el buffer pixmap al area de dibujo
		Gdk.Rectangle area = args.Event.Area;
		args.Event.Window.DrawDrawable (
		          darea.Style.BlackGC,
							pixmap,
							area.X, area.Y,
							area.X, area.Y,
							area.Width, area.Height);

		args.RetVal = false;  
  }
  
  
}
