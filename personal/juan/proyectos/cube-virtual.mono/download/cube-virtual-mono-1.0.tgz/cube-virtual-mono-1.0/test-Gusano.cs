//********************************************************************
//* test-Gusano       (c) Juan Gonzalez.  Marzo 2005                 *
//*------------------------------------------------------------------*
//*  Pruebas de la clase Gusano                                      *
//*------------------------------------------------------------------*
//* Licencia GPL                                                     *
//********************************************************************
/*-------------------------------------------------------------------------
 $Id: test-Gusano.cs,v 1.1 2005/03/20 23:25:45 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-Gusano.cs,v $
---------------------------------------------------------------------------*/

using System;

class Test_Gusano
{
  static void Main()
  {
    //--------------------------------------
    //-- Pruebas de construccion 
    //--------------------------------------
    Console.WriteLine("Pruebas de la clase Gusano");
    
    //-- Crear un gusano de 8 articulationes
    Gusano g1 = new Gusano(8);
    
    //-- Crear gusano de 2 articulaciones
    Gusano g2 = new Gusano(2);
    
    //-- Crear un gusano copia de otro
    Gusano g3 = new Gusano(g1);
    
    Console.WriteLine("Gusano 1: {0}. {1} articulaciones",g1,g1.Nmod);
    Console.WriteLine("Gusano 2: {0}. {1} articulaciones",g2,g2.Nmod);
    Console.WriteLine("Gusano 3: {0}. {1} articulaciones",g3,g3.Nmod);
    
    //--------------------------------------
    //-- Rotar articulaciones
    //--------------------------------------
    Console.WriteLine("\nRotacion:");
    g1.Set_Art(1,new Angulo(15),Gusano.Sentido.DERECHA);
    g1.Set_Art(2,new Angulo(-15),Gusano.Sentido.DERECHA);
    Console.WriteLine("Gusano 1: {0}",g1);
    
    //------------------------------------
    //-- Pruebas de ajuste
    //------------------------------------
    //-- Crear las funciones de ajuste
    Funcion f1 = new FuncionSin(15,100,0,5);
    Funcion  f2 = new FuncionSin(2,20,0,5);
    Funcion  f3 = new FuncionSemiSin(10,20,200,5);
    
    //-- Ajustar
    g1.Ajustar(f1,0);
    g2.Ajustar(f2,0);
    g3.Ajustar(f3,0);
    
    Console.WriteLine("\nAjuste:");
    Console.WriteLine("Gusano 1: {0}",g1);
    Console.WriteLine("Gusano 2: {0}",g2);
    Console.WriteLine("Gusano 3: {0}",g3);
   
  }
}
