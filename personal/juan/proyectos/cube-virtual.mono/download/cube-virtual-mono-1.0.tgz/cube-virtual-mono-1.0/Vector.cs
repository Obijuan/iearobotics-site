/**********************************************************/
/* Vector.cs.  Modulo de vectores en 2D. Agosto 2004      */
/*--------------------------------------------------------*/
/* Juan Gonzalez Gomez                                    */
/* Carlos Jesus Venegas Arrabe                            */
/*--------------------------------------------------------*/
/* Licencia GPL                                           */
/**********************************************************/
/*-------------------------------------------------------------------------
 $Id: Vector.cs,v 1.2 2005/12/09 12:54:11 juan Exp $
 $Revision: 1.2 $
 $Source: /var/lib/cvs/cube-virtual.mono/Vector.cs,v $
---------------------------------------------------------------------------*/

using System;

/*! \example test-Vector.cs
    Programa para hacer pruebas de la clase Vector
*/

//--------------------------------------------------------------------------
/*! Permite trabajar con vectores en 2D, tanto en cartesianas
    como en el formato modulo-argumento. Se pueden realizar todas
    las operaciones tipicas: combinaciones lineales, producto escalar, etc.
   \brief  Manejo de Vectores en 2D     */
//---------------------------------------------------------------------------
public class Vector
{

  /*-----------------------*/
  /* CONSTRUCTORES         */
  /*-----------------------*/
  /*! Constructor por defecto
      \brief CONSTRUCTOR. Crear un vector inicializado a 0  */
  public Vector() {
    this.cx=0.0;
    this.cy=0.0;
  }
  
  /*! Se crea un vector nuevo en cartesianas 
      \brief CONSTRUCTOR. Constructor en cartesianas */
  public Vector(double x, double y) {
    this.cx = x;
    this.cy = y;
  }
  
  /*! Construccion de un vector nuevo que es una copia de otro 
     \brief CONSTRUCTOR. Copiar un vector  */
  public Vector(Vector v) {
    this.cx = v.cx;
    this.cy = v.cy;
  }

  /*! Construccion en la forma modulo-argumento
      @param modulo Modulo del vector
      @param arg    Argumento      
     \brief CONSTRUCTOR. Constructor en la forma modulo-argumento */
  public Vector(double modulo, Angulo arg) {
    this.cx = modulo * Math.Cos(arg.Rad);
    this.cy = modulo * Math.Sin(arg.Rad);
  }

  /*---------------*/
  /* PROPIEDADES   */
  /*---------------*/
  /*! Leer/establecer el valor de la coordenada x
      \brief [get,set] Coordenada x                  */    
  public double x {
    get {
      return this.cx;
    }
    set {
      this.cx = value;
    }
  }
  
  /*! Leer/establecer el valor de la coordenada y
      \brief [get,set] Coordenada y                    */
  public double y {
    get {
      return this.cy;
    }
    set {
      this.cy=value;
    }
  }
  
  /*! Leer/establecer el modulo
      \brief [get,set] Modulo del vector   */
  public double Modulo {
    get {
      return Calc_Modulo();
    }
    set {
      //-- Obtener el Argumento que tiene el vector
      Angulo argumento = this.Arg;
      
      //-- Recalcular las nuevas coordenadas
      this.cx=value * Math.Cos(argumento.Rad);
      this.cy=value * Math.Sin(argumento.Rad);
    }
  }

  /*! Leer/establecer el argumento
      \brief [get,set] Argumento del vector   */
  public Angulo Arg {
    get {
      return Calcular_Argumento(this.cx, this.cy); 
    }
    set {
      //-- Obtener el modulo del vector
      double modulo = this.Modulo;
      
      //-- Recalcular las coordenadas
      this.cx= modulo * Math.Cos(value.Rad);
      this.cy= modulo * Math.Sin(value.Rad);
    }
  }

  /*--------------------------*/
  /*  METODOS ESTATICOS       */
  /*--------------------------*/
  /*! Dados dos valores x,y, que representan a un punto, se calcula
      cual es el modulo (distancia al origen)
    \brief Calcular el modulo a partir de coordenadas x,y   */
  public static double Calcular_Modulo(double x, double y)
  {
    return Math.Sqrt(Math.Pow(x,2) + Math.Pow(y,2));
  }
  
  /*! Dados dos valores x,y, que representan a un punto, se calcula
      cual es el argumento (distancia angular con eje x)
     \brief Calcular el modulo a partir de coordenas x,y      */
  public static Angulo Calcular_Argumento(double x, double y)
  {
    double arg;
    Angulo ang = new Angulo();
    
    //-- Asignamos el argumento 0 al vector nulo
    if (x==0 && y==0) return new Angulo(0);
    
    //-- Vector sobre eje y
    if (x==0) {
      if (y<0) return new Angulo(-90.0);
      else return new Angulo(90.0);
    }
    
    //-- Calcular el argumento
    arg = Math.Atan(y/x);
  
    //-- Garantizar que argumento este en el rango [180,-180)
  
    //-- Tercer cuadrante
    if (x<0 && y<0) {
      ang.Rad=arg-Math.PI;
      return ang;
    }  
      
    //-- Segundo cuadrante
    if (x<0 && y>=0) {
      ang.Rad=arg+Math.PI;
      return ang; 
    }      
  
    //-- Devolver el angulo
    ang.Rad=arg;
    return ang;
  }

  /*-------------------------------*/
  /* METODOS PUBLICOS              */
  /*-------------------------------*/
  
  /************************************************************************/
  /*! El vector define un punto en el plano. El Metodo Rotar permite
      girar este punto, un angulo determinado, con respecto a otro punto
      (centro).
      @param centro Vector de posicion del punto que hace de centro
      @param ang    Angulo a rotar el punto con respecto al centro
      \brief Rotar el punto definido por el vector, con respecto
             a un punto centro.                                           */
  /************************************************************************/
  public void Rotar(Vector centro, Angulo ang) {
    Vector radio;
    
    //-- Calcular radiovector
    radio=this-centro;
    
    //-- Rotar radiovector
    radio.Arg+=ang;
    
    //-- Obtener punto rotado
    this.cx=radio.cx+centro.cx;
    this.cy=radio.cy+centro.cy;
    
  }
  
  /**************************************************************************/
  /*! Calcular el angulo que forma el vector con el que se pasa como
      argumento.   
      El Criterio de signos es:<br>
      <ul>
      <li>Positivo: Si se rota el vector ese angulo en sentido        
       antihorario se obtiene el argumento de v
      <li>Negativo: Si se rota el vector ese angulo en sentido        
       horario, se obtiene el argumento de v 
      </ul>
    El valor absoluto indica la "distancia angular" y el signo hacia      
    donde esta el otro vector    
     @param v Vector con respecto al cual calcular la distancia angular       
      \brief Obtener el angulo que forma con otro vector                    */
  /**************************************************************************/
  public Angulo Distancia_Angular(Vector v) {
    
    return new Angulo(v.Arg - this.Arg);
  }
  
  /******************************************************************/
  /* Devolver un vector unitario (modulo unidad y mismo argumento)  */
  /******************************************************************/
  /*! Se crea un nuevo vector, con modulo unidad y argumento el mismo
      que el vector sobre el que se aplica
      \brief Devolver vector unitario                                */
  public Vector Unitario() {
    return new Vector (1,this.Arg);
  }

  /*-------------------------------*/
  /*  OPERADORES SOBRECARGADOS     */
  /*-------------------------------*/
  /*! Operador +. Ejemplo: v = w + z
       \brief Suma de vectores */
  public static Vector operator+(Vector a, Vector b) {
    return new Vector (a.x + b.x, a.y + b.y);
  }

  /*! Operador - binario. Ejemplo: v = w - z
      \brief Resta de vectores                     */
  public static Vector operator-(Vector a,Vector b) {
    return new Vector (a.x - b.x, a.y - b.y);
  }
  
  /*! Operador - unario. Ejemplo: v = -z
      \brief Obtener vector inverso        */
  public static Vector operator-(Vector a) {
    return new Vector (-a.x, -a.y);
  }
  
  /*! Multiplicacion por escalar. Ej: v = a * z.  Esta operacion es
      conmutativa. Se puede realizar v = z * a.
      \brief Producto de un Vector por constante  */
  public static Vector operator * (double k, Vector v) {
    return new Vector (v.x*k, v.y*k);
  }

  /* Producto de vector por constante */
  public static Vector operator * (Vector v, double k) {
    return new Vector (v.x*k, v.y*k);
  }
  
  /*! Division de un vector por un escalar. Ej: v = z/a. Esta
      operacion NO ES CONMUTATIVA.
      \brief Division de un vector por un escalar  */
  public static Vector operator / (Vector v, double k) {
    return new Vector (v.x/k, v.y/k);
  }

  /*! Obtener el producto escalar. Ejemplo: a = v1 * v2
      \brief Producto escalar                           */
  public static double operator *(Vector v1, Vector v2) {
    return v1.x*v2.x + v1.y*v2.y;
  }
  
  /*! Operador ==. Devuelve true si los vectores son iguales
      \brief Igualdad de vecores                            */
  public static bool operator == (Vector a, Vector b) {
    return (a.x == b.x) && (a.y == b.y);
  }
  
  /*! Operador !=. Devuelve true si los vectores son diferentes
      \brief Desigualdad de vectores                     */
  public static bool operator != (Vector a, Vector b) {
    return !(a==b);
  }
  
  //-- Igualdad. Es necesario sobrecargar este metodo
	public override bool Equals(object o) {
	  if (!(o is Vector)) {
		  return false;
		}
		return this == (Vector) o;
	}
  
  //-- Esto no lo entiendo muy bien... hay que ponerlo para
	//-- que no salga un warning al compilar...
	public override int GetHashCode() {
    return 1;
  }

  /*------------------------*/
  /* METODOS SOBRECARGADOS  */
  /*------------------------*/
  /* Conversion a una cadena */
  /*! Metodo para poder imprimir el vector en cartesianas. Esto permite hacer
      cosas del tipo: Console.WriteLine("Vector: {0}",v), siendo 'v' un
      objeto de tipo Vector
      \brief Convertir el vector a una cadena (cartesianas)    */
  public override string ToString() {
    String s = String.Format("({0:f3}; {1:f3})",this.cx,this.cy);
    return s;
  }

  /*-----------------------*/
  /* METODOS PRIVADOS      */
  /*-----------------------*/

  /************************/
  /*  Calcular el modulo  */
  /************************/
  private double Calc_Modulo() {
    return Math.Sqrt(Math.Pow(this.cx,2) + Math.Pow(this.cy,2));
  }

  /*-----------------------*/
  /* DATOS PRIVADOS        */
  /*-----------------------*/
  private double cx=0.0;  // Coordenada x
  private double cy=0.0;  // Coordenada y
}
