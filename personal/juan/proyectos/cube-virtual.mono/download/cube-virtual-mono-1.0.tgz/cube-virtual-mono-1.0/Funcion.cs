//********************************************************************
//* Funcion.cs   (c) Juan Gonzalez.  Enero 2005                      *
//*------------------------------------------------------------------*
//*  Clase para manejo de funciones                                  *
//*  En este fichero se encuentra la clase principal y sus derivadas *
//*------------------------------------------------------------------*
//* Licencia GPL                                                     *
//********************************************************************

using System;

/*! \example test-Funcion.cs
    Programa para hacer pruebas de la clase Funcion
*/

//----------------------------------------------------------------------
/*! Esta clase permite definir nuevas funciones f:(RxR)-->R utilizando
    las operaciones + y *, a partir de funciones basicas, como la
    funcion constante o una sinusoidal. Todas las funciones tiene dos
    argumetos: x,t. <br>
    Si f1 y f2 son dos objetos del tipo funcion, se pueden hacer cosas
    del tipo:  f3 = 2*f1 + 5.3*f2.  La nueva funcion, f3, queda definida
    mediante un arbol abstracto de datos, que representa la estructura
    anterios. Cada vez que se evalua f3(x,t), se recorre el arbol y 
    se calcula el valor final<br>
    Al imprimir una funcion que es combinacion lineal de otras mas 
    basicas, se recorre el arbol y se imprimen todos los nodos. Resulta
    muy util en la depuracion. 
    \brief  Clase para el manejo de funciones f:(RxR)-->R.             */
//----------------------------------------------------------------------
public class Funcion
{

  /***********************/
  /* CONSTRUCTORES       */
  /***********************/
  //------------------------------------------------------
  /*! Constructor por defecto. No se hace nada
      \brief CONSTRUCTOR. Crear una nueva funcion        */
  //------------------------------------------------------
  public Funcion()
  {
  }

  public static void Test()
  { 
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
  //-------------------------------------------------------------------
  /*! Es un metodo polimorfico. Evalua el valor de la funcion. Segun
      el tipo de funcion, calcula un valor u otro
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public virtual double Valor(double x, double t)
  {
    Console.WriteLine("f(x={0},t={1})",x,t);
    return 0.0;
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public virtual Funcion Clonar()
  {
     Console.WriteLine("Clonar!");
     return new Funcion();
  }
  
  /*----------------------------*/
	/* SOBRECARGA DE OPERADORES   */
	/*----------------------------*/
  //-- Suma de funciones
  //-----------------------------------------------------------------
  /*! Calcula una nueva funcion, suma de las dos funciones sumando:
      f(x,t)=f1(x,t) + f2(x,t)
      \brief Operador suma de funciones                             */
  //-----------------------------------------------------------------    
  public static Funcion operator + (Funcion f1, Funcion f2) {
    return new FuncionSuma(f1,f2);
	}
  
  //----------------------------------------------------------------------
  /*! Calcula la funcion: r(x,t) = f(x,t) + k
      \brief Operador suma de funcion y constante. CONMUTATIVA           */
  //----------------------------------------------------------------------
  public static Funcion operator + (Funcion f, double k) {
    return new FuncionSuma(f,new FuncionCte(k));
  }
  
  //-- Suma de constante + funcion
  public static Funcion operator + (double k, Funcion f) {
    return f + k;
  }
  
  //-----------------------------------------------------------------------
  /*! Calcula la funcion: p(x,t) = f1(x,t) * f2(x,t)
      \brief Operador multiplicacion de funcion por funcion               */
  //-----------------------------------------------------------------------
  public static Funcion operator * (Funcion f1, Funcion f2) {
    return new FuncionProducto(f1,f2);
  }
  
  //------------------------------------------------------------------------
  /*! Calcula la funcion r(x,t) = k * f(x,t)
      \brief Operador multiplicacion de constante por funcion. CONMUTATIVA */
  //-------------------------------------------------------------------------
  public static Funcion operator * (double k, Funcion f) {
    return new FuncionProducto(new FuncionCte(k),f);
  }  
  
  //-- Producto funcion * constante
  public static Funcion operator * (Funcion f, double k) {
    return k*f;
  }
  
  //-- Operador - unicario
  //------------------------------------------------------------------------
  /*! Calcula la funcion r(x,t) = -f(x,t)
      \brief Operador - unario                                             */
  //------------------------------------------------------------------------
  public static Funcion operator - (Funcion f) {
    return -1*f;
  }
  
  //------------------------------------------------------------------------
  /*! Calcula la funcion r(x,t) = f1 - f2                               
      \brief Operador de resta de dos funciones                            */
  //------------------------------------------------------------------------
  public static Funcion operator - (Funcion f1, Funcion f2) {
    return f1 + (-f2);
  }

}

//-------------------------------------------------------------
//--   CLASES DERIVADAS
//-------------------------------------------------------------

//----------------------------------------------------------------------
/*! Se utiliza para definir productos de funciones. Los objetos de este
    tipo son nodos intermedios del arbol abstracto de datos.
    <b>No esta pensada para ser utilizada directamente por el 
    usuario</b>.
    \brief  Funcion producto de Funciones                             */
//----------------------------------------------------------------------
class FuncionProducto : Funcion
{
  
  //--------------------------
  //-- CONSTRUCTORES 
  //--------------------------
  
  //--------------------------------------------------------------------
  /*! Se crea la funcion f(x,t) = f1(x,t) * f2(x,t)
      @param f1 Funcion factor
      @param f2 Funcion factor                                   
      \brief CONSTRUCTOR. Crear una nueva funcion productos
        de dos funciones                                               */
  //--------------------------------------------------------------------
  public FuncionProducto(Funcion f1, Funcion f2)
  {
    //-- Establecer las funciones factores
    this.f1 = f1;
    this.f2 = f2;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
  
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es f1(x,t) * f2(x,t)
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    return f1.Valor(x,t) * f2.Valor(x,t);
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionProducto f;
     
     f = new FuncionProducto(this.f1.Clonar(),this.f2.Clonar());
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("({0} * {1})",f1,f2);
    return s;
  }
  
  //--------------------------
  //-- PROPIEDADES PRIVADAS
  //--------------------------
  //-- Factores del producto: f1 y f2
  Funcion f1;
  Funcion f2;
}




/*************************************/
/* Clase FuncionSuma                 */
/* Suma de funciones                 */
/*************************************/
//----------------------------------------------------------------------
/*! Se utiliza para definir sumas de funciones. Los objetos de este
    tipo son nodos intermedios del arbol abstracto de datos.
    <b>No esta pensada para ser utilizada directamente por el 
    usuario</b>.
    \brief  Funcion suma de Funciones                             */
//----------------------------------------------------------------------
public class FuncionSuma : Funcion
{
  
  //--------------------------
  //-- CONSTRUCTORES 
  //--------------------------
  
  //--------------------------------------------------------------------
  /*! Se crea la funcion f(x,t) = f1(x,t) + f2(x,t)
      @param s1 Funcion sumando
      @param s2 Funcion sumando                                  
      \brief CONSTRUCTOR. Crear una nueva funcion suma
        de dos funciones                                               */
  //--------------------------------------------------------------------
  public FuncionSuma(Funcion s1, Funcion s2)
  {
    //-- Establecer las funciones sumando
    this.s1 = s1;
    this.s2 = s2;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
 
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es f1(x,t) + f2(x,t)
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    return s1.Valor(x,t) + s2.Valor(x,t);
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionSuma f;
     
     f = new FuncionSuma(this.s1.Clonar(),this.s2.Clonar());
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("({0} + {1})",s1,s2);
    return s;
  }
  
  //--------------------------
  //-- PROPIEDADES PRIVADAS
  //--------------------------
  //-- Sumandos de la suma: s1 y s2
  Funcion s1;
  Funcion s2;
}


//---------------------------------------------------------------------------
//    F U N C I O N E S      P R I M I T I V A S            
//---------------------------------------------------------------------------



//----------------------------------------------------------------------
/*! Definicion de semiondas. Son funciones que tienen el lobulo positivo
    de las sinusoidales, y que tambien son periodicas. Los parametros
    que la definen son: Altura (equivalente a la amplitud en las 
    sinusoidales), Anchura del lobulo (L) (equivalente a la longitud de 
    onda /2 de las sinusoidales), el periodo espacial (S) y la frecuencia 
    (frec)
    \brief Funciones Semisinusoidales                                  */
//----------------------------------------------------------------------
class FuncionSemiSin : Funcion
{
   //--------------------
  //-- CONSTRUCTORES
  //--------------------
  
  //--------------------------------------------------------------------
  /*! Se crea una funcion semisinusoidal. Se utilizan los parametros
      Amplitud, Anchura, Periodo espacial y frecuencia
      @param amplitud  Amplitud de la onda
      @param anchura   Anchura del lobulo
      @param s         Periodo espacial
      @param frec      Frecuencia
      \brief CONSTRUCTOR. Crear una nueva funcion sinusoidal           */
  //--------------------------------------------------------------------
  public FuncionSemiSin(double amplitud, double anchura,
                        double s, double frec)
  {
    this.amplitud = amplitud;
    this.anchura = anchura;
    this.periodo_espacial = s;
    this.frec = frec;
    this.periodo = this.periodo_espacial/this.frec;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
 
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es A*sin(2PI(x/2*L - t/T)), si la x
      esta comprendida en el intervalo [t/T, t/T+L].
      Previamente hay que calcular el modulo S de x, y el modulo T de t
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    double xi,xs;
    double y;
    int Si,Ti;
  
    //-- Obtener valores enteros del periodo espacial y temporal
    Si = (int)Math.Round(this.periodo_espacial);
    Ti = (int)Math.Round(this.periodo);
    
    //-- Normalizar x,t
    x = x % Si;
    t = t % Ti;
    
    xi=this.frec*t;
    xs=(xi+this.anchura) %Si;
  
    if (x<0) x = x + Si;
    
    y = this.amplitud*Math.Sin(2*Math.PI*((x-xi)/(2*this.anchura)));
    
    //-- Caso 1
    if (xi<xs) {
      if (x>=xi && x<=xs) return y;
      else return 0;
    }  
    
    //-- Caso 2 (xi>xs)
    if (x<xi && x>xs)
      return 0;
      else {
       if (x>=xi)
          return y;
       else 
         y = this.amplitud*Math.Sin
             (2*Math.PI*((x-(anchura+xs))/(2*this.anchura)));
        return y;
      }      
      
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionSemiSin f;
     
     f = new FuncionSemiSin(this.amplitud,this.anchura,
                            this.periodo_espacial,this.frec);
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("SEMI-A{0}-L{1}-S{2}-F{3}",
                             this.amplitud, this.anchura,
                             this.periodo_espacial, this.frec);
    return s;
  }
  
  //--------------------------
  //-- PROPIEDADES 
  //--------------------------
 
  //------------------------------------------------------------------
  /*! Establecer/leer la amplitud de la onda
      \brief Amplitud de la onda                                      */
  //------------------------------------------------------------------
  public double Amplitud 
  {
    get {
      return this.amplitud;
    }
    set {
      this.amplitud=value;
    }
  }
  
  //------------------------------------------------------------------
  /*! Establecer/leer la anchura de la semionda
      \brief Anchura del lobulo de la semionda                      */
  //------------------------------------------------------------------
  public double Anchura 
  {
    get {
      return this.anchura;
    }
    set {
      this.anchura=value;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Establecer/leer el periodo espacial
      \brief Periodo espacial                                        */
  //-------------------------------------------------------------------    
  public double Periodo_espacial
  {
    get {
      return this.periodo_espacial;
    }
    set {
      this.periodo_espacial=value;
      //-- El periodo depende de la frecuencia y el periodo_espacial
      //-- Recalcularlo
      this.periodo=this.periodo_espacial/this.frec;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Establecer/leer la frecuencia
      \brief Frecuencia                                               */
  //-------------------------------------------------------------------
  public double Frec
  {
    get {
      return this.frec;
    }
    set {
      this.frec=value;
      //-- El periodo depende de la frecuencia y el periodo espacial
      //-- Recalcularlo
      this.periodo=this.periodo_espacial/this.frec;
    }
  }
  
  //--------------------------------------------------------------------
  /*! Leer el periodo
      \brief Periodo                                                   */
  //--------------------------------------------------------------------
  public double Periodo
  {
    get {
      return periodo;
    }
  }
  
  //--------------------------
  //-- PROPIEDADES PRIVADAS  
  //--------------------------
  //-- Amplitud de la semionda
  double amplitud;
  
  //-- Anchura del lobulo
  double anchura;
  
  //-- Periodo espacial (longitud de onda)
  double periodo_espacial;
  
  //-- Frecuencia
  double frec;
  
  //-- Periodo. Frecuencia y periodo estan relacionados
  //-- por la ecuacion: periodo = periodo_espacial/frec;
  //-- Para algunos calculos es mas sencillo usar el periodo
  double periodo;
}  


//----------------------------------------------------------------------
/*! Definicion de ondas cuadradas periodicas
    de las sinusoidales, y que tambien son periodicas. Los parametros
    que la definen son: Altura (equivalente a la amplitud en las 
    sinusoidales), Anchura del lobulo (L) (equivalente a la longitud de 
    onda /2 de las sinusoidales) y el periodo espacial (S)
    \brief Funciones Semisinusoidales                                  */
//----------------------------------------------------------------------
class FuncionCuadrada : Funcion
{
   //--------------------
  //-- CONSTRUCTORES
  //--------------------
  
  //--------------------------------------------------------------------
  /*! Se crea una funcion cuadrada. Se utilizan los parametros
      Amplitud, Anchura, Periodo espacial y frecuencia
      @param amplitud  Altura del cuadrado
      @param anchura   Anchura de la base
      @param s         Periodo espacial
      @param frec      Frecuencia
      \brief CONSTRUCTOR. Crear una nueva funcion cuadrada            */
  //--------------------------------------------------------------------
  public FuncionCuadrada(double amplitud, double anchura,
                    double s, double frec)
  {
    this.amplitud = amplitud;
    this.anchura = anchura;
    this.periodo_espacial = s;
    this.frec = frec;
    this.periodo = this.periodo_espacial/this.frec;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
 
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es A cuando x esta en el intervalo [0,anchura]
      en el instante incial. La onda se propaga con el tiempo
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    double xi,xs;
    double y;
    int Si,Ti;
  
    //-- Obtener valores enteros del periodo espacial y temporal
    Si = (int)Math.Round(this.periodo_espacial);
    Ti = (int)Math.Round(this.periodo);
    
    //-- Normalizar x,t
    x = x % Si;
    t = t % Ti;
    
    xi=this.frec*t;
    xs=(xi+this.anchura) %Si;
  
    if (x<0) x = x + Si;
    
    y=this.amplitud;
    
    //Console.WriteLine("x: {0}",x);
    //-- Caso 1
    if (xi<xs) {
      if (x>=xi && x<=xs) return y;
      else return 0;
    }  
    
    //-- Caso 2 (xi>xs)
    if (x<xi && x>xs)
      return 0;
      else return y;  
      
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionCuadrada f;
     
     f = new FuncionCuadrada(this.amplitud,this.anchura,
                            this.periodo_espacial,this.frec);
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("{0}*Cuadrada(L={1},S={2},frec={3})",
                             this.amplitud, this.anchura,
                             this.periodo_espacial, this.frec);
    return s;
  }
  
  //--------------------------
  //-- PROPIEDADES 
  //--------------------------
 
  //------------------------------------------------------------------
  /*! Establecer/leer la amplitud de la onda
      \brief Amplitud de la onda                                      */
  //------------------------------------------------------------------
  public double Amplitud 
  {
    get {
      return this.amplitud;
    }
    set {
      this.amplitud=value;
    }
  }
  
  //------------------------------------------------------------------
  /*! Establecer/leer la anchura de la semionda
      \brief Anchura del lobulo de la semionda                      */
  //------------------------------------------------------------------
  public double Anchura 
  {
    get {
      return this.anchura;
    }
    set {
      this.anchura=value;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Establecer/leer el periodo espacial
      \brief Periodo espacial                                        */
  //-------------------------------------------------------------------    
  public double Periodo_espacial
  {
    get {
      return this.periodo_espacial;
    }
    set {
      this.periodo_espacial=value;
      //-- El periodo depende de la frecuencia y el periodo_espacial
      //-- Recalcularlo
      this.periodo=this.periodo_espacial/this.frec;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Establecer/leer la frecuencia
      \brief Frecuencia                                               */
  //-------------------------------------------------------------------
  public double Frec
  {
    get {
      return this.frec;
    }
    set {
      this.frec=value;
      //-- El periodo depende de la frecuencia y el periodo espacial
      //-- Recalcularlo
      this.periodo=this.periodo_espacial/this.frec;
    }
  }
  
  //--------------------------
  //-- PROPIEDADES PRIVADAS  
  //--------------------------
  //-- Amplitud de la semionda
  double amplitud;
  
  //-- Anchura del lobulo
  double anchura;
  
  //-- Periodo espacial (longitud de onda)
  double periodo_espacial;
  
  //-- Frecuencia
  double frec;
  
  //-- Periodo. Frecuencia y periodo estan relacionados
  //-- por la ecuacion: periodo = periodo_espacial/frec;
  //-- Para algunos calculos es mas sencillo usar el periodo
  double periodo;
}  

//----------------------------------------------------------------------
/*! Definicion de funciones Sinusoidales. Tienen tres parametros
    asociados: Amplitud, Longitud de onda y Frecuencia.<br>
    <b>Esta esa de las funciones primitivas</b>
    \brief  Funciones Senoidales                                       */
//----------------------------------------------------------------------
class FuncionSin : Funcion
{
  //--------------------
  //-- CONSTRUCTORES
  //--------------------
  
  //--------------------------------------------------------------------
  /*! Se crea una funcion sinusoidal. Se utilizan los parametros
      Amplitud, longitud de onda y frecuencia
      @param amplitud  Amplitud de la onda
      @param long_onda Longitud de onda
      @param fase_ini  Fase inicial
      @param frec      Frecuencia
      \brief CONSTRUCTOR. Crear una nueva funcion sinusoidal           */
  //--------------------------------------------------------------------
  public FuncionSin(double amplitud, double long_onda, 
                    double fase_ini, double frec)
  {
    this.amplitud = amplitud;
    this.long_onda = long_onda;
    this.fase_ini = fase_ini;
    this.frec = frec;
    this.periodo = this.long_onda/frec;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
 
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es A*sin(2PI(x/long - t/T))
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    double y;
  
    y = this.amplitud*Math.Sin(
             2*Math.PI*(x/this.long_onda - t/this.periodo) 
             + this.fase_ini);
    return y;
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionSin f;
     
     f = new FuncionSin(this.amplitud,this.long_onda,
                        this.fase_ini, this.frec);
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("SIN-A{0}-L{1}-FI{2}-F{3}",
                             this.amplitud, this.long_onda,
                             this.fase_ini, this.frec);
    return s;
  }
  
  //--------------------------
  //-- PROPIEDADES 
  //--------------------------
 
  //------------------------------------------------------------------
  /*! Establecer/leer la amplitud de la onda
      \brief Amplitud de la onda                                      */
  //------------------------------------------------------------------
  public double Amplitud 
  {
    get {
      return this.amplitud;
    }
    set {
      this.amplitud=value;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Establecer/leer la longitud de onda
      \brief Longitud de onda                                         */
  //-------------------------------------------------------------------    
  public double Long_onda
  {
    get {
      return this.long_onda;
    }
    set {
      this.long_onda=value;
      //-- El periodo depende de la frecuencia y la longitud de onda
      //-- Recalcularlo
      this.periodo=this.long_onda/this.frec;
    }
  }
  
  //--------------------------------------------------------------------
  /*! Establecer/leer la fase inicial                                  
      \brief Fase inicial                                              */
  //--------------------------------------------------------------------
  public double Fase_ini
  {
    get {
      return this.fase_ini;
    }
    set {
      this.fase_ini=value;
    }
  }  
  
  //-------------------------------------------------------------------
  /*! Establecer/leer la frecuencia
      \brief Frecuencia                                               */
  //-------------------------------------------------------------------
  public double Frec
  {
    get {
      return this.frec;
    }
    set {
      this.frec=value;
      //-- El periodo depende de la frecuencia y la longitud de onda
      //-- Recalcularlo
      this.periodo=this.long_onda/this.frec;
    }
  }
  
  //-------------------------------------------------------------------
  /*! Leer el periodo 
      \brief Periodo                                                   */
  //--------------------------------------------------------------------
  public double Periodo
  {
    get {
      return this.periodo;
    }
  }
  
  //--------------------------
  //-- PROPIEDADES PRIVADAS  
  //--------------------------
  //-- Amplitud de la onda
  double amplitud;
  
  //-- Longitud de onda
  double long_onda;
  
  //-- Fase inicial
  double fase_ini;
  
  //-- Frecuencia
  double frec;
  
  //-- Periodo. Frecuencia y periodo estan relacionados
  //-- por la ecuacion: periodo = long_onda/frec;
  //-- Para algunos calculos es mas sencillo usar el periodo
  double periodo;
}

//----------------------------------------------------------------------
/*! Definicion de funciones constantes. Solo tienen un parametro 
    asociado: la constante<br>
    <b>Esta es una de las funciones primitivas</b>
    \brief  Funciones Constantes                                      */
//----------------------------------------------------------------------
public class FuncionCte : Funcion
{
  //--------------------
  //-- CONSTRUCTORES
  //--------------------
  //-- Construccion a partir de la constante pasada
  //--------------------------------------------------------------------
  /*! Se crea una funcion constante. Se utiliza el parametro k, que es
      la constante.
      @param k  Constante
      \brief CONSTRUCTOR. Crear una nueva funcion constante           */
  //--------------------------------------------------------------------
  public FuncionCte(double k)
  {
    this.cte=k;
  }
  
  //----------------------------
  //-- METODOS
  //----------------------------
 
  //-------------------------------------------------------------------
  /*! El valor de esta funcion es la constante, con independencia
      de los parametros x,t
      @param x Parametro x
      @param t Parametro t
      \brief Devolver el valor de la funcion                          */
  //-------------------------------------------------------------------
  public override double Valor(double x, double t)
  {
    return this.cte;
  }
  
  //---------------------------------------------------------------------
  /*! Se crea una funcion nueva "clonada" y se devuelve.
      \brief Crear una copia de la funcion actual                      */
  //---------------------------------------------------------------------
  public override Funcion Clonar()
  {
     FuncionCte f;
     
     f = new FuncionCte(this.cte);
     return f;
  }
  
  //--------------------------------------------------------------------
  /*! Metodo usado para la impresion                         
      \brief Convertir a una cadena                                    */
  //--------------------------------------------------------------------
  public override string ToString() 
  {
    String s = String.Format("f_{0}",this.cte);
    return s;
  }
  
  //---------------------------
  //-- PROPIEDADES 
  //---------------------------
  
  //------------------------------------------------------------------
  /*! Establecer/leer la constante
      \brief Constante                                               */
  //------------------------------------------------------------------
  public double Cte
  {
    get {
      return this.cte;
    }
    set {
      this.cte=value;
    }
  }
  
  //---------------------------
  //-- Propiedades privadas 
  //---------------------------
  double cte;
}
