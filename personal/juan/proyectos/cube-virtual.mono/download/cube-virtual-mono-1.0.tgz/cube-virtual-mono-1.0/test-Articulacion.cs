/****************************************************/
/* test-Articulacion.cs  Juan Gonzalez. Marzo 2005  */
/*--------------------------------------------------*/
/* Pruebas de la clase articulacion                 */
/***************************************************/
/*-------------------------------------------------------------------------
 $Id: test-Articulacion.cs,v 1.1 2005/03/20 11:50:35 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/cube-virtual.mono/test-Articulacion.cs,v $
---------------------------------------------------------------------------*/

using System;
class Test_Articulacion 
{
  static void Main() {
  
    //---------------------------------
    //-- Pruebas de construccion
    //---------------------------------
    //-- Crear una articulacion inicializada a 0
    Articulacion a1 = new Articulacion();
    
    //-- Crear una articulacion a partir de otra
    Articulacion a2 = new Articulacion(a1);
    
    //-- Crear una articulacion a partir de un angulo y un vector
    Articulacion a3 = new Articulacion(new Angulo(30), new Vector(3,3));
    
    Console.WriteLine("Construccion: ");
    Console.WriteLine("a1: {0}",a1);
    Console.WriteLine("a2: {0}",a2);
    Console.WriteLine("a3: {0}",a3);
    
    //-------------------------------------
    //-- Cambiar el angulo y el vector
    //-------------------------------------
    a2.Angulo.Grad=20;
    a2.Vector.x=2;
    a2.Vector.y=2;
    
    a1.Angulo.Grad=10;
    a1.Vector.x=1;
    a1.Vector.y=1;
    
    Console.WriteLine("\nModificacion de las articulaciones: ");
    Console.WriteLine("a1: {0}",a1);
    Console.WriteLine("a2: {0}",a2);
    Console.WriteLine("a3: {0}",a3);
    
  }
}
