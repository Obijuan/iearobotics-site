/**********************************************/
/* Definicion de los registros para el 68HC08 */
/*--------------------------------------------*/
/* Juan Gonzalez. Febrero 2004.               */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/

/*-----------------*/
/* Puertos de E/S  */
/*-----------------*/
#define PORTA  (*(unsigned char *)0x0000)
#define PTA    PORTA
#define PORTB  (*(unsigned char *)0x0001)
#define PTB    PORTB
#define PORTC  (*(unsigned char *)0x0002)
#define PTC    PORTC
#define PORTD  (*(unsigned char *)0x0003)
#define PTD    PORTD
#define PORTE  (*(unsigned char *)0x0008)
#define PTE    PORTE

//-- Modo de los pines (entrada/salida)
#define DDRA   (*(unsigned char *)0x0004)
#define DDRB   (*(unsigned char *)0x0005)
#define DDRC   (*(unsigned char *)0x0006)
#define DDRD   (*(unsigned char *)0x0007)
#define DDRE   (*(unsigned char *)0x000C)

//-- Habilitacion de los pull-ups
#define PTAPUE (*(unsigned char *)0x000D)
#define PTCPUE (*(unsigned char *)0x000E)
#define PTDPUE (*(unsigned char *)0x000F)

/*-----------------------*/
/* Temporizador (TIM)    */
/*-----------------------*/
#define T1SC   (*(unsigned char *)0x0020)
#define T1CNTH (*(unsigned char *)0x0021)
#define T1CNTL (*(unsigned char *)0x0022)
#define T1MODH (*(unsigned char *)0x0023)
#define T1MODL (*(unsigned char *)0x0024)
#define T1SC0  (*(unsigned char *)0x0025)
#define T1CH0H (*(unsigned char *)0x0026)
#define T1CH0L (*(unsigned char *)0x0027)
#define T1SC1  (*(unsigned char *)0x0028)
#define T1CH1H (*(unsigned char *)0x0029)
#define T1CH1L (*(unsigned char *)0x002A)

/******************************************/
/* Comunicaciones serie Asincronas (SCI)  */
/******************************************/
#define SCC1 (*(unsigned char *)0x0013)
#define SCC2 (*(unsigned char *)0x0014)
#define SCC3 (*(unsigned char *)0x0015)
#define SCS1 (*(unsigned char *)0x0016)
#define SCS2 (*(unsigned char *)0x0017)
#define SCDR (*(unsigned char *)0x0018)
#define SCBR (*(unsigned char *)0x0019)

	
/********************/
/* Configuracion    */
/********************/
#define CONFIG1 (*(unsigned char *)0x001F)
	
/*	
	SPCR 	= 0x0010 ; SPI (Syncronous communications) 
	SPSCR 	= 0x0011 
	SPDR 	= 0x0012 
	
	

	INTKBSCR= 0x001a ; Keyboard interrupt control/status
	INTKBIER= 0x001b

	TBCR	= 0x001c ; Time base module

	INTSCR 	= 0x001d ; IRQ status/control

	CONFIG2 = 0x001e ; System configuration
 

	

	T2SC 	= 0x002b ; Timer 2
	T2CNTH	= 0x002c 
	T2CNTL  = 0x002d
	T2MODH 	= 0x002e
	T2MODL 	= 0x002f
	T2SC0 	= 0x0030
	T2CH0H	= 0x0031
	T2CH0L 	= 0x0032
	T2SC1 	= 0x0033
	T2CH1H	= 0x0034
	T2CH1L	= 0x0035

	PCTL 	= 0x0036 ; Phase lock loop (for crystals)
	PBWC 	= 0x0037 
	PMSH 	= 0x0038
	PMSL 	= 0x0039
 	PMRS 	= 0x003A
 	PMDS 	= 0x003B

 	ADSCR 	= 0x003C ; A to D converter 
	ADR 	= 0x003D 
	ADCLK 	= 0x003E 

	SBSR 	= 0xfe00 ; System integration 
	SRSR 	= 0xfe01 
	SUBAR 	= 0xfe02 
	SBFCR 	= 0xfe03

	INT1 	= 0xfe04 ; Interrupt status
	INT2 	= 0xfe05

	INT3 	= 0xfe06 
	FLTCR 	= 0xfe07 ; Flash test/programming 
	FLCR 	= 0xfe08
 
	BRKH 	= 0xfe09 ; Hardware breakpoint 
	BRKL 	= 0xfe0a 
	BRKSCR 	= 0xfe0b
 
	LVISR 	= 0xfe0c ; Low voltage detect 
	FLBPR 	= 0xff80 ; Flash boot protect 
	COPCTL 	= 0xffff ; COP (Computer operating properly) control 

	;(C)opywrite P&E Microcomputer Systems, 1998 
	; You may use this code freely as long as this copyright notice 
	; is included.

*/
