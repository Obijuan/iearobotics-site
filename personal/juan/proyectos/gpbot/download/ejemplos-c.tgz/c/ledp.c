/*************************************************/
/* ledp.c  (c) Juan Gonzalez. Marzo 2004         */
/*-----------------------------------------------*/
/* Ejemplo que hace parpadear un led conectado   */
/* al bit 0 del puerto B                         */
/* Se cambia el estado del led cada 0.5 segs     */
/*-----------------------------------------------*/
/* LICENCIA GPL                                  */
/*************************************************/
#include "mc68hc908gp32.h"
#include "delay.h"

void main(void)
{
	/*----------------------------*/
	/* Configurar el sistema      */
	/*----------------------------*/
	CONFIG1|=0x01;  //-- Deshabilitar el COP
  DDRB=0xFF;      //-- Configurar Puerto B para salida
	PORTB=0x00;     //-- Poner a 0 Puerto B

	//-- Inicializar el modulo de pausa
  delay_init();
	
  //-- Bucle principal
	for (;;) {
    PORTB^=0x01; //-- Cambiar de estado bit0 del puerto B
    delay(5);    //-- Pausa de 500ms
  }
}
