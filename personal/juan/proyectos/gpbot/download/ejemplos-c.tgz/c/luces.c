/*************************************************/
/* luces.c  (c) Juan Gonzalez. Marzo 2004        */
/*-----------------------------------------------*/
/* Juego de luces por el puerto B. Se hace hace  */
/* el efecto "coche fantastico"                  */
/*-----------------------------------------------*/
/* LICENCIA GPL                                  */
/*************************************************/
#include "mc68hc908gp32.h"
#include "delay.h"

unsigned char i;

void main(void)
{
	/*----------------------------*/
	/* Configurar el sistema      */
	/*----------------------------*/
	CONFIG1|=0x01;  //-- Deshabilitar el COP
  DDRB=0xFF;      //-- Configurar Puerto B para salida
	PORTB=0x00;     //-- Poner a 0 Puerto B

	//-- Inicializar el modulo de pausa
  delay_init();
	
  //-- Establecer valor inicial
	PORTB=0x01;  
	
	//-- Bucle principal
	for (;;) {
		//-- Mover leds en un sentido
		for (i=0; i<7; i++) {
			delay(1);
			PORTB=(PORTB<<1);
		}
		
		//-- Mover leds en el otro sentido
		for (i=0; i<7; i++) {
			delay(1);
			PORTB=(PORTB>>1);
		}
  }	
}
