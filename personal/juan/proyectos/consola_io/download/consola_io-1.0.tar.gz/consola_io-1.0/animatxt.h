/**************************************************************************/
/* animatxt.h                                                             */
/*  (C) Juan Gonzalez. Julio 2004                                         */
/* ---------------------------------------------------------------------- */
/* Rutinas de animacion en ASCII                                          */
/*------------------------------------------------------------------------*/
/* LICENCIA GPL                                                           */
/**************************************************************************/
/*-------------------------------------------------------------------------
 $Id: animatxt.h,v 1.1 2004/08/17 18:13:21 juan Exp $
 $Revision: 1.1 $
 $Source: /usr/local/cvs/consola_io/animatxt.h,v $
---------------------------------------------------------------------------*/

#ifndef _ANIMATXT_H
#define _ANIMATXT_H

/*---------------*/
/* PROTOTIPOS    */
/*---------------*/

/************************************************************/
/* Inicializar la animacion de la barrita hacia la derecha  */
/************************************************************/
void animatxt_barra_init();

/*******************************************************/
/* Animacion: Barrita que da vueltas hacia la derecha  */
/*-----------------------------------------------------*/
/* Devuelve: El siguiente caracter que toca imprimir   */
/*******************************************************/
char animatxt_barra();

/**********************************************************/
/* Animacion: Barrita que da vueltas hacia la derecha.    */
/* Imprime en la salida estandar el siguiente caracter    */
/* y retrocede el cursor una posicion hacia la izquierda  */
/**********************************************************/
void animatxt_barra_print();

#endif  // _ANIMATXT_H
