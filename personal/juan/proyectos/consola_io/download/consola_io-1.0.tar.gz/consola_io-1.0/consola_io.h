/*****************************************************************************/
/* consola_io.H                                                              */
/*---------------------------------------------------------------------------*/
/* Prototipos y definiciones del modulo consola_io.c                         */
/*---------------------------------------------------------------------------*/
/* LICENCIA GPL                                                              */
/*****************************************************************************/
/*----------------------------------------------------------------------------
 $Id: consola_io.h,v 1.1 2004/08/17 18:13:21 juan Exp $
 $Revision: 1.1 $
 $Source: /usr/local/cvs/consola_io/consola_io.h,v $
-----------------------------------------------------------------------------*/


#ifndef _CONSOLA_IO_H
#define _CONSOLA_IO_H

#define ESC 27

/*-----------------*/
/*   PROTOTIPOS    */
/*-----------------*/

/*************************************************************/
/* Configurar la entrada estandar para que las lecturas sean */
/* no bloqueantes.                                           */
/*                                                           */
/* DEVUELVE:                                                 */
/*  -  0 Si no ha habido error                               */
/*  - -1 Si ha ocurrido algun error                          */
/*************************************************************/
int consola_io_open(void);

/**********************************************/
/* Recuperar el estado anterior de la consola */
/**********************************************/
void consola_io_close(void);

/************************************************************************/
/*  Indicar si hay un caracter pendiente de ser leido. La funcion       */
/*  devuelve:                                                           */
/*    0 --> No hay caracteres pendientes                                */
/*    1 --> Si hay caracteres pendientes                                */
/************************************************************************/
int consola_io_kbhit(void);

/******************************************************************/
/*  Devolver el caracter leido por el teclado. Si no hay ningun   */
/*  caracter pendiente de ser leido se espera hasta que lo haya.  */
/******************************************************************/
char consola_io_getch(void);


#endif  // _CONSOLA_IO_H
