/**************************************************************************/
/*  animatxt.c                                                            */
/* (C) Juan Gonzalez. Julio 2004                                          */
/* ---------------------------------------------------------------------- */
/* Rutinas de animacion en ASCII                                          */
/*------------------------------------------------------------------------*/
/* LICENCIA GPL                                                           */
/**************************************************************************/
/*-------------------------------------------------------------------------
 $Id: animatxt.c,v 1.1 2004/08/17 18:13:21 juan Exp $
 $Revision: 1.1 $
 $Source: /usr/local/cvs/consola_io/animatxt.c,v $
---------------------------------------------------------------------------*/

#include <stdio.h>
#include "animatxt.h"

/*-------------*/
/* VARIABLES   */
/*-------------*/

/* Animacion: Barrita giratoria */
static char barra[]={'\\','|','/','-'};
static int i_barra=0;  //-- Siguiente caracter de la barra que toca

/************************************************************/
/* Inicializar la animacion de la barrita hacia la derecha  */
/************************************************************/
void animatxt_barra_init()
{
  i_barra=0;
}

/*******************************************************/
/* Animacion: Barrita que da vueltas hacia la derecha  */
/*-----------------------------------------------------*/
/* Devuelve: El siguiente caracter que toca imprimir   */
/*******************************************************/
char animatxt_barra()
{
  //-- Actualizar indice de barra
   i_barra=(i_barra+1)%4;
  
  //-- Devolver el siguiente caracter
  return barra[i_barra];
}

/**********************************************************/
/* Animacion: Barrita que da vueltas hacia la derecha.    */
/* Imprime en la salida estandar el siguiente caracter    */
/* y retrocede el cursor una posicion hacia la izquierda  */
/**********************************************************/
void animatxt_barra_print()
{
  char c;
  
  //-- Obtener el siguiente caracter
  c=animatxt_barra();
  
  //-- Actualizar barrita
  printf ("%c\b",c);
  fflush(stdout);
}
