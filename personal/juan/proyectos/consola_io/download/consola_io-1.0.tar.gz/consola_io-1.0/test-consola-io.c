/***************************************************************************/
/* test-consola-io.c                                                       */
/* (c) Juan Gonzalez. 2004                                                 */
/*-------------------------------------------------------------------------*/
/* Prueba del modulo consola-io                                            */
/* Se muestra un menu muy sencillo. El usuario puede elegir cualquier      */
/* opcion sin tener que pulsar la tecla enter. Mientras no se elige        */
/* ninguna opcion, se mueve una "barrita"                                  */
/*-------------------------------------------------------------------------*/
/* Licencia GPL                                                            */
/***************************************************************************/
/*-------------------------------------------------------------------------
 $Id: test-consola-io.c,v 1.2 2004/08/17 18:18:46 juan Exp $
 $Revision: 1.2 $
 $Source: /usr/local/cvs/consola_io/test-consola-io.c,v $
---------------------------------------------------------------------------*/

#include <stdio.h>

#include "consola_io.h"
#include "animatxt.h"


/*********************/
/* Imprimir el menu  */
/*********************/
void print_menu(void)
{
  printf ("\n");
  printf ("Men� de Opciones\n");
  printf ("----------------\n");
  printf ("1.-   Opcion 1\n");
  printf ("2.-   Opcion 2\n\n");
  printf ("SP.-  Volver a sacar el menu\n");
  printf ("ESC.- Terminar\n\n");
}

/**************************************/
/* Seleccionar las opciones del menu  */
/**************************************/
void menu(void)
{
  char c;

  print_menu();

  do {
    //-- Ha pulsado el usuario una tecla?
		if (consola_io_kbhit()) {
      
      //-- Si, leerla y seleccionar la opcion 
			c=consola_io_getch();
			switch(c) {
			case '1': printf ("Opcion 1\n");
				break;
			case '2': printf ("Opcion 2\n");
				break;
      case ' ': print_menu();
        break;
			}
		}	
		else {
      //-- Si no se ha pulsado ninguna tecla animamos la barrita
			animatxt_barra_print();
		}
  } while (c!=27);
}


/*----------------*/
/*     MAIN       */
/*----------------*/
int main (void)
{
  //-- Configurar la consola
  consola_io_open();
  
  //-- Inicializar animacion de la barrita que rota
  animatxt_barra_init();

  //-- Opciones del usuario
  menu();

  //-- Consola a su estado inicial
  consola_io_close();

  printf ("\n");
  return 0;
}
