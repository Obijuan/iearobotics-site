/**************************************************************************/
/*  consola_io.c   (C) 1996-2004. Juan Gonzalez.                          */
/* ---------------------------------------------------------------------- */
/*  Rutinas de E/S para la pantalla y el teclado.                         */
/*------------------------------------------------------------------------*/
/* consola_io.c                                                           */
/* (c) Juan Gonzalez. Julio 2004                                          */
/*------------------------------------------------------------------------*/
/* Este modulo cumple el estandar POSIX.1                                 */
/*                                                                        */
/* Este modulo deberia ser totalmente portable a Windows, utilizando la   */
/*  libreria Cygwin                                                       */
/*------------------------------------------------------------------------*/
/* LICENCIA GPL                                                           */
/**************************************************************************/
/*------------------------------------------------------------------------
 $Id: consola_io.c,v 1.1 2004/08/17 18:13:21 juan Exp $
 $Revision: 1.1 $
 $Source: /usr/local/cvs/consola_io/consola_io.c,v $
--------------------------------------------------------------------------*/

#include <termios.h>
#include <unistd.h>
#include <sys/select.h>
#include <stdio.h>

#include "consola_io.h"

//-- Tiempo de espera para el select, en micro-segundos
#define TIMEOUT_USEC 10000  


/*------------*/
/* VARIABLES  */
/*------------*/
static struct termios oldconsola,consola;


/*--------------*/
/* FUNCIONES    */
/*--------------*/

/*************************************************************/
/* Configurar la entrada estandar para que las lecturas sean */
/* no bloqueantes.                                           */
/*                                                           */
/* Se guarda la configuracion anterior de la consola         */
/*                                                           */
/* DEVUELVE:                                                 */
/*  -  0 Si no ha habido error                               */
/*  - -1 Si ha ocurrido algun error                          */
/*************************************************************/
int consola_io_open(void)
{
  /* Leer los parametros asociados a la consola */
  if (tcgetattr(STDIN_FILENO,&consola)==-1) {
    perror("Error en tcgetattr");
    return -1;
  }
  oldconsola = consola; /* Almacenar parametros para su posterior recup. */
  
  /* Cambiar parametros */
  consola.c_cc[VMIN]=1;
  consola.c_lflag&=~(ECHO|ICANON); 
  
  if (tcsetattr(STDIN_FILENO,TCSANOW,&consola)==-1) {
    perror("Error en tcsetattr");
    return -1;
  }
  
  return 0;
}

void consola_io_close(void)
/**********************************************/
/* Recuperar el estado anterior de la consola */
/**********************************************/
{
  if (tcsetattr(STDIN_FILENO,TCSANOW,&oldconsola)==-1) 
    perror("Error en tcsetattr");
}

/************************************************************************/
/*  Indicar si hay un caracter pendiente de ser leido. La funcion       */
/*  devuelve:                                                           */
/*    0 --> No hay caracteres pendientes                                */
/*    1 --> Si hay caracteres pendientes                                */
/************************************************************************/
int consola_io_kbhit(void)
{
  int n;
  fd_set rfd;
  struct timeval timeout;
  
  timeout.tv_sec  = 0;
  timeout.tv_usec = TIMEOUT_USEC;
  
  FD_ZERO(&rfd);
  FD_SET(STDIN_FILENO,&rfd);
  
  n = select(STDIN_FILENO+1,&rfd,NULL,NULL,&timeout);
  
  return n;
}

/******************************************************************/
/*  Devolver el caracter leido por el teclado. Si no hay ningun   */
/*  caracter pendiente de ser leido se espera hasta que lo haya.  */
/******************************************************************/
char consola_io_getch(void)
{
  int n;
  char c;
    
  while (!consola_io_kbhit());
  
  n = read(STDIN_FILENO,&c,1);
  
  return c;
}
