EESchema Schematic File Version 1
LIBS:power,./monolito,device,conn,linear,regul,74xx,cmos4000,adc-dac,memory,xilinx,special,analog_switches,./monolito.cache
EELAYER 23  0
EELAYER END
$Descr A4 11700 8267
Sheet 1 1
Title "Monolito"
Date "25 jun 2005"
Rev ""
Comp "www.iearobotics.com"
Comment1 "Libreria de componentes para esquemas con Kicad"
Comment2 "(c) Juan Gonzalez, 2005"
Comment3 "Licencia GPL"
Comment4 ""
$EndDescr
$Comp
L TEL6_DOC DOC?
U 1 1 42BD3431
P 3250 1500
F 0 "DOC?" H 3450 2150 60  0001 C C
F 1 "TEL6_DOC" H 3510 1280 60  0000 C C
	1    3250 1500
	1    0    0    -1  
$EndComp
$Comp
L CLEMA2 CT?
U 1 1 42BD2C8C
P 7900 2000
F 0 "CT?" H 8080 2370 60  0001 L C
F 1 "CLEMA2" H 7800 1900 60  0000 C C
	1    7900 2000
	1    0    0    -1  
$EndComp
$Comp
L LED_DOC DOC?
U 1 1 42BD2BC7
P 6300 950
F 0 "DOC?" H 6320 1100 60  0001 C C
F 1 "LED_DOC" H 6340 380 60  0000 C C
	1    6300 950 
	1    0    0    -1  
$EndComp
$Comp
L CLEMA3 CT?
U 1 1 42BD2895
P 7100 2000
F 0 "CT?" H 7280 2370 60  0001 L C
F 1 "CLEMA3" H 6900 1900 60  0000 C C
	1    7100 2000
	1    0    0    -1  
$EndComp
$Comp
L PULSADOR_DOC DOC?
U 1 1 42BD2567
P 6000 1850
F 0 "DOC?" H 6010 2020 60  0001 C C
F 1 "PULSADOR_DOC" H 6030 1670 60  0000 C C
	1    6000 1850
	1    0    0    -1  
$EndComp
$Comp
L PULSADOR S?
U 1 1 42BD2282
P 5450 1850
F 0 "S?" H 5210 1980 50  0001 C C
F 1 "PULSADOR" H 5260 1690 50  0000 C C
	1    5450 1850
	1    0    0    -1  
$EndComp
Text Notes 2460 1840 0    30   ~
telefonico RJ11
Text Notes 2580 1760 0    30   ~
Conector
$Comp
L TEL6 T?
U 1 1 42BAF834
P 2760 1500
F 0 "T?" H 2460 1920 60  0001 C C
F 1 "TEL6" H 2620 1400 60  0000 C C
	1    2760 1500
	1    0    0    -1  
$EndComp
$Comp
L JUMPER_TRIPLE JP?
U 1 1 42BAF271
P 8420 1180
F 0 "JP?" H 8520 1400 60  0001 C C
F 1 "JUMPER_TRIPLE" H 8500 1110 60  0000 C C
	1    8420 1180
	1    0    0    -1  
$EndComp
$Comp
L JUMPER JP?
U 1 1 42BAF0C3
P 7660 1180
F 0 "JP?" H 7710 1400 60  0001 C C
F 1 "JUMPER" H 7740 1110 60  0000 C C
	1    7660 1180
	1    0    0    -1  
$EndComp
$Comp
L CONDENSADOR C?
U 1 1 42BAEDCF
P 7300 1300
F 0 "C?" H 7380 1460 50  0001 L C
F 1 "CONDENSADOR" H 7180 1150 50  0000 L C
	1    7300 1300
	0    -1   -1   0   
$EndComp
$Comp
L CPOL C?
U 1 1 42BAEBB2
P 6850 1300
F 0 "C?" H 7000 1440 50  0001 L C
F 1 "CPOL" H 6910 1130 50  0000 L C
	1    6850 1300
	0    -1   -1   0   
$EndComp
Wire Notes Line
	1350 3450 1350 3050
Wire Notes Line
	2350 3450 1350 3450
Wire Notes Line
	2350 3050 2350 3450
Wire Notes Line
	1350 3050 2350 3050
Text Notes 1500 3350 0    60   ~
INTEGRADOS
Text Notes 1550 3200 0    60   ~
CIRCUITOS
$Comp
L MAX232 U?
U 1 1 42BAE524
P 1750 4800
F 0 "U?" H 1750 4900 70  0001 C C
F 1 "MAX232" H 1750 3900 70  0000 C C
	1    1750 4800
	1    0    0    -1  
$EndComp
Wire Notes Line
	7720 410  6220 410 
Wire Notes Line
	7720 610  7720 410 
Wire Notes Line
	6220 610  7720 610 
Wire Notes Line
	6220 410  6220 610 
Text Notes 6320 560  0    60   ~
COMPONENTES DISCRETOS
$Comp
L DIODO_LED D?
U 1 1 42BACC5B
P 5950 1150
F 0 "D?" H 5950 1250 50  0001 C C
F 1 "DIODO_LED" H 5950 1250 50  0000 C C
	1    5950 1150
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA2 R?
U 1 1 42BACC4D
P 5600 1150
F 0 "R?" V 5500 1150 50  0001 C C
F 1 "RESISTENCIA2" V 5500 1150 50  0000 C C
	1    5600 1150
	1    0    0    -1  
$EndComp
$Comp
L RESISTENCIA1 R?
U 1 1 42BACC3A
P 5250 1150
F 0 "R?" V 5150 1150 50  0001 C C
F 1 "RESISTENCIA1" V 5150 1160 50  0000 C C
	1    5250 1150
	1    0    0    -1  
$EndComp
Text Notes 1500 1850 0    30   ~
Pines del conector CT
Text Notes 1500 1750 0    30   ~
Documentacion
Wire Notes Line
	2250 450  1350 450 
Wire Notes Line
	2250 650  2250 450 
Wire Notes Line
	1350 650  2250 650 
Wire Notes Line
	1350 450  1350 650 
Text Notes 850  2000 0    30   ~
Conector tipo CT
$Comp
L CT_DOC CT_DOC?
U 1 1 42BACB5E
P 1800 1300
F 0 "CT_DOC?" H 1900 1000 60  0001 C C
F 1 "CT_DOC" H 1800 1050 60  0000 C C
F 2 "Conector tipo CT" H 2300 1100 50  0001 R B
	1    1800 1300
	1    0    0    -1  
$EndComp
Text Notes 1450 600  0    60   ~
CONECTORES
$Comp
L CT CT?
U 1 1 42BACB06
P 1250 1400
F 0 "CT?" V 1200 1400 60  0001 C C
F 1 "CT" V 1260 1400 60  0000 C C
	1    1250 1400
	1    0    0    -1  
$EndComp
$EndSCHEMATC
