/*********************************************************/
/* interface.c    (c) Juan Gonz�lez G�mez. Agosto 2002   */
/*-------------------------------------------------------*/
/* Crear el interfaz del modulo g-scterm                 */
/* Licencia GPL                                          */
/*-------------------------------------------------------*/
/* mail: juan@iearobotics.com                            */
/*********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"

void interface_create_app(interface_t *ifaz)
/***********************************************/
/*  Crear el interfaz de la ventana principal  */
/*  S�lo se debe llamar una vez a esta funcion */
/***********************************************/
{
  GladeXML *xml;
  
  /* Inicializar la estructura del interfaz */
  ifaz->main_window=NULL;
  ifaz->app_bar=NULL;
  ifaz->term_ascii=NULL;
  ifaz->term_hexa=NULL;
  ifaz->consola=NULL;
  ifaz->tool_limpiar=NULL;
  ifaz->tool_dtr=NULL;
  ifaz->tool_1200=NULL;
  ifaz->tool_9600=NULL;
  ifaz->file_quit=NULL;
  ifaz->acciones_dtr=NULL;
  ifaz->acciones_limpiar=NULL;
  ifaz->help_about=NULL;
  ifaz->notebook1=NULL;

  /* Leer el interfaz en XML */
  xml = glade_xml_new ("./g-scterm.glade", "app1", "Dominio");

  /*-------------------------------------*/
  /* Rellenar la estructura del interfaz */
  /* Con los widgets del fichero XML     */
  /*-------------------------------------*/
  /* Ventana principal */
  ifaz->main_window=glade_xml_get_widget(xml,"app1");
  /*-- STATUS BAR -- */
  ifaz->app_bar=glade_xml_get_widget(xml,"appbar1");

  /* Widget para el terminal */
  ifaz->term_ascii=glade_xml_get_widget(xml,"term_ascii");
  ifaz->term_hexa=glade_xml_get_widget(xml,"term_hexa");

  /* Widget para la consola */
  ifaz->consola=glade_xml_get_widget(xml,"consola");

  /* Widget para la BARRA DE HERRAMIENTAS */
  ifaz->tool_limpiar=glade_xml_get_widget(xml,"tool_limpiar");
  ifaz->tool_dtr=glade_xml_get_widget(xml,"tool_dtr");
  ifaz->tool_1200=glade_xml_get_widget(xml,"tool_1200");
  ifaz->tool_9600=glade_xml_get_widget(xml,"tool_9600");

  /*-- MENU FILE --*/
  ifaz->file_quit = glade_xml_get_widget (xml, "file_quit");

  /*-- MENU ACCIONES --*/
  ifaz->acciones_limpiar = glade_xml_get_widget (xml,"acciones_limpiar");
  ifaz->acciones_dtr = glade_xml_get_widget (xml, "acciones_dtr");

  /*-- MENU HELP --*/
  ifaz->help_about = glade_xml_get_widget (xml, "help_about");

  /*-- NOTEBOOK --*/
  ifaz->notebook1 = glade_xml_get_widget (xml, "notebook1");

  /*-----------------------*/
  /* Liberar el objeto xml */
  /*-----------------------*/
  g_object_unref (xml);

  /* Mostrar todos los widgets */
  gtk_widget_show_all(ifaz->main_window);
}

void interface_connect_signals(interface_t *ifaz)
/*******************************************/
/* Conectar las se�ales de retrollamada    */
/*******************************************/
{
  /* --- Se�al de DESTRUCCION --- */
  g_signal_connect (G_OBJECT (ifaz->main_window), "destroy",
		    G_CALLBACK (main_quit), NULL);

  /* -- BARRA DE HERRAMIENTAS -- */
  g_signal_connect (G_OBJECT(ifaz->tool_limpiar),"clicked",
		    G_CALLBACK(main_button),"1");
  g_signal_connect (G_OBJECT(ifaz->tool_1200),"clicked",
		    G_CALLBACK(main_button),"2");
  g_signal_connect (G_OBJECT(ifaz->tool_9600),"clicked",
		    G_CALLBACK(main_button),"3");

  g_signal_connect (G_OBJECT(ifaz->tool_dtr),"toggled",
		    G_CALLBACK(main_toggle_button),"1");

  /*-- MENU FILE --*/
  g_signal_connect (G_OBJECT(ifaz->file_quit), "activate",
		    G_CALLBACK(main_quit),NULL);

  /*-- MENU ACCIONES --*/
  g_signal_connect (G_OBJECT(ifaz->acciones_limpiar),"activate",
		    G_CALLBACK(main_button),"1");
  g_signal_connect (G_OBJECT(ifaz->acciones_dtr),"toggled",
		    G_CALLBACK(main_toggle_button),"2");

  /*-- MENU HELP --*/
  g_signal_connect (G_OBJECT(ifaz->help_about),"activate",
		    G_CALLBACK(help_about),NULL);
}

GtkWidget *interface_create_about()
/*********************************/
/* Crear la ventana de about     */
/*********************************/
{
  GladeXML *xml;
  GtkWidget *about;

  xml = glade_xml_new ("g-scterm.glade", "about1","dominio");
  about = glade_xml_get_widget (xml, "about1");

  g_object_unref(xml);

  return about;
}

