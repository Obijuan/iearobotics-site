/**************************************************************/
/* terminal.h    (c) Juan Gonzalez Gomez. Agosto   2002       */
/*------------------------------------------------------------*/
/* Estructuras de datos y prototipos del modulo terminal.c    */
/*------------------------------------------------------------*/
/* Licencia GPL.                                              */
/* mail: juan@iearobotics.com                                 */
/**************************************************************/

#ifndef _TERMINAL_H
#define _TERMINAL_H

/*------------------------*/
/* FUNCIONES DE INTERFAZ  */
/*------------------------*/

void terminal_interface_init(interface_t *ifaz);
/**************************************************/
/* Inicializar la parte gr�fica del terminal      */
/* Esta funci�n se debe llamar s�lo una vez       */
/**************************************************/

void terminal_clear();
/***************************************************/
/* Limpiar los buffers de texto de los terminales  */
/***************************************************/

void terminal_set_callback(GIOChannel *sioc);
/************************************************************************/
/* Conectar la funci�n de retrollamada para el canal serie especificado */
/* Si se especifica NULL no se conecta nada.                            */
/************************************************************************/

#endif /* _TERMINAL_H */
