/**************************************************************/
/* terminal.c    (c) Juan Gonzalez Gomez. Agosto   2002       */
/*------------------------------------------------------------*/
/* M�dulo terminal. Gestion de las funciones de retrollamada  */
/* y otros aspectos del terminal.                             */
/*------------------------------------------------------------*/
/* Licencia GPL.                                              */
/* mail: juan@iearobotics.com                                 */
/**************************************************************/

#include <gnome.h>

#include "interface.h"
#include "terminal.h"

/*--------------------------------*/
/* Variables globales del modulo  */
/*--------------------------------*/
static GtkTextBuffer *text_buffer_ascii=NULL;  /* Texto en el buffer ascii  */
static GtkTextBuffer *text_buffer_hexa=NULL;   /* Texto en el buffer hexa   */

static GtkWidget *term_ascii=NULL;  /* Widget para terminal ASCII */
static GtkWidget *term_hexa=NULL;   /* Widget para terminal HEXA  */

/*--------------------------------*/
/* PROTOTIPOS FUNCIONES PRIVADAS  */
/*--------------------------------*/
gboolean cb_serial_data_in (GIOChannel *ioc, 
			    GIOCondition condition, gpointer data);
gboolean cb_terminal_clicked(GtkWidget *widget,
			     GdkEventButton *event,gpointer user_data);
gboolean cb_terminal_key_press(GtkWidget *widget,
			       GdkEventKey *event, gpointer sioc);

/*-------------------------*/
/* Funciones de interfaz   */
/*-------------------------*/

void terminal_interface_init(interface_t *ifaz)
/**************************************************/
/* Inicializar la parte gr�fica del terminal      */
/* Esta funci�n se debe llamar s�lo una vez       */
/**************************************************/
{
  /* Inicializar los buffers de texto de los terminales */
  text_buffer_ascii = gtk_text_view_get_buffer
                       (GTK_TEXT_VIEW (ifaz->term_ascii));
  text_buffer_hexa = gtk_text_view_get_buffer 
                       (GTK_TEXT_VIEW (ifaz->term_hexa));

  /* Obtener los Widget de los terminales */
  term_ascii = ifaz->term_ascii;
  term_hexa  = ifaz->term_hexa;
}

void terminal_clear()
/***************************************************/
/* Limpiar los buffers de texto de los terminales  */
/***************************************************/
{
  gtk_text_buffer_set_text(text_buffer_ascii,"",-1);
  gtk_text_buffer_set_text(text_buffer_hexa,"",-1);
}

void terminal_set_callback(GIOChannel *sioc)
/************************************************************************/
/* Conectar la funci�n de retrollamada para el canal serie especificado */
/* Si se especifica NULL no se conecta nada.                            */
/************************************************************************/
{

  /* Llegada de datos por el puerto serie */
  if (sioc!=NULL)
    g_io_add_watch (sioc, G_IO_IN, cb_serial_data_in, NULL);

  /*------------------ */
  /* TERMINAL ASCII    */
  /*-------------------*/
  /* Click con el rat�n */
  g_signal_connect (G_OBJECT(term_ascii),"button-press-event",
		    G_CALLBACK(cb_terminal_clicked),NULL);
  /* Tecla pulsada */
  g_signal_connect (G_OBJECT(term_ascii),"key_press_event",
		    G_CALLBACK(cb_terminal_key_press),sioc);

  /*-------------------*/
  /* TERMINAL HEXA     */
  /*-------------------*/
  /* Click con el rat�n */
  g_signal_connect (G_OBJECT(term_hexa),"button-press-event",
		    G_CALLBACK(cb_terminal_clicked),NULL);
  /* Tecla pulsada */
  g_signal_connect (G_OBJECT(term_hexa),"key_press_event",
		    G_CALLBACK(cb_terminal_key_press),sioc);


}


/*---------------------------*/
/* FUNCIONES DE RETROLLAMADA */
/*---------------------------*/
gboolean cb_serial_data_in (GIOChannel *ioc, 
			    GIOCondition condition, gpointer data)
/**********************************************************/
/* Funci�n de retrollamada de los datos recibidos por el  */
/* puerto serie.                                          */
/**********************************************************/
{
  gchar buf[10];
  gint num;
  GError *error=NULL;
  GtkTextIter iter_ascii;
  GtkTextIter iter_hexa;
  GString *cad_ascii;
  GString *cad_hexa;

  /* Leer un car�cter e imprimirlo en el terminal  */
  g_io_channel_read_chars (ioc,buf,1,&num,&error);


  /* Asignar las cadenas con el valor a imprimir, seg�n el tipo */
  /* de terminal que estemos empleado: ASCII o HEXA             */
  cad_ascii=g_string_new("");
  cad_hexa=g_string_new("");

  /* Terminal HEXA */
  g_string_printf(cad_hexa,"%hhX ",buf[0]);

  /* Terminal ASCII */
  if(buf[0]>0) g_string_printf (cad_ascii,"%c", buf[0]);
  else {
    g_string_printf(cad_ascii,"*");
  }


  /*---------------------------*/
  /* MODIFICAR EL BUFFER ASCII */
  /*---------------------------*/

  /* Insertar el texto al final del buffer */
  gtk_text_buffer_insert_at_cursor(text_buffer_ascii,cad_ascii->str,-1);

  /* Inicializar la estrucura "iter" */
  gtk_text_buffer_get_iter_at_line(text_buffer_ascii,&iter_ascii,0);
  gtk_text_buffer_get_end_iter(text_buffer_ascii,&iter_ascii);

  /* Hacer un scroll para visualizar siempre el final del buffer */
  gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(term_ascii),
			       &iter_ascii, 0.0,FALSE, 0.0,0.0);

  /* Activar el "foco" para que se visualice lo �ltimo */
  gtk_widget_grab_focus(term_ascii);	 

  /*-----------------------------*/
  /* MODIFICAR EL BUFFER HEXA    */
  /*-----------------------------*/
  /* Insertar el texto al final del buffer */
  gtk_text_buffer_insert_at_cursor(text_buffer_hexa,cad_hexa->str,-1);

  /* Inicializar la estrucura "iter" */
  gtk_text_buffer_get_iter_at_line(text_buffer_hexa,&iter_hexa,0);
  gtk_text_buffer_get_end_iter(text_buffer_hexa,&iter_hexa);

  /* Hacer un scroll para visualizar siempre el final del buffer */
  gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(term_hexa),
			       &iter_hexa, 0.0,FALSE, 0.0,0.0);

  g_string_free(cad_ascii,TRUE);
  g_string_free(cad_hexa,TRUE);
  return TRUE;
}

gboolean cb_terminal_clicked(GtkWidget *widget,
		   GdkEventButton *event,gpointer user_data)
/**************************************************************/
/* Funci�n de retrollamada del bot�n del rat�n dentro del     */
/* terminal. Se fija el foco y se termina. De esta menera el  */
/* usuario no puede cambiar el cursor de sitio.               */
/**************************************************************/
{
  gtk_widget_grab_focus(widget);
  return TRUE;
}

gboolean cb_terminal_key_press(GtkWidget *widget,
			       GdkEventKey *event, gpointer ioc)
/***********************************************************/
/* Funci�n de retrollamada de tecla pulsada en el terminal */
/***********************************************************/
{
  GError *error=NULL;
  gint num;
  GIOChannel *sioc;
  GIOStatus status;

  sioc=(GIOChannel *)ioc;

  //g_print ("%s",event->string);

  /* Enviar la tecla al puerto serie */
  if (sioc!=NULL) {
    status=g_io_channel_write_chars(sioc,event->string,1,&num,&error);
    if (status!=G_IO_STATUS_NORMAL) {
      g_print ("Error: %s\n",error->message);
      g_clear_error(&error);
    }
    status=g_io_channel_flush(sioc,&error);
    if (status!=G_IO_STATUS_NORMAL) {
      g_print ("Error: %s\n",error->message);
      g_clear_error(&error);
    }
  }

  return TRUE;
}

