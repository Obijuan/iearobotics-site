/*********************************************************/
/* g-scterm.c    (c) Juan Gonzalez Gomez. Agosto   2002  */
/*-------------------------------------------------------*/
/* Terminal de comunicaciones basado en la libreria SC   */
/* (Serial Comunication)                                 */
/*-------------------------------------------------------*/
/* Licencia GPL.                                         */
/* mail: juan@iearobotics.com                            */
/*********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"
#include "sercom.h"
#include "terminal.h"
#include "consola.h"

/*------------------------*/
/*    CONSTANTS           */
/*------------------------*/
#define VERSION "0.2-2"

/*--------------------*/
/*    PROTOTIPOS      */
/*--------------------*/

/*---------------*/
/* VARIABLES     */
/*---------------*/
static gchar app_id[] = {"G-SCTERM"};
interface_t interface;
GIOChannel *sioc=NULL;             /* Canal serie                 */

/* TEST */
gchar serial_name[][12] = {        /* Nombre de los disp. serie   */
  {"/dev/ttyS0"},
  {"/dev/ttyS0"},
  {"/dev/ttyS1"},
  {"/dev/ttyS2"},
  {"/dev/ttyS3"},
  {"/dev/ttyS4"},
};
gint serial_num=0;  /* Numero del dispositivo serie */

/**************************/
/* Parametros de usuario  */
/**************************/
static gboolean flag;

/* Par�metros de usuario */
struct poptOption options[]={
  {"flag",'h',POPT_ARG_NONE, &flag, 0, "Activar la opcion Flag", NULL},
  {NULL, '\0', 0, NULL, 0, NULL, NULL}
};

/*----------------------------*/
/* FUNCIONES PARA LA CONSOLA  */
/*----------------------------*/

/*-------------------------*/
/* CALLBACK FUNCTIONS      */
/*-------------------------*/
void main_quit(GtkWidget *window, gpointer data)
{

  /* Cerrar puerto serie */
  if (sioc!=NULL) {
    sc_close(sioc);
    g_print("Cerrando puerto serie\n");
  }

  /* Terminar */
  gtk_main_quit();
}

void main_button(GtkWidget *widget,gpointer data)
/********************************************/
/* Funcion de retrollamada de los botones   */
/********************************************/
{
  gint n;
  gboolean activo;
  GError *error=NULL;

  /* Obtener el numero del boton */
  n=atoi((char *)data);

  switch(n) {
    case 1: /* Limpiar el terminal */
      terminal_clear();
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
			      "Terminal limpiado");
      consola_print("ACCION: Terminal limpiado...\n");
      break;
    case 2:  /* 1200 baudios */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	if (sioc!=NULL) {
	  sc_baudios_set(sioc,B1200,&error);
	  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				  "Velocidad: 1200 baudios");
	  consola_print("ACCION: Velocidad 1200 baudios\n");
	}
      }
      break;
    case 3:  /* 9600 baudios */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	if (sioc!=NULL) {
	  sc_baudios_set(sioc,B9600,&error);
	  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				  "Velocidad: 9600 baudios");
	  consola_print("ACCION: Velocidad 9600 baudios\n");
	}
      }
      break;
    default: 
      g_print ("Boton: %d\n",n);
  }
  
}

void main_toggle_button(GtkWidget *widget, gpointer data)
/************************************************/
/* Funcion de retrollamada de botones "toggle"  */
/************************************************/
{
  int n;
  gboolean activo;
  GError *error=NULL;

  /* Obtener el numero del boton */
  n=atoi((char *)data);

  switch(n) {
    case 1: /* DTR en TOOLBAR */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	if (sioc!=NULL) {
	  sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_ON, &error);
	  gtk_check_menu_item_set_active(
	     GTK_CHECK_MENU_ITEM(interface.acciones_dtr),TRUE);
	  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				  "DTR ON");
	  consola_print("ACCION: DTR ON\n");
	}
      }
      else {
	if (sioc!=NULL) {
	  sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
	  gtk_check_menu_item_set_active(
	     GTK_CHECK_MENU_ITEM(interface.acciones_dtr),FALSE);
	  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				  "DTR OFF");
	  consola_print("ACCION: DTR OFF\n");
	}
      }
      break;
    case 2: /* DTR en men� */
      activo=gtk_check_menu_item_get_active(GTK_CHECK_MENU_ITEM(widget));
      if (activo) { 
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.tool_dtr)
				     ,TRUE);
      }
      else {
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.tool_dtr)
				     ,FALSE);
      }
      break;
    default: 
      g_print ("Toggle: %d\n",n);
      
  }
}


void help_about (GtkMenuItem *menuitem, gpointer user_data)
/*************************************/
/*  Mostrar la ventana de "ABOUT"    */
/*************************************/
{
  GtkWidget *about = NULL;

  about = interface_create_about();
  gtk_widget_show (about);
}

GIOStatus configurar_puerto_serie(GIOChannel **ioc, GError **error)
/*******************************/
/* Configurar el puerto serie  */
/*******************************/
{
  GIOStatus status;

  /*--------------------------------*/
  /* Configuracion del puerto SERIE */
  /*--------------------------------*/
  /* Abrir el puerto serie */
  status=sc_open(serial_name[0],ioc,G_IO_FLAG_NONBLOCK,error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }
  
  g_assert(*ioc!=NULL);

  /* Configurar los baudios */
  status=sc_baudios_set(*ioc,B9600,error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(*ioc, SC_SIGNAL_DTR_OFF, error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  return G_IO_STATUS_NORMAL;
}


/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{
  poptContext contexto;
  GIOStatus status;
  GError *error=NULL;
  GString *cad;

  /* Inicializar GNOME, con los parametros del usuario */
  gnome_init_with_popt_table (app_id, VERSION, argc,argv, 
 		              options, 0, &contexto);
  poptFreeContext (contexto);

  /*-- Comprobar parametros de usuario --*/
  if (flag) g_print ("Opcion Flag....\n");

  /*-- Inicializar GLADE -- */
  glade_gnome_init();

  /*------------------------*/
  /*  Crear el interfaz     */
  /*------------------------*/
  /* Obtener los widgets del fichero XML */
  interface_create_app(&interface);

  /* Conectar las se�ales de retrollamada */
  interface_connect_signals(&interface);

  /*------------------------------*/
  /* CONFIGURACIONES ESPECIFICAS  */
  /*------------------------------*/
  /* Inicializar terminal y consola */
  terminal_interface_init(&interface);
  consola_interface_init(&interface);

  /* Establecer se�ales de retrollamada de la consola */
  consola_set_callback();

  /*------------------------------*/
  /* Inicializar el puerto serie  */
  /*------------------------------*/
  cad=g_string_new("");
  status=configurar_puerto_serie(&sioc,&error);
  if (status!=G_IO_STATUS_NORMAL) { /* Ocurri� alg�n error */
 
    /* Puerto serie NO ABIERTO */
    if (sioc==NULL) {
      g_string_printf(cad,
		      "****ERROR*****-Error al abrir dispositivo %s: %s\n",
		      serial_name[0],error->message);
      consola_print(cad->str);
    }
    else { /* Puerto serie ABIERTO, pero ocurri� alg�n error */
      g_string_printf(cad,"Dispositivo %s ABIERTO\n",serial_name[0]);
      consola_print(cad->str);
      g_string_printf(cad,"****ERROR*****-Error de configuracion: %s\n",
		      error->message);
      consola_print(cad->str);
      g_string_printf(cad,"Dispositivo %s CERRADO\n",serial_name[0]);
      consola_print(cad->str);
      /* Cerrar el dispositivo abierto */
      sc_close(sioc);

      /* No hay canal serie abierto */
      sioc=NULL;
    }

    /* Limpiar el error */
    g_clear_error(&error);

    /* Mostrar la consola */
    gtk_notebook_set_page (GTK_NOTEBOOK(interface.notebook1),2);

  } /* SI NO HAY ERRORES */
  else {
    g_string_printf (cad,"Dispositivo %s ABIERTO\n",serial_name[0]);
    consola_print(cad->str);
  }

  g_string_free(cad,TRUE);

  /* Establecer funciones de retrollamada del terminal */
  terminal_set_callback(sioc);

  /*-------------------------*/
  /* Inicializar el interfaz */
  /*-------------------------*/
  /* Marcar bot�n de velocidad 9600 baudios */
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.tool_9600),TRUE);
  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Inicio");
  
  /*-- Que comience la fiesta!!!! -- */
  gtk_main();

  return 0;
}


