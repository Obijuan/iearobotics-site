/***************************************************/
/* sercom.h  (c) Juan Gonz�lez G�mez. Agosto-2002  */
/*--------------------------------------------------------------*/
/* Prototipos y definiciones para el modulo sercom.c            */
/*--------------------------------------------------------------*/
/* LICENCIA GPL                                                 */
/****************************************************************/

#ifndef _SERCOM_H
#define _SERCOM_H

#include <glib.h>
#include <termios.h>

/*----------------*/
/* DEFINICIONES   */
/*----------------*/
/* ERRORES */
#define SC_ERROR_OPEN        1  /* Dominio */
#define SC_ERROR_OPEN_SETUP1 1  /* Error al configurar puerto serie */
#define SC_ERROR_OPEN_SETUP2 2  /* Error al configurar puerto serie */
#define SC_ERROR_OPEN_SETUP3 3  /* Error al configurar puerto serie */

#define SC_ERROR_BAUDIOS        2
#define SC_ERROR_BAUDIOS_SETUP1 1 /* Error al leer atributos         */
#define SC_ERROR_BAUDIOS_SET    2 /* Error al establecer los baudios */
#define SC_ERROR_BAUDIOS_SETUP2 3 /* Error al escribir atributos     */

#define SC_ERROR_SIGNAL     3
#define SC_ERROR_SIGNAL_GET 1
#define SC_ERROR_SIGNAL_SET 2

/* PARAMETROS */
#define SC_SIGNAL_DTR_ON  1   /* Establecer DTR a ON  */
#define SC_SIGNAL_DTR_OFF 2   /* Establecer DTR a OFF */

/*--------------------------------------*/
/*  DEFINICION PROTOTIPOS DEL INTERFAZ  */
/*--------------------------------------*/

GIOStatus sc_open(const gchar *fich, GIOChannel **ioc,
		  GIOFlags flags, GError **error);
/********************************************************************/
/* Abrir el puerto serie especificado por un fichero. Dependiendo   */
/* de la plataforma el fichero ser� uno u otro                      */
/*                                                                  */
/* ENTRADAS:                                                        */
/*     -fich: Fichero con el dispositivo serie de entrada           */
/* SALIDAS:                                                         */
/*     -ioc: Canal asociado al puerto serie                         */
/*     -error: Error producido                                      */
/* DEVUELVE:                                                        */
/*     -Estado de la operaci�n realizada                            */
/********************************************************************/ 

void sc_close(GIOChannel *ioc);
/**************************************************/
/* Cerrar el puerto serie. Se ignoran los errores */
/* ENTRADAS: canal a cerrar                       */
/**************************************************/

GIOStatus sc_baudios_set(GIOChannel *ioc, gint vel, GError **error);
/*****************************************************************/
/* Configurar la velocidad de transmision.                       */
/*                                                               */
/* ENTRADAS:                                                     */
/*   -ioc : Canal del puerto serie                               */
/*   -vel : Velocidad. Las etiquetas v�lidas son las definidas   */
/*          en termios.h:                                        */
/*             B0,B50,B75,B110,B134,B150,B200,B300,B600, B1200   */
/*             B1800,B2400,,B4800,B9600,B19200,B38400,B57600,    */
/*             B115200, B230400                                  */
/* SALIDAS                                                       */
/*   -error: Error ocurrido                                      */
/* DEVUELVE:                                                     */
/*   -Estado de la operaci�n                                     */
/*****************************************************************/

GIOStatus sc_signal_dtr_get(GIOChannel *ioc, gint *estado, GError **error);
/***********************************************************/
/*  Leer el estado del modem                               */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -ioc: Canal.                                         */
/*  SALIDAS:                                               */
/*    -estado: EStado del DTR:                             */  
/*        SC_SIGNAL_DTR_ON                                 */
/*        SC_SIGNAL_DTR_OFF                                */
/*    -error                                               */
/*  DEVUELVE:                                              */
/*    -estado de la operaci�n                              */
/***********************************************************/

GIOStatus sc_signal_dtr_set(GIOChannel *ioc, gint estado, GError **error);
/***********************************************************/
/*  Establecer el estado de la se�al DTR.                  */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -ioc: Canal.                                         */
/*    -estado: EStado del DTR:                             */  
/*        SC_SIGNAL_DTR_ON                                 */
/*        SC_SIGNAL_DTR_OFF                                */
/*  SALIDAS:                                               */
/*    -error                                               */
/*  DEVUELVE:                                              */
/*    -estaddo de la operaci�n                             */
/***********************************************************/

#endif  /* _SERCOM_H */
