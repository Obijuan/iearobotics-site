/***********************************************************/
/* interface.h   (c) Juan Gonz�lez G�mez. Agosto 2002      */
/*---------------------------------------------------------*/
/* Licencia GPL                                            */
/***********************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

#include <gnome.h>

/*-----------------------*/
/* ESTRUCTURAS DE DATOS  */
/*-----------------------*/

/* ---- Estructura de datos del interfaz ---- */
typedef struct interface_s {
  GtkWidget *main_window;   /* Ventana principal                */
  GtkWidget *app_bar;       /* Barra de aplicaciones            */
  GtkWidget *term_ascii;    /* Terminal de visualizacion Ascii  */
  GtkWidget *term_hexa;     /* Terminal de visualizacion Hexa   */
  GtkWidget *consola;       /* Consola de mensajes              */

  /*-- Barra de herramientas -- */
  GtkWidget *tool_limpiar;  /* Limpiar terminal      */
  GtkWidget *tool_dtr;      /* Cambiar DTR           */
  GtkWidget *tool_1200;     /* Bot�n de 1200 baudios */
  GtkWidget *tool_9600;     /* Bot�n de 9600 baudios */

  /*-- Menu File ---*/
  GtkWidget *file_quit;     /* Salir  */

  /*-- Menu acciones --*/
  GtkWidget *acciones_limpiar;  /* Limpiar el terminal           */
  GtkWidget *acciones_dtr;      /* Acceso al DTR desde el menu   */

  /*-- Menu Help --*/
  GtkWidget *help_about;        /* About  */

  /*-- Notebook --*/
  GtkWidget *notebook1;   /* Notebook */

} interface_t;

/*--------------*/
/* PROTOTIPOS   */
/*--------------*/
void interface_create_app(interface_t *ifaz);
/***********************************************/
/*  Crear el interfaz de la ventana principal  */
/*  S�lo se debe llamar una vez a esta funcion */
/***********************************************/

void interface_connect_signals(interface_t *ifaz);
/*******************************************/
/* Conectar las se�ales de retrollamada    */
/*******************************************/

GtkWidget *interface_create_about();
/********************************/
/* Crear la ventana de ABOUT    */
/********************************/

#endif  /* _INTEFACE_H */
