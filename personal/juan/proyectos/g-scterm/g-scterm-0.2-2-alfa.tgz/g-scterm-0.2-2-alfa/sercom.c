/****************************************************************/
/* sercom.c  (c) Juan Gonz�lez G�mez. Agosto-2002               */
/*--------------------------------------------------------------*/
/* Modulo de comunicaciones serie, multiplataforma y orientado  */
/* a comunicaciones con microcontroladores                      */
/****************************************************************/

#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>
#include <glib.h>

#include "sercom.h"

/*-----------------------*/
/* Definiciones locales  */
/*-----------------------*/
#define DEFAULT_BAUD B9600  /* Velocidad por defecto, en la apertura */

/*--------------------------------------------------*/
/* Prototipos de las funciones privadas del modulo  */
/*--------------------------------------------------*/
GIOStatus setup_serial(GIOChannel *ioc, GError **error);


/*--------------------------------------------------*/
/*      IMPLEMENTACION FUNCIONES PRIVADAS           */
/*--------------------------------------------------*/

GIOStatus setup_serial(GIOChannel *ioc, GError **error)
/************************************************************************/
/* Configurar la estructura termios para trabajar con el puerto serie.  */
/* Configurar para 8 bits de datos y sin paridad.                       */
/*                                                                      */
/* ENTRADAS:                                                            */
/*   -ioc: Canal del puerto serie.                                      */
/* SALIDAS:                                                             */
/*   -error: Error producido                                            */
/* DEVUELVE                                                             */
/*   -Estado de la operaci�n:                                           */ 
/*          G_IO_STATUS_ERROR: Error                                    */
/*          G_IO_STATUS_NORMAL: OK                                      */
/************************************************************************/
{
  struct termios newtermios;
  struct termios oldtermios;
  gint fd;
 
  g_assert(ioc!=NULL);

  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);

  /* Leer atributos del puerto serie */
  if (tcgetattr(fd,&oldtermios)==-1) {
      g_set_error (error,
		   SC_ERROR_OPEN,
		   SC_ERROR_OPEN_SETUP1,
		   "Error de lectura de parametros");
    return G_IO_STATUS_ERROR;
  }
  
  /* Modificar los atributos */
  newtermios.c_cflag= CBAUD | CS8 | CLOCAL | CREAD;
  newtermios.c_iflag=IGNPAR;
  newtermios.c_oflag=0;
  newtermios.c_lflag=0;
  newtermios.c_cc[VMIN]=1;
  newtermios.c_cc[VTIME]=0;

  /* Establecer velocidad por defecto */
  cfsetospeed(&newtermios,DEFAULT_BAUD);
  cfsetispeed(&newtermios,DEFAULT_BAUD);
  
  /* Vaciar los buffers de entrada y salida */
  if (tcflush(fd,TCIFLUSH)==-1) {
    g_set_error (error,
		 SC_ERROR_OPEN,
		 SC_ERROR_OPEN_SETUP2,
		 "Error limpiando buffer");
    return G_IO_STATUS_ERROR;
  }

  /* Vaciar buffer de salida */
  if (tcflush(fd,TCOFLUSH)==-1) {
    g_set_error (error, 
		 SC_ERROR_OPEN,
		 SC_ERROR_OPEN_SETUP2,
		 "Error limpiando buffer");
    return G_IO_STATUS_ERROR;
  }

  /* Escribir los nuevos atributos */
  if (tcsetattr(fd,TCSANOW,&newtermios)==-1) {
    g_set_error (error,
		 SC_ERROR_OPEN,
		 SC_ERROR_OPEN_SETUP3,
		 "Error de escritura de par�metros");
    return G_IO_STATUS_ERROR;
  }  
  return 1;
}

/*----------------------------------------------*/
/*    IMPLEMENTACI�N FUNCIONES DE INTERFAZ      */
/*----------------------------------------------*/

GIOStatus sc_baudios_set(GIOChannel *ioc, gint vel, GError **error)
/*****************************************************************/
/* Configurar la velocidad de transmision.                       */
/*                                                               */
/* ENTRADAS:                                                     */
/*   -ioc : Canal del puerto serie                               */
/*   -vel : Velocidad. Las etiquetas v�lidas son las definidas   */
/*          en termios.h:                                        */
/*             B0,B50,B75,B110,B134,B150,B200,B300,B600, B1200   */
/*             B1800,B2400,B4800,B9600,B19200,B38400,B57600,     */
/*             B115200, B230400                                  */
/* SALIDAS                                                       */
/*   -error: Error ocurrido                                      */
/* DEVUELVE:                                                     */
/*   -Estado de la operaci�n                                     */
/*****************************************************************/
{
  struct termios mytermios;
  gint fd;
 
  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);

  /* Leer atributos del puerto serie */
  if (tcgetattr(fd,&mytermios)==-1) {
      g_set_error (error,
		   SC_ERROR_BAUDIOS,
		   SC_ERROR_BAUDIOS_SETUP1,
		   "Error de lectura de parametros");
    return G_IO_STATUS_ERROR;
  }

  /* Establecer la velocidad */  
  if (cfsetospeed(&mytermios,vel)==-1) {
    g_set_error(error,
		SC_ERROR_BAUDIOS,
		SC_ERROR_BAUDIOS_SET,
		"Error al establecer velocidad");
    return G_IO_STATUS_ERROR;
  }
  if (cfsetispeed(&mytermios,vel)==-1) {
    g_set_error(error,
		SC_ERROR_BAUDIOS,
		SC_ERROR_BAUDIOS_SET,
		"Error al establecer velocidad");
    return G_IO_STATUS_ERROR;
  }

  /* Guardar la configuraci�n */
  if (tcsetattr(fd,TCSANOW,&mytermios)==-1) {
    g_set_error(error,
		SC_ERROR_BAUDIOS,
		SC_ERROR_BAUDIOS_SETUP2,
		"Error al escribir par�metros");
    return G_IO_STATUS_ERROR;
  }

  /* Velocidad modificada sin problemas */
  return G_IO_STATUS_NORMAL;
}


GIOStatus sc_open(const gchar *fich, GIOChannel **ioc,
		  GIOFlags flags, GError **error)
/********************************************************************/
/* Abrir el puerto serie especificado por un fichero. Dependiendo   */
/* de la plataforma el fichero ser� uno u otro                      */
/*                                                                  */
/* ENTRADAS:                                                        */
/*     -fich: Fichero con el dispositivo serie de entrada           */
/*     -flag: Establecer alguna condici�n, como por ejemplo no      */
/*            BLOQUEANTE (G_IO_FLAG_NONBLOCK)                       */
/* SALIDAS:                                                         */
/*     -ioc: Canal asociado al puerto serie                         */
/*     -error: Error producido                                      */
/* DEVUELVE:                                                        */
/*     -Estado de la operaci�n realizada                            */
/********************************************************************/
{
  GIOFlags flg;
  GIOStatus status;

  /* Abrir el puerto serie para lectura/escritura */
  *ioc = g_io_channel_new_file(fich,"r+",error);
  if (*error != NULL) {
    *ioc=NULL;
    return G_IO_STATUS_ERROR;
  } 

  g_assert((*error)==NULL);
  g_assert((*ioc)!=NULL);

  /* Establecer los flags definidos por el usuario */
  flg=g_io_channel_get_flags(*ioc);
  flg|=flags;
  status=g_io_channel_set_flags(*ioc,flags,error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  g_assert((*error)==NULL);

  /* Establecer codificaci�n binaria (NULA) */
  status=g_io_channel_set_encoding(*ioc,NULL,error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  g_assert((*error)==NULL);

  /* Configurar el puerto serie */
  setup_serial(*ioc,error);
  if (*error!=NULL) {
    return G_IO_STATUS_ERROR;
  }

  g_print ("OK\n");

  /* Puerto serie abierto y configurado correctamente */
  return G_IO_STATUS_NORMAL;
} 

GIOStatus sc_signal_dtr_get(GIOChannel *ioc, gint *estado, GError **error)
/***********************************************************/
/*  Leer el estado del DTR                                 */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -ioc: Canal.                                         */
/*  SALIDAS:                                               */
/*    -estado: EStado del DTR:                             */  
/*        SC_SIGNAL_DTR_ON                                 */
/*        SC_SIGNAL_DTR_OFF                                */
/*    -error                                               */
/*  DEVUELVE:                                              */
/*    -estado de la operaci�n                              */
/***********************************************************/
{
  gint fd;
  gint arg;
 
  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);

  if (ioctl(fd,TIOCMGET,&arg)==-1) {
    g_set_error (error, 
		 SC_ERROR_SIGNAL,
		 SC_ERROR_SIGNAL_GET,
		 "Error al leer las senales de control");
    return G_IO_STATUS_ERROR;
  }

  if ((arg&TIOCM_DTR)==TIOCM_DTR) *estado=SC_SIGNAL_DTR_ON;
  else *estado=SC_SIGNAL_DTR_OFF;

  /* Operaci�n realizada normalmente */
  return G_IO_STATUS_NORMAL;
}


GIOStatus sc_signal_dtr_set(GIOChannel *ioc, gint estado, GError **error)
/***********************************************************/
/*  Establecer el estado de la se�al DTR.                  */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -ioc: Canal.                                         */
/*    -estado: EStado del DTR:                             */  
/*        SC_SIGNAL_DTR_ON                                 */
/*        SC_SIGNAL_DTR_OFF                                */
/*  SALIDAS:                                               */
/*    -error                                               */
/*  DEVUELVE:                                              */
/*    -estaddo de la operaci�n                             */
/***********************************************************/
{
  gint fd;
  gint arg;
  gint cmd;

  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);

  /* Se�al a modificar */
  arg = TIOCM_DTR;

  if (estado==SC_SIGNAL_DTR_ON) {
    cmd=TIOCMBIS;
  }
  else cmd=TIOCMBIC;

  /* Escribir estado actual */
  if (ioctl(fd,cmd,&arg)==-1) {
    g_set_error (error, 
		 SC_ERROR_SIGNAL,
		 SC_ERROR_SIGNAL_SET,
		 "Error al escribir las senales de control");
    return G_IO_STATUS_ERROR;
  }
  
  return G_IO_STATUS_NORMAL;
}

void sc_close(GIOChannel *ioc)
/**************************************************/
/* Cerrar el puerto serie. Se ignoran los errores */
/* ENTRADAS: canal a cerrar                       */
/**************************************************/

{
  GError *error=NULL;
  GIOStatus status;

  g_assert(ioc!=NULL);

  status=g_io_channel_shutdown(ioc,TRUE,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print("Error en close\n");
    g_clear_error(&error);
  }
  g_print ("OK, close\n");
}

