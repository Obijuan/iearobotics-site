/**************************************************************/
/* consola.h     (c) Juan Gonzalez Gomez. Agosto   2002       */
/*------------------------------------------------------------*/
/* Estructuras de datos y prototipos del modulo consola.c     */
/*------------------------------------------------------------*/
/* Licencia GPL.                                              */
/* mail: juan@iearobotics.com                                 */
/**************************************************************/

#ifndef _CONSOLA_H
#define _CONSOLA_H

#include <gnome.h>

/*------------------------*/
/* FUNCIONES DE INTERFAZ  */
/*------------------------*/
void consola_interface_init(interface_t *ifaz);
/**************************************************/
/* Inicializar la parte gr�fica de la consola     */
/* Esta funci�n se debe llamar s�lo una vez       */
/**************************************************/

void consola_clear();
/**************************/
/* Limpiar la consola     */
/**************************/

void consola_set_callback();
/********************************************************************/
/* Conectar las funciones de retrollamada asociadas a la consola    */
/********************************************************************/

void consola_print(gchar *cad);
/**************************************/
/* Imprimir un mensaje en la consola  */
/**************************************/

#endif /* _CONSOLA_H */
