/**************************************************************/
/* consola.c    (c) Juan Gonzalez Gomez. Agosto   2002        */
/*------------------------------------------------------------*/
/* M�dulo consola. Gestion de las funciones de retrollamada   */
/* y otros aspectos de la consola.                            */
/*------------------------------------------------------------*/
/* Licencia GPL.                                              */
/* mail: juan@iearobotics.com                                 */
/**************************************************************/

#include <gnome.h>

#include "interface.h"
#include "consola.h"

/*--------------------------------*/
/* Variables globales del modulo  */
/*--------------------------------*/
static GtkTextBuffer *text_consola=NULL;  /* Texto de la consola    */
static GtkWidget *consola=NULL;           /* Widget para la consola */

/*--------------------------------*/
/* PROTOTIPOS FUNCIONES PRIVADAS  */
/*--------------------------------*/
gboolean cb_consola_clicked(GtkWidget *widget,
			     GdkEventButton *event,gpointer user_data);

/*-------------------------*/
/* Funciones de interfaz   */
/*-------------------------*/
void consola_interface_init(interface_t *ifaz)
/**************************************************/
/* Inicializar la parte gr�fica de la consola     */
/* Esta funci�n se debe llamar s�lo una vez       */
/**************************************************/
{
  /* Inicializar el buffers de texto de la consola */
  text_consola  = gtk_text_view_get_buffer
                       (GTK_TEXT_VIEW (ifaz->consola));
  
  /* Obtener el widget de la consola */
  consola = ifaz->consola;
}

void consola_clear()
/**************************/
/* Limpiar la consola     */
/**************************/
{
  gtk_text_buffer_set_text(text_consola,"",-1);
}

void consola_set_callback()
/********************************************************************/
/* Conectar las funciones de retrollamada asociadas a la consola    */
/********************************************************************/
{

  /* Click con el rat�n */
  g_signal_connect (G_OBJECT(consola),"button-press-event",
		    G_CALLBACK(cb_consola_clicked),NULL);
}

void consola_print(gchar *cad)
/**************************************/
/* Imprimir un mensaje en la consola  */
/**************************************/
{
  GtkTextIter iter;

  /* Insertar el texto al final del buffer */
  gtk_text_buffer_insert_at_cursor(text_consola,cad,-1);

  /* Inicializar la estrucura "iter" */
  gtk_text_buffer_get_iter_at_line(text_consola,&iter,0);
  gtk_text_buffer_get_end_iter(text_consola,&iter);

  /* Hacer un scroll para visualizar siempre el final del buffer */
  gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(consola),
			       &iter, 0.0,FALSE, 0.0,0.0); 
}



/*---------------------------*/
/* FUNCIONES DE RETROLLAMADA */
/*---------------------------*/
gboolean cb_consola_clicked(GtkWidget *widget,
			    GdkEventButton *event,gpointer user_data)
/**************************************************************/
/* Funci�n de retrollamada del bot�n del rat�n dentro de la   */
/* consola. Se fija el foco y se termina. De esta menera el   */
/* usuario no puede cambiar el cursor de sitio.               */
/**************************************************************/
{
  gtk_widget_grab_focus(widget);
  return TRUE;
}
