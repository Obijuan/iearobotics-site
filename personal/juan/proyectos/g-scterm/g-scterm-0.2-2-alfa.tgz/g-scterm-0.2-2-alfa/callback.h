/************************************************************/
/* callback.h    (c) Juan Gonzalez Gomez. Agosto 2002       */
/*----------------------------------------------------------*/
/* This project is under GPL license                        */
/************************************************************/

#ifndef _CALLBACK_H
#define _CALLBACK_H

#include <gnome.h>

void main_quit(GtkWidget *window, gpointer data);
void main_button(GtkWidget *widget,gpointer data);
void main_toggle_button(GtkWidget *widget, gpointer data);
void help_about (GtkMenuItem *menuitem, gpointer user_data);
gboolean terminal_clicked(GtkWidget *widget,
		   GdkEventButton *event,gpointer user_data);

#endif /* _CALLBALLK_H */
