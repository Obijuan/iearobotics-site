/*********************************************************/
/* g-scterm.c    (c) Juan Gonzalez Gomez. Agosto   2002  */
/*-------------------------------------------------------*/
/* Terminal de comunicaciones basado en la libreria SC   */
/* (Serial Comunication)                                 */
/*-------------------------------------------------------*/
/* Licencia GPL.                                         */
/* mail: juan@iearobotics.com                            */
/*********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"
#include "sercom.h"

/*------------------------*/
/*    CONSTANTS           */
/*------------------------*/
#define VERSION "0.1"

/*--------------------*/
/*    PROTOTIPOS      */
/*--------------------*/

/*---------------*/
/* VARIABLES     */
/*---------------*/
static gchar app_id[] = {"G-SCTERM"};
interface_t interface;
GIOChannel *sioc;            /* Canal serie                */
GtkTextBuffer *text_buffer;  /* Texto en el buffer de entrada serie  */

/**************************/
/* Parametros de usuario  */
/**************************/
static gboolean flag;

/* Par�metros de usuario */
struct poptOption options[]={
  {"flag",'h',POPT_ARG_NONE, &flag, 0, "Activar la opcion Flag", NULL},
  {NULL, '\0', 0, NULL, 0, NULL, NULL}
};

/*-------------------------*/
/* CALLBACK FUNCTIONS      */
/*-------------------------*/
void main_quit(GtkWidget *window, gpointer data)
{

  /* Cerrar puerto serie */
  sc_close(sioc);

  /* Terminar */
  gtk_main_quit();
}

void main_button(GtkWidget *widget,gpointer data)
/********************************************/
/* Funcion de retrollamada de los botones   */
/********************************************/
{
  gint n;
  gboolean activo;
  GError *error;

  /* Obtener el numero del boton */
  n=atoi((char *)data);

  switch(n) {
    case 1: /* Limpiar el terminal */
      gtk_text_buffer_set_text(text_buffer,"",-1);
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
			      "Terminal limpiado");
      break;
    case 2:  /* 1200 baudios */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	sc_baudios_set(sioc,B1200,&error);
	gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				"Velocidad: 1200 baudios");
      }
      break;
    case 3:  /* 9600 baudios */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	sc_baudios_set(sioc,B9600,&error);
	gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				"Velocidad: 9600 baudios");
      }
      break;
    default: 
      g_print ("Boton: %d\n",n);
  }
  
}

void main_toggle_button(GtkWidget *widget, gpointer data)
/************************************************/
/* Funcion de retrollamada de botones "toggle"  */
/************************************************/
{
  int n;
  gboolean activo;
  GError *error=NULL;

  /* Obtener el numero del boton */
  n=atoi((char *)data);

  switch(n) {
    case 1: /* DTR en TOOLBAR */
      activo=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(widget));
      if (activo) {
	sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_ON, &error);
	gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(interface.menu_dtr)
				       ,TRUE);
	gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				"DTR ON");
      }
      else { 
	sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
	gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(interface.menu_dtr)
				       ,FALSE);
	gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
				"DTR OFF");
      }
      break;
    case 2: /* DTR en men� */
      activo=gtk_check_menu_item_get_active(GTK_CHECK_MENU_ITEM(widget));
      if (activo) { 
        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.button_dtr)
				     ,TRUE);
      }
      else {
	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.button_dtr)
				     ,FALSE);
      }
      break;
    default: 
      g_print ("Toggle: %d\n",n);
      
  }
}


void help_about (GtkMenuItem *menuitem, gpointer user_data)
/*************************************/
/*  Mostrar la ventana de "ABOUT"    */
/*************************************/
{
  GtkWidget *about = NULL;

  about = create_about();
  gtk_widget_show (about);
}

GIOStatus configurar_puerto_serie(GIOChannel **ioc, GError **error)
/*******************************/
/* Configurar el puerto serie  */
/*******************************/
{
  GIOStatus status;

  /*--------------------------------*/
  /* Configuracion del puerto SERIE */
  /*--------------------------------*/

  /* Abrir el puerto serie */
  status=sc_open("/dev/ttyS0",ioc,G_IO_FLAG_NONBLOCK,error);
  if (status!=G_IO_STATUS_NORMAL) {
    *ioc=NULL;
    return status;
  }

  /* Configurar los baudios */
  status=sc_baudios_set(*ioc,B9600,error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(*ioc, SC_SIGNAL_DTR_OFF, error);
  if (status!=G_IO_STATUS_NORMAL) {
    return status;
  }

  return G_IO_STATUS_NORMAL;
}

gboolean serial_data_in (GIOChannel *ioc, 
			 GIOCondition condition, gpointer data)
/**********************************************************/
/* Funci�n de retrollamada de los datos recibidos por el  */
/* puerto serie.                                          */
/**********************************************************/
{
  gchar buf[2];
  gint num;
  GError *error=NULL;
  GtkTextIter iter;

  /* Leer un car�cter e imprimirlo en el terminal  */
  g_io_channel_read_chars (ioc,buf,1,&num,&error); 
  if(buf[0]>0) g_print ("%c", buf[0]);
  else {
    g_print("[%hhu]",buf[0]);
    buf[0]='*';
  }
  buf[1]=0;

  /* Insertar el caracter recibido, al final del buffer */
  gtk_text_buffer_insert_at_cursor(text_buffer,buf,-1);

  /* Inicializar la estrucura "iter" */
  gtk_text_buffer_get_iter_at_line(text_buffer,&iter,0);
  gtk_text_buffer_get_end_iter(text_buffer,&iter);

  /* Hacer un scroll para visualizar siempre el final del buffer */
   gtk_text_view_scroll_to_iter(GTK_TEXT_VIEW(interface.terminal),
			       &iter, 0.0,FALSE, 0.0,0.0);
  		 
  return TRUE;
}

gboolean terminal_clicked(GtkWidget *widget,
		   GdkEventButton *event,gpointer user_data)
/**************************************************************/
/* Funci�n de retrollamada del bot�n del rat�n dentro del     */
/* terminal. Se fija el foco y se termina. De esta menera el  */
/* cursor nunca cambia de sitio.                              */
/**************************************************************/
{
  gtk_widget_grab_focus(widget);
  return TRUE;
}

gboolean terminal_key_press(GtkWidget *widget,
		       GdkEventKey *event, gpointer user_data)
/***********************************************************/
/* Funci�n de retrollamada de tecla pulsada en el terminal */
/***********************************************************/
{
  GError *error=NULL;
  gint num;

  //g_print ("%s",event->string);

  /* Enviar la tecla al puerto serie */
  g_io_channel_write_chars(sioc,event->string,1,&num,&error);
  g_io_channel_flush(sioc,&error);

  return TRUE;
}



/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{
  poptContext contexto;
  GIOStatus status;
  GError *error=NULL;

  /* Inicializar GNOME, con los parametros del usuario */
  gnome_init_with_popt_table (app_id, VERSION, argc,argv, 
                              options, 0, &contexto);
  poptFreeContext (contexto);

  /*-- Comprobar parametros de usuario --*/
  if (flag) g_print ("Opcion Flag....\n");

  /*-- Inicializar GLADE -- */
  glade_gnome_init ();

  /*------------------------*/
  /*  Crear el interfaz     */
  /*------------------------*/
  create_app(&interface);
  text_buffer = gtk_text_view_get_buffer (GTK_TEXT_VIEW (interface.terminal));
  g_signal_connect (G_OBJECT(interface.terminal),"key_press_event",
		    G_CALLBACK(terminal_key_press),NULL);
  g_signal_connect (G_OBJECT(interface.terminal),"button-press-event",
		    G_CALLBACK(terminal_clicked),NULL);

  /*------------------------------*/
  /* Inicializar el puerto serie  */
  /*------------------------------*/
  status=configurar_puerto_serie(&sioc,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Puerto serie: %s\n",error->message);
    g_clear_error(&error);
  }

  g_io_add_watch (sioc, G_IO_IN, serial_data_in, NULL);

  /*-------------------------*/
  /* Inicializar el interfaz */
  /*-------------------------*/
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.button_9600),
			       TRUE);
 
  /*-- Que comience la fiesta!!!! -- */
  gtk_main();

  return 0;
}


