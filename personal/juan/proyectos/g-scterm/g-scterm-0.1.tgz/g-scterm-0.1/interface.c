/*********************************************************/
/* interface.c    (c) Juan Gonz�lez G�mez. Agosto 2002   */
/*-------------------------------------------------------*/
/* Crear el interfaz del modulo g-scterm                 */
/* Licencia GPL                                          */
/*-------------------------------------------------------*/
/* mail: juan@iearobotics.com                            */
/*********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"

void create_app(interface_t *ifaz)
/***********************************/
/*  Crear la ventana principal     */
/***********************************/
{
  GladeXML *xml;
  GtkWidget *app;
  GtkWidget *menu;
  GtkWidget *button;

  /*----------------------*/
  /* Obtener los widgets  */
  /*----------------------*/
  /* Leer el interfaz en XML */
  xml = glade_xml_new ("./g-scterm.glade", "app1", "Dominio");

  /* Obtener el widget de la aplicacion */
  app = glade_xml_get_widget (xml, "app1");
  ifaz->main_window=GNOME_APP(app);

  /*-- STATUS BAR -- */
  ifaz->app_bar=glade_xml_get_widget(xml,"appbar1");

  /*-- Obtener el widget terminal --*/
  ifaz->terminal=glade_xml_get_widget(xml,"terminal");


  /*------------------------------------------*/
  /* Conexion de las se�ales de retrollamada  */
  /*------------------------------------------*/
  g_signal_connect (G_OBJECT (app), "destroy",
		    G_CALLBACK (main_quit), NULL);

  /*---------*/
  /* TOOLBAR */
  /*---------*/
  /*-- Boton para limpiar el terminal --*/
  button = glade_xml_get_widget (xml, "clear_terminal");
  g_signal_connect (G_OBJECT(button),"clicked",G_CALLBACK(main_button),"1");
    
  menu = glade_xml_get_widget(xml,"accion_limpiar_terminal");
  g_signal_connect (G_OBJECT(menu),"activate",G_CALLBACK(main_button),"1");
  
  /*-- Boton para el DTR --*/
  button=glade_xml_get_widget(xml, "dtr");
  g_signal_connect (G_OBJECT(button),"toggled",
		    G_CALLBACK(main_toggle_button),"1");
  ifaz->button_dtr=button;

  menu = glade_xml_get_widget(xml,"acciones_dtr");
  g_signal_connect (G_OBJECT(menu),"toggled",
		    G_CALLBACK(main_toggle_button),"2");
  ifaz->menu_dtr=menu;

  /*-- Boton de 1200 baudios */
  button=glade_xml_get_widget(xml, "baudios_1200");
  g_signal_connect (G_OBJECT(button),"clicked",
		    G_CALLBACK(main_button),"2");
  ifaz->button_1200=button;

  /*-- Boton de 9600 baudios-- */
  button=glade_xml_get_widget(xml, "baudios_9600");
  g_signal_connect (G_OBJECT(button),"clicked",
		    G_CALLBACK(main_button),"3");
  ifaz->button_9600=button;

  /*********************************/
  /* Conectar las se�ales del menu */
  /*********************************/

  /*-------------*/
  /* File Menu   */
  /*-------------*/
  menu = glade_xml_get_widget (xml, "file_quit");
  g_signal_connect_object (menu,"activate",G_CALLBACK(main_quit),menu,0);
  

  /*--------------*/
  /* Help Menu    */
  /*--------------*/
  menu = glade_xml_get_widget (xml,"help_about");
  g_signal_connect_object (menu,"activate",G_CALLBACK(help_about),menu,0);
  

  /*------------*/
  /* Terminar   */
  /*------------*/

  /* Liberar el objeto xml */
  g_object_unref (xml);

  /* Mostrar todos los widgets */
  gtk_widget_show_all(app);
}

GtkWidget *create_about()
/*********************************/
/* Crear la ventana de about     */
/*********************************/
{
  GladeXML *xml;
  GtkWidget *about;

  xml = glade_xml_new ("g-scterm.glade", "about1","dominio");
  about = glade_xml_get_widget (xml, "about1");

  g_object_unref(xml);

  return about;
}

