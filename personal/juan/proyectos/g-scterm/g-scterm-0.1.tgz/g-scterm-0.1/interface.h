/***********************************************************/
/* interface.h   (c) Juan Gonz�lez G�mez. Agosto 2002      */
/*---------------------------------------------------------*/
/* Licencia GPL                                            */
/***********************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

/*-----------------------*/
/* ESTRUCTURAS DE DATOS  */
/*-----------------------*/

/* ---- Estructura de datos del interfaz ---- */
typedef struct interface_s {
  GnomeApp    *main_window;   /* Ventana principal             */
  GtkWidget   *app_bar;       /* Barra de aplicaciones         */
  GtkWidget   *terminal;      /* Terminal de visualizacion     */
  GtkWidget   *button_1200;   /* Bot�n de 1200 Baudios         */
  GtkWidget *button_9600;     /* Bot�n de 9600 Baudios         */
  GtkWidget *button_dtr;      /* Bot�n de DTR                  */
  GtkWidget *menu_dtr;        /* Acceso al DTR desde el menu   */
} interface_t;

/*--------------*/
/* PROTOTIPOS   */
/*--------------*/
void create_app(interface_t *ifaz);
GtkWidget *create_about();

#endif  /* _INTEFACE_H */
