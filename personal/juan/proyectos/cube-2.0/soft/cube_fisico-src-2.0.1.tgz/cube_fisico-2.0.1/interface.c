/****************************************************************************/
/* interface.c   Juan Gonzalez Gomez.  Octubre 2000                        */
/*--------------------------------------------------------------------------*/
/* Dibujo del interfaz.                                                     */
/****************************************************************************/

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "gtkutils.h"
#include "interface.h"
#include "lcd.h"
#include "retrollamada.h"

static GtkWidget *crear_item_menu(main_state_t *estado, GtkWidget *menu, char *nombre,char *accel, 
                                  char *tip, GtkSignalFunc func,gpointer data)
/****************************************************************************/
/* Crear un elemento y colocarlo en el menu                                 */
/*                                                                          */
/*  ENTRADA:                                                                */
/*     - Estado global                                                      */
/*     - Menu donde situar la nueva opcion                                  */
/*     - Nombre de la opcion de menu                                        */
/*     - Tecla de aceleracion                                               */
/*     - Sugerencia                                                         */
/*     - Funcion de retrollamada, llamada cuando el usuario elije la opcion */
/*     - Datos a pasar a la funcion de retrollamada                         */
/*                                                                          */
/*  DEVUELVE:                                                               */
/*     - Widget de item de menu                                             */
/****************************************************************************/       
{
  GtkWidget *menuitem;
  
  /* Si el menu tiene nombre ... */
  if (nombre && strlen(nombre)) {
    menuitem = gtk_menu_item_new_with_label(nombre);
    gtk_signal_connect(GTK_OBJECT(menuitem), "activate", 
                       GTK_SIGNAL_FUNC(func), data);
  }
  else {
    /* -- Crear un separador -- */
    menuitem = gtk_menu_item_new();
  }
  

  
  /* -- Añadir elemento de menu y mostrarlo -- */
  gtk_menu_append (GTK_MENU(menu), menuitem);
  gtk_widget_show (menuitem);
  
  /* Cadena de aceleracion */
  
  if (estado->accel_group == NULL) {
    estado->accel_group = gtk_accel_group_new();
    gtk_accel_group_attach (estado->accel_group, GTK_OBJECT (estado->win_main));
  }
  
  if (accel && accel[0]=='^') {
    gtk_widget_add_accelerator (menuitem, "activate",estado->accel_group, accel[1], 
                                GDK_CONTROL_MASK,
                                GTK_ACCEL_VISIBLE);
  }

  /* Sugerencias */
  if (tip && strlen(tip)) {
    gtk_tooltips_set_tip (estado->sugerencias, menuitem, tip, NULL);
  }
  
  return (menuitem);
}

void create_window1 (main_state_t *estado)
/************************************************************************/
/* Se le pasa como parametro un puntero a la estructura que contiene    */
/* todo el estado global del interfaz, que es accedido por otras partes */
/* del programa                                                         */
/************************************************************************/
{
  GtkWidget *lcd;
  GtkWidget *window1;
  GtkWidget *grados_in[4];       /* Entrada de datos manuales                */
  GtkWidget *lcd_g_art[4];       /* Visualizacion de la posicion en grados   */
  GtkWidget *lcd_gf_art[4];      /* Visualizacion de la posicion en grados f */
  GtkWidget *lcd_vect;
  GtkWidget *lcd_fich;           /* LCD que muestra el nombre del fichero    */
  GtkObject *adj[4];             /* Valores de las articulaciones            */
  GtkObject *grados_in_adj[4];   /* Valores manuales introducidos            */
  GtkObject *secuencia_adj;      /* Valor del potenciometro de secuncias     */
  GtkObject *te_adj;             /* Valor del tiempo de espera               */
  GtkWidget *te_lcd;             /* Entrada asociada al tiempo de espera     */
  GtkObject *ct_adj;             /* Valor de la cte de tiempo                */
  GtkWidget *ct_lcd;             /* Entrada asociada a la cte de tiempo      */
  GtkAdjustment *adj_pb;         /* Valor de la barra de progreso */
  GtkWidget *progresbar;         /* Barra de progreso             */

  
  GtkWidget *vbox1, *vbox2, *vbox3;
  GtkWidget *hbox3;
  GtkWidget *hbox4, *hbox5, *hbox6, *hbox7;
  GtkWidget *hbox8, *hbox9, *hbox10, *hbox11;
  GtkWidget *frame1, *frame2,  *frame3, *frame4, *frame5;
  GtkWidget *label2, *label3, *label4, *label5, *label6, *label7;
  GtkWidget *hscrollbar3;
  GtkWidget *hscrollbar2;
  GtkWidget *hscrollbar4;
  GtkWidget *hscrollbar5;
  GtkWidget *hscrollbar6;
  GtkWidget *button2, *button3;
  GtkWidget *button4, *button5, *button6, *button7, *button8;
  GtkWidget *button9, *button10, *button11, *button12, *button13;
  GtkWidget *button14,*button15, *button16, *button17;
  GtkWidget *menubar;
  GtkWidget *menu;
  GtkWidget *menuitem;
  
  int i;

  window1 = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_object_set_data (GTK_OBJECT (window1), "window1", window1);
  gtk_container_set_border_width (GTK_CONTAINER (window1), 3);
  gtk_window_set_title (GTK_WINDOW (window1), "CUBE FISICO");
  gtk_window_set_policy (GTK_WINDOW (window1), FALSE, FALSE, FALSE);
  
  /* Almacenar ventana principal en el estado global */
  estado->win_main=window1;

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox1", vbox1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (window1), vbox1);

  /*---------- BARRA DE MENU ----------*/
  menubar = gtk_menu_bar_new();
  gtk_box_pack_start(GTK_BOX(vbox1), menubar, FALSE, TRUE, 0);
  gtk_widget_show(menubar);
  
  

  
  /* OPCION FILE */
  menu = gtkutils_crear_submenu_bar(menubar,"File");
  menuitem = crear_item_menu(estado,menu,"New","","Nuevo grupo de secuencias",
                             GTK_SIGNAL_FUNC(menu_file), "0");
                             

                             
  menuitem = crear_item_menu(estado,menu,"Open","^O","Abrir fichero de secuencias",
                             GTK_SIGNAL_FUNC(menu_file), "1");
  menuitem = crear_item_menu(estado,menu,"Save","^S","Grabar fichero de secuencias actual",
                             GTK_SIGNAL_FUNC(menu_file), "2");
  menuitem = crear_item_menu(estado,menu,"Save as","","Grabar fichero de secuencias con otro nombre",
                             GTK_SIGNAL_FUNC(menu_file), "3");                           
                             
  menuitem = crear_item_menu(estado,menu,"Quit  ","^Q","Salir del programa",
                             GTK_SIGNAL_FUNC(main_destroy), "");
                             
  /* OPCION HELP */
  menu = gtkutils_crear_submenu_bar(menubar,"Help");
  menuitem = crear_item_menu(estado,menu,"About","","Sobre cube-fisico",
                             GTK_SIGNAL_FUNC(menu_help), "0");

        

  /* ---------- LCD --------------*/
  frame1 = gtk_frame_new ("");
  gtk_widget_ref (frame1);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame1", frame1,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame1);
  gtk_box_pack_start (GTK_BOX (vbox1), frame1, TRUE, TRUE, 0);

  hbox8 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox8);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox8", hbox8,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox8);
  gtk_container_add (GTK_CONTAINER (frame1), hbox8);

  /*---------- LCD ------------*/
  lcd = lcd_init();
  gtk_widget_ref (lcd);
  gtk_widget_show (lcd);
  gtk_box_pack_start (GTK_BOX (hbox8), lcd, TRUE, TRUE, 0);


  label6 = gtk_label_new ("CUBE-FISICO\nVERSION 2.0");
  gtk_widget_ref (label6);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label6", label6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label6);
  gtk_box_pack_start (GTK_BOX (hbox8), label6, FALSE, FALSE, 0);
  gtk_misc_set_padding (GTK_MISC (label6), 65, 0);




  /*------------ARTICULACIONES -----------*/
  frame2 = gtk_frame_new ("");
  gtk_widget_ref (frame2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame2", frame2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame2);
  gtk_box_pack_start (GTK_BOX (vbox1), frame2, TRUE, TRUE, 0);

  vbox2 = gtk_vbox_new (FALSE, 5);
  gtk_widget_ref (vbox2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox2", vbox2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (frame2), vbox2);
  gtk_container_set_border_width (GTK_CONTAINER (vbox2), 2);

  hbox3 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox3", hbox3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox3);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox3, TRUE, TRUE, 0);

 
  /* ------ Articulacion 1 ----------- */
  label3 = gtk_label_new ("Art 1");
  gtk_widget_ref (label3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label3", label3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label3);
  gtk_box_pack_start (GTK_BOX (hbox3), label3, FALSE, FALSE, 0);


  /* Potenciometro  */
  adj[0]=gtk_adjustment_new(0.1,-90,91,1,1,1);
  hscrollbar3 = gtk_hscrollbar_new (GTK_ADJUSTMENT (adj[0]));
  gtk_widget_ref (hscrollbar3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hscrollbar3", hscrollbar3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hscrollbar3);
  gtk_box_pack_start (GTK_BOX (hbox3), hscrollbar3, TRUE, TRUE, 0);
  gtk_widget_set_usize (hscrollbar3, 150, -2);

  /* Visualizacion en grados */
  lcd_g_art[0] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_g_art[0]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry5", lcd_g_art[0],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_g_art[0]);
  gtk_box_pack_start (GTK_BOX (hbox3), lcd_g_art[0], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_g_art[0], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_g_art[0]),FALSE);

  /* Visualizacion en grados futaba */
  lcd_gf_art[0] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_gf_art[0]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry8", lcd_gf_art[0],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_gf_art[0]);
  gtk_box_pack_start (GTK_BOX (hbox3), lcd_gf_art[0], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_gf_art[0], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_gf_art[0]),FALSE);

  /* Boton de reset */
  button5 = gtk_button_new_with_label ("Reset");
  gtk_widget_ref (button5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button5", button5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button5);
  gtk_box_pack_start (GTK_BOX (hbox3), button5, FALSE, FALSE, 0);

  hbox4 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox4);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox4", hbox4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox4);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox4, TRUE, TRUE, 0);

  /*------------ Articulacion 2 -----------*/
  label2 = gtk_label_new ("Art 2");
  gtk_widget_ref (label2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label2", label2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label2);
  gtk_box_pack_start (GTK_BOX (hbox4), label2, FALSE, FALSE, 0);

  /* Potenciometro */
  adj[1]= gtk_adjustment_new (0.1, -90, 91, 1, 1, 1);
  hscrollbar2 = gtk_hscrollbar_new (GTK_ADJUSTMENT (adj[1]));
  gtk_widget_ref (hscrollbar2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hscrollbar2", hscrollbar2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hscrollbar2);
  gtk_box_pack_start (GTK_BOX (hbox4), hscrollbar2, TRUE, TRUE, 0);
  gtk_widget_set_usize (hscrollbar2, 150, -2);

  /* Visualizacion en grados */
  lcd_g_art[1] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_g_art[1]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry3", lcd_g_art[1],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_g_art[1]);
  gtk_box_pack_start (GTK_BOX (hbox4), lcd_g_art[1], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_g_art[1], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_g_art[1]),FALSE);

  /* Visualizacion en grados futaba */
  lcd_gf_art[1] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_gf_art[1]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry4", lcd_gf_art[1],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_gf_art[1]);
  gtk_box_pack_start (GTK_BOX (hbox4), lcd_gf_art[1], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_gf_art[1], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_gf_art[1]),FALSE);

  button2 = gtk_button_new_with_label ("Reset");
  gtk_widget_ref (button2);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button2", button2,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button2);
  gtk_box_pack_start (GTK_BOX (hbox4), button2, FALSE, FALSE, 0);

  hbox5 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox5", hbox5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox5);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox5, TRUE, TRUE, 0);

  /* -------------------- Articulacion 3 ------------------ */

  label4 = gtk_label_new ("Art 3");
  gtk_widget_ref (label4);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label4", label4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label4);
  gtk_box_pack_start (GTK_BOX (hbox5), label4, FALSE, FALSE, 0);

  /* Potenciometro */
  adj[2] = gtk_adjustment_new(0.1,-90,91,1,1,1);
  hscrollbar4 = gtk_hscrollbar_new (GTK_ADJUSTMENT (adj[2]));
  gtk_widget_ref (hscrollbar4);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hscrollbar4", hscrollbar4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hscrollbar4);
  gtk_box_pack_start (GTK_BOX (hbox5), hscrollbar4, TRUE, TRUE, 0);
  gtk_widget_set_usize (hscrollbar4, 150, -2);


  /* LCD de grados */
  lcd_g_art[2] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_g_art[2]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry6", lcd_g_art[2],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_g_art[2]);
  gtk_box_pack_start (GTK_BOX (hbox5), lcd_g_art[2], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_g_art[2], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_g_art[2]),FALSE);

  /* LCD de grados futaba */
  lcd_gf_art[2] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_gf_art[2]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry9", lcd_gf_art[2],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_gf_art[2]);
  gtk_box_pack_start (GTK_BOX (hbox5), lcd_gf_art[2], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_gf_art[2], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_gf_art[2]),FALSE);

  button3 = gtk_button_new_with_label ("Reset");
  gtk_widget_ref (button3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button3", button3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button3);
  gtk_box_pack_start (GTK_BOX (hbox5), button3, FALSE, FALSE, 0);

  hbox6 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox6);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox6", hbox6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox6);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox6, TRUE, TRUE, 0);

  /*---------- Articulacion 4 ----------------*/
  label5 = gtk_label_new ("Art 4");
  gtk_widget_ref (label5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label5", label5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label5);
  gtk_box_pack_start (GTK_BOX (hbox6), label5, FALSE, FALSE, 0);

  /* Potenciometro */
  adj[3]=gtk_adjustment_new(0.1,-90,91,1,1,1);
  hscrollbar5 = gtk_hscrollbar_new (GTK_ADJUSTMENT (adj[3]));
  gtk_widget_ref (hscrollbar5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hscrollbar5", hscrollbar5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hscrollbar5);
  gtk_box_pack_start (GTK_BOX (hbox6), hscrollbar5, TRUE, TRUE, 0);
  gtk_widget_set_usize (hscrollbar5, 150, -2);

  /* LCD grados */
  lcd_g_art[3] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_g_art[3]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry7", lcd_g_art[3],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_g_art[3]);
  gtk_box_pack_start (GTK_BOX (hbox6), lcd_g_art[3], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_g_art[3], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_g_art[3]),FALSE);

  /* LCD grados futaba */
  lcd_gf_art[3] = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_gf_art[3]);
  gtk_object_set_data_full (GTK_OBJECT (window1), "entry10",lcd_gf_art[3],
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_gf_art[3]);
  gtk_box_pack_start (GTK_BOX (hbox6), lcd_gf_art[3], TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_gf_art[3], 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_gf_art[3]),FALSE);

  button4 = gtk_button_new_with_label ("Reset");
  gtk_widget_ref (button4);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button4", button4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button4);
  gtk_box_pack_start (GTK_BOX (hbox6), button4, FALSE, FALSE, 0);


  /* Tiempo de espera */
  hbox6 = gtk_hbox_new (FALSE, 2);
  gtk_widget_ref (hbox6);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox6", hbox6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox6);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox6, TRUE, TRUE, 0);

  label5 = gtk_label_new ("Tiempo espera (ms): ");
  gtk_widget_ref (label5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label5", label5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label5);
  gtk_box_pack_start (GTK_BOX (hbox6), label5, FALSE, FALSE, 0);
  
  te_adj = gtk_adjustment_new (0,0,90000, 1, 1, 1);
  te_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (te_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(te_lcd),5);
  gtk_box_pack_start (GTK_BOX (hbox6), te_lcd, TRUE,TRUE, 0);
  gtk_widget_show (te_lcd);
  
  
  /* Constante de tiempo */
  label5 = gtk_label_new ("Cte tiempo(msx10): ");
  gtk_widget_ref (label5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label5", label5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label5);
  gtk_box_pack_start (GTK_BOX (hbox6), label5, FALSE, FALSE, 0);
  
  ct_adj = gtk_adjustment_new (0,0,90000, 1, 1, 1);
  ct_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (ct_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(ct_lcd),5);
  gtk_box_pack_start (GTK_BOX (hbox6), ct_lcd, TRUE,TRUE, 0);
  gtk_widget_show (ct_lcd);


  /*------ Creacion de los cuadros de entrada manuales en grados ------*/
  frame4 = gtk_frame_new ("");
  gtk_widget_ref (frame4);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame4", frame4,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame4);
  gtk_box_pack_start (GTK_BOX (vbox1), frame4, TRUE, TRUE, 0);

  hbox9 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox9);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox9", hbox9,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox9);
  gtk_container_add (GTK_CONTAINER (frame4), hbox9);
  gtk_container_set_border_width (GTK_CONTAINER (hbox9), 2);

  /* Entrada 1 */
  grados_in_adj[0] = gtk_adjustment_new (0,-90,90, 1, 10, 10);
  grados_in[0]=gtk_spin_button_new (GTK_ADJUSTMENT (grados_in_adj[0]), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(grados_in[0]),3);
  gtk_box_pack_start (GTK_BOX (hbox9), grados_in[0], TRUE,TRUE, 0);
  gtk_widget_set_usize (grados_in[0], 50, -2);
  gtk_widget_show (grados_in[0]);
  
    /* Entrada 2 */
  grados_in_adj[1] = gtk_adjustment_new (0,-90,90, 1, 10, 10);
  grados_in[1]=gtk_spin_button_new (GTK_ADJUSTMENT (grados_in_adj[1]), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(grados_in[1]),3);
  gtk_box_pack_start (GTK_BOX (hbox9), grados_in[1], TRUE,TRUE, 0);
  gtk_widget_set_usize (grados_in[1], 50, -2);
  gtk_widget_show (grados_in[1]);  
  
    /* Entrada 3 */
  grados_in_adj[2] = gtk_adjustment_new (0,-90,90, 1, 10, 10);
  grados_in[2]=gtk_spin_button_new (GTK_ADJUSTMENT (grados_in_adj[2]), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(grados_in[2]),3);
  gtk_box_pack_start (GTK_BOX (hbox9), grados_in[2], TRUE,TRUE, 0);
  gtk_widget_set_usize (grados_in[2], 50, -2);
  gtk_widget_show (grados_in[2]);    
  
    /* Entrada 4 */
  grados_in_adj[3] = gtk_adjustment_new (0,-90,90, 1, 10, 10);
  grados_in[3]=gtk_spin_button_new (GTK_ADJUSTMENT (grados_in_adj[3]), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(grados_in[3]),3);
  gtk_box_pack_start (GTK_BOX (hbox9), grados_in[3], TRUE,TRUE, 0);
  gtk_widget_set_usize (grados_in[3], 50, -2);
  gtk_widget_show (grados_in[3]);    

  /* Boton de lectura de los potenciometros */
  button11 = gtk_button_new_with_label("Leer");
  gtk_widget_ref(button11);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button11", button11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button11);
  gtk_box_pack_start (GTK_BOX (hbox9), button11, FALSE, FALSE, 0);
  
  /* Boton de actulizacion de las articulaciones y potenciometros */
  button10 = gtk_button_new_with_label ("OK");
  gtk_widget_ref (button10);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button10", button10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button10);
  gtk_box_pack_start (GTK_BOX (hbox9), button10, FALSE, FALSE, 0);

  /*--------- SECUENCIAS -------------------------*/
  frame5 = gtk_frame_new ("");
  gtk_widget_ref (frame5);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame5", frame5,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame5);
  gtk_box_pack_start (GTK_BOX (vbox1), frame5, TRUE, TRUE, 0);

  /* Caja vertical */
  vbox3 = gtk_vbox_new (FALSE, 0);
  gtk_widget_ref (vbox3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "vbox31", vbox3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (vbox3);
  gtk_container_add (GTK_CONTAINER (frame5), vbox3);

  /* Fila del potenciometro de secuencia */
  hbox10 = gtk_hbox_new (FALSE, 10);
  gtk_widget_ref (hbox10);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox10", hbox10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox10);
  gtk_box_pack_start(GTK_BOX(vbox3),hbox10,FALSE,FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (hbox10), 2);
  
  label7 = gtk_label_new ("Secuencia");
  gtk_widget_ref (label7);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label7", label7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label7);
  gtk_box_pack_start (GTK_BOX (hbox10), label7, FALSE, FALSE, 0);
  
  /* Potenciometro  */
  secuencia_adj=gtk_adjustment_new(0,0,0,1,1,1);
  hscrollbar6 = gtk_hscrollbar_new (GTK_ADJUSTMENT (secuencia_adj));
  gtk_widget_ref (hscrollbar6);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hscrollbar6", hscrollbar6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hscrollbar6);
  gtk_box_pack_start (GTK_BOX (hbox10), hscrollbar6, TRUE, TRUE, 0);
  gtk_widget_set_usize (hscrollbar6, 150, -2);
  
  /* Visualizacion vector activo */
  lcd_vect = gtk_entry_new_with_max_length (5);
  gtk_widget_ref (lcd_vect);
  gtk_object_set_data_full (GTK_OBJECT (window1), "lcd_vect", lcd_vect,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_vect);
  gtk_box_pack_start (GTK_BOX (hbox10), lcd_vect, TRUE, TRUE, 0);
  gtk_widget_set_usize (lcd_vect, 50, -2);
  gtk_entry_set_editable(GTK_ENTRY(lcd_vect),FALSE);
  gtk_entry_set_text(GTK_ENTRY(lcd_vect),"0");
  
  /* Boton de ir al vector 0 */
  button13 = gtk_button_new_with_label ("Init");
  gtk_widget_ref (button13);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button13", button13,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button13);
  gtk_box_pack_start (GTK_BOX (hbox10), button13, FALSE, FALSE, 0);
  
  /*-- Nombre del fichero --*/
  hbox10 = gtk_hbox_new (FALSE, 2);
  gtk_widget_ref (hbox10);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox10", hbox10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox10);
  gtk_box_pack_start(GTK_BOX(vbox3),hbox10,FALSE,FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (hbox10), 2);
  
  label7 = gtk_label_new ("Fichero: ");
  gtk_widget_ref (label7);
  gtk_object_set_data_full (GTK_OBJECT (window1), "label7", label7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (label7);
  gtk_box_pack_start (GTK_BOX (hbox10), label7, FALSE, FALSE, 0);
  
  /* LCD FICHERO */
  hbox10 = gtk_hbox_new (FALSE, 2);
  gtk_widget_ref (hbox10);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox10", hbox10,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox10);
  gtk_box_pack_start(GTK_BOX(vbox3),hbox10,FALSE,FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (hbox10), 2);
  
  lcd_fich = gtk_entry_new_with_max_length (256);
  gtk_widget_ref (lcd_fich);
  gtk_object_set_data_full (GTK_OBJECT (window1), "lcd_fich", lcd_fich,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (lcd_fich);
  gtk_box_pack_start (GTK_BOX (hbox10), lcd_fich, TRUE, TRUE, 0);
  gtk_entry_set_editable(GTK_ENTRY(lcd_fich),FALSE);
  gtk_entry_set_text(GTK_ENTRY(lcd_fich),"");
  
  /* Fila de botones de control de las secuencias */
  hbox11 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox11);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox11", hbox11,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox11);
  gtk_box_pack_start(GTK_BOX(vbox3),hbox11,FALSE,FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (hbox11), 2);
  
  /* Boton de Insert */
  button15 = gtk_button_new_with_label ("Insert");
  gtk_widget_ref (button15);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button15", button15,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button15);
  gtk_box_pack_start (GTK_BOX (hbox11), button15, FALSE, FALSE, 0);
  
  /* Boton de delete */
  button16 = gtk_button_new_with_label ("Delete");
  gtk_widget_ref (button16);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button16", button16,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button16);
  gtk_box_pack_start (GTK_BOX (hbox11), button16, FALSE, FALSE, 0);
  
  /* Boton de grabacion */
  button12 = gtk_button_new_with_label ("GRAB");
  gtk_widget_ref (button12);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button12", button12,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button12);
  gtk_box_pack_start (GTK_BOX (hbox11), button12, FALSE, FALSE, 0);
  
  /* Boton de Play */
  button14 = gtk_button_new_with_label ("PLAY");
  gtk_widget_ref (button14);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button14", button14,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button14);
  gtk_box_pack_start (GTK_BOX (hbox11), button14, FALSE, FALSE, 0);
  
  /* Boton de play # */
  button17 = gtk_button_new_with_label ("PLAY #");
  gtk_widget_ref (button17);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button17", button17,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button17);
  gtk_box_pack_start (GTK_BOX (hbox11), button17, FALSE, FALSE, 0);
  


  /*---------- BOTONES PRINCIPALES --------------*/
  frame3 = gtk_frame_new ("");
  gtk_widget_ref (frame3);
  gtk_object_set_data_full (GTK_OBJECT (window1), "frame3", frame3,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (frame3);
  gtk_box_pack_start (GTK_BOX (vbox1), frame3, TRUE, TRUE, 0);

  hbox7 = gtk_hbox_new (FALSE, 0);
  gtk_widget_ref (hbox7);
  gtk_object_set_data_full (GTK_OBJECT (window1), "hbox7", hbox7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (hbox7);
  gtk_container_add (GTK_CONTAINER (frame3), hbox7);
  gtk_container_set_border_width (GTK_CONTAINER (hbox7), 2);

  button6 = gtk_button_new_with_label ("QUIT");
  gtk_widget_ref (button6);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button6", button6,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button6);
  gtk_box_pack_start (GTK_BOX (hbox7), button6, FALSE, FALSE, 0);

  button7 = gtk_button_new_with_label ("RESET 6811");
  gtk_widget_ref (button7);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button7", button7,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button7);
  gtk_box_pack_start (GTK_BOX (hbox7), button7, FALSE, FALSE, 0);

  button8 = gtk_button_new_with_label ("LOAD");
  gtk_widget_ref (button8);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button8", button8,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button8);
  gtk_box_pack_start (GTK_BOX (hbox7), button8, FALSE, FALSE, 0);

  button9 = gtk_button_new_with_label ("RESET POS");
  gtk_widget_ref (button9);
  gtk_object_set_data_full (GTK_OBJECT (window1), "button9", button9,
                            (GtkDestroyNotify) gtk_widget_unref);
  gtk_widget_show (button9);
  gtk_box_pack_start (GTK_BOX (hbox7), button9, FALSE, FALSE, 0);
  
  

  /* -------------- Creacion de la barra de progreso ----------- */
  adj_pb = (GtkAdjustment *)gtk_adjustment_new(0,0,256,0,0,0);
  progresbar = gtk_progress_bar_new_with_adjustment(adj_pb);
  gtk_widget_show(progresbar);
  gtk_box_pack_start(GTK_BOX(vbox1),progresbar,FALSE,FALSE,0);


  /*-------------------------------------------------*/
  /* Configuracion de las señales de retrollamada    */
  /*-------------------------------------------------*/

  /************************/
  /* BOTONES PRINCIPALES  */
  /************************/

  /* Escucha de la señal de destruccion */
  gtk_signal_connect(GTK_OBJECT(window1),"destroy", GTK_SIGNAL_FUNC(main_destroy), NULL);

  /* Boton de quit */
  gtk_signal_connect(GTK_OBJECT(button6),"clicked", GTK_SIGNAL_FUNC(main_boton), "1");
  
  /* Boton de reset ct6811 */
  gtk_signal_connect(GTK_OBJECT(button7),"clicked", GTK_SIGNAL_FUNC(main_boton), "2");
  
  /* Boton de load */
  gtk_signal_connect(GTK_OBJECT(button8),"clicked", GTK_SIGNAL_FUNC(main_boton), "3");
  
  /* Boton de reset pos */
  gtk_signal_connect(GTK_OBJECT(button9),"clicked", GTK_SIGNAL_FUNC(main_boton), "4");
  
  /* Boton de grab */
  gtk_signal_connect(GTK_OBJECT(button12),"clicked", GTK_SIGNAL_FUNC(main_boton), "12");
  
  /* Boton de init */
  gtk_signal_connect(GTK_OBJECT(button13),"clicked", GTK_SIGNAL_FUNC(main_boton), "13");
  
  /* Boton de Play */
  gtk_signal_connect(GTK_OBJECT(button14),"clicked", GTK_SIGNAL_FUNC(main_boton), "14");
  
  /* Boton de insert */
  gtk_signal_connect(GTK_OBJECT(button15),"clicked", GTK_SIGNAL_FUNC(main_boton), "15");
  
  /* Boton de delete */
  gtk_signal_connect(GTK_OBJECT(button16),"clicked", GTK_SIGNAL_FUNC(main_boton), "16");
  
  /* Boton de play # */
  gtk_signal_connect(GTK_OBJECT(button17),"clicked", GTK_SIGNAL_FUNC(main_boton), "17");

  /***********************************/
  /* BOTONES DE RESET DE LA POSICION */
  /***********************************/
  gtk_signal_connect(GTK_OBJECT(button5),"clicked", GTK_SIGNAL_FUNC(main_boton), "5");
  gtk_signal_connect(GTK_OBJECT(button2),"clicked", GTK_SIGNAL_FUNC(main_boton), "6");
  gtk_signal_connect(GTK_OBJECT(button3),"clicked", GTK_SIGNAL_FUNC(main_boton), "7");
  gtk_signal_connect(GTK_OBJECT(button4),"clicked", GTK_SIGNAL_FUNC(main_boton), "8");

  /***********************************************/
  /*  CAMBIO EN LOS VALORES DE LAS ARTICULACION  */
  /***********************************************/
  gtk_signal_connect(adj[0],"value_changed", GTK_SIGNAL_FUNC(pot_changed),"0");
  gtk_signal_connect(adj[1],"value_changed", GTK_SIGNAL_FUNC(pot_changed),"1");
  gtk_signal_connect(adj[2],"value_changed", GTK_SIGNAL_FUNC(pot_changed),"2");
  gtk_signal_connect(adj[3],"value_changed", GTK_SIGNAL_FUNC(pot_changed),"3");

  /**************************************/
  /* CAMBIOS EN EL NUMERO DE SECUENCIA  */
  /**************************************/
  gtk_signal_connect(secuencia_adj,"value_changed", GTK_SIGNAL_FUNC(sec_changed),"0");

  /****************************************/
  /*  CUADROS DE ENTRADA DE GRADOS        */
  /****************************************/
  gtk_signal_connect(GTK_OBJECT(button10),"clicked",GTK_SIGNAL_FUNC(main_boton),"10");
  gtk_signal_connect(GTK_OBJECT(button11),"clicked",GTK_SIGNAL_FUNC(main_boton),"11");

  

  /* ACTUALIZAR EL ESTADO GLOBAL */

  estado->secuencia_adj=secuencia_adj;
  estado->lcd_vect=lcd_vect;
  estado->lcd_fich=lcd_fich;
  estado->progresbar=progresbar;
  estado->te_adj=te_adj;
  estado->ct_adj=ct_adj;
  for (i=0; i<4; i++) {
    estado->lcd_g_art[i]=lcd_g_art[i];
    estado->lcd_gf_art[i]=lcd_gf_art[i];
    estado->adj[i]=adj[i];
    estado->grados_in_adj[i]=grados_in_adj[i];
  }

}
