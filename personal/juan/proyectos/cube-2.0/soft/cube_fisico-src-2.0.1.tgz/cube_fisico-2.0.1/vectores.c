/**************************************************************************/
/* VECTORES.C   Juan Gonzalez Gomez.   Octubre 2000                       */
/*------------------------------------------------------------------------*/
/* Modulo para la gestion de los vectores de posicion angular.            */
/**************************************************************************/

#include <stdio.h>
#include <glib.h>

#include "vectores.h"
#include "spinet.h"


#define BLOQUE1 'a'

/*-----------------------------------------------*/
/*   F U N C I O N E S   D E   I N T E R F A Z   */
/*-----------------------------------------------*/

/*------------------------*/
/* FUNCIONES DE CALCULO   */
/*------------------------*/

double vector_distancia(vector_pos_t *v1, vector_pos_t *v2)
/***********************************************************/
/* Devolver la distancia entre dos vectores de posicion    */
/*                                                         */
/* ENTRADAS:                                               */
/*   v1: Puntero al vector de posicion inicial             */
/*   v2: Puntero al vector de posicion final               */
/*                                                         */
/* DEVUELVE:                                               */
/*   -El valor de la distancia.                            */
/*                                                         */
/*  La distancia entre dos vectores de posicion se define  */
/* como la maxima distancia angular entre las mismas       */
/* componentes de los vectores v1 y v2:                    */
/*                                                         */
/*  Sea v1=(a1,a2,a3,a4)                                   */
/*      v2=(b1,b2,b3,b4)                                   */
/*                                                         */
/*      d(v1,v2)=MAX{|b1-a1|, |b2-a2|, |b3-a3|, |b4-a4|}   */
/*                                                         */
/***********************************************************/
{
  double max;
  double d1,d2,d3,d4;
  
  /* Calcular las distancias angulares de cada componente */
  d1 = ABS(v2->pos[0]-v1->pos[0]);
  d2 = ABS(v2->pos[1]-v1->pos[1]);
  d3 = ABS(v2->pos[2]-v1->pos[2]);
  d4 = ABS(v2->pos[3]-v1->pos[3]);
  
  /*  Obtener el maximo de las distancias */
  max = MAX(d1,d2);
  max = MAX(d3,max);
  max = MAX(d4,max);
  
  return max;
}

unsigned long vector_tiempo_trans(vector_pos_t *v1, vector_pos_t *v2, double ct)
/*******************************************************************/
/* Obtener el tiempo de transito desde la posicon v1 hasta la v2   */
/* El parametro ct es la constante de tiempo (tau) de los servos   */
/*                                                                 */
/* ENTRADAS:                                                       */
/*   -v1: Vector de posicion inicial                               */
/*   -v2: Vector de posicion final                                 */
/*   -ct: Constante de tiempo de los servos                        */
/*                                                                 */
/* DEVUELVE:                                                       */
/*   -El tiempo de transito (tt) en las mismas unidades que ct     */
/*                                                                 */
/* El tiempo de transito se define como el tiempo que emplea el    */
/* servo en recorrer una distancia angular. Para el caso de haber  */
/* muchos servos, el tt es el maximo de todos.                     */
/*                                                                 */
/*  tt = ct*d(v1,v2)  siendo d(v1,v2) la distancia entre v1 y v2   */
/*******************************************************************/
{
  unsigned long tt;
  double d;
  
  /* Calcular la distancia */
  d = vector_distancia(v1,v2);

  /* Calcular tiempo de transito */  
  tt = (unsigned long) (d*ct);
  
  /* Devolver el tiempo de transito */
  return tt;
}


/*-----------------------------------------------------*/
/* FUNCIONES RELACIONADAS CON LA ASIGNACION DE MEMORIA */
/*-----------------------------------------------------*/

vector_pos_t *vector_new()
/********************************************************************/
/* Crear un vector de posicion nuevo, con todos los campos a cero   */
/* DEVUELVE:                                                        */
/*    Un puntero al vector creado                                   */
/********************************************************************/
{
  vector_pos_t *vector;
  
  /* Crear un vector nuevo */
  vector = g_malloc(sizeof(vector_pos_t));
  
  /* Inicializar todos sus campos a cero */
  VECTOR_ASIGNAR(vector,0,0,0,0);
  vector->te=0;
  
  return vector;
}

void vector_free(vector_pos_t *vector)
/**********************************************/
/* Liberar la memoria tomada por un vector    */
/**********************************************/
{
  g_assert(vector!=NULL);
  g_free(vector);
}

vector_pos_t *vector_crear(double a1, double a2, double a3, double a4, unsigned int te)
/*****************************************************************/
/* Crear un vector nuevo con los valores indicados               */
/*                                                               */
/* ENTRADAS:                                                     */
/*   -a1,a2,a3,a4 : Angulos en grados de las articulaciones      */
/*   -te : Tiempo de espera.                                     */
/*                                                               */
/* DEVUELVE:                                                     */
/*   Puntero al vector creado                                    */
/*****************************************************************/
{
  vector_pos_t *v;
  
  
  v=vector_new();
  VECTOR_ASIGNAR(v,a1,a2,a3,a4);
  v->te=te;
  
  return v;
}

/*-----------------------------------------------*/
/* FUNCIONES RELACIONADAS CON EL ACCESO A DISCO  */
/*-----------------------------------------------*/

int vector_save(FILE *f, vector_pos_t *v)
/**************************************************************/
/* Grabar un vector en el fichero especificado por el stream  */
/* DEVUELVE:                                                  */
/*   0 si ha ocurrido un error.                               */
/*   1 si todo bien.                                          */
/**************************************************************/
{
  int n;
  
  n=fprintf (f,"[%.0f,%.0f,%.0f,%.0f],%u\n",v->pos[0],v->pos[1],v->pos[2],v->pos[3],v->te);
  if (n<0) return 0;
  
  return 1;
  
}

int vector_load(FILE *f, vector_pos_t *v)
/***********************************************/
/* Cargar un vector del fichero especificado   */
/* DEVUELVE:                                   */
/*   0 si ha ocurrido un error                 */
/*   1 si todo bien                            */
/*   2 si se al alcanzado el final del fichero */
/***********************************************/
{
  int n;
  int a1,a2,a3,a4;
  unsigned long te;

  /* Leer el vector del fichero */  
  n=fscanf (f,"[%d,%d,%d,%d],%lu\n",&a1,&a2,&a3,&a4,&te);
  
  v->pos[0]=(double) a1;
  v->pos[1]=(double) a2;
  v->pos[2]=(double) a3;
  v->pos[3]=(double) a4;
  v->te=te;

  if (n==EOF) return 2;
  
  if (n!=5) return 0;
  
  return 1;
}


/*-------------------------------------------------*/
/*  FUNCIONES RELACIONADAS CON EL SERVIDOR SPINET  */
/*-------------------------------------------------*/

void vector_posicionar(vector_pos_t *v)
/****************************************/
/* Enviar el vector de posicion a cube  */
/****************************************/
{
  spinet_set_pos_sistema_grados(BLOQUE1,v->pos[0], v->pos[1], v->pos[2], v->pos[3]);
}


/*--------------------------------*/
/*  FUNCIONES DE DEPURACION       */
/*--------------------------------*/

void vector_print(vector_pos_t *v)
/***************************************************/
/* Imprmir las componentes del vector de posicion  */
/***************************************************/
{
  g_print ("[%.0f,%.0f,%.0f,%.0f],%u\n",v->pos[0],v->pos[1],v->pos[2],v->pos[3],v->te);
}


