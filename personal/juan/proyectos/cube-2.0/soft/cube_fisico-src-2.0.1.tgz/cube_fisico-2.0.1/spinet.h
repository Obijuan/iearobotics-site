/****************************************************************************/
/* SPINET.H    NOVIEMBRE 2000                                              */
/*--------------------------------------------------------------------------*/
/* Definiciones y prototipos para el modulo SPINET.                         */
/* CONTROL DE 4 MOTORES FUTABA A TRAVES DE LA SPINET                        */
/****************************************************************************/

#include <microbotica/ctclient.h>

#ifndef _SPINET_H
#define _SPINET_H

/* Posiciones de los futaba. */
#define EXTREMO1 0
#define CENTRO   128
#define EXTREMO2 236

/* Mascaras de habilitacion para los futaba. Usado con la funcion  */
#define FUT1  0x01
#define FUT2  0x02
#define FUT3  0x04
#define FUT4  0x08
#define	DISABLE x00 /* Deshabilitar futabas */

/* Mascara para indicar que no hay cambios en la posicion de un futaba */
#define SIN_CAMBIOS 255

/*********************************/
/*    P R O T O T I P O S        */
/*********************************/
void spinet_cambiar_led(byte dir);
void spinet_activar(byte dir, byte mask);
void spinet_puertoc(byte dir, byte valor);
void spinet_posicionar(byte dir, byte motor, byte pos);
void spinet_pos_sistema(byte dir, byte fut1, byte fut2, byte fut3, byte fut4);
void spinet_set_pos_grados(byte dir,byte fut, double pos);
void spinet_set_pos_sistema_grados(byte dir,double fut1, double fut2, double fut3, double f4);
double spinet_to_grados_fut(double grados);

#endif /* _SPINET_H */


