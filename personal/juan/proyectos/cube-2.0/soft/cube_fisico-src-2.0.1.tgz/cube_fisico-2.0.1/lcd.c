/****************************************************************************/
/* lcd.c                               Octubre 2000                        */
/*--------------------------------------------------------------------------*/
/* LCD para las GTK                                                         */
/****************************************************************************/

#include <string.h>
#include <gtk/gtk.h>

#include "gtkutils.h"

#define TAMX 150
#define TAMY 30

/*--- PROTOTIPOS ----*/
static gint configure_event (GtkWidget *widget, GdkEventConfigure *event);
static gint expose_event (GtkWidget *widget, GdkEventExpose *event);
static GdkGC *get_pen(GdkColor *c);

/*---- VARIABLES ---*/
static GtkWidget *drawing_area=NULL;    /* Widget del area de dibujo */
static GdkPixmap *pixmap = NULL;        /* buffer de dibujo          */

static GdkFont *font     = NULL;   /* Tipo de letra empleado */    
static GdkGC *pen_red    = NULL;   /* Color rojo             */
static GdkGC *pen_green  = NULL;   /* Color verde            */
static GdkGC *pen_blue   = NULL;   /* Color azul             */
static GdkGC *pen_yellow = NULL;   /* Color amarillo         */

static char lcd_text[2][20]={"",""};
static int  lcd_y=0;


void lcd_refrescar()
/******************************/
/* Refrescar la pantalla.     */
/******************************/
{
  GdkRectangle update_rect;

  update_rect.x = 0;
  update_rect.y = 0;
  update_rect.width  = drawing_area->allocation.width;
  update_rect.height = drawing_area->allocation.height;

  gtk_widget_draw(drawing_area,&update_rect);
}

static GdkGC *get_pen(GdkColor *c)
/*******************************/
/* Obtener un gc para dibujar  */
/*******************************/
{
  GdkGC *gc;
  
  /* --- Crear un gc --- */
  gc = gdk_gc_new(pixmap);
  
  /*--- Configurar el primer plano con el color --- */
  gdk_gc_set_foreground (gc,c);
  
  return (gc);
}


GtkWidget *lcd_init()
/*******************/
/* Crear el lcd    */
/*******************/
{

   /* -- Crear area de dibujo -- */
  drawing_area = gtk_drawing_area_new();
  
  /* -- Asignar tipo de letra --*/
  font = drawing_area->style->font;
  
  /* Establecer tamaño area dibujo */
  gtk_drawing_area_size (GTK_DRAWING_AREA(drawing_area), TAMX, TAMY);
  
  /* Hacerla visible */
  gtk_widget_show(drawing_area);
  
  /* Configurar los eventos expose_event y configure_event */
  gtk_signal_connect (GTK_OBJECT (drawing_area), "configure_event",
                      (GtkSignalFunc) configure_event, NULL);
                      
  gtk_signal_connect (GTK_OBJECT (drawing_area), "expose_event",
                      (GtkSignalFunc) expose_event, NULL);
                      
  /* Devolver widget creado */                    
  return (drawing_area);                    
}


static gint configure_event (GtkWidget *widget, GdkEventConfigure *event)
/***************************************************/
/* Funcion llamada por la señal CONFIGURE_EVENT    */
/***************************************************/
{

  /* Liberar buffer de dibujo, si ya estaba creado */
  if (pixmap) {
    gdk_pixmap_unref (pixmap);
  }

  /* Crear un nuevo buffer, segun el tamaño de la nueva ventana */
  pixmap = gdk_pixmap_new (widget->window,
                           widget->allocation.width,
                           widget->allocation.height,
                           -1);
                           
  /* Crear los pinceles, si no estaban creados */
  if (pen_red==NULL) {
    pen_red   = get_pen (gtkutils_new_color(0xffff, 0, 0));
    pen_green = get_pen (gtkutils_new_color(0x0, 0xffff, 0));
    pen_blue  = get_pen (gtkutils_new_color(0x0, 0x0, 0xffff));
    pen_yellow= get_pen (gtkutils_new_color(0xffff,0xffff,0x0000));
  }                         

  return TRUE;
}

static gint expose_event (GtkWidget *widget, GdkEventExpose *event)
/***************************************************************************/
/* Funcion llamada por la señal EXPOSE_EVENT, que se produce cada vez que  */
/* hay que redibujar la pantalla grafica.                                  */
/***************************************************************************/
{
  /* Borrar imagen anterior en buffer */
  gdk_draw_rectangle (pixmap, widget->style->black_gc,
                      TRUE, 0,0,
                      widget->allocation.width,
                      widget->allocation.height);
 
  /* Dibujar la nueva imagen en el buffer */                     
  gdk_draw_rectangle(pixmap,pen_red,FALSE,1,1,TAMX,TAMY);
  gdk_draw_string(pixmap,font,pen_yellow,5,15,(gchar *)lcd_text[0]);
  gdk_draw_string(pixmap,font,pen_yellow,5,28,(gchar *)lcd_text[1]);
  
  /* Copiar buffer a la ventana */
  gdk_draw_pixmap(widget->window, widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
                  pixmap,
                  event->area.x, event->area.y,
                  event->area.x, event->area.y,
                  event->area.width, event->area.height);                    
                      
  return TRUE;
}


void lcd_print(char *cad)
{
  strcat(lcd_text[lcd_y],cad);
  lcd_refrescar();
}

void lcd_locate(int x, int y)
{
  lcd_y = y-1;
}

void lcd_cls()
{
  strcpy(lcd_text[0],"");
  strcpy(lcd_text[1],"");
                  
  lcd_y = 0;                
                      
  lcd_refrescar();
}

