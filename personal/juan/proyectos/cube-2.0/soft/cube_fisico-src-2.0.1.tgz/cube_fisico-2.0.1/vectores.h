/**************************************************************************/
/* VECTORES.H   Juan Gonzalez Gomez.   Octubre 2000                       */
/*------------------------------------------------------------------------*/
/* Prototipos y definiciones para el modulo vectores.c                    */
/**************************************************************************/

#ifndef _VECTORES_H
#define _VECTORES_H

/*-----------------*/
/* DEFINICIONES    */
/*-----------------*/

/* Numero de articulaciones */
#define NUM_ART 4

/*-------------*/
/*  MACROS     */
/*-------------*/
#define VECTOR_ASIGNAR(V,A1,A2,A3,A4) \
         V->pos[0]=A1; V->pos[1]=A2; \
         V->pos[2]=A3; V->pos[3]=A4;


/*-------------------------*/
/* ESTRUCTURAS DE DATOS    */
/*-------------------------*/

/* Vector de posicion angular */
typedef struct vector_pos_s {
  double pos[NUM_ART]; /* Posicion en grados de cada articulacion */
  unsigned int te;     /* Tiempo de espera, en milisegundos       */
} vector_pos_t;

/*-------------------*/
/*    PROTOTIPOS     */
/*-------------------*/
double vector_distancia(vector_pos_t *v1, vector_pos_t *v2);
unsigned long vector_tiempo_trans(vector_pos_t *v1, vector_pos_t *v2, double ct);
vector_pos_t *vector_new();
vector_pos_t *vector_crear(double a1, double a2, double a3, double a4, unsigned int te);
void vector_free(vector_pos_t *vector);
int vector_save(FILE *f, vector_pos_t *v);
int vector_load(FILE *f, vector_pos_t *v);
void vector_posicionar(vector_pos_t *v);
void vector_print(vector_pos_t *v);

#endif  /* _VECTORES_H */


