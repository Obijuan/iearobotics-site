/************************************************************************/
/* func.h       Sep-2000                                                */
/*----------------------------------------------------------------------*/
/* Prototipos y definiciones del modulo func.c                          */
/************************************************************************/

#ifndef _FUNC_H
#define _FUNC_H

/*---  Modificacion de parametros ----*/
void func_amplitud_set(double amp);
void func_long_onda_set(double lamda);
void func_tiempo_set(double time);
void func_frec_set(double frecuencia);

/*--- Obtencion de parametros --- */
double func_periodo_get();

/*--- Funciones de contorno --- */
double func_onda_sinusoidal(double x);
double func_nula(double x);
double func_recta(double x);
double func_ventana(double x);

double func_F1(double x);
double func_F2(double x);



#endif
