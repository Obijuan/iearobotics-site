/************************************************************************/
/* video.h       Sep-2000                                               */
/*----------------------------------------------------------------------*/
/* Definiciones y prototipos del modulo video.c                         */
/************************************************************************/

#ifndef _VIDEO_H
#define _VIDEO_H

#include <glib.h>
#include <gtk/gtk.h>

/*-----------------------------*/
/*  PROTOTIPOS  DEL INTERFAZ   */
/*-----------------------------*/

GtkWidget *video_init();
void video_origenx_inc(int inc);
void video_origeny_inc(int inc);
void video_origen_reset();
void video_refrescar();
void video_set_func_draw(double (*func)(double));
void video_set_art_activa(int nart);
void video_show_ejex(gboolean dibujar);
void video_show_func(gboolean dibujar);
void video_show_cube(gboolean dibujar);

#endif
