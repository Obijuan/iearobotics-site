/************************************************************************/
/* func.c       Sep-2000                                                */
/*----------------------------------------------------------------------*/
/* Modulo para la generacion y manipulacion de funciones matematicas    */
/*  para utilizarlas como ondas de desplazamiento.                      */
/************************************************************************/

#include <math.h>
#include "func.h"

#define PI 3.1416
#define AMPLITUD_INICIAL  50
#define LONG_ONDA_INICIAL 140
#define INSTANTE_INICIAL  0
#define FREC_INICIAL      2
#define PENDIENTE_INICIAL 1


/*-------------------------------*/
/* PARAMETROS DE LAS FUNCIONES   */
/*-------------------------------*/

/* AMPLITUD */
static double amplitud = AMPLITUD_INICIAL;

/* LONGITUD DE ONDA */
static double long_onda= LONG_ONDA_INICIAL;

/* TIEMPO  */
static double tiempo   = INSTANTE_INICIAL;

/* FRECUENCIA */
/* Numero de ondas que pasan por un punto en la unidad de tiempo */
static double frec     = FREC_INICIAL;

/* Anchura de la funcion ventana */
static double anchura  = LONG_ONDA_INICIAL/2;

/* Pendiente de la funcion recta  */
static double pendiente = PENDIENTE_INICIAL;

/*-----------------------------------------------*/
/* FUNCIONES DE MODIFICACION DE LOS PARAMETROS   */
/*-----------------------------------------------*/

void func_amplitud_set(double amp)
/**************************************/
/* Establecer la amplitud de la onda  */
/**************************************/
{
  amplitud=amp;
}

void func_long_onda_set(double lamda)
/***************************************/
/* Establecer la longitud de onda      */
/***************************************/
{
  long_onda=lamda;
}

void func_tiempo_set(double time)
/***************************************/
/* Establecer el parametro tiempo      */
/***************************************/
{
  tiempo=time;
}

void func_frec_set(double frecuencia)
/***************************************/
/* Establecer el parametro frecuencia  */
/***************************************/
{
  frec=frecuencia;
}

double func_periodo_get()
/******************************************************************/
/* Obtener el periodo temporal, a partir de los otros parametros  */
/******************************************************************/
{
  return long_onda/frec;
}

/*--------------------------------------------------*/
/*     F U N C I O N E S   D E   C O N T O R N O    */
/*--------------------------------------------------*/

double func_onda_sinusoidal(double x)
/*****************************************************/
/* Onda sinusoidal, con los parametros:              */
/*                                                   */
/*  Amplitud, long_onda, frec, tiempo                */
/*****************************************************/
{
  double y;
  double periodo;
  
  periodo = long_onda/frec;
  
  y = amplitud*sin(2*PI*(x/long_onda - tiempo/periodo));
  return y;
}

double func_ventana(double x)
/**********************************/
/* Funcion ventana. Parametros:   */
/*                                */
/* Anchura, tiempo                */
/**********************************/
{
  double xi,xs;
  double velocidad;
  
  
  velocidad = long_onda*frec;
  
  xi=frec*tiempo;
  xs=xi+anchura;
  
  if (x<xi || x>xs) return 0;
  
  return 1;
}

double func_signo(double x)
/******************************************************************************/
/* Funcion SIGNO. Se utiliza para recortar la parte negativa de otra funcion  */
/* Se utiliza componiendola con otra funcion.                                 */
/******************************************************************************/
{
  return (x>0) ? x : 0;
}

double func_nula(double x)
/**********************************************************/
/* FUNCION NULA. Devuelve cero para cualquier valor de x  */
/**********************************************************/
{
  return 0;
}

double func_recta(double x)
/*********************************/
/* FUNCION RECTA. Parametros:    */
/*                               */
/* pendiente.                    */
/*********************************/
{
  return x*pendiente;
}

double func_F1(double x)
/****************************************************/
/* FUNCION DE CONTORNO 1.                           */
/*                                                  */
/* Onda sinusoidal con la parte negativa recortada  */
/****************************************************/
{
  return func_signo(func_onda_sinusoidal(x));
}

double func_F2(double x)
/****************************************************/
/* FUNCION DE CONTORNO 2                            */
/*                                                  */
/* Onda sinusoidal vista a traves de una ventana    */
/****************************************************/
{
  return func_onda_sinusoidal(x)*func_ventana(x);
}



