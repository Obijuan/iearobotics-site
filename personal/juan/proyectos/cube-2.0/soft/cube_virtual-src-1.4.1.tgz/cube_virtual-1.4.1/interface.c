/****************************************************************************/
/* interface.c   Juan Gonzalez Gomez.  Octubre 2000                        */
/*--------------------------------------------------------------------------*/
/* Dibujo del interfaz.                                                     */
/****************************************************************************/

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "gtkutils.h"
#include "interface.h"
#include "retrollamada.h"
#include "video.h"

/*-------------------------*/
/*      I C O N O S        */
/*-------------------------*/

/* Barra de herramientas superior */
#include "spain.xpm"
#include "disco.xpm"
#include "stop.xpm"
#include "tux.xpm"

/* Barra de herramientas inferior */
#include "f_der.xpm"
#include "f_izq.xpm"
#include "f_up.xpm"
#include "f_down.xpm"

static void crear_tool_bar(GtkWidget *vbox_main)
/****************************************/
/* Crear la barra de herramientas       */
/****************************************/
{
  GtkWidget *toolbar;
  GtkWidget *element;

  /* Crear barra de herramientas y añadirla a la ventana */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_box_pack_start(GTK_BOX(vbox_main),toolbar,FALSE,TRUE,0);
  gtk_widget_show(toolbar);
  
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) spain_xpm);
  
  /* Añadir un elemento a la barra de herramientas */
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","prueba","prueba",
                              element, 
                              (GtkSignalFunc) prueba,NULL);
                                     
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) disco_xpm);                                   
  /* Añadir un elemento a la barra de herramientas */                                   
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba2","prueba2","prueba2",
                               element, 
                               (GtkSignalFunc) prueba,NULL);
                                     
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) stop_xpm);                                   
  /* Añadir un elemento a la barra de herramientas */                                   
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba3","prueba3","prueba3",
                              element, 
                              (GtkSignalFunc) prueba,NULL);
                                     
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) tux_xpm);                                   
  /* Añadir un elemento a la barra de herramientas */                                   
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba4","prueba4","prueba4",
                              element, 
                              (GtkSignalFunc) prueba,NULL);
  element = gtk_label_new("About");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "about","Sobre cube-virtual","about",
                              element, 
                              (GtkSignalFunc) prueba,NULL);                            
                                     
}

static GtkWidget *crear_item_menu(main_state_t *estado,GtkWidget *menu, char *nombre,char *accel, 
                                  char *tip, GtkSignalFunc func,gpointer data)
/****************************************************************************/
/* Crear un elemento y colocarlo en el menu                                 */
/*                                                                          */
/*  ENTRADA:                                                                */
/*     - Estado del interfaz                                                */
/*     - Menu donde situar la nueva opcion                                  */
/*     - Nombre de la opcion de menu                                        */
/*     - Tecla de aceleracion                                               */
/*     - Sugerencia                                                         */
/*     - Funcion de retrollamada, llamada cuando el usuario elije la opcion */
/*     - Datos a pasar a la funcion de retrollamada                         */
/*                                                                          */
/*  DEVUELVE:                                                               */
/*     - Widget de item de menu                                             */
/****************************************************************************/       
{
  GtkWidget *menuitem;
  
  /* Si el menu tiene nombre ... */
  if (nombre && strlen(nombre)) {
    menuitem = gtk_menu_item_new_with_label(nombre);
    gtk_signal_connect(GTK_OBJECT(menuitem), "activate", 
                       GTK_SIGNAL_FUNC(func), data);
  }
  else {
    /* -- Crear un separador -- */
    menuitem = gtk_menu_item_new();
  }
  
  /* -- Añadir elemento de menu y mostrarlo -- */
  gtk_menu_append (GTK_MENU(menu), menuitem);
  gtk_widget_show (menuitem);
  
  /* Cadena de aceleracion */
  

  
  if (estado->accel_group == NULL) {
    estado->accel_group = gtk_accel_group_new();
    gtk_accel_group_attach (estado->accel_group, GTK_OBJECT (estado->win_main));
  }
  

  
  if (accel && accel[0]=='^') {
    gtk_widget_add_accelerator (menuitem, "activate",estado->accel_group, accel[1], 
                                GDK_CONTROL_MASK,
                                GTK_ACCEL_VISIBLE);
  }

  /* Sugerencias */
  if (tip && strlen(tip)) {
    gtk_tooltips_set_tip (estado->sugerencias, menuitem, tip, NULL);
  }
  
  return (menuitem);
}

void create_window1 (main_state_t *estado)
/*********************************/
/* Crear el interfaz principal   */
/*********************************/
{
  int i;
  GtkWidget *vbox_main;
  GtkWidget *drawing_area;
  GtkWidget *menubar;
  GtkWidget *menu;
  GtkWidget *menuitem;
  GtkWidget *hbox1;
  GtkWidget *toolbar1;
  GtkWidget *radiobutton1;
  GtkWidget *radiobutton2;
  GtkWidget *label1;
  GtkWidget *flecha;
  GtkWidget *table;
  GtkWidget *frame;
  GtkWidget *vbox;
  GtkWidget *lcd;
  GtkWidget *pot1;
  GtkObject *adj1;
  GtkObject *amp_adj;   /* Amplitud          */
  GtkObject *lamda_adj; /* Longitud de onda  */
  GtkObject *time_adj;  /* Tiempo            */
  GtkObject *frec_adj;  /* Frecuencia        */
  GtkWidget *toolbar;
  GtkWidget *element;
  GtkWidget *label;
  GtkWidget *radiobutton;
  GtkWidget *radiobutton3;
  GtkWidget *radiobutton4;
  GtkWidget *radiobutton5;
  GtkWidget *radiobutton6;
  GtkWidget *amp_lcd;
  GtkWidget *lamda_lcd;
  GtkWidget *time_lcd;
  GtkWidget *frec_lcd;
  GtkWidget *toggle_ejex;
  GtkWidget *toggle_func;
  GtkWidget *toggle_cube;
  GtkWidget *toggle_enganche;
  GtkWidget *lcd_grados[6];
  GtkWidget *lcd_x[6];
  GtkWidget *lcd_y[6];
  GtkObject *a_adj[4];
  GtkWidget *vector_lcd[4];
  GtkWidget *sentido[4];

  /*  Crear ventana superior */
  estado->win_main = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  
  /* No permitir que se redimensione la ventana... */
  gtk_window_set_policy(GTK_WINDOW(estado->win_main), FALSE, FALSE, TRUE);
  
  /* Titulo */
  gtk_window_set_title (GTK_WINDOW(estado->win_main), "CUBE-VIRTUAL");
  gtk_container_border_width(GTK_CONTAINER(estado->win_main),0);
  
  /* Crear vbox */
  vbox_main=gtk_vbox_new(FALSE,0);
  
  /* Colocar vbox */
  gtk_container_add(GTK_CONTAINER(estado->win_main), vbox_main);
  
  gtk_widget_show(vbox_main);
  gtk_widget_show(estado->win_main);
 
  /* ....Barra de menu.... */
  menubar = gtk_menu_bar_new();
  gtk_box_pack_start(GTK_BOX(vbox_main), menubar, FALSE, TRUE, 0);
  gtk_widget_show(menubar);
  
  /*-----------------*/
  /*  MENU FILE      */
  /*-----------------*/
  menu = gtkutils_crear_submenu_bar(menubar,"File");
  menuitem = crear_item_menu(estado,menu,"Quit  ","^Q","Salir del programa",
                             GTK_SIGNAL_FUNC(file_quit), "quit");                              
  /*-----------------------*/
  /* BARRA DE HERRAMIENTAS */
  /*-----------------------*/
  crear_tool_bar(vbox_main);
  
  /*-----------------------*/
  /* CREAR AREA DE DIBUJO  */
  /*-----------------------*/
  drawing_area=video_init();

  /* --- Añadir area de dibujo al empaquetado --- */
  gtk_box_pack_start(GTK_BOX (vbox_main), drawing_area, TRUE, TRUE, 0);


  /*----------------------------------*/
  /* BARRA DE HERRAMIENTAS INFERIOR 1 */
  /*----------------------------------*/
  /* Crear barra de herramientas y añadirla a la ventana */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar),0);
  gtk_box_pack_start(GTK_BOX(vbox_main), toolbar,FALSE,TRUE,0);
  gtk_widget_show(toolbar);
  
  /*---------------------------------------*/
  /* FLECHAS DE DESPLAZAMIENTO DEL ORIGEN  */
  /*---------------------------------------*/
  
  /* FLECHA DERECHA */
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) f_der_xpm);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Desplazar el origen a la derecha","prueba",
                              element, 
                              (GtkSignalFunc) main_boton,"1");
  
  /* FLECHA IZQUIERDA */                            
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) f_izq_xpm);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Desplazar el origen a la izquierda","prueba",
                              element, 
                              (GtkSignalFunc) main_boton,"2");
  
  /* FLECHA ARRIBA */                            
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) f_up_xpm);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Desplazar el origen arriba","prueba",
                              element, 
                              (GtkSignalFunc) main_boton,"3");
  /* FLECHA ABAJO */                              
  element=gtkutils_crear_widget_from_xpm(vbox_main, (gchar **) f_down_xpm);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Desplazar el origen abajo","prueba",
                              element, 
                              (GtkSignalFunc) main_boton,"4");
                           
  /*--------------------*/                            
  /* AÑADIR SEPARACION  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));

  /*---------------------------------------*/
  /* BOTONES DE SELECCION DE ARTICULACION  */
  /*---------------------------------------*/

  label = gtk_label_new("1");
  radiobutton= gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                                           NULL,
                                           "prueba","Articulacion 1","prueba",
                                           label, 
                                           (GtkSignalFunc) toggle_boton,"5");
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton), TRUE);
  gtk_toggle_button_set_mode (GTK_TOGGLE_BUTTON (radiobutton), FALSE);

  label = gtk_label_new("2");  
  radiobutton2=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                              radiobutton,
                              "prueba","Articulacion 2","prueba",
                              label, 
                              (GtkSignalFunc) toggle_boton,"6");
  gtk_toggle_button_set_mode (GTK_TOGGLE_BUTTON (radiobutton2), FALSE);
  
  label = gtk_label_new("3");
  radiobutton3=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                              radiobutton2,
                              "prueba","Articulacion 3","prueba",
                              label, 
                              (GtkSignalFunc) toggle_boton,"7");

  label = gtk_label_new("4");                              
  radiobutton4=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                              radiobutton3,
                              "prueba","Articulacion 4","prueba",
                              label, 
                              (GtkSignalFunc) toggle_boton,"8");
                              
  label = gtk_label_new("5");
  radiobutton5=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                              radiobutton4,
                              "prueba","Articulacion 5","prueba",
                              label, 
                              (GtkSignalFunc) toggle_boton,"9");
                              

  label = gtk_label_new("6");
  radiobutton6=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_RADIOBUTTON,
                              radiobutton5,
                              "prueba","Articulacion 6","prueba",
                              label, 
                              (GtkSignalFunc) toggle_boton,"10");
                              
  /*--------------------*/                            
  /* AÑADIR SEPARACION  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));

  /*----------------------------------------------------------*/
  /* FLECHAS DE MOVIMIENTO DE CUBE                            */
  /*----------------------------------------------------------*/
  flecha=gtk_arrow_new(GTK_ARROW_UP,GTK_SHADOW_OUT);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Aumentar angulo","prueba",
                              flecha, 
                              (GtkSignalFunc) main_boton,"11");
                              
  flecha=gtk_arrow_new(GTK_ARROW_DOWN,GTK_SHADOW_OUT);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Disminuir angulo","prueba",
                              flecha, 
                              (GtkSignalFunc) main_boton,"12");
                              
  flecha=gtk_arrow_new(GTK_ARROW_LEFT,GTK_SHADOW_OUT);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Aumentar angulo","prueba",
                              flecha, 
                              (GtkSignalFunc) main_boton,"13");
                              
  flecha=gtk_arrow_new(GTK_ARROW_RIGHT,GTK_SHADOW_OUT);
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Disminuir angulo","prueba",
                              flecha, 
                              (GtkSignalFunc) main_boton,"14");                              
                              
  /*--------------------*/                            
  /* AÑADIR SEPARACION  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));                            
                              
  /*----------------------------------------------*/
  /* AÑADIR BOTON DE INFORMACION DE ARTICULACION  */                            
  /*----------------------------------------------*/
  label = gtk_label_new("I");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Ver datos de la articulacion","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"15");
                              
  /*------------------------*/
  /* AÑADIR BOTON DE RESET  */                            
  /*------------------------*/
  label = gtk_label_new("R");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Reset de las articulaciones","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"16");
  
  /*-----------------------------------*/
  /* BARRA DE HERRAMIENTAS INFERIOR 2  */
  /*-----------------------------------*/
    
  /* Crear barra de herramientas y añadirla a la ventana */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar),0);
  gtk_box_pack_start(GTK_BOX(vbox_main),toolbar,FALSE,TRUE,0);
  gtk_widget_show(toolbar);
  
  label = gtk_label_new("Error");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Ver error de ajuste de la articulacion activa","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"20");
                              
  label = gtk_label_new("Aprox");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Aproximar la articulacion activa a la funcion contorno","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"21");
                              
  label = gtk_label_new("Ang ini");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Calcular anguno inicial de primera aproximacion","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"22");
                              
  label = gtk_label_new("Ajustar");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Ajustar Cube a la funcion contorno","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"23");
                              
  /*--------------------*/                            
  /* AÑADIR SEPARACION  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
                              
                              
  /*-------------------------------------------------*/                              
  /* BOTONES TOGGLE PARA ACTIVAR/DESACTIVAR OPCIONES */
  /*-------------------------------------------------*/                             
  label = gtk_label_new("Eje X");
  toggle_ejex=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                         NULL,
                                         "prueba","Eje X ON/OFF","prueba",
                                          label, 
                                          (GtkSignalFunc) toggle_boton,"26");
                                          
  label = gtk_label_new("Func");
  toggle_func=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                         NULL,
                                         "prueba","Funcion de contorno ON/OFF","prueba",
                                          label, 
                                          (GtkSignalFunc) toggle_boton,"27");
                                          
  label = gtk_label_new("Cube");
  toggle_cube=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                         NULL,
                                         "prueba","Cube ON/OFF","prueba",
                                          label, 
                                          (GtkSignalFunc) toggle_boton,"28");
    
  /*-----------------------------------*/
  /* BARRA DE HERRAMIENTAS INFERIOR 3  */
  /*-----------------------------------*/
  
  
  /* Crear barra de herramientas y añadirla a la ventana */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar),0);
  gtk_box_pack_start(GTK_BOX(vbox_main),toolbar,FALSE,FALSE,0);
  gtk_widget_show(toolbar);
  
  label = gtk_label_new("F1");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Seleccionar funcion 1","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"30");
                              
  label = gtk_label_new("F2");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Seleccionar funcion 2","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"31");
  
  label = gtk_label_new("F3");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Seleccionar funcion 3","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"32");
                              
  /*--------------------*/                            
  /* AÑADIR SEPARACION  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));

  /*--------------------------------------------------------*/
  /* ENTRADAS DE MANIPULACION DE PARAMETROS DE LA FUNCION   */
  /*--------------------------------------------------------*/
  
  /*--- AMPLITUD ---*/
  amp_adj = gtk_adjustment_new (0,0,200, 1, 1, 1);
  amp_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (amp_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(amp_lcd),5);
  gtk_widget_show(amp_lcd);                           
  gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_WIDGET,
                             amp_lcd, "prueba","Modificar amplitud","prueba",
                             NULL,NULL,NULL);
  
  /* -- SEPARACION --*/    
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
                          
  /*--- LONGITUD DE ONDA ---*/                           
  lamda_adj = gtk_adjustment_new (0,0,400, 1, 1, 1);
  lamda_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (lamda_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(lamda_lcd),5);
  gtk_widget_show(lamda_lcd);                           
  gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_WIDGET,
                             lamda_lcd, "prueba","Modificar longitud de onda","prueba",
                             NULL,NULL,NULL);
                             
  /* -- SEPARACION --*/    
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
                             
  /*--- TIEMPO ---*/                           
  time_adj = gtk_adjustment_new (0,0,400, 1, 1, 1);
  time_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (time_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(time_lcd),5);
  gtk_widget_show(time_lcd);                           
  gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_WIDGET,
                             time_lcd, "prueba","Modificar longitud de onda","prueba",
                             NULL,NULL,NULL);
                             
  /* -- SEPARACION --*/    
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
                             
  /*--- FRECUENCIA ---*/                           
  frec_adj = gtk_adjustment_new (0,0,200, 1, 1, 1);
  frec_lcd = gtk_spin_button_new (GTK_ADJUSTMENT (frec_adj), 1, 0);
  gtk_entry_set_max_length(GTK_ENTRY(frec_lcd),5);
  gtk_widget_show(frec_lcd);
  gtk_toolbar_append_element(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_WIDGET,
                             frec_lcd, "prueba","Modificar frecuencia","prueba",
                             NULL,NULL,NULL);
                             
  /* -- SEPARACION --*/    
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar));
  
  /* -- Botones --- */
  label = gtk_label_new("Play");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","reproducir movimiento","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"34");
                              
  /* -- Boton de grabar --- */
  label = gtk_label_new("Grabar");
  gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              "prueba","Grabar movimiento","prueba",
                              label, 
                              (GtkSignalFunc) main_boton,"35");
  
  
  /*-----------------------------------------------------*/
  /* POTENCIOMETROS DE MOVIMIENTO DE LAS ARTICULACIONES  */
  /*-----------------------------------------------------*/
  /* Cuadro de empaquetado horizontal para situar el potenciometro, el cuadro */
  /* de dialogo y los botones de sentido de la actualizacion                  */
  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox_main), hbox1, FALSE, FALSE, 0);

  /* Crear potenciometro */
  adj1 = gtk_adjustment_new(0,-90,91,1,1,1);
  pot1 = gtk_hscrollbar_new (GTK_ADJUSTMENT(adj1));
    gtk_widget_set_usize (pot1, 150, 30);
  gtk_widget_show (pot1);
  gtk_box_pack_start (GTK_BOX (hbox1), pot1, FALSE, FALSE, 0);
  gtk_range_set_update_policy(GTK_RANGE(pot1),GTK_UPDATE_CONTINUOUS);
  

  /* Crear botones de sentido de actualizacion */
  toolbar1 = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);
  gtk_widget_show (toolbar1);
  gtk_box_pack_start (GTK_BOX (hbox1), toolbar1, FALSE, FALSE, 0);
  flecha=gtk_arrow_new(GTK_ARROW_LEFT,GTK_SHADOW_OUT);
  radiobutton1 = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_RADIOBUTTON,
                                NULL,
                                NULL,
                                NULL, NULL,
                                flecha, (GtkSignalFunc)toggle_boton,"40");
                              /*  (GtkSignalFunc) toggle_boton*/
  gtk_widget_show (radiobutton1);
  gtk_toggle_button_set_mode (GTK_TOGGLE_BUTTON (radiobutton1), FALSE);

  flecha=gtk_arrow_new(GTK_ARROW_RIGHT,GTK_SHADOW_OUT);
  radiobutton2 = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_RADIOBUTTON,
                                radiobutton1,
                                NULL,
                                NULL, NULL,
                                flecha, (GtkSignalFunc)toggle_boton,"41");
  gtk_widget_show (radiobutton2);
  gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON (radiobutton2), TRUE);
  gtk_toggle_button_set_mode (GTK_TOGGLE_BUTTON (radiobutton2), FALSE);
  
  /*--------------------*/
  /* Añadir separacion  */
  /*--------------------*/
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar1));
  gtk_toolbar_append_space(GTK_TOOLBAR(toolbar1));
  
  label1 = gtk_label_new("Enganchar");
  toggle_enganche=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar1), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                         NULL,
                                         NULL,"Enganchar cube",NULL,
                                         label1, 
                                         (GtkSignalFunc) toggle_boton,"33");
  
  /*--------------------------------------*/
  /*------- VENTANA CON LOS LCD'S ------- */
  /*--------------------------------------*/
  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox_main), hbox1, TRUE, TRUE, 0);
  
  table = gtk_table_new(4,7,FALSE);
  gtk_widget_show(table);
  gtk_box_pack_start(GTK_BOX(hbox1), table, FALSE, FALSE, 0);
  
  label1 = gtk_label_new("Art 1");
  gtk_table_attach(GTK_TABLE(table), label1,1,2,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Art 2");
  gtk_table_attach(GTK_TABLE(table), label1,2,3,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Art 3");
  gtk_table_attach(GTK_TABLE(table), label1,3,4,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Art 4");
  gtk_table_attach(GTK_TABLE(table), label1,4,5,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Art 5");
  gtk_table_attach(GTK_TABLE(table), label1,5,6,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Art 6");
  gtk_table_attach(GTK_TABLE(table), label1,6,7,0,1,GTK_FILL,GTK_FILL,5,0);
  gtk_widget_show(label1);
  
  label1 = gtk_label_new("Grados: ");
  gtk_widget_show(label1);
  gtk_table_attach_defaults(GTK_TABLE(table), label1,0,1,1,2);
  
  label1 = gtk_label_new("X: ");
  gtk_widget_show(label1);
  gtk_table_attach_defaults(GTK_TABLE(table), label1,0,1,2,3);
  
  label1 = gtk_label_new("Y: ");
  gtk_widget_show(label1);
  gtk_table_attach_defaults(GTK_TABLE(table), label1,0,1,3,4);
  
  /* Art 1 */
  lcd_grados[0] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[0]);
  gtk_widget_set_usize (lcd_grados[0], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[0]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[0]), "-90");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[0],1,2,1,2,GTK_FILL,GTK_FILL,5,0);
  
  /* Art 2 */
  lcd_grados[1] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[1]);
  gtk_widget_set_usize (lcd_grados[1], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[1]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[1]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[1],2,3,1,2,GTK_FILL,GTK_FILL,5,0);
  
  /* Art 3 */
  lcd_grados[2] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[2]);
  gtk_widget_set_usize (lcd_grados[2], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[2]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[2],3,4,1,2,GTK_FILL,GTK_FILL,5,0);
  
  /* Art 4 */
  lcd_grados[3] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[3]);
  gtk_widget_set_usize (lcd_grados[3], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[3]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[3]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[3],4,5,1,2,GTK_FILL,GTK_FILL,5,0);
 
  /* Art 5 */
  lcd_grados[4] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[4]);
  gtk_widget_set_usize (lcd_grados[4], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[4]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[4]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[4],5,6,1,2,GTK_FILL,GTK_FILL,5,0);

  /* Art 6 */
  lcd_grados[5] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (lcd_grados[5]);
  gtk_widget_set_usize (lcd_grados[5], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_grados[5]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_grados[5]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_grados[5],6,7,1,2,GTK_FILL,GTK_FILL,5,0);
  
  /* Art 1 */
  lcd_x[0] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[0]);
  gtk_widget_set_usize (lcd_x[0], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[0]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[0]), "-100");
  gtk_table_attach(GTK_TABLE(table), lcd_x[0],1,2,2,3,GTK_FILL,GTK_FILL,5,0);
  
   /* Art 2 */
  lcd_x[1] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[1]);
  gtk_widget_set_usize (lcd_x[1], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[1]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[1]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_x[1],2,3,2,3,GTK_FILL,GTK_FILL,5,0);  
  
   /* Art 3 */
  lcd_x[2] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[2]);
  gtk_widget_set_usize (lcd_x[2], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[2]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_x[2],3,4,2,3,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 4 */
  lcd_x[3] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[3]);
  gtk_widget_set_usize (lcd_x[3], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[3]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_x[3],4,5,2,3,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 5 */
  lcd_x[4] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[4]);
  gtk_widget_set_usize (lcd_x[4], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[4]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[4]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_x[4],5,6,2,3,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 6 */
  lcd_x[5] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_x[5]);
  gtk_widget_set_usize (lcd_x[5], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_x[5]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_x[5]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_x[5],6,7,2,3,GTK_FILL,GTK_FILL,5,0);
  
  
  /*---- LCD COORDENADA Y ----- */
  
  /* Art 1 */
  lcd_y[0] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[0]);
  gtk_widget_set_usize (lcd_y[0], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[0]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[0]), "-100");
  gtk_table_attach(GTK_TABLE(table), lcd_y[0],1,2,3,4,GTK_FILL,GTK_FILL,5,0);
  
   /* Art 2 */
  lcd_y[1] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[1]);
  gtk_widget_set_usize (lcd_y[1], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[1]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[1]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_y[1],2,3,3,4,GTK_FILL,GTK_FILL,5,0);  
  
   /* Art 3 */
  lcd_y[2] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[2]);
  gtk_widget_set_usize (lcd_y[2], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[2]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_y[2],3,4,3,4,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 4 */
  lcd_y[3] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[3]);
  gtk_widget_set_usize (lcd_y[3], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[3]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_y[3],4,5,3,4,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 5 */
  lcd_y[4] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[4]);
  gtk_widget_set_usize (lcd_y[4], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[4]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[4]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_y[4],5,6,3,4,GTK_FILL,GTK_FILL,5,0);  
  
  /* Art 6 */
  lcd_y[5] = gtk_entry_new_with_max_length(4);
  gtk_widget_show (lcd_y[5]);
  gtk_widget_set_usize (lcd_y[5], 40, -2);
  gtk_entry_set_editable (GTK_ENTRY (lcd_y[5]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (lcd_y[5]), "0");
  gtk_table_attach(GTK_TABLE(table), lcd_y[5],6,7,3,4,GTK_FILL,GTK_FILL,5,0);
  
  /* ----- MARCO PARA CONVERSION DE CUBE-VIRTUAL A CUBE-FISICO ----- */
  frame = gtk_frame_new("Conversiones");
  gtk_widget_show(frame);
  gtk_box_pack_start(GTK_BOX(vbox_main), frame, TRUE, TRUE, 0);
  
  /* Crear caja vertical  */
  vbox=gtk_vbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(frame), vbox);
  gtk_widget_show(vbox);
  
  /* ------cuadros de dialogo de offset -------*/
  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox), hbox1, TRUE, TRUE, 0);
  
  label1 = gtk_label_new("Offset: ");
  gtk_widget_show(label1);
  gtk_box_pack_start (GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
  
  a_adj[0] = gtk_adjustment_new(0,-90,90,1,1,1);
  lcd = gtk_spin_button_new (GTK_ADJUSTMENT (a_adj[0]), 1, 0);  
  gtk_box_pack_start(GTK_BOX(hbox1), lcd, FALSE, FALSE, 0);
  gtk_widget_show(lcd);
  
  a_adj[1] = gtk_adjustment_new(0,-90,90,1,1,1);
  lcd = gtk_spin_button_new (GTK_ADJUSTMENT (a_adj[1]), 1, 0);  
  gtk_box_pack_start(GTK_BOX(hbox1), lcd, FALSE, FALSE, 0);
  gtk_widget_show(lcd);
  
  a_adj[2] = gtk_adjustment_new(0,-90,90,1,1,1);
  lcd = gtk_spin_button_new (GTK_ADJUSTMENT (a_adj[2]), 1, 0);  
  gtk_box_pack_start(GTK_BOX(hbox1), lcd, FALSE, FALSE, 0);
  gtk_widget_show(lcd);
  
  a_adj[3] = gtk_adjustment_new(0,-90,90,1,1,1);
  lcd = gtk_spin_button_new (GTK_ADJUSTMENT (a_adj[3]), 1, 0);  
  gtk_box_pack_start(GTK_BOX(hbox1), lcd, FALSE, FALSE, 0);
  gtk_widget_show(lcd);
  
  /*-- Sentido ---*/
  label1 = gtk_label_new("Sentido: ");
  gtk_widget_show(label1);
  gtk_box_pack_start (GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
  
  sentido[0] = gtk_check_button_new_with_label("1");
  gtk_widget_show(sentido[0]);
  gtk_box_pack_start(GTK_BOX(hbox1), sentido[0], FALSE, FALSE, 0);
  
  sentido[1] = gtk_check_button_new_with_label("2");
  gtk_widget_show(sentido[1]);
  gtk_box_pack_start(GTK_BOX(hbox1), sentido[1], FALSE, FALSE, 0);
  
  sentido[2] = gtk_check_button_new_with_label("3");
  gtk_widget_show(sentido[2]);
  gtk_box_pack_start(GTK_BOX(hbox1), sentido[2], FALSE, FALSE, 0);
  
  sentido[3] = gtk_check_button_new_with_label("4");
  gtk_widget_show(sentido[3]);
  gtk_box_pack_start(GTK_BOX(hbox1), sentido[3], FALSE, FALSE, 0);
  
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(sentido[1]),TRUE);
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(sentido[2]),TRUE);
  
  /*-- Vector para cube-fisico  ---*/
  hbox1 = gtk_hbox_new (FALSE, 3);
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox), hbox1, TRUE, TRUE, 0);
  
  label1 = gtk_label_new("Vector de posicion fisico: ");
  gtk_widget_show(label1);
  gtk_box_pack_start (GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
  
  vector_lcd[0] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (vector_lcd[0]);
  gtk_widget_set_usize (vector_lcd[0], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (vector_lcd[0]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (vector_lcd[0]), "-90");
  gtk_box_pack_start (GTK_BOX(hbox1), vector_lcd[0], FALSE, FALSE, 0);
  
  vector_lcd[1] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (vector_lcd[1]);
  gtk_widget_set_usize (vector_lcd[1], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (vector_lcd[1]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (vector_lcd[1]), "-90");
  gtk_box_pack_start (GTK_BOX(hbox1), vector_lcd[1], FALSE, FALSE, 0);
  
  vector_lcd[2] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (vector_lcd[2]);
  gtk_widget_set_usize (vector_lcd[2], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (vector_lcd[2]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (vector_lcd[2]), "-90");
  gtk_box_pack_start (GTK_BOX(hbox1), vector_lcd[2], FALSE, FALSE, 0);
  
  vector_lcd[3] = gtk_entry_new_with_max_length(3);
  gtk_widget_show (vector_lcd[3]);
  gtk_widget_set_usize (vector_lcd[3], 30, -2);
  gtk_entry_set_editable (GTK_ENTRY (vector_lcd[3]), FALSE);
  gtk_entry_set_text (GTK_ENTRY (vector_lcd[3]), "-90");
  gtk_box_pack_start (GTK_BOX(hbox1), vector_lcd[3], FALSE, FALSE, 0);
  
  /*-------------------------------------------------*/
  /* Configuracion de las señales de retrollamada    */
  /*-------------------------------------------------*/

  /* Escucha de la señal de destruccion */
  gtk_signal_connect(GTK_OBJECT(estado->win_main),"destroy", GTK_SIGNAL_FUNC(main_destroy), NULL);
  
  /* Cambio en el potenciometro */
  gtk_signal_connect(adj1,"value_changed", GTK_SIGNAL_FUNC(pot_changed),"0");
  
  /*---- Cambio en algun parametro de la señal  ----*/                           
  gtk_signal_connect(amp_adj,"value_changed",GTK_SIGNAL_FUNC(valor_cambiado),"1");
  gtk_signal_connect(lamda_adj,"value_changed",GTK_SIGNAL_FUNC(valor_cambiado),"2");
  gtk_signal_connect(time_adj,"value_changed",GTK_SIGNAL_FUNC(valor_cambiado),"3");
  gtk_signal_connect(frec_adj,"value_changed",GTK_SIGNAL_FUNC(valor_cambiado),"4");

  /* ACTUALIZAR EL ESTADO GLOBAL */
  estado->adj1=adj1;
  estado->amp_adj=amp_adj;
  estado->lamda_adj=lamda_adj;
  estado->time_adj=time_adj;  
  estado->frec_adj=frec_adj;  
  estado->toggle_ejex=toggle_ejex;
  estado->toggle_func=toggle_func;
  estado->toggle_cube=toggle_cube;
  estado->toggle_enganche=toggle_enganche;
  
  for (i=0; i<6; i++) {
    estado->lcd_grados[i]=lcd_grados[i];
    estado->lcd_x[i]=lcd_x[i];
    estado->lcd_y[i]=lcd_y[i];
  }  
  
  for (i=0; i<4; i++) {
    estado->a_adj[i]=a_adj[i];
    estado->vector_lcd[i]=vector_lcd[i];
    estado->sentido[i]=sentido[i];
  }
    
}


