/*************************************************************************/
/* retrollamada.h   Juan Gonzalez Gomez.  Octubre 2000                   */
/*-----------------------------------------------------------------------*/
/* Prototipos de las funciones de retrollamada del interfaz              */
/*************************************************************************/

#ifndef _RETROLLAMADA_H
#define _RETROLLAMADA_H

#include <gtk/gtk.h>

gint main_destroy(GtkWidget *widget, gpointer gdata);
gint file_quit(GtkWidget *widget, gpointer gdata);
void pot_changed(GtkWidget *widget, gpointer gdata);
void main_boton(GtkWidget *widget, gpointer data);
void toggle_boton(GtkWidget *widget,gpointer data);
void valor_cambiado(GtkWidget *widget, gpointer data);
void prueba (GtkWidget *widget, gpointer data);


#endif  /* _RETROLLAMADA_H */
