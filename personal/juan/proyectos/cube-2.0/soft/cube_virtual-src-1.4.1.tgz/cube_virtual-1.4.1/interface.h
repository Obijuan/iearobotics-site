/********************************************************************/
/* interface.h  Juan Gonzalez Gomez.  Octubre 2000                  */
/*------------------------------------------------------------------*/
/* Prototipos y definiciones para el modulo interface.c             */
/********************************************************************/

#ifndef _INTERFACE_H
#define _INTERFACE_H

#include <gtk/gtk.h>

/*------------------------*/
/* ESTRUCTURAS DE DATOS   */
/*------------------------*/

/* -- Estado global del programa -- */
typedef struct main_state_s {
  GtkWidget *win_main;          /* Ventana principal */
  GtkTooltips *sugerencias;     /* Sugerencias        */
  GtkAccelGroup *accel_group;   /* Teclas aceleracion */
  GtkObject *adj1;              /* Valor asociado al potenciometro  */
  
  /*-- Valores de los diferentes parametros de la onda -- */
  GtkObject *amp_adj;   /* Amplitud          */
  GtkObject *lamda_adj; /* Longitud de onda  */
  GtkObject *time_adj;  /* Tiempo            */
  GtkObject *frec_adj;  /* Frecuencia        */
  
  /* ---- Botones Toggle  ----- */
  GtkWidget *toggle_ejex;
  GtkWidget *toggle_func;
  GtkWidget *toggle_cube;
  GtkWidget *toggle_enganche;
  
  /* --- LCD's ---- */
  GtkWidget *lcd_grados[6];
  GtkWidget *lcd_x[6];
  GtkWidget *lcd_y[6];
  
  /*--- Valores para el vector de offset ---*/
  GtkObject *a_adj[4];

  /*--- Lcd para vectores fisicos ----*/
  GtkWidget *vector_lcd[4];

  /*--- Valores para los botones de sentido --*/
  GtkWidget *sentido[4];
  
} main_state_t;

/*----------------*/
/*  PROTOTIPOS    */
/*----------------*/
void create_window1 (main_state_t *estado);

#endif  /* _INTERFACE_H */


