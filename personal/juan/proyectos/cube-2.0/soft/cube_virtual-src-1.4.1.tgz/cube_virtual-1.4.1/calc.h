
/************************************************************************/
/* calc.h     Juan Gonzalez Gomez.    Octubre-2000                      */
/*----------------------------------------------------------------------*/
/* Definiciones y prototipos del modulo calc.c                          */
/************************************************************************/

#ifndef _CALC_H
#define _CALC_H

/*--------------------*/
/*   DEFINICIONES     */
/*--------------------*/
#define PI 3.1416

/*---------------------*/
/*    MACROS           */
/*---------------------*/
/* --- Convertir de radianes a grados --- */
#define TOGRADOS(X) (180 * X)/PI

/* --- Convertir de grados a radianes -- */
#define TORAD(X) (PI * X)/180

/* --- Devolver el signo de X --- */
#define SIGNO(X) (X>0) ? 1 : -1

/*----------------------------*/
/*    ESTRUCTURAS DE DATOS    */
/*----------------------------*/

/* Tipo punto en 2D */
typedef struct calc_punto2d_s {
  double x;
  double y;
} calc_punto2d_t;


/*-----------------------*/
/*    PROTOTIPOS         */
/*-----------------------*/

double calc_angulo(calc_punto2d_t centro, calc_punto2d_t extremo);
double calc_angulo_aprox(calc_punto2d_t centro, calc_punto2d_t extremo, double (*func_contorno)(double)); 
double calc_angulo_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo, double (*func_contorno)(double));
double calc_distancia(calc_punto2d_t p1, calc_punto2d_t p2);
void   calc_rotar_punto(calc_punto2d_t centro, calc_punto2d_t extremo,
                        double ang, calc_punto2d_t *rotado);
double calc_error_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo,
                         double (*funcion)(double));


#endif  /* _CALC_H */


