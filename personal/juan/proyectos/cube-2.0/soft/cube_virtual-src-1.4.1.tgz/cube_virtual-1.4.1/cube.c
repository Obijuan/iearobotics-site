/************************************************************************/
/* cube.c       Sep-2000                                                */
/*----------------------------------------------------------------------*/
/* Modulo de manipulacion de cube                                       */
/************************************************************************/

#include <stdio.h>
#include <glib.h>
#include <math.h>

#include "cube.h"
#include "video.h"
#include "func.h"
#include "calc.h"

/*------------------------------*/
/*   D E F I N I C I O N E S    */
/*------------------------------*/
#define LSEG 50   /* Longitud de los segmentos */

/*----------------------------------*/
/* VARIABLES GLOBALES DEL PROGRAMA  */
/*----------------------------------*/
GList *cube_cola = NULL;
static int    art_activa=0;      /* Articulacion activa */

/*------------------------------------------*/
/* V A R I A B L E S   D E L   M O D U L O  */
/*------------------------------------------*/
static double (*func_act)(double); /* Puntero a la funcion de contorno activa */


/***********************************************/
/*  Variables para definir el cube fisico      */
/***********************************************/

/* La variable sentido_fut determina el 'sentido' de como estan       */
/* colocados los Servos. Hay un elemento por cada Futaba en el gusano */
static int sentido_fut[]={1,1,1,1};

/* Definir la longitud de los segmentos del gusano. El numero de segmentos */
/* siempre es el de futaba + 1                                             */
static int long_seg[]={LSEG,LSEG,LSEG,LSEG,LSEG};

/*static int long_seg[]={50,30,35,30,50};*/ /* segmentos del cube real */


/*----------------------------------------------------------------*/
/*   P R O T O T I P O S   F U N C I O N E S   P R I V A D A S    */
/*----------------------------------------------------------------*/

/*--- FUNCIONES RELACIONADAS CON LA CREACION E INICIALIZACION ---*/
static void cube_generar();
static void cube_set_art(articulacion_t *art, int numero, int fi, 
                         double x, double y, int sentido);
static articulacion_t *cube_generar_art();

/*---- FUNCIONES RELACIONADAS CON LOS ANGULOS DE LAS ARTICULACIONES --*/
static double cube_articulacion_get_angulo(int num_art);
static double cube_articulacion_get_angulo_aprox(int num_art);

/*---- FUNCIONES RELACIONADAS CON LAS ROTACIONES DE ARTICULACIONES ---*/
static void cube_rotar_art(int centro, int extremo, double ang);

/*--------------------------------------------------------*/
/*      F U N C I O N E S   D E   I N T E R F A Z         */
/*--------------------------------------------------------*/

void cube_init()
/*********************************************************************/
/* Crear e inicializar las estructuras de datos necesarias para el   */ 
/* modulo.                                                           */
/*********************************************************************/
{
  art_activa=0;

  /* Generar la estructura de CUBE */
  cube_generar();
  
  /* Inicializar articulaciones */
  cube_inicializar_gusano();
  
  /* Establecer la funcion de contorno activa */
  func_act=func_onda_sinusoidal;
  video_set_func_draw(func_act);
}

int cube_long_get()
/*************************************/
/* Devolver la longitud del gusano   */
/*************************************/
{
  return g_list_length(cube_cola);
}

void cube_cola_get_xy(double *x,double *y)
/****************************************************/
/* Obtener las coordenadas x,y de la cola de cube   */
/****************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  
  /* Acceder a la articulacion de la cola */
  nodo = g_list_nth(cube_cola,0);
  art=nodo->data;
  
  *x=art->coord.x;
  *y=art->coord.y;
}

void cube_cola_set_xy(double x,double y)
/**************************************************************************/
/* Establecer las coordenadas x,y de la cola de cube. Automaticamente se  */
/* re-calculan las coordenadas de las demas articulaciones                */
/**************************************************************************/
{
  double xinc;
  double yinc;
  int nart;
  int i;
  articulacion_t *art;
  GList          *nodo;
  
  /* Acceder a la articulacion de la cola */
  nodo = g_list_nth(cube_cola,0);
  art=nodo->data;
  
  /* Calcular los incrementos a aplicar */
  xinc = x - art->coord.x;
  yinc = y - art->coord.y;
  
  art->coord.x=x;
  art->coord.y=y;
 
  /* Obtener longitud de cube */
  nart = cube_long_get();
  
  /* Recalcular las coordenadas de las articulaciones */
  for (i=1; i<nart; i++) {
    /* Acceder a la articulacion */
    nodo = g_list_nth(cube_cola,i);
    art=nodo->data;

    /* Aplicar incremento */
    art->coord.x+=xinc;
    art->coord.y+=yinc;
  }
  
}


void cube_func_contorno_set(double (*func_contorno)(double))
/*********************************************/
/* Establecer la funcion de contorno activa  */
/*********************************************/
{
  /* Actualizar variable global del modulo */
  func_act = func_contorno;
  
  /* Establecer la funcion que se dibuja */
  video_set_func_draw(func_act);
}

void cube_rotar(int centro, int ang, int sentido)
/*******************************************************************/
/* Rotar el gusano entero respecto a la articulacion especificada  */
/* Se actualiza de izquierda a derecha, o de derecha a izda segun  */
/* el valor del parametro sentido.                                 */
/*                                                                 */
/*  ENTRADA:                                                       */
/*    -centro : Articulacion centro                                */
/*    -ang    : Angulo a girar.                                    */
/*    -sentido: Que parte rotar: DERECHA o IZQUIERDA               */
/*                                                                 */
/*  La rotacion SE PROPAGA desde la articulacion centro hasta uno  */
/*  de los extremos.                                               */
/*                                                                 */
/*  El angulo de posicion de la articulacion centro se incrementa  */
/*  (o decrementa) en el angulo rotado.                            */
/*******************************************************************/
{
  int n;
  int i;
  articulacion_t *art;
  GList          *nodo;

  /* Obtener la articulacion centro */
  nodo = g_list_nth(cube_cola,centro);
  art=nodo->data;

  /* Modificar el angulo de posicion de la articulacion */
  art->fi= (art->fi + ang) % 360;
  
  /* ¡¡RESTRICCION!! El angulo de posicion debe estar comprendido */
  /* entre -90 y 90 grados. Si se sobrepasa hay que recortar      */
  
  if (art->fi>90) {
    /* Calcular angulo de giro para que no se sobrepasen los 90 grados */
    ang -= (art->fi - 90);
    art->fi=90;
  }  
  if (art->fi<-90) {
    /* Calcular angulo de giro para no sobrepasar los -90 grados */
    ang += (ABS(art->fi) - 90);
    art->fi=-90;
  }  
  
  /* Obtener la longitud del gusano */
  n = g_list_length(cube_cola);
  
  /* Determinar el sentido de rotacion */
  
  if (sentido==DERECHA) {
    /* Actualizar desde el centro a la derecha */
    for (i=centro+1; i<n; i++) 
      cube_rotar_art(centro,i,ang);
  }
  else {
    /* Actualizar desde centro a la izquierda */
    for (i=centro-1; i>=0; i--) {
      cube_rotar_art(centro,i,-ang);
    }  
  }    
}

void cube_info_art(int num_art)
/*********************************************************/
/* Devolver informacion sobre la articulacion indicada   */
/*********************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  double ang_ini;
  
  /* Acceder a la articulacion activa */
  nodo = g_list_nth(cube_cola,num_art);
  art=nodo->data;
  
  /* Imprimir informacion */
  g_print ("[%d] (%.3f,%.3f) pos: %d\n",num_art+1,art->coord.x,art->coord.y,art->fi);
  ang_ini = cube_articulacion_get_angulo(num_art);
  ang_ini = TOGRADOS(ang_ini);
  g_print ("     Angulo con eje x: %.3f\n",ang_ini);
}


void cube_inicializar_gusano()
/**********************************************************************/
/* Inicializar los valores del gusano, a partir de los datos fisicos  */
/* Se recorre el gusano desde la articulacion 0 hasta la ultima,      */
/* asignando valores a las articulaciones.                            */
/*                                                                    */
/*   Las coordenadas x,y de las articulaciones asi como los angulos   */
/* de los servos se inicializan de forma que el gusano este sobre     */
/* el eje x.                                                          */
/*                                                                    */
/* ENTRADAS:                                                          */
/*    - cube_cola : Variable global que apunta a la estructura del    */
/*                  gusano. Debe estar creada.                        */
/*    - long_seg  : Varible global que contiene los datos sobre las   */
/*                  longitudes de los diferentes segmentos del gusano */
/**********************************************************************/
{
  GList    *nodo;
  int nart;
  int i;
  double x;
  
  /* El gusano debe estar creado!! */
  g_assert(cube_cola!=NULL);
  
  /* Inicializar origen de coordenadas en pantalla */
  video_origen_reset();
  
  /* Inicializar la articulacion virtual de la cola */
  cube_set_art(cube_cola->data,1,0,0,0,1);
  x=0;
  
  /* Obtener el numero de articulaciones */
  nart = g_list_length(cube_cola);

  /* Recorrer la lista inicializando las articulaciones */  
  for (i=1; i<nart; i++) {
    /* Acceder a la articulacion i */
    nodo = g_list_nth(cube_cola,i);
    
    /* Obtener coordenada x de la articulacion en funcion de la longitud */
    /* del segment                                                       */
    x+=long_seg[i-1];
    
    /* Dar valores a los parametros de la articulacion */
    cube_set_art(nodo->data,i+1,0,x,0,1);
  }
}

double cube_error_get(int nart)
/***********************************************************************/
/*  Devolver el error de aproximacion de la articulacion especificada  */
/* Se devuelve el error multiplicado por 100                           */
/***********************************************************************/
{
  articulacion_t *art;
  articulacion_t *art_centro;
  GList          *nodo;
  double error;

  if (nart==0) return 0;

  /* Obtener articulacion centro */
  nodo = g_list_nth(cube_cola,nart-1);
  art_centro=nodo->data;

  /* Obtener articulacion activa */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;

  /* Calcular error de ajuste */    
  error=calc_error_ajuste(art_centro->coord,art->coord,func_act);
  
  return error*100;
}

void cube_ajustar_art(int num_art)
/****************************************************************************/
/* Aplicar el algoritmo de ajuste a la articulacion especificada, respecto  */
/* de la funcion de contorno activa.                                        */
/*                                                                          */
/*  Se aplica el algoritmo sobre la articulacion SIN CALCULAR EL ANGULO     */
/*  DE APROXIMACION.                                                        */
/*                                                                          */
/*  ENTRADA:                                                                */
/*    -Numero de articulacion sobre la que aplicar el algoritmo             */
/*    -La variable global func_act debe apuntar a la funcion de contorno    */
/*                                                                          */
/*  SALIDA:                                                                 */
/*    -Se calcula la nueva posicion ajustada y se PROPAGA a un extremo      */
/*    -Se modifica el angulo de posicion de la articulacion centro          */
/****************************************************************************/
{
  articulacion_t *art;
  articulacion_t *art_centro;
  GList          *nodo;
  GList          *nodo_centro;
  double teta;

  /* La articulacion 0 no se puede ajustar hacia la derecha */
  if (num_art==0) return;
  
  /* Acceder a la articulacion extremo */
  nodo = g_list_nth(cube_cola,num_art);
  art=nodo->data;
  
  /* Acceder a la articulacion centro */
  nodo_centro = g_list_nth(cube_cola,num_art-1);
  art_centro=nodo_centro->data;

  /* Calcular el angulo de ajuste */
  teta = calc_angulo_ajuste(art_centro->coord,art->coord,func_act);
  
  /* Rotar la articulacion extremo para ajustarla */
  cube_rotar(num_art-1,teta,DERECHA);
}


void cube_rotar_aprox_rep(int nart)
/********************************************************************/
/* Funcion similar a cube_rotar_aprox(), pero se realizan varias    */
/* iteraciones, para que la articulacion se aproxime mas a la       */
/* funcion de contorno                                              */
/********************************************************************/
{
  double error_ini;
  double error_fin;
  int ciclos=0;
  
  /* Situar cube en el angulo de aproximacion inicial */
  cube_rotar_aprox(nart);
    
  ciclos=0;
  /* Realizar algunas iteraciones sobre el angulo de aproximacion */
  do {
    error_ini = cube_error_get(nart);
    cube_rotar_aprox(nart);
    error_fin = cube_error_get(nart);
    ciclos++;
  } while (error_fin<error_ini && ciclos<5);
  
}

void cube_rotar_aprox(int nart)
/***************************************************************************/
/* Situar la articulacion especificada en el angulo de aproximacion        */
/* La rotacion se "propaga" de izquierda a derecha                         */
/*                                                                         */
/* SOLO SE HACE UNA ITERACION                                              */
/*                                                                         */
/* ENTRADA:                                                                */
/*   -nart : Numero de articulacion sobre la que actuar.                   */
/*                                                                         */
/* SALIDA:                                                                 */
/*  - Se actualizan las coordenadas desde la articulacion pasada como      */
/*    argumento hasta un extremo.                                          */
/*  - Se actualiza el angulo de posicion de la articulacion centro         */
/***************************************************************************/
{
  articulacion_t *art;
  articulacion_t *art_centro;
  GList          *nodo;
  double ang_aprox;
  double ang_actual;
  
  if (nart==0) return;

  /* Obtener articulacion centro */
  nodo = g_list_nth(cube_cola,nart-1);
  art_centro=nodo->data;

  /* Obtener articulacion activa */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;
  
  /* Obtener angulo de aproximacion */
  ang_aprox = calc_angulo_aprox(art_centro->coord,art->coord,func_act);
  ang_aprox = TOGRADOS(ang_aprox);
  
  /* Obtener el angulo actual que forma la articulacion con la horizontal */
  ang_actual = calc_angulo(art_centro->coord,art->coord);
  ang_actual = TOGRADOS(ang_actual);
  
  /* Colocar la articulacion en el angulo de aproximacion y propagar */
  /* la rotacion.                                                    */
  cube_rotar(nart-1,ang_aprox-ang_actual,DERECHA);
}

void cube_ajustar(int nart)
/***************************************************************************/
/* Ajustar cube a la funcion de contorno activa, desde la articulacion     */
/* indicada en adelante.                                                   */
/*                                                                         */
/* Para cada articulacion primero se calcula el angulo de aproximacion y   */
/* luego se aplica el algoritmo de ajuste.                                 */
/***************************************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  double x,y;

  int n;
  int i;

  /* Si la articulacion activa es la cola, hay que situarla sobre la  */
  /* funcion de contorno                                              */
  if (nart==0) {
    /* Obtener coordenadas, x,y de la cola */
    cube_cola_get_xy(&x,&y);
  
    /* Obtener la coordenada y de la funcion de contorno */
    y = func_act(x);
    
    /* Situar la cola en la funcion de contorno */
    cube_cola_set_xy(x,y);
    
    /* Ajustar a partir de la articulacion 1 hacia la derecha */
    nart=1;
  }  

  /* Obtener la articulacion activa */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;
  
  /* Obtener la longitud de la lista */
  n = g_list_length(cube_cola);

  /* Recorrer las articulaciones desde la activa hasta la DERECHA */
  /* y se van ajustando a la funcion de contorno activa           */
  for (i=nart; i<n; i++) {
  
    /* Situar articulacion en angulo de aproximacion */
    /* Se hacen varias iteraciones para que converja */
    /* mas rapido                                    */
    cube_rotar_aprox_rep(i);
    
    /* Ajustar la articulacion */
    cube_ajustar_art(i);
  }
}

/*----------------------------------------------*/
/*   F U N C I O N E S   P R I V A D A S        */
/*----------------------------------------------*/

/*----------------------------------------------------------------------------*/
/* FUNCIONES RELACIONADAS CON LA INICIALIZACION Y LA CREACION DE ESTRUCTURAS  */
/*----------------------------------------------------------------------------*/

static void cube_generar()
/*************************************************************************/
/* Crear la estructura de datos de CUBE. Esta estructura es una lista    */
/* doblemente enlazada, y cada nodo representa a una articulacion.       */
/* Se consideran articulaciones los puntos extremos, situados en la cola */
/* y en la cabeza, aunque no son articulaciones reales, pues no tienen   */
/* un servo asociado.                                                    */
/*                                                                       */
/*  El numero de nodos se obtiene de la variable global sentido_fut.     */
/*                                                                       */
/* ENTRADAS:                                                             */
/*   - Variable global sentido_fut: Se utiliza para determinar el numero */
/*     de nodos en la lista.                                             */
/*                                                                       */
/* SALIDAS:                                                              */
/*   - Se genera la variable global cube_cola, que es un puntero cube    */
/*     por la cola.                                                      */
/*   - Esta lista tiene tantos nodos como articulaciones haya en cube,   */
/*     incluyendo las articulaciones ficticias extremo.                  */
/*   - Los nodos estan inicializados a cero: coordenadas, posicion...    */
/*************************************************************************/
{
  articulacion_t *art;
  int nart;
  int i;

  cube_cola=NULL;
  
  /* Calcular el numero de articulaciones */
  nart=sizeof(sentido_fut)/sizeof(int) + 2;
  
  /* Crear articulaciones y añadirlas a la lista */
  for (i=0; i<nart; i++) {
    /* Crear nodo i, con todos los campos a cero */
    art = cube_generar_art();
    
    /* Añadir nodo i a la lista */
    cube_cola = g_list_append(cube_cola, art);
  } 
}

static articulacion_t *cube_generar_art()
/************************************************************/
/* Crear una articulacion nueva con todos los campos a 0    */
/*                                                          */
/* ENTRADAS: Ninguna                                        */
/* DEVUELVE:                                                */
/*  - Un puntero a una articulacion nueva con todos los     */
/*    campos a cero.                                        */
/************************************************************/
{
  articulacion_t *art;
  
  /* Reservar espacio para la articulacion */
  art = g_malloc (sizeof(articulacion_t));
  
  /* Inicializar a cero todos los campos de la articulacion */
  art->numero=0;
  art->coord.x=0;
  art->coord.y=0;
  art->fi=0;
  art->sentido=0;
  
  /* Devolver puntero a la articulacion creada */
  return art;
}

static void cube_set_art(articulacion_t *art, int numero, int fi, double x, double y, int sentido)
/***********************************************************************/
/* Dar valores a una articulacion. Simplemente se rellenan los campos, */
/* pero no se realizan rotaciones ni nada por el estilo. La mision de  */
/* esta funcion es dar unos valores iniciales.                         */
/*                                                                     */
/* ENTRADAS:                                                           */
/*   - art: Puntero a la articulacion a rellenar con datos.            */
/*   - numero: Numero de articulacion                                  */
/*   - fi: Angulo de posicion del servo                                */
/*   - x,y: Coordenadas x,y del servo                                  */
/*   - sentido: Sentido de colocacion del servo                        */
/***********************************************************************/
{
  /* Asegurarse que la articulacion esta creada */
  g_assert (art!=NULL);
  
  /* Asignar valores */
  art->numero=numero;
  art->fi=fi;
  art->coord.x=x;
  art->coord.y=y;
  art->sentido=sentido;
}


/*----------------------------------------------------------------*/
/* FUNCIONES RELACIONADAS CON LOS ANGULOS DE LAS ARTICULACIONES   */
/*----------------------------------------------------------------*/

static double cube_articulacion_get_angulo(int num_art)
/************************************************************************/
/* Obtener el angulo que forma una articulacion con el eje x.           */
/*                                                                      */
/* ENTRADA:                                                             */
/*   -num_art : Numero de articulacion                                  */
/*                                                                      */
/* DEVUELVE:                                                            */
/*   - El angulo en radianes                                            */
/************************************************************************/
{
  articulacion_t *extremo;
  articulacion_t *centro;
  GList *nodo;
  
  if (num_art==0) return 0;
  
  /* Obtener la articulacion extremo */
  nodo = g_list_nth(cube_cola,num_art);
  extremo=nodo->data;
  
  /* Obtener la articulacion centro */
  nodo = g_list_nth(cube_cola,num_art-1);
  centro=nodo->data;
  
  /* Calcular el angulo */
  return calc_angulo(centro->coord,extremo->coord);
}

static double cube_articulacion_get_angulo_aprox(int num_art)
/*******************************************************************/
/* Obtener el angulo de aproximacion de la articulacion a la       */
/* funcion de contorno activa.                                     */
/*                                                                 */
/* ENTRADA:                                                        */
/*   - num_art: Numero de articulacion a calcular angulo de aprox  */
/*******************************************************************/
{
  articulacion_t *extremo;
  articulacion_t *centro;
  GList *nodo;
  
  if (num_art==0) return 0;
  
  /* Acceder a la articulacion extremo */
  nodo = g_list_nth(cube_cola,num_art);
  extremo=nodo->data;
  
  /* Acceder a la articulacion centro */
  nodo = g_list_nth(cube_cola,num_art-1);
  centro=nodo->data;
  
  /* Calcular angulo de aproximacion */
  return calc_angulo_aprox(centro->coord,extremo->coord,func_act);
}


/*------------------------------------------------------------*/
/* FUNCIONES RELACIONADAS CON LA ROTACION DE ARTICULACIONES   */
/*------------------------------------------------------------*/

static void cube_rotar_art(int centro, int extremo, double ang)
/******************************************************************/
/* Rotar una articulacion con respecto a otra.                    */
/*                                                                */
/* ENTRADA:                                                       */
/*   - centro : Numero de articulacion respecto de la que se va   */
/*               a rotar.                                         */
/*   - extremo: Rotacion a girar                                  */
/*   - ang    : Angulo a rotar (en grados)                        */
/*                                                                */
/* Se actualiza la posicion de la articulacion extremo en funcion */
/* del angulo de posicion (fi) de la articulacion centro          */
/*                                                                */
/* Esta funcion NO PROPAGA la rotacion.                           */
/*                                                                */
/* La articulacion que hace de centro NO ES modificada            */
/******************************************************************/
{
  articulacion_t *art_centro;
  articulacion_t *art_extremo;
  GList  *nodo;

  /* Obtener articulacion centro */  
  nodo = g_list_nth(cube_cola,centro);
  art_centro=nodo->data;
  
  /* Obtener articulacion extremo */
  nodo = g_list_nth(cube_cola,extremo);
  art_extremo=nodo->data;
  
  /* Realizar la rotacion y actualizar las coordenadas de la articulacion */
  /* extremo.                                                             */
  calc_rotar_punto(art_centro->coord, art_extremo->coord, ang, &art_extremo->coord);
}

void cube_articulacion_get_xy(int nart, double *x, double *y)
/*************************************************************/
/* Leer las coordenadas x,y de la articulacion especificada  */
/*************************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  
  /* Obtener articulacion a leer */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;
  
  *x=art->coord.x;
  *y=art->coord.y;
}

double cube_articulacion_get_pos(int nart)
/***********************************************************/
/* Leer la posicion de la articulacion especificada        */
/***********************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  
  /* Obtener articulacion a leer */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;
  
  /* Devolver la posicion */
  return art->fi;
}

void cube_articulacion_set_pos(int nart, double pos, int sentido)
/************************************************************/
/* Establecer la posicion de una articulacion determinada   */
/*                                                          */
/* ENTRADAS:                                                */
/*   - nart: articulacion centro a rotar.                   */
/*   - pos : angulo de posicion del futaba                  */
/*                                                          */
/* SALIDAS:                                                 */
/*   - El angulo de posicion del servo se establece a pos   */
/*   - Se propaga el cambio desde la articulacion centro    */
/*     hasta un extremo.                                    */
/************************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  double fi_actual;
  
  /* Obtener articulacion a rotar */
  nodo = g_list_nth(cube_cola,nart);
  art=nodo->data;
  
  /* Obtener la posicion actual */
  fi_actual=art->fi;
  
  /* Rotar la articulacion de manera que se traslade desde la posicion  */
  /* en la que esta ahora hasta la indicada.                            */
  cube_rotar(nart,pos-fi_actual,sentido);
}





