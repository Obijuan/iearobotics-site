/************************************************************************/
/* cube.h       Sep-2000                                                */
/*----------------------------------------------------------------------*/
/* Definiciones y prototipos del modulo cube.c                          */
/************************************************************************/

#ifndef _CUBE_H
#define _CUBE_H

#include "calc.h"

#define DERECHA   1
#define IZQUIERDA 0

/*----------------------------*/
/*    ESTRUCTURAS DE DATOS    */
/*----------------------------*/

/* Tipo articulacion */
typedef struct articulacion_s {
  gint numero;          /* Numero de servo                          */
  gint fi;              /* Angulo de posicion del servo, en grados  */
  calc_punto2d_t coord; /* Coordenadas x,y del eje de salida        */
  gint  sentido;        /* Sentido del servo. Como esta colocado    */
} articulacion_t;

/*-------------------------------*/
/*  PROTOTIPOS DE INTERFAZ       */
/*-------------------------------*/
void cube_init();
int  cube_long_get();
double cube_articulacion_get_pos(int nart);
void cube_articulacion_set_pos(int nart, double pos, int sentido);
void cube_articulacion_get_xy(int nart, double *x, double *y);
void cube_rotar(int centro, int ang, int sentido);
void cube_info_art(int num_art);
void cube_inicializar_gusano();
double cube_error_get(int nart);
void cube_ajustar_art(int num_art);
void cube_rotar_aprox(int nart);
void cube_rotar_aprox_rep(int nart);
void cube_ajustar(int nart);
void cube_func_contorno_set(double (*func_contorno)(double));
void cube_cola_get_xy(double *x,double *y);
void cube_cola_set_xy(double x,double y);

#endif _CUBE_H



