/********************************************************************/
/* interface.h  Juan Gonzalez Gomez. Microbotica, S.L. Octubre 2000 */
/*------------------------------------------------------------------*/
/* Prototipos y definiciones para el modulo interface.c             */
/********************************************************************/

#ifndef _INTERFACE_H
#define _INTERFACE_H

#include <gtk/gtk.h>

/*------------------------*/
/* ESTRUCTURAS DE DATOS   */
/*------------------------*/

/* -- Estado global del programa -- */
typedef struct main_state_s {
  GtkWidget *win_main;           /* Ventana principal */
  GtkWidget *lcd_g_art[4];       /* Visualizacion de la posicion en grados    */
  GtkWidget *lcd_gf_art[4];      /* Visualizacion de la posicion en grados f  */
  GtkWidget *lcd_vect;           /* Visualizacion del vector activo           */
  GtkWidget *lcd_fich;           /* Visualizacion del nombre del fichero      */
  GtkObject *grados_in_adj[4];   /* Valores manuales introducidos             */
  GtkObject *adj[4];             /* Valores de las articulaciones             */
  GtkObject *secuencia_adj;      /* Valor del potenciometro de secuncias      */
  GtkObject *te_adj;             /* Valor del tiempo de espera en ms          */
  GtkObject *ct_adj;             /* Valor de la cte de tiempo en ms x 10      */
  GtkTooltips *sugerencias;      /* Sugerencias        */
  GtkAccelGroup *accel_group;    /* Teclas aceleracion */
  GtkWidget *progresbar;         /* Barra de progreso             */
  GtkWidget *ventana_ok;
} main_state_t;

/*----------------*/
/*  PROTOTIPOS    */
/*----------------*/
void create_window1 (main_state_t *estado);

#endif  /* _INTERFACE_H */


