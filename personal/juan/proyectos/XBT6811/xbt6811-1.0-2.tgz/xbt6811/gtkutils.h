/************************************************************************/
/* gtk_utils.h    Microbotica, S.L  Sep-2000                            */
/*----------------------------------------------------------------------*/
/* Prototipos y definiciones del modulo gtkutils.c                      */
/************************************************************************/

#ifndef _GTKUTILS_H
#define _GTKUTILS_H


/*-------------------------*/
/* PROTOTIPOS DE INTERFAZ  */
/*-------------------------*/
GtkWidget *gtkutils_crear_submenu_bar(GtkWidget *menu, char *nombre);
GtkWidget *gtkutils_crear_widget_from_xpm(GtkWidget *window, gchar **xpm_data);
GdkColor  *gtkutils_new_color (long red, long green, long blue);

GtkWidget *gtkutils_dialog_ok(char *mensaje,char *tittle, GtkSignalFunc ok, gpointer data);
GtkWidget *gtkutils_dialog_text(char *mensaje, char *tittle);
void gtkutils_dialog_sino(char *mensaje, void (*func_si)(), void (*func_no)());


#endif

