/**************************************************************************/
/* CUBE-FISICO.C    Juan Gonzalez Gomez. Microbotica, S.L.  Octubre 2000  */
/*------------------------------------------------------------------------*/
/* Control de las articulaciones "fisicas" de cube.                       */
/**************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include <microbotica/r6811pc.h>
#include <microbotica/serie.h>
#include <microbotica/bootstrp.h>
#include <microbotica/s19.h>
#include <microbotica/ctclient.h>
/*#include <microbotica/f4client.h>*/

#include "interface.h"
#include "lcd.h"
#include "vectores.h"
#include "secuencias.h"
#include "spinet.h"
#include "retrollamada.h"
#include "gtkutils.h"

/*----------------------*/
/*    CONSTANTES        */
/*----------------------*/
/* Periodo de comprobacion de la conexion */
#define PERIODO_VIVE 500

/* Identificador de la BT6811 numero 1 */
#define BLOQUE1 'a'

/*------------------*/
/*   PROTOTIPOS     */
/*------------------*/
static void boton_ok(GtkWidget *widget, gpointer data);
static void file_save();

/*---------------------*/
/* VARIABLES GLOBALES  */
/*---------------------*/
static main_state_t main_state;

static int temporizador;

/* Variables de estado */
static int conexion=0;   /* Estado de la conexion con f4server    */
static int nbytes_tx=0;  /* Numero de bytes transmitidos          */
static int playing = 0;  /* Indica si se esta reproduciendo o no  */
static GString *fich;    /* Nombre del fichero de secuencia actual, con path completo */


/*-----------------------*/
/* FUNCIONES DE AYUDA    */
/*-----------------------*/

void pot_set(main_state_t *estado, vector_pos_t *v)
/**********************************************/
/* Establecer el valor de los potenciometros  */
/* y del tiempo de espera                     */
/**********************************************/
{
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->adj[0]),v->pos[0]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->adj[1]),v->pos[1]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->adj[2]),v->pos[2]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->adj[3]),v->pos[3]);
  
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->te_adj),v->te);
}

void pot_get(main_state_t *estado, vector_pos_t *v)
/**********************************************************/
/* Devolver un vector con el valor de los potenciometros  */
/* y el tiempo de espera                                  */
/**********************************************************/
{
  v->pos[0]=GTK_ADJUSTMENT(estado->adj[0])->value;
  v->pos[1]=GTK_ADJUSTMENT(estado->adj[1])->value;
  v->pos[2]=GTK_ADJUSTMENT(estado->adj[2])->value;
  v->pos[3]=GTK_ADJUSTMENT(estado->adj[3])->value;
  
  v->te=GTK_ADJUSTMENT(estado->te_adj)->value;
}

void entry_get(main_state_t *estado, vector_pos_t *v)
/*************************************************************/
/* Devolver un vector con el valor de las entradas manuales  */
/*************************************************************/
{
  v->pos[0]=GTK_ADJUSTMENT(estado->grados_in_adj[0])->value;
  v->pos[1]=GTK_ADJUSTMENT(estado->grados_in_adj[1])->value;
  v->pos[2]=GTK_ADJUSTMENT(estado->grados_in_adj[2])->value;
  v->pos[3]=GTK_ADJUSTMENT(estado->grados_in_adj[3])->value;
}

void entry_set(main_state_t *estado, vector_pos_t *v)
/*********************************************************/
/* Establecer un valor en las entradas manuales          */
/*********************************************************/
{
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->grados_in_adj[0]),v->pos[0]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->grados_in_adj[1]),v->pos[1]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->grados_in_adj[2]),v->pos[2]);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(estado->grados_in_adj[3]),v->pos[3]);
}


/*---------------------*/
/*   OTRAS FUNCIONES   */
/*---------------------*/

void update_progres()
/*************************************************************/
/* Llamada cada vez que se recibe el eco de un byte enviado  */
/* Se actualiza la barra de progreso.                        */
/*************************************************************/
{
  double n;
  
  /* Incrementar numero de bytes recibidos */
  nbytes_tx++;  
  
  /* Solo se actualiza la barra de progreso cada 2 bytes */
  if (nbytes_tx % 2) return;
  
  /* Calcular el porcentaje */
  n=(gfloat) nbytes_tx/256;

  /* Actualizar barra de progreso */
  gtk_progress_set_percentage(GTK_PROGRESS (main_state.progresbar), n);
  
  /* Procesar los eventos pendientes */
  while(gtk_events_pending())
    gtk_main_iteration();

}

int vive_conexion(gpointer data)
/**********************************************/
/* Comprobar si hay conexion con el servidor  */
/**********************************************/
{
  /* Si no hay conexion... */
  if (!check_conexion()) {
    conexion=0;
    gtk_timeout_remove(temporizador);
    
    /* Hay que indicarlo al usuario */
    lcd_cls();
    lcd_print("Conexion perdida\n");
    
    return 0;
  }
  
  return 1;
}


/*-------------------------------------------------*/
/* FUNCIONES ASOCIADAS A DIFERENTES BOTONES        */
/*-------------------------------------------------*/

int xcargar_f4server()
/****************************************************/
/* Cargar el F4SERVER.  Asociada al boton LOAD      */
/****************************************************/
{
  vector_pos_t v;

  char *caderror;
  S19 fs19;

  /* Si hay conexion eliminar el temporizador */
  if (conexion) gtk_timeout_remove(temporizador);

  if (abrir_s19("btserver.s19",&fs19,1)==0) {
    caderror=(char *)geterrors19();
    g_print ("Error: %s\n",caderror);
    return 0;
  }

  lcd_cls();
  lcd_print("Cargando...");
  set_break_timeout(500000);
  
  nbytes_tx=0;
  
  if (cargars19_ramint(fs19,update_progres)==0) {
    lcd_print ("Error!");
    cerrar_s19(fs19);
    return 0;
  }
  cerrar_s19(fs19);
  lcd_print("OK\n");
  /*baudios(9600);*/
  usleep(200000);
  
  lcd_locate(1,2);
  lcd_print("Conexion Ok");
 
  conexion=1;
    
  /* Activar temporizador, cada seg se comprueba si la */
  /* conexion con el servidor esta operativa o no      */
    
  //temporizador = gtk_timeout_add(PERIODO_VIVE, vive_conexion, NULL);
    
  /* Activar los futabas */
  spinet_activar(BLOQUE1,0x0F);
    
  /* Leer valor de los potenciometros */
  pot_get(&main_state,&v);
    
  /* Enviar el vector a cube */
  vector_posicionar(&v);
  
  return 1;
}

static void entrada_manual()
/*************************************************************************/
/* Mandar al servidor las posiciones que se han introducido manualmente  */
/* Asociado al boton OK de la entrada manual                             */
/*************************************************************************/
{
  vector_pos_t v;

  /* Leer valor de las entradas manuales  */
  entry_get(&main_state,&v);

  /* Actualizar los potenciometros */
  pot_set(&main_state,&v);
}

static void actualizar_entrada_manual()
/***********************************************************************/
/* Leer valor de los potenciometros y meterlo en las entradas manuales */
/***********************************************************************/
{
  vector_pos_t v;

  /* Leer valor de los potenciometros  */
  pot_get(&main_state,&v);
  
  /* Actualizar las entradas manuales */
  entry_set(&main_state,&v);
}

static void grab()
/**********************************************/
/* Almacenar el vector de posicion actual     */
/**********************************************/
{
  vector_pos_t *v;
  int vector_act=0;
  int n;
  
  /* Leer el numero de vector actual */
  vector_act=GTK_ADJUSTMENT(main_state.secuencia_adj)->value;
  
  /* Leer valor de los potenciometros  */
  v=vector_new();
  pot_get(&main_state,v);
  
  /* A�adir vector de posicion en la posicion actual */
  sec_situar_vector(vector_act,v);
  
  /* Obtener el numero total de vectores en la secuencia */
  n = sec_num_vectores();
     
  /* Si es el ultimo vector, a�adimos un vector nuevo */
  if (vector_act==n-1) {
    v = vector_new();
    pot_get(&main_state,v);
    
    sec_anadir_vector(v);
    
    GTK_ADJUSTMENT(main_state.secuencia_adj)->upper=n+1;
    gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),vector_act+1);
    gtk_adjustment_changed(GTK_ADJUSTMENT(main_state.secuencia_adj));
  }
  else {
    gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),vector_act+1);
  }
}

static void go_sec0()
/************************************/
/* Ir a al vector 0 de la secuencia */
/************************************/
{
   gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),0);
}

static void play(int nrep)
/*************************************************************/
/* Boton de play                                             */
/* Se pasa como argumento el numero de repeticiones a hacer  */
/*************************************************************/
{
  vector_pos_t *vini;
  vector_pos_t *v;
  long tt;
  long  pausa;
  double ct;
  
  int num;
  int i;
  
  /* Obtener la longitud de la secuencia */
  num = sec_num_vectores();
  
  /* Obtener el valor de la cte de tiempo, en ms */
  ct = (GTK_ADJUSTMENT(main_state.ct_adj)->value) / 10;
  
  if (num==1) return;
  
  /* Estamos reproduciendo */
  main_state.ventana_ok=gtkutils_dialog_ok("Parar la reproduccion","PLAY", boton_ok,"1");
  playing = 1;
    
  /* Leeer vector inicial */
  vini = sec_get_vector(0);
  
  vector_posicionar(vini);
  usleep(342000);
  
  while(nrep>0) {
    for (i=1; i<num; i++) {
      
      /* Obtener vector */
      v=sec_get_vector(i);
      vector_print(v);
      
      /* Comprobar si hay que seguir reproduciendo */
      if (!playing) {
        pot_set(&main_state,v);
        gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),i);
        return;
      }  
    
      /* Examinar los eventos pendientes */
      while(gtk_events_pending())
        gtk_main_iteration();
    
      /* Calcular tiempo de transito */
      tt = vector_tiempo_trans(vini,v,ct);
    
      /* Obtener la pausa total en useg (Tiempo transito + tiempo espera)*/
      pausa = (long) (tt+v->te)*1000;
    
      /* Mover las articulaciones */
      vector_posicionar(v);
      usleep(pausa);
    
      vini=v;
    }
    nrep--;
  }
  /* Fin de la reproduccion                      */
  /* Eliminar la ventana para parar la secuencia */
  gtk_widget_destroy(main_state.ventana_ok);
}



static void insert()
/**************************************************************************/
/* Insertar un vector de posicion en la secuencia, en la posicion activa  */
/**************************************************************************/
{
  vector_pos_t *v;
  int vector_act=0;
  int n;

  /* Leer el numero de vector actual */
  vector_act=GTK_ADJUSTMENT(main_state.secuencia_adj)->value;
 
  /* Leer valor de los potenciometros  */
  v = vector_new();
  pot_get(&main_state,v);
  
  /* Insertar vector de posicion */
  sec_insertar_vector(vector_act,v);
  
  /* Obtener longitud de la secuencia */
  n = sec_num_vectores();
  
  GTK_ADJUSTMENT(main_state.secuencia_adj)->upper=n;
  gtk_adjustment_changed(GTK_ADJUSTMENT(main_state.secuencia_adj));
}

static void delete()
/******************************************/
/* Borrar un vector de la secuencia       */
/******************************************/
{
  vector_pos_t *v;
  int vector_act=0;
  int n;

  /* Leer el numero de vector actual */
  vector_act=GTK_ADJUSTMENT(main_state.secuencia_adj)->value;
  
  /* Obtener longitud de la secuencia */
  n = sec_num_vectores();
  
  /* Si solo hay 1 elemento no se borra nada */
  if (n==1) return;
  
  /* Borrar el vector actual */
  sec_delete_vector(vector_act);
  
  /* Si hemos borrado el ultimo elemento, el activo es el anterior */
  if (vector_act==n-1) vector_act--;
  
  /* Obtener el valor de la posicion actual */
  v=sec_get_vector(vector_act);

  /* Colocar los potenciometros en la nueva posicion */  
  pot_set(&main_state,v);
  
  GTK_ADJUSTMENT(main_state.secuencia_adj)->upper=n-1;
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),vector_act);
  gtk_adjustment_changed(GTK_ADJUSTMENT(main_state.secuencia_adj));
}


/*-------------------------------------------------*/
/* FUNCIONES DE RETROLLAMADA DE LOS FILE-SELECTORS */
/*-------------------------------------------------*/
void file_open_ok(GtkWidget *widget, gpointer filew)
/*************************************/
/* Cargar un fichero de secuencias   */
/*************************************/
{
  FILE *f;
  int num;
  gchar *cad;
  
  /* Obtener el nombre del fichero */
  cad = gtk_file_selection_get_filename(GTK_FILE_SELECTION(filew));

  if (strlen(cad)==0) {
    gtk_widget_destroy(GTK_WIDGET(filew));
    return;
  }

  g_print ("CARGANDO: %s\n",cad);

  /* Abrir el fichero */  
  f = fopen(cad,"r");
  if (f==NULL) {
    g_print ("Error al abrir fichero %s\n",fich->str);
    gtk_widget_destroy(GTK_WIDGET(filew));
    return;
  }
  
  /* Leer los vectores de posicion */
  if (!sec_load_vectores(f)) {
    g_print ("Fichero NO esta en formato .f4\n");
  }
    
  fclose(f);
  
  g_print ("OK\n");
  
  /* Obtener el numero de vectores en la secuencia leida */
  num = sec_num_vectores();
  
  /* Actualizar el indicador del vector actual */
  GTK_ADJUSTMENT(main_state.secuencia_adj)->upper=num;
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),0);
  gtk_adjustment_changed(GTK_ADJUSTMENT(main_state.secuencia_adj));
  
  /* Almacenar el nombre del fichero */
  g_string_assign(fich,cad);
  
  /* -- Inicializar LCD con nombre de fichero -- */  
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_fich),fich->str);
  
  gtk_widget_destroy(GTK_WIDGET(filew));
}

void file_save_as_ok(GtkWidget *widget, gpointer filew)
/*************************/
/*  Grabar un fichero    */
/*************************/
{
  gchar *cad;
  
   /* Obtener el nombre del fichero */
  cad = gtk_file_selection_get_filename(GTK_FILE_SELECTION(filew));
  
  /* Asignar el nombre */
  g_string_assign(fich,cad);
  
  /* Grabar con nuevo nombre */
  file_save();

  /* -- Inicializar LCD con nombre de fichero -- */  
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_fich),fich->str);
  
  gtk_widget_destroy(GTK_WIDGET(filew));
}


/*------------------------------------------------*/
/* FUNCIONES ASOCIADAS A OPCIONES DEL MENU FILE   */
/*------------------------------------------------*/

void file_new()
/*******************************/
/* Opcion new del menu file    */
/*******************************/
{
  char wd[256];     /* Wordking Directory */
  int num;

  /* Borrar la secuencia actual */
  sec_init();
  
  /* Liberar el nombre actual */
  g_string_free(fich,TRUE);
  
  /* Establecer nuevo nombre del fichero */
  getcwd(wd,256);           /* Leer directorio actual */
  fich=g_string_new(wd);   
  g_string_append(fich,"/noname.f4");  /* Nombre por defecto */
  
  /* -- Inicializar LCD con nombre de fichero -- */  
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_fich),fich->str);  
  g_print ("Fichero: %s\n",fich->str);

  /* Obtener el numero de vectores en la secuencia leida */
  num = sec_num_vectores();
  
  /* Actualizar el indicador del vector actual */
  GTK_ADJUSTMENT(main_state.secuencia_adj)->upper=num;
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.secuencia_adj),0);
  gtk_adjustment_changed(GTK_ADJUSTMENT(main_state.secuencia_adj));
  
}

void file_open()
/**************************************/
/* Opcion de open del menu file       */
/**************************************/
{
  GtkWidget *filew;
  
  filew = gtk_file_selection_new("OPEN");
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew),fich->str);
  gtk_file_selection_hide_fileop_buttons(GTK_FILE_SELECTION(filew));
  
  gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button),
                           "clicked", (GtkSignalFunc) gtk_widget_destroy,
                           GTK_OBJECT(filew));
  gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),"clicked", 
                     GTK_SIGNAL_FUNC(file_open_ok), filew);
  gtk_widget_show(filew);
}

static void file_save()
/**************************************/
/* Opcion de grabacion del menu file  */
/**************************************/
{
  FILE *f;
  
  g_print ("SAVE: %s\n",fich->str);
  
  /* Abrir fichero. Si no existe se crea y si existe se borra */
  f=fopen(fich->str,"w");
  if (f==NULL) {
    g_print ("Error\n");
    return;
  }
  
  /* Grabar la secuencia */ 
  sec_grabar_vectores(f);
  
  /* Cerrar fichero */
  fclose(f);
  
  g_print ("OK\n");
}

void file_save_as()
/***************************************/
/* Opcion de save_as del menu file     */
/***************************************/
{
  GtkWidget *filew;
  
  filew = gtk_file_selection_new("SAVE AS");
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew),fich->str);
  gtk_file_selection_hide_fileop_buttons(GTK_FILE_SELECTION(filew));
  
  gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button),
                           "clicked", (GtkSignalFunc) gtk_widget_destroy,
                           GTK_OBJECT(filew));
  gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),"clicked", 
                     GTK_SIGNAL_FUNC(file_save_as_ok), filew);
  gtk_widget_show(filew);
  
}


/*----------------------------------*/
/*  FUNCIONES DE RETROLLAMADA       */
/*----------------------------------*/

void menu_file(GtkWidget *widget, gpointer data)
/**************************************************************/
/* Funcion de retrollamada de las opciones del menu file      */
/**************************************************************/
{
  int n;
  
  /* Obtener el numero de boton */
  n=atoi((char *)data);
  
  switch(n) {
    case 0 : file_new();
             break;
    case 1 : file_open();
             break;
    case 2 : file_save();
             break;
    case 3 : file_save_as();
             break;
    default: g_print ("Opcion %d\n",n);
  }

}

static void boton_ok(GtkWidget *widget, gpointer data)
/**********************************************************/
/* Funcion llamada cuando se pulsa el boton de OK de la   */
/* ventana de dialogo de OK.                              */
/**********************************************************/
{
  int n;

  /* Obtener el numero de ventana de dialogo */
  n=atoi((char *)data);
  
  switch(n) {
    case 1: /* Para la reproduccion de la secuencia */
            playing=0;
            break;
  }

  /* Destruir la ventana */
  gtk_widget_destroy(GTK_WIDGET(main_state.ventana_ok));
}

gint main_destroy(GtkWidget *widget, gpointer gdata)
/************************************************************/
/* Funcion llamada cuando se destruye la ventana principal  */
/************************************************************/
{
  cerrar_puerto_serie();
  gtk_main_quit();
  
  return (FALSE);
}

void main_boton(GtkWidget *widget, gpointer data)
/*******************************************************************************/
/* FUNCION DE RETROLLAMADA DE LOS BOTONES NORMALES.                            */
/*                                                                             */
/* Cada boton tiene asociado un numero                                         */
/* un numero.                                                                  */
/*  En funcion del boton apretado se llama a la funcion correspondiente        */
/*******************************************************************************/
{
  int n;
  vector_pos_t v;

  
  /* Obtener el numero de boton */
  n=atoi((char *)data);
  
  /* Acceder a la funcion correspondiente de cada boton */
  switch (n) {
    case 1 : /* Quit */
             gtk_widget_destroy(GTK_WIDGET(main_state.win_main));
             break;
    case 2 : /* Boton de reset de la CT6811 */
             okreset();
             break;
    case 3 : /* Cargar servidor */
             xcargar_f4server();
             break;
    case 4 : /* Posicion inicial de los potenciometros */
             VECTOR_ASIGNAR((&v),0,0,0,0);
             v.te=0;
             pot_set(&main_state,&v);
             
             break;
    case 5 :
    case 6 :
    case 7 :
    case 8 : gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.adj[n-5]),0);
             break;
    case 10: entrada_manual();
             break;
    case 11: actualizar_entrada_manual();
             break;
    case 12: grab();
             break;
    case 13: go_sec0(); /* Boton de inicializacion de la secuencia */
             break;
    case 14: play(30000); /* Reproduccion infinita */
             break;
    case 15: insert(); /* Insertar un vector en la secuencia */
             break;
    case 16: delete(); /* Borrar un vector de la secuencia */
             break;
    case 17: play(1);  /* Reproducir solo 1 vez */
             break;
    default: g_print ("Boton: %d\n",n);
  }
  
}
  
void sec_changed(GtkWidget *widget, gpointer data)
/************************************************************/
/* Funcion llamada cuado hay algun cambio en el numero de   */
/* secuencia.                                               */
/************************************************************/
{
  int numvect;
  char cad[5];
  vector_pos_t *v;
  
  /* Leer numero de vector */
  numvect = (int) (GTK_ADJUSTMENT(widget))->value;
  
  /* Imprimir valor en lcd */
  sprintf (cad,"%d",numvect);
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_vect),cad);
  
  /* Leer el vector de posicion */
  v=sec_get_vector(numvect);

  /* asignar valor a los potenciometros */
  pot_set(&main_state,v);
  
}
  
void pot_changed(GtkWidget *widget, gpointer data)
/******************************************************************/
/* Funcion llamada cuando hay algun cambio en los potenciometros  */
/******************************************************************/
{
  int valor;
  int fut;
  double p;
  int n;
  char cad[5];

  /* Obtener el numero de articulacion */
  n=atoi((char *)data);

  /* Leer valor del potenciometro, en grados  */
  valor=(int)(GTK_ADJUSTMENT(widget))->value;
  
  /* Imprimirlo en grados */
  sprintf (cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_g_art[n]),cad);
  
  /* Imprimirlo en grados futaba */
  p = spinet_to_grados_fut((GTK_ADJUSTMENT(widget))->value);
  fut = (int)p;
  sprintf (cad,"%d",fut);
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_gf_art[n]),cad);
  
  /* Actualizar posicion del futaba */
  if (conexion) spinet_set_pos_grados(BLOQUE1,n+1,valor);
}


/*---------------------------*/
/*      M  A  I  N           */
/*---------------------------*/


int
main (int argc, char *argv[])
{
  vector_pos_t *v;
  char wd[256];     /* Wordking Directory */

  gtk_set_locale ();
  gtk_init (&argc, &argv);
  
  /* --- Inicializar el estado del interfaz -- */
  main_state.sugerencias = gtk_tooltips_new();
  main_state.accel_group=NULL;
  
  /* --- Inicializar estado del programa --- */
  getcwd(wd,256);  /* Leer directorio actual */
  fich=g_string_new(wd);  /* Nombre por defecto del fichero */
  g_string_append(fich,"/noname.f4");
  g_print ("Fichero: %s\n",fich->str);

  
  /* --- Inicializar puerto Serie --- */
  if (abrir_puerto_serie(COM1)==0) {
    printf ("Error al abrir puerto serie: %s\n",getserial_error());
    exit(1);
  }  

  /* --- Crear el interfaz principal ---*/
  create_window1 (&main_state);
  gtk_widget_show (main_state.win_main);

  /* -- Inicializar LCD con nombre de fichero -- */  
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_fich),fich->str);
  
  /*--- Inicializar las posiciones de los potenciometros ---*/
  v=vector_crear(0,0,0,0,0);
  pot_set(&main_state,v);
  
  /*-- Inicializar cte de tiempo y tiempo de espera -- */
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.ct_adj),38);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.te_adj),0);
  
  /*--- Inicializar el LCD ----*/
  lcd_print("XBT6811 v1.0");
  lcd_locate(1,2);
  lcd_print("---------------");

  /*--- Inicializar el modulo de secuencias --*/
  sec_init();
  
  gtk_main ();
  return 0;
}



