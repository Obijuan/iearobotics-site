/*************************************************************************/
/* lcd.h      Microbotica, S.L        Octubre-2000                       */
/*-----------------------------------------------------------------------*/
/* Funciones y prototipos del modulo lcd.c                               */
/*************************************************************************/

GtkWidget *lcd_init();
void lcd_print(char *cad);
void lcd_cls();
void lcd_locate(int x, int y);
