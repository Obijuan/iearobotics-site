/****************************************************************************/
/* SPINET      (C)  MICROBOTICA, S.L      NOVIEMBRE 2000                    */
/****************************************************************************/
/* Servicios proporcionados por la SPINET                                   */
/****************************************************************************/

#include <stdio.h>

#include <microbotica/serie.h>
#include <microbotica/ctclient.h>

#include "spinet.h"

/*****************************************/
/* Codigos de las tramas de la SPINET    */
/*****************************************/
#define SPINET_CAMBIAR_LED 0x6C
#define SPINET_ACTIVAR     0x65
#define SPINET_PUERTOC     0x63
#define SPINET_POSICIONAR  0x70

/*---------------------------------*/
/* PROTOTIPOS FUNCIONES PRIVADAS   */
/*---------------------------------*/
static void construir_spinet_trama(byte *trama, byte valor1, byte valor2, 
                                   byte valor3, byte valor4);

/*---------------------------------------------------*/
/*  F U N C I O N E S    D E     I N T E R F A Z     */
/*---------------------------------------------------*/
void spinet_cambiar_led(byte dir)
/***********************************************/
/* SERVICIO SPINET: Cambiar estado del led     */
/*                                             */
/* ENTRADAS:                                   */
/*   -dir : Direccion del nodo                 */
/***********************************************/
{
  byte trama[4];
  
  /* -- Construir la trama de la spinet --*/
  construir_spinet_trama(trama,dir,SPINET_CAMBIAR_LED,0,0);
  
  /* -- Enviar la trama -- */
  enviar_bloque(trama,4);
}

void spinet_activar(byte dir, byte mask)
/************************************************************/
/* SERVICIO SPINET: Enviar mascara de activacion de servos  */
/*                                                          */
/* ENTRADAS:                                                */
/*   -dir : Direccion del nodo                              */
/*   -mask: Mascara de activacion                           */
/************************************************************/
{
  byte trama[4]; 
  
  /* -- Construir la trama de la spinet --*/
  construir_spinet_trama(trama,dir,SPINET_ACTIVAR,mask,0);
  
  /* -- Enviar la trama -- */
  enviar_bloque(trama,4);
}

void spinet_puertoc(byte dir, byte valor)
/************************************************************/
/* SERVICIO SPINET: Enviar valor por el puerto C            */
/*                                                          */
/* ENTRADAS:                                                */
/*   -dir : Direccion del nodo                              */
/*   -valor: Dato a sacar por puerto C                      */
/************************************************************/
{
  byte trama[4]; 
  
  /* -- Construir la trama de la spinet --*/
  construir_spinet_trama(trama,dir,SPINET_PUERTOC,valor,0);
  
  /* -- Enviar la trama -- */
  enviar_bloque(trama,4);
}

void spinet_posicionar(byte dir, byte motor, byte pos)
/************************************************************/
/* SERVICIO SPINET: Posicionar un servo                     */
/*                                                          */
/* ENTRADAS:                                                */
/*   -dir  : Direccion del nodo                             */
/*   -motor: Numero de motor                                */
/*   -pos  : Posicion en grados futaba                      */
/************************************************************/
{
  byte trama[4]; 
  
  /* -- Construir la trama de la spinet --*/
  construir_spinet_trama(trama,dir,SPINET_POSICIONAR,motor,pos);
  
  /* -- Enviar la trama -- */
  enviar_bloque(trama,4);
}

void spinet_pos_sistema(byte dir, byte fut1, byte fut2, byte fut3, byte fut4)
/*************************************************/
/* Posicionar todos los servos de un nodo        */
/*                                               */
/* ENTRADA:                                      */
/*   -dir: Direccion del nodo                    */
/*   -fut1: Posicion del servo 1                 */
/*   -fut2: Posicion del servo 2                 */
/*   -fut3: Posicion del servo 3                 */
/*   -fut4: Posicion del servo 4                 */
/*************************************************/
{
  spinet_posicionar(dir,1,fut1);
  spinet_posicionar(dir,2,fut2);
  spinet_posicionar(dir,3,fut3);
  spinet_posicionar(dir,4,fut4);
}

void spinet_set_pos_grados(byte dir,byte fut, double pos)
/*****************************************************/
/* Establecer la posicion de un servo en grados      */
/*                                                   */
/* ENTRADAS:                                         */
/*   -dir: Direccion del nodo                        */
/*   -fut: Numero de servo a posicionar              */
/*   -pos: Posicion en GRADOS                        */
/*****************************************************/
{
  byte a;
  
  /* Convertir de grados a grados futaba */
  a = (byte) spinet_to_grados_fut(pos);

  /* Actuar sobre el servo */
  spinet_posicionar(dir,fut,a);
}

void spinet_set_pos_sistema_grados(byte dir,double fut1, double fut2, double fut3, double fut4)
/***********************************************************/
/* Establecer la posicion de todos los servos en GRADOS    */
/*                                                         */
/* ENTRADAS:                                               */
/*   -dir: Direccion del nodo                              */
/*   -fut1: Posicion servo 1                               */
/*   -fut2: Posicion servo 2                               */
/*   -fut3: Posicion servo 3                               */
/*   -fut4: Posicion servo 4                               */
/***********************************************************/
{
  byte a1,a2,a3,a4;
  
  /* Convertir de grados a grados futaba */
  a1 = (byte) spinet_to_grados_fut(fut1);
  a2 = (byte) spinet_to_grados_fut(fut2);
  a3 = (byte) spinet_to_grados_fut(fut3);
  a4 = (byte) spinet_to_grados_fut(fut4);

  /* Actuar sobre el servo */
  spinet_pos_sistema(dir,a1,a2,a3,a4);
}

double spinet_to_grados_fut(double grados)
/****************************************************************************/
/* Convertir de grados a grados futaba                                      */
/* El angulo del futaba, en grados, esta comprendido en el entorno [-90,90] */
/* El angulo en grados futabas esta comprendido entre 0-230.                */
/* El valor en grados futaba correspondiente a cero grados es 115           */
/* La pendiente de la recta es 115/90 = 1.28.                               */
/****************************************************************************/
{
  return 1.28*grados + 115;
}


/*---------------------------------------------------*/
/*  F U N C I O N E S    P R I V A D A S             */
/*---------------------------------------------------*/



static void construir_spinet_trama(byte *trama, byte valor1, byte valor2, 
                                   byte valor3, byte valor4)
/**********************************************************************/
/* Constuir una trama para la spinet a partir de los valores pasados  */
/**********************************************************************/
{
  trama[0]=valor1;
  trama[1]=valor2;
  trama[2]=valor3;
  trama[3]=valor4;
}





