/**************************************************************************/
/* SECUENCIAS.H   Juan Gonzalez Gomez. Microbotica, S.L.  Octubre 2000    */
/*------------------------------------------------------------------------*/
/* Datos y prototipos para el modulo secuencias.h                         */
/**************************************************************************/

#ifndef _SECUENCIAS_H
#define _SECUENCIAS_H

#include "vectores.h"

/*-------------*/
/* PROTOTIPOS  */
/*-------------*/
void sec_init();
int  sec_num_vectores();
vector_pos_t *sec_get_vector(int numvect);
void sec_anadir_vector(vector_pos_t *v);
void sec_situar_vector(int numvect, vector_pos_t *v);
void sec_insertar_vector(int numvect, vector_pos_t *v);
void sec_delete_vector(int numvect);
void sec_grabar_vectores(FILE *f);
int  sec_load_vectores(FILE *f);


#endif  /* _SECUENCIAS_H */
