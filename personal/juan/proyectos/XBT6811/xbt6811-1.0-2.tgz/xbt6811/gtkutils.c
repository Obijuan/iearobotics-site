/************************************************************************/
/* gtkutils.c     Microbotica, S.L  Sep-2000                            */
/*----------------------------------------------------------------------*/
/* Funciones de utilidad basadas en las GTK                             */
/* Hacer la programacion GTK un poco mas sencilla.                      */
/************************************************************************/

#include <gtk/gtk.h>
#include "gtkutils.h"


/*----------------------------------------------*/
/*    P R O T O T I P O S    P R I V A D O S    */
/*----------------------------------------------*/
static void dialog_destroy(GtkWidget *widget, gpointer data);
static void boton_ok(GtkWidget *widget, gpointer data);
static void dialog_destroy(GtkWidget *widget, gpointer data);
static void boton_sino(GtkWidget *widget, gpointer data);

/*--------------------------------------------------*/
/*    F U N C I O N E S    D E   I N T E R F A Z    */
/*--------------------------------------------------*/
GtkWidget *gtkutils_crear_submenu_bar(GtkWidget *menu, char *nombre)
/******************************************************************/
/* Crear un submenu en una barra de menu                          */
/*                                                                */
/* ENTRADAS:                                                      */
/*    - Widget barra de menu, creado con gtk_menu_bar_new         */
/*    - Nombre del menu                                           */
/*                                                                */
/* DEVUELVE:                                                      */
/*    - Widget de submenu                                         */
/******************************************************************/
{
  GtkWidget *menuitem;
  GtkWidget *submenu;
  
  /* Crear el menu */
  menuitem = gtk_menu_item_new_with_label(nombre);
  
  /* A�adirlo a la barra de menu */
  gtk_menu_bar_append(GTK_MENU_BAR(menu), menuitem);
  gtk_widget_show(menuitem);
  
  /* Obtener un menu y asociarlo al elemento de menu */
  submenu = gtk_menu_new();
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(menuitem), submenu);
  
  return (submenu);
}

GtkWidget *gtkutils_crear_widget_from_xpm(GtkWidget *window, gchar **xpm_data)
/*************************************************************/
/*  Convertir una cadena xpm en un widget de mapa de pixels  */
/*  Utiliza la variable global win_main                      */
/*************************************************************/
{
  GdkBitmap *mask;
  GdkPixmap *pixmap_data;
  GtkWidget *pixmap_widget;
  
  /* Convertir la cadena en un dato Gdk_pixmap */
  pixmap_data = gdk_pixmap_create_from_xpm_d (window->window, &mask, 
                                              NULL, (gchar **) xpm_data);
  /* --- Convertir el mapa de pixels en un widget de mapa de pixels */
  pixmap_widget = gtk_pixmap_new (pixmap_data, mask);
  
  /* -- Hacer visible el widget --- */
  gtk_widget_show (pixmap_widget);
  
  return (pixmap_widget);
}

GdkColor *gtkutils_new_color (long red, long green, long blue)
/*************************************************/
/* Obtener el color a partir de las componentes  */
/*************************************************/
{
  /* -- Obtener color --*/
  GdkColor *c = (GdkColor *) g_malloc(sizeof(GdkColor));
  
  /* --- Rellenarlo ---*/
  c->red = red;
  c->green = green;
  c->blue = blue;
  
  gdk_color_alloc(gdk_colormap_get_system(), c);
  
  return (c);
}

GtkWidget *gtkutils_dialog_text(char *mensaje, char *tittle)
/*************************************************************/
/* Crear una ventana de texto                                */
/*************************************************************/
{
  static GtkWidget *label;
  GtkWidget *dialog_window;
  
  /*--- Crear una ventana de dialogo ----*/
  dialog_window = gtk_dialog_new();
  
  /*-- Atrapar se�al de cierre de ventana, para liberar restriccion de foco --*/
  gtk_signal_connect (GTK_OBJECT(dialog_window), "destroy",dialog_destroy, NULL);
                      
  gtk_window_set_title (GTK_WINDOW(dialog_window), tittle);
  gtk_container_border_width (GTK_CONTAINER(dialog_window),5);
  
  /*----------------------------*/
  /* Crear el mensaje           */
  /*----------------------------*/
  label = gtk_label_new(mensaje);
  
  /* -- Dejar algo de espacio alrededor de la etiqueta -- */
  gtk_misc_set_padding(GTK_MISC(label), 10,10);
  
  /* -- A�adir etiqueta al cuadro de dialogo -- */
  gtk_box_pack_start (GTK_BOX(GTK_DIALOG (dialog_window)->vbox), label, TRUE, TRUE, 0);
  
  gtk_widget_show(label);
  
  gtk_widget_show(dialog_window);
  gtk_grab_add(dialog_window);
  
  return dialog_window;

}

GtkWidget *gtkutils_dialog_ok(char *mensaje, char *tittle, GtkSignalFunc ok, gpointer data)
/*************************************************************/
/* Crear una ventana con un boton de OK                      */
/*                                                           */
/* ENTRADA:                                                  */
/*   - Mensaje a escribir en la ventana de dialogo           */
/*************************************************************/
{
  static GtkWidget *label;
  GtkWidget *button;
  GtkWidget *dialog_window;
  
  /*--- Crear una ventana de dialogo ----*/
  dialog_window = gtk_dialog_new();
  
  /*-- Atrapar se�al de cierre de ventana, para liberar restriccion de foco --*/
  gtk_signal_connect (GTK_OBJECT(dialog_window), "destroy",dialog_destroy, NULL);
                      
  gtk_window_set_title (GTK_WINDOW(dialog_window), tittle);
  gtk_container_border_width (GTK_CONTAINER(dialog_window),5);
  
  /*----------------------------*/
  /* Crear el mensaje           */
  /*----------------------------*/
  label = gtk_label_new(mensaje);
  
  /* -- Dejar algo de espacio alrededor de la etiqueta -- */
  gtk_misc_set_padding(GTK_MISC(label), 10,10);
  
  /* -- A�adir etiqueta al cuadro de dialogo -- */
  gtk_box_pack_start (GTK_BOX(GTK_DIALOG (dialog_window)->vbox), label, TRUE, TRUE, 0);
  
  gtk_widget_show(label);
  
  /*----------------------------*/
  /*   Crear el boton de OK     */
  /*----------------------------*/
  
  button = gtk_button_new_with_label ("Ok");
  
  /* Hace falta cerrar la ventana si se pulsa "OK"  */
  gtk_signal_connect (GTK_OBJECT(button), "clicked", ok, data);
                      
  /* Permitir que sea el boton predeterminado */
  GTK_WIDGET_SET_FLAGS(button,GTK_CAN_DEFAULT);
  
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog_window)->action_area),
                     button, TRUE, TRUE, 0);
                     
  gtk_widget_grab_default(button);
  gtk_widget_show(button);
  gtk_widget_show(dialog_window);
  gtk_grab_add(dialog_window);
  
  return dialog_window;
}

void gtkutils_dialog_sino(char *mensaje, void (*func_si)(), void (*func_no)())
/*****************************************************************************/
/* Crear una ventana con las opciones SI y NO para que el usuario elija      */
/*                                                                           */
/* ENTRADA:                                                                  */
/*   - Mensaje a escribir en la ventana de dialogo                           */
/*   - Funcion de retrollamada del boton si                                  */
/*   - Funcion de retrollamada del boton no                                  */
/*****************************************************************************/
{
  GtkWidget *label;
  GtkWidget *button;
  GtkWidget *dialog_window;
  
  /*-- Crear el cuadro de dialogo ---*/
  dialog_window=gtk_dialog_new();
  
  /*-- Atrapar la se�al de cierre de ventana --*/
  gtk_signal_connect(GTK_OBJECT(dialog_window),"destroy",
                     GTK_SIGNAL_FUNC(dialog_destroy), &dialog_window);
  /*-- Establecer el titulo --*/
  gtk_window_set_title(GTK_WINDOW(dialog_window),"sino");
  gtk_container_border_width(GTK_CONTAINER (dialog_window), 5);
  
  /*---------------------*/
  /* Crear el mensaje    */
  /*---------------------*/
  label = gtk_label_new(mensaje);
  gtk_misc_set_padding(GTK_MISC(label),10,10);
  gtk_box_pack_start(GTK_BOX (GTK_DIALOG(dialog_window)->vbox), label,
                     TRUE,  TRUE, 0);
  gtk_widget_show(label);
  
  /*------------*/
  /* Boton si   */
  /*------------*/
  button = gtk_button_new_with_label("Si");
  gtk_signal_connect (GTK_OBJECT(button), "clicked", GTK_SIGNAL_FUNC (func_si),
                      dialog_window);
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG (dialog_window)->action_area),
                     button, TRUE, TRUE, 0);
  gtk_widget_show(button);
  
  /*------------*/
  /*  Boton no  */
  /*------------*/
  button = gtk_button_new_with_label("NO");
  gtk_signal_connect (GTK_OBJECT(button), "clicked",GTK_SIGNAL_FUNC(func_no),
                      dialog_window);
  GTK_WIDGET_SET_FLAGS (button, GTK_CAN_DEFAULT);                    
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG (dialog_window)->action_area), button,
                     TRUE, TRUE, 0);
  gtk_widget_grab_default(button);
  gtk_widget_show(button);
  gtk_widget_show(dialog_window);
  gtk_grab_add(dialog_window);
}


/*--------------------------------------------------*/
/*   F U N C I O N E S    P R I V A D A S           */
/*--------------------------------------------------*/
static void boton_ok(GtkWidget *widget, gpointer data)
/**********************************************************/
/* Funcion llamada cuando se pulsa el boton de OK de la   */
/* ventana de dialogo de OK.                              */
/**********************************************************/
{
  gtk_widget_destroy(GTK_WIDGET(data));
}

static void dialog_destroy(GtkWidget *widget, gpointer data)
/*************************************************************/
/* Funcion llamada antes de destruir una ventana de dialogo  */
/*************************************************************/
{
  /* Levantar la restriccion del foco */
  gtk_grab_remove (GTK_WIDGET(widget));
}

static void boton_sino(GtkWidget *widget, gpointer data)
/*****************************************************************/
/* Ejemplo de funcion de retrollamada cuando se pulsa el boton   */
/* de si o de no de la ventana de dialogo si/no                  */
/*****************************************************************/
{
  gtk_widget_destroy(GTK_WIDGET(data));
}


