/*************************************************************************/
/* retrollamada.h   Juan Gonzalez Gomez. Microbotica, S.L. Octubre 2000  */
/*-----------------------------------------------------------------------*/
/* Prototipos de las funciones de retrollamada del interfaz              */
/*************************************************************************/

#ifndef _RETROLLAMADA_H
#define _RETROLLAMADA_H

#include <gtk/gtk.h>

gint main_destroy(GtkWidget *widget, gpointer gdata);
void main_boton(GtkWidget *widget, gpointer data);
void pot_changed(GtkWidget *widget, gpointer data);
void sec_changed(GtkWidget *widget, gpointer data);
void menu_file(GtkWidget *widget, gpointer data);

#endif  /* _RETROLLAMADA_H */
