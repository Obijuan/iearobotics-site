/**********************************************/
/* sg-tramas-picp.c   Juan Gonzalez Gomez.    */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <termios.h>
#include <string.h>

#include "sg-serial.h"
#include "sg-tramas.h"


/***********************************/
/*          CONSTANTES             */
/***********************************/
//-- Tiempo de espera tras un error o un timeout
#define ERROR_TIMEOUT 500000  //en microsegundos


//--TIMEOUT hasta considerar que el sistema no responde
#define TIMEOUT 100000

/***********************************/
/*             VARIABLES           */
/***********************************/
static int serial_fd;  /*-- Descriptor puerto serie */


/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/************************************************************/
/* Inicializacion del m�dulo sg-tramas-picp                 */
/*----------------------------------------------------------*/
/* Simplemente se establece el descriptor del puerto serie  */
/*                                                          */
/* ENTRADAS:                                                */
/*   fd: Descriptor del puerto serie a usar                 */
/************************************************************/
void sg_tramas_picp_init(int fd)
{
  //-- Asignar el puerto serie a utilizar
  serial_fd=fd;
}


/*****************************************************************/
/* Servicio RESET directo al StarGate                            */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_reset()
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  ssize_t n;
  struct timeval timeout;
  int status;
  int ret;

  // Construir la trama 
  trama[0]=TRAMA_RST_CAB;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RRST_CAB) {  
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      /* Vaciar los buffers de entrada y salida */
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //--Cualquier otro error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio INCREMENT-ADDRESS directo al StarGate                */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_increment_address()
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  ssize_t n;
  struct timeval timeout;
  int status;
  int ret;

  // Construir la trama 
  trama[0]=TRAMA_INC_CAB;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RINC_CAB) {  
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      /* Vaciar los buffers de entrada y salida */
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //--Cualquier otro error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio READ_DATA directo al StarGate                        */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* SALIDAS:                                                      */
/*    valor: Valor de 14 bits leido                              */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_read_data(int *valor)
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  byte bms;
  byte BMS;
  
  // Construir la trama RRD
  trama[0]=TRAMA_RD_CAB; 

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RRD_CAB) { 
	status=1;
	bms=respuesta[1]; //-- Byte menos significativo
	BMS=respuesta[2]; //-- Byte mas significativo
	*valor =(int) ((BMS<<8) | bms);
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
	*valor=0;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      valor=0;
      break;
    default: //-- Otro Error
      status=-1;
      valor=0;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio LOAD CONFIG directo al StarGate                      */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load_config()
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  ssize_t n;
  struct timeval timeout;
  int status;
  int ret;

  // Construir la trama 
  trama[0]=TRAMA_CONF_CAB;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RCONF_CAB) {  
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      /* Vaciar los buffers de entrada y salida */
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //--Cualquier otro error
      status=-1;
      break;
  }

  return status;
}


/*****************************************************************/
/* Servicio PROG directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_prog(int valor)
{
  char trama[4];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  
  // Construir la trama PROG
  trama[0]=TRAMA_PROG_CAB;
  trama[1]=(char)(valor & 0x00FF);           //-- Byte menos sig.
  trama[2]=(char)((valor>>8)&0x00FF);        //-- Byte mas sig.

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,3);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 2;  //-- Establecer el TIMEOUT
  timeout.tv_usec = 0; //TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RPROG_CAB) { 
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //-- Otro Error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio LOAD-DATA directo al StarGate                        */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load_data(int valor)
{
  char trama[4];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  
  // Construir la trama LOAD_DATA
  trama[0]=TRAMA_DATA_CAB;
  trama[1]=(char)(valor & 0x00FF);           //-- Byte menos sig.
  trama[2]=(char)((valor>>8)&0x00FF);        //-- Byte mas sig.

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,3);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 2;  //-- Establecer el TIMEOUT
  timeout.tv_usec = 0; //TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RDATA_CAB) { 
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //-- Otro Error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio BEGIN PROGRAM/ERASE CYCLE                            */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_begin_pec()
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  ssize_t n;
  struct timeval timeout;
  int status;
  int ret;

  // Construir la trama 
  trama[0]=TRAMA_BEGIN_CAB;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RBEG_CAB) {  
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      /* Vaciar los buffers de entrada y salida */
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //--Cualquier otro error
      status=-1;
      break;
  }

  return status;
}
