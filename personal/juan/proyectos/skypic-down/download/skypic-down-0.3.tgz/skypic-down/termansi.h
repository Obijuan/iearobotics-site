#define NEGRO    0
#define AZUL     4
#define VERDE    2
#define CYAN     6
#define ROJO     1
#define MAGENTA  5
#define AMARILLO 3
#define BLANCO   7

#define SIMPLE 0
#define DOBLE  1

void configansi(int t);
/**************************************************************************/
/* Cambiar el estado del ansi. Cuando el parametro de entrada indica 0    */
/* no se utilizan comandos ansi. Cuando t=1 si.                           */
/**************************************************************************/

void dprint(char *cad);
/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/******************************************************/

void clrscr();
/************************/
/*  Borrar la pantalla  */
/************************/

void locate(char x, char y);
/**********************************************/
/*  Situar el cursor en la posicion indicada  */
/**********************************************/

void fondo(char f);
/**********************************/
/* Cambiar el color del fondo     */
/**********************************/

void setcolor(char c);
/**************************************/
/*  Cambiar el color del primer plano */
/**************************************/

void color(char f,char b);
/***********************************************/
/*  Cambiar color del primer plano y del fondo */
/***********************************************/

void high();
/******************************************************************/
/*  Establecer atributos de alta intensidad en color primer plano */
/******************************************************************/

/********************************/
/*  Poner atributos a 'cero'    */
/********************************/
void low();

void print(char *cad);
