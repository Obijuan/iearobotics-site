/**************************************************/
/* skypic-down.c      Juan Gonzalez Gomez.        */
/*------------------------------------------------*/
/* Cliente del StarGate PICP                      */
/* Grabaci�n de programas en PICs 16F84           */
/* No se utilizan hilos                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include "sg-serial.h"
#include "sg-tramas.h"
#include "sg-tramas-picp.h"
#include "intelHex.h"
#include "termansi.h"

/*-- Tama�o del buffer para la lectura de fichero .hex --*/
#define TAM_BUFFER 1024
#define COM1 0
#define COM2 1
#define ESC 27

char version[]={"0.2"};
char fecha[]={"Octubre 2003"};

/************************/
/* VARIABLES GLOBALES   */
/************************/
int puerto;  // Puerto serie a utilizar
int flag_16f87xa;
char fich_name[80];


/*****************************/
/*    FUNCIONES              */
/*****************************/

/*************************************************************/
/* Identificar el servidor, imprimiendo el nombre completo.  */
/* Se devuelve el estado de la conexion y la identifiacion   */
/*************************************************************/
int id(byte *server_id)
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is, im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    *server_id=is;
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    *server_id=0;
    break;
  default:
    printf ("[ERROR]\n");
    *server_id=0;
  }

  return status;
}

/**************************************************/
/* Verificar la memoria de un pic contra un       */
/* buffer de memoria                              */
/* -----------------------------------------------*/
/* DEVUELVE:                                      */
/*   0 : Error de verificacion                    */
/*   1 : Verificacion OK                          */
/**************************************************/
int program_verify(unsigned int *buffer, int tam)
{
  int status;
  int i=0;
  int valor;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  }

  //-------- Comenzar la VERIFICACION
  for (i=0; i<tam; i++) {
    status=sg_read_data(&valor);
    if (status==1) {
      if (valor==buffer[i]) {
	printf (".");
	fflush(stdout);
      }
      else {
	printf ("\nERROR!. Posicion: %x\n",i);
	printf ("Leido: %x\n",valor);
	printf ("Valor correcto: %x\n",buffer[i]);
	return 0;
      }
    }
    else {
      printf ("X\n");
      break;
    }
    //-- Pasar a la siguiente posicion
    status=sg_increment_address();
    if (status!=1) {
      printf ("X\n");
      break;
    }
  }

  printf ("\n");
  if (i==tam) {  //-- Programa correctamente verificado
    return 1;
  }
  else {
    return 0;
  }
 
}

/*****************************************************/
/* Grabar en un pic de la familia 16F8X              */
/*---------------------------------------------------*/
/* DEVUELVE:                                         */
/*   0: Error                                        */
/*   1: OK, aunque no se hace verificacion           */
/*****************************************************/
int program_16f8x(unsigned int *buffer, int tam)
{
  int status;
  int i;

  //-- Comenzar la programacion
  for (i=0; i<tam; i++) {
    status=sg_prog(buffer[i]);
    if (status==1) {
      printf (".");
      fflush(stdout);
    }
    else {
      printf ("X\n");
      break;
    }
    //-- Pasar a la siguiente posicion
    status=sg_increment_address();
    if (status!=1) {
      printf ("X\n");
      break;
    }
  }
  
  printf ("\n");
  if (i==tam) {  //-- Programa grabado
    return 1;
  }
  else {
    return 0;
  }
}



/*****************************************************/
/* Grabar en un pic de la familia 16F8X              */
/*---------------------------------------------------*/
/* DEVUELVE:                                         */
/*   0: Error                                        */
/*   1: OK, aunque no se hace verificacion           */
/*****************************************************/
int program_16f87xa(unsigned int *buffer, int tam)
{
  int status;
  int i=0;
  int valor;
  int base;
  int error=0;

  error=0;
  for (base=0;  base<tam; base+=8) {

    //-- Cargar un bloque de 8 bytes
    for (i=0; i<8; i++) {

      //--Ver si hay que poner caracteres de relleno
      if ((base+i)>tam) valor=0x00;
      else valor=buffer[base+i];

      //-- Enviar valor
      status=sg_load_data(valor);
      if (status==1) {
	printf (".");
	fflush(stdout);
      }
      else {
	printf ("X");
	fflush(stdout);
	error=1;
	break;
      }

      //-- Pasar a la siguiente posicion
      //-- Si es el �ltimo valor no se incrementa
      if (i<7) {
	//-- Pasar a la siguiente posicion
	status=sg_increment_address();
	if (status!=1) {
	  printf ("Error...\n");
	  error=1;
	  break;
	}
      }
    }

    //-- Grabar el bloque
    status=sg_begin_pec();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }

    //-- Apuntar al comienzo de la siguiente posicion a grabar
    status=sg_increment_address();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }
  }
  
  printf ("\n");
  
  if (error) return 0;
  return 1;
}


/****************************************************/
/* Grabar en la memoria del pic el programa que se  */
/* encuentra en el buffer.                          */
/*--------------------------------------------------*/
/* DEVUELVE:                                        */
/*   0 : Error                                      */
/*   1 : OK, aunque no se hace verificacion         */
/****************************************************/
int program(unsigned int *buffer, int tam)
{
  int status;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 

  //-- Seleccionar la forma de programaci�n en funci�n
  //-- del tipo de pic

  if (flag_16f87xa) 
    return program_16f87xa(buffer,tam); //-- Familia 16F87XA
  else 
    return program_16f8x(buffer,tam); //-- Familia 16F8X  
}


/***********************************************/
/* Grabar la palabra de configuracion          */
/* (y verificarla)                             */
/*---------------------------------------------*/
/* ENTRADAS:                                   */
/*   config: Valor a grabar                    */
/* DEVUELVE:                                   */
/*    0: Error                                 */
/*    1: OK. Se hace verificacion              */
/***********************************************/
int prog_config(int config)
{
  int status;
  int valor;
  int i;

  printf ("Grabando en la configuracion...\n");

  //-- Acceder a la memoria de configuracion
  status=sg_load_config();
  if (status!=1) {
    return 0;
  }

  //-- Avanzar hasta la posicion 7
  for (i=0; i<7; i++) {
    status=sg_increment_address();
    if (status!=1) {
      return 0;
    }
  }

  //-- Mostrar el valor actual
  status=sg_read_data(&valor);
  if (status!=1) {
    return 0;
  }
  printf ("Valor Actual: %x\n",valor);

  //-- Grabar el nuevo valor
  status=sg_prog(config);
  if (status!=1) {
    return 0;
  }

  //-- Leer el valor grabado
  status=sg_read_data(&valor);
  if (status!=1) {
    return 0;
  }
  printf ("Nuevo Valor: %x\n",valor);
  
  //-- Si lo leido es distinto de lo grabado.. error
  if (config!=valor) return 0;

  return 1;
}

/*******************************************/
/* Establecer la conexion con el StarGate  */
/*-----------------------------------------*/
/* Devuelve:                               */
/*    0 : Error                            */
/*    1 : OK                               */
/*******************************************/
int conexion_servidor()
{
  int status;
  int intentos=0;
  byte is;

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id(&is);
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) return 1;
  else return 0;
}


/***********************************************************/
/* Leer un fichero, meterlo en el buffer y devolver el     */
/* tama�o                                                  */
/*---------------------------------------------------------*/
/* ENTRADAS:                                               */
/*    Descriptor fichero entrada                           */
/* SALIDAS:                                                */
/*    buffer: Contiene el programa leido                   */
/*    tam   : Tama�o (en palabras)                         */
/* DEVUELVE:                                               */
/*    0 : Error al procesar fichero .hex                   */
/*    1 : OK                                               */
/***********************************************************/
int leer_fichero_hex(FILE *fich, unsigned int *buffer, int *tam)
{
  int status;
  int i;
  int max,min;

  //--- Poner el buffer a '0'
  for (i=0; i<=1024; i++) {
    buffer[i]=0;
  }

  //-- Leer el fichero .hex
  status=readihex(fich, buffer, &min, &max);
  if (status!=1) return 0; 

  *tam=max;

  return 1;
}

void print_error(char *cad)
/*******************************/
/* Imprimir cadena de error    */
/*******************************/
{
  setcolor(AMARILLO);
  high();
  print ("\n  ---> ERROR: ");
  low();
  printf (cad);
  printf ("\n\n");
}

void print_info(char *nombre, int tam, int puerto)
/********************************************************/
/* Imprimir informacion sobre los parametros actuales   */
/********************************************************/
{
  printf ("Puerto actual        : COM%u\n",puerto+1);
  printf ("Fichero              : %s\n",nombre);
  printf ("Tama�o               : %d palabras\n",tam);
}

void presenta()
/*******************************/
/* Encabezado de presentacion  */
/*******************************/
{
  printf ("\n");
  setcolor(ROJO);
  high();
  print ("SKYPIC ");
  setcolor(AMARILLO);
  print (version);
  setcolor(VERDE);
  print (" para LINUX. ");
  setcolor(CYAN);
  print ("Juan Gonz�lez <juan@iearobotics.com>, ");
  print (fecha);
  printf ("\n");
  setcolor(BLANCO);
  print ("Descarga de programas en la tarjeta SkyPic\n");
  print ("Licencia GPL\n\n");
  low();

}


void help()
/*********************/
/* Mostrar la ayuda  */
/*********************/
{
  presenta();
  low();
  high();
  print ("Forma de uso: ");
  low();
  print ("skypic fichero.s19 [opciones]\n\n");
  high(); print ("   -com1   ");
  low();  print ("Utilizar el COM1\n");
  high(); print ("   -com2   ");
  low();  print ("Utilizar el COM2\n");
  high(); print ("   -h      ");
  low();  print ("Esta ayuda\n");
  high(); print ("   -p      ");
  low();  print ("Se est� usando un pic 16F87XA\n\n");
  high(); print ("Ejemplo:  ");
  low();  print ("skypic ledp.hex -com1\n\n");
}

void analizar_parametros(int argc, char* argv[])
/*****************************************************************/
/* Analizar los parametros pasados desde la linea de comandos    */
/* Se actualizan las variables globales:                         */
/*       - puerto: Con el puerto serie especificado              */
/*       - flag_terminal: Si hay que ejecutar el terminal        */
/*****************************************************************/
{
    int c;

    puerto=COM1;     /* Puerto por defecto  */
    flag_16f87xa=0;

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .hex\n");
      printf ("Utilice skypic-down -h para obtener ayuda\n\n");
      exit(1);
    }  
      
    strcpy(fich_name,argv[1]);
    while ((c = getopt(argc, argv, ":c:hp"))!=EOF) {
 	switch (c) {
  	  case 'c':
            if (strcmp("om2",optarg)==0) puerto=COM2;
            else 
              if (strcmp("om1",optarg)==0) puerto=COM1;
              else puerto=COM2;
	    break;
          case 'p':
            flag_16f87xa=1;
            break;  
	  case 'h':
	default: help();
	         exit (0);
	}
    }
}


/************************/
/* PROGRAMA PRINCIPAL   */
/************************/
int main(int argc, char* argv[])
{
  int serial_fd;  /*-- Descriptor puerto serie */
  int status;
  FILE *fich;
  unsigned int buffer[TAM_BUFFER];
  int tam;
  char cad[80];
  char cad2[80];

  analizar_parametros(argc,argv);
  printf ("\n");
  presenta();

  //-- Abrir el fichero
  fich=fopen(fich_name,"r");
  if (fich==NULL) {
    sprintf (cad,"Fichero: %s no encontrado\n\n",fich_name);
    print_error (cad);
    return 0;
  }

  //-- Leer el buffer
  status = leer_fichero_hex(fich,buffer,&tam);
  if (status!=1) {
    sprintf (cad,"Formato no reconocido. Fichero: %s\n\n",fich_name);
    print_error (cad);
    fclose(fich);
    return 0;
  }

  //-- Ya podemos cerrar el fichero.
  fclose(fich);

  //-- Abrir el puerto serie
  sprintf (cad,"/dev/ttyS%d",puerto);
  serial_fd=sg_serial_open(cad);
  if (serial_fd==-1) {
    sprintf (cad2,"No se puede abrir puerto serie (%s)\n\n",cad);
    print_error(cad2);
    return 0;
  }

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  sg_tramas_picp_init(serial_fd);
  
  //-- Establecer conexi�n el servidor
  status=conexion_servidor();
  if (status!=1) {
    sprintf (cad,"No se estable conexi�n con el grabador\n\n");
    print_error(cad);
    printf ("Aseg�rese de que est� conectado y correctamente alimentado\n\n");
    return 0;  //-- Terminar
  }

  printf ("Grabador detectado\n");
  print_info(fich_name,tam,puerto);

  status=program(buffer,tam);
  if (status!=1) {
    sprintf (cad,"No se ha podido realizar la grabaci�n\n\n");
    print_error(cad);
    close(serial_fd);
    return 0;
  }
  printf ("OK!!\n");
  printf ("VERIFICANDO\n");
  status=program_verify(buffer,tam);
  if (status!=1) {
    printf ("---> [ERROR], Verificaci�n incorrecta\n\n");
    close(serial_fd);
    return 0;
  }
  printf ("PROGRAMA GRABADO CORRECTAMENTE\n\n");
  //-- Grabar la palabra de configuracion
  status=prog_config(0x3F39);
  if (status!=1) {
    printf ("---> [ERROR]. Grabacion configuracion incorrecta \n\n");
    close(serial_fd);
    return 0;
  }
  printf ("OK!!\n");

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}

