/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                                  <>
<>  ESFERA 1.0                                                      <>
<>  ==========                                                      <>
<>                                                                  <>
<> Esfera es un software dise�ado para dotar al usuario del control <>
<> ergon�mico de dos c�maras con 180 grados de libertad en los      <>
<> ejes x, e y.                                                     <>
<>                                                                  <>
<> Carlos Jesus Venegas <eventyr@terra.es>                          <>
<> Ivan Gonzalez        <gmivan@teleline.es>                        <>
<> Juan Gonzalez        <juan@iearobotics.com>                      <>
<>                                                                  <>
<> ---------------------------------------------------------------- <>
<>                                                                  <>
<> CRM <www.ii.uam.es/~mecatron>  IEAROBOTICS <www.iearobotics.com> <>
<>                                                                  <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
*/

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include "about.h"
#include "strings.h"

// Variable global que guarda el logotipo de esfera
static GdkPixbuf *logo; 

gint logo_expose (GtkWidget *widget,GdkEventExpose *event,gpointer args)
{
  guint width,    // ancho
        height;   // alto

  // Tomamos las dimensiones de la imagen
  width = gdk_pixbuf_get_width(logo);
  height = gdk_pixbuf_get_height(logo);
  
  // Renderizamos la imagen
  gdk_pixbuf_render_to_drawable (logo,
				 widget->window,
				 widget->style->fg_gc[GTK_STATE_NORMAL],
				 0,
				 0,
				 0,
				 0,
				 width,
				 height,
				 GDK_RGB_DITHER_MAX,
				 0,
				 0);

  return TRUE;
}

gint About (GtkWidget *widget,gpointer args){

  GtkWidget *credits,    // Creditos. 
            *autor1,     // autor 1.
            *autor2,     // autor 2.
            *autor3,     // autor 3.
            *vbox,       // contendor vertical.
            *logoarea,   // area de dibujo para el logo.
            *license,    // licencia.
            *copyright,  // autor 7.
            *copyright2, // autor 8.
            *separator;  // separador horizontal.
  guint     height,      //  altura de la ventana.
            width;       // anchura de la ventana.

  // Creacion de la ventana de creditos.
  credits=gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Creamos el texto a motrar, autores, licencia, etc

  autor1 = gtk_label_new ("Carlos Jes�s Venegas <eventyr@terra.es>");
  autor2 = gtk_label_new ("Iv�n Gonz�lez <gmivan@teleline.es>");
  autor3 = gtk_label_new ("Juan Gonz�lez <juan@iearobotics.com>");
  license = gtk_label_new ("Este programa se distribuye bajo licencia GPL");
  copyright = gtk_label_new ("CRM <www.ii.uam.es/~mecatron>");
  copyright2= gtk_label_new ("IEAROBOTICS <www.iearobotics.com>");
  
  // Creamos un separador horizontal
  separator = gtk_hseparator_new ();
  
  // Creamos el contenedor de la aplicacion esfera.
  vbox = gtk_vbox_new (FALSE, 0);

  // Area de dibujo para el logo
  logoarea= gtk_drawing_area_new();  

  // Abrimos el logo
  logo=gdk_pixbuf_new_from_file(LOGO);
  width = gdk_pixbuf_get_width(logo);
  height = gdk_pixbuf_get_height(logo);

  // Establecemos las caracteristicas de la ventana principal
  gtk_window_set_title(GTK_WINDOW(credits),"Cr�ditos Esfera 1.0");
 
  gtk_window_set_policy(GTK_WINDOW(credits),
                        TRUE,
                        TRUE,
                        TRUE);
  gtk_container_set_border_width(GTK_CONTAINER(credits),10);
  
  gtk_window_set_default_size(GTK_WINDOW(credits),width+10,height+180);
  
  gtk_drawing_area_size (GTK_DRAWING_AREA(logoarea), width,height);
  

  // Capturamos la se�al de repintado de la ventana

  gtk_signal_connect (GTK_OBJECT (logoarea), 
		      "expose-event",
                      GTK_SIGNAL_FUNC (logo_expose), NULL);

  gtk_widget_set_events(logoarea,
                        GDK_EXPOSURE_MASK);

  // Empaquetamos todos los widgets de la aplicacion

  gtk_container_add (GTK_CONTAINER (credits), vbox);
  gtk_box_pack_start (GTK_BOX (vbox), logoarea, TRUE, TRUE, 0);
  gtk_box_pack_start(GTK_BOX(vbox),autor1,TRUE,TRUE,0);  
  gtk_box_pack_start(GTK_BOX(vbox),autor2,TRUE,TRUE,0);  
  gtk_box_pack_start(GTK_BOX(vbox),autor3,TRUE,TRUE,0);  
  gtk_box_pack_start (GTK_BOX (vbox), separator, FALSE, TRUE, 5);
  gtk_box_pack_start(GTK_BOX(vbox),license,TRUE,TRUE,0);  
  gtk_box_pack_start(GTK_BOX(vbox),copyright,TRUE,TRUE,0);  
  gtk_box_pack_start(GTK_BOX(vbox),copyright2,TRUE,TRUE,0);  

  gtk_widget_show_all (credits);

  return TRUE;
}

