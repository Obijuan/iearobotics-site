/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                                  <>
<>  ESFERA 1.0                                                      <>
<>  ==========                                                      <>
<>                                                                  <>
<> Esfera es un software diseñado para dotar al usuario del control <>
<> ergonómico de dos cámaras con 180 grados de libertad en los      <>
<> ejes x, e y.                                                     <>
<>                                                                  <>
<> Carlos Jesus Venegas <eventyr@terra.es>                          <>
<> Ivan Gonzalez        <gmivan@teleline.es>                        <>
<> Juan Gonzalez        <juan@iearobotics.com>                       <>
<>                                                                  <>
<> ---------------------------------------------------------------- <>
<>                                                                  <>
<> CRM <www.ii.uam.es/~mecatron>  IEAROBOTICS <www.iearobotics.com  <>
<>                                                                  <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
*/

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
#include "about.h"
#include "strings.h"
#include "spinet.h"

//#define __DEBUG_ESFERA__   // Para activar los mensajes de debug.

// Dimensiones del area de dibujo
#define WIDTH       180
#define HEIGHT      180

// Definicion para los botones
#define NO_CAPTURAR 0
#define CAPTURAR 1
#define BOTON_DERECHO 3

// Definiciones para la red del SPI
#define BLOQUE1 'a'

// Variables globales

static gint status =NO_CAPTURAR;  // Indica si debemos capturar o no.
static GtkWidget *posxy  = NULL;  // Posicion x, y de la camara.
static guint idcontext;           // contexto para la barra de estado.
static GdkPixbuf *pixmap = NULL;  // area de recorrido.
static GtkWidget *invx   = NULL;  // boton para invertir eje x.
static GtkWidget *invy   = NULL;  // boton para incertir eje y.
static gint inversion_x  = 1;     // flag de inversion en x.
static gint inversion_y  = 1;     // flag de inversion en y.

void pot_changed(int pot, int data)
{
    int valor;
    int fut;
    double p;
    int n;
    char cad[5];

    // Obtener el numero de articulacion  */
    n=data;

    // Leer valor del potenciometro, en grados   */
    valor=pot;

    // Actualizar posicion del futaba */
    spinet_set_pos_grados(BLOQUE1,n+1,valor);
}

gint Motion(GtkWidget *widget,GdkEvent *event,gpointer args)
{

  char text[25];      // Mostramos la posicion X,Y del cursor.
  gint x,             // Posicion X.
       y;             // Posicion Y.

  // Vemos qué tipo de evento se ha producido en el panel y
  // actuamos en consecuencia.

  switch(event->type){

  case GDK_BUTTON_PRESS:

    // Se ha presionado el boton derecho, hay que reinicializar
    // las camaras al inicio, si se ha pulsado otro boton,
    // alternamos de modo activo (captura) a inactivo.

    if((int)event->button.button==BOTON_DERECHO){
       pot_changed(0, 0);
       pot_changed(0,1);
    }
    else status=(status+1)%2;

    break;

  case GDK_MOTION_NOTIFY:

    // Se ha detectado movimiento del raton, si estamos en
    // modo de captura, y nos hallamos dentro del area
    // permitida (giramos 180 grados en total),pues
    // actualizamos el movimiento.

    if(status==CAPTURAR&&
       event->motion.x <= WIDTH &&
       event->motion.y <= HEIGHT){

      x=(inversion_x==0)
	?0-((gint)event->motion.x-90)
	:(gint)event->motion.x-90;

      y=(inversion_y==0)
	?0-(90-(gint)event->motion.y)
	:90-(gint)event->motion.y;

      // Actualizamos la posicion en la barra de status
      g_snprintf(text, 25, "X:%d Y:%d",x,y);

      gtk_statusbar_pop( GTK_STATUSBAR(posxy),idcontext);

      gtk_statusbar_push(GTK_STATUSBAR(posxy),
			     idcontext,
			     text);

#ifdef __DEBUG_ESFERA__
      g_print("x=%d y=%d\n",(int)event->motion.x,(int)event->motion.y);
#endif

      pot_changed(x, 0);
      pot_changed(y,1);
    }

    break;

  default:

    return FALSE;
  }

  return TRUE;
}

gint canvas_expose (GtkWidget *widget,GdkEventExpose *event, gpointer args)
{
  // Actualizacion de la imagen de fondo.

  gdk_pixbuf_render_to_drawable (pixmap,
				 widget->window,
				 widget->style->fg_gc[GTK_STATE_NORMAL],
				 0,
				 0,
				 0,
				 0,
				 WIDTH,
				 HEIGHT,
				 GDK_RGB_DITHER_MAX,
				 0,
				 0);

  return TRUE;
}

void Invertir_ejes (GtkWidget *widget, gpointer data)
{
  // Vemos en qué estado están los botones de seleccion
  // del modo de los ejes y cambiamos el sentido
  // del eje x o/y del eje y segúb proceda.

  if (GTK_TOGGLE_BUTTON (invx)->active) {

#ifdef __DEBUG_ESFERA__
    printf("INVERTIR EJE X\n");
#endif

    inversion_x=0;

  }else{

#ifdef __DEBUG_ESFERA__
    printf("NO INVERTIR X\n");
#endif

    inversion_x=1;
  }

  if (GTK_TOGGLE_BUTTON (invy)->active) {

#ifdef __DEBUG_ESFERA__
    printf("INVERTIR EJE Y\n");
#endif

    inversion_y=0;

  }else{

#ifdef __DEBUG_ESFERA__
    printf("NO INVERTIR Y\n");
#endif

    inversion_y=1;
  }
}

GtkWidget *esfera_app()
{
  GtkWidget *canvas;         // Area de captura de raton.
  GtkWidget *vbox;           // Container para meter la aplicacion.
  GtkWidget *toolbar;        // Menu.

  // Creamos el area de captura de movimiento del raton.
  canvas= gtk_drawing_area_new();

  // Establecemos las caracteristicas y dimensiones del area
  // de captura.
  gtk_drawing_area_size (GTK_DRAWING_AREA(canvas), WIDTH, HEIGHT);

  // Capturamos los eventos de movimiento, punteo del raton y
  // refresco de la imagen de fondo.

  gtk_signal_connect(GTK_OBJECT(canvas),
		     "motion_notify_event",
		     GTK_SIGNAL_FUNC(Motion),NULL);

  gtk_signal_connect(GTK_OBJECT(canvas),
		     "button_press_event",
		     GTK_SIGNAL_FUNC(Motion),NULL);

  gtk_signal_connect (GTK_OBJECT (canvas),
		      "expose-event",
                      GTK_SIGNAL_FUNC (canvas_expose), NULL);

  gtk_widget_set_events(canvas,
                        GDK_EXPOSURE_MASK|
                        GDK_POINTER_MOTION_MASK|
			GDK_BUTTON_PRESS_MASK);

  // Abrimos la imagen de fondo de la aplicacion
  pixmap=gdk_pixbuf_new_from_file(FONDO);

  // Creamos la nueva barra de status
  posxy=gtk_statusbar_new();

  //Obtenemos el contexto para esta barra
  idcontext=gtk_statusbar_get_context_id(GTK_STATUSBAR(posxy),
					 "Posicion de la camara");

  // Creamos la toolbar
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_BOTH);

  //Añadimos las opciones al toolbar
  gtk_toolbar_append_item(GTK_TOOLBAR(toolbar),
			  "About",
                          "Créditos",
                          NULL,
                          NULL,
                          GTK_SIGNAL_FUNC(About),
                          NULL);

  // Creamos el grupo de botones para la inversion de ejes
  invx=gtk_toolbar_append_element(
                    GTK_TOOLBAR(toolbar),
                    GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                    NULL,
                    "Inv. X",
                    "Invertir eje X",
                    NULL,
                    NULL,
                    GTK_SIGNAL_FUNC (Invertir_ejes),
                    toolbar);

  invy=gtk_toolbar_append_element(GTK_TOOLBAR(toolbar),
                               GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                               NULL,
                               "Inv. Y",
                               "Invertir eje Y",
                               NULL,
                               NULL,
                               GTK_SIGNAL_FUNC (Invertir_ejes),
                               toolbar);

  // Creamos el contenedor para los elementos de la aplicacion
  vbox = gtk_vbox_new (FALSE, 0);

  // Añadimos todos los componentes al contenedor
  gtk_box_pack_start(GTK_BOX(vbox),toolbar,TRUE,TRUE,0);
  gtk_box_pack_start (GTK_BOX (vbox), canvas, TRUE, TRUE, 0);
  gtk_box_pack_end(GTK_BOX(vbox),posxy,TRUE,TRUE,0);

  return vbox;
}











