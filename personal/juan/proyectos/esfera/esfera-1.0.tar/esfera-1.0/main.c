/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                                  <>
<>  ESFERA 1.0                                                      <>
<>  ==========                                                      <>
<>                                                                  <>
<> Esfera es un software diseñado para dotar al usuario del control <>
<> ergonómico de dos cámaras con 180 grados de libertad en los      <>
<> ejes x, e y.                                                     <>
<>                                                                  <>
<> Carlos Jesus Venegas <eventyr@terra.es>                          <>
<> Ivan Gonzalez        <gmivan@teleline.es>                        <>
<> Juan Gonzalez        <juan@iearobotics.com>                      <>
<>                                                                  <>
<> ---------------------------------------------------------------- <>
<>                                                                  <>
<> CRM <www.ii.uam.es/~mecatron>  IEAROBOTICS <www.iearobotics.com  <>
<>                                                                  <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
*/

#include <gtk/gtk.h>
#include "esfera.h"
#include "serie.h"

#define WIN_WIDTH   180     // ancho ventana.
#define WIN_HEIGHT  220     // alto venta.

gint Delete_event(GtkWidget *widget,GdkEvent *event, gpointer args)
{
  return FALSE;
}

void Destroy_window(GtkWidget *widget,gpointer args)
{
  gtk_main_quit();
}

int main()
{
  GtkWidget *mainwin;
  GtkWidget *vbox;

  gtk_init(NULL,NULL);
  gdk_rgb_init();

  // Creacion de la ventana principal
  mainwin=gtk_window_new(GTK_WINDOW_TOPLEVEL);

  // Establecemos las caracteristicas de la ventana principal
  gtk_window_set_title(GTK_WINDOW(mainwin),"Esfera 1.0");

  gtk_window_set_policy(GTK_WINDOW(mainwin),
                        TRUE,
                        TRUE,
                        TRUE);
  gtk_window_set_default_size(GTK_WINDOW(mainwin),WIN_WIDTH,WIN_HEIGHT);

  gtk_container_set_border_width(GTK_CONTAINER(mainwin),0);

  // Capturamos las seniales para la aplicacion principal
  gtk_signal_connect(GTK_OBJECT(mainwin),
		     "destroy",
		     GTK_SIGNAL_FUNC(Destroy_window),NULL);

  gtk_signal_connect(GTK_OBJECT(mainwin),
		     "delete_event",
		     GTK_SIGNAL_FUNC(Delete_event),NULL);

  // Creamos la aplicacion de esfera
  vbox = esfera_app();

  // Añadimos esfera a la aplicacion principal
  gtk_container_add (GTK_CONTAINER (mainwin), vbox);

  // Visualizamos todo y comenzamos la aplicacion
  gtk_widget_show_all(mainwin);

  // Abrir puerto serie para comunicarse con tarjeta CT6811 
  if (abrir_puerto_serie(COM1)==0) {
	printf ("Error al abrir puerto serie: %s\n",getserial_error());
	exit(1);
    }

  gtk_main();

  return 0;
}
