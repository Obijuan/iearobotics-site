/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                                  <>
<>  ESFERA 1.0                                                      <>
<>  ==========                                                      <>
<>                                                                  <>
<> Esfera es un software diseñado para dotar al usuario del control <>
<> ergonómico de dos cámaras con 180 grados de libertad en los      <>
<> ejes x, e y.                                                     <>
<>                                                                  <>
<> Carlos Jesus Venegas <eventyr@terra.es>                          <>
<> Ivan Gonzalez        <gmivan@teleline.es>                        <>
<> Juan Gonzalez        <juan@iearobotics.com>                       <>
<>                                                                  <>
<> ---------------------------------------------------------------- <>
<>                                                                  <>
<> CRM <www.ii.uam.es/~mecatron>  IEAROBOTICS <www.iearoboticsc.com <>
<>                                                                  <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
*/

#ifndef __ESFERA__
#define __ESFERA__

GtkWidget *esfera_app(void);

#endif
