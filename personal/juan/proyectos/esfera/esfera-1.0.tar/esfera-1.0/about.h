/*
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
<>                                                                  <>
<>  ESFERA 1.0                                                      <>
<>  ==========                                                      <>
<>                                                                  <>
<> Esfera es un software diseñado para dotar al usuario del control <>
<> ergonómico de dos cámaras con 180 grados de libertad en los      <>
<> ejes x, e y.                                                     <>
<>                                                                  <>
<> Carlos Jesus Venegas <eventyr@terra.es>                          <>
<> Ivan Gonzalez        <gmivan@teleline.es>                        <>
<> Juan Gonzalez        <juan@iearobotics.com>                      <>
<>                                                                  <>
<> ---------------------------------------------------------------- <>
<>                                                                  <>
<> CRM <www.ii.uam.es/~mecatron>  IEAROBOTICS <www.iearobotics.com> <>
<>                                                                  <>
<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>
*/

#ifndef __ABOUT__
#define __ABOUT__

gint About (GtkWidget *widget,gpointer args);

#endif
