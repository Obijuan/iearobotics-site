/*****************************************************/
/* NEWTON.c    (c) Juan Gonzalez Gomez. Marzo 2002   */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include <gnome.h>
#include <math.h>

/*------------------------*/
/*    DEFINICIONES        */
/*------------------------*/
#define VERSION "0.2"

/*-- Definiciones para el UNIVERSO --*/
#define MAX_PARTICULAS 2  /* Numero maximo de particulas */
#define DIAMETRO       10 /* Diametro de las particulas  */

/* Duracion del Tiempo Discreto. Constante que indica cuanto dura en   */
/* "la realidad" cada TIC de reloj de tiempo discreto. Se              */
/* expresa en milisegundos                                             */
#define DTD   20

/* TICS de reloj para el calculo de la cinematica inversa */
#define TICS_CI 5

/* Numero de unidades de tiempo a simular */
#define SIMULATION_TIME 50

/* Valor inicial del "ZOOM" */
#define PIXELS_PER_UNIT 1.0

/* Valor del incremento/decremento del "ZOOM" */
#define ZOOM_INC 0.05

/* Factor de Visualizacion de Vectores. Las particulas tienen un vector  */
/* "READL" (verdadero) y tienen otro vector VISUAL, que es el que se     */
/* dibuja en el CANVAS. No tienen porque coincidir. Esta constante se    */
/* define como: FVV= Vector visual / Vector real (en modulo), de manera  */
/* que para calcular el vector visual para dibujar tenemos que           */
/* hacer la operacion v_visual = vector_real*FVV                         */
#define FVV   5.0

/*-----------------------*/
/* ESTRUCTURAS DE DATOS  */
/*-----------------------*/

/* Estructura para cada particula */
typedef struct particula_s {
  /*-- Vector de posicion --*/
  gdouble x;
  gdouble y;

  /*-- Vector de posicion en el instante anterior -- */
  gdouble xold;
  gdouble yold;

  /*-- Vector velocidad (cinematica directa) --*/
  gdouble vx;
  gdouble vy;

  /*-- Vector velocidad (cinematica inversa) --*/
  gdouble vx_ci;
  gdouble vy_ci;

  /*-- Informacion para el interfaz --*/
  gboolean press;          /* Boton del mouse apretado sobre ella              */
  gboolean change_vel;     /* Cambio en el vector velocidad                    */
  GnomeCanvasGroup *grupo; /* Grupo al que pertenece la particula              */
  GnomeCanvasItem *vel;    /* Dibujo del vector de velocidad, Cinemat. Directa */
  GnomeCanvasItem *vel_ci; /* Dibujo del vector de velocidad, Cinemat. Inv.    */
  GnomeCanvasItem *num;    /* Dibujo del numero de particula                   */


} particula_t;

/*--------------------*/
/*    PROTOTIPOS      */
/*--------------------*/
static void about(GtkWidget *widget, gpointer data);
static void toggle_boton(GtkWidget *widget,gpointer data);
static void toggle_check_boton(GtkWidget *widget,gpointer data);
static void univ_update_particulas(gboolean futuro);
static void univ_init();

/*----------------------*/
/* VARIABLES DEL MODULO */
/*----------------------*/

/*-- Variables para el modelado del universo -- */
static particula_t particula[MAX_PARTICULAS]; /* Particulas */
static gint     cd_tiempo;      /* Tiempo de simulacion para Cinematica Directa */
static gint     ci_tiempo;      /* Tics de reloj entre comprobaciones de la CI  */
static gboolean cd_simu_futuro; /* Direccion de la simulacion: PASADO/FUTURO    */

/* -- Temporizador -- */
static int temporizador;

static gdouble pixel_per_unit=PIXELS_PER_UNIT;

/*-- Variables para GNOME */
static gchar app_id[] = {"Newton"};
static GnomeCanvas *canvas;
static GnomeApp *main_window;
static GtkWidget *app_bar;
static GtkWidget *toggle_vel;

/*************************************/
/* Parametros pasados por el usario  */
/*************************************/

/*-- Variables donde almacenar los Parametros pasados por el usuario -- */
static gboolean flag;  /* -- Flag de test */

/* Descripcion de los parametros que puede pasar el usuario */
struct poptOption opciones[]={
  {"flag",'h',POPT_ARG_NONE, &flag, 0, "Activar la opcion Flag", NULL},
  {NULL, '\0', 0, NULL, 0, NULL, NULL}
};

/*********************************/
/* Estructura del menu principal */
/*********************************/
/*-- MENU FILE --*/
static GnomeUIInfo file_menu[] = {
  GNOMEUIINFO_MENU_EXIT_ITEM(gtk_main_quit,NULL),
  GNOMEUIINFO_END
};

/*-- MENU HELP --*/
static GnomeUIInfo help_menu[] = {
  GNOMEUIINFO_MENU_ABOUT_ITEM(about, NULL),
  GNOMEUIINFO_END
};

/*-- MENU VIEW --*/
static GnomeUIInfo view_menu[] = {
  {GNOME_APP_UI_TOGGLEITEM,
    "Vectores de velocidad",
    "Mostrar/ocultar vectores velocidad",
    toggle_check_boton,"1",0,0},
  {GNOME_APP_UI_TOGGLEITEM,
    "Numeros de particulas",
    "Mostrar/Ocultar los numeros de las particulas",
    toggle_check_boton,"2",0,0},
   {GNOME_APP_UI_TOGGLEITEM,
    "Cinematica inversa",
    "Mostrar/Ocultar vector velocidad de la cinematica inversa",
    toggle_check_boton,"3",0,0},
  GNOMEUIINFO_END
};

static GnomeUIInfo main_menu[] = {
  GNOMEUIINFO_MENU_FILE_TREE (file_menu),
  GNOMEUIINFO_SUBTREE("View",view_menu),
  GNOMEUIINFO_MENU_HELP_TREE(help_menu),
  GNOMEUIINFO_END
};

/*----------------------------*/
/* FUNCIONES DE RETROLLAMADA  */
/*----------------------------*/
void main_quit(GtkWidget *window, gpointer data)
{
  gtk_main_quit();
}

static void about(GtkWidget *widget, gpointer data)
/*************************/
/* ABOUT, del menu HELP  */
/*************************/
{
  static GtkWidget* dialog = NULL;

  /* Lista de autores */
  const gchar *authors[] = {
      "Juan Gonzalez <juan@iearobotics.com>",
      NULL
  };

  if(dialog) {
    gtk_widget_show_now(dialog);
    gdk_window_raise(dialog->window);
    return;
  }

  dialog = gnome_about_new(
            "Newton", VERSION,
            "Cinematica de particulas. Marzo-2002",
             authors, "Licencia GPL",
             NULL);

  gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(main_window));
  gtk_signal_connect(GTK_OBJECT(dialog), "destroy",
                      GTK_SIGNAL_FUNC(gtk_widget_destroyed), &dialog);

  gtk_widget_show(dialog);
}

static void actualizar_items(void)
/*********************************************************/
/* Re-calcular las posiciones de los "items" del CANVAS  */
/*********************************************************/
{
  gint i;
  gdouble x,y;
  gdouble vx,vy;
  GnomeCanvasPoints *points;

  for (i=0; i<MAX_PARTICULAS; i++) {

    /* Obtener las coordenadas del centro de la particula  */
    /* que se encuentra en el CANVAS                       */
    gtk_object_get(
      GTK_OBJECT(particula[i].grupo),
      "x", &x,
      "y", &y,
      NULL);

    /* Calcular el vector velocidad, como la variacion del */
    /* vector de posicion: v=rf-ri                         */
    vx=particula[i].x - x;  /* Componente x */
    vy=particula[i].y - y;  /* Componente y */

    /* Mover la particula (y su grupo) a la nueva posicion */
    gnome_canvas_item_move(GNOME_CANVAS_ITEM(particula[i].grupo),vx,vy);

    /* Dibujar el nuevo vector velocidad de cinematica directa */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=particula[i].vx*FVV;
    points->coords[3]=particula[i].vy*FVV;

    gnome_canvas_item_set(
         particula[i].vel,
        "points", points,
         NULL);
    gnome_canvas_points_free(points);

    /* Dibujar el vector velocidad de cinematica inversa */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=(particula[i].vx_ci*FVV);
    points->coords[3]=(particula[i].vy_ci*FVV);

    gnome_canvas_item_set(
         particula[i].vel_ci,
        "points", points,
         NULL);
    gnome_canvas_points_free(points);

  }
}


static gboolean particula_evento(GnomeCanvasItem *item, GdkEvent *event, gpointer data)
/****************************************************/
/* Gestion de eventos de las particulas del canvas  */
/****************************************************/
{
  gint i;
  gdouble x,y;
  gdouble modulo;

  /* Obtener la particula a la que se ha accedido */
  i = GPOINTER_TO_INT(data);

  /* Obtener las coordenadas del raton */
  x = event->motion.x;
  y = event->motion.y;

  /*------------------------------------------------------*/
  /* Boton apretado sobre los elementos de la particula i */
  /*------------------------------------------------------*/
  if(event->type == GDK_BUTTON_PRESS && event->button.button==1) {

    /* Calcular el modulo del vector que une la posicion del  */
    /* raton con el centro de la particula                    */
    modulo=sqrt(pow(x-particula[i].x,2)+pow(y-particula[i].y,2));

    /* Determinar que elemento es el seleccionado */
    if (modulo<=(gdouble)DIAMETRO/2) { /* Particula seleccionada */
      particula[i].press=TRUE;
    }
    else {   /* Vector seleccionado */
      particula[i].change_vel=TRUE;
    }
    return TRUE;
  }

  /*-----------------------------------------------------*/
  /* MOVIMIENTO DE LOS VECTORES DE LA CINEMATICA DIRECTA */
  /*-----------------------------------------------------*/
  if (particula[i].change_vel && event->type == GDK_MOTION_NOTIFY) {
    particula[i].vx=(x-particula[i].x)/FVV;
    particula[i].vy=(y-particula[i].y)/FVV;
    actualizar_items();
    return TRUE;
  }

  /*-----------------------------*/
  /* MOVIMIENTO DE LA PARTICULA  */
  /*-----------------------------*/
  if (particula[i].press && event->type == GDK_MOTION_NOTIFY) {
     particula[i].x=x;
     particula[i].y=y;
     /* Redibujar */
     actualizar_items();

     return TRUE;
   }

   /*----------------*/
   /* BOTON SOLTADO  */
   /*----------------*/
   if (event->type == GDK_BUTTON_RELEASE) {
     particula[i].press=FALSE;
     particula[i].change_vel=FALSE;
     return TRUE;
   }

  /* No capturado, devolver FALSE */
  return FALSE;
}


static gboolean univ_main_timer(gpointer data)
/************************************************************/
/* FUNCION DE RETRO-LLAMADA DEL TEMPORIZADOR PRINCIPAL      */
/* Este temporizador cuenta los TICS de reloj del universo  */
/************************************************************/
{
  gint i;

  /*-----------------------------------------------------*/
  /* Aplicar la cinematica directa, si se esta simulando */
  /*-----------------------------------------------------*/
  if (cd_tiempo>0) {
    cd_tiempo--;  /* Un tic menos le queda a la simulacion */

    /* Actualizar el estado del universo */
    univ_update_particulas(cd_simu_futuro);

    /* Actualizar los objetos del CANVAS con el nuevo estado del universo */
    actualizar_items();

    /* Comprobar si ha finalizado la simulacion para indicarlo */
    if (cd_tiempo==0)
      gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Simulacion finalizada!!");
  }

  /*------------------------------------*/
  /* Aplicar la cinematica inversa      */
  /*------------------------------------*/
  ci_tiempo--;
  if (ci_tiempo==0) {

    /* Tiempo transcurrido. Recalcular los vectores de la CI */
    for (i=0; i<MAX_PARTICULAS; i++) {

      /* Calcular el vector de velocidad de la cinematica inversa */
      particula[i].vx_ci=(particula[i].x - particula[i].xold)/(gdouble)TICS_CI;
      particula[i].vy_ci=(particula[i].y - particula[i].yold)/(gdouble)TICS_CI;

      /* Almacenar la nueva posicion */
      particula[i].xold=particula[i].x;
      particula[i].yold=particula[i].y;
    }
    actualizar_items();

    //g_print(">ci(%f,%f), cd(%f,%f)\n",(particula[0].vx_ci), (particula[0].vy_ci),
    //     (particula[0].vx),(particula[0].vy));

    /* Inicializar contador */
    ci_tiempo=TICS_CI;
  }

  return TRUE;
}


void toggle_check_boton(GtkWidget *widget,gpointer data)
/**************************************************/
/* FUNCION DE RETROLLAMADA DE OPCIONES CHECK_MENU */
/**************************************************/
{
  int n;
  int activo;
  char cad[80];
  int i;

  activo = (GTK_CHECK_MENU_ITEM(widget)->active);

  n=atoi((char *)data);

  switch(n) {

    /* MENU VIEW: Show vectores ON/OFF */
    case 1:
      if (activo) {
        sprintf (cad,"Vectores de velocidad ON");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_show(particula[i].vel);
      } else {
        sprintf (cad,"Vectores de Velocidad OFF");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_hide(particula[i].vel);
      }
      gnome_appbar_set_status(GNOME_APPBAR(app_bar),cad);
      break;

    /* MENU VIEW: Mostrar numeros de particulas */
    case 2:
       if (activo) {
        sprintf (cad,"Numero de particulas ON");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_show(particula[i].num);
      } else {
        sprintf (cad,"Numero de particulas OFF");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_hide(particula[i].num);
      }
      gnome_appbar_set_status(GNOME_APPBAR(app_bar),cad);
      break;
      /* MENU VIEW: Vector velocidad de cinematica inversa */
    case 3:
      if (activo) {
        sprintf (cad,"Cinematica inversa ON)\n");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_show(particula[i].vel_ci);
      } else {
        sprintf (cad,"Cinematica inversa OFF)\n");
        for (i=0; i<MAX_PARTICULAS; i++)
          gnome_canvas_item_hide(particula[i].vel_ci);
      }
      break;

  }

}

void toggle_boton(GtkWidget *widget,gpointer data)
/*************************************************************/
/* FUNCION DE RETROLLAMADA DE BOTONES TOGGLE                 */
/* Se llaman cuando hay un cambio en el estado               */
/*************************************************************/
{
  int n;
  int activo;

  activo = (GTK_TOGGLE_BUTTON(widget)->active);

  n=atoi((char *)data);
  g_print("Toggle Boton: %d\n",n);

}

void main_boton(GtkWidget *widget,gpointer data)
/*************************************************/
/* FUNCION DE RETROLLAMADA DE BOTONES NORMALES   */
/*************************************************/
{
  int n;

  n=atoi((char *)data);

  switch(n) {
    /* Reset del tiempo. t=0 */
    case 1:
       univ_init();
       actualizar_items();
       gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Estado inicial");
       break;

    /* Retroceder un instante de tiempo */
    case 2:
       gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Simulando...");
       cd_tiempo=1;
       cd_simu_futuro=FALSE;
       break;

    /* Avanzar un instante de tiempo hacia el futuro */
    case 3:
       gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Simulando...");
       cd_tiempo=1;
       cd_simu_futuro=TRUE;
       break;

    /* simulacion hacia el pasado */
    case 4:
       gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Simulando...");
       cd_tiempo=SIMULATION_TIME;
       cd_simu_futuro=FALSE;
       break;

    /* simulacion hacia el futuro */
    case 5:
       gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Simulando...");
       cd_tiempo=SIMULATION_TIME;
       cd_simu_futuro=TRUE;
       break;

    /* ZOOM + */
    case 6:
      pixel_per_unit+=ZOOM_INC;
      gnome_canvas_set_pixels_per_unit (GNOME_CANVAS (canvas), (double) pixel_per_unit);
      gnome_appbar_set_status(GNOME_APPBAR(app_bar),"ZOOM +");
      break;

    /* ZOOM - */
    case 7:
      pixel_per_unit-=ZOOM_INC;
      gnome_canvas_set_pixels_per_unit (GNOME_CANVAS (canvas), (double) pixel_per_unit);
      gnome_appbar_set_status(GNOME_APPBAR(app_bar),"ZOOM -");
      break;

  }


}

/*------------------*/
/*   C A N V A S    */
/*------------------*/

void crear_canvas_items()
/***********************************************************************/
/* Crear todos los items del CANVAS: particulas y sus items asociados  */
/***********************************************************************/
{
  GnomeCanvasItem *item;
  GnomeCanvasPoints *points;
  gchar cad[5];
  gint i;

  for (i=0; i<MAX_PARTICULAS; i++) {

    /* Crear los grupo de la particula i */
    item = gnome_canvas_item_new(
       gnome_canvas_root(canvas),
       gnome_canvas_group_get_type(),
       "x", particula[i].x,
       "y", particula[i].y,
        NULL);

    /* Guardar grupo */
    particula[i].grupo=GNOME_CANVAS_GROUP(item);

    /* Funcion de retro-llamada de la particula y sus items asociados */
    gtk_signal_connect(GTK_OBJECT(item), "event",
                       GTK_SIGNAL_FUNC(particula_evento),
                       GINT_TO_POINTER(i));

    /* Crear PARTICULA                                          */
    /* Dentro del grupo de cada particula, el origen esta en el */
    /* centro de la particula                                   */
    item=gnome_canvas_item_new(particula[i].grupo,
      gnome_canvas_ellipse_get_type(),
       "outline_color", "dark gray",
       "x1",(gdouble)(-DIAMETRO/2),
       "y1",(gdouble)(-DIAMETRO/2),
       "x2",(gdouble)(DIAMETRO/2),
       "y2",(gdouble)(DIAMETRO/2),
       "fill_color", "red",
       "outline_color", "red",
       "width_pixels", 1,
       NULL);

    /* Crear el texto con el numero de la particula */
    sprintf (cad,"%d",i);
    particula[i].num = gnome_canvas_item_new (particula[i].grupo, gnome_canvas_text_get_type(),
       "text", cad, "x", (gdouble) -DIAMETRO, "y",(gdouble) DIAMETRO,
       "anchor", GTK_ANCHOR_WEST, "font", "fixed",
       "fill_color", "red",NULL);

    /* Inicialmente no visualizar numero particula */
    gnome_canvas_item_hide(particula[i].num);

    /* Vector velocidad (Cinematica directa) */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=particula[i].vx;
    points->coords[3]=particula[i].vy;

    particula[i].vel=gnome_canvas_item_new(particula[i].grupo, gnome_canvas_line_get_type(),
      "points", points, "fill_color", "black",
      "width_units", 0.0, "join_style", GDK_CAP_BUTT,
      "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
      "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
    gnome_canvas_points_free(points);

    /* Inicialmente no visualizar vectores velocidad */
    gnome_canvas_item_hide(particula[i].vel);

    /* Vector velocidad (Cinematica inversa) */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=particula[i].vx_ci;
    points->coords[3]=particula[i].vy_ci;
    particula[i].vel_ci=gnome_canvas_item_new(particula[i].grupo, gnome_canvas_line_get_type(),
      "points", points, "fill_color", "black",
      "width_units", 0.0, "join_style", GDK_CAP_BUTT,
      "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
      "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
    gnome_canvas_points_free(points);

    /* Inicialmente no visualizar vectores de velocidad CI */
    gnome_canvas_item_hide(particula[i].vel_ci);
  }

}

static void univ_update_particulas(gboolean futuro)
/****************************************************************************/
/* Calcular el estado de las particulas en el siguiente instante de tiempo  */
/* ENTRADAS:                                                                */
/*    -Futuro: TRUE: Avanzar un instante de tiempo                          */
/*             FALSE: Retroceder un instante de tiempo                      */
/****************************************************************************/
{
  gint i;
  gdouble svx,svy;

  /* Calcular el "signo" de la velocidad */
  /* Si vamos al futuro los vectores de velocidad son los de  */
  /* las particulas. Si vamos al pasado son los mismos pero   */
  /* cambiados de signo.                                      */
  if (futuro) {
    svx=1.0;
    svy=1.0;
  }
  else {
    svx=-1.0;
    svy=-1.0;
  }

  for (i=0; i<MAX_PARTICULAS; i++) {
    /* Actulizar los vectores de posicion */
    particula[i].x+=(particula[i].vx)*svx;
    particula[i].y+=(particula[i].vy)*svy;
  }
}

void univ_init()
/*****************************/
/* Inicializar el universo   */
/*****************************/
{

  /* Inicializar las particulas */
  particula[0].x=particula[0].xold=20.0;
  particula[0].y=particula[0].yold=20.0;
  particula[0].vx=2.0;
  particula[0].vy=2.0;
  particula[0].vx_ci=0.0;
  particula[0].vy_ci=0.0;
  particula[0].press=FALSE;
  particula[0].change_vel=FALSE;

  particula[1].x=particula[1].xold=50.0;
  particula[1].y=particula[1].yold=50.0;
  particula[1].vx=3.0;
  particula[1].vy=0.0;
  particula[1].vx_ci=0.0;
  particula[1].vy_ci=0.0;
  particula[1].press=FALSE;
  particula[1].change_vel=FALSE;

  /* Inicializar variables globales */
  cd_tiempo=0;
  ci_tiempo=TICS_CI;
  cd_simu_futuro=TRUE;
}

/*--------------------*/
/*  CREAR INTERFAZ    */
/*--------------------*/

static GnomeApp *crear_main_window(void)
/***********************************/
/* Creacion del interfaz principal */
/***********************************/
{

  GtkWidget *vbox_main;
  GtkWidget *label;
  GtkWidget *app;
  GtkWidget *toolbar;
   GtkWidget *flecha;

  /* -- Ventana principal -- */
  app = gnome_app_new(app_id, "Newton");
  gtk_window_set_default_size(GTK_WINDOW(app),320,200);
  gtk_signal_connect (GTK_OBJECT (app),"destroy",
                      GTK_SIGNAL_FUNC (main_quit),NULL);

  /*-- Menus --*/
  gnome_app_create_menus(GNOME_APP(app),main_menu);

  /*-- Barra de estado -- */
  app_bar=gnome_appbar_new(FALSE,TRUE,GNOME_PREFERENCES_USER);
  gnome_app_set_statusbar(GNOME_APP(app), app_bar);
  gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Hola!!!");

  /* Hacer que las ayudas del menu aparezcan en la barra de estado */
  gnome_app_install_menu_hints(GNOME_APP(app), main_menu);

  /* Crear vbox */
  vbox_main=gtk_vbox_new(FALSE,0);

  /* El contenido de la ventana es un contenedor vertical */
  gnome_app_set_contents(GNOME_APP(app), GTK_WIDGET(vbox_main));

  /* Crear un canvas */
  canvas = GNOME_CANVAS(gnome_canvas_new());
  gnome_canvas_set_scroll_region(canvas, 0.0, 0.0,310.0,310.0);
  gnome_canvas_set_pixels_per_unit(canvas, pixel_per_unit);
  gtk_widget_set_usize(GTK_WIDGET(canvas),310.0,310.0);

  /* A�adir CANVAS al empaquetado vertical */
  gtk_box_pack_start(GTK_BOX(vbox_main), GTK_WIDGET(canvas), FALSE, TRUE, 0);

  /* A�adir barra de herramientas */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar),0);
  gtk_box_pack_start(GTK_BOX(vbox_main), toolbar,FALSE,FALSE,0);

    /* Boton de prueba (TOGGLE) */
    label = gtk_label_new("TEST");
    toggle_vel=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                NULL,
                                NULL,"Pruebas",NULL,
                                label,
                                (GtkSignalFunc) toggle_boton,"1");

    /* Boton de Reset del tiempo */
    label = gtk_label_new("t=0");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"Ir al Estado inicial",NULL,
                                label,
                                (GtkSignalFunc) main_boton,"1");

    /* Retroceder un instante de tiempo hacia el pasado */
    flecha=gtk_arrow_new(GTK_ARROW_LEFT,GTK_SHADOW_OUT);
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              NULL,"Instante de tiempo anterior",NULL,
                              flecha,
                              (GtkSignalFunc) main_boton,"2");

    /* Pasar al siguiente instante de tiempo */
    flecha=gtk_arrow_new(GTK_ARROW_RIGHT,GTK_SHADOW_OUT);
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              NULL,"Siguiente instante de tiempo",NULL,
                              flecha,
                              (GtkSignalFunc) main_boton,"3");

    /* Boton de Simulacion hacia el pasado */
    label = gtk_label_new("Go-");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"Comenzar la simulacion",NULL,
                                label,
                                (GtkSignalFunc) main_boton,"4");

    /* Boton de Simulacion hacia el futuro */
    label = gtk_label_new("Go+");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"Comenzar la simulacion",NULL,
                                label,
                                (GtkSignalFunc) main_boton,"5");
    /* ZOOM IN */
    label = gtk_label_new("Zoom+");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"ZOOM+",NULL,
                                label,
                                (GtkSignalFunc) main_boton,"6");

    /* ZOOM OUT */
    label = gtk_label_new("Zoom-");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"ZOOM-",NULL,
                                label,
                                (GtkSignalFunc) main_boton,"7");

  return GNOME_APP(app);
}


/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{

  poptContext contexto;


  /* Inicializar GNOME, teniendo en cuenta los parametros pasados por el user */
  gnome_init_with_popt_table (app_id, VERSION, argc,argv, opciones, 0, &contexto);
  poptFreeContext (contexto);

  /*-- Comprobar las opciones pasadas por el usuario --*/
  if (flag) g_print ("Se ha invocado con la opcion Flag..\n");

  /*------------------------*/
  /*  Crear el interfaz     */
  /*------------------------*/
  main_window=crear_main_window();
  gtk_widget_show_all(GTK_WIDGET(main_window));

  /*-- Inicializar el universo --*/
  univ_init();

  /* A�adir objetos al canvas */
  crear_canvas_items();

   /* Establecer estado inicial de los botones */
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggle_vel),TRUE);

  /* Establecer estado inicial de check menu items */
  /* Estado de los vectores de velocidad */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(view_menu[0].widget),TRUE);
  /* Estado de los numeros de las particulas */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(view_menu[1].widget),FALSE);
  /* Estado de los numeros de las particulas */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(view_menu[2].widget),TRUE);

  temporizador=gtk_timeout_add(DTD, univ_main_timer, "2");

  /*-- Que comience la fiesta!!! -- */
  gtk_main();

  return 0;
}




