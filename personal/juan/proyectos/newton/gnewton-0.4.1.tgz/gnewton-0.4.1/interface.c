/*****************************************************/
/* interface.c    april 2002                         */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#include <glade/glade.h>
#include <glade/glade-xml.h>
#include <gnome.h>

#include "univ.h"
#include "particle.h"
#include "interface.h"
#include "callback.h"

extern interface_t interface;

/*---------------------------------------------------------*/
/*          I M P L E M E N T A T I O N                    */
/*---------------------------------------------------------*/

void create_app(interface_t *ifaz)
{
  GladeXML *xml;
  GtkWidget *app;
  GtkWidget *button;
  GtkWidget *menu;
  GtkWidget *spin;


  /* Leer el interfaz en XML */
  xml = glade_xml_new ("./gnewton.glade", "app1");

  /* Obtener el widget de la aplicacion */
  app = glade_xml_get_widget (xml, "app1");

  gtk_window_set_default_size(GTK_WINDOW(app),320,200);
  gtk_signal_connect (GTK_OBJECT (app),"destroy",
                      GTK_SIGNAL_FUNC (main_quit),NULL);

  ifaz->main_window=GNOME_APP(app);

  /*-- STATUS BAR -- */
  ifaz->app_bar=glade_xml_get_widget(xml,"appbar1");
  gnome_appbar_set_status(GNOME_APPBAR(ifaz->app_bar),"Hola!!!");

  /* Hints will appear at the status bar */
  menu=glade_xml_get_widget(xml,"menubar1");
  //gnome_app_install_menu_hints(GNOME_APP(app), GTK_MENU(menu));


  /* Configure the CANVAS */
  ifaz->canvas = GNOME_CANVAS(glade_xml_get_widget(xml,"canvas1"));
  gnome_canvas_set_scroll_region(ifaz->canvas, 0.0, 0.0,600.0,600.0);
  gnome_canvas_set_pixels_per_unit(ifaz->canvas, ifaz->pixel_per_unit);


  /*-----------------------------------------------*/
  /* Connect the buttons to its callback functions */
  /*-----------------------------------------------*/

  /*-----------*/
  /* TOOLBAR   */
  /*-----------*/
  /* ADD PARTICLE BUTTON */
  button = glade_xml_get_widget (xml, "button_add");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"1");

  /* T- BUTTON */
  button = glade_xml_get_widget (xml, "button_t-");
  //gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"2");

  /* T+ BUTTON */
  button = glade_xml_get_widget (xml, "button_t+");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"3");

  /* Toward past simulation button */
  button = glade_xml_get_widget (xml, "button_exec-");
  //gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"4");

  /* Toward future simulation button */
  button = glade_xml_get_widget (xml, "button_exec+");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"5");

  /* ZOOM IN */
  button = glade_xml_get_widget (xml, "button_zoom+");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"6");

  /* ZOOM OUT */
  button = glade_xml_get_widget (xml, "button_zoom-");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"7");

  /*----------------*/
  /* BOTOM TOOLBAR  */
  /*----------------*/
  /* Duration of the simulation */
  spin=glade_xml_get_widget(xml,"spin_tiempo_simu");
  ifaz->simulation_time=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->simulation_time),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"1");

  /* Reset */
  button = glade_xml_get_widget(xml,"button_reset");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"8");

  /* SET */
  button = glade_xml_get_widget(xml,"button_set_state");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",GTK_SIGNAL_FUNC(main_button),"9");

  /*------------------*/
  /* VECTORS          */
  /*------------------*/
  /* Position vector */
  spin=glade_xml_get_widget(xml,"spin_work_posx");
  ifaz->work_posx=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_posx),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"2");

  spin=glade_xml_get_widget(xml,"spin_work_posy");
  ifaz->work_posy=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_posy),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"3");

  /* Velocity vector */
  spin=glade_xml_get_widget(xml,"spin_work_velx");
  ifaz->work_velx=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_velx),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"4");

  spin=glade_xml_get_widget(xml,"spin_work_vely");
  ifaz->work_vely=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_vely),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"5");

  /* Celerity vector */
  spin=glade_xml_get_widget(xml,"spin_work_celx");
  ifaz->work_celx=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_celx),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"6");

  spin=glade_xml_get_widget(xml,"spin_work_cely");
  ifaz->work_cely=gtk_spin_button_get_adjustment(GTK_SPIN_BUTTON(spin));
  gtk_signal_connect(GTK_OBJECT(ifaz->work_cely),
                     "value_changed",GTK_SIGNAL_FUNC(spin_button),"7");


  /****************************/
  /* Connect the menu signals */
  /****************************/
  /*-----------*/
  /* View Menu */
  /*-----------*/
  ifaz->toggle_vel = glade_xml_get_widget (xml, "view_vel_vect");
  gtk_signal_connect(GTK_OBJECT(ifaz->toggle_vel),"toggled",GTK_SIGNAL_FUNC(toggle_check_boton),"1");

  ifaz->toggle_num = glade_xml_get_widget (xml, "view_num");
  gtk_signal_connect(GTK_OBJECT(ifaz->toggle_num),"toggled",GTK_SIGNAL_FUNC(toggle_check_boton),"2");

  ifaz->toggle_ik_vel = glade_xml_get_widget (xml, "view_ik_vel_vect");
  gtk_signal_connect(GTK_OBJECT(ifaz->toggle_ik_vel),"toggled",GTK_SIGNAL_FUNC(toggle_check_boton),"3");

  /*-------------*/
  /* File Menu   */
  /*-------------*/
  menu = glade_xml_get_widget (xml, "file_quit");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",GTK_SIGNAL_FUNC(main_quit),"1");

  /*--------------*/
  /* Help Menu    */
  /*--------------*/
  menu = glade_xml_get_widget (xml,"about1");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",GTK_SIGNAL_FUNC(help_about),NULL);

  gtk_object_unref (GTK_OBJECT (xml));

  gtk_widget_show_all(app);
}

GtkWidget *create_about()
/*********************************/
/* Create the about window       */
/*********************************/
{
  GladeXML *xml;
  GtkWidget *about;

  xml = glade_xml_new ("gnewton.glade", "about");
  about = glade_xml_get_widget (xml, "about");

  gtk_object_unref (GTK_OBJECT (xml));

  return about;

}

void interface_show_particle_info(int id)
/***********************************************/
/* Show the information of one particle        */
/***********************************************/
{
  particle *part;

  part=univ_get_particle(id);
  if (part==NULL) return;

  gtk_adjustment_set_value(interface.work_posx, Pcl_GetWorkPos_x(part));
  gtk_adjustment_set_value(interface.work_posy, Pcl_GetWorkPos_y(part));
  gtk_adjustment_set_value(interface.work_velx, Pcl_GetWorkVeloc_x(part));
  gtk_adjustment_set_value(interface.work_vely, Pcl_GetWorkVeloc_y(part));
  gtk_adjustment_set_value(interface.work_celx, Pcl_GetWorkCel_x(part));
  gtk_adjustment_set_value(interface.work_cely, Pcl_GetWorkCel_y(part));

}



