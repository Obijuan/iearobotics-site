/*****************************************************/
/* debug.c    april 2002                             */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/


#include <gnome.h>


#include "vector.h"
#include "particle.h"
#include "particle_private.h"
#include "debug.h"

void vector_print(vector2D *v)
/************************/
/* Print the vector     */
/************************/
{
  g_print("(%.1f , %.1f)",v->cords.x,v->cords.y);
}

void particle_private_print(particle_private_t *p)
/*******************************************/
/* Print the private part of the particle  */
/*******************************************/
{
  g_print("  IK_VEL: ");
  vector_print(p->ik_vel);
  g_print("\n");
}

void particle_print(particle *p)
/*****************************/
/* Print the data particle   */
/******************************/
{
  g_print("--------------\n");
  g_print("Particula: %d\n",p->id);
  g_print("  ESTADO INICIAL:");
  g_print("  pos: ");
    vector_print(&p->init.position);
  g_print("  Vel: ");
    vector_print(&p->init.velocity);
  g_print("  Acel: ");
    vector_print(&p->init.celerity);
  g_print("\n");

  g_print("  ESTADO ACTUAL (WORKING)   :");
  g_print("  pos: ");
    vector_print(&p->working.position);
  g_print("  Vel: ");
    vector_print(&p->working.velocity);
  g_print("  Acel: ");
    vector_print(&p->working.celerity);
  g_print("\n");

  g_print("  ESTADO TEMPORAL  :");
  g_print("  pos: ");
    vector_print(&p->tmp.position);
  g_print("  Vel: ");
    vector_print(&p->tmp.velocity);
  g_print("  Acel: ");
    vector_print(&p->tmp.celerity);
  g_print("\n");

  g_print("  PRIVATE: ");
  if (PPARTICLE_PRIVATE(p)==NULL) g_print ("NULL!\n");
  else particle_private_print(PPARTICLE_PRIVATE(p));

  g_print("--------------\n");

}




