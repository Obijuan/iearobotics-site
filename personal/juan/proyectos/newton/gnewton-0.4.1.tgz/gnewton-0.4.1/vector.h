/*****************************************************/
/* NEWTON    (c) Carlos Jesus Venegas Arrabe.        */
/*                                                   */
/* Vector manipulate module.                         */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#ifndef __NEWTON_VECTOR__
#define __NEWTON_VECTOR__

#include "types.h"

/* Numeric constant PI */
#define PI M_PI


/* Macross to rapid access at the member of structures */
#define v_y(Y) (Y.cords.y)
#define v_x(X) (X.cords.x)
#define v_mod(M) (M.module)


/* ******************************************************  */
/* point2D                                                 */
/* -------                                                 */
/*                                                         */
/* This struture define a point in a 2d coordenate system. */
/*                                                         */
/* Members:                                                */
/*                                                         */
/*          x => coordinate in x axys.                     */
/*          y => coordinate in y axys.                     */
/*                                                         */
/* ******************************************************* */

typedef struct {

  double x,y;

}point2D, *ppoint2D;


/* *******************************************************  */
/* vector2D                                                 */
/* --------                                                 */
/*                                                          */
/* This struture define a vector in a 2d coordenate system. */
/*                                                          */
/* Members:                                                 */
/*                                                          */
/*         cords  => origin's vector coordinates.           */
/*         module => vector's module.                       */
/*                                                          */
/* ******************************************************** */

typedef struct{

  point2D cords;
  double module;
  
}vector2D, *pvector2D;



/* *************************************************************** */
/* Vector_New                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to create a new vector.                                */
/*                                                                 */
/* Arguments:                                                      */
/*            x => init x coordenate.                              */
/*            y => init y coordenate.                              */
/*                                                                 */
/* Return:                                                         */
/*            pvector2D => pointer to vector2D structure.          */
/*                                                                 */
/* *************************************************************** */

pvector2D Vector_New(double x,double y);


/* *************************************************************** */
/* Vector_Assign                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to assign vector to other.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1=> the vector to copy in.                          */
/*            v2=> vector to duplicate.                            */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Assign(pvector2D v1, pvector2D v2);


/* *************************************************************** */
/* Vector_Set_Comp                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's components.                         */
/*                                                                 */
/* Arguments:                                                      */
/*            x,y => components to the vector.                     */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_Comp(double x, double y, pvector2D v1);


/* *************************************************************** */
/* Vector_Get_Comp                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's components.                            */
/*                                                                 */
/* Arguments:                                                      */
/*            x,y => components to the vector.                     */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Get_Comp(double *x, double *y, pvector2D v1);


/* *************************************************************** */
/* Vector_Set_x                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's x component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            x => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_x(double x, pvector2D v1);


/* *************************************************************** */
/* Vector_Set_x                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's x component .                          */
/*                                                                 */
/* Arguments:                                                      */
/*            x => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_x(pvector2D v1);

/* *************************************************************** */
/* Vector_Set_y                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's y component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            y => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS  Vector_Set_y(double y, pvector2D v1);


/* *************************************************************** */
/* Vector_Get_y                                                    */ 
/* ------------                                                    */
/*                                                                 */
/* Function to get vector's y component .                          */
/*                                                                 */
/* Arguments:                                                      */
/*            y => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_y(pvector2D v1);


/* *************************************************************** */
/* Vector_Set_mod                                                  */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's module.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_mod(pvector2D v1);

/* *************************************************************** */
/* Vector_Get_mod                                                  */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's module.                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_mod(pvector2D v1);


/* *************************************************************** */
/* Vector_Module                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to calculate the vector's module.                      */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*                                                                 */
/* Return:                                                         */
/*            double => vector's module.                           */
/*                                                                 */
/* *************************************************************** */

double Vector_Module(pvector2D v);


/* *************************************************************** */
/* Vector_Add                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the add of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 + v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Add(pvector2D v1, pvector2D v2, pvector2D result);


/* *************************************************************** */
/* Vector_Sub                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the sub of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 - v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Sub(pvector2D v1, pvector2D v2, pvector2D result);

/* *************************************************************** */
/* Vector_MK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that multiply a vector for a constant.                 */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
STATUS Vector_MK(pvector2D v, double k, pvector2D result);

/* *************************************************************** */
/* Vector_MK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that multiply a vector for a constant.                 */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
STATUS Vector_MK(pvector2D v, double k, pvector2D result);
/* *************************************************************** */
/* Vector_DK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that divide a vector for a constant.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
STATUS Vector_DK(pvector2D v, double k, pvector2D result);

/* *************************************************************** */
/* Vector_Unit                                                     */
/* -----------                                                     */
/*                                                                 */
/* Function that calculate de unitary vector from v1.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector.                                        */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS  Vector_Unit(pvector2D v1, pvector2D result);

/* *************************************************************** */
/* Vector_Dotp                                                     */
/* -----------                                                     */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* algebraic method.                                               */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Dotp(pvector2D v1, pvector2D v2,double *result);


/* *************************************************************** */
/* Vector_DotpMod                                                  */
/* --------------                                                  */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in radians.         */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_DotpMod(pvector2D v1, pvector2D v2,double angle,double *result);

/* *************************************************************** */
/* Vector_AngleDeg                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in degrees.                                   */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_AngleDeg(pvector2D v1, pvector2D v2, double *angle);

/* *************************************************************** */
/* Vector_AngleRad                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors in radians.   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in radians.                                   */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_AngleRad(pvector2D v1, pvector2D v2, double *angle);

/* *************************************************************** */
/* Vector_VectpMod                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate the module of vectorial product , with  */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in radians.         */
/*            result => v1 ^ v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ^ This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_VectpMod(pvector2D v1, pvector2D v2,double angle,double *result);

#endif

