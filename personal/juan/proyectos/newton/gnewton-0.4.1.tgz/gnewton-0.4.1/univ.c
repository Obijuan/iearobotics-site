/*****************************************************/
/* univ.c      Abril 2002                            */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#include <gnome.h>

#include "particle.h"
#include "particle_private.h"
#include "univ.h"
#include "vector.h"
#include "debug.h"

GList *universe=NULL;        /* Universe of the particles */
GList *node;    /* Just for navigating into the universe  */

particle *univ_get_first_particle()
/*************************************************************/
/* Return a pointer to the first particle of the universe    */
/*************************************************************/
{
  if (universe==NULL) return NULL;
  node=universe;
  return node->data;
}

particle *univ_get_next_particle()
/*********************************************************/
/* Return a pointer to the next particle of the universe */
/*********************************************************/
{
  if (node==NULL) return NULL;
  node=node->next;

  if (node==NULL) return NULL;

  return node->data;
}

particle *univ_get_particle(gint num)
/*******************************************************/
/* Get the particle number num.                        */
/* It returns a ponter to that particle                */
/*******************************************************/
{
  particle *part;
  GList *node;

  if (universe==NULL) return NULL;

  /* Get the particle */
  node=g_list_nth(universe,num);

  if (node==NULL) g_print ("NULL!\n");

  part=node->data;

  return part;
}

int univ_add_particle(particle *part)
/****************************************/
/* Add a new particle to the universe   */
/* It returns the number of the particle*/
/****************************************/
{
  int n;

  universe=g_list_append(universe,part);
  n=g_list_length(universe)-1;

  part->id=n;

  return n;
}

void univ_del_particle(guint part_num)
/******************************************/
/* Delete the specified particle          */
/******************************************/
{
  particle *part;

  /* Get the particle */
  part=(g_list_nth(universe,part_num))->data;

  /* Free the list Node */
  //universe=g_list_remove(universe,part);

  /* Free the private zone of the particle */
  particle_private_free(part->userdata);

  /* Free the particle */
  free(part);
}

void univ_destroy()
/************************************************/
/* Eliminate all the particles of the universe  */
/************************************************/
{
  int total;
  int i;

  /* This is NOT optimal!!!  */

  /* Get the number of particle that comprise the universe */
  total=g_list_length(universe);

  g_print("Total: %d\n",total);

  for (i=0; i<total; i++) {
    univ_del_particle(0);
    g_print("Particula %d destruida\n",i);
  }

}

void univ_update_particulas(gboolean futuro)
/****************************************************************************/
/* Calcular el estado de las particulas en el siguiente instante de tiempo  */
/* ENTRADAS:                                                                */
/*    -Futuro: TRUE: Avanzar un instante de tiempo                          */
/*             FALSE: Retroceder un instante de tiempo                      */
/****************************************************************************/
{
  gdouble svx,svy;
  vector2D temp;
  particle *part;

  /* Calcular el "signo" de la velocidad */
  /* Si vamos al futuro los vectores de velocidad son los de  */
  /* las particulas. Si vamos al pasado son los mismos pero   */
  /* cambiados de signo.                                      */
  if (futuro) {
    svx=1.0;
    svy=1.0;
  }
  else {
    svx=-1.0;
    svy=-1.0;
  }

  part=univ_get_first_particle();

  while(part!=NULL) {
    Vector_Add(&(part->working.celerity),&(part->working.velocity),&(part->working.velocity));
    Vector_MK(&(part->working.velocity),svx,&temp);
    Vector_Add(&(part->working.position),&temp,
               &(part->working.position));
    part=univ_get_next_particle();
  }

}


void univ_create()
/****************************************/
/* Create the universe of the particles */
/****************************************/
{
/*  particle *part;
  int n;

  part=Pcl_New(20.0,20.0,2.0,2.0,0.0,0.2);
  Pcl_SetUserdata(part,particle_private_new());
  n=univ_add_particle(part);
  g_print ("Particle %d added\n",n);

  part=Pcl_New(50.0,50.0,3.0,0.0,0.0,0.2);
  Pcl_SetUserdata(part,particle_private_new());
  n=univ_add_particle(part);
  g_print ("Particle %d added\n",n);*/

}

void univ_reset()
/********************************************/
/* Reset all the particles in the universe  */
/********************************************/
{
  GList *node;

  node=universe;
  while (node!=NULL) {
    Pcl_Reset(node->data);
    node=node->next;
  }

}

void univ_set()
/***************************/
/* Set the initial state   */
/***************************/
{
  GList *node;

  node=universe;
  while (node!=NULL) {
    Pcl_Set(node->data);
    node=node->next;
  }
}


void univ_particles_navigate()
/*******************************************/
/* Navigate through the list of particles  */
/*******************************************/
{
  GList *node;

  node=universe;
  while (node!=NULL) {
    g_print(".");
    node=node->next;
  }
  g_print("\n");

}

void univ_print_particles_num()
/**************************************************/
/*  Print all the identification numbers of the   */
/* particles of the universe                      */
/**************************************************/
{
  particle *part;
  GList *node;

  node=universe;
  while (node!=NULL) {
    part=node->data;
    if (part==NULL) g_print("NULL!\n");
    else {
      g_print("->%d",part->id);
    }
    node=node->next;
  }
  g_print("\n");
}



