/*****************************************************/
/* NEWTON    (c) Carlos Jesus Venegas Arrabe.        */
/*                                                   */
/* particle definition module.                       */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#ifndef __NEWTON_PARTICLE__
#define __NEWTON_PARTICLE__

#include "vector.h"
#include "types.h"

typedef struct{

  vector2D position;
  vector2D velocity;
  vector2D celerity;
  void *userdata;

}particle_state, *pparticle_state;

typedef struct{
  int id;   /* Identification number of the particle */
  particle_state init;
  particle_state working;
  particle_state tmp;
  void *userdata;

}particle, *pparticle;


void Pcl_Reset(particle *part);
void Pcl_Set(particle *part);

/* ************************************************************ */
/* Pcl_New                                                      */
/* =======                                                      */
/*                                                              */
/* This function create a new particle.                         */
/*                                                              */
/* Receive:                                                     */
/*            sx,xy => space origin coordinates.                */
/*            ax,ay => celerity origin coordinates(origin       */
/*                     at particle coordinate reference system).*/
/*            vx,vy => velocity origin coordinates(origin at    */
/*                     particle coordinate reference system).   */
/*                                                              */
/* Return:                                                      */
/*            The new particle.                                 */
/*            NULL if an error ocurred.                         */
/*                                                              */
/* ************************************************************ */

pparticle  Pcl_New(double sx,double sy,double vx,double vy,double ax,double ay);


/* ************************************************************************** */
/* ****************** Set the properties of the particles ******************* */
/* ************************************************************************** */

/* *************************************************************** */
/* Pcl_SetInit???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the init field.                                              */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetInitPos(pparticle p,double x, double y);

inline STATUS Pcl_SetInitVeloc(pparticle p,double x, double y);

inline STATUS Pcl_SetInitCel(pparticle p,double x, double y);

inline STATUS Pcl_SetInitUserdata(pparticle p,void *data);


/* *************************************************************** */
/* Pcl_SetWork???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the working field.                                           */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetWorkPos(pparticle p,double x, double y);

inline STATUS Pcl_SetWorkVeloc(pparticle p,double x, double y);

inline STATUS Pcl_SetWorkCel(pparticle p,double x, double y);

inline STATUS Pcl_SetWorkUserdata(pparticle p,void *data);


/* *************************************************************** */
/* Pcl_SetTmp???                                                   */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the tmp field.                                               */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetTmpPos(pparticle p,double x, double y);

inline STATUS Pcl_SetTmptVeloc(pparticle p,double x, double y);

inline STATUS Pcl_SetTmpCel(pparticle p,double x, double y);

inline STATUS Pcl_SetTmpUserdata(pparticle p,void *data);


/* *************************************************************** */
/* Pcl_SetUserdata                                                 */
/* ===============                                                 */
/*                                                                 */
/* This functions sets the user data field.                        */
/*                                                                 */
/* Receive:                                                        */
/*            data=> pointer to the user data. The user manage     */
/*                   this field.                                   */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetUserdata(pparticle p,void *data);


/* ************************************************************************** */
/* ************** Increment  the properties of the particles **************** */
/* ************************************************************************** */

/* *************************************************************** */
/* Pcl_Inc???                                                      */
/* ==========                                                      */
/*                                                                 */
/* This functions increments the position,velocity and celerity    */
/* values.                                                         */
/*                                                                 */
/* Receive:                                                        */
/*            nx,ny => amount to increment.                        */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_IncPos(pparticle p,double nx, double ny);

inline STATUS Pcl_IncVeloc(pparticle p,double nx, double ny);

inline STATUS Pcl_IncCel(pparticle p,double nx, double ny);


/* *********************************************************************** */
/* ******************** Get  properties of the particle ****************** */
/* *********************************************************************** */

/* *************************************************************** */
/* Pcl_GetInit???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the init field.                                              */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetInitPos(pparticle p,double *x, double *y);

inline double Pcl_GetInitPos_x(pparticle p);

inline double Pcl_GetInitPos_y(pparticle p);

inline double Pcl_GetInitPos_module(pparticle p);

inline STATUS Pcl_GetInitVeloc(pparticle p,double *x, double *y);

inline double Pcl_GetInitVeloc_x(pparticle p);

inline double Pcl_GetInitVeloc_y(pparticle p);

inline double Pcl_GetInitVeloc_module(pparticle p);

inline STATUS Pcl_GetInitCel(pparticle p,double *x, double *y);

inline double Pcl_GetInitCel_x(pparticle p);

inline double Pcl_GetInitCel_y(pparticle p);

inline double Pcl_GetInitCel_module(pparticle p);

void *pcl_GetInitUserdata(pparticle p);


/* *************************************************************** */
/* Pcl_GetWork???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the working field.                                           */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetWorkPos(pparticle p,double *x, double *y);

inline double Pcl_GetWorkPos_x(pparticle p);

inline double Pcl_GetWorkPos_y(pparticle p);

inline double Pcl_GetWorkPos_module(pparticle p);

inline STATUS Pcl_GetWorkVeloc(pparticle p,double *x, double *y);

inline double Pcl_GetWorkVeloc_x(pparticle p);

inline double Pcl_GetWorkVeloc_y(pparticle p);

inline double Pcl_GetWorkVeloc_module(pparticle p);

inline STATUS Pcl_GetWorkCel(pparticle p,double *x, double *y);

inline double Pcl_GetWorkCel_x(pparticle p);

inline double Pcl_GetWorkCel_y(pparticle p);

inline double Pcl_GetWorkCel_module(pparticle p);

void* Pcl_GetWorkUserdata(pparticle p);


/* *************************************************************** */
/* Pcl_GetTmp???                                                   */
/* =============                                                   */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the tmp field.                                               */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetTmpPos(pparticle p,double *x, double *y);

inline double Pcl_GetTmpPos_x(pparticle p);

inline double Pcl_GetTmpPos_y(pparticle p);

inline double Pcl_GetTmpPos_module(pparticle p);

inline STATUS Pcl_GetTmpVeloc(pparticle p,double *x, double *y);

inline double Pcl_GetTmpVeloc_x(pparticle p);

inline double Pcl_GetTmpVeloc_y(pparticle p);

inline double Pcl_GetTmpVeloc_module(pparticle p);

inline STATUS Pcl_GetTmpCel(pparticle p,double *x, double *y);

inline double Pcl_GetTmpCel_x(pparticle p);

inline double Pcl_GetTmpCel_y(pparticle p);

inline double Pcl_GetTmpCel_module(pparticle p);

void* Pcl_GetTmpUserdata(pparticle p);


/* *************************************************************** */
/* Pcl_GetUserdata                                                 */
/* ===============                                                 */
/*                                                                 */
/* This function gets the pointer to the general userdata memory   */
/*                                                                 */
/* Receive:                                                        */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*           address to the general user data field.               */
/*                                                                 */
/* *************************************************************** */

inline void* Pcl_GetUserdata(pparticle p);

#endif
