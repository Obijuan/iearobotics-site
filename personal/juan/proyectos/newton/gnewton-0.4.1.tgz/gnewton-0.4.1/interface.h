/*****************************************************/
/* interface.h    April, 2002                        */
/*---------------------------------------------------*/
/* This project is under GPL license                 */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

/*-------------------------------*/
/*  DATA STRUCTURES              */
/*-------------------------------*/

/* ---- Interface's data structure ---- */
typedef struct interface_s {
  GnomeApp    *main_window;   /* Main_window                                     */
  GnomeCanvas *canvas;        /* CANVAS, for the representation of the universe  */
  GtkWidget   *app_bar;       /* status bar, at the bottom                       */
  GtkWidget   *toggle_vel;    /* View velocity vectors                           */
  GtkWidget   *toggle_num;    /* View particle numbers                           */
  GtkWidget   *toggle_ik_vel; /* View ik velocity vector                         */
  GtkAdjustment *simulation_time; /* Duration of the simulation   */
  GtkAdjustment *work_posx;       /* Component x of the working position vector  */
  GtkAdjustment *work_posy;       /* Component y of the working position vector  */
  GtkAdjustment *work_velx;       /* Component x of the working velocity vector  */
  GtkAdjustment *work_vely;       /* Component y of the working velocity vector  */
  GtkAdjustment *work_celx;       /* Component x of the working celerity vector  */
  GtkAdjustment *work_cely;       /* Component y of the working celerity vector  */

  /* CANVAS STATUS */
  gdouble pixel_per_unit;

} interface_t;

/*--------------*/
/* PROTOTYPES   */
/*--------------*/

void create_app(interface_t *interface);
/**********************************************************/
/* Create the main interface and initialize the inteface  */
/* data structure                                         */
/**********************************************************/

GtkWidget *create_about();
/*****************************************/
/* Create and display the about window   */
/*****************************************/

void interface_show_particle_info(int id);


#endif  /* _INTEFACE_H */
