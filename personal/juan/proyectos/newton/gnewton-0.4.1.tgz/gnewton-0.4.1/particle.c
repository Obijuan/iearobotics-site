/*****************************************************/
/* NEWTON    (c) Carlos Jesus Venegas Arrabe.        */
/*                                                   */
/* particle definition module.                       */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include "vector.h"
#include "particle.h"
#include <malloc.h>


/* ************************************************************ */
/* Pcl_New                                                      */
/* =======                                                      */
/*                                                              */
/* This function create a new particle.                         */
/*                                                              */
/* Receive:                                                     */
/*            sx,xy => space origin coordinates.                */
/*            ax,ay => celerity origin coordinates(origin       */
/*                     at particle coordinate reference system).*/
/*            vx,vy => velocity origin coordinates(origin at    */
/*                     particle coordinate reference system).   */
/*                                                              */
/* Return:                                                      */
/*            The new particle.                                 */
/*            NULL if an error ocurred.                         */
/*                                                              */
/* ************************************************************ */

pparticle  Pcl_New(double sx,double sy,double vx,double vy,double ax,double ay)
{
  pparticle newp;

  newp=(pparticle) malloc (sizeof(particle));
  
  if(newp==NULL) return NULL;

  Vector_Set_Comp(vx,vy,&(newp->init.velocity));
  Vector_Set_Comp(sx,sy,&(newp->init.position));
  Vector_Set_Comp(ax,ay,&(newp->init.celerity));

  Vector_Set_Comp(vx,vy,&(newp->working.velocity));
  Vector_Set_Comp(sx,sy,&(newp->working.position));
  Vector_Set_Comp(ax,ay,&(newp->working.celerity));

  Vector_Set_Comp(vx,vy,&(newp->tmp.velocity));
  Vector_Set_Comp(sx,sy,&(newp->tmp.position));
  Vector_Set_Comp(ax,ay,&(newp->tmp.celerity));

  newp->init.userdata=NULL;
  newp->working.userdata=NULL;
  newp->tmp.userdata=NULL;
  newp->userdata=NULL;
 
  return newp;
}

void Pcl_Reset(particle *part)
/******************************************/
/* Change the state to the initial one    */
/******************************************/
{
  Vector_Assign(&part->working.position,&part->init.position);
  Vector_Assign(&part->working.velocity,&part->init.velocity);
  Vector_Assign(&part->working.celerity,&part->init.celerity);

  Vector_Assign(&part->tmp.position,&part->init.position);
  Vector_Assign(&part->tmp.velocity,&part->init.velocity);
  Vector_Assign(&part->tmp.celerity,&part->init.celerity);
}

void Pcl_Set(particle *part)
/***********************************/
/* Set de initial state            */
/***********************************/
{
  Vector_Assign(&part->init.position,&part->working.position);
  Vector_Assign(&part->init.velocity,&part->working.velocity);
  Vector_Assign(&part->init.celerity,&part->working.celerity);

  Vector_Assign(&part->tmp.position,&part->working.position);
  Vector_Assign(&part->tmp.velocity,&part->working.velocity);
  Vector_Assign(&part->tmp.celerity,&part->working.celerity);
}


/* ************************************************************************** */
/* ****************** Set the properties of the particles ******************* */
/* ************************************************************************** */

/* *************************************************************** */
/* Pcl_SetInit???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the init field.                                              */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetInitPos(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->init.position));
}

inline STATUS Pcl_SetInitVeloc(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->init.velocity));
}

inline STATUS Pcl_SetInitCel(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->init.celerity));
}

inline STATUS Pcl_SetInitUserdata(pparticle p,void *data)
{
  if(p==NULL) return ERROR;

  p->init.userdata = data;

  return OK;
}


/* *************************************************************** */
/* Pcl_SetWork???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the working field.                                           */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetWorkPos(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->working.position));
}

inline STATUS Pcl_SetWorkVeloc(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->working.velocity));
}

inline STATUS Pcl_SetWorkCel(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->working.celerity));
}

inline STATUS Pcl_SetWorkUserdata(pparticle p,void *data)
{
  if(p==NULL) return ERROR;
  
  p->working.userdata = data;
  
  return OK;
}


/* *************************************************************** */
/* Pcl_SetTmp???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions sets x and y coordinates of specefic properties  */
/* of the tmp field.                                               */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => new coordinates of the particle's propertie.  */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetTmpPos(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->tmp.position));
}

inline STATUS Pcl_SetTmptVeloc(pparticle p,double x, double y)
{
  return  Vector_Set_Comp(x,y,&(p->tmp.velocity));
}

inline STATUS Pcl_SetTmpCel(pparticle p,double x, double y)
{
  return Vector_Set_Comp(x,y,&(p->tmp.celerity));
}

inline STATUS Pcl_SetTmpUserdata(pparticle p,void *data)
{
  if(p==NULL) return ERROR;

  p->tmp.userdata = data;

  return OK;
}


/* *************************************************************** */
/* Pcl_SetUserdata                                                 */
/* ===============                                                 */
/*                                                                 */
/* This functions sets the user data field.                        */
/*                                                                 */
/* Receive:                                                        */
/*            data=> pointer to the user data. The user manage     */
/*                   this field.                                   */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_SetUserdata(pparticle p,void *data)
{
  if(p==NULL) return ERROR;
  p->userdata=data;
  return OK;
}


/* ************************************************************************** */
/* ************** Increment  the properties of the particles **************** */
/* ************************************************************************** */

/* *************************************************************** */
/* Pcl_Inc???                                                      */
/* ==========                                                      */
/*                                                                 */
/* This functions increments the position,velocity and celerity    */
/* values.                                                         */
/*                                                                 */
/* Receive:                                                        */
/*            nx,ny => amount to increment.                        */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_IncPos(pparticle p,double nx, double ny)
{
  return Vector_Set_Comp(p->working.position.cords.x + nx,
			 p->working.position.cords.y + ny,
			 &(p->working.position));
}

inline STATUS Pcl_IncVeloc(pparticle p,double nx, double ny)
{
  return Vector_Set_Comp(p->working.velocity.cords.x + nx,
			 p->working.velocity.cords.y + ny,
			 &(p->working.velocity));
}

inline STATUS Pcl_IncCel(pparticle p,double nx, double ny)
{
  return Vector_Set_Comp(p->working.celerity.cords.x + nx,
			 p->working.celerity.cords.y + ny,
			 &(p->working.celerity));
}

/* *********************************************************************** */
/* ******************** Get  properties of the particle ****************** */
/* *********************************************************************** */

/* *************************************************************** */
/* Pcl_GetInit???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the init field.                                              */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetInitPos(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->init.position));
}

inline double Pcl_GetInitPos_x(pparticle p)
{
  return Vector_Get_x(&(p->init.position));
}

inline double Pcl_GetInitPos_y(pparticle p)
{
  return Vector_Get_y(&(p->init.position));
}

inline double Pcl_GetInitPos_module(pparticle p)
{
  return Vector_Get_mod(&(p->init.position));
}

inline STATUS Pcl_GetInitVeloc(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->init.velocity));
}

inline double Pcl_GetInitVeloc_x(pparticle p)
{
  return Vector_Get_x(&(p->init.velocity));
}

inline double Pcl_GetInitVeloc_y(pparticle p)
{
  return Vector_Get_y(&(p->init.velocity));
}

inline double Pcl_GetInitVeloc_module(pparticle p)
{
  return Vector_Get_mod(&(p->init.velocity));
}

inline STATUS Pcl_GetInitCel(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->init.celerity));
}

inline double Pcl_GetInitCel_x(pparticle p)
{
  return Vector_Get_x(&(p->init.celerity));
}

inline double Pcl_GetInitCel_y(pparticle p)
{
  return Vector_Get_y(&(p->init.celerity));
}

inline double Pcl_GetInitCel_module(pparticle p)
{
  return Vector_Get_mod(&(p->init.celerity));
}

void *pcl_GetInitUserdata(pparticle p)
{
  if(p==NULL) return NULL;

  return p->init.userdata;
}


/* *************************************************************** */
/* Pcl_GetWork???                                                  */
/* ==============                                                  */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the working field.                                           */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetWorkPos(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->working.position));
}

inline double Pcl_GetWorkPos_x(pparticle p)
{
  return Vector_Get_x(&(p->working.position));
}

inline double Pcl_GetWorkPos_y(pparticle p)
{
  return Vector_Get_y(&(p->working.position));
}

inline double Pcl_GetWorkPos_module(pparticle p)
{
  return Vector_Get_mod(&(p->working.position));
}

inline STATUS Pcl_GetWorkVeloc(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->working.velocity));
}

inline double Pcl_GetWorkVeloc_x(pparticle p)
{
  return Vector_Get_x(&(p->working.velocity));
}

inline double Pcl_GetWorkVeloc_y(pparticle p)
{
  return Vector_Get_y(&(p->working.velocity));
}

inline double Pcl_GetWorkVeloc_module(pparticle p)
{
  return Vector_Get_mod(&(p->working.velocity));
}

inline STATUS Pcl_GetWorkCel(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->working.celerity));
}

inline double Pcl_GetWorkCel_x(pparticle p)
{
  return Vector_Get_x(&(p->working.celerity));
}

inline double Pcl_GetWorkCel_y(pparticle p)
{
  return Vector_Get_y(&(p->working.celerity));
}

inline double Pcl_GetWorkCel_module(pparticle p)
{
  return Vector_Get_mod(&(p->working.celerity));
}

void* Pcl_GetWorkUserdata(pparticle p)
{
  if(p==NULL) return NULL;
  return p->working.userdata;
}


/* *************************************************************** */
/* Pcl_GetTmp???                                                   */
/* =============                                                   */
/*                                                                 */
/* This functions gets x and y coordinates of specefic properties  */
/* of the tmp field.                                               */  
/*                                                                 */
/* Receive:                                                        */
/*            x,y => pointer to the x and y variable ,the memorie  */
/*                   should be reserved by the user.               */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*            OK if all is ok.                                     */
/*            ERROR if an error ocurred.                           */
/*                                                                 */
/* *************************************************************** */

inline STATUS Pcl_GetTmpPos(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->tmp.position));
}

inline double Pcl_GetTmpPos_x(pparticle p)
{
  return Vector_Get_x(&(p->tmp.position));
}

inline double Pcl_GetTmpPos_y(pparticle p)
{
  return Vector_Get_y(&(p->tmp.position));
}

inline double Pcl_GetTmpPos_module(pparticle p)
{
  return Vector_Get_mod(&(p->tmp.position));
}

inline STATUS Pcl_GetTmpVeloc(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->tmp.velocity));
}

inline double Pcl_GetTmpVeloc_x(pparticle p)
{
  return Vector_Get_x(&(p->tmp.velocity));
}

inline double Pcl_GetTmpVeloc_y(pparticle p)
{
  return Vector_Get_y(&(p->tmp.velocity));
}

inline double Pcl_GetTmpVeloc_module(pparticle p)
{
  return Vector_Get_mod(&(p->tmp.velocity));
}

inline STATUS Pcl_GetTmpCel(pparticle p,double *x, double *y)
{
  return Vector_Get_Comp(x,y,&(p->tmp.celerity));
}

inline double Pcl_GetTmpCel_x(pparticle p)
{
  return Vector_Get_x(&(p->tmp.celerity));
}

inline double Pcl_GetTmpCel_y(pparticle p)
{
  return Vector_Get_y(&(p->tmp.celerity));
}

inline double Pcl_GetTmpCel_module(pparticle p)
{
  return Vector_Get_mod(&(p->tmp.celerity));
}

void* Pcl_GetTmpUserdata(pparticle p)
{
  if(p==NULL) return NULL;

  return p->tmp.userdata;
}


/* *************************************************************** */
/* Pcl_GetUserdata                                                 */
/* ===============                                                 */
/*                                                                 */
/* This function gets the pointer to the general userdata memory   */
/*                                                                 */
/* Receive:                                                        */
/*            p   => particle.                                     */
/*                                                                 */
/* Return:                                                         */
/*           address to the general user data field.               */
/*                                                                 */
/* *************************************************************** */

inline void* Pcl_GetUserdata(pparticle p)
{
  if(p==NULL) return NULL;

  return p->userdata;
}
