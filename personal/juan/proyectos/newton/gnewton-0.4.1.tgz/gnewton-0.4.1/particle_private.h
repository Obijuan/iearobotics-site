/*****************************************************/
/* particle_private.h    Abril 2002                  */
/*---------------------------------------------------*/
/* GPL License                                       */
/*****************************************************/

#ifndef _PARTICLE_PRIVATE_H_
#define _PARTICLE_PRIVATE_H_

#include <gnome.h>
#include "vector.h"

#define PPARTICLE_PRIVATE(Y) (((particle_private_t *)(Y->userdata)))
#define PPARTICLE_PRIVATE_IK_VEL_X(Y) (PPARTICLE_PRIVATE(Y)->ik_vel->cords.x)
#define PPARTICLE_PRIVATE_IK_VEL_Y(Y) (PPARTICLE_PRIVATE(Y)->ik_vel->cords.y)

#define PARTICLE_PRIVATE(Y) (((particle_private_t *)(Y.private)))
#define PARTICLE_PRIVATE_IK_VEL_X(Y) (PARTICLE_PRIVATE(Y)->ik_vel->cords.x)
#define PARTICLE_PRIVATE_IK_VEL_Y(Y) (PARTICLE_PRIVATE(Y)->ik_vel->cords.y)

/* Private structure of the particle */
typedef struct particle_interface {
  vector2D *ik_vel;   /* Inverse Kinematics velocity vector */

  /*-- Informacion para el interfaz --*/
  gboolean press;          /* Boton del mouse apretado sobre ella              */
  gboolean change_vel;     /* Cambio en el vector velocidad                    */
  GnomeCanvasGroup *grupo; /* Grupo al que pertenece la particula              */
  GnomeCanvasItem  *item_part;  /* Dibujo de la part�cula                      */
  GnomeCanvasItem *item_vel;    /* Dibujo del vector de velocidad, Cinemat. Directa */
  GnomeCanvasItem *vel_ci; /* Dibujo del vector de velocidad, Cinemat. Inv.    */
  GnomeCanvasItem *num;    /* Dibujo del numero de particula                   */
} particle_private_t;

/*******************/
/*   PROTOTYPES    */
/*******************/
particle_private_t *particle_private_new();
void particle_private_free(particle_private_t *pv);


#endif  /* _PARTICLE_PRIVATE_H_  */


