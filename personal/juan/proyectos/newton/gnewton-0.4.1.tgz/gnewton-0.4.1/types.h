#ifndef __MY_TYPES__
#define __MY_TYPES__

typedef enum{false=-1, true} BOOL;
typedef enum{ERROR=-1, OK} STATUS;

#endif
