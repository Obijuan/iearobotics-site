/*****************************************************/
/* univ.h     Abril 2002                             */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#ifndef _UNIV_H
#define _UNIV_H

#include "particle.h"

/*-- Definiciones para el UNIVERSO --*/
#define MAX_PARTICULAS 2  /* Numero maximo de particulas */

/*------------*/
/* PROTOTYPES */
/*------------*/
void univ_update_particulas(gboolean futuro);
void univ_create();
void univ_destroy();
void univ_reset();
void univ_set();
int univ_add_particle(particle *part);
void univ_del_particle(guint part_num);
particle *univ_get_first_particle();
particle *univ_get_next_particle();
particle *univ_get_particle(gint num);
void univ_print_particles_num();
void univ_particles_navigate();

#endif  /* _UNIV_H */
