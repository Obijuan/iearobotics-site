/*****************************************************/
/* NEWTON    (c) Carlos Jesus Venegas Arrabe.        */
/*                                                   */
/* Vector manipulate module.                         */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include <malloc.h>
#include <math.h>
#include "vector.h"



/* *************************************************************** */
/* Vector_New                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to create a new vector.                                */
/*                                                                 */
/* Arguments:                                                      */
/*            x => init x coordenate.                              */
/*            y => init y coordenate.                              */
/*                                                                 */
/* Return:                                                         */
/*            pvector2D => pointer to vector2D structure.          */
/*                                                                 */
/* *************************************************************** */

pvector2D Vector_New(double x,double y)
{
  pvector2D aux;

  aux=(pvector2D)malloc(sizeof(vector2D));
  
  if (aux==NULL) return NULL;

  aux->cords.x=x;
  aux->cords.y=y;
  aux->module=Vector_Module(aux);

  return aux;
}


/* *************************************************************** */
/* Vector_Assign                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to assign vector to other.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1=> the vector to copy in.                          */
/*            v2=> vector to duplicate.                            */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Assign(pvector2D v1, pvector2D v2)
{
  if ((v1 == NULL) || (v2==NULL)) return ERROR;

  *v1=*v2;

  return OK;
}


/* *************************************************************** */
/* Vector_Set_Comp                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's components.                         */
/*                                                                 */
/* Arguments:                                                      */
/*            x,y => components to the vector.                     */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_Comp(double x, double y, pvector2D v1)
{
  if(v1==NULL) return ERROR;
  
  v1->cords.x=x;
  v1->cords.y=y;

  return OK;
}

/* *************************************************************** */
/* Vector_Get_Comp                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's components.                            */
/*                                                                 */
/* Arguments:                                                      */
/*            x,y => components to the vector.                     */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Get_Comp(double *x, double *y, pvector2D v1)
{
  if(v1==NULL || x==NULL || y==NULL) return ERROR;
  
  *x=v1->cords.x;
  *y=v1->cords.y;

  return OK;
}


/* *************************************************************** */
/* Vector_Set_x                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's x component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            x => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_x(double x, pvector2D v1)
{
  if(v1==NULL) return ERROR;
  
  v1->cords.x=x;

  return OK;
}

/* *************************************************************** */
/* Vector_Set_x                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's x component .                          */
/*                                                                 */
/* Arguments:                                                      */
/*            x => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_x(pvector2D v1)
{
  return v1->cords.x;
}


/* *************************************************************** */
/* Vector_Set_y                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's y component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            y => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS  Vector_Set_y(double y, pvector2D v1)
{
  if(v1==NULL) return ERROR;
  
  v1->cords.y=y;

  return OK;
}

/* *************************************************************** */
/* Vector_Get_y                                                    */ 
/* ------------                                                    */
/*                                                                 */
/* Function to get vector's y component .                          */
/*                                                                 */
/* Arguments:                                                      */
/*            y => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_y(pvector2D v1)
{
    return v1->cords.y;
}

/* *************************************************************** */
/* Vector_Set_mod                                                  */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's module.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline STATUS Vector_Set_mod(pvector2D v1)
{
  if (v1==NULL) return ERROR;

  v1->module=Vector_Module(v1);

  return OK;
}

/* *************************************************************** */
/* Vector_Get_mod                                                  */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to get vector's module.                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline double Vector_Get_mod(pvector2D v1)
{
  return Vector_Module(v1);
}


/* *************************************************************** */
/* Vector_Module                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to calculate the vector's module.                      */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*                                                                 */
/* Return:                                                         */
/*            double => vector's module.                           */
/*                                                                 */
/* *************************************************************** */

double Vector_Module(pvector2D v)
{
  if (v==NULL) return -1.0;
  
  else return sqrt((v->cords.x * v->cords.x) + (v->cords.y * v->cords.y));
}


/* *************************************************************** */
/* Vector_Add                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the add of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 + v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Add(pvector2D v1, pvector2D v2, pvector2D result)
{
  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return ERROR;
  
  result->cords.x=v1->cords.x + v2->cords.x;
  result->cords.y=v1->cords.y + v2->cords.y;
  result->module=Vector_Module(result);
  
  return OK;
}


/* *************************************************************** */
/* Vector_Sub                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the sub of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 - v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Sub(pvector2D v1, pvector2D v2, pvector2D result)
{
  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return ERROR;
  
  result->cords.x=v1->cords.x - v2->cords.x;
  result->cords.y=v1->cords.y - v2->cords.y;
  result->module=Vector_Module(result);
  
  return OK;
}


/* *************************************************************** */
/* Vector_MK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that multiply a vector for a constant.                 */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
STATUS Vector_MK(pvector2D v, double k, pvector2D result)
{
  if ((v == NULL) || (result == NULL)) return ERROR;
  
  result->cords.x =v->cords.x * k;
  result->cords.y=v->cords.y * k;
  result->module=v->module * k;
  
  return OK;
}



/* *************************************************************** */
/* Vector_DK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that divide a vector for a constant.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
STATUS Vector_DK(pvector2D v, double k, pvector2D result)
{
  if ((v == NULL) || (result == NULL)) return ERROR;
  
  result->cords.x =v->cords.x / k;
  result->cords.y=v->cords.y / k;
  result->module=v->module / k;
  
  return OK;
}


/* *************************************************************** */
/* Vector_Unit                                                     */
/* -----------                                                     */
/*                                                                 */
/* Function that calculate de unitary vector from v1.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector.                                        */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

STATUS  Vector_Unit(pvector2D v1, pvector2D result)
{
  if ((v1 == NULL) || (result == NULL)) return ERROR;
  
  result->cords.x=v1->cords.x / v1->module;
  result->cords.y=v1->cords.y / v1->module;
  result->module=1;
  
  return OK;
}


/* *************************************************************** */
/* Vector_Dotp                                                     */
/* -----------                                                     */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* algebraic method.                                               */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_Dotp(pvector2D v1, pvector2D v2,double *result)
{
  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return ERROR;
  
  *result=(v1->cords.x * v2->cords.x) + (v1->cords.y * v2->cords.y);
  
  return OK;
}


/* *************************************************************** */
/* Vector_DotpMod                                                  */
/* --------------                                                  */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in radians.         */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_DotpMod(pvector2D v1, pvector2D v2,double angle,double *result)
{
  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return ERROR;
  
  *result=v1->module * v2->module * cos(angle);
  
  return OK;
}


/* *************************************************************** */
/* Vector_AngleDeg                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*            OK if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in degrees.                                   */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_AngleDeg(pvector2D v1, pvector2D v2, double *angle)
{
  double cos,module1,module2;

  if ((v1 == NULL) || (v2 == NULL)) return ERROR;
  
  module1=Vector_Module(v1);
  module2=Vector_Module(v2);
 
  if (module1==0.0 || module2==0.0) cos=0.0;
  else
    cos=((v1->cords.x*v2->cords.x) + (v1->cords.y*v2->cords.y)) /
      (double)(module1 * module2) ;
  
  *angle=180.0*acos(cos)/PI;

  return OK;
}


/* *************************************************************** */
/* Vector_AngleRad                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors in radians.   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in radians.                                   */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_AngleRad(pvector2D v1, pvector2D v2, double *angle)
{
  double cos,module1,module2;

  if ((v1 == NULL) || (v2 == NULL)) return ERROR;
 
  module1=Vector_Module(v1);
  module2=Vector_Module(v2);
 
  if (module1==0.0 || module2==0.0) cos=0.0;
  else
    cos=((v1->cords.x*v2->cords.x) + (v1->cords.y*v2->cords.y)) /
         (double)(module1 * module2) ;

  *angle=acos(cos);

  return OK;
}


/* *************************************************************** */
/* Vector_VectpMod                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate the module of vectorial product , with  */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in degrees.         */
/*            result => v1 ^ v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            ERROR if error.                                      */
/*             OK if OK.                                           */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ^ This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

STATUS Vector_VectpMod(pvector2D v1, pvector2D v2,double angle,double *result)
{
  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return ERROR;
  
  *result=v1->module * v2->module * sin(angle);
  
  return OK;
}
