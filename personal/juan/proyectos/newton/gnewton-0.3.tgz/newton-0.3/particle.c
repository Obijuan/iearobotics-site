/*****************************************************/
/* particle.c    Abril 2002                          */
/*---------------------------------------------------*/
/* GPL License                                       */
/*****************************************************/

#include <glib.h>
#include <stdio.h>

#include "particle.h"

void particle_set_initial_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel)
/***********************************************/
/* Set the initial state of the particle       */
/***********************************************/
{
  Vector_Assign(&p->init_state.pos,pos);
  Vector_Assign(&p->init_state.vel,vel);
  Vector_Assign(&p->init_state.acel,acel);
}

void particle_set_old_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel)
/*******************************************/
/* Set the old state of the particle       */
/*******************************************/
{
  Vector_Assign(&p->old_state.pos,pos);
  Vector_Assign(&p->old_state.vel,vel);
  Vector_Assign(&p->old_state.acel,acel);
}

void particle_set_t_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel)
/*******************************************/
/* Set the old state of the particle       */
/*******************************************/
{
  Vector_Assign(&p->t_state.pos,pos);
  Vector_Assign(&p->t_state.vel,vel);
  Vector_Assign(&p->t_state.acel,acel);
}

void particle_reset(particle_t *p)
/*****************************************************/
/* Set the t_state and old_state to the initial one  */
/*****************************************************/
{
  particle_set_t_state(p,
        &PARTICLE_INIT_STATE((*p)).pos,
        &PARTICLE_INIT_STATE((*p)).vel,
        &PARTICLE_INIT_STATE((*p)).acel);

  particle_set_old_state(p,
        &PARTICLE_INIT_STATE((*p)).pos,
        &PARTICLE_INIT_STATE((*p)).vel,
        &PARTICLE_INIT_STATE((*p)).acel);
}

particle_t *particle_new()
/*********************************************/
/* Create a new particle initilized to zero  */
/* Returns the pointer to the new particle   */
/*********************************************/
{
  particle_t *part;

  /* Get memory for the particle */
  part=g_malloc(sizeof(particle_t));

  /* Initialize the particle */
  particle_init(part);

  return part;
}

void particle_free(particle_t *part)
/************************************************************/
/* Destroy de particle and free the memory                  */
/* If the private part has no been free yet, It does        */
/************************************************************/
{
  g_assert(part!=NULL);
  if (part==NULL) return;

  if (part->private!=NULL)  g_free(part->private);

  g_free(part);

}

void particle_init(particle_t *p)
/**********************************************************/
/* Initialize the particle. This function MUST be called  */
/* before any other                                       */
/**********************************************************/
{
  vector2D nulo;

  /* Initialize all the states */
  v_x(nulo)=0;
  v_y(nulo)=0;
  particle_set_initial_state(p,&nulo,&nulo,&nulo);
  particle_reset(p);

  /* Initialize the private field */
  p->private=NULL;
}



