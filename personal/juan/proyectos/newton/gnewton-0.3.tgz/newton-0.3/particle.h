/*****************************************************/
/* particle.h    Abril 2002                          */
/*---------------------------------------------------*/
/* GPL License                                       */
/*****************************************************/


#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include "vector.h"

/*-------------------*/
/* DATA STRUCTURES   */
/*-------------------*/

/* Vector that determine the state of the */
/* particle in a instant of time          */
typedef struct state_s {
  vector2D pos;  /*-- Position vector    --*/
  vector2D vel;  /*-- Velocity vector    --*/
  vector2D acel; /*-- aceleration vector --*/
} state_t;

/* Particles Data structure */
typedef struct particle_s {
  int id;   /* Identification number of the particle */

  /* STATE OF THE PARTICLE */
  state_t init_state; /* Initial state (State when the particle is reset)  */
  state_t old_state;  /* old state (State of the particle in the past)     */
  state_t t_state;    /* actual state (State in the t instante of time)    */

  void *private;   /* Private data. It depens on the application */

} particle_t;

/*---------*/
/* MACROS  */
/*---------*/
#define PARTICLE_INIT_STATE(X) (X.init_state)
#define PPARTICLE_INIT_STATE(X) (X->init_state)
#define PARTICLE_OLD_STATE(X)  (X.old_state)
#define PPARTICLE_OLD_STATE(X)  (X->old_state)
#define PARTICLE_T_STATE(X)    (X.t_state)
#define PPARTICLE_T_STATE(X)    ((X->t_state))

/*------------*/
/* PROTOTYPES */
/*------------*/
void particle_set_initial_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel);
void particle_set_old_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel);
void particle_set_t_state(particle_t *p,pvector2D pos,pvector2D vel,pvector2D acel);
void particle_reset(particle_t *p);
void particle_init(particle_t *p);
void particle_free(particle_t *part);
particle_t *particle_new();

#endif  /* _PARTICLE_H_  */



