/*****************************************************/
/* interface.h    April, 2002                        */
/*---------------------------------------------------*/
/* This project is under GPL license                 */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

/*-------------------------------*/
/*  DATA STRUCTURES              */
/*-------------------------------*/

/* ---- Interface's data structure ---- */
typedef struct interface_s {
  GnomeApp    *main_window;  /* Main_window                                     */
  GnomeCanvas *canvas;       /* CANVAS, for the representation of the universe  */
  GtkWidget   *app_bar;      /* status bar, at the bottom                       */
  GtkWidget   *toggle_vel;
  GnomeUIInfo *view_menu;    /* View menu */

  /* CANVAS STATUS */
  gdouble pixel_per_unit;

} interface_t;

/*--------------*/
/* PROTOTYPES   */
/*--------------*/

void interface_create_main_window(interface_t *interface, gchar *app_id);
/**********************************************************/
/* Create the main interface and initialize the inteface  */
/* data structure                                         */
/**********************************************************/

#endif  /* _INTEFACE_H */