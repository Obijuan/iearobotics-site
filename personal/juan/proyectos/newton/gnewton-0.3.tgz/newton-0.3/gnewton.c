/*****************************************************/
/* GNEWTON.c    (c) Juan Gonzalez Gomez. Marzo 2002  */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include <gnome.h>
#include <math.h>

#include "about.h"
#include "interface.h"
#include "callback.h"
#include "vector.h"
#include "particle.h"
#include "particle_private.h"
#include "univ.h"
#include "graph_univ.h"
#include "debug.h"

/*------------------------*/
/*    CONSTANTS           */
/*------------------------*/

/* Discrete Time Duration. The duration of a clock TIC.   */
/* Exxpressed in miliseconds                              */
#define DTD   20

/* Clock TICS used for the inverse kinematics calculus  */
#define TICS_IK 5

/* Duration of the simulation in TICS  */
#define SIMULATION_TIME 50

/* Initial value for the "ZOOM" */
#define PIXELS_PER_UNIT 1.0

/* Zoom Increment/decrement */
#define ZOOM_INC 0.05

/*--------------------*/
/*    PROTOTYPES      */
/*--------------------*/
void univ_update_particulas(gboolean futuro);

/*---------------*/
/* VARIABLES     */
/*---------------*/
interface_t interface;
static gint     simulation_time; 
static gint     ik_tics;        /* Tics beetwen two IK comprobations        */
static gboolean to_future_simu; /* Direction of the simulation: PAST/FUTURE */

/* -- main timer -- */
static int main_timer;

/*-- Variables for GNOME */
static gchar app_id[] = {"GNewton"};


/***********************/
/* User parameters     */
/***********************/

static gboolean flag;  /* -- Test Flag*/

/* User parameters description */
struct poptOption options[]={
  {"flag",'h',POPT_ARG_NONE, &flag, 0, "Activar la opcion Flag", NULL},
  {NULL, '\0', 0, NULL, 0, NULL, NULL}
};


/*-------------------------*/
/* CALLBACK FUNCTIONS      */
/*-------------------------*/
void main_quit(GtkWidget *window, gpointer data)
{
  gtk_timeout_remove(main_timer);
  //univ_destroy();
  gtk_main_quit();
}


static gboolean univ_main_timer(gpointer data)
/************************************************************/
/* Main timer callback function. It's executed every clock  */
/* tic in the universe.                                     */
/************************************************************/
{
  particle_t *part;

  /*--------------------------------------------------------*/
  /* Update the state of the universe, if we are simulating */
  /*--------------------------------------------------------*/
  if (simulation_time>0) {
    simulation_time--;

    /* Update the state of the universer */
    univ_update_particulas(to_future_simu);

    /* Draw the new state of the universe */
    graph_univ_draw();

    /* Inform the user when the simulation has finished */
    if (simulation_time==0)
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Simulacion finalizada!!");
  }

  /*------------------------------------*/
  /* "inverse kinematics" calculus      */
  /*------------------------------------*/
  ik_tics--;
  if (ik_tics==0) {

    part=univ_get_first_particle();

    while (part!=NULL) {
      /* Calculate the "inverse kinematics" velocity vector */
      /* ik_vel = pos - old_pos */
      /* It is calculated every TICS_IK units of time, therefore   */
      /* we have to divide it by TICS_IK                           */
      Vector_Sub(&(PPARTICLE_T_STATE(part).pos),
                 &(PPARTICLE_OLD_STATE(part).pos),
                 (PPARTICLE_PRIVATE(part)->ik_vel));
      Vector_MK(PPARTICLE_PRIVATE(part)->ik_vel,
               (double)(1.0/TICS_IK),
                PPARTICLE_PRIVATE(part)->ik_vel);

      /* Store the new position vector */
      Vector_Assign(&PPARTICLE_OLD_STATE(part).pos,
                    &PPARTICLE_T_STATE(part).pos);
      part=univ_get_next_particle();
    }

    graph_univ_draw();

    /* Reset the IK clock */
    ik_tics=TICS_IK;
  }

  return TRUE;
}


void toggle_check_boton(GtkWidget *widget,gpointer data)
/***********************************/
/* CHECK_MENU CALLBACK FUNCTION    */
/***********************************/
{
  int n;
  int active;
  char cad[80];

  /* Get the state of the check button pressed */
  active = (GTK_CHECK_MENU_ITEM(widget)->active);

  /* The the button number */
  n=atoi((char *)data);

  switch(n) {

    /* VIEW MENU: Show vectors ON/OFF */
    case 1:
      if (active) {
        sprintf (cad,"Vectores de velocidad ON");
	graph_univ_show_velocity_vel();
      } else {
        sprintf (cad,"Vectores de Velocidad OFF");
	graph_univ_hide_velocity_vel();
      }
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),cad);
      break;

    /* VIEW MENU: Show particles numbers ON/OFF */
    case 2:
       if (active) {
        sprintf (cad,"Numero de particulas ON");
	graph_univ_show_particle_num();
       } else {
        sprintf (cad,"Numero de particulas OFF");
	graph_univ_hide_particle_num();
       }
       gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),cad);
       break;

    /* VIEW MENU: Show "inverse kinematics" velocity vector ON/OFF */
    case 3:
      if (active) {
        sprintf (cad,"Cinematica inversa ON)\n");
	graph_univ_show_ik_velocity_vel();
      } else {
        sprintf (cad,"Cinematica inversa OFF)\n");
	graph_univ_hide_ik_velocity_vel();
      }
      break;
  }

}

void toggle_boton(GtkWidget *widget,gpointer data)
/*************************************************************/
/* FUNCION DE RETROLLAMADA DE BOTONES TOGGLE                 */
/* Se llaman cuando hay un cambio en el estado               */
/*************************************************************/
{
  int n;
  int activo;

  activo = (GTK_TOGGLE_BUTTON(widget)->active);

  n=atoi((char *)data);
  g_print("Toggle Boton: %d\n",n);

  univ_print_particles_num();
  univ_particles_navigate();

}

void main_button(GtkWidget *widget,gpointer data)
/****************************************/
/* Normal buttons callback function     */
/****************************************/
{
  vector2D pos;
  vector2D vel;
  vector2D acel;
  particle_t *part;
  int n;
  int i;


  /* Get the button number */
  n=atoi((char *)data);

  switch(n) {

    case 1:
      part=(particle_t *)particle_new();
      Vector_Set_Comp(100.0,100.0,&pos);
      Vector_Set_Comp(2.0,2.0,&vel);
      Vector_Set_Comp(0.0,0.0,&acel);
      particle_set_initial_state(part,&pos,&vel,&acel);
      particle_reset(part);
      part->private=particle_private_new();

      /* Add the particle to the universe */
      i=univ_add_particle(part);
      graph_univ_add_particle(interface.canvas,part,i);
      g_print("Particula: %d\n",i);

      /* Show the velocity and ik_velocity vectors */
      /* CHANGE!!!!!                               */
      graph_univ_show_velocity_vel();
      graph_univ_show_ik_velocity_vel();

      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Particula a�adida");

      break;

    /* Retroceder un instante de tiempo */
    case 2:
       gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Simulando...");
       simulation_time=1;
       to_future_simu=FALSE;
       break;

    /* Avanzar un instante de tiempo hacia el futuro */
    case 3:
       gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Simulando...");
       simulation_time=1;
       to_future_simu=TRUE;
       break;

    /* simulacion hacia el pasado */
    case 4:
       gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Simulando...");
       simulation_time=SIMULATION_TIME;
       to_future_simu=FALSE;
       break;

    /* simulacion hacia el futuro */
    case 5:
       gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Simulando...");
       simulation_time=SIMULATION_TIME;
       to_future_simu=TRUE;
       break;

    /* ZOOM + */
    case 6:
      interface.pixel_per_unit+=ZOOM_INC;
      gnome_canvas_set_pixels_per_unit (GNOME_CANVAS (interface.canvas), (double) interface.pixel_per_unit);
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"ZOOM +");
      break;

    /* ZOOM - */
    case 7:
      interface.pixel_per_unit-=ZOOM_INC;
      gnome_canvas_set_pixels_per_unit (GNOME_CANVAS (interface.canvas), (double) interface.pixel_per_unit);
      gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"ZOOM -");
      break;

  }
}

/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{
  poptContext contexto;

  /* Initialize GNOME, using user parameters */
  gnome_init_with_popt_table (app_id, VERSION, argc,argv, options, 0, &contexto);
  poptFreeContext (contexto);

  /*-- Check the user parameters --*/
  if (flag) g_print ("Opcion Flag...\n");

  /*------------------------*/
  /*  Create the interfaz   */
  /*------------------------*/
  interface.pixel_per_unit=PIXELS_PER_UNIT;
  interface_create_main_window(&interface,app_id);

  /*------------------------*/
  /*  Create the universe   */
  /*------------------------*/
  univ_create();

  /*-------------------------------------*/
  /* -- Create the graphical universe -- */
  /*-------------------------------------*/
  graph_univ_create(interface.canvas);

  /*----------------------*/
  /* Initialize variables */
  /*----------------------*/
  simulation_time=0;
  ik_tics=TICS_IK;
  to_future_simu=TRUE;

  /*--------------------------------------*/
  /* SET the initial state of the buttons */
  /*--------------------------------------*/

  /* View velocity vector ON/OFF */
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(interface.toggle_vel),TRUE);

  /*--------------------------------*/
  /* Check menu items initial state */
  /*--------------------------------*/
  /* View velocity vector ON/OFF */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(interface.view_menu[0].widget),TRUE);

  /* View particle numbers ON/OFF */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(interface.view_menu[1].widget),FALSE);

  /* View inverse kinematics velocity vectors ON/OFF */
  gtk_check_menu_item_set_active(GTK_CHECK_MENU_ITEM(interface.view_menu[2].widget),TRUE);

  graph_univ_draw();

  /* Start the Main timer */
  main_timer=gtk_timeout_add(DTD, univ_main_timer, "2");

  /*-- Let's start the party!!!  -- */
  gtk_main();

  return 0;
}




