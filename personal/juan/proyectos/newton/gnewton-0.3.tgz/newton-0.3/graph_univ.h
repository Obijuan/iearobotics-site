/*****************************************************/
/* graph_univ.h    April, 2002                       */
/*---------------------------------------------------*/
/* This project is under GPL license                 */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#ifndef _GRAPH_UNIV_H
#define _GRAPH_UNIV_H

#define DIAMETRO       10 /* Diametro de las particulas  */

/* Factor de Visualizacion de Vectores. Las particulas tienen un vector  */
/* "REAL" (verdadero) y tienen otro vector VISUAL, que es el que se     */
/* dibuja en el CANVAS. No tienen porque coincidir. Esta constante se    */
/* define como: FVV= Vector visual / Vector real (en modulo), de manera  */
/* que para calcular el vector visual para dibujar tenemos que           */
/* hacer la operacion v_visual = vector_real*FVV                         */
#define FVV   5.0



void actualizar_items(void);
void crear_canvas_items(GnomeCanvas *canvas);
void graph_univ_create(GnomeCanvas *canvas);
void graph_univ_draw(void);
void graph_univ_show_velocity_vel(void);
void graph_univ_hide_velocity_vel(void);
void graph_univ_show_particle_num();
void graph_univ_hide_particle_num();
void graph_univ_show_ik_velocity_vel();
void graph_univ_hide_ik_velocity_vel();
void graph_univ_add_particle(GnomeCanvas *canvas,particle_t *part,int num);

#endif  /* _GRAPH_UNIV_H */
