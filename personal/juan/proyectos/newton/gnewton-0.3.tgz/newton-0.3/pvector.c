/*****************************************************/
/* NEWTON.c    (c) Juan Gonzalez Gomez.              */
/*                 Carlos Jesus Venegas Arrabe.      */
/*                                                   */
/* test for Vector manipulate module.                */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include "vector.h"
#include <stdio.h>
#include <stdlib.h>

int main()
{
  
  vector2D *v1,*v2, result;
  double alpha,escalar;

  // Creacion de vectores
  v1=Vector_New(1,1);
  v2=Vector_New(1,0);
  
   printf("v1 = x:%f y:%f m:%f\n",v_x((*v1)),v_y((*v1)),v_mod((*v1)));
  printf("v2 = x:%f y:%f m:%f\n",v_x((*v2)),v_y((*v2)),v_mod((*v2)));

  Vector_AngleDeg(v1,v2,&alpha);
  printf ("El valor en grados del angulo entre v1 y v2 es: %f\n",alpha);

  Vector_AngleRad(v1,v2,&alpha);
  printf ("El valor en radianes del angulo entre v1 y v2 es: %f\n",alpha);

  Vector_DotpMod(v1,v2,alpha,&escalar);
  printf ("El producto escalar por el metodo geometrico es: %f\n",escalar);

  Vector_Dotp(v1,v2,&escalar);
  printf ("El producto escalar por el metodo algebraico es: %f\n",escalar);

  Vector_VectpMod(v1,v2,alpha,&escalar);
  printf ("El modulo del producto vectorial por el metodo geometrico es: %f\n",escalar);
  
  Vector_Unit(v1,&result);
  printf("v1 unitario = x:%f y:%f m:%f\n",v_x(result),v_y(result),v_mod(result));
  
  Vector_Unit(v2,&result);
  printf("v2 unitario = x:%f y:%f m:%f\n",v_x(result),v_y(result),v_mod(result));
  
  Vector_MK(v1,2,&result);
  printf("v1 * 2 = x:%f y:%f m:%f\n",v_x(result),v_y(result),v_mod(result));

  Vector_Sub(v1,v2,&result);
  printf("v1 - v2 = x:%f y:%f m:%f\n",v_x(result),v_y(result),v_mod(result));
  
  Vector_Add(v1,v2,&result);
  printf("v1 + v2 = x:%f y:%f m:%f\n",v_x(result),v_y(result),v_mod(result));
  
  free(v1);
  free(v2);

  return 0;
}
