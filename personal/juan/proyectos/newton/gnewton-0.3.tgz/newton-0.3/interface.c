/*****************************************************/
/* interface.c    april 2002                         */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#include <gnome.h>

#include "about.h"
#include "interface.h"
#include "callback.h"

/***************/
/* MAIN MENU   */
/***************/
/*-- FILE MENU--*/
static GnomeUIInfo file_menu[] = {
  GNOMEUIINFO_MENU_EXIT_ITEM(main_quit,NULL),
  GNOMEUIINFO_END
};

/*-- MENU HELP --*/
static GnomeUIInfo help_menu[] = {
  GNOMEUIINFO_MENU_ABOUT_ITEM(about, NULL),
  GNOMEUIINFO_END
};

/*-- MENU VIEW --*/
static GnomeUIInfo view_menu[] = {
  {GNOME_APP_UI_TOGGLEITEM,
    "Vectores de velocidad",
    "Mostrar/ocultar vectores velocidad",
    toggle_check_boton,"1",0,0},
  {GNOME_APP_UI_TOGGLEITEM,
    "Numeros de particulas",
    "Mostrar/Ocultar los numeros de las particulas",
    toggle_check_boton,"2",0,0},
   {GNOME_APP_UI_TOGGLEITEM,
    "Cinematica inversa",
    "Mostrar/Ocultar vector velocidad de la cinematica inversa",
    toggle_check_boton,"3",0,0},
  GNOMEUIINFO_END
};

static GnomeUIInfo main_menu[] = {
  GNOMEUIINFO_MENU_FILE_TREE (file_menu),
  GNOMEUIINFO_SUBTREE("View",view_menu),
  GNOMEUIINFO_MENU_HELP_TREE(help_menu),
  GNOMEUIINFO_END
};


/*---------------------------------------------------------*/
/*          I M P L E M E N T A T I O N                    */
/*---------------------------------------------------------*/


void interface_create_main_window(interface_t *interface, gchar *app_id)
/**********************************************************/
/* Create the main interface and initialize the inteface  */
/* data structure                                         */
/**********************************************************/
{
  GtkWidget *vbox_main;
  GtkWidget *label;
  GtkWidget *app;
  GtkWidget *toolbar;
  GtkWidget *flecha;

  /* -- MAIN WINDOW -- */
  app = gnome_app_new(app_id, "GNewton");
  gtk_window_set_default_size(GTK_WINDOW(app),320,200);
  gtk_signal_connect (GTK_OBJECT (app),"destroy",
                      GTK_SIGNAL_FUNC (main_quit),NULL);

  interface->main_window=GNOME_APP(app);

  /*-- Menus --*/
  gnome_app_create_menus(GNOME_APP(app),main_menu);

  /*-- STATUS BAR -- */
  interface->app_bar=gnome_appbar_new(FALSE,TRUE,GNOME_PREFERENCES_USER);
  gnome_app_set_statusbar(GNOME_APP(app), interface->app_bar);
  gnome_appbar_set_status(GNOME_APPBAR(interface->app_bar),"Hola!!!");

  /* Hints will appear at the status bar */
  gnome_app_install_menu_hints(GNOME_APP(app), main_menu);

  /* Crear vbox */
  vbox_main=gtk_vbox_new(FALSE,0);

  /* The contents of the main window is a vertical container */
  gnome_app_set_contents(GNOME_APP(app), GTK_WIDGET(vbox_main));

  /* Create the CANVAS of the universe */
  interface->canvas = GNOME_CANVAS(gnome_canvas_new());
  gnome_canvas_set_scroll_region(interface->canvas, 0.0, 0.0,310.0,310.0);
  gnome_canvas_set_pixels_per_unit(interface->canvas, interface->pixel_per_unit);
  gtk_widget_set_usize(GTK_WIDGET(interface->canvas),310.0,310.0);

  /* Append CANVAS to the vertical box */
  gtk_box_pack_start(GTK_BOX(vbox_main), GTK_WIDGET(interface->canvas), FALSE, FALSE, 0);

  /* Append toolbar */
  toolbar=gtk_toolbar_new(GTK_ORIENTATION_HORIZONTAL,GTK_TOOLBAR_ICONS);
  gtk_container_set_border_width(GTK_CONTAINER(toolbar),0);
  gtk_box_pack_start(GTK_BOX(vbox_main), toolbar,FALSE,FALSE,0);

    /* Test button (TOGGLE) */
    label = gtk_label_new("TEST");
    interface->toggle_vel=gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_TOGGLEBUTTON,
                                NULL,
                                NULL,"Pruebas",NULL,
                                label,
                                (GtkSignalFunc) toggle_boton,"1");

    /* Reset time button */
    label = gtk_label_new("ADD");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"A�adir una particula",NULL,
                                label,
                                (GtkSignalFunc) main_button,"1");

    /* Go 1 unit of time back to the past */
    flecha=gtk_arrow_new(GTK_ARROW_LEFT,GTK_SHADOW_OUT);
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              NULL,"Instante de tiempo anterior",NULL,
                              flecha,
                              (GtkSignalFunc) main_button,"2");

    /* Go 1 unit of time to the future */
    flecha=gtk_arrow_new(GTK_ARROW_RIGHT,GTK_SHADOW_OUT);
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                              NULL,
                              NULL,"Siguiente instante de tiempo",NULL,
                              flecha,
                              (GtkSignalFunc) main_button,"3");

    /* Toward past simulation button */
    label = gtk_label_new("Go-");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"Comenzar la simulacion",NULL,
                                label,
                                (GtkSignalFunc) main_button,"4");

    /* Toward future simulation button */
    label = gtk_label_new("Go+");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"Comenzar la simulacion",NULL,
                                label,
                                (GtkSignalFunc) main_button,"5");
    /* ZOOM IN */
    label = gtk_label_new("Zoom+");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"ZOOM+",NULL,
                                label,
                                (GtkSignalFunc) main_button,"6");

    /* ZOOM OUT */
    label = gtk_label_new("Zoom-");
    gtk_toolbar_append_element (GTK_TOOLBAR(toolbar), GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                NULL,"ZOOM-",NULL,
                                label,
                                (GtkSignalFunc) main_button,"7");


  interface->view_menu=view_menu;

  gtk_widget_show_all(app);

}
