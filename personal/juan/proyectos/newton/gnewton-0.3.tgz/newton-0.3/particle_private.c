/*****************************************************/
/* particle_private.c    Abril 2002                  */
/*---------------------------------------------------*/
/* GPL License                                       */
/*****************************************************/

#include <gnome.h>

#include "vector.h"
#include "particle_private.h"

particle_private_t *particle_private_new()
/***********************************************/
/* Create the private part of the particle     */
/***********************************************/
{
  particle_private_t *pv;

  /* Create the private part */
  pv=(particle_private_t *)g_malloc(sizeof(particle_private_t));

  /* Initialize the private part */
  pv->press=FALSE;
  pv->change_vel=FALSE;
  pv->grupo=NULL;
  pv->item_vel=NULL;
  pv->vel_ci=NULL;
  pv->num=NULL;
  pv->ik_vel= Vector_New(0,0);

  return pv;
}

void particle_private_free(particle_private_t *pv)
/********************************************/
/* Free the memory of the private particle  */
/********************************************/
{
  g_assert(pv!=NULL);
  if (pv==NULL) return;

  free(pv->ik_vel);
  g_free(pv);
}


