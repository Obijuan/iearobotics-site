/*****************************************************/
/* about.c     Abril 2002                            */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#include <gnome.h>

#include "interface.h"
#include "about.h"

/*----------------------------------------*/
/* VARIABLES IMPORTADAS DE OTROS MODULOS  */
/*----------------------------------------*/
extern interface_t interface;


void about(GtkWidget *widget, gpointer data)
/*************************/
/* ABOUT, del menu HELP  */
/*************************/
{
  static GtkWidget* dialog = NULL;

  /* Lista de autores */
  const gchar *authors[] = {
      "Juan Gonzalez <juan@iearobotics.com>",
      "Carlos Venegas (charli)<eventyr@mac.com>",
      NULL
  };

  if(dialog) {
    gtk_widget_show_now(dialog);
    gdk_window_raise(dialog->window);
    return;
  }

  dialog = gnome_about_new(
            "GNewton", VERSION,
            "Cinematica de particulas. Marzo-2002",
             authors, "Licencia GPL",
             NULL);

  gnome_dialog_set_parent(GNOME_DIALOG(dialog), GTK_WINDOW(interface.main_window));
  gtk_signal_connect(GTK_OBJECT(dialog), "destroy",
                      GTK_SIGNAL_FUNC(gtk_widget_destroyed), &dialog);

  gtk_widget_show(dialog);
}


