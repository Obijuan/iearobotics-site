/*****************************************************/
/* NEWTON    (c) Carlos Jesus Venegas Arrabe.        */
/*                                                   */
/* Vector manipulate module.                         */
/*---------------------------------------------------*/
/* Licencia GPL.                                     */
/*****************************************************/

#include <malloc.h>
#include <math.h>
#include "vector.h"

/* *************************************************************** */
/* Vector_New                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to create a new vector.                                */
/*                                                                 */
/* Arguments:                                                      */
/*            x => init x coordenate.                              */
/*            y => init y coordenate.                              */
/*                                                                 */
/* Return:                                                         */
/*            pvector2D => pointer to vector2D structure.          */
/*                                                                 */
/* *************************************************************** */

pvector2D Vector_New(double x,double y)
{
  pvector2D aux;

  aux=(pvector2D)malloc(sizeof(vector2D));
  
  if (aux==NULL) return NULL;

  aux->cords.x=x;
  aux->cords.y=y;
  aux->module=Vector_Module(aux);

  return aux;
}


/* *************************************************************** */
/* Vector_Assign                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to assign vector to other.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1=> the vector to copy in.                          */
/*            v2=> vector to duplicate.                            */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline int Vector_Assign(pvector2D v1, pvector2D v2)
{
  if ((v1 == NULL) || (v2==NULL)) return -1;

  //*v1=*v2;
  v1->cords.x=v2->cords.x;
  v1->cords.y=v2->cords.y;
  v1->module=v2->module;

  return 0;
}


/* *************************************************************** */
/* Vector_Set_Comp                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's components.                         */
/*                                                                 */
/* Arguments:                                                      */
/*            x,y => components to the vector.                     */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline int Vector_Set_Comp(double x, double y, pvector2D v1)
{
  if(v1==NULL) return -1;
  
  v1->cords.x=x;
  v1->cords.y=y;

  return 0;
}


/* *************************************************************** */
/* Vector_Set_x                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's x component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            x => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline int Vector_Set_x(double x, pvector2D v1)
{
  if(v1==NULL) return -1;
  
  v1->cords.x=x;

  return 0;
}


/* *************************************************************** */
/* Vector_Set_y                                                    */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's y component .                       */
/*                                                                 */
/* Arguments:                                                      */
/*            y => component to the vector.                        */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline int Vector_Set_y(double y, pvector2D v1)
{
  if(v1==NULL) return -1;
  
  v1->cords.y=y;

  return 0;
}

/* *************************************************************** */
/* Vector_Set_mod                                                  */ 
/* ---------------                                                 */
/*                                                                 */
/* Function to assign vector's module.                             */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector to update.                              */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* *************************************************************** */

inline int Vector_Set_mod(pvector2D v1)
{
  if (v1==NULL) return -1;

  v1->module=Vector_Module(v1);

  return 0;
}


/* *************************************************************** */
/* Vector_Module                                                   */
/* -------------                                                   */
/*                                                                 */
/* Function to calculate the vector's module.                      */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*                                                                 */
/* Return:                                                         */
/*            double => vector's module.                           */
/*                                                                 */
/* *************************************************************** */

double Vector_Module(pvector2D v)
{
  if (v==NULL) return -1.0;
  
  else return sqrt((v->cords.x * v->cords.x) + (v->cords.y * v->cords.y));
}


/* *************************************************************** */
/* Vector_Add                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the add of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 + v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

int Vector_Add(pvector2D v1, pvector2D v2, pvector2D result)
{

  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return -1;
  
  result->cords.x=v1->cords.x + v2->cords.x;
  result->cords.y=v1->cords.y + v2->cords.y;
  result->module=Vector_Module(result);
  
  return 0;
}


/* *************************************************************** */
/* Vector_Sub                                                      */
/* ----------                                                      */
/*                                                                 */
/* Function to calculate the sub of two vectors.                   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 - v2.                                   */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

int Vector_Sub(pvector2D v1, pvector2D v2, pvector2D result)
{

  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return -1;
  
  result->cords.x=v1->cords.x - v2->cords.x;
  result->cords.y=v1->cords.y - v2->cords.y;
  result->module=Vector_Module(result);
  
  return 0;
}


/* *************************************************************** */
/* Vector_MK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that multiply a vector for a constant.                 */
/*                                                                 */
/* Arguments:                                                      */
/*            v => vector.                                         */
/*            k => constant.                                       */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */
 
int Vector_MK(pvector2D v, double k, pvector2D result)
{

  if ((v == NULL) || (result == NULL)) return -1;
  
  result->cords.x =v->cords.x * k;
  result->cords.y=v->cords.y * k;
  result->module=v->module * k;
  
  return 0;
}


/* *************************************************************** */
/* Vector_MK                                                       */
/* ---------                                                       */
/*                                                                 */
/* Function that calculate de unitary vector from v1.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector.                                        */
/*            result => k * v1.                                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*                                                                 */
/* *************************************************************** */

int Vector_Unit(pvector2D v1, pvector2D result)
{

  if ((v1 == NULL) || (result == NULL)) return -1;
  
  result->cords.x=v1->cords.x / v1->module;
  result->cords.y=v1->cords.y / v1->module;
  result->module=1;
  
  return 0;
}


/* *************************************************************** */
/* Vector_Dotp                                                     */
/* -----------                                                     */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* algebraic method.                                               */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

int Vector_Dotp(pvector2D v1, pvector2D v2,double *result)
{

  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return -1;
  
  *result=(v1->cords.x * v2->cords.x) + (v1->cords.y * v2->cords.y);
  
  return 0;
}


/* *************************************************************** */
/* Vector_DotpMod                                                  */
/* --------------                                                  */
/*                                                                 */
/* Function that calculate de dot product for vectors, with        */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in radians.         */
/*            result => v1 ? v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

int Vector_DotpMod(pvector2D v1, pvector2D v2,double angle,double *result)
{

  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return -1;
  
  *result=v1->module * v2->module * cos(angle);
  
  return 0;
}


/* *************************************************************** */
/* Vector_AngleDeg                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors.              */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in degrees.                                   */
/*                                                                 */
/* *************************************************************** */

int Vector_AngleDeg(pvector2D v1, pvector2D v2, double *angle)
{
  double cos;

  if ((v1 == NULL) || (v2 == NULL)) return -1;
  
  cos=((v1->cords.x*v2->cords.x) + (v1->cords.y*v2->cords.y)) /
         (double)(v1->module * v2->module) ;
  
  *angle=180.0*acos(cos)/PI;

  return 0;
}


/* *************************************************************** */
/* Vector_AngleRad                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate angle between two vectors in radians.   */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2.                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ? This notation is for dot product.                        */
/*      The angle is in radians.                                   */
/*                                                                 */
/* *************************************************************** */

int Vector_AngleRad(pvector2D v1, pvector2D v2, double *angle)
{
  double cos;

  if ((v1 == NULL) || (v2 == NULL)) return -1;
  
  cos=((v1->cords.x*v2->cords.x) + (v1->cords.y*v2->cords.y)) /
         (double)(v1->module * v2->module) ;

  *angle=acos(cos);

  return 0;
}


/* *************************************************************** */
/* Vector_VectpMod                                                 */
/* ---------------                                                 */
/*                                                                 */
/* Function that calculate the module of vectorial product , with  */
/* geometry method.                                                */
/*                                                                 */
/* Arguments:                                                      */
/*            v1 => vector one.                                    */
/*            v2 => vector two.                                    */
/*            angle => angle between v1 and v2 in radians.         */
/*            result => v1 ^ v2                                    */
/*                                                                 */
/* Return:                                                         */
/*            -1 if error.                                         */
/*             0 if OK.                                            */
/*                                                                 */
/* Note:                                                           */
/*      The function don't reserved memory for any argyment.       */
/*      ^ This notation is for dot product.                        */
/*                                                                 */
/* *************************************************************** */

int Vector_VectpMod(pvector2D v1, pvector2D v2,double angle,double *result)
{

  if ((v1 == NULL) || (v2 == NULL) || (result == NULL)) return -1;
  
  *result=v1->module * v2->module * sin(angle)*180.0/PI;
  
  return 0;
}
