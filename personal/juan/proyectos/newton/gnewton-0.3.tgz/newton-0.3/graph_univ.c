/*****************************************************/
/* graph_univ.c  Abril 2002. (c) Juan Gonzalez       */
/*---------------------------------------------------*/
/* Graphical universe                                */
/*---------------------------------------------------*/
/* GPL License                                       */
/*****************************************************/

#include <gnome.h>

#include "univ.h"
#include "graph_univ.h"
#include "vector.h"
#include "particle.h"
#include "particle_private.h"

gboolean graph_univ_particle_event(GnomeCanvasItem *item, GdkEvent *event, gpointer data)
/****************************************************************************/
/* Particle Event handle function. It's called when an event ocurr on any   */
/* particle                                                                 */
/****************************************************************************/
{
  gint i;
  gdouble module;
  vector2D vec;
  vector2D mouse_pos; /* Mouse Position vector */
  particle_t *part;

  /* Get the particle that generated the event */
  i = GPOINTER_TO_INT(data);
  part=univ_get_particle(i);

  g_assert(part!=NULL);

  /* Get the mouse position */
  Vector_Set_x(event->motion.x,&mouse_pos);
  Vector_Set_y(event->motion.y,&mouse_pos);

  /*------------------------------------------------------*/
  /* Left button pressed on the item group of particle i  */
  /*------------------------------------------------------*/
  if(event->type == GDK_BUTTON_PRESS && event->button.button==1) {

    /* Calculate the module of the vector that starts at the   */
    /* mouse position and ends in the center of the particle   */

    /* vec=mouse_pos - particle_pos */
    Vector_Sub(&mouse_pos,&(PPARTICLE_T_STATE(part).pos),&vec);
    module=Vector_Module(&vec);

    /* Get the item that was selected */
    if (module<=(gdouble)DIAMETRO/2) { /* The particle was selected...*/
      PPARTICLE_PRIVATE(part)->press=TRUE;
    }
    else {   /* Velocity vector selected */
      PPARTICLE_PRIVATE(part)->change_vel=TRUE;
    }
    return TRUE;
  }


  /*-----------------------------------------------------*/
  /* MOVIMIENTO DE LOS VECTORES DE LA CINEMATICA DIRECTA */
  /*-----------------------------------------------------*/
  if (PPARTICLE_PRIVATE(part)->change_vel && event->type == GDK_MOTION_NOTIFY) {

    /* Get the new velocity vector: vel= mouse_pos - particle_pos */
    Vector_Sub(&mouse_pos, &(PPARTICLE_T_STATE(part).pos), &(PPARTICLE_T_STATE(part).vel));

    /* Calculate the "visual" module of the vector */
    Vector_MK(&(PPARTICLE_T_STATE(part).vel),1/FVV,&(PPARTICLE_T_STATE(part).vel));

    graph_univ_draw();
    return TRUE;
  }

  /*-----------------------------*/
  /* MOVIMIENTO DE LA PARTICULA  */
  /*-----------------------------*/
  if (PPARTICLE_PRIVATE(part)->press && event->type == GDK_MOTION_NOTIFY) {

     Vector_Assign(&PPARTICLE_T_STATE(part).pos,&mouse_pos);

     /* Redibujar */
     graph_univ_draw();

     return TRUE;
   }

   /*----------------*/
   /* BOTON SOLTADO  */
   /*----------------*/
   if (event->type == GDK_BUTTON_RELEASE) {
     PPARTICLE_PRIVATE(part)->press=FALSE;
     PPARTICLE_PRIVATE(part)->change_vel=FALSE;
     return TRUE;
   }

  /* No capturado, devolver FALSE */
  return FALSE;
}


void graph_univ_draw(void)
/*******************************************************************/
/* Re-calculate the position of the CANVAS items accoding to the   */
/* state of the particles of the universe                          */
/*******************************************************************/
{
  vector2D vel;
  vector2D posi;
  GnomeCanvasPoints *points;
  particle_t *part;


  part=univ_get_first_particle();

  while (part!=NULL) {

    /* Obtener las coordenadas del centro de la particula  */
    /* que se encuentra en el CANVAS                       */
    gtk_object_get(
      GTK_OBJECT(PPARTICLE_PRIVATE(part)->grupo),
      "x", &(v_x(posi)),
      "y", &(v_y(posi)),
      NULL);

    /* Calcular el vector velocidad, como la variacion del */
    /* vector de posicion: vel=pos-posi                    */
    Vector_Sub(&(PPARTICLE_T_STATE(part).pos),&posi,&vel);

    /* Mover la particula (y su grupo) a la nueva posicion */
    gnome_canvas_item_move(GNOME_CANVAS_ITEM(PPARTICLE_PRIVATE(part)->grupo),v_x(vel),v_y(vel));

    /* Dibujar el nuevo vector velocidad de cinematica directa */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=v_x(PPARTICLE_T_STATE(part).vel)*FVV;
    points->coords[3]=v_y(PPARTICLE_T_STATE(part).vel)*FVV;

    gnome_canvas_item_set(
         PPARTICLE_PRIVATE(part)->item_vel,
        "points", points,
         NULL);
    gnome_canvas_points_free(points);

    /* Dibujar el vector velocidad de cinematica inversa */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=PPARTICLE_PRIVATE_IK_VEL_X(part)*FVV;
    points->coords[3]=PPARTICLE_PRIVATE_IK_VEL_Y(part)*FVV;

    gnome_canvas_item_set(
         PPARTICLE_PRIVATE(part)->vel_ci,
        "points", points,
         NULL);
    gnome_canvas_points_free(points);

    part=univ_get_next_particle();
  }
}

void graph_univ_add_particle(GnomeCanvas *canvas,particle_t *part,int num)
/**************************************************/
/* Create a new interfaz for the particle         */
/**************************************************/
{
  GnomeCanvasItem *item;
  GnomeCanvasPoints *points;
  gchar cad[5];

  /* Create the group for the particle i */
  item = gnome_canvas_item_new(
     gnome_canvas_root(canvas),
     gnome_canvas_group_get_type(),
     "x", v_x(PPARTICLE_T_STATE(part).pos),
     "y", v_y(PPARTICLE_T_STATE(part).pos),
      NULL);

  /* Guardar grupo */
  PPARTICLE_PRIVATE(part)->grupo=GNOME_CANVAS_GROUP(item);

  /* Funcion de retro-llamada de la particula y sus items asociados */
  gtk_signal_connect(GTK_OBJECT(item), "event",
                     GTK_SIGNAL_FUNC(graph_univ_particle_event),
                     GINT_TO_POINTER(num));

  /* Crear PARTICULA                                          */
  /* Dentro del grupo de cada particula, el origen esta en el */
  /* centro de la particula                                   */
  item=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo,
    gnome_canvas_ellipse_get_type(),
     "outline_color", "dark gray",
     "x1",(gdouble)(-DIAMETRO/2),
     "y1",(gdouble)(-DIAMETRO/2),
     "x2",(gdouble)(DIAMETRO/2),
     "y2",(gdouble)(DIAMETRO/2),
     "fill_color", "red",
     "outline_color", "red",
     "width_pixels", 1,
     NULL);

  /* Crear el texto con el numero de la particula */
  sprintf (cad,"%d",part->id);
  PPARTICLE_PRIVATE(part)->num = gnome_canvas_item_new (PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_text_get_type(),
     "text", cad, "x", (gdouble) -DIAMETRO, "y",(gdouble) DIAMETRO,
     "anchor", GTK_ANCHOR_WEST, "font", "fixed",
     "fill_color", "red",NULL);

  /* Inicialmente no visualizar numero particula */
  gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->num);

  /* Vector velocidad (Cinematica directa) */
  points = gnome_canvas_points_new(2);
  points->coords[0]=0.0;
  points->coords[1]=0.0;
  points->coords[2]=v_x(PPARTICLE_T_STATE(part).vel);
  points->coords[3]=v_y(PPARTICLE_T_STATE(part).vel);

  PPARTICLE_PRIVATE(part)->item_vel=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_line_get_type(),
    "points", points, "fill_color", "black",
    "width_units", 0.0, "join_style", GDK_CAP_BUTT,
    "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
    "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
  gnome_canvas_points_free(points);

  /* Inicialmente no visualizar vectores velocidad */
  gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->item_vel);

  /* Vector velocidad (Cinematica inversa) */
  points = gnome_canvas_points_new(2);
  points->coords[0]=0.0;
  points->coords[1]=0.0;
  points->coords[2]=PPARTICLE_PRIVATE_IK_VEL_X(part);
  points->coords[3]=PPARTICLE_PRIVATE_IK_VEL_Y(part);

  PPARTICLE_PRIVATE(part)->vel_ci=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_line_get_type(),
    "points", points, "fill_color", "black",
    "width_units", 0.0, "join_style", GDK_CAP_BUTT,
    "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
    "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
  gnome_canvas_points_free(points);

  /* Inicialmente no visualizar vectores de velocidad CI */
  gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->vel_ci);

}

void graph_univ_create(GnomeCanvas *canvas)
/***********************************/
/* Create the graphical universe   */
/***********************************/
{
  GnomeCanvasItem *item;
  GnomeCanvasPoints *points;
  particle_t *part;
  gchar cad[5];
  int i=0;

  part=univ_get_first_particle();

  while (part!=NULL) {

    /* Create the group for the particle i */
    item = gnome_canvas_item_new(
       gnome_canvas_root(canvas),
       gnome_canvas_group_get_type(),
       "x", v_x(PPARTICLE_T_STATE(part).pos),
       "y", v_y(PPARTICLE_T_STATE(part).pos),
        NULL);

    /* Guardar grupo */
    PPARTICLE_PRIVATE(part)->grupo=GNOME_CANVAS_GROUP(item);

    /* Funcion de retro-llamada de la particula y sus items asociados */
    gtk_signal_connect(GTK_OBJECT(item), "event",
                       GTK_SIGNAL_FUNC(graph_univ_particle_event),
                       GINT_TO_POINTER(part->id));

    /* Crear PARTICULA                                          */
    /* Dentro del grupo de cada particula, el origen esta en el */
    /* centro de la particula                                   */
    item=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo,
      gnome_canvas_ellipse_get_type(),
       "outline_color", "dark gray",
       "x1",(gdouble)(-DIAMETRO/2),
       "y1",(gdouble)(-DIAMETRO/2),
       "x2",(gdouble)(DIAMETRO/2),
       "y2",(gdouble)(DIAMETRO/2),
       "fill_color", "red",
       "outline_color", "red",
       "width_pixels", 1,
       NULL);

    /* Crear el texto con el numero de la particula */
    sprintf (cad,"%d",part->id);
    PPARTICLE_PRIVATE(part)->num = gnome_canvas_item_new (PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_text_get_type(),
       "text", cad, "x", (gdouble) -DIAMETRO, "y",(gdouble) DIAMETRO,
       "anchor", GTK_ANCHOR_WEST, "font", "fixed",
       "fill_color", "red",NULL);

    /* Inicialmente no visualizar numero particula */
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->num);

    /* Vector velocidad (Cinematica directa) */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=v_x(PPARTICLE_T_STATE(part).vel);
    points->coords[3]=v_y(PPARTICLE_T_STATE(part).vel);

    PPARTICLE_PRIVATE(part)->item_vel=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_line_get_type(),
      "points", points, "fill_color", "black",
      "width_units", 0.0, "join_style", GDK_CAP_BUTT,
      "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
      "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
    gnome_canvas_points_free(points);

    /* Inicialmente no visualizar vectores velocidad */
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->item_vel);

    /* Vector velocidad (Cinematica inversa) */
    points = gnome_canvas_points_new(2);
    points->coords[0]=0.0;
    points->coords[1]=0.0;
    points->coords[2]=PPARTICLE_PRIVATE_IK_VEL_X(part);
    points->coords[3]=PPARTICLE_PRIVATE_IK_VEL_Y(part);

    PPARTICLE_PRIVATE(part)->vel_ci=gnome_canvas_item_new(PPARTICLE_PRIVATE(part)->grupo, gnome_canvas_line_get_type(),
      "points", points, "fill_color", "black",
      "width_units", 0.0, "join_style", GDK_CAP_BUTT,
      "last_arrowhead",TRUE, "arrow_shape_a", 3.0,
      "arrow_shape_b",5.0, "arrow_shape_c", 5.0, NULL);
    gnome_canvas_points_free(points);

    /* Inicialmente no visualizar vectores de velocidad CI */
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->vel_ci);

    i++;
    part=univ_get_next_particle();
  }

}

void graph_univ_show_velocity_vel()
/***********************************************************/
/* Show the direct velocity vector of all the particles in */
/* the universe                                            */
/***********************************************************/
{
  particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_show(PPARTICLE_PRIVATE(part)->item_vel);
    part=univ_get_next_particle();
  }
}

void graph_univ_hide_velocity_vel()
/***********************************************************/
/* Hide the direct velocity vector of all the particles in */
/* the universe                                            */
/***********************************************************/
{
  particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->item_vel);
    part=univ_get_next_particle();
  }
}

void graph_univ_show_particle_num()
/************************************************************/
/* Show the number of all the particles in the universe     */
/************************************************************/
{
 particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_show(PPARTICLE_PRIVATE(part)->num);
    part=univ_get_next_particle();
  }
}

void graph_univ_hide_particle_num()
/************************************************************/
/* Hide the number of all the particles in the universe     */
/************************************************************/
{
 particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->num);
    part=univ_get_next_particle();
  }
}

void graph_univ_show_ik_velocity_vel()
/*********************************************************/
/* Show the "inverse kinematics" velocity vector of      */
/* number of all the particles in the universe           */
/*********************************************************/
{
 particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_show(PPARTICLE_PRIVATE(part)->vel_ci);
    part=univ_get_next_particle();
  }
}

void graph_univ_hide_ik_velocity_vel()
/*********************************************************/
/* Hide the "inverse kinematics" velocity vector of      */
/* number of all the particles in the universe           */
/*********************************************************/
{
 particle_t *part;

  part=univ_get_first_particle();

  while (part!=NULL) {
    gnome_canvas_item_hide(PPARTICLE_PRIVATE(part)->vel_ci);
    part=univ_get_next_particle();
  }
}







