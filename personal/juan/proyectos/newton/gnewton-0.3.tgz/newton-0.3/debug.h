/*****************************************************/
/* debug.h       Abril 2002                          */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/


#ifndef _DEBUG_H
#define _DEBUG_H

#include "vector.h"
#include "particle.h"

void particle_print(particle_t *p);
void vector_print(vector2D *v);

#endif  /* _DEBUG_H */
