/*****************************************************/
/* debug.c    april 2002                             */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/


#include <gnome.h>


#include "vector.h"
#include "particle.h"
#include "particle_private.h"
#include "debug.h"

void vector_print(vector2D *v)
/************************/
/* Print the vector     */
/************************/
{
  g_print("(%.1f , %.1f)",v->cords.x,v->cords.y);
}

void particle_private_print(particle_private_t *p)
/*******************************************/
/* Print the private part of the particle  */
/*******************************************/
{
  g_print("  IK_VEL: ");
  vector_print(p->ik_vel);
  g_print("\n");
}

void particle_print(particle_t *p)
/*****************************/
/* Print the data particle   */
/******************************/
{
  g_print("--------------\n");
  g_print("Particula: %d\n",p->id);
  g_print("  ESTADO INICIAL:");
  g_print("  pos: ");
    vector_print(&PPARTICLE_INIT_STATE(p).pos);
  g_print("  Vel: ");
    vector_print(&PPARTICLE_INIT_STATE(p).vel);
  g_print("  Acel: ");
    vector_print(&PPARTICLE_INIT_STATE(p).acel);
  g_print("\n");

  g_print("  ESTADO T      :");
  g_print("  pos: ");
    vector_print(&PPARTICLE_T_STATE(p).pos);
  g_print("  Vel: ");
    vector_print(&PPARTICLE_T_STATE(p).vel);
  g_print("  Acel: ");
    vector_print(&PPARTICLE_T_STATE(p).acel);
  g_print("\n");

  g_print("  ESTADO_OLD    :");
  g_print("  pos: ");
    vector_print(&PPARTICLE_OLD_STATE(p).pos);
  g_print("  Vel: ");
    vector_print(&PPARTICLE_OLD_STATE(p).vel);
  g_print("  Acel: ");
    vector_print(&PPARTICLE_OLD_STATE(p).acel);
  g_print("\n");

  g_print("  PRIVATE: ");
  if (PPARTICLE_PRIVATE(p)==NULL) g_print ("NULL!\n");
  else particle_private_print(PPARTICLE_PRIVATE(p));

  g_print("--------------\n");

}




