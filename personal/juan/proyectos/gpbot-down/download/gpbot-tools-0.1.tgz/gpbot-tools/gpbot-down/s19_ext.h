/****************************************************/
/* s19_ext.h  (c) Juan Gonzalez Gomez. Febrero 2004 */
/*--------------------------------------------------*/
/* Extensiones al modulo s19.c                      */
/****************************************************/

/*******************************************/
/* Imprimir los datos de la estructura S19 */
/* Usado para depuracion                   */
/*******************************************/
void s19_print(S19 mis19);

/******************************************************************/
/* Ordenar una estructura S19, en orden creciente de direcciones  */
/******************************************************************/
void s19_ordenar(S19 mis19);

/*****************************************************************/
/* Obtener la palabra (2 bytes) que se encuentra a partir de la  */
/* direcion especificada                                         */
/*---------------------------------------------------------------*/
/* ENTRADAS:                                                     */
/*   -mis19: Datos del S19. DEBEN ESTAR ORDENADOS EN ORDEN       */
/*           CRECIENTE DE DIRECIONES                             */
/*   -dir: Direccion de acceso                                   */
/* SALIDAS:                                                      */
/*   -valor: Contenido de la direccion                           */
/* DEVUELVE:                                                     */
/*   1 : La direccion existe en el S19                           */
/*   0 : La direccion NO existe                                  */
/*---------------------------------------------------------------*/
/* NOTA: La estructura mis19 debe estar ORDENADA EN ORDEN        */
/*  CRECIENTE DE DIRECCIONES                                     */
/*****************************************************************/
int s19_get_word(S19 mis19, unsigned int dir, unsigned int *valor);

/*****************************************************************/
/* Obtener el byte que se encuentra en la direcion especificada  */
/*---------------------------------------------------------------*/
/* ENTRADAS:                                                     */
/*   -mis19: Datos del S19. DEBEN ESTAR ORDENADOS EN ORDEN       */
/*           CRECIENTE DE DIRECIONES                             */
/*   -dir: Direccion de acceso                                   */
/* SALIDAS:                                                      */
/*   -valor: Contenido de la direccion                           */
/* DEVUELVE:                                                     */
/*   1 : La direccion existe en el S19                           */
/*   0 : La direccion NO existe                                  */
/*---------------------------------------------------------------*/
/* NOTA: La estructura mis19 debe estar ORDENADA EN ORDEN        */
/*  CRECIENTE DE DIRECCIONES                                     */
/*****************************************************************/
int s19_get_byte(S19 mis19, unsigned int dir, unsigned char *valor);
