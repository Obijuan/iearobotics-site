/******************************************************/
/* s19_ext.c   (c) Juan Gonzalez Gomez. Febrero 2004  */
/*----------------------------------------------------*/
/* Extensiones al modulo .S19                         */
/******************************************************/

#include <stdio.h>

#include "s19.h"
#include "ascbin.h"

/************************/
/* Funciones privadas   */
/************************/
/***********************************/
/* Hacer una copia de un registro1 */
/***********************************/
void copiar(struct registros1 *orig, struct registros1 *copia)
{
	int i;
	
	/*-- Hacer una copia de ese registro --*/
	copia->tam=orig->tam;
	copia->dir=orig->dir;
	for (i=0; i<37; i++) {
		copia->codigo[i]=orig->codigo[i];
	}
	copia->crc=orig->crc;
	copia->sig=orig->sig;
}

/**********************************************************************/
/* Intercambiar el registro indicado con el siguiente                 */
/*--------------------------------------------------------------------*/
/* ENTRADAS:                                                          */
/*    -reg: Indice del primer registro (1..max)                       */
/**********************************************************************/
int intercambiar(S19 ss19, int nreg)
{
	struct registros1 *punt=NULL;
	struct registros1 *ps=NULL;
	struct registros1 copia;
	int reg=1;      /* Comenzar la busqueda por el registro 1 */
	
	/* Si es el ultimo registro, no se puede intercambiar */
	if (nreg>=ss19.nreg) return 1;
	
  punt=ss19.cabeza;
  while(punt!=NULL) {
    if (reg==nreg) {
      break;
    }
    punt=punt->sig;
    reg++;
  }
  if (punt==NULL) return 0;  /* Registro pedido no se encuentra */
	
	/*-- punt apunta al registro encontrado --*/
	
	//-- Copiar el registro1
	copiar(punt,&copia);
	
	//-- Copiar el siguiente registro sobre el primero
	ps=punt->sig;
	copiar(ps,punt); /* Al copiarse perdemos el valor punt->sig */
	punt->sig=ps;
	
	//-- Copiar el primero sobre el segundo (el primero esta en la copia)
	copia.sig=ps->sig;
	copiar(&copia,ps);
	
	return 1;
}

/***********************************************************************/
/* Se toman los registros desde el principio (1) hasta el "fondo"      */
/* indicado. El que tenga la mayor direccion es el que se coloca en el */
/* "fondo"  (el de mayor peso se "hunde"                               */
/***********************************************************************/
void s19_hundir(S19 mis19, int reg_fondo)
{
	unsigned int nreg;
	unsigned int dir1;
	unsigned int dir2;
	int i;
	
	nreg=mis19.nreg;
	
	/*-- Si el fondo es el primer registro, terminar */
	if (reg_fondo==1) return;
	
	/* Fondo demasiado grande. Se ajusta al numero de registros */
	if (reg_fondo>nreg) reg_fondo=nreg;
		
	for (i=1; i<reg_fondo; i++) {
		leerdir_s19(mis19,i,&dir1);
		leerdir_s19(mis19,i+1,&dir2);
		if (dir1>dir2)
			intercambiar(mis19, i);
  }	
}

/*--------------------------------*/
/* Funciones de interfaz          */
/*--------------------------------*/


/*******************************************/
/* Imprimir los datos de la estructura S19 */
/* Usado para depuracion                   */
/*******************************************/
void s19_print(S19 mis19)
{
	unsigned int nreg;
	unsigned int dir;
	char cad2[5];
	int i,n;
	byte codigo[37];
  byte crc;
  byte tam;
	
  /* ---------------------------- */
  /* ---- VOLCAR EL FICHERO  ---- */
  /* ---------------------------- */
  nreg=getnregs19(mis19);
  printf ("\n");
  printf ("Reg. Dir. tam.                  Codigo/datos\n");

  for (i=1; i<=nreg; i++) {
    leerdir_s19(mis19,i,&dir);
    leercod_s19(mis19,i,codigo,&tam,&crc);
    printf ("%3u %4X  %4u ",i,dir,tam);
    for (n=0; n<tam; n++) {
      bytetochar2(codigo[n],cad2);
      printf ("%s",cad2);
    }
    printf ("\n");

  }
}


/******************************************************************/
/* Ordenar una estructura S19, en orden creciente de direcciones  */
/******************************************************************/
void s19_ordenar(S19 mis19)
{
  unsigned int nreg;
	int i;
	
  nreg=mis19.nreg;
	for (i=nreg; i>1; i--) {
	  s19_hundir(mis19,i);
	}
}


/*****************************************************************/
/* Obtener el byte que se encuentra en la direcion especificada  */
/*---------------------------------------------------------------*/
/* ENTRADAS:                                                     */
/*   -mis19: Datos del S19. DEBEN ESTAR ORDENADOS EN ORDEN       */
/*           CRECIENTE DE DIRECIONES                             */
/*   -dir: Direccion de acceso                                   */
/* SALIDAS:                                                      */
/*   -valor: Contenido de la direccion                           */
/* DEVUELVE:                                                     */
/*   1 : La direccion existe en el S19                           */
/*   0 : La direccion NO existe                                  */
/*---------------------------------------------------------------*/
/* NOTA: La estructura mis19 debe estar ORDENADA EN ORDEN        */
/*  CRECIENTE DE DIRECCIONES                                     */
/*****************************************************************/
int s19_get_byte(S19 mis19, unsigned int dir, unsigned char *valor)
{
	
	unsigned int nreg;
	unsigned int dir_reg;
	int i;
	byte codigo[37];
  byte crc;
  byte tam;
	
	//-- Obtener el numero total de registros
  nreg=getnregs19(mis19);

	//-- Recorrer los registros hasta encontrar la direccion buscada
  for (i=1; i<=nreg; i++) {
    leerdir_s19(mis19,i,&dir_reg);
    leercod_s19(mis19,i,codigo,&tam,&crc);
		
		//-- La direccion de este registro es mayor
		//-- Aqui no esta
		if (dir<dir_reg) {
			*valor=0;
			return 0;
		}
		
		//-- La direccion buscada esta en este registro
		if (dir>=dir_reg && dir<(dir_reg+tam)) {
			*valor=codigo[dir-dir_reg];
			return 1;
		}
  }
	//-- Si se llega hasta aqui es que no se ha encontrado
	*valor=0;
	return 0;
}

/*****************************************************************/
/* Obtener la palabra (2 bytes) que se encuentra a partir de la  */
/* direcion especificada                                         */
/*---------------------------------------------------------------*/
/* ENTRADAS:                                                     */
/*   -mis19: Datos del S19. DEBEN ESTAR ORDENADOS EN ORDEN       */
/*           CRECIENTE DE DIRECIONES                             */
/*   -dir: Direccion de acceso                                   */
/* SALIDAS:                                                      */
/*   -valor: Contenido de la direccion                           */
/* DEVUELVE:                                                     */
/*   1 : La direccion existe en el S19                           */
/*   0 : La direccion NO existe                                  */
/*---------------------------------------------------------------*/
/* NOTA: La estructura mis19 debe estar ORDENADA EN ORDEN        */
/*  CRECIENTE DE DIRECCIONES                                     */
/*****************************************************************/
int s19_get_word(S19 mis19, unsigned int dir, unsigned int *valor)
{
	int peso=1;   //-- Peso=0 se busca el byte de mayor peso, peso=0 el menor
	unsigned byte1;  //-- Byte de mayor peso (el primero)
	unsigned byte0;  //-- Byte de menor peso (el segundo)
	unsigned int nreg;
	unsigned int dir_reg;
	int i;
	byte codigo[37];
  byte crc;
  byte tam;
	
	//-- Obtener el numero total de registros
  nreg=getnregs19(mis19);

	//-- Recorrer los registros hasta encontrar la direccion buscada
  for (i=1; i<=nreg; i++) {
    leerdir_s19(mis19,i,&dir_reg);
    leercod_s19(mis19,i,codigo,&tam,&crc);
		
		//-- La direccion de este registro es mayor
		//-- Aqui no esta
		if (dir<dir_reg) {
			*valor=0;
			return 0;
		}
		
		//-- La direccion buscada esta en este registro
		if (dir>=dir_reg && dir<(dir_reg+tam)) {
			//-- La palabra entera esta en este bloque
			if ((dir+1)<(dir_reg+tam) && peso==1) { 
				byte1=codigo[dir-dir_reg];
				byte0=codigo[dir-dir_reg+1];
				*valor=byte1*256 + byte0;
				return 1;
			}
			//-- Si llega aqui es que la palabra esta partida, estado
			//-- un byte en cada registro
				
			if (peso==1) { //--Encontrado primer byte
				peso--;
				byte1=codigo[dir-dir_reg];  //-- Leerlo
				dir++; //-- Buscar el siguiente byte
			}
			else {  //-- Encontrado el segundo byte
				byte0=codigo[dir-dir_reg];
				*valor=byte1*256 + byte0;
				return 1;
			}
		}
  }
	//-- Si se llega hasta aqui es que no se ha encontrado
	*valor=0;
	return 0;
}
