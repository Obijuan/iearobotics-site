/**************************************************/
/* gpbot-down.c      Juan Gonzalez Gomez.         */
/*------------------------------------------------*/
/* Programa para grabar en la flash de la GPBOT   */
/* fichero .S19                                   */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "termansi.h"
#include "gp_monitor.h"
#include "sg-serial.h"
#include "s19.h"
#include "contenedor.h"
#include "ejecuta.h"
#include "s19_ext.h"

#define VECTORES 0xFFDC  //-- Direccion de comienzo vectores int.

const char version[]={"0.1"};
const char fecha[]={"Febrero 2004"};

/***********************************/
/*             VARIABLES           */
/***********************************/
char disp_serie[80];     /* Puerto serie.              */
char fich[80];			     /* Fichero                    */
unsigned int dir_ini=0;  /* Direccion de arranque      */
char fich[80];
int flag_verbose=0;      // Modo verboso

/*****************************/
/*    FUNCIONES              */
/*****************************/

void grabar(int serial_fd, char *fich_name)
{
	S19 mis19;
	char *caderror;
	int dir;
	int dir_bloque;       //-- Direccion alineada
	int dir_ini;			    //-- Direccion menor del codigo
	int dir_rst;          //-- Direccion a la que apunta el vector reset
	int dir_rst_ok;
	unsigned char valor;
	unsigned char *block;
	int ok;
	int vectores=0;   // Indica si el bloque es de los vectores de int.
	int status;
	
	if (flag_verbose) {
    printf ("Grabar fichero: %s\n",fich_name);
	}	
	
	if (abrir_s19(fich,&mis19,1)==0) {
    caderror=(char *)geterrors19();
    printf ("Error: %s\n",caderror);
    return;
  }
	if (flag_verbose) {
	  printf ("OK, fichero abierto\n");
		printf ("-->Fichero S19 sin ordenar\n");
  	s19_print(mis19);
	}	
	
	//-- Ordenar todos los bytes de codigo en orden creciente
	//-- de direcciones
	s19_ordenar(mis19);
	
	if (flag_verbose) {
		printf ("-->Fichero S19 ORDENADO\n");
	  s19_print(mis19);
	}

  printf ("Tama�o: %d bytes\n",getnbytes19(mis19));
	
	printf ("Borrando Flash..."); fflush(stdout);
	status=gp_monitor_borrar_flash(serial_fd);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("OK\n");
	
	//-- Entrar en modo monitor
  if (!gp_monitor_configure(serial_fd)) {
    printf ("ERROR: No se ha entrado en modo monitor\n");
    return;
  }
	
	if (flag_verbose)
	  printf ("--> Entrando en modo monitor\n");
	
	//-- Obtener la direccion a la que apunta el vector de reset
	dir_rst_ok=s19_get_word(mis19,0xfffe,&dir_rst);
	
	//-- Procesar el archivo
	dir=ejecuta_init(&mis19);
	
	//-- Si se habia definido el vector de reset se toma como
	//-- direccion de inicio
	if (dir_rst_ok) {
		printf ("Vector de RESET: %04X\n",dir_rst);
		dir_ini=dir_rst;
	}
	else {  //-- Sino, se toma la primera que aparece (la mas baja)
		dir_ini=dir;
	}
	
	if (flag_verbose)
	  printf ("Direccion inicial: %X\n",dir_ini);
	
	do {
		//-- Obtener un contenedor vacio
		contenedor_init();
		
		//-- El siguiente bloque NO es de datos, sino vectores de int.
		if (dir>=VECTORES && dir<=0xFFFF) {
			vectores=1;
			dir_bloque=VECTORES;
			contenedor_insert_padding(0xFF, dir-dir_bloque);
		}
		else { //-- Bloque de DATOS
			vectores=0;
			//-- Rellenarlo con 0s, desde la direccion de comienzo
			//-- del bloque hasta la direccion actual
			dir_bloque = (dir&0xFFC0);  //-- Obtener dir del bloque flash
			contenedor_insert_padding(0,dir-dir_bloque);
		}
		
		//-- Insertar bytes hasta llenar contenedor
		while (contenedor_get_espacio()>0) {
			ejecuta_next_byte(&valor,&dir); //-- Leer siguiente byte
			contenedor_insert_byte(valor);  //-- Meterlo en contenedor
		}
		
		//-- Contenedor lleno. Listo para grabar
		
		//-- Obtener el puntero al contenedor
		block=contenedor_get();
		
		if (vectores) {
			printf ("Vectores de interrupcion...");
			fflush(stdout);
			gp_monitor_program_vectors(serial_fd, block);
		}
		else {
			printf ("Grabando bloque de datos...");
			fflush(stdout);
			gp_monitor_program_block_flash(serial_fd,dir_bloque,block);
		}	
		printf ("OK\n");
		
		//-- Imprimir el bloque (Depuracion)
		if (flag_verbose)
		  contenedor_print();
		
		//-- Saltar al siguiente bloque de datos
		ok=ejecuta_next_block(&dir);
	} while (ok);	
	
	printf ("FINALIZADO\n");
	
	//-- MODIFICAR!!! Que la direccion de ejecucion NO sea la inicial
	//-- por defecto, sino que se tome del vector de reset, si existe
	status=gp_monitor_ejecutar(serial_fd, dir_ini);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("-->EJECUTANDO!!!\n");
	printf ("\n");
	
	cerrar_s19(mis19);
}

void presenta()
/******************************************/
/* Encabezado de presentacion del CTLOAD  */
/******************************************/
{
  printf ("\n");
  setcolor(ROJO);
  high();
  printf ("GPBOT-DOWN "); fflush(stdout);
  setcolor(AMARILLO);
  printf (version); fflush(stdout);
  setcolor(VERDE);
  printf (" para LINUX. ");
  setcolor(CYAN);
  printf ("(c) Juan Gonzalez Gomez ");
  printf (fecha);
  printf ("\n");
  setcolor(BLANCO);
  printf ("Descarga de programas en la GPBOT\n\n");
  low();
}

/*********************/
/* Mostrar la ayuda  */
/*********************/
void help()
{
  presenta();
  low();
  high();
  printf ("Forma de uso: ");
  low();
  printf ("gpbot-down fichero.s19 [opciones]\n\n");
  high(); printf ("   -com1   ");
  low();  printf ("Utilizar el COM1\n");
  high(); printf ("   -com2   ");
  low();  printf ("Utilizar el COM2\n");
  high(); printf ("   -h      ");
  low();  printf ("Esta ayuda\n");
  high(); printf ("   -v      ");
  low();  printf ("Modo Verbose (mostrar m�s informacion)\n\n");
  high(); printf ("Ejemplo:  ");
  low();  printf ("gpbot-down ledp.s19 -com2\n\n");
}

/*****************************************************************/
/* Analizar los parametros pasados desde la linea de comandos    */
/* Se actualizan las variables globales:                         */
/*       - puerto: Con el puerto serie especificado              */
/*       - flag_terminal: Si hay que ejecutar el terminal        */
/*---------------------------------------------------------------*/
/* ENTRADAS: Argumentos de la funcion main()                 	   */
/* DEVUELVE:                                                     */
/*    0 : Error                                                  */
/*    1 : OK                                                     */
/*****************************************************************/
int analizar_parametros(int argc, char* argv[])
{
    int c;
	
	  //-- Establecer puerto serie por defecto
		strcpy(disp_serie,"/dev/ttyS0");

    if (argc<2) {
      printf ("\nERROR: No se ha especificado nombre de fichero .s19\n");
      printf ("Utilice gpbot-down -h para obtener ayuda\n\n");
      return 0;
    }  
      
		//-- Obtener el fichero
    strcpy(fich,argv[1]);
		
		//-- Obtener el resto de parametros
    while ((c = getopt(argc, argv, ":c:hv"))!=EOF) {
 			switch (c) {
  	  	case 'c':
        	if (strcmp("om2",optarg)==0) 
						strcpy(disp_serie,"/dev/ttyS1");
          else 
            if (strcmp("om1",optarg)==0)
              strcpy(disp_serie,"/dev/ttyS0");
	    	break;
        case 'v':
        	flag_verbose=1;
          break;  
	  		case 'h':
				default: help();
	        return 0;
			}
    }
		return 1;
}

void main_quit(int serial_fd)
{
  //-- Cerrar puerto serie
  close(serial_fd);
}

int main (int argc, char* argv[])
{
  int serial_fd;  /*-- Descriptor puerto serie */
	int ok;

	printf ("\n");
	printf ("GPBOT-DOWN. (c) Juan Gonzalez. Febrero 2004. Licencia GPL\n");
	printf ("Grabaci�n de programas en la Flash de la tarjeta GPBOT\n");
	printf ("\n");
	
	ok=analizar_parametros(argc,argv);
	if (!ok) return 0;
	
  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Entrar en modo monitor
  if (!gp_monitor_configure(serial_fd)) {
    printf ("ERROR: No se ha entrado en modo monitor\n");
    main_quit(serial_fd);
    exit(1);
  }
	if (flag_verbose) {
    printf ("\n");
    printf ("--> Entrando en MODO MONITOR\n");
	}	
 
  grabar(serial_fd, fich);
  main_quit(serial_fd);

  return 0;
}
