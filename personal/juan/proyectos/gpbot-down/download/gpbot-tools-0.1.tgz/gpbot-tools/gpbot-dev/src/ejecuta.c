/******************************************************/
/* ejecuta.c    Juan Gonzalez Gomez. Feb-2004         */
/*----------------------------------------------------*/
/* Este modulo ofrece una interfaz muy sencilla       */
/* para obtener la informacion del fichero ejecutable */
/* que esta en formato .S19                           */
/******************************************************/

#include <stdio.h>

#include "ejecuta.h"
#include "s19.h"

/*------------------------*/
/* Variables globales     */
/*------------------------*/

static S19 *fichs19;             //-- Fichero S19 empleado
static int dir;                  //-- Direccion actual
static unsigned char tam;        //-- Tamano del bloque
static int nblocks;              //-- Numero de bloques en el s19
static unsigned char bloque[80]; //-- Almacenamiento del bloque
static int ic;									 //-- Indice al byte del bloque actual
static int ib;                   //-- Indice al bloque actual
/*****************************/
/*  FUNCIONES                */
/*****************************/

/***********************************************************************/
/* Inicializar el módulo ejecuta                                       */
/*---------------------------------------------------------------------*/
/* ENTRADAS:                                                           */
/*    Puntero a la estructura S19 que contiene los datos del programa  */
/* DEVUELVE:                                                           */
/*    La direccion de comienzo del primer bloque                       */
/***********************************************************************/
int ejecuta_init(S19 *f) 
{
	unsigned char crc;
	
	//-- Guardar el puntero al tipo S19
	fichs19=f;
	
	//-- Obtener el numero de bloques S19
	nblocks=getnregs19(*fichs19);
	
	//-- Leer la direccion inicial
	leerdir_s19(*fichs19,1,&dir);
	
	//-- Obtener el tamano del bloque
	leercod_s19(*fichs19,1,bloque,&tam,&crc);
	
	//-- Otras inicializaciones
	ic=0;
	ib=1;
	
	return dir;
}

/*-------------------------------------------------------*/
/* Devolver el siguiente byte. Si en esa posicion no hay */
/* nada almacenado, se devuelve un 0                     */
/*-------------------------------------------------------*/
/* SALIDAS:                                              */
/*    valor: Valor que hay en la direccion actual        */
/*    dir_actual: Direccion a la que esta accediendo     */
/* DEVUELVE:                                             */
/*    0 si estamos "fuera" del programa                  */
/*    1 Si estamos en una zona "dentro" del programa     */
/*-------------------------------------------------------*/
int ejecuta_next_byte(unsigned char *valor, int *dir_actual)
{
	int dir_bloque;
	unsigned char crc;
	
	//-- Estamos fuera del último bloque
	if (ib>nblocks) {
		*valor=0;				 //-- Devolver caracter 0
		*dir_actual=dir; //-- Devolver la direccion actual
		dir++;           //-- Incrementar direccion
		return 0;
	}
	
	//-- Leer direccion comienzo bloque actual
	leerdir_s19(*fichs19,ib,&dir_bloque);
	
	if ((dir>=dir_bloque) && (dir<(dir_bloque+tam))) {
		//Caso 1: estamos dentro de un bloque
		*valor=bloque[ic];         // Devolver caracter apuntado
		*dir_actual=dir;		       // Devolver la direccion
		ic++;                      // Incrementar indice de caracter
		dir++;                     // Apuntar a la sig. direccion
		
		//--- si era el ultimo byte, cargamos el siguiente bloque 
		if (dir==(dir_bloque + tam)) {
			ib++;
			ic=0;
			if (ib<=nblocks)  //-- Solo se lee si hay más
			  leercod_s19(*fichs19,ib,bloque,&tam,&crc);
		}
		return 1;
	}
	
	//-- Caso 2: Estamos entre dos bloques
	*valor=0;
	*dir_actual=dir;
	dir++;
	return 1;
}

/*------------------------------------------------------------*/
/*  Saltar al comienzo del siguiente bloque, solo si estamos  */
/*  entre dos bloques                                         */
/*------------------------------------------------------------*/
/* SALIDA:                                                    */
/*    -dir_bloque: Direccion del siguiente bloque, siempre    */
/*     exista                                                 */
/* DEVUELVE:                                                  */
/*    0 Si no hay siguiente bloque (estamos fuera)            */
/*    1 Si se ha accedido al siguiente bloque                 */
/*------------------------------------------------------------*/
int ejecuta_next_block(int *dir_bloque)
{
	int dir_b;
	
	//-- Estamos fuera del último bloque
	if (ib>nblocks) {
		*dir_bloque=0;
		return 0;
	}
	
	//-- Leer direccion comienzo bloque actual
	leerdir_s19(*fichs19,ib,&dir_b);
	
	//-- Si estamos dentro de un bloque, todo ok
	if ((dir>=dir_b) && (dir<(dir_b+tam))) {
		*dir_bloque=dir;
		return 1;
	}	
	
	//-- Si estamos entre medias de dos bloques
	//-- Nos situamos al comienzo del siguiente bloque
	dir=dir_b;
	*dir_bloque=dir_b;  //-- Devolver direccion del bloque
	
	return 1;
}
