/***********************************************/
/* sg-serial.h       Juan Gonzalez Gomez.      */
/*---------------------------------------------*/
/* Comunicaciones serie para clientes StarGate */
/* Licencia GPL                                */
/***********************************************/

#ifndef SG_SERIAL_H
#define SG_SERIAL_H

#define DTR_ON  1
#define DTR_OFF 0

/*--------------------------*/
/* PROTOTIPOS DEL INTERFAZ  */
/*--------------------------*/

/********************************************/
/* Enviar una cadena por el puerto serie    */
/********************************************/
void sg_serial_enviar(int serial_fd, char *cadena, int tam);

/***********************************************/
/* Lectura de un n�mero de bytes del puerto    */
/* con serie con TIMEOUT                       */
/* La funci�n devuelve el control cuando       */
/* han llegado los caracteres solicitados,     */
/* transcurra el timeout especificado          */
/* (entre sucesivos accesos) u ocurra un error */
/* ENTRADAS:                                   */
/*   -serial_fd: Descriptor puerto serie       */
/*   -timeout: Timeout en micro-segundos       */
/*   -tam: Tama�o de los datos a leer          */
/* SALIDAS:                                    */
/*   -buff: Buffer con los datos leidos        */
/* DEVUELVE:                                   */
/*   -1 : Si ha ocurrido alg�n error           */
/*    0 : Si ha ocurrido un TIMEOUT            */
/*    1 : OK                                   */
/***********************************************/
int sg_serial_read(int serial_fd, char *buff, int tam,int timeout);


/***********************************************************/
/*  Establecer el estado de la se�al DTR.                  */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -fd: Descriptor serie                                */
/*    -estado: EStado del DTR:                             */  
/*        SC_SIGNAL_DTR_ON                                 */
/*        SC_SIGNAL_DTR_OFF                                */
/***********************************************************/
void sg_serial_dtr_set(int fd, int estado);


/********************************************************************/
/* Abrir el puerto serie                                            */
/*------------------------------------------------------------------*/
/* ENTRADA:                                                         */
/*   disp: cadena con el dispositivo serie                          */
/*                                                                  */
/* DEVUELVE:                                                        */
/*   -El descriptor del puerto serie � -1 si ha ocurrido un error   */
/********************************************************************/
int sg_serial_open(char *disp);


#endif  /* del define SG_SERIAL_H */
