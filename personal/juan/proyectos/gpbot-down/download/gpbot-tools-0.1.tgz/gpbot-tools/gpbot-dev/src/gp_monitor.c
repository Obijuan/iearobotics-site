/**************************************************/
/* gp_monitor.c      Juan Gonzalez Gomez.         */
/*------------------------------------------------*/
/* Rutinas de acceso al modo monitor del micro    */
/* 6808 de la tarjeta GP-BOT.                     */
/**************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "sg-serial.h"
#include "gp_monitor.h"

/*****************************/
/*  DEFINICIONES             */
/*****************************/
/*-- Definiciones de algunos registros del 6808 --*/
#define REG_FLCR  0xFE08   //-- Flash Control Register
#define REG_FLBPR 0xFF7E  //-- Flash Block Protect Register

//-- Comandos del modo monitor
#define CMD_WRITE	 0x49
#define CMD_READ   0x4A
#define CMD_IREAD  0x1A
#define CMD_IWRITE 0x19
#define CMD_READSP 0x0C
#define CMD_RUN    0x28

/*****************************************/
/* PROTOTIPOS DE LAS FUNCIONES PRIVADAS  */
/*****************************************/
static int comprueba(int serial_fd, char car);


/*-----------------------------------------------------------*/
/*                  FUNCIONES                                */
/*-----------------------------------------------------------*/

/*********************************************/
/* Enviar el caracter indicado y comprobar   */
/* si se recibe el doble eco                 */
/*-------------------------------------------*/
/* ENTRADAS                                  */
/*   -serial_fd: Descriptor puerto serie     */
/*   -car: Caracter a enviar                 */
/* DEVUELVE                                  */
/*   1 : OK                                  */
/*   0 : Error                               */
/*********************************************/
static int comprueba(int serial_fd, char car)
{
	char respuesta[10];
	int status;
	
	sg_serial_enviar(serial_fd,&car,1);
	status=sg_serial_read(serial_fd,respuesta,2,100000);
	if (status==1) {
		if (respuesta[1]!=car)
			return 0;  //-- Error
	}
	else return 0; //-- Error, timeout
		
	return 1;
}

/***************************************************/
/* Configurar la GP-BOT para modo monitor          */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*    -serial_fd: Descriptor serie                 */
/* DEVUELVE:                                       */
/*    1 : OK, se ha entrado en modo monitor        */
/*    0 : Error                                    */
/***************************************************/
int gp_monitor_configure(int serial_fd)
{
	int status;
	int i;
	char id[]={0xFF,0xff,0xff,0xff,
		         0xff,0xff,0xff,0xff};  //-- Cadena de identificacion
	char respuesta[80];
	
	//-- Poner DTR a OFF, para hacer reset
	sg_serial_dtr_set(serial_fd,0);
	
	usleep(100000);
	
	//-- Poner DTR a ON
	sg_serial_dtr_set(serial_fd,1);
	
	usleep(100000);

	//-- Enviar los 8 bytes de identificacion
	//-- y comprobar si se recibe la se�al de BREAK
	for (i=0; i<8; i++) {
		if (comprueba(serial_fd,id[i])!=1) return 0;
	}	
	status=sg_serial_read(serial_fd,respuesta,1,100000);
	if (status!=1) return 0;
	if (respuesta[0]!=0) return 0;  //Error, recibido algo distinto de 0
	
	//-- Modo monitor OK
	return 1;
}

/*******************************************************/
/* COMANDO WRITE. El micro debe estar en modo monitor  */
/*-----------------------------------------------------*/
/* ENTRADAS:                                           */
/*   -serial_fd: Descriptor del puerto serie           */
/*   -dir: Direccion de 16 bits donde escribir         */
/*   -dir: Valor de 8 bits donde escribir              */
/* DEVUELVE:                                           */
/*   0 Ocurrio algun error                             */
/*   1 OK                                              */
/*******************************************************/
int gp_monitor_write(int serial_fd, int dir, unsigned char valor)
{
	int high;
	int low;
	
	if (!comprueba(serial_fd, CMD_WRITE)) return 0;

  //-- Enviar la direccion
	high=(dir>>8)&0xFF;
	low=dir&0xFF;
	
	if (!comprueba(serial_fd, high)) return 0;
	if (!comprueba(serial_fd, low)) return 0;	
		
	//-- Enviar el valor a escribir
	valor=(valor & 0xFF);
	if (!comprueba(serial_fd, valor)) return 0;	
		
	return 1;
}


/******************************************************/
/* COMANDO READ. El micro debe estar en modo monitor  */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: Descriptor del puerto serie          */
/*   -dir: Direccion (16 bits) de donde leer          */
/* SALIDAS:                                           */
/*   -valor: Byte leido                               */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_read(int serial_fd, int dir, unsigned char *valor)
{
	int high;
	int low;
	char resp;
	int status;
	
	//-- Enviar comando y comprobar
	if (!comprueba(serial_fd, CMD_READ)) return 0;
	
	
	//-- Enviar direccion y comprobar
	high=(dir>>8)&0xFF;
	low=dir&0xFF;
	
	if (!comprueba(serial_fd, high)) return 0;
	if (!comprueba(serial_fd, low)) return 0;
		
	//-- Leer valor
	status=sg_serial_read(serial_fd,&resp,1,100000);
	if (status!=1) return 0;
		
	*valor=resp&0xFF;
	
	return 1;
}

/*********************************************************/
/* COMANDO IWRITE. El micro debe estar en modo monitor   */
/* Escritura en la direccion siguiente a la ultima       */
/* accedida                                              */
/*-------------------------------------------------------*/
/* ENTRADAS:                                             */
/*   -serial_fd: Descriptor del puerto serie             */
/*   -valor: Valor a escribir                            */
/* DEVUELVE:                                             */
/*   0 Error                                             */
/*   1 OK                                                */
/*********************************************************/
int gp_monitor_iwrite(int serial_fd, unsigned char valor)
{
	//-- Enviar comando y comprobar
	if (!comprueba(serial_fd, CMD_IWRITE)) return 0;
		
	//-- Enviar dato a escribir
	if (!comprueba(serial_fd, valor)) return 0;
	return 1;
}

/********************************************************/
/* Comando IREAD. Devuelve 2 bytes, correspondientes a  */
/* las direcciones dir+1, dir+2                         */
/*------------------------------------------------------*/
/* ENTRADAS:                                            */
/*   -serial_fd: Descriptor del puerto serie            */
/* SALIDAS:                                             */
/*   -Devuelve los dos bytes leidos: valor[0] y valor[1]*/
/* DEVUELVE:                                             */
/*   0 Error                                             */
/*   1 OK                                                */
/*********************************************************/
int gp_monitor_iread(int serial_fd, unsigned char *valor)
{
	unsigned char data[10];
	int status;
	
	//-- Enviar comando y comprobar
	if (!comprueba(serial_fd, CMD_IREAD)) return 0;
		
	//-- Leer primer valor
	status=sg_serial_read(serial_fd,data,1,100000);
	if (status!=1) return 0;
	
	//-- Leer segundo valor
	status=sg_serial_read(serial_fd,&(data[1]),1,100000);
	if (status!=1) return 0;
		
	valor[0]=(data[0]&0xFF);
	valor[1]=(data[1]&0xFF);
	
	return 1;
}


/*******************************************/
/* COMANDO READSP. Devolver el valor de    */
/* SP + 1                                  */
/*-----------------------------------------*/
/* ENTRADAS                                */
/*   -serial_fd: Descriptor puerto serie   */
/* SALIDAS                                 */
/*   -dir: Valor del SP+1                  */
/* DEVUELVE:                               */
/*   0 Error                               */
/*   1 OK                                  */
/*******************************************/
int gp_monitor_readsp(int serial_fd, unsigned int *dir)
{
	int status;
	unsigned char dirh;
	unsigned char dirl;
	
	//-- Enviar comando y comprobar
	if (!comprueba(serial_fd, CMD_READSP)) return 0;
		
  //-- Leer valor alto de la direcion
	status=sg_serial_read(serial_fd,&dirh,1,100000);
	if (status!=1) return 0;	
		
	//-- Leer valor bajo de la direcion
	status=sg_serial_read(serial_fd,&dirl,1,100000);
	if (status!=1) return 0;	
	
	*dir=((dirh&0xFF)<<8) | (dirl&0xFF);
	
	return 1;
}

/***************************************************/
/* COMANDO RUN. Ejecutar el programa               */
/* El 6808 saca el valor del PC de la pila y       */
/* ejecuta el codigo al que apunte                 */
/* NOTA: Esta funcion solo envia el comando de     */
/* ejecucion, pero NO modifica el valor del PC     */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd: Descriptor del puerto serie       */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_run(int serial_fd)
{
	
	//-- Enviar comando y comprobar
	if (!comprueba(serial_fd, CMD_RUN)) return 0;
	
	return 1;
}

/***************************************************/
/* Ejecutar a partir de la direccion indicada      */
/* Se accede a la PILA, se deposita el nuevo valor */
/* del PC y se ejecuta el comando RUN              */
/* LA CONEXION CON EL MONITOR SE PIERDE            */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd : Descriptor del puerto serie      */
/*   -dir: Direccion a la que saltar               */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_ejecutar(int serial_fd, int dir)
{
	int status;
	int pcl;
	int pch;
	int sp;
	
	//-- Obtener la direccion del SP+1
	status=gp_monitor_readsp(serial_fd, &sp);
	if (status!=1) return 0; 
	
	//-- Obtener los nuevos valores del PC
	pch=(dir>>8)&0xFF;
	pcl=dir&0xFF;

	//-- Obtener direccion en la pila del PC
	sp=sp+4;
	
	//-- Cambiar los valores del PC
	status=gp_monitor_write(serial_fd, sp, pch);
	if (status!=1) return 0;
	
	status=gp_monitor_write(serial_fd, sp+1,pcl);
	if (status!=1) return 0;
		
	//-- Ejecutar!!!
	status=gp_monitor_run(serial_fd);
	if (status!=1) return 0;
		
	return 1;
}

/******************************************************/
/* Borrar la memoria Flash completa                   */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: Descriptor del puerto serie          */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_borrar_flash(int serial_fd)
{
	int status;
	unsigned char valor;
	
	//-- Poner a 1 los bits ERASE y MASS
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x06);
	if (status!=1) return 0;
	
	//-- Leer del Flash Block Protect register
	status=gp_monitor_read(serial_fd, REG_FLBPR, &valor);
	if (status!=1) return 0;
	
	//-- Escribir un valor en el Flash Block Protect Register
	status=gp_monitor_write(serial_fd, REG_FLBPR,0xFF);
	if (status!=1) return 0;
	
	//-- Poner a 1 el bit HVEN
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x0E);
	if (status!=1) return 0;
	
	//-- Poner a '0' el bit ERASE
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x0C);
	if (status!=1) return 0;
	
	//-- Poner a '0' el bit HVEN
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x04);
	if (status!=1) return 0;
	
	//-- Poner a '0' el bit MASS
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x00);
	if (status!=1) return 0;
		
	return 1;
}

/****************************************************/
/* Funcion privada para grabar un bloque de flash   */
/*------------------------------------------------- */
/* ENTRADAS:                                        */
/*   -serial_fd: Descriptor del puerto serie        */
/*   -dir: Direccion inicial del bloque             */
/*   -tam: Tama�o del bloque. Debe ser de 64 bytes  */
/*     para grabar bloques de programa y de 36 para */
/*     grabar los vectores de interrupcion          */
/*   -prog: Bloque a grabar                         */
/* DEVUELVE:                                        */
/*   0 Error                                        */
/*   1 OK                                           */
/****************************************************/
int program_flash_block(int serial_fd, int dir, int tam, unsigned char *prog)
{
	int status;
	int i;
	unsigned char valor;
	
	//-- Poner el bit PGM a '1'
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x01);
	
	//-- Leer del Flash Block Protect register
	status=gp_monitor_read(serial_fd, REG_FLBPR, &valor);
	
	//-- Escribir cualquier cosa dentro del bloque a grabar
	status=gp_monitor_write(serial_fd, dir, 0xFF);
	
	//--Poner el bit HVEN a '1'
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x09);
	
	//-- Grabar los datos
	//-- Por hacer
	for (i=0; i<tam; i++) {
		status=gp_monitor_write(serial_fd, dir+i, prog[i]);
	}
		
	//-- Poner el Bit PGM a '0'
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x08);
	
	//-- Poner el bit HVEN a '0'
	status=gp_monitor_write(serial_fd, REG_FLCR, 0x00);
	
	return 1;
}

/***************************************************/
/* Grabar los vectores de interrupcion             */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd: descriptor serie                  */
/*   -vector: Bloque de 36 bytes con los vectores  */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_program_vectors(int serial_fd, unsigned char *vector)
{
	return program_flash_block(serial_fd, 0xFFDC, 36, vector);
}

/******************************************************/
/* Grabar un bloque de datos en la FLASH. Hay que     */
/* que indicarle UNA DIRECCION ALINEADA, que sea      */
/* multiplo de 64 bytes. Lo es cualquier que termine  */
/* en 00, 40, 80, C0                                  */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: descriptor serie                     */
/*   -dir: Direccion de comienzo del bloque (alineada)*/
/*   -prog: Bloque de 64 bytes a grabar               */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_program_block_flash(int serial_fd, int dir, unsigned char *prog)
{
	return program_flash_block(serial_fd, dir, 64, prog);
}
