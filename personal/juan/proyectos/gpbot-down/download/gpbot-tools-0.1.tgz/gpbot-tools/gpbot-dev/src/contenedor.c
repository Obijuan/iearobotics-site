/*****************************************************/
/* contenedor.c   Juan Gonzalez Gomez. Febrero 2004  */
/*---------------------------------------------------*/
/* Funciones para el manejo de un contener de bytes  */
/*****************************************************/

#include <stdio.h>

#include "contenedor.h"

#define TAMANO 64   // Tamano del contenedor

/**********************************/
/* Variables globales del modulo  */
/**********************************/

static unsigned char contenedor[TAMANO];
static int ic;     // Indice a la sig posicion libre

/*****************************/
/* Inicializar el contenedor */
/*****************************/
void contenedor_init()
{
	ic=0;
}

/***************************************/
/* Introducir un byte en el contenedor */
/*-------------------------------------*/
/* ENTRADAS                            */
/*    valor: Dato a insertar           */
/* DEVUELVE                            */
/*    0 : Contenedor lleno             */
/*    1 : Ok, dato insertado           */
/***************************************/
int contenedor_insert_byte(unsigned char valor)
{
	if (ic==TAMANO) { //-- El contenedor esta lleno
		return 0;
	}
	
	//-- Insertar valor
	contenedor[ic]=valor;
	ic++;
	
	return 1;
}

/*************************************************/
/* Introducir un valor varias veces              */
/*-----------------------------------------------*/
int contenedor_insert_padding(unsigned char valor, int cant)
{
	int ok;
	
	//-- Hay que especificar una cantidad positiva
	if (cant<=0) return 1;
	
	//-- Insertar los caracteres de relleno
	//-- Si no caben mas se indica que contenedor lleno
	while (cant) {
		ok=contenedor_insert_byte(valor);
		if (!ok) return 0;
		cant--;
	}
	
	//-- Todos los datos han entrado
	return 1;
}

/*******************************************/
/* Obtener el espacio que queda libre en   */
/* el contenedor                           */
/*******************************************/
int contenedor_get_espacio()
{
	return (TAMANO-ic);
}

/******************************************/
/* Devolver la direccion del contenedor   */
/******************************************/
unsigned char *contenedor_get()
{
	return contenedor;
}

/*******************************************************/
/* Imprimir el contenedor. Para realizar depuraciones  */
/*******************************************************/
void contenedor_print()
{
	int i;
	
	for (i=0; i<TAMANO; i++) {
		if ((i&0x0F)==0)
			printf ("\n");
		printf ("%02X ",contenedor[i]);
	}
	printf ("\n");
}
