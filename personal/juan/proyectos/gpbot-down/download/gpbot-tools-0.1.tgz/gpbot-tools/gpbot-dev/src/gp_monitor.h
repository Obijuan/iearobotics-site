/***********************************************/
/* gp_monitor.h       Juan Gonzalez Gomez.     */
/*---------------------------------------------*/
/***********************************************/

#ifndef GP_MONITOR_H
#define GP_MONITOR_H

/*--------------------------*/
/* PROTOTIPOS DEL INTERFAZ  */
/*--------------------------*/

/***************************************************/
/* Configurar la GP-BOT para modo monitor          */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*    -serial_fd: Descriptor serie                 */
/* DEVUELVE:                                       */
/*    1 : OK, se ha entrado en modo monitor        */
/*    0 : Error                                    */
/***************************************************/
int gp_monitor_configure(int serial_fd);

/*******************************************************/
/* COMANDO WRITE. El micro debe estar en modo monitor  */
/*-----------------------------------------------------*/
/* ENTRADAS:                                           */
/*   -serial_fd: Descriptor del puerto serie           */
/*   -dir: Direccion de 16 bits donde escribir         */
/*   -dir: Valor de 8 bits donde escribir              */
/*******************************************************/
int gp_monitor_write(int serial_fd, int dir, unsigned char valor);

/******************************************************/
/* COMANDO READ. El micro debe estar en modo monitor  */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: Descriptor del puerto serie          */
/*   -dir: Direccion (16 bits) de donde leer          */
/* SALIDAS:                                           */
/*   -valor: Byte leido                               */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_read(int serial_fd, int dir, unsigned char *valor);

/*********************************************************/
/* COMANDO IWRITE. El micro debe estar en modo monitor   */
/* Escritura en la direccion siguiente a la ultima       */
/* accedida                                              */
/*-------------------------------------------------------*/
/* ENTRADAS:                                             */
/*   -serial_fd: Descriptor del puerto serie             */
/*   -valor: Valor a escribir                            */
/* DEVUELVE:                                             */
/*   0 Error                                             */
/*   1 OK                                                */
/*********************************************************/
int gp_monitor_iwrite(int serial_fd, unsigned char valor);

/********************************************************/
/* Comando IREAD. Devuelve 2 bytes, correspondientes a  */
/* las direcciones dir+1, dir+2                         */
/*------------------------------------------------------*/
/* ENTRADAS:                                            */
/*   -serial_fd: Descriptor del puerto serie            */
/* SALIDAS:                                             */
/*   -Devuelve los dos bytes leidos: valor[0] y valor[1]*/
/* DEVUELVE:                                             */
/*   0 Error                                             */
/*   1 OK                                                */
/*********************************************************/
int gp_monitor_iread(int serial_fd, unsigned char *valor);


/*******************************************/
/* COMANDO READSP. Devolver el valor de    */
/* SP + 1                                  */
/*-----------------------------------------*/
/* ENTRADAS                                */
/*   -serial_fd: Descriptor puerto serie   */
/* SALIDAS                                 */
/*   -dir: Valor del SP+1                  */
/* DEVUELVE:                               */
/*   0 Error                               */
/*   1 OK                                  */
/*******************************************/
int gp_monitor_readsp(int serial_fd, unsigned int *dir);

/***************************************************/
/* COMANDO RUN. Ejecutar el programa               */
/* El 6808 saca el valor del PC de la pila y       */
/* ejecuta el codigo al que apunte                 */
/* NOTA: Esta funcion solo envia el comando de     */
/* ejecucion, pero NO modifica el valor del PC     */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd: Descriptor del puerto serie       */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_run(int serial_fd);

/***************************************************/
/* Ejecutar a partir de la direccion indicada      */
/* Se accede a la PILA, se deposita el nuevo valor */
/* del PC y se ejecuta el comando RUN              */
/* LA CONEXION CON EL MONITOR SE PIERDE            */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd : Descriptor del puerto serie      */
/*   -dir: Direccion a la que saltar               */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_ejecutar(int serial_fd, int dir);

/******************************************************/
/* Borrar la memoria Flash completa                   */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: Descriptor del puerto serie          */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_borrar_flash(int serial_fd);

/******************************************************/
/* Grabar un bloque de datos en la FLASH. Hay que     */
/* que indicarle UNA DIRECCION ALINEADA, que sea      */
/* multiplo de 64 bytes. Lo es cualquier que termine  */
/* en 00, 40, 80, C0                                  */
/*----------------------------------------------------*/
/* ENTRADAS:                                          */
/*   -serial_fd: descriptor serie                     */
/*   -dir: Direccion de comienzo del bloque (alineada)*/
/*   -prog: Bloque de 64 bytes a grabar               */
/* DEVUELVE:                                          */
/*   0 Error                                          */
/*   1 OK                                             */
/******************************************************/
int gp_monitor_program_block_flash(int serial_fd,int dir, unsigned char *prog);

/***************************************************/
/* Grabar los vectores de interrupcion             */
/*-------------------------------------------------*/
/* ENTRADAS:                                       */
/*   -serial_fd: descriptor serie                  */
/*   -vector: Bloque de 36 bytes con los vectores  */
/* DEVUELVE:                                       */
/*   0 Error                                       */
/*   1 OK                                          */
/***************************************************/
int gp_monitor_program_vectors(int serial_fd, unsigned char *vector);


#endif  /* del define GP_MONITOR_H */
