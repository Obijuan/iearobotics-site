/******************************************************/
/* contenedor.h    Juan Gonzalez Gomez. Febrero 2004  */
/*----------------------------------------------------*/
/* Prototipos y definiciones para el modulo contenedor*/
/******************************************************/

/*****************************/
/* Inicializar el contenedor */
/*****************************/
void contenedor_init();

/***************************************/
/* Introducir un byte en el contenedor */
/*-------------------------------------*/
/* ENTRADAS                            */
/*    valor: Dato a insertar           */
/* DEVUELVE                            */
/*    0 : Contenedor lleno             */
/*    1 : Ok, dato insertado           */
/***************************************/
int contenedor_insert_byte(unsigned char valor);

/*************************************************/
/* Introducir un valor varias veces              */
/*-----------------------------------------------*/
int contenedor_insert_padding(unsigned char valor, int cant);

/*******************************************/
/* Obtener el espacio que queda libre en   */
/* el contenedor                           */
/*******************************************/
int contenedor_get_espacio();

/*******************************************************/
/* Imprimir el contenedor. Para realizar depuraciones  */
/*******************************************************/
void contenedor_print();

/******************************************/
/* Devolver la direccion del contenedor   */
/******************************************/
unsigned char *contenedor_get();
