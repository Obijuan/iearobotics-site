/**************************************************/
/* gpbot-dev.c      Juan Gonzalez Gomez.          */
/*------------------------------------------------*/
/* Prueba de las funciones desarrolladas para     */
/* la GPBOT.                                      */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "gp_monitor.h"
#include "sg-serial.h"
#include "s19.h"
#include "contenedor.h"
#include "ejecuta.h"

#define VECTORES 0xFFDC  //-- Direccion de comienzo vectores int.

/***********************************/
/*             VARIABLES           */
/***********************************/

/*-- configuracion de la consola --*/
static struct termios oldconsola,consola;

/*****************************/
/*    FUNCIONES              */
/*****************************/

int config_consola()
/*************************************************************/
/* Configurar la consola                                     */
/*************************************************************/
{
  /* Leer los parametros asociados a la consola */
  if (tcgetattr(STDIN_FILENO,&consola)==-1) {
    perror("Error en tcgetattr");
    return -1;
  }
  oldconsola = consola; /* Almacenar parametros para su posterior recup. */
  
  /* Cambiar parametros */
  consola.c_cc[VMIN]=1;
  consola.c_lflag&=~(ECHO|ICANON); 
  
  if (tcsetattr(STDIN_FILENO,TCSANOW,&consola)==-1) {
    perror("Error en tcsetattr");
    return -1;
  }
  
  return 0;
}

void reset_consola()
/**********************************************/
/* Reestablecer la consola anterior           */
/**********************************************/
{
  if (tcsetattr(STDIN_FILENO,TCSANOW,&oldconsola)==-1) 
    perror("Error en tcsetattr");
}


void menu_iwrite(int serial_fd)
{
	int valor;
	int status;
	
	reset_consola();
	printf ("Valor? (hex): "); fflush(stdout);
	scanf("%x",&valor);
	config_consola();
	
	status=gp_monitor_iwrite(serial_fd, valor);
	if (status!=1) printf ("ERROR!\n");
	else printf ("OK\n");
}

void menu_write(int serial_fd)
{
	int dir;
	int valor;
	int status;
	
	reset_consola();
	printf ("Direccion? (hex): "); fflush(stdout);
	scanf("%x",&dir);
	printf ("Valor? (hex): "); fflush(stdout);
	scanf("%x",&valor);
	config_consola();
	
	status=gp_monitor_write(serial_fd, dir, valor);
	if (status!=1) printf ("ERROR!\n");
}

void menu_read(int serial_fd)
{
	int dir;
	unsigned char valor;
	int status;
	
	reset_consola();
	printf ("Direccion? (hex): "); fflush(stdout);
	scanf("%x",&dir);
	config_consola();
	status=gp_monitor_read(serial_fd, dir,&valor);
	if (status==1)
		printf ("Valor: %x\n",valor);
	else 
		printf ("Error\n");
}

void menu_iread(int serial_fd)
{
	int status;
	unsigned char valor[10];
	
	status=gp_monitor_iread(serial_fd,valor); 
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("%x, %x\n",valor[0], valor[1]);
}

void menu_readsp(int serial_fd)
{
	int status;
	int dir;
	
	status=gp_monitor_readsp(serial_fd,&dir);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
  printf ("SP+1: %04x\n",dir);
}

void menu_run(int serial_fd)
{
	int status;
	
	status=gp_monitor_run(serial_fd);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("RUN\n");
}

void menu_ejecutar(int serial_fd)
{
	int dir;
	int status;
	
	reset_consola();
	printf ("Direccion de ejecuci�n? (hex): "); fflush(stdout);
	scanf("%x",&dir);
	config_consola();
	
	status=gp_monitor_ejecutar(serial_fd, dir);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("EJECUTANDO!!!\n");
}

/*-----------------------------------------------------*/
/* Cargar los opcodes del programa test                */
/* en la memoria RAM, a partir de la direccion 0x0040  */
/*-----------------------------------------------------*/
void menu_load_test(int serial_fd)
{
	int i;
	int status;
	
	//-- Opcodes del programa test
	static unsigned char test[]={
		0xA6, 0xFF, 0xC7, 0x00, 0x05, 0xA6, 0xAA, 0xC7, 
		0x00, 0x01, 0x20, 0xFE
	};
		
	//-- Cargar los opcodes en la ram
	for (i=0; i<12; i++) {
		//-- El primer opcode se graba con WRITE, 
		//-- El resto con IWRITE
		if (i==0)
			status=gp_monitor_write(serial_fd, 0x0040, test[0]);
		else 
			status=gp_monitor_iwrite(serial_fd, test[i]);
		
		if (status!=1) {
			printf ("Error...\n");
		}
	}
	
	printf ("OK\n");
}

void menu_load_test2(int serial_fd)
{
	int i;
	int status;
	
	//-- Opcodes del programa test (para la Flash)
	//-- Los opcodes coinciden con los del programa test para
	//-- la RAM (no hay saltos absolutos)
	static unsigned char test[]={
		0xA6, 0xFF, 0xC7, 0x00, 0x05, 0xA6, 0xAA, 0xC7,
		0x00, 0x01, 0x20, 0xFE 
	};
	unsigned char zero[64];
	
	for (i=0; i<64; i++) {
		zero[i]=0xFF;
	}
	
	printf ("Grabando en la flash...\n");
	status=gp_monitor_program_block_flash(serial_fd, 0x8000, test);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("OK\n");
}

void menu_borrar_flash(int serial_fd)
{
	int status;
	
	status=gp_monitor_borrar_flash(serial_fd);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("OK\n");
}

void menu_modificar_reset(int serial_fd)
{
	int dir;
	int status;
	int i;
	static unsigned char block[64]; 
	
	//-- Inicializar el bloque a grabar
	for (i=0; i<36; i++) {
		block[i]=0xFF;
	}
	
	printf ("Modificadi�n del vector de reset\n");
	reset_consola();
	printf ("Direccion a la que saltar? (hex): "); fflush(stdout);
	scanf("%x",&dir);
	config_consola();
	
	//--Establecer nuevo vector de reset_consola
	block[34]=((dir>>8)&0xFF);  //-- Parte m�s significativa
	block[35]=(dir&0xFF);       //-- Parte menos significativa
	
	printf ("Grabando en la flash...\n");
	status=gp_monitor_program_vectors(serial_fd, block);
	if (status!=1) {
		printf ("ERROR\n");
		return;
	}
	printf ("OK\n");
}

void menu_grabacion_fichero(int serial_fd)
{
	char fich[80];
	char *caderror;
	S19 mis19;
	int dir;
	int dir_bloque;       //-- Direccion alineada
	unsigned char valor;
	unsigned char *block;
	int ok;
	int vectores=0;   // Indica si el bloque es de los vectores de int.
	
	reset_consola();
	printf ("Introduzca Fichero .s19 a grabar: "); fflush(stdout);
	scanf("%s",fich);
	config_consola();
	
	if (abrir_s19(fich,&mis19,1)==0) {
    caderror=(char *)geterrors19();
    printf ("Error: %s\n",caderror);
    return;
  }
	printf ("OK, fichero abierto\n");
	
	//-- Procesar el archivo
	dir=ejecuta_init(&mis19);
	printf ("Direccion inicial: %X\n",dir);
	
	do {
		//-- Obtener un contenedor vacio
		contenedor_init();
		
		//-- El siguiente bloque NO es de datos, sino vectores de int.
		if (dir>=VECTORES && dir<=0xFFFF) {
			vectores=1;
		}
		else { //-- Bloque de DATOS
			vectores=0;
			//-- Rellenarlo con 0s, desde la direccion de comienzo
			//-- del bloque hasta la direccion actual
			dir_bloque = (dir&0xFFC0);  //-- Obtener dir del bloque flash
			contenedor_insert_padding(0,dir-dir_bloque);
		}
		
		//-- Insertar bytes hasta llenar contenedor
		while (contenedor_get_espacio()>0) {
			ejecuta_next_byte(&valor,&dir); //-- Leer siguiente byte
			contenedor_insert_byte(valor);  //-- Meterlo en contenedor
		}
		
		//-- Contenedor lleno. Listo para grabar
		
		//-- Obtener el puntero al contenedor
		block=contenedor_get();
		
		if (vectores) {
			printf ("VECTORES DE INTERRUPCION:\n");
			gp_monitor_program_vectors(serial_fd, block);
		}
		else {
			printf ("BLOQUE DE DATOS\n");
			gp_monitor_program_block_flash(serial_fd,dir_bloque,block);
		}	
		
		//-- Imprimir el bloque (Depuracion)
		contenedor_print();
		
		//-- Saltar al siguiente bloque de datos
		ok=ejecuta_next_block(&dir);
	} while (ok);	
	printf ("OK\n");
	
	cerrar_s19(mis19);
}

void print_menu()
{
	printf ("\n");
  printf ("Men� de Opciones\n");
  printf ("----------------\n");
  printf ("1.- READ\n");
	printf ("2.- WRITE\n");
	printf ("3.- IREAD\n");
	printf ("4.- IWRITE\n");
	printf ("5.- READSP\n");
	printf ("6.- Comando RUN\n");
	printf ("7.- EJECUTAR!\n");
	printf ("8.- Cargar programa test (En direcion 0x0040)\n");
	printf ("9.- Cargar programa test (En direccion 0x8000, FLASH)\n");
	printf ("a.- BORRAR FLASH\n");
	printf ("b.- Modificar vector de RESET\n");
	printf ("c.- Grabacion de un programa\n");
  printf ("ESC.- Terminar\n\n");
	printf ("SPC.- Volver a sacar el menu\n");
}

void menu(int serial_fd)
{
  char c;
	
  print_menu();

  do {
    //-- Leer caracter
    fread(&c,1,1,stdin);
    switch(c) {
    case '1': 
			menu_read(serial_fd);
      break;
    case '2': 
			menu_write(serial_fd);
      break;
		case '3':
			menu_iread(serial_fd);
			break;
		case '4':
			menu_iwrite(serial_fd);
			break;
		case '5':
			menu_readsp(serial_fd);
			break;
		case '6':
			menu_run(serial_fd);
			break;
		case '7':
			menu_ejecutar(serial_fd);
			break;
		case '8':
			menu_load_test(serial_fd);
			break;
		case '9':
			menu_load_test2(serial_fd);
			break;
		case 'a':
			menu_borrar_flash(serial_fd);
			break;
		case 'b':
			menu_modificar_reset(serial_fd);
			break;
		case 'c':
			menu_grabacion_fichero(serial_fd);
			break;
		case ' ':
			print_menu();
			break;
    }
  } while (c!=27);
}

void main_quit(int serial_fd)
{
 //-- Consola a su estado inicial
  reset_consola();

  //-- Cerrar puerto serie
  close(serial_fd);
}

int main (void)
{
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Configurar la consola
  config_consola();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

	//-- Inicializar
	
	if (!gp_monitor_configure(serial_fd)) {
		printf ("ERROR: No se ha entrado en modo monitor\n");
		main_quit(serial_fd);
		exit(1);
	}
	
	printf ("\n");
	printf ("MODO MONITOR OK\n");
 
  menu(serial_fd);

  main_quit(serial_fd);

  return 0;
}
