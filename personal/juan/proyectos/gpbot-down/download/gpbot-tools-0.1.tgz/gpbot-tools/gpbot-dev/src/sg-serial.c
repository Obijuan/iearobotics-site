/***********************************************/
/* sg-serial.c        Juan Gonzalez Gomez.     */
/*---------------------------------------------*/
/* Comunicaciones serie para clientes StarGate */
/* Licencia GPL                                */
/***********************************************/

#include <stdio.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include "sg-serial.h" 

/********************************************/
/* Enviar una cadena por el puerto serie    */
/********************************************/
void sg_serial_enviar(int serial_fd, char *trama, int tam)
{
  write(serial_fd, trama, tam);
}

/***********************************************/
/* Lectura de un n�mero de bytes del puerto    */
/* con serie con TIMEOUT                       */
/* La funci�n devuelve el control cuando       */
/* han llegado los caracteres solicitados,     */
/* transcurra el timeout especificado          */
/* (entre sucesivos accesos) u ocurra un error */
/* ENTRADAS:                                   */
/*   -serial_fd: Descriptor puerto serie       */
/*   -timeout: Timeout en micro-segundos       */
/*   -tam: Tama�o de los datos a leer          */
/* SALIDAS:                                    */
/*   -buff: Buffer con los datos leidos        */
/* DEVUELVE:                                   */
/*   -1 : Si ha ocurrido alg�n error           */
/*    0 : Si ha ocurrido un TIMEOUT            */
/*    1 : OK                                   */
/***********************************************/
int sg_serial_read(int serial_fd, char *buff, int tam,int timeout)
{
  fd_set fds;
  struct timeval tout;
  int leidos=0;
  int ret;
	int inicio=0;
	
	do {
		//-- Esperar a que haya datos listos
		FD_ZERO(&fds);
		FD_SET (serial_fd, &fds);
	
		tout.tv_sec = 0;  //-- Establecer el TIMEOUT
		tout.tv_usec = timeout;
	
		ret=select (FD_SETSIZE,&fds, NULL, NULL,&tout);
	
		//-- Procesar los datos recibidos
		switch(ret) {
			case 1 : //--Datos listos 
				leidos=read (serial_fd, &(buff[inicio]), tam-leidos);
				tam=(tam-leidos);  //-- Quedan menos bytes por leer
				inicio=(inicio+leidos);
				break;
			case 0: //-- Timeout
				/* Vaciar los buffers de entrada y salida */
				tcflush(serial_fd,TCIOFLUSH);
				return 0;
				break;
			default: //--Cualquier otro error
				return -1;
				break;
		}
	} while (tam!=0);
	
	return 1;
}

/********************************************************************/
/* Abrir el puerto serie                                            */
/*------------------------------------------------------------------*/
/* ENTRADA:                                                         */
/*   disp: cadena con el dispositivo serie                          */
/*                                                                  */
/* DEVUELVE:                                                        */
/*   -El descriptor del puerto serie � -1 si ha ocurrido un error   */
/********************************************************************/
int sg_serial_open(char *disp)
{
  struct termios newtermios;
  int fd;

  fd = open(disp,O_RDWR | O_NOCTTY); /* Abrir puerto serie */

  /* Modificar los atributos */
  newtermios.c_cflag= CBAUD | CS8 | CLOCAL | CREAD;
  newtermios.c_iflag=IGNPAR;
  newtermios.c_oflag=0;
  newtermios.c_lflag=0;
  newtermios.c_cc[VMIN]=1;
  newtermios.c_cc[VTIME]=0;

  /* Establecer velocidad por defecto */
  cfsetospeed(&newtermios,B9600);
  cfsetispeed(&newtermios,B9600);
  
  /* Vaciar los buffers de entrada y salida */
  if (tcflush(fd,TCIFLUSH)==-1) {
    return -1;
  }

  /* Vaciar buffer de salida */
  if (tcflush(fd,TCOFLUSH)==-1) {
    return -1;
  }

  /* Escribir los nuevos atributos */
  if (tcsetattr(fd,TCSANOW,&newtermios)==-1) {
    return -1;
  }  

  return fd;
}

void sg_serial_dtr_set(int fd, int estado)
/***********************************************************/
/*  Establecer el estado de la se�al DTR.                  */
/*                                                         */
/*  ENTRADAS:                                              */
/*    -fd: Descriptor serie                                */
/*    -estado: EStado del DTR:                             */  
/*        DTR_ON                                           */
/*        DTR_OFF                                          */
/***********************************************************/
{
  int arg;
  int cmd;

  /* Se�al a modificar */
  arg = TIOCM_DTR;

  if (estado==DTR_ON) {
    cmd=TIOCMBIS;
  }
  else cmd=TIOCMBIC;

  /* Escribir estado actual */
  if (ioctl(fd,cmd,&arg)==-1) {
   //-- Gestion del error
  }
}

/********************************************************************/
/* Cerrar el puerto serie                                           */
/*------------------------------------------------------------------*/
/* ENTRADA:                                                         */
/*   fd: Descriptor del fichero                                     */
/********************************************************************/
void sg_serial_close(int fd)
{
  close(fd);
}
