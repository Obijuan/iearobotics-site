/*****************************************************/
/* ejecuta.h   Juan Gonzalez Gomez.  Feb-2004        */
/*---------------------------------------------------*/
/* Prototipos y definiciones para el modulo ejecuta  */
/*****************************************************/
#include "s19.h"

/***********************************************************************/
/* Inicializar el módulo ejecuta                                       */
/*---------------------------------------------------------------------*/
/* ENTRADAS:                                                           */
/*    Puntero a la estructura S19 que contiene los datos del programa  */
/* DEVUELVE:                                                           */
/*    La direccion de comienzo del primer bloque                       */
/***********************************************************************/
int ejecuta_init(S19 *f);

/*-------------------------------------------------------*/
/* Devolver el siguiente byte. Si en esa posicion no hay */
/* nada almacenado, se devuelve un 0                     */
/*-------------------------------------------------------*/
/* SALIDAS:                                              */
/*    valor: Valor que hay en la direccion actual        */
/*    dir_actual: Direccion a la que esta accediendo     */
/* DEVUELVE:                                             */
/*    0 si estamos "fuera" del programa                  */
/*    1 Si estamos en una zona "dentro" del programa     */
/*-------------------------------------------------------*/
int ejecuta_next_byte(unsigned char *valor, int *dir_actual);

/*------------------------------------------------------------*/
/*  Saltar al comienzo del siguiente bloque, solo si estamos  */
/*  entre dos bloques                                         */
/*------------------------------------------------------------*/
/* DEVUELVE:                                                  */
/*    0 Si no hay siguiente bloque (estamos fuera)            */
/*    1 Si se ha accedido al siguiente bloque                 */
/*------------------------------------------------------------*/
int ejecuta_next_block(int *dir_bloque);
