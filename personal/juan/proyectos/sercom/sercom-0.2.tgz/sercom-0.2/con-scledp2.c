/****************************************************************************/
/* CON-SCLEDP.C   (C) Juan Gonz�lez G�mez.  Agosto 2002                     */
/****************************************************************************/
/* Ejemplo de prueba para el m�dulo SERCOM.C. Carga de un programa en la    */
/* interna de la CT6811                                                     */
/*--------------------------------------------------------------------------*/
/* Licencia GPL                                                             */
/* juan@iearobotics.com                                                     */
/****************************************************************************/

#include <stdlib.h>
#include <unistd.h>

#include <glib.h>
#include "sercom.h"


/*----------------*/
/* Programa ledp  */
/*----------------*/

gchar ledp[256]={
  0xB6,0x10,0x00,0x88,0x40,0xB7,0x10,0x00,0x18,0xCE,0x5F,0xFF,0x18,0x09,0x18,
  0x8C,0x00,0x00,0x26,0xF8,0x20,0xEA,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,
};

GIOChannel *sioc;    /* Canal serie      */
GError *error=NULL;

void enviar_bloque(GIOChannel *ioc, gchar *buf, gssize tam)
{
  GIOStatus status;
  gsize num;

  status=g_io_channel_write_chars(sioc,buf,tam,&num,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error: %s\n",error->message);
    g_clear_error(&error);
    sc_close(ioc);
    exit;
  }
}

void enviar_car(GIOChannel *ioc, gchar car)
{
  GIOStatus status;
  gsize num;
  gchar buf[2];

  buf[0]=car;
  status=g_io_channel_write_chars(sioc,buf,1,&num,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error: %s\n",error->message);
    g_clear_error(&error);
    sc_close(ioc);
    exit;
  }
}

gint leer_car_plazo(GIOChannel *ioc, gchar *car, gulong timeout)
/******************************************************/
/* Leer un caracter con timeout. Devuelve:            */
/* 0 : Timeout                                        */
/* 1 : OK                                             */
/* -1: Error                                          */
/******************************************************/
{
  GIOStatus status;
  gsize num;
  gchar buf[10];
  GTimer *crono;
  gulong tiempo;

  crono = g_timer_new();

  do {
    status=g_io_channel_read_chars (sioc,buf,1,&num,&error);
    if (status==G_IO_STATUS_ERROR) {
      g_print ("Error: %s\n",error->message);
      g_clear_error(&error);
      sc_close(ioc);
      g_timer_destroy(crono);
      return -1;
    }
    g_timer_elapsed (crono, &tiempo);

  } while (num==0 && tiempo<timeout);

  g_timer_destroy(crono);

  if (tiempo>=timeout) return 0;
  *car = buf[0];

  return 1;
}

gint main (gint argc, gchar *argv[])
{
  GIOStatus status;
  gint n;
  gchar c;
  gint i;

  /*--------------------------------*/
  /* Configuracion del puerto SERIE */
  /*--------------------------------*/
  
  /* Abrir el puerto serie */
  status=sc_open("/dev/ttyS0",&sioc,G_IO_FLAG_NONBLOCK,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al abrir puerto serie: %s\n",error->message);
    g_error_free(error);
    return 0;
  }

  /* Configurar los baudios */
  status=sc_baudios_set(sioc,B9600,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al modificar velocidad: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Se�ales: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /*-----------------------------------------------------*/
  /* Comprobar si el reset se ha realizado correctamente */
  /*-----------------------------------------------------*/
  usleep(100);
  g_print ("Esperando reset...");
  n=leer_car_plazo(sioc,&c,1000);
  if (n==0) {
    g_print ("Timeout!\n");
    sc_close(sioc);
    return 0;
  }
  if (c==0)  g_print ("OK\n");
  else {
    g_print ("Error\n");
    sc_close(sioc);
    return 0;
  }

  /*----------------------*/
  /* Enviar el programa   */
  /*----------------------*/

  /* Configurar a 1200 baudios el 6811 */
  enviar_car(sioc,'a');
  g_io_channel_flush(sioc,&error);

  usleep(100);

  /* Configurar a 1200 baudios el PC */
  status=sc_baudios_set(sioc,B1200,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al modificar velocidad: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /* Enviar los datos al 6811 */
  enviar_bloque(sioc,ledp,256);   

  /* Comprobar el eco recibido */
  for (i=0; i<256; i++) {
    n=leer_car_plazo(sioc,&c, 500000);
    if (n==0) {
      g_print ("Timeout!\n");
      break;
    }
    if (c!=ledp[i]) {
      g_print ("Error!!\n");
      g_print ("Enviado [%hhu], Recibido [%hhu]\n",ledp[i],c);
      sc_close(sioc);
      return 0;
    }
    g_print (".");
  }

  /*-------*/
  /* FIN   */
  /*-------*/
  g_print("\n\n");

  /* Cerrar el puerto serie */
  sc_close(sioc);

  return 1;
}
