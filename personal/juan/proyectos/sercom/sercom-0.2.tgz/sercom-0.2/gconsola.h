/*********************************************************************/
/* gconsola.h   (c) Juan Gonz�lez G�mez.  Agosto-2002                */
/*-------------------------------------------------------------------*/
/* Definiciones para el modulo gconsola.c                            */
/*-------------------------------------------------------------------*/
/* Licencia GPL                                                      */
/*********************************************************************/

#include <glib.h>

#define GCONSOLA_OPEN 1
#define GCONSOLA_OPEN_SETUP1 1
#define GCONSOLA_OPEN_SETUP2 2


GIOStatus gconsola_open(GIOChannel **con, GError **error);
/*********************************************/
/* Abrir y configurar la consola             */
/*                                           */
/* SALIDAS: Error                            */
/* DEVUELVE: El estado de la operaci�n       */
/*********************************************/

void gconsola_close();
/********************************************************/
/* Cerrar la consola y devolverla a su estado anterior  */
/********************************************************/

