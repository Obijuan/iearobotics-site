/*******************************************************/
/* gconsola.c   (c) Juan Gonzalez Gomez. Agosto 2002   */
/*-----------------------------------------------------*/
/* Convertir la consola en un Canal GIO para poderla   */
/* integrar en el bucle principal de aplicaciones      */
/* basadas en GLIB-2.0                                 */
/*-----------------------------------------------------*/
/* Licencia GPL                                        */
/*******************************************************/

#include <glib.h>
#include <termios.h>
#include <unistd.h>

#include "gconsola.h"

/*------------*/
/* VARIABLES  */
/*------------*/
static struct termios oldconsola,consola;
GIOChannel *ioc;

GIOStatus gconsola_open(GIOChannel **con, GError **error)
/*********************************************/
/* Abrir y configurar la consola             */
/*                                           */
/* SALIDAS: Error                            */
/* DEVUELVE: El estado de la operaci�n       */
/*********************************************/
{
  gint fd;
  GIOStatus status;
  GIOFlags flags;

  /* Abrir un canal asociado a la consola */
  ioc=g_io_channel_unix_new(STDIN_FILENO);
  *con=ioc; /* Devolver canal */

  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);
  
  g_assert(ioc!=NULL);

  /* Configurar el canal para que sea NO BLOQUEANTE */
  flags=g_io_channel_get_flags(ioc);
  flags|=G_IO_FLAG_NONBLOCK;
  status=g_io_channel_set_flags(ioc,flags,error);
  if (status!=G_IO_STATUS_NORMAL) {
    /* Cerrar el canal */
    g_io_channel_shutdown(ioc,FALSE,error);
    return status;
  }

  /* Establecer codificaci�n binaria (NULA) */
  status=g_io_channel_set_encoding(ioc,NULL,error);
  if (status!=G_IO_STATUS_NORMAL) {
    /* Cerrar el canal */
    g_io_channel_shutdown(ioc,FALSE,error);
    return status;
  }

  /* Leer los parametros asociados a la consola */
  if (tcgetattr(fd,&consola)==-1) {
    g_set_error(error,
		GCONSOLA_OPEN, 
		GCONSOLA_OPEN_SETUP1,
		"Error al leer parametros");
    return G_IO_STATUS_ERROR;
  }

  /* Almacenar parametros para su posterior recuperaci�n */
  oldconsola = consola;
  
  /* Cambiar parametros */
  consola.c_cc[VMIN]=0;
  consola.c_lflag&=~(ECHO|ICANON); 
  
  /* Establecer los nuevos par�metros */
  if (tcsetattr(fd,TCSANOW,&consola)==-1) {
    g_set_error(error,
		GCONSOLA_OPEN,
		GCONSOLA_OPEN_SETUP2,
		"Error al escribir parametros");
    return G_IO_STATUS_ERROR;
  }
  
  return G_IO_STATUS_NORMAL;
}

void gconsola_close()
/********************************************************/
/* Cerrar la consola y devolverla a su estado anterior  */
/********************************************************/
{
  gint fd;

  /* Obtener el descriptor del fichero */
  fd=g_io_channel_unix_get_fd(ioc);

  tcsetattr(fd,TCSANOW,&oldconsola);
}


