/****************************************************************************/
/* CON-SCLEDP3.C   (C) Juan Gonz�lez G�mez.  Agosto 2002                    */
/****************************************************************************/
/* Ejemplo de prueba para el m�dulo SERCOM.C. Carga de un programa en la    */
/* interna de la CT6811                                                     */
/*--------------------------------------------------------------------------*/
/* Licencia GPL                                                             */
/* juan@iearobotics.com                                                     */
/****************************************************************************/

#include <stdlib.h>
#include <unistd.h>

#include <glib.h>
#include "sercom.h"

typedef enum {
  CT6811_IDLE,
  CT6811_RESETING,
  CT6811_ERROR,
  CT6811_LOADING
} CT6811Status;


/*----------------*/
/* Programa ledp  */
/*----------------*/

gchar ledp[256]={
  0xB6,0x10,0x00,0x88,0x40,0xB7,0x10,0x00,0x18,0xCE,0x5F,0xFF,0x18,0x09,0x18,
  0x8C,0x00,0x00,0x26,0xF8,0x20,0xEA,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,
};

GIOChannel *sioc;    /* Canal serie      */
GError *error=NULL;
GMainLoop *scterm;
CT6811Status estado=CT6811_IDLE; /* Estado de la CT6811 */
gulong tiempo;
gboolean timer_running=FALSE;
guint timer;

void enviar_bloque(GIOChannel *ioc, gchar *buf, gssize tam)
{
  GIOStatus status;
  gsize num;

  status=g_io_channel_write_chars(sioc,buf,tam,&num,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error: %s\n",error->message);
    g_clear_error(&error);
    sc_close(ioc);
    exit;
  }
}

void enviar_car(GIOChannel *ioc, gchar car)
{
  GIOStatus status;
  gsize num;
  gchar buf[2];

  buf[0]=car;
  status=g_io_channel_write_chars(sioc,buf,1,&num,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error: %s\n",error->message);
    g_clear_error(&error);
    sc_close(ioc);
    exit;
  }
}

gint leer_car_plazo(GIOChannel *ioc, gchar *car, gulong timeout)
/******************************************************/
/* Leer un caracter con timeout. Devuelve:            */
/* 0 : Timeout                                        */
/* 1 : OK                                             */
/* -1: Error                                          */
/******************************************************/
{
  GIOStatus status;
  gsize num;
  gchar buf[10];
  GTimer *crono;
  gulong tiempo;

  crono = g_timer_new();

  do {
    status=g_io_channel_read_chars (sioc,buf,1,&num,&error);
    if (status==G_IO_STATUS_ERROR) {
      g_print ("Error: %s\n",error->message);
      g_clear_error(&error);
      sc_close(ioc);
      g_timer_destroy(crono);
      return -1;
    }
    g_timer_elapsed (crono, &tiempo);

  } while (num==0 && tiempo<timeout);

  if (tiempo>=timeout) return 0;
  *car = buf[0];

  return 1;
}

gboolean temporizador(gpointer data)
{

  switch(estado) {
  case CT6811_RESETING:
    estado=CT6811_ERROR;
    g_print ("Timeout!\n");
    g_main_loop_quit(scterm);
    return FALSE;
  case CT6811_LOADING:
    g_print("Timeout!\n");
    g_main_loop_quit(scterm);
    return FALSE;
  default:
    g_print ("#");
    return TRUE;
  }

  return TRUE;
}


gboolean data_in (GIOChannel *ioc, GIOCondition condition, gpointer data)
/**********************************************************/
/* Funci�n de retrollamada de los datos recibidos por el  */
/* puerto serie.                                          */
/**********************************************************/
{
  gchar buf[2];
  gint num;
  GIOStatus status;
  static gint count=0;

  /* Seg�n el estado en el que se encuentre... */
  switch(estado) {
  case CT6811_RESETING: /* Estado de reset */
    /* Leer caracter recibido */
    g_io_channel_read_chars(ioc,buf,1,&num,&error);
    if (buf[0]==0) {
      estado=CT6811_LOADING;
      g_source_remove(timer);
      g_print ("OK!\n");

      /* Configurar a 1200 baudios el 6811 */
      enviar_car(sioc,'a');
      g_io_channel_flush(sioc,&error);

      usleep(100);

      /* Configurar a 1200 baudios el PC */
      status=sc_baudios_set(sioc,B1200,&error);
      if (status!=G_IO_STATUS_NORMAL) {
	g_print ("Error al modificar velocidad: %s\n",error->message);
	g_clear_error(&error);
	return 0;
      }

      /* Enviar los datos al 6811 */
      enviar_bloque(sioc,ledp,256);
      g_io_channel_flush(sioc,&error);
      timer=g_timeout_add(100,temporizador,NULL); 
    }
    else estado=CT6811_ERROR;
    break;
  case CT6811_LOADING:
    g_io_channel_read_chars(ioc,buf,1,&num,&error);
    if (buf[0]==ledp[count++]) {
      g_source_remove(timer);
      timer=g_timeout_add(100,temporizador,NULL);
      g_print (".");
      if (count==255) {
	g_print ("OK!\n");
	g_main_loop_quit(scterm);
      }
    }
    else {
      g_print ("Error!");
      g_main_loop_quit(scterm);
    }
    break;

  default:
    /* Leer un car�cter e imprimirlo en el terminal  */
    g_io_channel_read_chars (ioc,buf,1,&num,&error); 
    if(buf[0]>0) g_print ("%c", buf[0]);
    else g_print("[%hhu]",buf[0]);
  }


  return TRUE;
}


void reset(GIOChannel *ioc)
{
  GIOStatus status;

  /* Activar el DTR */
  status = sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_ON, &error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Se�ales: %s\n",error->message);
    g_clear_error(&error);
    return;
  }

  usleep(100);

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Se�ales: %s\n",error->message);
    g_clear_error(&error);
    return;
  }

  usleep(100);
  /* Pasar al estado de RESET */
  estado=CT6811_RESETING;
  timer=g_timeout_add(100,temporizador,NULL); 

}


gint main (gint argc, gchar *argv[])
{
  GIOStatus status;

  /*--------------------------------*/
  /* Configuracion del puerto SERIE */
  /*--------------------------------*/
  
  /* Abrir el puerto serie */
  status=sc_open("/dev/ttyS0",&sioc,G_IO_FLAG_NONBLOCK,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al abrir puerto serie: %s\n",error->message);
    g_error_free(error);
    return 0;
  }

  /* Configurar los baudios */
  status=sc_baudios_set(sioc,B9600,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al modificar velocidad: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Se�ales: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /*-----------------------------------------*/
  /* CONFIGURAR EVENTOS DEL BUCLE PRINCIPAL  */
  /*-----------------------------------------*/
  g_io_add_watch (sioc, G_IO_IN, data_in, NULL);
  scterm=g_main_loop_new(NULL,FALSE);
 
  /*-----------------------*/
  /* COMIENZO DE LA CARGA  */
  /*-----------------------*/
  reset(sioc);
  g_print("Esperando reset...");

  /*---------------------*/
  /*  BUCLE PRINCIPAL    */
  /*---------------------*/
  g_main_loop_run(scterm);


  /*-------*/
  /* FIN   */
  /*-------*/
  g_print("\n\n");

  /* Cerrar el puerto serie */
  sc_close(sioc);

  return 1;
}
