/********************************************************/
/* con-scterm.c   (c) Juan Gonz�lez G�mez. Agosto 2002  */
/*------------------------------------------------------*/
/* Terminal de comunicaciones en consola                */
/* Licencia GPL                                         */
/********************************************************/

#include <stdio.h>
#include <unistd.h>
#include <glib.h>

#include "sercom.h"
#include "gconsola.h"

GMainLoop *scterm;
GIOChannel *sioc;    /* Canal serie      */
GIOChannel *con_ioc; /* Canal de consola */
GError *error=NULL;

gboolean tecla_in (GIOChannel *ioc, GIOCondition condition, gpointer data)
/***************************************************************/
/* Funci�n de retrollamada del teclado. Cada vez que se pulsa  */
/* una tecla se invoca a esta funci�n                          */
/***************************************************************/
{
  GIOStatus status;
  gchar buf[2];
  gint num;
  
  /* Leer la tecla */
  status=g_io_channel_read_chars(ioc,buf,1,&num,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al leer tecla: %s\n",error->message);
    g_clear_error(&error);
    return TRUE;
  }

  /* Condici�n de salida. Si la tecla recibida  */
  /* es ESC se termina el programa              */
  if (buf[0]==27) g_main_loop_quit(scterm);

  /* Si es una tecla correspondiente al menu... */
  if (g_ascii_isdigit(buf[0])) {
    switch(buf[0]) {
      case '1': 
	sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_ON, &error);
	g_print (" [DTR ON] ");
	return TRUE;
      case '2':
	sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
	g_print(" [DTR OFF] ");
	return TRUE;
      case '3':
	sc_baudios_set(sioc, B1200, &error);
	g_print (" [BAUDIOS 1200] ");
	return TRUE;
      case '4' :
	sc_baudios_set(sioc, B9600, &error);
	g_print (" [BAUDIOS 9600] ");
	return TRUE;
    }
  }

  /* Enviar la tecla al puerto serie */
  g_io_channel_write_chars(sioc,buf,1,&num,&error);
  g_io_channel_flush(sioc,&error);
  return TRUE;
}

gboolean data_in (GIOChannel *ioc, GIOCondition condition, gpointer data)
/**********************************************************/
/* Funci�n de retrollamada de los datos recibidos por el  */
/* puerto serie.                                          */
/**********************************************************/
{
  gchar buf[2];
  gint num;

  /* Leer un car�cter e imprimirlo en el terminal  */
  g_io_channel_read_chars (ioc,buf,1,&num,&error); 
  if(buf[0]>0) g_print ("%c", buf[0]);
  else g_print("[%hhu]",buf[0]);

  return TRUE;
}

void show_dtr(GIOChannel *ioc)
/********************************/
/* Mostrar el estado del DTR    */
/********************************/
{
  GIOStatus status;
  gint estado;
  GError *error=NULL;

  /* Obtener estado del DTR */
  status=sc_signal_dtr_get(ioc,&estado,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Senales: %s\n",error->message);
    g_clear_error(&error);
    return;
  }

  if (estado==SC_SIGNAL_DTR_ON) g_print ("DTR ON\n");
  else g_print ("DTR OFF\n");
}


void menu()
{
  g_print ("\n");
  g_print ("Menu de opciones\n\n");
  g_print ("1.- DTR ON\n");
  g_print ("2.- DTR OFF\n");
  g_print ("3.- Velocidad: 1200 Baudios\n");
  g_print ("4.- Velocidad: 9600 Baudios\n");
  g_print ("ESC.- Terminar\n\n");
  show_dtr(sioc);
}


gint main (gint argc, gchar *argv[])
{
  GIOChannel *con;
  GIOStatus status;

  /*--------------------------------*/
  /* Configuracion del puerto SERIE */
  /*--------------------------------*/
  
  /* Abrir el puerto serie */
  status=sc_open("/dev/ttyS0",&sioc,G_IO_FLAG_NONBLOCK,&error);

  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al abrir puerto serie: %s\n",error->message);
    g_error_free(error);
    return 0;
  }

  /* Configurar los baudios */
  status=sc_baudios_set(sioc,B1200,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error al modificar velocidad: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /* Desactivar el DTR */
  status = sc_signal_dtr_set(sioc, SC_SIGNAL_DTR_OFF, &error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Se�ales: %s\n",error->message);
    g_clear_error(&error);
    return 0;
  }

  /*--------------------------*/
  /* CONFIGURAR LA CONSOLA    */
  /*--------------------------*/

  /* Abrir la consola */
  status=gconsola_open(&con,&error);
  if (status!=G_IO_STATUS_NORMAL) {
    g_print ("Error apertura consola: %s",error->message);
    g_clear_error(&error);
    return 0;
  }

  /*-----------------------------------------*/
  /* CONFIGURAR EVENTOS DEL BUCLE PRINCIPAL  */
  /*-----------------------------------------*/
  g_io_add_watch (sioc, G_IO_IN, data_in, NULL);
  g_io_add_watch (con, G_IO_IN, tecla_in, NULL);
  
  /* Sacar menu principal */
  menu();

  /*---------------------*/
  /*  BUCLE PRINCIPAL    */
  /*---------------------*/
  scterm=g_main_loop_new(NULL,FALSE);
  g_main_loop_run(scterm);

  /*-------*/
  /* FIN   */
  /*-------*/
  g_print("\n\n");

  /* Cerrar el puerto serie */
  sc_close(sioc);

  /* Cerrar la consola */
  gconsola_close();

  g_free(scterm);
  return 0;
}

