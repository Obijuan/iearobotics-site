EESchema Schematic File Version 1
LIBS:power,./monolito,device,conn,linear,regul,74xx,cmos4000,adc-dac,memory,xilinx,special,analog_switches
EELAYER 23  0
EELAYER END
$Descr A4 11700 8267
Sheet 1 1
Title "Freeleds Board"
Date "21 jun 2005"
Rev "0.1"
Comp "www.iearobotics.com"
Comment1 "Open Hardware License"
Comment2 "designed by Andres Prieto-Moreno (C) 2001-2005"
Comment3 "Derived from the open board PCTLED"
Comment4 "(c) Juan Gonz�lez 2005"
$EndDescr
Text Notes 3900 2800 0    40   ~
pines del conector
Text Notes 3900 2700 0    40   ~
Numeracion del los
Wire Notes Line
	4700 2450 4700 2200
Wire Notes Line
	4550 2600 4700 2450
Wire Notes Line
	4700 2200 4550 2350
Wire Notes Line
	4100 2200 4700 2200
Wire Notes Line
	3950 2350 4100 2200
Wire Notes Line
	3950 2600 3950 2350
Wire Notes Line
	4550 2600 3950 2600
Wire Notes Line
	4550 2350 4550 2600
Wire Notes Line
	4300 2350 4550 2350
Wire Notes Line
	4350 2300 4300 2350
Wire Notes Line
	4250 2300 4350 2300
Wire Notes Line
	4200 2350 4250 2300
Wire Notes Line
	3950 2350 4200 2350
Text Notes 4400 2450 0    40   ~
1
Text Notes 4000 2550 0    40   ~
6
Text Notes 4100 2550 0    40   ~
7
Text Notes 4200 2550 0    40   ~
8
Text Notes 4300 2550 0    40   ~
9
Text Notes 4400 2550 0    40   ~
10
Text Notes 4000 2450 0    40   ~
5
Text Notes 4100 2450 0    40   ~
4
Text Notes 4200 2450 0    40   ~
3
Text Notes 4300 2450 0    40   ~
2
Text Notes 7550 2100 0    60   ~
LEDS
$Comp
L DIODO_LED D7
U 1 1 42A9A6DD
P 7650 4100
F 0 "D7" H 7650 4200 50  0000 C C
F 1 "DIODO_LED" H 7650 4000 50  0001 C C
	1    7650 4100
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D6
U 1 1 42A9A6DA
P 7650 3850
F 0 "D6" H 7650 3950 50  0000 C C
F 1 "DIODO_LED" H 7650 3750 50  0001 C C
	1    7650 3850
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D5
U 1 1 42A9A6C3
P 7650 3600
F 0 "D5" H 7650 3700 50  0000 C C
F 1 "DIODO_LED" H 7650 3500 50  0001 C C
	1    7650 3600
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D2
U 1 1 42A9A6C0
P 7650 2850
F 0 "D2" H 7650 2950 50  0000 C C
F 1 "DIODO_LED" H 7650 2750 50  0001 C C
	1    7650 2850
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D3
U 1 1 42A9A6BE
P 7650 3100
F 0 "D3" H 7650 3200 50  0000 C C
F 1 "DIODO_LED" H 7650 3000 50  0001 C C
	1    7650 3100
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D1
U 1 1 42A9A6B5
P 7650 2600
F 0 "D1" H 7650 2700 50  0000 C C
F 1 "DIODO_LED" H 7650 2500 50  0001 C C
	1    7650 2600
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D4
U 1 1 42A9A697
P 7650 3350
F 0 "D4" H 7650 3450 50  0000 C C
F 1 "DIODO_LED" H 7650 3250 50  0001 C C
	1    7650 3350
	1    0    0    -1  
$EndComp
$Comp
L DIODO_LED D0
U 1 1 42A9A67D
P 7650 2350
F 0 "D0" H 7650 2450 50  0000 C C
F 1 "DIODO_LED" H 7650 2250 50  0001 C C
	1    7650 2350
	1    0    0    -1  
$EndComp
$Comp
L RESISTENCIA1 R7
U 1 1 42A9A2A1
P 7100 3850
F 0 "R7" V 7200 3950 50  0000 C C
F 1 "220" V 7200 3750 50  0000 C C
	1    7100 3850
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R6
U 1 1 42A9A29A
P 7100 3600
F 0 "R6" V 7200 3700 50  0000 C C
F 1 "220" V 7200 3500 50  0000 C C
	1    7100 3600
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R5
U 1 1 42A9A260
P 7100 3350
F 0 "R5" V 7200 3450 50  0000 C C
F 1 "220" V 7200 3250 50  0000 C C
	1    7100 3350
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R4
U 1 1 42A9A259
P 7100 3100
F 0 "R4" V 7200 3200 50  0000 C C
F 1 "220" V 7200 3000 50  0000 C C
	1    7100 3100
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R8
U 1 1 42A9A255
P 7100 4100
F 0 "R8" V 7200 4200 50  0000 C C
F 1 "220" V 7200 4000 50  0000 C C
	1    7100 4100
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R3
U 1 1 42A9A251
P 7100 2850
F 0 "R3" V 7200 2950 50  0000 C C
F 1 "220" V 7200 2750 50  0000 C C
	1    7100 2850
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R2
U 1 1 42A9A232
P 7100 2600
F 0 "R2" V 7200 2700 50  0000 C C
F 1 "220" V 7200 2500 50  0000 C C
	1    7100 2600
	0    -1   -1   0   
$EndComp
$Comp
L RESISTENCIA1 R1
U 1 1 42A9A07B
P 7100 2350
F 0 "R1" V 7200 2450 50  0000 C C
F 1 "220" V 7200 2250 50  0000 C C
	1    7100 2350
	0    -1   -1   0   
$EndComp
$Comp
L CT CT1
U 1 1 42A941CB
P 5250 2800
F 0 "CT1" V 5250 2800 60  0000 C C
F 1 "CT" V 5300 2800 60  0001 C C
	1    5250 2800
	-1   0    0    1   
$EndComp
Text Notes 5000 2200 0    60   ~
Conector
Wire Bus Line
	6550 2150 6550 4000
Wire Bus Line
	5900 2150 6550 2150
Wire Bus Line
	5900 3350 5900 2150
Text Label 6650 2850 0    40   ~
bit2
Text Label 6650 2600 0    40   ~
bit1
Text Label 6650 2350 0    40   ~
bit0
Entry Wire Line
	6550 2500 6650 2600
Wire Wire Line
	6850 2600 6650 2600
Text Label 5650 3250 0    40   ~
bit1
Text Label 5650 3150 0    40   ~
bit3
Text Label 5650 3050 0    40   ~
bit5
Text Label 5650 2950 0    40   ~
bit7
Text Label 5650 2650 0    40   ~
bit6
Text Label 5650 2550 0    40   ~
bit4
Text Label 5650 2450 0    40   ~
bit2
Text Label 5650 2350 0    40   ~
bit0
Wire Wire Line
	5600 2350 5800 2350
Entry Wire Line
	5800 2350 5900 2450
Connection ~ 8000 4200
$Comp
L PWR_FLAG #FLG1
U 1 1 4298C325
P 8000 4200
F 0 "#FLG1" H 8000 4470 30  0001 C C
F 1 "PWR_FLAG" H 8000 4430 30  0000 C C
	1    8000 4200
	0    1    1    0   
$EndComp
Wire Wire Line
	5750 2750 5750 2800
Wire Wire Line
	5600 2750 5750 2750
$Comp
L GNDPWR #PWR2
U 1 1 4298C0C4
P 5750 2800
F 0 "#PWR2" H 5750 2800 40  0001 C C
F 1 "GNDPWR" H 5750 2720 40  0001 C C
	1    5750 2800
	1    0    0    -1  
$EndComp
Text Label 6650 4100 0    40   ~
bit7
Text Label 6650 3850 0    40   ~
bit6
Text Label 6650 3600 0    40   ~
bit5
Text Label 6650 3350 0    40   ~
bit4
Text Label 6650 3100 0    40   ~
bit3
Wire Wire Line
	6850 3100 6650 3100
Entry Wire Line
	6550 4000 6650 4100
Entry Wire Line
	6550 3750 6650 3850
Entry Wire Line
	6550 3500 6650 3600
Entry Wire Line
	6550 3250 6650 3350
Entry Wire Line
	6550 3000 6650 3100
Entry Wire Line
	6550 2750 6650 2850
Entry Wire Line
	5800 3250 5900 3350
Entry Wire Line
	5800 3150 5900 3250
Entry Wire Line
	5800 3050 5900 3150
Entry Wire Line
	5800 2950 5900 3050
Entry Wire Line
	5800 2650 5900 2750
Entry Wire Line
	5800 2550 5900 2650
Entry Wire Line
	5800 2450 5900 2550
Wire Wire Line
	5600 3250 5800 3250
Wire Wire Line
	5600 3150 5800 3150
Wire Wire Line
	5600 3050 5800 3050
Wire Wire Line
	5600 2950 5800 2950
Wire Wire Line
	5600 2650 5800 2650
Wire Wire Line
	5600 2550 5800 2550
Wire Wire Line
	5600 2450 5800 2450
Wire Wire Line
	6850 4100 6650 4100
Wire Wire Line
	6850 3850 6650 3850
Wire Wire Line
	6850 3600 6650 3600
Wire Wire Line
	6850 3350 6650 3350
Wire Wire Line
	6850 2850 6650 2850
NoConn ~ 5600 2850
Entry Wire Line
	6550 2250 6650 2350
Wire Wire Line
	6850 2350 6650 2350
Connection ~ 8000 2600
Connection ~ 8000 2850
Connection ~ 8000 3100
Connection ~ 8000 3350
Connection ~ 8000 3600
Connection ~ 8000 3850
Connection ~ 8000 4100
Wire Wire Line
	7850 4100 8000 4100
Wire Wire Line
	7850 3850 8000 3850
Wire Wire Line
	7850 3600 8000 3600
Wire Wire Line
	7850 3350 8000 3350
Wire Wire Line
	7850 3100 8000 3100
Wire Wire Line
	7850 2850 8000 2850
Wire Wire Line
	7850 2600 8000 2600
Wire Wire Line
	8000 2350 8000 4250
Wire Wire Line
	7850 2350 8000 2350
Wire Wire Line
	7350 4100 7450 4100
Wire Wire Line
	7350 3850 7450 3850
Wire Wire Line
	7350 3600 7450 3600
Wire Wire Line
	7350 3350 7450 3350
Wire Wire Line
	7350 3100 7450 3100
Wire Wire Line
	7350 2850 7450 2850
Wire Wire Line
	7350 2600 7450 2600
Wire Wire Line
	7350 2350 7450 2350
$Comp
L GNDPWR #PWR1
U 1 1 4298B3A8
P 8000 4250
F 0 "#PWR1" H 8000 4250 40  0001 C C
F 1 "GNDPWR" H 8000 4170 40  0001 C C
	1    8000 4250
	1    0    0    -1  
$EndComp
Text Notes 3900 3700 0    40   ~
Conexion a Skypic
Text Notes 3900 3600 0    40   ~
Peso de los Bits
Wire Notes Line
	4700 3350 4700 3100
Wire Notes Line
	4550 3500 4700 3350
Wire Notes Line
	4700 3100 4550 3250
Wire Notes Line
	4100 3100 4700 3100
Wire Notes Line
	3950 3250 4100 3100
Wire Notes Line
	3950 3500 3950 3250
Wire Notes Line
	4550 3500 3950 3500
Wire Notes Line
	4550 3250 4550 3500
Wire Notes Line
	4300 3250 4550 3250
Wire Notes Line
	4350 3200 4300 3250
Wire Notes Line
	4250 3200 4350 3200
Wire Notes Line
	4200 3250 4250 3200
Wire Notes Line
	3950 3250 4200 3250
Text Notes 4450 3360 0    40   ~
B1
Text Notes 3970 3460 0    30   ~
GND
Text Notes 4100 3460 0    40   ~
B6
Text Notes 4210 3460 0    40   ~
B4
Text Notes 4330 3460 0    40   ~
B2
Text Notes 4450 3460 0    40   ~
B0
Text Notes 4000 3360 0    40   ~
X
Text Notes 4100 3360 0    40   ~
B7
Text Notes 4210 3360 0    40   ~
B5
Text Notes 4330 3360 0    40   ~
B3
$EndSCHEMATC
