#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "wiimote.h"
#include "wiimote_api.h"

GLfloat matBlanco[] = {1.0, 1.0, 1.0, 1.0};

wiimote_t wiimando = WIIMOTE_INIT;
wiimote_report_t estado = WIIMOTE_REPORT_INIT;
float rotx=.0, roty=.0, rotz=.0;
float escala=1.0;
float tx=.0, ty=.0, tz=.0;

void dibujar() 
{ 
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
    glLoadIdentity(); 
    gluLookAt(0.0, 1.0, 8.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);

	 glTranslatef(tx, ty, tz);
    glPushMatrix();
	 glRotatef (90, 1.0, 0.0, 0.0);
	 glRotatef (-rotx, 1, 0, 0);
	 glRotatef (roty, 0, 1, 0);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, matBlanco);
    glPushMatrix();
    	 glScalef (5.0 * escala, 2.0 * escala, 1.2 * escala);
       glutSolidCube(1.0);
    glPopMatrix();
	 glutSwapBuffers();      
} 

void escalar(int w, int h) 
{ 
  // Viewport para dibujar en toda la ventana 
  glViewport( 0, 0, w, h ); 
  
  // Actualizamos en la matriz de proyección el ratio ancho/alto 
  glMatrixMode( GL_PROJECTION ); 
  glLoadIdentity(); 
  gluPerspective( 60., (double)w/(double)h, 1., 20. ); 
  
  // Volvemos al modo Vista de Modelo 
  glMatrixMode( GL_MODELVIEW ); 
}

void actualizar()
{
	if (wiimote_is_open(&wiimando)) {
		if ((wiimote_update(&wiimando) < 0) || (wiimando.keys.home)) {
			wiimote_disconnect(&wiimando); exit(1);
		}

		estado.channel = WIIMOTE_RID_STATUS;
		wiimote_report(&wiimando, &estado, sizeof(estado.status));

		if ((wiimando.tilt.x > -180) && (wiimando.tilt.x < 180))
			rotx = wiimando.tilt.x;
		if ((wiimando.tilt.y > -180) && (wiimando.tilt.y < 180))
			roty = wiimando.tilt.y;

		if (wiimando.keys.one) escala+=0.01;
		if (wiimando.keys.two) escala-=0.01;
		if (wiimando.keys.up)    tx-=0.03;
		if (wiimando.keys.down)  tx+=0.03;
		if (wiimando.keys.right) ty+=0.03;
		if (wiimando.keys.left)  ty-=0.03;
	}
	glutPostRedisplay();
}

int main( int argc, char** argv ) 
{ 
  GLfloat posluz[] = {0.0, 4.0, 8.0, 0.0}; 
  GLfloat luz[] = {1.0, 1.0, 1.0, 1.0};

  glutInit( &argc, argv ); 
  
  glutInitDisplayMode( GLUT_DEPTH | GLUT_RGB | GLUT_DOUBLE ); 
  glutInitWindowSize(640, 480); 
  glutCreateWindow( "Ejemplo WiiMando" ); 
  
  glClearColor(0.2, 0.2, 0.2, 1.0);
  glShadeModel(GL_SMOOTH);
  glLightfv(GL_LIGHT0, GL_POSITION, posluz);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, luz);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_DEPTH_TEST);

  printf ("Pulsa los botones 1 y 2 del WiiMando simultáneamente para conectar...\n");

  // Conectamos con el wiimando
  if (wiimote_connect(&wiimando, "00:17:AB:3B:8A:CE") < 0) {
		printf ("No se pudo conectar con wiimando: %s\n", wiimote_get_error()); exit(1);
  }

  printf ("Conectado!! Pulsa el botón Home para salir\n");

  wiimando.led.one = 1;  // Activamos el primer led del wiimando	
  wiimando.rumble = 0;   
  wiimando.mode.acc = 1; // Activamos el acelerometro

  // Registro de funciones de callback
  glutDisplayFunc(dibujar); 
  glutReshapeFunc(escalar); 
  glutIdleFunc(actualizar); 
  glutMainLoop();  
  return 0; 
}
