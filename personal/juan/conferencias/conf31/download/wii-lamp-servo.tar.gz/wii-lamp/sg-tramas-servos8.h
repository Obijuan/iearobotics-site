/****************************************************************/
/* sg-tramas-servos8.h   (c) Juan Gonzalez Gomez. 5-Marzo-2004  */
/*--------------------------------------------------------------*/
/* LICENCIA GPL                                                 */
/****************************************************************/

/**********************************/
/* Inicializar el modulo servos8  */
/**********************************/
void sg_servos8_init(int fd);

/***************************************************/
/* Posicionamiento de un servo, en grados          */
/***************************************************/
void sg_servos8_pos1_grados(int servo, int pos);

/********************************************************/
/* Posicionamiento de los 8 servos, en grados           */
/********************************************************/
void sg_servos8_pos8_grados(int s1, int s2, int s3, int s4,
                            int s5, int s6, int s7, int s8);

/*****************************************************************/
/* Servicio de HABILITACION de los servos, directo al StarGate   */
/*---------------------------------------------------------------*/
/* Se construye la trama ENA, se envía al StarGate               */
/*                                                               */
/*****************************************************************/
void sg_servos8_enable(int mask);
