/************************************************************************/
/* test-servos8.   Juan Gonzalez Gomez.   Diciembre-2005                */
/*----------------------------------------------------------------------*/
/* Ejemplo de manejo del modulo servos8                                 */
/*----------------------------------------------------------------------*/
/* LICENCIA GPL                                                         */
/************************************************************************/
#include <stdio.h>
#include <unistd.h>

#include <stargate/stargate.h>
#include "sg-tramas-servos8.h"

int main(void)
{
	int serial_fd;  /*-- Descriptor puerto serie */
	
  printf ("Test de servos8\n");
	
  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el módulo servos8
	sg_servos8_init(serial_fd);
 
  //-- Llevar todos los servos a la posicion inicial
  sg_servos8_pos8_grados(0,0,0,0,0,0,0,0);
  
  //-- Habilitar todos los servos
  sg_servos8_enable(0xFF);
  
  //-- Llevar servo 1 a un extremo
  sg_servos8_pos1_grados(1,-90);
  
  //-- Esperar 
  sleep(1);
  
  //-- Llevar servo a posicion inicial
  sg_servos8_pos1_grados(1,0);
  
  //-- Esperar
  sleep(1);
  
  //-- Deshabilitar servos
  sg_servos8_enable(0x00);
 
	//-- Cerrar puerto serie
  close(serial_fd);
	
  return 0;
}
