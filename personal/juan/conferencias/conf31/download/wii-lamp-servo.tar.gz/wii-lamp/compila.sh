#!/bin/bash
gcc -I./libwiimote-0.4/src/ -L./libwiimote-0.4/lib/ -lGL -lGLU -lglut -lcwiimote -lbluetooth -lm -Os -Wall -pipe -D_ENABLE_TILT -D_ENABLE_FORCE -g -O2 -o wiigl wiigl.c
