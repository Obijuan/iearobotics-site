/**************************************************/
/* test-skylamp.c      Juan Gonzalez Gomez.       */
/*------------------------------------------------*/
/* Ejemplo Hola mundo para activa/desactivar      */
/* el rele de la SKY293                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>

#include "consola_io.h"
#include "stargate.h"

/****************/
/* CONSTANTES   */
/****************/
#define TRISA 0x85
#define PORTA 0x05
#define ON    0x08  
#define OFF   0x20

/*****************************/
/*    FUNCIONES              */
/*****************************/

/********************************/
/* Identificacion del servidor  */
/********************************/
int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}


/*********************/
/* Imprimir el MENU  */
/*********************/
void print_menu(void)
{
  printf ("\n");
  printf ("1.-   ON\n");
  printf ("2.-   OFF\n");
  printf ("ESC.- Terminar\n\n");
}

/*******************/
/* Menu Principal  */
/*******************/
void menu(void)
{
  char c;
	int estado=0;
	int i;

  //-- Imprimir el menu
  print_menu();

  //-- Bucle principal
  do {
    //-- Leer caracter
	  c=consola_io_getch();
    
    //-- Seleccionar la opcion
    switch(c) {
    case '1': 
			sg_store(TRISA,0x1F);
			sg_store(PORTA,0x00);  //-- ON
      break;
    case '2': 
				sg_store(TRISA,0x1F);
		    sg_store(PORTA,0x20);  //-- OFF
      break;
		case '3':
			  for (i=0; i<100; i++) {
					sg_store(TRISA,0x1F);
					if (estado==1) 
					  sg_store(PORTA,0x20);  //-- OFF
					else
						sg_store(PORTA,0x08);  //-- ON
					estado=(estado+1) % 2;
					usleep(50000);
				}
					
    }
  } while (c!=27);
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Prueba de la SKYLAMP\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexi�n establecida\n");
  else {
    printf ("Conexi�n NO establecida\n");
    exit(1);
  }
}

int main (void)
{
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Configurar la consola
  consola_io_open();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  //inicio();
  
  //-- Configurar SKYPIC
  sg_store(TRISA,0x1F);
  
  //-- Opciones para el usuario
  menu();

  //-- Consola a su estado inicial
   consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
