/************************************************************************/
/* video.c       Sep-2000                                               */
/*----------------------------------------------------------------------*/
/* Modulo para dibujar el gusano virtual.                               */
/************************************************************************/

#include <stdio.h>
#include <gtk/gtk.h>

#include "video.h"
#include "gtkutils.h"
#include "cube.h"
#include "func.h"

/* --- Tamaño de la ventana de dibujo --- */
#define TAMX 400
#define TAMY 200

/* --- Origen para las coordenadas de pantalla -- */
#define ORIGENX 50
#define ORIGENY 120

/*-----------------------------------*/
/*      VARIABLES EXTERNAS           */
/*-----------------------------------*/
extern GList *cube_cola;

/*------------------------------------*/
/*   VARIABLES LOCALES DEL MODULO     */
/*------------------------------------*/
/* Articulacion activa, que se pinta de otro color */
static int  art_activa=0;

static GtkWidget *drawing_area=NULL;    /* Widget del area de dibujo */
static GdkPixmap *pixmap = NULL;        /* buffer de dibujo          */

/* -- Origen de coordenadas en pantalla -- */
static int origenx = ORIGENX; 
static int origeny = ORIGENY;

static GdkFont *font     = NULL;   /* Tipo de letra empleado */    
static GdkGC *pen_red    = NULL;   /* Color rojo             */
static GdkGC *pen_green  = NULL;   /* Color verde            */
static GdkGC *pen_blue   = NULL;   /* Color azul             */
static GdkGC *pen_yellow = NULL;   /* Color amarillo         */
static GdkGC *pen_black  = NULL;

/* -- Funcion que se dibuja en pantalla -- */
static double (*func_draw)(double);

/* -- Estado de visualizacion -- */
static gboolean show_ejex=TRUE;
static gboolean show_func=TRUE;
static gboolean show_cube=TRUE;


/*------------------------------------------------------------*/
/* P R O T O T I P O S   F U N C I O N E S   P R I V A D A S  */
/*------------------------------------------------------------*/
static GdkGC *get_pen(GdkColor *c);
static gint configure_event (GtkWidget *widget, GdkEventConfigure *event);
static gint expose_event (GtkWidget *widget, GdkEventExpose *event);
static void dibujar_cube(GtkWidget *widget);
static void dibujar_grafica(GtkWidget *widget);
static void dibujar_ejex(GtkWidget *widget);

/*------------------------------------------------*/
/*  F U N C I O N E S    D E   I N T E R F A Z    */
/*------------------------------------------------*/

GtkWidget *video_init()
/****************************************************************************/
/* Crear el area de dibujo, configurarla y asignar los eventos pertinentes  */
/* Se inicializan todas las variables locales del modulo.                   */
/*                                                                          */
/* Esta funcion es la que primero debe ser llamada del modulo.              */
/*                                                                          */
/* DEVUELVE:                                                                */
/*             el Widget creado.                                            */
/****************************************************************************/
{

   /* -- Crear area de dibujo -- */
  drawing_area = gtk_drawing_area_new();
  
  /* -- Asignar tipo de letra --*/
  font = drawing_area->style->font;
  
  /* Establecer tamaño area dibujo */
  gtk_drawing_area_size (GTK_DRAWING_AREA(drawing_area), TAMX, TAMY);
  
  /* Hacerla visible */
  gtk_widget_show(drawing_area);
  
  /* Configurar los eventos expose_event y configure_event */
  gtk_signal_connect (GTK_OBJECT (drawing_area), "configure_event",
                      (GtkSignalFunc) configure_event, NULL);
                      
  gtk_signal_connect (GTK_OBJECT (drawing_area), "expose_event",
                      (GtkSignalFunc) expose_event, NULL);
                      
  /* Devolver widget creado */                    
  return (drawing_area);                    
}

void video_origenx_inc(int inc)
/******************************************/
/* Incrementar el origen de coordenadas X */
/******************************************/
{
  origenx+=inc;
}

void video_origeny_inc(int inc)
/******************************************/
/* Incrementar el origen de coordenadas Y */
/******************************************/
{
  origeny+=inc;
}

void video_origen_reset()
/*********************************************/
/* Llevar el origen a su posicion inicial    */
/*********************************************/
{
  origenx=ORIGENX;
  origeny=ORIGENY;
}

void video_refrescar()
/**************************************************/
/* Refrescar la pantalla. Se redibuja el gusano   */
/**************************************************/
{
  GdkRectangle update_rect;

  update_rect.x = 0;
  update_rect.y = 0;
  update_rect.width  = drawing_area->allocation.width;
  update_rect.height = drawing_area->allocation.height;

  gtk_widget_draw(drawing_area,&update_rect);
}

void video_set_func_draw(double (*func)(double))
/*************************************/
/* Establecer la funcion a dibujar   */
/*************************************/
{
  func_draw=func;
}

void video_show_ejex(gboolean dibujar)
/******************************************************/
/* Establecer el estado del ejex X: visto o no visto  */
/******************************************************/
{
  show_ejex=dibujar;
}

void video_show_cube(gboolean dibujar)
/********************************************************/
/* Establecer el estado de cube: visto o no visto       */
/********************************************************/
{
  show_cube=dibujar;
}

void video_show_func(gboolean dibujar)
/**********************************************************************/
/* Establecer el estado de la funcion de contorno: vista o no vista   */
/**********************************************************************/
{
  show_func=dibujar;
}

void video_set_art_activa(int nart)
/*******************************************************************/
/* Establecer la articulacion activa, que se pintara de otro color */
/*******************************************************************/
{
  art_activa=nart;
}


/*-------------------------------------------------*/
/*     F U N C I O N E S    P R I V A D A S        */
/*-------------------------------------------------*/

static GdkGC *get_pen(GdkColor *c)
/*******************************/
/* Obtener un gc para dibujar  */
/*******************************/
{
  GdkGC *gc;
  
  /* --- Crear un gc --- */
  gc = gdk_gc_new(pixmap);
  
  /*--- Configurar el primer plano con el color --- */
  gdk_gc_set_foreground (gc,c);
  
  return (gc);
}


static gint configure_event (GtkWidget *widget, GdkEventConfigure *event)
/***************************************************/
/* Funcion llamada por la señal CONFIGURE_EVENT    */
/***************************************************/
{

  /* Liberar buffer de dibujo, si ya estaba creado */
  if (pixmap) {
    gdk_pixmap_unref (pixmap);
  }

  /* Crear un nuevo buffer, segun el tamaño de la nueva ventana */
  pixmap = gdk_pixmap_new (widget->window,
                           widget->allocation.width,
                           widget->allocation.height,
                           -1);
                           
  /* Crear los pinceles, si no estaban creados */
  if (pen_red==NULL) {
    pen_red   = get_pen (gtkutils_new_color(0xffff, 0, 0));
    pen_green = get_pen (gtkutils_new_color(0x0, 0xffff, 0));
    pen_blue  = get_pen (gtkutils_new_color(0x0, 0x0, 0xffff));
    pen_yellow= get_pen (gtkutils_new_color(0xffff,0xffff,0x0000));
    pen_black = get_pen (gtkutils_new_color(0x0,0x0,0x0));
  }                         

  return TRUE;
}

static gint expose_event (GtkWidget *widget, GdkEventExpose *event)
/***************************************************************************/
/* Funcion llamada por la señal EXPOSE_EVENT, que se produce cada vez que  */
/* hay que redibujar la pantalla grafica.                                  */
/***************************************************************************/
{
  /* Borrar imagen anterior en buffer */
  gdk_draw_rectangle (pixmap, widget->style->white_gc,
                      TRUE, 0,0,
                      widget->allocation.width,
                      widget->allocation.height);
 
  /* Dibujar la nueva imagen en el buffer */                     
  //gdk_draw_rectangle(pixmap,pen_red,FALSE,2,2,65,20);
  //gdk_draw_string(pixmap,font,pen_red,5,15,"CUBE-1.4.1");
  
  dibujar_ejex(widget);
  dibujar_grafica(widget);
  dibujar_cube(widget);
                      
  /* Copiar buffer a la ventana */
  gdk_draw_pixmap(widget->window, widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
                  pixmap,
                  event->area.x, event->area.y,
                  event->area.x, event->area.y,
                  event->area.width, event->area.height);                    
                      
  return TRUE;
}

static void dibujar_ejex(GtkWidget *widget)
/****************************************************/
/* Dibujar el eje x, si es que esta activo          */
/****************************************************/
{
  double xp1,yp1;
  double xp2,yp2;

  if (!show_ejex) return;

  /* Coordenadas de pantalla parte izquierda eje x */
  xp1=origenx-ORIGENX;
  yp1=origeny-0;

  /* Coordenadas de pantalla parte derecha eje x */
  xp2=origenx+TAMX;
  yp2=origeny-0;

  gdk_draw_line(pixmap,pen_blue,xp1,yp1,xp2,yp2);
}

static void dibujar_grafica(GtkWidget *widget)
{
  double xp;
  double yp;
  double xc,yc;  /* Coordenadas del cursor grafico */
  double x;
  double y;
  
  if (!show_func) return;

  /* Obtener punto inicial, en coordenadas de pantalla */
  xc=-50;
  yc=(*func_draw)(xc);
  xc = origenx+xc;
  yc = origeny-yc;
  
  for (x=-50; x<380; x++) {
    y=(*func_draw)(x);
    xp=origenx+x;
    yp=origeny-y;
/*    gdk_draw_point(pixmap,pen_yellow,xp,yp);*/
    gdk_draw_line(pixmap,pen_black,xc,yc,xp,yp);
    
    /* Actualizar el cursor grafico */
    xc=xp;
    yc=yp;
  }
}

static void dibujar_cube(GtkWidget *widget)
/*****************************************************************************/
/* Dibujar el gusano a partir de la estructura abstracta.                    */
/* Se utilizan una serie de variables globales para indicar ciertos eventos: */
/*                                                                           */
/*   - art_activa = Indica el numero de articulacion activa.  Se pinta de    */
/*                  otro color.                                              */
/*****************************************************************************/
{
  articulacion_t *art;
  GList          *nodo;
  GdkGC          *pen;
  int i=0;
  int xc,yc;  /* Coordenadas del cursor grafico */
  int x,y;    /* Coordenadas de pantalla        */
  char cad[3];
  
  if (!show_cube) return;
  
  /* Inicializar coordenadas del cursor grafico */
  art=(articulacion_t *)cube_cola->data;
  xc=origenx + art->coord.x;
  yc=origeny - art->coord.y;
  
  /* Recorrer las articulaciones dibujando todo */
  for (nodo=cube_cola, i=0; nodo; nodo=nodo->next, i++) {
    art=(articulacion_t *)nodo->data;
    
    /* Calcular coordenadas de pantalla de la articulacion */
    x=origenx+art->coord.x;
    y=origeny-art->coord.y;
    
    /* Dibujar desde el cursor grafico hasta la articulacion */
    gdk_draw_line(pixmap,pen_red,xc,yc,x,y);
    
    /* Dibujar las articulaciones */
    if (art_activa==i) pen=pen_green;
    else pen=pen_red;
    
    sprintf (cad,"%d",i+1);
    gdk_draw_string(pixmap,font,pen,x-4, y+17,cad);
    gdk_draw_arc (pixmap, pen, TRUE,x-5, y-5, 10,10,0,(360*64));
    
    /* Actualizar cursor grafico */
    xc=x; yc=y;
  }  
}

