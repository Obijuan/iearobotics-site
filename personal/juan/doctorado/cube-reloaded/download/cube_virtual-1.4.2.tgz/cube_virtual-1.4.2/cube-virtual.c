/************************************************************************/
/* cube-virtual.   Juan Gonzalez Gomez.   Sep-2000                      */
/*----------------------------------------------------------------------*/
/* Simulador grafico para CUBE.                                         */
/************************************************************************/

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "gtk/gtk.h"

#include "interface.h"
#include "gtkutils.h"
#include "cube.h"
#include "video.h"
#include "func.h"
#include "vectores.h"
#include "retrollamada.h"

/*---------------------------------------*/
/* Informacion para la ventana de about  */
/*---------------------------------------*/
#define ABOUT_TITULO   "CUBE-VIRTUAL"
#define ABOUT_VERSION  " 1.4.2"
#define ABOUT_DESC     "Simulador virtual para CUBE"
#define ABOUT_URL      "www.iearobotics.com"
#define ABOUT_FECHA    "Mayo 2003"
#define ABOUT_LICENCIA "Licencia GPL, "
#define ABOUT_AUTOR    "Autor: Juan Gonzalez Gomez"
#define ABOUT_EMAIL    "email: juan@iearobotics.com"
#define ABOUT_IEAROBOTICS "IEA ROBOTICS"

#define MAX_ABOUT strlen(ABOUT_TITULO)+strlen(ABOUT_URL)+strlen(ABOUT_FECHA)+\
                  strlen(ABOUT_LICENCIA)+strlen(ABOUT_AUTOR)+strlen(ABOUT_EMAIL)+\
                  strlen(ABOUT_IEAROBOTICS)+strlen(ABOUT_DESC)+strlen(ABOUT_VERSION)+10

/*----------------------------------*/
/* VARIABLES GLOBALES DEL PROGRAMA  */
/*----------------------------------*/
int art_activa=0;
int sentido_act=DERECHA;  /* Sentido de propagacion activo */

/*----------------------------------*/
/* VARIABLES GLOBALES DEL MODULO    */
/*----------------------------------*/
/* Estado del interfaz */
main_state_t main_state;

/* --- Ventana de ok -- */
GtkWidget *ventana_ok;

/* -- Temporizador -- */
static int temporizador;

#define FUNC_F1 0
#define FUNC_F2 1
#define FUNC_F3 2

static double periodo;
/* Funcion de contorno activa */
static int func_act=FUNC_F1;

/* Nombre del fichero de la secuencia a grabar */
static GString *fich;

static FILE *f;
static gboolean grabando=FALSE;

/*-----------------------------------*/
/*     P R O T O T I P O S           */
/*-----------------------------------*/

/*-------------------------------------------*/
/*    F U N C I O N E S    P R I V A D A S   */
/*-------------------------------------------*/

/*-----------------------------*/
/*   GESTION DE SEÃALES        */
/*-----------------------------*/

gint main_destroy(GtkWidget *widget, gpointer gdata)
/************************************************************/
/* Funcion llamada cuando se destruye la ventana principal  */
/************************************************************/
{
  gtk_main_quit();
  
  return (FALSE);
}


/*----------------------------------------*/
/*   FUNCIONES ASOCIADAS A LOS MENUS      */
/*----------------------------------------*/
gint file_quit(GtkWidget *widget, gpointer gdata)
/**********************************************************/
/* Funcion llamada cuando se invoca la opcion file->quit  */
/**********************************************************/
{
  g_print("Terminando..\n");
  gtk_widget_destroy(GTK_WIDGET(main_state.win_main));
  
  return(FALSE);
}


static void obtener_vector(vector_pos_t *v)
/********************************************************************/
/* Obtener un vector de posicion angular a partir del cube virtual  */
/********************************************************************/
{
  int nart;
  int i;
  
  /* Obtener longitud del gusano */
  nart = cube_long_get();
  
  /* Recorrer gusano obteniendo los angulos */
  for (i=1; i<nart-1; i++) {
    v->pos[i-1] = cube_articulacion_get_pos(i);
  }
  
  v->te=0;
  return;
}

static void mostrar_vector_pos(vector_pos_t *v)
/*************************************************/
/* Sacar el vector de posicion en los LCD's      */
/*************************************************/
{
  char cad[20];
  int i;
  
  for (i=0; i<4; i++) {
    sprintf (cad,"%.0f",v->pos[i]);
    gtk_entry_set_text(GTK_ENTRY(main_state.vector_lcd[i]),cad);
  }
  
}

static void obtener_vector_fisico(vector_pos_t *v)
/**************************************************************************/
/* Obtener el vector de posicion angular, con las correcciones aplicadas  */
/**************************************************************************/
{
  vector_pos_t voffset;
  vector_pos_t vsentido;
  
  /* Obtener vector de posicion */
  obtener_vector(v);
  
  v->te = 0;
  voffset.te = 0;
  vsentido.te = 0;
  
  /* Obtener vector de offset */
  voffset.pos[0] = GTK_ADJUSTMENT(main_state.a_adj[0])->value;
  voffset.pos[1] = GTK_ADJUSTMENT(main_state.a_adj[1])->value;
  voffset.pos[2] = GTK_ADJUSTMENT(main_state.a_adj[2])->value;
  voffset.pos[3] = GTK_ADJUSTMENT(main_state.a_adj[3])->value;
  
  /* Obtener vector de sentido */
  vsentido.pos[0] = (GTK_TOGGLE_BUTTON(main_state.sentido[0])->active) ? -1 : 1;
  vsentido.pos[1] = (GTK_TOGGLE_BUTTON(main_state.sentido[1])->active) ? -1 : 1;
  vsentido.pos[2] = (GTK_TOGGLE_BUTTON(main_state.sentido[2])->active) ? -1 : 1;
  vsentido.pos[3] = (GTK_TOGGLE_BUTTON(main_state.sentido[3])->active) ? -1 : 1;
  
  /* Aplicar correccion de offset */
  vector_suma(v,&voffset,v);
  
  /* Aplicar correccion de sentido */
  vector_producto(v,&vsentido,v);
  
}

static void actualizar_lcd()
/*****************************************************************/
/* Leer el estado completo de CUBE VIRTUAL y mostrar los         */
/* datos en los LCD                                               */
/*****************************************************************/
{
  int nart;
  int i;
  double pos;
  double x,y;
  char cad_pos[20];
  char cad_x[20];
  char cad_y[20];
  vector_pos_t v;

  /* Obtener longitud del gusano */
  nart = cube_long_get();
 
  /* Recorrer gusano sacando datos en los LCD's */ 
  for (i=0; i<nart; i++) {
    /* Sacar los angulos */
    pos=cube_articulacion_get_pos(i);
    sprintf (cad_pos,"%.0f",pos);
    gtk_entry_set_text(GTK_ENTRY(main_state.lcd_grados[i]),cad_pos);
    
    /* Sacar coordenadas x,y */
    cube_articulacion_get_xy(i,&x,&y);
    sprintf (cad_x,"%.0f",x);
    sprintf (cad_y,"%.0f",y);
    gtk_entry_set_text(GTK_ENTRY(main_state.lcd_x[i]),cad_x);
    gtk_entry_set_text(GTK_ENTRY(main_state.lcd_y[i]),cad_y);
  }
  
  /* Obtener el vector de posicion corregido */
  obtener_vector_fisico(&v); 
  
  /* Sacar el vector de posicion fisico en los LCD's */
  mostrar_vector_pos(&v);
}

static void leer_art_activa()
/***********************************************************************/
/* Leer la articulacion activa y actualizar el valor del potenciometro */
/***********************************************************************/
{
  double pos;

  /* Obtener posicion actual */
  pos=cube_articulacion_get_pos(art_activa);
        
  /* Poner posicion en el potenciometro */
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.adj1),(gfloat) pos);

}


static void stop(GtkWidget *widget, gpointer data)
/****************************************************/
/* Funcion llamada cuando se aborta la reproduccion */
/****************************************************/
{
  gtk_widget_destroy(ventana_ok);
  gtk_timeout_remove(temporizador);
}

static int reproduciendo()
/*****************************************************************/
/* Funcion llamada periodicamente para realizar la reproduccion  */
/*****************************************************************/
{
  double tiempo;
  vector_pos_t v;
  
  /* Obtener periodo */
  if (func_act==FUNC_F1) periodo = func_periodo_get();
  else periodo=80;
  
  tiempo = GTK_ADJUSTMENT(main_state.time_adj)->value;

  /* Si estamos en modo grabacion */
  if (grabando) {
    obtener_vector_fisico(&v);
    vector_print(&v);
    vector_save(f,&v);
  
    /* Si ha avanzado un periodo terminar */
    if (tiempo==periodo-1) {
      gtk_timeout_remove(temporizador);
      gtk_widget_destroy(ventana_ok);
      fclose(f);
      grabando=FALSE;
      g_print("Fin\n");
    }
  }

  tiempo = (double) ((int)(tiempo+1) % (int)periodo);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.time_adj),tiempo);

  return 1;
}

static void grabar_ok(GtkWidget *widget, gpointer filew)
/*****************************/
/* Grabar en un fichero .f4  */
/*****************************/
{
  gchar *cad;
  
   /* Obtener el nombre del fichero */
  cad = gtk_file_selection_get_filename(GTK_FILE_SELECTION(filew));
  
  /* Asignar el nombre */
  g_string_assign(fich,cad);

  /* Quitar ventana de seleccion de fichero */  
  gtk_widget_destroy(GTK_WIDGET(filew));

  /* Abrir fichero. Si no existe se crea y si existe se borra */
  f=fopen(fich->str,"w");
  if (f==NULL) {
    g_print ("Error\n");
    return;
  }

  grabando=TRUE;

  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(main_state.toggle_enganche),TRUE);
  ventana_ok=gtkutils_dialog_text("Generando secuencias","CUBE-VIRTUAL. GRABANDO");
  
  /* Poner tiempo a cero */
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.time_adj),0);
  
  /* Obtener periodo */
  if (func_act==FUNC_F1) periodo = func_periodo_get();
  else periodo = 80;
  
  temporizador=gtk_timeout_add(10, reproduciendo, NULL);
}

static void grabar()
/***************************************************************************/
/* Funcion de retrollamada del boton de grabar. Se solicita el nombre del  */
/* fichero y se graba                                                      */
/***************************************************************************/
{
  GtkWidget *filew;
  
  filew = gtk_file_selection_new("GRABACION DE SECUENCIA");
  gtk_file_selection_set_filename(GTK_FILE_SELECTION(filew),fich->str);
  gtk_file_selection_hide_fileop_buttons(GTK_FILE_SELECTION(filew));
  
  gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(filew)->cancel_button),
                           "clicked", (GtkSignalFunc) gtk_widget_destroy,
                           GTK_OBJECT(filew));
  gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(filew)->ok_button),"clicked", 
                     GTK_SIGNAL_FUNC(grabar_ok), filew);
  gtk_widget_show(filew);

}


static void play()
/********************************/
/*  Iniciar la reproduccion     */
/********************************/
{
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(main_state.toggle_enganche),TRUE);
  ventana_ok=gtkutils_dialog_ok("PARAR REPRODUCCION","REPRODUCIENDO",FALSE,stop,NULL);
  
  /* Poner tiempo a cero */
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.time_adj),0);
  
  /* Obtener periodo */
  if (func_act==FUNC_F1) periodo = func_periodo_get();
  else periodo = 80;
  
  temporizador=gtk_timeout_add(100, reproduciendo, NULL);
  
}

/*----------------------------------------*/
/* FUNCIONES DE RETROLLAMADA DE BOTONES   */
/*----------------------------------------*/

static void about_ok(GtkWidget *widget, gpointer data)
/****************************************************/
/* Se llama cuando se pulsa el boton de ok de About */
/****************************************************/
{
  gtk_widget_destroy(ventana_ok);
}

void prueba (GtkWidget *widget, gpointer data)
/******************************/
/* Abrir la ventana de ABOUT  */
/******************************/
{
  char mensaje[MAX_ABOUT];
  
  /* Crear el mensaje */
  mensaje[0]=0;
  strcat(mensaje,ABOUT_TITULO);
  strcat(mensaje,ABOUT_VERSION); strcat(mensaje,"\n");
  strcat(mensaje,ABOUT_DESC);   strcat(mensaje,"\n");
  strcat(mensaje,ABOUT_LICENCIA); strcat(mensaje,ABOUT_FECHA);
  strcat(mensaje,"\n"); strcat(mensaje,"\n");
  
  strcat(mensaje,ABOUT_AUTOR);    strcat(mensaje,"\n");
  strcat(mensaje,ABOUT_EMAIL);    strcat(mensaje,"\n");
  strcat(mensaje,ABOUT_IEAROBOTICS); strcat(mensaje,"\n");
  strcat(mensaje,ABOUT_URL);         strcat(mensaje,"\n");
   
  
  ventana_ok=gtkutils_dialog_ok(mensaje,"About cube-virtual",TRUE,about_ok,NULL);
}

void toggle_boton(GtkWidget *widget,gpointer data)
/*************************************************************/
/* FUNCION DE RETROLLAMADA DE BOTONES TOGGLE                 */
/* Se llaman cuando hay un cambio en el estado               */
/*************************************************************/
{
  int n;
  int activo;

  activo = (GTK_TOGGLE_BUTTON(widget)->active);
  
  n=atoi((char *)data);
  switch(n) {
    /*--------------------------------------*/        
    /* Botones de seleccion de articulacion */
    /*--------------------------------------*/        
    case 5:
    case 6: 
    case 7:
    case 8:
    case 9:
    case 10: 
      if (activo) {
        /* Seleccionar articulacion activa */
        art_activa=n-5; 
        
        /* Leer la posicion y mandarla al LCD */
        leer_art_activa();
        
        /* Establecer la artiva en el modulo video */
        video_set_art_activa(art_activa);
      }  
      break;
    /*----------------------------------------*/
    /* BOTONES TOGGLE DE LA BARRA INFERIOR 2  */
    /*----------------------------------------*/
    case 26: if (activo) video_show_ejex(TRUE);
             else video_show_ejex(FALSE);
             break;
    case 27: if (activo) video_show_func(TRUE);
             else video_show_func(FALSE);
             break;
    case 28: if (activo) video_show_cube(TRUE);
             else video_show_cube(FALSE);
             break;
    case 33: if (activo) {
               cube_ajustar(0);
               actualizar_lcd();
             }  
             break;
    case 40: if (activo) {
               sentido_act=IZQUIERDA;
             }
             break;
    case 41: if (activo) {
               sentido_act=DERECHA;
             }
             break;
  }
  video_refrescar();
}

void main_boton(GtkWidget *widget, gpointer data)
/*******************************************************************************/
/* FUNCION DE RETROLLAMADA DE LOS BOTONES NORMALES.                            */
/*                                                                             */
/* Cada boton tiene asociado un numero                                         */
/*  En funcion del boton apretado se llama a la funcion correspondiente        */
/*******************************************************************************/
{
  double x,y;
  double error;
  int n;

  /* Obtener el numero de boton */
  n=atoi((char *)data);
  
  /* Acceder a la funcion correspondiente de cada boton */
  switch (n) {
    /*--------------------------------------*/
    /* Botones de movimiento del origen     */
    /*--------------------------------------*/
    case 1: video_origenx_inc(-5);
            break;
    case 2: video_origenx_inc(5);
            break;
    case 3: video_origeny_inc(-5);
            break;
    case 4: video_origeny_inc(5);
            break;    
    /*-----------------------------------------*/
    /*  BOTONES de desplazamiento de cube      */
    /*-----------------------------------------*/
    case 11: cube_cola_get_xy(&x,&y);
             cube_cola_set_xy(x,y+1);
             break;
    case 12: cube_cola_get_xy(&x,&y);
             cube_cola_set_xy(x,y-1);
             break;
    case 13: cube_cola_get_xy(&x,&y);
             cube_cola_set_xy(x-1,y);
             break;
    case 14: cube_cola_get_xy(&x,&y);
             cube_cola_set_xy(x+1,y);
             break;
    /*--------------------*/
    /*  Boton de Info     */
    /*--------------------*/
    case 15: cube_info_art(art_activa);
             break;
    /*--------------------*/
    /*  Boton de RESET    */
    /*--------------------*/
    case 16: cube_inicializar_gusano();
             break;
    /*----------------------------------*/
    /* BOTONES DE LA BARRA INFERIOR 2   */
    /*----------------------------------*/
    case 20: error = cube_error_get(art_activa);
             printf ("[%d]: %.2f%%\n",art_activa,error);
             break;
    case 21: cube_ajustar_art(art_activa);
             break;
    case 22: cube_rotar_aprox(art_activa);
             break;
    case 23: cube_ajustar(art_activa);
             break;         
             
    /*-----------------------------------*/
    /*  BOTONES DE LA BARRA INFERIOR 3   */ 
    /*-----------------------------------*/        
    case 30: cube_func_contorno_set(func_onda_sinusoidal);
             func_act=FUNC_F1;
             break;
    case 31: cube_func_contorno_set(func_F1);
             func_act=FUNC_F2;
             break;
    case 32: cube_func_contorno_set(func_F2);
             func_act=FUNC_F3;
             break;
             
    /*------------*/
    /* BOTONES    */
    /*------------*/
    case 34: play();
             break;
    case 35: grabar();
             break;
  }
  
  leer_art_activa();
  actualizar_lcd();
  video_refrescar();  
}

void valor_cambiado(GtkWidget *widget, gpointer data)
/************************************************************************/
/* Funcion llamada cuando hay algun cambio en los valores "adjustment"  */
/************************************************************************/
{
  int n;
  double amp;
  double lamda;
  double time;
  double frec;

  /* Obtener el numero asociado al adjustment */
  n=atoi((char *)data);
 
  switch(n) {
    case 1 : amp = (GTK_ADJUSTMENT(widget))->value;
             func_amplitud_set(amp);
             break;
    case 2 : lamda = (GTK_ADJUSTMENT(widget))->value;
             func_long_onda_set(lamda);
             break;
    case 3 : time = (GTK_ADJUSTMENT(widget))->value;
             func_tiempo_set(time);
             break;
    case 4 : frec = (GTK_ADJUSTMENT(widget))->value;
             func_frec_set(frec);
             break;
  }

  if (GTK_TOGGLE_BUTTON(main_state.toggle_enganche)->active) {
    actualizar_lcd();
    cube_ajustar(0);
  }
  video_refrescar();
}

void pot_changed(GtkWidget *widget, gpointer data)
/******************************************************************/
/* Funcion llamada cuando hay algun cambio en los potenciometros  */
/******************************************************************/
{
  int valor;
  char cad[5];

  /* Leer valor del potenciometro y pintarlo en el LCD */
  valor=(int)(GTK_ADJUSTMENT(widget))->value;
  sprintf (cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(main_state.lcd_grados[art_activa]),cad);
  
  /* Situar la articulacion en la nueva posicion */
  cube_articulacion_set_pos(art_activa,valor,sentido_act);

  actualizar_lcd();
  
  /* Pintar */
  video_refrescar();
}

/*-----------------------------------------------------------*/
/*                M  A   I   N                               */
/*-----------------------------------------------------------*/


int main(int argc, char *argv[])
{
  char wd[256];     /* Working Directory */

  gtk_init(&argc,&argv);
  
  /* Inicializar cube */
  cube_init();

  main_state.accel_group=NULL;
  main_state.sugerencias = gtk_tooltips_new();

  /* --- Inicializar estado del programa --- */
  getcwd(wd,256);  /* Leer directorio actual */
  fich=g_string_new(wd);  /* Nombre por defecto del fichero */
  g_string_append(fich,"/noname.f4");
  g_print ("Fichero: %s\n",fich->str);

  create_window1 (&main_state);

  /* Establecer estado inicial de los botones */
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(main_state.toggle_ejex),TRUE);
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(main_state.toggle_func),TRUE);
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(main_state.toggle_cube),TRUE);
  
  /* Establecer parametros iniciales de la onda */
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.amp_adj),20);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.lamda_adj),150);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.time_adj),0);
  gtk_adjustment_set_value(GTK_ADJUSTMENT(main_state.frec_adj),5);

  /* Pintar en los LCD's el estado actual de las articulaciones */
  actualizar_lcd();

  func_act=FUNC_F1;  
  gtk_main();
  
  return 0;
} 

 
