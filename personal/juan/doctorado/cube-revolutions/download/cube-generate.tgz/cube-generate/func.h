/************************************************************************/
/* func.h                                                               */
/*----------------------------------------------------------------------*/
/* Prototipos y definiciones del modulo func.c                          */
/************************************************************************/

#ifndef _FUNC_H
#define _FUNC_H

/************************************/
/* Establecer el parametro amplitud */
/************************************/
void func_amplitud_set(double amp);

/*********************************************/
/* Establecer el parametro longitud de onda  */
/*********************************************/
void func_long_onda_set(double lamda);

/*****************************************/
/* Establecer el tiempo actual           */
/*****************************************/
void func_tiempo_set(double time);

/*****************************************/
/* Establecer el parametro frecuencia    */
/*****************************************/
void func_frec_set(double frecuencia);

/*************************************/
/* Obtener el periodo                */
/*************************************/
double func_periodo_get();

/*******************************************************************/
/*      FUNCIONES DE CONTORNO DEFINIDAS                            */
/*  El parametro tiempo es global para todas                       */
/*  y se establece con la funcion func_tiempo_set()                */
/*******************************************************************/

/*  Funcion sinusoidal                 */
double func_onda_sinusoidal(double x);

/*  Funcion semisinusoidal      */
double func_F1(double x);

/*  Funcion nula                */
double func_nula(double x);

/*  Funcion recta               */
double func_recta(double x);

/*  Funcion ventana             */
double func_ventana(double x);

/*  Funcion para hacer pruebas  */
double func_F2(double x);



#endif
