/************************************************************************/
/* cube-octave.   Juan Gonzalez Gomez.   Marzo-2004                     */
/*----------------------------------------------------------------------*/
/* Ejemplo de visualizacion de Cube Revolutions en Octave               */
/* Generacion de secuencias para CUBE REVOLUTIONS                       */
/*----------------------------------------------------------------------*/
/* LICENCIA GPL                                                         */
/************************************************************************/

#include <stdio.h>
#include <math.h>

#include "cube.h"
#include "func.h"

/*-----------------------------------------------------------*/
/*                M  A   I   N                               */
/*-----------------------------------------------------------*/
int main(void)
{
  
  /* Inicializar cube */
  cube_init();

  /*- Seleccionar una onda sinusoidal  */
  cube_func_contorno_set(func_onda_sinusoidal);
  
  /** Para trabajar con semiondas se descomentaria esto  */
  /*  cube_func_contorno_set(func_F1);                   */
  
  /* Establecer los parametros para esta onda */
  func_long_onda_set(100);
  func_amplitud_set(15);
  func_frec_set(5.0);

  /*-- Ajustar cube a la ONDA --*/
  cube_ajustar(0);
  
  /*-- Sacar los comandos octave para visualizar el gusano */
  /*-- No se visualiza la funcion                          */           
  /*-- El color usado es el rojo                           */
  cube_octave(0,1,1);

  return 0;
}
