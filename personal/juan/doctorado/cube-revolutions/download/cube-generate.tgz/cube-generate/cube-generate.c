/************************************************************************/
/* cube-generate.   Juan Gonzalez Gomez.   Marzo-2004                   */
/*----------------------------------------------------------------------*/
/* Generacion de secuencias para CUBE REVOLUTIONS                       */
/*----------------------------------------------------------------------*/
/* LICENCIA GPL                                                         */
/************************************************************************/

#include <stdio.h>
#include <math.h>

#include "cube.h"
#include "func.h"

/*-------------------------------------------*/
/*    F U N C I O N E S    P R I V A D A S   */
/*-------------------------------------------*/

/*************************************************/
/* Imprimir el vector de estado, en formato .f8  */
/*************************************************/
void print_estado()
{
  int i;
  int ang;

  printf("[");
  for (i=1; i<=8; i++) {
    ang=(int)cube_articulacion_get_pos(i);
    printf ("%d ",ang);
  }
  printf ("],0;\n");
}

/*-----------------------------------------------------------*/
/*                M  A   I   N                               */
/*-----------------------------------------------------------*/
int main(int argc, char *argv[])
{
  double t;
  double T;
  
  /* Inicializar cube */
  cube_init();

  /*- Seleccionar una onda sinusoidal  */
  cube_func_contorno_set(func_onda_sinusoidal);
  
  /** Para trabajar con semiondas se descomentaria esto  */
  /*  cube_func_contorno_set(func_F1);                   */
  
  /* Establecer los parametros para esta onda */
  func_long_onda_set(100);
  func_amplitud_set(15);
  func_frec_set(5.0);

  /* Obtener el periodo de la onda, para saber cuantos instantes */
  /* de tiempo hay que desplazar la onda para la generacion      */
  T=func_periodo_get();

  /* Los ficheros en formato .f8 empiezan asi */
  printf ("NSERVOS=8\n");

  /*-- Generar la secuencia. Se incrementa el tiempo para desplazar la */
  /*-- onda y se "ajusta" el gusano a la onda                          */
  for (t=0; t<T; t++) {
    /*-- Desplazar la onda --*/
    func_tiempo_set(t);
    
    /*- Ajusta gusano a la onda -*/ 
    cube_ajustar(0);
    
    /*- Imprimir vector de posicion angular -*/
    print_estado();
  }
  
  printf ("\n");

  return 0;
}
