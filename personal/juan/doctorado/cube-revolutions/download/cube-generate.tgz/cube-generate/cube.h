/************************************************************************/
/* cube.h                                                               */
/*----------------------------------------------------------------------*/
/* Definiciones y prototipos del modulo cube.c                          */
/************************************************************************/

#ifndef _CUBE_H
#define _CUBE_H

#include "calc.h"

#define DERECHA   1
#define IZQUIERDA 0


/*-------------------------------*/
/*  PROTOTIPOS DEL INTERFAZ      */
/*-------------------------------*/

/*********************************************************************/
/* Inicializacion del modulo de CUBE. Hay que ejecutarlo antes de    */
/* usar cualquier otra funcion.                                      */
/*  Se inicializan todas las estructuras de datos y se genera un     */
/* CUBE apoyado sobre el eje x, con todos su angulos a 0             */
/*********************************************************************/
void cube_init();

/***************************************************************************/
/* Se inicializa a cube, haciendo que se encuentre en posicion horizontal  */
/* con y = 0. Se calculan las coordenadas x,y de cada articulacion en      */
/* funcion de las constantes del gusano                                    */
/* Usar esta funcion siempre que se quiera volver al estado inicial        */
/***************************************************************************/
void cube_reset();

/***************************************************************************/
/* Ajustar cube a la funcion de contorno activa, desde la articulacion     */
/* indicada en adelante.                                                   */
/*                                                                         */
/* Para cada articulacion primero se calcula el angulo de aproximacion y   */
/* luego se aplica el algoritmo de ajuste.                                 */
/***************************************************************************/
void cube_ajustar(int art);

/*********************************************/
/* Establecer la funcion de contorno activa  */
/*********************************************/
void cube_func_contorno_set(double (*func_contorno)(double));

/*******************************************************************/
/* Rotar el gusano entero respecto a la articulacion especificada  */
/* Se actualiza de izquierda a derecha, o de derecha a izda segun  */
/* el valor del parametro sentido.                                 */
/*                                                                 */
/*  ENTRADA:                                                       */
/*    -centro : Articulacion centro                                */
/*    -ang    : Angulo a girar.                                    */
/*    -sentido: Que parte rotar: DERECHA o IZQUIERDA               */
/*                                                                 */
/*  La rotacion SE PROPAGA desde la articulacion centro hasta uno  */
/*  de los extremos.                                               */
/*                                                                 */
/*  El angulo de posicion de la articulacion centro se incrementa  */
/*  (o decrementa) en el angulo rotado.                            */
/*******************************************************************/
void cube_rotar(int centro, int ang, int sentido);

/************************************************/
/* Obtener el numero de articulaciones de Cube  */
/* Se incluyen las articulaciones virtuales, de */
/* cola y cabeza                                */
/************************************************/
int cube_get_nart();

/***********************************************************************/
/* Sacar los comandos necesarios de OCTAVE/MATHLAB para dibujar el     */
/* gusano y la funcion de contorno actual                              */
/* --------------------------------------------------------------------*/
/* ENTRADAS:                                                           */
/*   -func: Si la funcion de contorno se pinta o no (1/0)              */
/*   -gusano: Si el gusano se pinta o no (1/0)                         */
/*   -Color: Color con el que dibujar el gusano                        */
/***********************************************************************/
void cube_octave(int func, int gusano, int color);

/*********************************************************/
/* Devolver informacion sobre la articulacion indicada   */
/* Numero de articulaciones, posicion de cada una y      */
/* angulo que forma con el eje x                         */
/*********************************************************/
void cube_info_art(int num_art);


/************************************************************/
/* Establecer la posicion de una articulacion determinada   */
/*                                                          */
/* ENTRADAS:                                                */
/*   - nart: articulacion centro a rotar.                   */
/*   - pos : angulo de posicion del futaba                  */
/*                                                          */
/* SALIDAS:                                                 */
/*   - El angulo de posicion del servo se establece a pos   */
/*   - Se propaga el cambio desde la articulacion centro    */
/*     hasta un extremo.                                    */
/************************************************************/
void cube_articulacion_set_pos(int art, double pos, int sentido);

/***********************************************************/
/* Leer la posicion de la articulacion especificada        */
/***********************************************************/
double cube_articulacion_get_pos(int art);

/***********************************************************/
/* Establecer las coordenadas x,y de la articulacion       */
/* especificada de CUBE. Automaticamente se re-calculan    */
/* las coordenadas de las demas articulaciones             */
/***********************************************************/
void cube_articulacion_set_xy(int art, double x, double y);

/*************************************************************/
/* Leer las coordenadas x,y de la articulacion especificada  */
/*************************************************************/
void cube_articulacion_get_xy(int art, double *x, double *y);

/************************************************************************/
/* Obtener el angulo que forma una articulacion con el eje x.           */
/*                                                                      */
/* ENTRADA:                                                             */
/*   -num_art : Numero de articulacion                                  */
/*                                                                      */
/* DEVUELVE:                                                            */
/*   - El angulo en radianes                                            */
/************************************************************************/
double cube_articulacion_get_angulo_ejex(int num_art);

/**************************************************************************/
/* Establecer las coordenadas x,y de la cola de cube. Automaticamente se  */
/* re-calculan las coordenadas de las demas articulaciones                */
/**************************************************************************/
void cube_cola_set_xy(double x,double y);

/****************************************************/
/* Obtener las coordenadas x,y de la cola de cube   */
/****************************************************/
void cube_cola_get_xy(double *x,double *y);


#endif // _CUBE_H
