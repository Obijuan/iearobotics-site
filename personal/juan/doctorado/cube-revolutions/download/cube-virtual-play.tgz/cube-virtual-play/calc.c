/************************************************************************/
/* calc.c   Juan Gonzalez Gomez.  Febrero 2004                          */
/*----------------------------------------------------------------------*/
/* Realizar calculos y operaciones con puntos 2D                        */
/************************************************************************/

#include <math.h>
#include "calc.h"


/*****************************************************************************/
/*  Calcular el angulo que forma el segmento que une los dos puntos con la   */
/* horizontal.                                                               */
/*                                                                           */
/*  ENTRADA:                                                                 */
/*    - centro: Uno de los puntos                                            */
/*    - extremo: El otro punto                                               */
/*                                                                           */
/*  DEVUELVE:                                                                */
/*    - El angulo en radianes.                                               */
/*****************************************************************************/
double calc_angulo(calc_punto2d_t centro, calc_punto2d_t extremo)
{
  double ang;
  double xinc,yinc;
  
  /* Calcular angulo inicial y su signo */
  xinc = extremo.x - centro.x;
  yinc = extremo.y - centro.y;
  ang = atan (yinc/xinc);
  
  if (xinc<0)
    ang = ang + M_PI;
    
  return ang;  
}

/************************************************************************/
/* Funcion para rotar el punto extremo a partir del punto centro.       */
/* El valor rotado                                                      */
/* se devuelve en el ultimo parametro.                                  */
/*                                                                      */
/*  ENTRADA:                                                            */
/*    - centro:  coordenadas del punto centro de rotacion               */
/*    - extremo: coordenadas del punto a rotar.                         */
/*    - ang:     Angulo de rotacion, en grados                          */
/*                                                                      */
/*  SALIDA:                                                             */
/*    - rotado:  Coordenadas del punto ya rotado.                       */
/************************************************************************/
void calc_rotar_punto(calc_punto2d_t centro, calc_punto2d_t extremo,
                      double ang, calc_punto2d_t *rotado)
{
  double radio;
  double radianes;
  double ang_ini;
	
  /* Calcular angulo de giro en radianes */
  radianes = TORAD(ang);
  
  /* Calcular angulo inicial  */
  ang_ini = calc_angulo(centro,extremo);
  
  /* Carcular el radio de giro */
  radio = sqrt(pow(centro.x - extremo.x,2) +
          pow(centro.y - extremo.y,2));
          
  /* Calcular las coordenadas del punto rotado */        
  rotado->x=centro.x+radio*cos(radianes+ang_ini);
  rotado->y=centro.y+radio*sin(radianes+ang_ini);
}

/**************************************************************************/
/* Calcular el angulo de aproximacion que debe formar un punto            */
/* con respecto a un punto de rotacion.                                   */
/*                                                                        */
/*  ENTRADA:                                                              */
/*    -centro: Coordenadas del punto respecto del que se rota.            */
/*    -extremo: Punto que se quiere aproximar a la funcion contorno.      */
/*    -func_contorno: Puntero a la funcion de contorno a emplear para la  */
/*                    aproximacion.                                       */
/*                                                                        */
/*  DEVUELVE:                                                             */
/*    -El angulo de aproximacion en radianes                              */
/**************************************************************************/
double calc_angulo_aprox(calc_punto2d_t centro, calc_punto2d_t extremo, 
                          double (*func_contorno)(double))
{
  double ang_aprox;

  /* Obtener angulo de aproximacion en grados */
  ang_aprox = atan( ((*func_contorno)(extremo.x)-centro.y)/(extremo.x-centro.x));
  
  return ang_aprox;
}

/***************************************************************************/
/* Calcular el error de ajuste del punto x con respecto al punto centro y  */
/* la funcion de contorno                                                  */
/*                                                                         */
/* ENTRADAS:                                                               */
/*   - centro : Punto centro de rotacion para realizar el ajuste           */
/*   - x      : Posicion x del punto que se quiere aproximar               */
/*   - func_contorno: Funcion de contorno                                  */
/*   - long_seg: Longitud del segmento que une el centro con el punto a    */
/*               aproximar.                                                */
/***************************************************************************/
double calc_error_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo,
                         double (*funcion)(double))
{
  double F2;
  double error;
  double h;

  /* Funcion de contorno al cuadrado */
  F2 = pow((*funcion)(extremo.x)-centro.y,2);
  
  /* Calcular longitud del segmento */
  h = calc_distancia(centro,extremo);
  
  /* Calcular error normalizado */
  error = (pow(extremo.x-centro.x,2) + F2)/pow(h,2) - 1;

  return ABS(error);
}

/***********************************************************************/
/*  Calcular la distancia entre los dos puntos.                        */
/*                                                                     */
/*  ENTRADAS:                                                          */
/*    - p1 : Un punto                                                  */
/*    - p2 : Otro punto                                                */
/***********************************************************************/
double calc_distancia(calc_punto2d_t p1, calc_punto2d_t p2)
{
  double x2;
  double y2;
  
  x2 = pow(p1.x-p2.x,2);
  y2 = pow(p1.y-p2.y,2);

  return sqrt(x2+y2);
}

/*****************************************************************************/
/* Calcular el angulo que hay que rotar el punto extremo, respecto del       */
/* centro para que se ajuste lo mas posible a la funcion contorno, esto es   */
/* que el error de ajuste se minimice.                                       */ 
/*                                                                           */
/*  ENTRADAS:                                                                */
/*    -centro: Punto centro de rotacion                                      */
/*    -extremo: Coordenadas del punto a ajustar                              */
/*    -func_contorno: Funcion de contorno que se emplea para el ajuste       */
/*                                                                           */
/*  DEVUELVE:                                                                */
/*    - Angulo que hay que rotar el punto extremo, respecto del centro para  */
/*      que se ajuste lo mas posible a la funcion contorno. (EN GRADOS).     */
/*****************************************************************************/
double calc_angulo_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo,
                          double (*func_contorno)(double))
{
  calc_punto2d_t inicial;
  calc_punto2d_t rotado;
  double sentido;
  double error_ini;  /* Error antes de rotar         */
  double error_rot;  /* Error despues de rotar       */
  double teta=0;     /* Angulo acumulado de rotacion */

  /* Almacenar coordenadas del extremo */
  rotado.x = extremo.x;
  rotado.y = extremo.y;
  
  
  /* Realizar iteraciones, aproximando el punto hasta que el error */
  /* deje de decrecer (Hasta alcanzar un minimo local).            */
  /* El angulo acumulado se almacena en teta                       */
  do {
  
    /* Coordenadas iniciales para el paso de aproximacion */
    inicial.x = rotado.x;
    inicial.y = rotado.y;
  
    /* Calcular sentido de aproximacion a la funcion de contorno */
    sentido = (*func_contorno)(inicial.x) - inicial.y;
    sentido = SIGNO(sentido);
  
    /* Calcular el error actual */
    error_ini=calc_error_ajuste(centro,inicial,func_contorno);
    
    /* Rotar */
    calc_rotar_punto(centro,inicial,(sentido)*1,&rotado);
    
    /* Calcular el nuevo error */
    error_rot = calc_error_ajuste(centro,rotado,func_contorno);
    
    /* Se incrementa el angulo a girar solo si se reduce el error */
    if (error_rot<=error_ini) teta+= (sentido)*1;
    
    /* Terminar cuando el error no disminuye */
  } while (error_rot<=error_ini);
  
  /* Devolver el angulo que hay que rotar el punto inicial */
  /* para que se ajuste a la funcion de contorno           */
  return teta;
}
