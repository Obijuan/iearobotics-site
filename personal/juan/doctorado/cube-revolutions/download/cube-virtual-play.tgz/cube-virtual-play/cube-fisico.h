/***************************************************/
/* cube-fisico.h  (c) Juan Gonzalez. Marzo-2004    */
/*-------------------------------------------------*/
/* LICENCIA GPL                                    */
/***************************************************/

#include "vectores.h"

/*--------------------*/
/* DEFINICIONES       */
/*--------------------*/
#define ESTABLE           1
#define INESTABLE_IZDA    3
#define INESTABLE_DECHA   2
#define INESTABLE_UNKNOW  0


/*******************************************************************/
/* Hacer que la articulacion especificada se apoye sobre el eje X  */
/* Todo el gusano se desplaza                                      */
/* Pero el estado sigue siendo el mismo                            */
/* ENTRADAS:                                                       */
/*   art: Numero de articulacion a apoyar en el suelo              */
/*******************************************************************/
void cube_fisico_apoyar_art(int art);

/************************************************************************/
/* Establecer el estado interno del gusano. El criterio tomado es el de */
/* dejar fijada la articulacion de la cola e ir aplicando los angulos   */
/* desde la izquierda hasta la derecha. El gusano que se obtiene esta   */
/* en une estado externo indeterminado: puede no estar apoyado sobre    */
/* el eje X, y ademas seguramente estara en una posicion inestable      */
/************************************************************************/
void cube_fisico_estado_interno_inicial(int a1, int a2, int a3, int a4,
                       int a5, int a6, int a7, int a8);
											 
/*******************************************************************/
/* FUNCION PRINCIPAL!!!. A partir del estado actual del gusano     */
/* y del nuevo estado interno (nuevas posiciones de los servos)    */
/* se calcula el gusano fisico que tiene ese estado, es estable y  */
/* cumple con los criterios de rozamiento establecidos             */
/*******************************************************************/
void cube_fisico_estado_interno_set(int a1, int a2, int a3, int a4,
                                    int a5, int a6, int a7, int a8);

/***************************************************************/
/* Igual que la funcion cube_fisico_estado_interno_set() pero  */
/* pasando como parametro un vector de posicion                */
/***************************************************************/
void cube_fisico_vector_posicionar(vector_pos_t *v);
