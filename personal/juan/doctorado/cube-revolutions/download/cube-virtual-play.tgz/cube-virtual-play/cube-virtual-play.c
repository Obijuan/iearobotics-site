/************************************************************************/
/* cube-virtual-play.   Juan Gonzalez Gomez.   Marzo-2004               */
/*----------------------------------------------------------------------*/
/* Reproduccion de fichero .f8 para el gusano virtual                   */
/*----------------------------------------------------------------------*/
/* LICENCIA GPL                                                         */
/************************************************************************/

#include <stdio.h>
#include <math.h>
#include <unistd.h>

#include "vectores.h"
#include "secuencias.h"
#include "cube-fisico.h"
#include "cube.h"

/*-------------------------------------------*/
/*    F U N C I O N E S    P R I V A D A S   */
/*-------------------------------------------*/

void inicio()
{
  printf ("\n");
  printf ("%%Reproduccion de secuencias para CUBE REVOLUTIONS Virtual\n");
}

/*-----------------------------------------------------------*/
/*                M  A   I   N                               */
/*-----------------------------------------------------------*/
int main(int argc, char *argv[])
{
	FILE *f;
	int tam;
	int i;
	int j;
	vector_pos_t *v;
	vector_pos_t *vini;

	inicio();
	
  /* Abrir el fichero */  
  f = fopen(argv[1],"r");
  if (f==NULL) {
    printf ("%%Error al abrir fichero");
    return 0;
  }
  
  /* Leer los vectores de posicion */
  if (!sec_load_vectores(f)) {
    printf ("%%Fichero NO esta en formato .cube\n");
  }  
  fclose(f);
	
	tam=sec_num_vectores();
	printf ("%%Numero de vectores: %d\n",tam);
  
	//-- Iniciar gusano
	cube_init();
	
	/* Leeer vector inicial */
  vini = sec_get_vector(0);
	cube_fisico_vector_posicionar(vini);
	
  /* Repetir la matriz de movimento unas cuantas veces */
	for (j=0; j<4; j++) {
    
    /* Recorrer la matriz de movimiento */
  	for (i=1; i<tam; i++) {
	  	/* Leer el vector de posicion */
		  v=sec_get_vector(i);
		
		  /* Mover las articulaciones */
		  cube_fisico_vector_posicionar(v);
		
      /* Generar comandos para octave */
		  cube_octave(0,1,3);
	  }
  }
	printf ("pause\n");
  return 0;
}
