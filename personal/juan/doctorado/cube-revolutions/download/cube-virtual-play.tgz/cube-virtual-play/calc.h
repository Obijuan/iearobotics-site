
/************************************************************************/
/* calc.h     Juan Gonzalez Gomez.    Feb-2004                          */
/*----------------------------------------------------------------------*/
/* Definiciones y prototipos del modulo calc.c                          */
/************************************************************************/

#include <math.h>

#ifndef _CALC_H
#define _CALC_H

/*---------------------*/
/*    MACROS           */
/*---------------------*/
/* --- Convertir de radianes a grados --- */
#define TOGRADOS(X) (180 * X)/M_PI

/* --- Convertir de grados a radianes -- */
#define TORAD(X) (M_PI * X)/180

/* --- Devolver el signo de X --- */
#define SIGNO(X) (X>0) ? 1 : -1

/* -- Valor absoluto de X -- */
#define ABS(X) (X>0) ? X : -X

/*----------------------------*/
/*    ESTRUCTURAS DE DATOS    */
/*----------------------------*/

/* Tipo punto en 2D */
typedef struct calc_punto2d_s {
  double x;
  double y;
} calc_punto2d_t;


/*-----------------------*/
/*    PROTOTIPOS         */
/*-----------------------*/

/*****************************************************************************/
/*  Calcular el angulo que forma el segmento que une los dos puntos con la   */
/* horizontal.                                                               */
/*                                                                           */
/*  ENTRADA:                                                                 */
/*    - centro: Uno de los puntos                                            */
/*    - extremo: El otro punto                                               */
/*                                                                           */
/*  DEVUELVE:                                                                */
/*    - El angulo en radianes.                                               */
/*****************************************************************************/
double calc_angulo(calc_punto2d_t centro, calc_punto2d_t extremo);

/************************************************************************/
/* Funcion para rotar el punto extremo a partir del punto centro.       */
/* El valor rotado                                                      */
/* se devuelve en el ultimo parametro.                                  */
/*                                                                      */
/*  ENTRADA:                                                            */
/*    - centro:  coordenadas del punto centro de rotacion               */
/*    - extremo: coordenadas del punto a rotar.                         */
/*    - ang:     Angulo de rotacion, en grados                          */
/*                                                                      */
/*  SALIDA:                                                             */
/*    - rotado:  Coordenadas del punto ya rotado.                       */
/************************************************************************/
void calc_rotar_punto(calc_punto2d_t centro, calc_punto2d_t extremo,
                      double ang, calc_punto2d_t *rotado);


/**************************************************************************/
/* Calcular el angulo de aproximacion que debe formar un punto            */
/* con respecto a un punto de rotacion.                                   */
/*                                                                        */
/*  ENTRADA:                                                              */
/*    -centro: Coordenadas del punto respecto del que se rota.            */
/*    -extremo: Punto que se quiere aproximar a la funcion contorno.      */
/*    -func_contorno: Puntero a la funcion de contorno a emplear para la  */
/*                    aproximacion.                                       */
/*                                                                        */
/*  DEVUELVE:                                                             */
/*    -El angulo de aproximacion en radianes                              */
/**************************************************************************/
double calc_angulo_aprox(calc_punto2d_t centro, calc_punto2d_t extremo, 
                          double (*func_contorno)(double));


/***************************************************************************/
/* Calcular el error de ajuste del punto x con respecto al punto centro y  */
/* la funcion de contorno                                                  */
/*                                                                         */
/* ENTRADAS:                                                               */
/*   - centro : Punto centro de rotacion para realizar el ajuste           */
/*   - x      : Posicion x del punto que se quiere aproximar               */
/*   - func_contorno: Funcion de contorno                                  */
/*   - long_seg: Longitud del segmento que une el centro con el punto a    */
/*               aproximar.                                                */
/***************************************************************************/
double calc_error_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo,
                         double (*funcion)(double));

/***********************************************************************/
/*  Calcular la distancia entre los dos puntos.                        */
/*                                                                     */
/*  ENTRADAS:                                                          */
/*    - p1 : Un punto                                                  */
/*    - p2 : Otro punto                                                */
/***********************************************************************/
double calc_distancia(calc_punto2d_t p1, calc_punto2d_t p2);

/*****************************************************************************/
/* Calcular el angulo que hay que rotar el punto extremo, respecto del       */
/* centro para que se ajuste lo mas posible a la funcion contorno, esto es   */
/* que el error de ajuste se minimice.                                       */ 
/*                                                                           */
/*  ENTRADAS:                                                                */
/*    -centro: Punto centro de rotacion                                      */
/*    -extremo: Coordenadas del punto a ajustar                              */
/*    -func_contorno: Funcion de contorno que se emplea para el ajuste       */
/*                                                                           */
/*  DEVUELVE:                                                                */
/*    - Angulo que hay que rotar el punto extremo, respecto del centro para  */
/*      que se ajuste lo mas posible a la funcion contorno. (EN GRADOS).     */
/*****************************************************************************/
double calc_angulo_ajuste(calc_punto2d_t centro, calc_punto2d_t extremo,
                          double (*func_contorno)(double));


#endif  /* _CALC_H */
