/**************************************************************/
/* cube-fisico.c  (c) Juan Gonzalez. Marzo-2004               */
/*------------------------------------------------------------*/
/* Rutinas para realizar calculos sobre el modelo fisico de   */
/* CUBE                                                       */
/*------------------------------------------------------------*/
/* LICENCIA GPL                                               */
/**************************************************************/

#include <stdio.h>

#include "vectores.h"
#include "cube.h"
#include "cube-fisico.h"

/************************************************************************/
/* Establecer el estado interno del gusano. El criterio tomado es el de */
/* dejar fijada la articulacion de la cola e ir aplicando los angulos   */
/* desde la izquierda hasta la derecha. El gusano que se obtiene esta   */
/* en une estado externo indeterminado: puede no estar apoyado sobre    */
/* el eje X, y ademas seguramente estara en una posicion inestable      */
/************************************************************************/
void cube_fisico_estado_interno_inicial(int a1, int a2, int a3, int a4,
                       int a5, int a6, int a7, int a8)
{
	cube_articulacion_set_pos(1, a1, DERECHA);
	cube_articulacion_set_pos(2, a2, DERECHA);
	cube_articulacion_set_pos(3, a3, DERECHA);
	cube_articulacion_set_pos(4, a4, DERECHA);
	cube_articulacion_set_pos(5, a5, DERECHA);
	cube_articulacion_set_pos(6, a6, DERECHA);
	cube_articulacion_set_pos(7, a7, DERECHA);
	cube_articulacion_set_pos(8, a8, DERECHA);
}

/*******************************************************************/
/* Hacer que la articulacion especificada se apoye sobre el eje X  */
/* Todo el gusano se desplaza                                      */
/* Pero el estado sigue siendo el mismo                            */
/* ENTRADAS:                                                       */
/*   art: Numero de articulacion a apoyar en el suelo              */
/*******************************************************************/
void cube_fisico_apoyar_art(int art)
{
	double x,y;
	
	//-- Obtener las coordenada x,y de la articulacion
	cube_articulacion_get_xy(art, &x, &y);
	
	//-- Situarla con y=0
	cube_articulacion_set_xy(art, x, 0.0);
	
}

/****************************************************************/
/* Modificar estado externo para que al menos haya un punto de  */
/* apoyo. El criterio seguido es calcular la coordenada Y minima*/
/* partiendo de la cola del gusano. En caso de que haya dos     */
/* articulaciones con la mismo Y, se tomara la situada mas      */
/* cerca de la cola (la mas izquierda)                          */
/* DEVUELVE:                                                    */
/*   -La articulacion apoyada sobre el eje X                    */
/****************************************************************/
int cube_fisico_estabilizar1()
{
	int art_ymin;
	
	//-- Obtener la articulacion con la Y minima, partiendo de la cola
	//-- hacia la izquierda
	art_ymin=cube_art_ymin(0,DERECHA);
	
	//-- Apoyarla sobre el eje X
	cube_fisico_apoyar_art(art_ymin);
	
	return art_ymin;
}

/*******************************************************/
/* Calcular si el sistema actual es estable. No se     */
/* modifica ninguno de sus parametros.                 */
/* SALIDA:                                             */
/*    zi: Articulacion que hace de zapato izquierdo    */
/*    zd: Articulacion que hace de zapato derecho      */
/*     Si el sistema tiene un unico punto de apoyo     */
/*     entonces zi=zd                                  */
/* DEVUELVE:                                           */
/*    1 : Es estable                                   */
/*    2 : Es inestable por la derecha                  */
/*    3 : Es inestable por la izquierda                */
/*    0 : Problemas!! Como por ejemplo que no se ha    */
/*        encontrado ningun zapato. En cuaquier caso   */
/*        el sistema es inestable                      */
/*******************************************************/
int cube_fisico_analizar_estabilidad(int *zi, int *zd)
{
	double xg,yg;
	double xzi,yzi;
	double xzd,yzd;
	int zap_izdo;
	int zap_decho;
	int nzap;
	
	//-- Calcular el centro de masas
	cube_centro_masas(&xg,&yg);
	
	//-- Obtener los zapatos
	nzap=cube_get_art_zapato(&zap_izdo,&zap_decho);
	printf ("%%Numero de zapatos: %d\n",nzap);
	printf ("%%Zap. Izdo: %d\n",zap_izdo);
	printf ("%%Zap. Decho: %d\n",zap_decho);
	
	//--- Ahora analizamos la estabilidad. Hay varios casos
	//CASO 1: No hay zapatos. El sistema esta en el aire--> Inestable
	if (nzap==0) {  
		*zi=*zd=-1;
		return INESTABLE_UNKNOW;
	}
	
	//-- CASO 2: Solo hay un punto de apoyo. El sistema es inestable, pero
	//-- puede serlo por la derecha o por la izquierda
	if (nzap==1) {
		*zi=zap_izdo;
		*zd=zap_decho;
		
		//-- Obtener las coordenadas de la articulacion
		cube_articulacion_get_xy(zap_izdo,&xzi,&yzi);
		
		//-- Comparar la x del zapato con la x del centro de masas
		if (xg<=xzi) {
			//-- Inestable por la izquierda
			return INESTABLE_IZDA;
		}

		//-- Inestable por la derecha
		return INESTABLE_DECHA;
	}

  //-- Hay dos zapatos. Devolverlos	
	*zi=zap_izdo;
	*zd=zap_decho;
	
	//-- Obtener las coordenadas de los zapatos
  cube_articulacion_get_xy(zap_izdo, &xzi,&yzi);
	cube_articulacion_get_xy(zap_decho,&xzd,&yzd);
	
	//-- CASO 3: Dos zapatos. El centro de gravedad esta dentro del 
	//-- segmento de apoyo
	if (xg>=xzi && xg<=xzd) {
		return ESTABLE;
	}
	
	//-- CASO 4: Dos zapatos, pero el centro de gravedad esta fuera del
	//-- segmento de apoyo--> SISTEMA INESTABLE
	
	//-- Inestable por la izquierda
	if (xg<xzi) {
		return INESTABLE_IZDA;
	}
	
	//-- Si no lo es por la izquierda lo es por la derecha
	return INESTABLE_DECHA;
}

/*************************************************************/
/* Funcion de depuracion. Imprimir por pantalla              */
/* la estabilidad del sistema. Hay que llamarla              */
/* despues de la funcion cube_fisico_analizar_estabilidad()  */
/* ENTRADAS:                                                 */
/*   -estado: El estado de la estabilidad                    */
/*   -zi,zd : Zapatos izquiedo y derecho                     */
/*************************************************************/
void cube_fisico_print_estabilidad(int estado, int zi, int zd)
{
	printf ("%%----------------------------------------\n");
	printf ("%% ESTADO DEL SISTEMA: \n");
	switch(estado)
	{
		case 0: 
			printf ("%% INESTABLE. No tiene zapatos\n");
		  break;
		case 1:
			printf ("%% ESTABLE\n");
		  printf ("%% Zapatos: (%d,%d)\n",zi,zd);
		  break;
		case 2:
			printf ("%% INESTABLE POR LA DERECHA\n");
		  printf ("%% Zapatos: (%d,%d)\n",zi,zd);
		  break;
		case 3: 
			printf ("%% INESTABLE POR LA IZQUIERDA\n");
		  printf ("%% Zapatos: (%d,%d)\n",zi,zd);
		  break;
	}
	printf ("%%-----------------------------------------\n");
}


/****************************************************************/
/* Estabilizar el sistema desde la articulacion indicada segun  */
/* el sentido especificado                                      */
/* El sistema se rota hacia la el sentido indicado hasta que    */
/* alguna otra articulacion se apoye en el suelo                */
/* NOTA: La articulacion pasada debe estar apoyada              */
/****************************************************************/
void cube_fisico_estabilizar_art(int art, int sentido)
{
	double ang;
	double ang_min;
	int i;
	
	//-- Calcular la articulacion con menor angulo de caida
	for (i=art+1; i<=9; i++) {
	  ang=cube_angulo_caida(art,i);
	}	
	
	ang_min=cube_ang_caida_min(art,sentido);
	
	//-- Rotar a cube hasta que la articulacion con menor angulo 
	//-- de caida se apoye en el suelo
	cube_girar(art,ang_min, sentido);
}


/*******************************************************************/
/* FUNCION PRINCIPAL!!!. A partir del estado actual del gusano     */
/* y del nuevo estado interno (nuevas posiciones de los servos)    */
/* se calcula el gusano fisico que tiene ese estado, es estable y  */
/* cumple con los criterios de rozamiento establecidos             */
/*******************************************************************/
void cube_fisico_estado_interno_set(int a1, int a2, int a3, int a4,
                                    int a5, int a6, int a7, int a8)
{
	int art_ymin;
	int estado;
	int zi,zd;
	double xzi_old;
	double yzi_old;
	
	//-- Obtener copia del gusano actual
	cube_copiar();
	
	//-- Establecer el estado interno. Se obtiene un cube fisico con un 
	//-- estado externo indeterminado
	cube_fisico_estado_interno_inicial(a1,a2,a3,a4,a5,a6,a7,a8);
	
	//-- @@@ Debug
	//cube_octave(0,1,2);
	
	//-- Encontrar un estado externo en el que al menos haya un punto de 
	//-- de apoyo sobre el eje X
	art_ymin=cube_fisico_estabilizar1();
	
	//------------------------------
	//-- Estabilizar el sistema
	//------------------------------
	do {
	  //-- Analizar la estabilidad del sistema
	  estado=cube_fisico_analizar_estabilidad(&zi, &zd);
	  cube_fisico_print_estabilidad(estado,zi,zd);

		//-- Si no es estable, hay que modificar su estado externo
		switch(estado) {
			case ESTABLE:  //-- Estable: no se hace nada
				break;
			case INESTABLE_UNKNOW:  //-- No se sabe que hacer...
				printf ("#PANIC!!\n");
				break;
			case INESTABLE_IZDA:  //-- El sistema tiende a caer hacia la izquierda
				//-- Estabilizar el sistema a partir del zapato izquierdo
			  cube_fisico_estabilizar_art(zi, IZQUIERDA);
			  break;
			case INESTABLE_DECHA: //-- El sistema tiende a caer hacia la derecha
				//-- Estabilizar el sistema a partir del zapato derecho
			  cube_fisico_estabilizar_art(zd, DERECHA);
			  break;
		}
	} while (estado!=ESTABLE);	
	
	//-- El sistema es estable
	//-- @@@ Debug
	//cube_octave(0,1,3);
	
	//-- Establecer la coordenada x de los zapatos en funcion del gusano
	//-- del estado anterior y del modelo de rozamiento con el suelo que
	//-- se quiere
	
	//-- Criterio 1: El zapato izquierdo se queda en la misma posicion que
	//-- tenia en el estado anterior
	
	//-- Obtener coordenadas x,y del zapato izdo del estado anterior
	cube_copia_articulacion_get_xy(zi, &xzi_old, &yzi_old);
	
	//-- Situar el zapato izquierdo en esa posicion
	cube_articulacion_set_xy(zi,xzi_old,0.0);
  
}
 
void cube_fisico_vector_posicionar(vector_pos_t *v)
/********************************************************/
/* Enviar el vector de posicion al cube fisico virtual  */
/********************************************************/
{
	int a1,a2,a3,a4,a5,a6,a7,a8;
	
	a1=(int)(v->pos[0]);
	a2=(int)(v->pos[1]);
	a3=(int)(v->pos[2]);
	a4=(int)(v->pos[3]);
	a5=(int)(v->pos[4]);
	a6=(int)(v->pos[5]);
	a7=(int)(v->pos[6]);
	a8=(int)(v->pos[7]);
	
	cube_fisico_estado_interno_set(a1,a2,a3,a4,a5,a6,a7,a8);
}
