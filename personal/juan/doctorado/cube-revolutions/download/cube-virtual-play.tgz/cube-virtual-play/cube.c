/************************************************************************/
/* cube.c     Juan Gonzalez Gomez.  Feb-2004                            */
/*----------------------------------------------------------------------*/
/* Modulo de manipulacion de cube                                       */
/************************************************************************/

#include <math.h>
#include <stdio.h>
#include <string.h>

#include "cube.h"
#include "func.h"
#include "calc.h"

/*--------------------------------------------------------------------------*/
/* Modelo mecanico. Se considera que cada articulacion tiene dos segmentos  */
/* cada uno de distancia LSEG. La longitud total de cada modulo, cuando     */
/* el angulo es 0 es de 2*LSEG.                                             */
/*--------------------------------------------------------------------------*/

/*******************/
/* DEFINICIONES    */
/*******************/
#define SERVOS 8       // Numero de SERVOS en el gusano
#define LSEG  15       // Longitud de cada segmento del modulo

//-- No modificables directamente por el usuario

#define NART SERVOS+2  // Numero de articulaciones (Los extremos cuentan)
#define LAST NART-1    // Indice a la ultima articulacion (Cabeza)
#define COLA 0         // La cola del gusano

/*****************************/
/* TIPOS DE DATOS PRIVADOS   */
/*****************************/

/* Tipo articulacion */
typedef struct articulacion_s {
  int fi;               /* Angulo de posicion del servo, en grados  */
  calc_punto2d_t coord; /* Coordenadas x,y del eje de salida        */
  int  sentido;         /* Sentido del servo. Como esta colocado    */
} articulacion_t;

/***************************/
/* VARIABLES DEL MODULO    */
/***************************/
static articulacion_t cube[NART];
static articulacion_t cube_copy[NART];
static double (*func_act)(double); // Puntero a la funcion de contorno activa 

/****************************************************************/
/*                FUNCIONES PRIVADAS                            */
/****************************************************************/

static void set_art(articulacion_t *art,int fi, 
                         double x, double y, int sentido)
/***********************************************************************/
/* Dar valores a una articulacion. Simplemente se rellenan los campos, */
/* pero no se realizan rotaciones ni nada por el estilo. La mision de  */
/* esta funcion es dar unos valores iniciales.                         */
/*                                                                     */
/* ENTRADAS:                                                           */
/*   - art: Puntero a la articulacion a rellenar con datos.            */
/*   - fi: Angulo de posicion del servo                                */
/*   - x,y: Coordenadas x,y del servo                                  */
/*   - sentido: Sentido de colocacion del servo                        */
/***********************************************************************/
{
  /* Asignar valores */
  art->fi=fi;
  art->coord.x=x;
  art->coord.y=y;
  art->sentido=sentido;
}

static void rotar_art(int centro, int extremo, double ang)
/******************************************************************/
/* Rotar una articulacion con respecto a otra.                    */
/*                                                                */
/* ENTRADA:                                                       */
/*   - centro : Numero de articulacion respecto de la que se va   */
/*               a rotar.                                         */
/*   - extremo: Rotacion a girar                                  */
/*   - ang    : Angulo a rotar (en grados)                        */
/*                                                                */
/* Se actualiza la posicion de la articulacion extremo en funcion */
/* del angulo de posicion (fi) de la articulacion centro          */
/*                                                                */
/* Esta funcion NO PROPAGA la rotacion.                           */
/*                                                                */
/* La articulacion que hace de centro NO ES modificada            */
/******************************************************************/
{
  articulacion_t *art_centro;
  articulacion_t *art_extremo;

  /* Obtener articulacion centro y extremo */  
  art_centro=&(cube[centro]);
  art_extremo=&(cube[extremo]);
  
  /* Realizar la rotacion y actualizar las coordenadas de la articulacion */
  /* extremo.                                                             */
  calc_rotar_punto(cube[centro].coord, cube[extremo].coord,
	ang, &(cube[extremo].coord));
}

static double error_aprox_get(int art)
/***********************************************************************/
/*  Devolver el error de aproximacion de la articulacion especificada  */
/* Se devuelve el error multiplicado por 100                           */
/***********************************************************************/
{
  double error;
	int centro;

  if (art==0) return 0.0;

  /* Obtener articulacion centro */
	centro=art-1;
	
  /* Calcular error de ajuste */    
  error=calc_error_ajuste(cube[centro].coord,cube[art].coord,func_act);
  
  return error*100.00;
}

static void cube_rotar_aprox(int art)
/***************************************************************************/
/* Situar la articulacion especificada en el angulo de aproximacion        */
/* La rotacion se "propaga" de izquierda a derecha                         */
/*                                                                         */
/* SOLO SE HACE UNA ITERACION                                              */
/*                                                                         */
/* ENTRADA:                                                                */
/*   -art : Numero de articulacion sobre la que actuar.                    */
/*                                                                         */
/* SALIDA:                                                                 */
/*  - Se actualizan las coordenadas desde la articulacion pasada como      */
/*    argumento hasta un extremo.                                          */
/*  - Se actualiza el angulo de posicion de la articulacion centro         */
/***************************************************************************/
{
  double ang_aprox;
  double ang_actual;
	int centro;
  
	//-- Hacer el cado nart=0
  if (art==0) return;

  /* Obtener articulacion centro */
	centro=art-1;
  
  /* Obtener angulo de aproximacion */
  ang_aprox = calc_angulo_aprox(cube[centro].coord,cube[art].coord,func_act);
  ang_aprox = TOGRADOS(ang_aprox);
  
  /* Obtener el angulo actual que forma la articulacion con la horizontal */
  ang_actual = calc_angulo(cube[centro].coord,cube[art].coord);
  ang_actual = TOGRADOS(ang_actual);
  
  /* Colocar la articulacion en el angulo de aproximacion y propagar */
  /* la rotacion.                                                    */
  cube_rotar(art-1,ang_aprox-ang_actual,DERECHA);
}

static void cube_rotar_aprox_rep(int art)
/********************************************************************/
/* Funcion similar a cube_rotar_aprox(), pero se realizan varias    */
/* iteraciones, para que la articulacion se aproxime mas a la       */
/* funcion de contorno                                              */
/********************************************************************/
{
  double error_ini;
  double error_fin;
  int ciclos=0;
  
  /* Situar cube en el angulo de aproximacion inicial */
  cube_rotar_aprox(art);
    
  ciclos=0;
  /* Realizar algunas iteraciones sobre el angulo de aproximacion */
  do {
    error_ini = error_aprox_get(art);
    cube_rotar_aprox(art);
    error_fin = error_aprox_get(art);
    ciclos++;
  } while (error_fin<error_ini && ciclos<5);
  
}

static void cube_ajustar_art(int num_art)
/****************************************************************************/
/* Aplicar el algoritmo de ajuste a la articulacion especificada, respecto  */
/* de la funcion de contorno activa.                                        */
/*                                                                          */
/*  Se aplica el algoritmo sobre la articulacion SIN CALCULAR EL ANGULO     */
/*  DE APROXIMACION.                                                        */
/*                                                                          */
/*  ENTRADA:                                                                */
/*    -Numero de articulacion sobre la que aplicar el algoritmo             */
/*    -La variable global func_act debe apuntar a la funcion de contorno    */
/*                                                                          */
/*  SALIDA:                                                                 */
/*    -Se calcula la nueva posicion ajustada y se PROPAGA a un extremo      */
/*    -Se modifica el angulo de posicion de la articulacion centro          */
/****************************************************************************/
{
  double teta;
	int centro;

	//-- DEBUG: La articulacion 0 se ajusta haciendo que su Y
	//-- sea la misma que la de la funcion...
  /* La articulacion 0 no se puede ajustar hacia la derecha */
  if (num_art==0) return;
  
  /* Acceder a la articulacion centro */
	centro=num_art-1;

  /* Calcular el angulo de ajuste */
  teta = calc_angulo_ajuste(cube[centro].coord,cube[num_art].coord,func_act);
  
  /* Rotar la articulacion extremo para ajustarla */
  cube_rotar(centro,teta,DERECHA);
}



/***************************************************************/
/*                FUNCIONES DE INTERFAZ                        */
/***************************************************************/

/***************************************************************************/
/* Se inicializa a cube, haciendo que se encuentre en posicion horizontal  */
/* con y = 0. Se calculan las coordenadas x,y de cada articulacion en      */
/* funcion de las constantes del gusano                                    */
/* Usar esta funcion siempre que se quiera volver al estado inicial        */
/***************************************************************************/
void cube_reset()
{
	int i;
	double xant=0;  /* Coordenada x del extremo derecho del modulo anterior  */
	
	//-- Inicializar la primera articulacion (de la cola) que es virtual 
	set_art(&(cube[0]),0,0,0,0);
	
	/* Recorrer la lista inicializando las articulaciones */  
  for (i=1; i<NART; i++) {
		
		if (i==(LAST)) { /* Si es la cabeza (articulacion virtual */
			set_art(&(cube[i]),0,xant,0,0);  // Se coloca en el extremo
		}
		else {
			/* Dar valores a los parametros de la articulacion actual*/
		  set_art(&(cube[i]),0,xant+LSEG,0,0);
		
		  /* Establecer la nueva coordenada x del extremo derecho del modulo */
		  xant=(xant+LSEG+LSEG);
		}
  }
}

/*********************************************************************/
/* Inicializacion del modulo de CUBE. Hay que ejecutarlo antes de    */
/* usar cualquier otra funcion.                                      */
/*  Se inicializan todas las estructuras de datos y se genera un     */
/* CUBE apoyado sobre el eje x, con todos su angulos a 0             */
/*********************************************************************/
void cube_init()
{
	int i;
	
	/* Inicializar todas las articulaciones */
	for (i=0; i<NART; i++) {
		set_art(&(cube[i]),0,0,0,0);
	}
  
  /* Inicializar articulaciones */
  cube_reset();
  
  /* Establecer la funcion de contorno activa */
	func_act=func_onda_sinusoidal;
	
}

/*******************************************************************/
/* Rotar el gusano entero respecto a la articulacion especificada  */
/* Se actualiza de izquierda a derecha, o de derecha a izda segun  */
/* el valor del parametro sentido.                                 */
/*                                                                 */
/*  ENTRADA:                                                       */
/*    -centro : Articulacion centro                                */
/*    -ang    : Angulo a girar.                                    */
/*    -sentido: Que parte rotar: DERECHA o IZQUIERDA               */
/*                                                                 */
/*  La rotacion SE PROPAGA desde la articulacion centro hasta uno  */
/*  de los extremos.                                               */
/*                                                                 */
/*  El angulo de posicion de la articulacion centro se incrementa  */
/*  (o decrementa) en el angulo rotado.                            */
/*******************************************************************/
void cube_rotar(int centro, int ang, int sentido)
{
  int i;

  /* Modificar el angulo de posicion de la articulacion */
	cube[centro].fi=(cube[centro].fi + ang) % 360;
  
  /* ¡¡RESTRICCION!! El angulo de posicion debe estar comprendido */
  /* entre -90 y 90 grados. Si se sobrepasa hay que recortar      */
  
  if (cube[centro].fi>90) {
    /* Calcular angulo de giro para que no se sobrepasen los 90 grados */
    ang -= (cube[centro].fi - 90);
    cube[centro].fi=90;
  }  
  if (cube[centro].fi<-90) {
    /* Calcular angulo de giro para no sobrepasar los -90 grados */
    ang += (ABS(cube[centro].fi) - 90);
    cube[centro].fi=-90;
  }  
  
  /* Determinar el sentido de rotacion */
  
  if (sentido==DERECHA) {
    /* Actualizar desde el centro a la derecha */
    for (i=centro+1; i<NART; i++) 
      rotar_art(centro,i,(double)ang);
  }
  else {
    /* Actualizar desde centro a la izquierda */
    for (i=centro-1; i>=0; i--) {
      rotar_art(centro,i,(double)-ang);
    }  
  }    
}

/***************************************************************************/
/* Ajustar cube a la funcion de contorno activa, desde la articulacion     */
/* indicada en adelante.                                                   */
/*                                                                         */
/* Para cada articulacion primero se calcula el angulo de aproximacion y   */
/* luego se aplica el algoritmo de ajuste.                                 */
/***************************************************************************/
void cube_ajustar(int art)
{
  double x,y;
  int i;

  /* Si la articulacion activa es la cola, hay que situarla sobre la  */
  /* funcion de contorno                                              */
  if (art==0) {
    /* Obtener coordenadas, x,y de la cola */
    cube_cola_get_xy(&x,&y);
  
    /* Obtener la coordenada y de la funcion de contorno */
    y = func_act(x);
    
    /* Situar la cola en la funcion de contorno */
    cube_cola_set_xy(x,y);
    
    /* Ajustar a partir de la articulacion 1 hacia la derecha */
    art=1;
  }  

  /* Recorrer las articulaciones desde la activa hasta la DERECHA */
  /* y se van ajustando a la funcion de contorno activa           */
  for (i=art; i<NART; i++) {
  
    /* Situar articulacion en angulo de aproximacion */
    /* Se hacen varias iteraciones para que converja */
    /* mas rapido                                    */
    cube_rotar_aprox_rep(i);
    
    /* Ajustar la articulacion */
    cube_ajustar_art(i);
  }
}

/************************************************/
/* Obtener el numero de articulaciones de Cube  */
/* Se incluyen las articulaciones virtuales, de */
/* cola y cabeza                                */
/************************************************/
int cube_get_nart()
{
	return NART;
}

/************************************************************/
/* Establecer la posicion de una articulacion determinada   */
/*                                                          */
/* ENTRADAS:                                                */
/*   - nart: articulacion centro a rotar.                   */
/*   - pos : angulo de posicion del futaba                  */
/*                                                          */
/* SALIDAS:                                                 */
/*   - El angulo de posicion del servo se establece a pos   */
/*   - Se propaga el cambio desde la articulacion centro    */
/*     hasta un extremo.                                    */
/************************************************************/
void cube_articulacion_set_pos(int art, double pos, int sentido)
{
  double fi_actual;
  
  /* Obtener la posicion actual */
  fi_actual=cube[art].fi;
  
  /* Rotar la articulacion de manera que se traslade desde la posicion  */
  /* en la que esta ahora hasta la indicada.                            */
  cube_rotar(art,pos-fi_actual,sentido);
}

/***********************************************************/
/* Leer la posicion de la articulacion especificada        */
/***********************************************************/
double cube_articulacion_get_pos(int art)
{ 
  /* Devolver la posicion */
  return cube[art].fi;
}

/*************************************************************/
/* Leer las coordenadas x,y de la articulacion especificada  */
/*************************************************************/
void cube_articulacion_get_xy(int art, double *x, double *y)
{ 
  *x=cube[art].coord.x;
  *y=cube[art].coord.y;
}

/********************************************************/
/* Leer las coordenadas x,y de la articulacion de la    */
/* copia de cube                                        */
/********************************************************/
void cube_copia_articulacion_get_xy(int art, double *x, double *y)
{
	*x=cube_copy[art].coord.x;
	*y=cube_copy[art].coord.y;
}

/************************************************************************/
/* Obtener el angulo que forma una articulacion con el eje x.           */
/*                                                                      */
/* ENTRADA:                                                             */
/*   -num_art : Numero de articulacion                                  */
/*                                                                      */
/* DEVUELVE:                                                            */
/*   - El angulo en radianes                                            */
/************************************************************************/
double cube_articulacion_get_angulo_ejex(int num_art)
{
  int centro;
	
  if (num_art==0) return 0;
   
  /* Obtener la articulacion centro */
  centro=num_art-1;
  
  /* Calcular el angulo */
  return calc_angulo(cube[centro].coord,cube[num_art].coord);
}

/*********************************************************/
/* Devolver informacion sobre la articulacion indicada   */
/*********************************************************/
void cube_info_art(int num_art)
{
  double ang_ini;
  
  /* Imprimir informacion */
  printf ("[%d] (%.3f,%.3f) pos: %d\n",num_art,cube[num_art].coord.x,
	        cube[num_art].coord.y,cube[num_art].fi);
  ang_ini = cube_articulacion_get_angulo_ejex(num_art);
  ang_ini = TOGRADOS(ang_ini);
  printf ("     Angulo con eje x: %.3f\n",ang_ini);
}


/***********************************************************/
/* Establecer las coordenadas x,y de la articulacion       */
/* especificada de CUBE. Automaticamente se re-calculan    */
/* las coordenadas de las demas articulaciones             */
/***********************************************************/
void cube_articulacion_set_xy(int art, double x, double y)
{
	double xinc;
	double yinc;
	int i;
	
	/* Calcular los incrementos a aplicar */
	xinc = x - cube[art].coord.x;
	yinc = y - cube[art].coord.y;
	
	/* Recalcular las coordenadas de las articulaciones */
  for (i=COLA; i<=LAST; i++) {
    /* Aplicar incremento */
    cube[i].coord.x+=xinc;
    cube[i].coord.y+=yinc;
  }
}

/**************************************************************************/
/* Establecer las coordenadas x,y de la cola de cube. Automaticamente se  */
/* re-calculan las coordenadas de las demas articulaciones                */
/**************************************************************************/
void cube_cola_set_xy(double x,double y)
{
  double xinc;
  double yinc;
  int i;
  
  /* Calcular los incrementos a aplicar */
  xinc = x - cube[COLA].coord.x;
  yinc = y - cube[COLA].coord.y;
  
	cube[COLA].coord.x=x;
  cube[COLA].coord.y=y;
  
  /* Recalcular las coordenadas de las articulaciones */
  for (i=1; i<NART; i++) {
    /* Aplicar incremento */
    cube[i].coord.x+=xinc;
    cube[i].coord.y+=yinc;
  }
}

/****************************************************/
/* Obtener las coordenadas x,y de la cola de cube   */
/****************************************************/
void cube_cola_get_xy(double *x,double *y)
{
  *x=cube[COLA].coord.x;
  *y=cube[COLA].coord.y;
}

/*********************************************/
/* Establecer la funcion de contorno activa  */
/*********************************************/
void cube_func_contorno_set(double (*func_contorno)(double))
{
  /* Actualizar variable global del modulo */
  func_act = func_contorno;
}

/***************************************************************/
/* DEPURACION: Imprimir las coordenadas de las articulaciones  */
/***************************************************************/
void cube_print()
{
	char cadx[255];
	char cady[255];
	char cadxtemp[255];
	char cadytemp[255];
	int i;
	
	sprintf(cadx,"x=[");
	sprintf(cady,"y=[");
	
	for (i=0; i<NART; i++) {
		if (i==(LAST)) { //-- Si es la articulacion de la cabeza...
		  sprintf (cadxtemp,"%.2f];",cube[i].coord.x); 
		  sprintf (cadytemp,"%.2f];",cube[i].coord.y);
		}	
		else {
		  sprintf (cadxtemp,"%.2f,",cube[i].coord.x);
		  sprintf (cadytemp,"%.2f,",cube[i].coord.y);
		}	
		strcat(cadx,cadxtemp);
		strcat(cady,cadytemp);
	}
	printf ("%s\n",cadx);
	printf ("%s\n",cady);
}

/*************************************************************/
/* DEBUG: Imprimir los puntos de la funcion de contorno      */
/*************************************************************/
void cube_func_print(double xmin, double xinc, double xmax)
{
	double x;
	double y;
	
	printf ("fx = [%.2f:%.2f:%.2f];\n",xmin,xinc,xmax);
	printf("fy=[");
	
	
	for (x=xmin; x<=xmax; x+=xinc) {
		y=func_act(x);
		if (x>=xmax) { //-- Ultimo punto
			printf ("%.2f];",y);
		}
		else {
		  printf ("%.2f,",y);
		}	
	}
	printf ("\n");
}

/***********************************************************************/
/* Sacar los comandos necesarios de OCTAVE/MATHLAB para dibujar el     */
/* gusano y la funcion de contorno actual                              */
/* --------------------------------------------------------------------*/
/* ENTRADAS:                                                           */
/*   -func: Si la funcion de contorno se pinta o no (1/0)              */
/*   -gusano: Si el gusano se pinta o no (1/0)                         */
/*   -Color: Color con el que dibujar el gusano                        */
/***********************************************************************/
void cube_octave(int func, int gusano, int color)
{
  //-- Si no hay que dibujar ni gusano ni funcion se retorna
  if (func==0 && gusano==0) return;
  
  //-- Generar los puntos x,y de la articulaciones de Cube,
  //-- En formato octave
	if (gusano) cube_print();
    
  //-- Generar los puntos fx,fy de la funcion
  if (func) cube_func_print(0.0,1.0,250.0);
    
  //-- Comandos para configurar la parte grafica
	printf ("axis([%0.2f, %0.2f, %0.2f, %0.2f]);\n",
	        -50.0,250.0,-150.0, 150.0);
	printf ("grid on\n");
	printf ("pause(0.1);\n");
	
  //-- Comandos para dibujar el gusano y/o la funcion
  
  //-- Si hay que dibujar los dos a la vez
	if (func && gusano) {
		printf ("plot(fx,fy,'-b',x,y,'*:%d');\n",color);
		return;
	}
	
  //-- Dibujar solo la funcion
	if (func) {
		printf ("plot(fx,fy,'-b');\n");
	}
  
  //-- Dibujar solo el gusano
	if (gusano) {
		printf ("plot(x,y,'*:%d');\n",color);
	}	
}

/**********************************************************/
/* FUNCIONES RELACIONADAS CON EL MODELO FISICO            */
/**********************************************************/

/**************************************************************/
/* Devolver la articulacion que tiene la coordenada Y mas     */
/* pequena. Se recorre el gusano desde la art especificada    */
/* hacia el sentido especificado                              */
/**************************************************************/
int cube_art_ymin(int art, int sentido)
{
	int ymin;
	int art_ymin;
	int y;
	int i;
	
	//-- Inicialmente tomamos como minima la articulacion pasada
	ymin=cube[art].coord.y;
	art_ymin=art;
	
	if (sentido==DERECHA) { 
	  //-- Recorrer el gusano hacia la derecha
	  for (i=art+1; i<=LAST; i++) {
	  	y=cube[i].coord.y;
	  	if (y<ymin) { //-- La articulacion actual tiene una Y menor
	  		ymin=y;
	  		art_ymin=i;
	  	}	
	  }
		return art_ymin;
	}

  //-- Recorrer gusano hacian la izquierda
  for (i=art-1; i>=COLA; i--) {
		y=cube[i].coord.y;
		if (y<ymin) {
			ymin=y;
			art_ymin=i;
		}
	}		
	
	return art_ymin;
}

/***************************************************************************/
/* Calcular el momento que se ejerce sobre la articulacion art, calculado  */
/* hacia la derecha                                                        */
/***************************************************************************/
double cube_momento_derecha(int art)
{
	int i;
	double momento=0.0;
	double dist;
	
	//-- Si es la ultima articulacion, su momento por la derecha es 0
	if (art==LAST) return 0.0;
	
  for (i=art+1; i<=LAST; i++) {
    dist=calc_distancia(cube[art].coord, cube[i].coord);		
	  momento+=dist;
	}	
	return momento;
}

/************************************************************************/
/* Calcular el momento que se ejerce sobre la articulacion, calculado   */
/* hacia la izquierda                                                   */
/************************************************************************/
double cube_momento_izquierda(int art)
{
	int i;
	double momento=0.0;
	double dist;
	
	if (art==COLA) return 0.0;
		
	for (i=art-1; i>=COLA; i--) {
		dist=calc_distancia(cube[art].coord, cube[i].coord);
		momento+=dist;
	}
	
	return momento;
}

/*********************************************************************/
/* Calcular el angulo que forma el segmento que une la articulacion  */
/* centro con la extremo y el eje X                                  */
/*********************************************************************/
double cube_angulo_caida(int centro, int extremo)
{
	double ang;
	
	ang=TOGRADOS(calc_angulo(cube[centro].coord,cube[extremo].coord));
	if (ang>90.0) ang=(180.0-ang);
	
	return ang;
}

/********************************************************************/
/* Girar CUBE en torno a un centro. No se modifican los angulos de  */
/* posicion de las articulaciones. Solo cambia la orientacion       */
/********************************************************************/
void cube_girar(int centro, double ang, int sentido)
{
	int i;
	
	if (sentido==DERECHA) ang=-ang;
	
	//-- Girar los puntos del centro a la izquierda
	if (centro>0) {
	  for (i=centro-1; i>=0; i--) {
		  rotar_art(centro,i,ang);
  	}
	}
	
  //-- Girar los puntos del centro a la derecha	
	if (centro<LAST) {
		for (i=centro+1; i<=LAST; i++) {
			rotar_art(centro,i,ang);
		}
	}
	
}


/*****************************************************************/
/* Calcular el angulo de caida minimo, desde la articulaciones   */
/* centro hacia el sentido indicado (derecha o izquierda)        */
/*****************************************************************/
double cube_ang_caida_min(int centro, int sentido)
{
	double ang_min;
	double ang; 
	int i;
	
	if (sentido==IZQUIERDA) {
	
	  if (centro==COLA) return 0.0;
	
	  //-- Inicialmente tomamos como minimo el angulo de caida de 
	  //-- la articulacion centro-1
	  ang_min=cube_angulo_caida(centro,centro-1);
	
	  //-- Recorrer el gusano
	  for (i=centro-1; i>=COLA; i--) {
	  	ang=cube_angulo_caida(centro,i);
		  if (ang<ang_min) { //-- La articulacion actual tiene una Y menor
			  ang_min=ang;
		  }	
 	  }
	  return ang_min;
  }

  //-- Sentido Derecha
	if (centro==LAST) return 0.0;
		
	//-- Inicialmente tomamos como minimo el angulo de caida de
	//-- la articulacion centro+1
	ang_min=cube_angulo_caida(centro,centro+1);
	
	//-- Recorrer gusano
	for (i=centro+1; i<=LAST; i++) {
		ang=cube_angulo_caida(centro,i);
		if (ang<ang_min) {
			ang_min=ang;
		}
	}
	return ang_min;
}

/************************************************************/
/* Devolver las coordenadas del centro de masas del gusano  */
/************************************************************/
void cube_centro_masas(double *x, double *y)
{
	double sumx,sumy;
	double x2,y2;
	double nart;
	int i;
	
	sumx=0.0;
	sumy=0.0;
	
	//-- Recorrer todo el gusano
	for (i=COLA; i<=LAST; i++) {
		sumx+=cube[i].coord.x;
		sumy+=cube[i].coord.y;
	}

  //-- Numero de articulaciones	
	nart = (double)NART;

	//-- Obtener las coordenadas del centro de masas
	x2 = (sumx / nart);
	y2 = (sumy / nart);
	
	//-- Devolverlo
	*x= x2;
	*y= y2;
}

/****************************************************/
/* Devoler los zapatos izquierdo y derecho          */
/* SALIDAS:                                         */
/*   zi,zd: zapato izquierdo y zapato derecho       */
/* DEVUELVE:                                        */
/*   0 : No hay zapatos                             */
/*   1 : Hay un unico zapato. En ese caso zi=zd     */
/*   2 : Hay dos zapatos diferentes                 */
/****************************************************/
int cube_get_art_zapato(int *zi, int *zd)
{
	int lista[NART];
	int i;
	int max=0;
	double x,y;
	double xmin, xmax;
	int zapato_izdo;
	int zapato_decho;
	
	//-- recorrer gusano y obtener las articulaciones que estan apoyadas
	for (i=COLA; i<=LAST; i++) {
		//-- Comprobar si la articulacion esta apoyada sobre eje X
		y=cube[i].coord.y;
	  if (y<=0.01 && y>=-0.01) { //-- Esta apoyada, la insertamos en la lista
		  lista[max]=i;
			max++;
	  }
	}
	
	//-- No hay ningun zapato
	if (max==0) {
		*zi=-1;
		*zd=-1;
		return 0; 
	}	
	
	//-- Solo hay un zapato. Es el que tenga la y minima, calculado
	//-- anteriormente
	if (max==1) {
		*zi=*zd=lista[0];
		return 1;
	}
	
	printf ("%%Numero de art. apoyadas: %d\n",max);
	
	//-- Hay mas de una articulacion apoyada. El zapato izquierdo es el
	//-- que tenga la x minima y el derecho la xmaxima
	
	//-- Partimos del primer elemento de la lista
	xmin=cube[lista[0]].coord.x;
	xmax=cube[lista[0]].coord.x;
	zapato_izdo=zapato_decho=lista[0];
	
	printf ("%%xmin: %.2f, xmax: %.2f\n",xmin,xmax);
	for (i=0; i<max; i++) {
	  //-- Obtener las articulaciones con xminima y xmaxima
	  x=cube[lista[i]].coord.x;
		printf ("%%X: %.2f\n",x);
	  if (x>xmax) {
			xmax=x;
			zapato_decho=lista[i];
		}
		if (x<xmin) {
			xmin=x;
			zapato_izdo=lista[i];
		}
	}
	
	*zi=zapato_izdo;
	*zd=zapato_decho;
	
	return 2;
}

  
/***********************************************/
/* Hacer una copia del cube actual             */
/***********************************************/
void cube_copiar()
{
	memcpy(cube_copy, cube, sizeof(cube));
}
