/**********************************************/
/* sg-tramas.c        Juan Gonzalez Gomez.    */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <termios.h>
#include <string.h>

#include "sg-serial.h"
#include "sg-tramas.h"


/***********************************/
/*          CONSTANTES             */
/***********************************/
//-- Tiempo de espera tras un error o un timeout
#define ERROR_TIMEOUT 500000  //en microsegundos


//--TIMEOUT hasta considerar que el sistema no responde
#define TIMEOUT 200000

/***********************************/
/*             VARIABLES           */
/***********************************/
static int serial_fd;  /*-- Descriptor puerto serie */


/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/************************************************************/
/* Inicializacion del m�dulo sg-tramas                      */
/*----------------------------------------------------------*/
/* Simplemente se establece el descriptor del puerto serie  */
/*                                                          */
/* ENTRADAS:                                                */
/*   fd: Descriptor del puerto serie a usar                 */
/************************************************************/
void sg_tramas_init(int fd)
{
  //-- Asignar el puerto serie a utilizar
  serial_fd=fd;
}


/*********************************************************/
/* Obtenci�n de una cadena con la identificaci�n         */ 
/* del servidor (is)                                     */
/*********************************************************/
void sg_tramas_is_to_string(byte is, char *cad)
{
  switch(is) {
  case SG_NULL: 
    strcpy(cad,SG_NULL_CAD);
    break;
  case SG_GENERIC:
    strcpy(cad,SG_GENERIC_CAD);
    break;
  case SG_SERVOS8:
    strcpy(cad,SG_SERVOS8_CAD);
    break;
  case SG_PICP:
    strcpy(cad,SG_PICP_CAD);
    break;
  default:
    strcpy(cad,"XXXX");
  }
}


/***********************************************/
/* Obtenci�n de la cadena de identificaci�n    */
/* del microcontrolador (im)                   */
/***********************************************/
void sg_tramas_im_to_string(byte im, char *cad)
{
  switch(im) {
  case MICRO_68HC11E2:
    strcpy(cad,MICRO_68HC11E2_CAD);
    break;
  case MICRO_68HC08:
    strcpy(cad,MICRO_68HC08_CAD);
    break;
  case MICRO_PIC16F876:
    strcpy(cad,MICRO_PIC16F876_CAD);
    break;
  default:
    strcpy(cad,"XXXX");
  }
}

/**************************************************/
/* Obtencion de la cadena de identificacion de    */
/* la placa                                       */
/**************************************************/
void sg_tramas_ipv_to_string(byte im, byte ipv, char *cad)
{
  int placa;

  if ((ipv&0xF0) == 0) {
    strcpy(cad,PLACA_USER_CAD);
    return;
  }

  placa = ((im<<4)&0xFF0) | ((ipv>>4)&0x0F);

  switch(placa) {
  case PLACA_CT6811:
    strcpy(cad,PLACA_CT6811_CAD);
    break;
  case PLACA_GPBOT:
    strcpy(cad,PLACA_GPBOT_CAD);
    break;
  default:
    strcpy(cad,"XXX");
  }

}

/*****************************************************************/
/* Servicio PING directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama PING, se env�a al StarGate y se espera  */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_ping()
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  ssize_t n;
  struct timeval timeout;
  int status;
  int ret;

  // Construir la trama PING
  trama[0]=TRAMA_PING_CAB;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_PONG_CAB) {  //-- Trama PONG
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      /* Vaciar los buffers de entrada y salida */
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //--Cualquier otro error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio ID directo al StarGate                               */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* SALIDAS:                                                      */
/*    is: Identificador de servidor                              */
/*    im: Identificador de micro                                 */
/*    id: Identificador de placa y version del servidor          */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_id(byte *is, byte *im, byte *ipv)
{
  char trama[2];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  
  // Construir la trama ID
  trama[0]=TRAMA_ID_CAB; 

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,1);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RID_CAB) {  //-- RID
	status=1;
	*is=respuesta[1];
	*im=respuesta[2];
	*ipv=respuesta[3];
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
	*is=0;
	*im=0;
	*ipv=0;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      *is=0;
      *im=0;
      *ipv=0;
      break;
    default: //-- Otro Error
      status=-1;
      *is=0;
      *im=0;
      *ipv=0;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio STORE directo al StarGate                            */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir:   Direccion de almacenamiento                         */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_store(int dir, int valor)
{
  char trama[4];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  
  // Construir la trama ID
  trama[0]=TRAMA_STORE_CAB;
  trama[1]=(dir & 0x00FF);
  trama[2]=(char)((dir>>8)&0x00FF);
  trama[3]=(char)valor;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,4);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RSTORE_CAB) { 
	status=1;
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      break;
    default: //-- Otro Error
      status=-1;
      break;
  }

  return status;
}

/*****************************************************************/
/* Servicio LOAD directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir: Direccion                                             */
/*                                                               */
/* SALIDAS:                                                      */
/*    valor: Valor leido                                         */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load(int dir, int *valor)
{
  char trama[4];
  char respuesta[10];
  fd_set fds;
  struct timeval timeout;
  int status;
  int ret;
  int n;
  
  // Construir la trama LOAD
  trama[0]=TRAMA_LOAD_CAB;
  trama[1]=(dir & 0x00FF);
  trama[2]=(char)((dir>>8)&0x00FF);

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,3);

  //-- Esperar la respuesta
  FD_ZERO(&fds);
  FD_SET (serial_fd, &fds);

  timeout.tv_sec = 0;  //-- Establecer el TIMEOUT
  timeout.tv_usec = TIMEOUT;

  ret=select (FD_SETSIZE,&fds, NULL, NULL,&timeout);

  //-- Procesar la respuesta

  switch(ret) {
    case 1 : //--Datos listos 
      n=read (serial_fd, respuesta, 10);
      if (respuesta[0]==TRAMA_RLOAD_CAB) {  
	status=1;
	*valor=respuesta[1];
      }
      else { //-- Recibido algo distinto de lo esperado
	usleep(ERROR_TIMEOUT);
	/* Vaciar los buffers de entrada y salida */
	tcflush(serial_fd,TCIOFLUSH);
	status=-1;
	valor=0;
      }
      break;
    case 0: //-- Timeout
      tcflush(serial_fd,TCIOFLUSH);
      status=0;
      valor=0;
      break;
    default: //-- Otro Error
      status=-1;
      valor=0;
      break;
  }

  return status;
}
