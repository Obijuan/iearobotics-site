/************************************************************/
/* sec-windows.c    (c) Juan Gonzalez Gomez. Abril  2004    */
/*----------------------------------------------------------*/
/* Funciones de retrollamada para la ventana de secuencias  */
/*----------------------------------------------------------*/
/* Licencia GPL.                                            */
/* mail: juan@iearobotics.com                               */
/************************************************************/

#include <gnome.h>
#include <glib.h>
#include <glade/glade.h>

#include "callback.h"
#include "sg-tramas-servos8.h"
#include "vectores.h"
#include "secuencias.h"

/*-----------------------------*/
/* Variables globales externas */
/*-----------------------------*/
extern int serial_fd; //-- Descriptor puerto serie 
extern int enable;    //-- Estado de habilitacion de los servos

/*--------------------------------*/
/* Variables globales del modulo  */
/*--------------------------------*/

/*-------------------------------*/
/* FUNCIONES PRIVADAS            */
/*-------------------------------*/
void vector_posicionar(vector_pos_t *v)
/****************************************/
/* Enviar el vector de posicion a cube  */
/****************************************/
{
	int a1,a2,a3,a4,a5,a6,a7,a8;
	
	a1=-(int)(v->pos[0]);
	a2=-(int)(v->pos[1]);
	a3=-(int)(v->pos[2]);
	a4=-(int)(v->pos[3]);
	a5=-(int)(v->pos[4]);
	a6=-(int)(v->pos[5]);
	a7=-(int)(v->pos[6]);
	a8=-(int)(v->pos[7]);
	
	sg_servos8_pos8_grados(a1,a2,a3,a4,a5,a6,a7,a8);
}


/*************************************/
/* Reproducir la indicada            */
/*************************************/
void play(char *fich, int nrep)
{
	FILE *f;
	int tam;
	long  pausa;
	double ct=3.8;
	int i;
	long tt;
	vector_pos_t *v;
	vector_pos_t *vini;
	
	/* Abrir el fichero */  
  f = fopen(fich,"r");
  if (f==NULL) {
    printf ("Error al abrir fichero\n");
		return;
  }
	
	g_print ("Cargado fichero...\n");
	
	/* Leer los vectores de posicion */
  if (!sec_load_vectores(f)) {
    printf ("Fichero NO esta en formato .cube\n");
		return;
  }  
  fclose(f);
	
	g_print("OK\n");
	
	tam=sec_num_vectores();
	printf ("Numero de vectores: %d\n",tam);
	
	//v=vector_crear(90,-90,90,-90,90,-90,90,-90,0);
	//vector_posicionar(v);
	//vector_print(v);
	
	/* Leeer vector inicial */
  vini = sec_get_vector(0);
	vector_posicionar(vini);
  //usleep(342000);
	
	while (nrep>0) {
		for (i=0; i<tam; i++) {
			/* Leer el vector de posicion */
			v=sec_get_vector(i);
			//vector_print(v);
			
			/* Calcular tiempo de transito */
			tt = vector_tiempo_trans(vini,v,ct);
			
			/* Obtener la pausa total en useg (Tiempo transito + tiempo espera)*/
			pausa = (long) (tt+v->te)*1000;
			
			/* Mover las articulaciones */
			vector_posicionar(v);
			usleep(pausa);
			vini=v;
		}
		sg_ping();
		nrep--;
	}	
}

void reverse_play(char *fich, int nrep)
{
	FILE *f;
	int tam;
	long  pausa;
	double ct=3.8;
	int i;
	long tt;
	vector_pos_t *v;
	vector_pos_t *vini;
	
	/* Abrir el fichero */  
  f = fopen(fich,"r");
  if (f==NULL) {
    printf ("Error al abrir fichero");
    return;
  }
  
  /* Leer los vectores de posicion */
  if (!sec_load_vectores(f)) {
    printf ("Fichero NO esta en formato .cube\n");
		return;
  }  
  fclose(f);
	
	tam=sec_num_vectores();
	printf ("Numero de vectores: %d\n",tam);
	
	//v=vector_crear(90,-90,90,-90,90,-90,90,-90,0);
	//vector_posicionar(v);
	//vector_print(v);
	
	/* Leeer vector inicial */
  vini = sec_get_vector(tam-1);
	vector_posicionar(vini);
  usleep(342000); 
	
	while (nrep>0) {
		for (i=tam-1; i>=0; i--) {
			/* Leer el vector de posicion */
			v=sec_get_vector(i);
			//vector_print(v);
			
			/* Calcular tiempo de transito */
			tt = vector_tiempo_trans(vini,v,ct);
			
			/* Obtener la pausa total en useg (Tiempo transito + tiempo espera)*/
			pausa = (long) (tt+v->te)*1000;
			
			/* Mover las articulaciones */
			vector_posicionar(v);
			//ping();
			usleep(pausa);
			//usleep(100000);
			vini=v;
		}
		sg_ping();
		nrep--;
	}	
}
	
/*--------------------------------------------------------------------------*/
/*             CALLBACK FUNCTIONS                                           */
/*--------------------------------------------------------------------------*/
void on_sec1_clicked(GtkWidget *widget, gpointer data) 
{
	play("sec1.cube",1);
}
void on_sec1_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("sec1.cube",1);
}

void on_sec2_clicked(GtkWidget *widget, gpointer data) 
{
	play("sec2.cube",1);
}

void on_sec2_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("sec2.cube",1);
}

void on_sec3_clicked(GtkWidget *widget, gpointer data) 
{
	play("sec3.cube",1);
}
void on_sec3_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("sec3.cube",1);
}

void on_sec4_clicked(GtkWidget *widget, gpointer data) 
{
	play("sec4.cube",1);
}
void on_sec4_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("sec4.cube",1);
}

void on_sec5_clicked(GtkWidget *widget, gpointer data) 
{
	play("sec5.cube",1);
}

void on_sec5_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("sec5.cube",1);
}

/***************************/
/*- ONDAS SINUSOIDADLES    */
/***************************/
void on_onda1_clicked(GtkWidget *widget, gpointer data) 
{
	play("onda1.cube",5);
}

void on_onda1_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("onda1.cube",5);
}

void on_onda2_clicked(GtkWidget *widget, gpointer data) 
{
	play("onda2.cube",5);
}

void on_onda2_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("onda2.cube",5);
}

void on_onda3_clicked(GtkWidget *widget, gpointer data) 
{
	play("onda3.cube",4);
}

void on_onda3_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("onda3.cube",4);
}

void on_onda4_clicked(GtkWidget *widget, gpointer data) 
{
	play("loop1.cube",1);
}

void on_onda4_rev_clicked(GtkWidget *widget, gpointer data) 
{
	reverse_play("loop1.cube",1);
}
/***************************/
/*- Secuencias manuales    */
/***************************/

void on_off_button_clicked(GtkWidget *widget, gpointer data)
{
	sg_servos8_enable(0x00);
}

void on_on_button_clicked(GtkWidget *widget, gpointer data)
{
	sg_servos8_enable(0xff);
}

void on_test_button_clicked(GtkWidget *widget, gpointer data)
{
	sg_servos8_pos8_grados(-90,0,0,0,0,0,0,0);
}

void on_reset_button_clicked(GtkWidget *widget, gpointer data) 
{
	sg_servos8_pos8_grados(0,0,0,0,0,0,0,0);
}

void on_encoger1_button_clicked(GtkWidget *widget, gpointer data)
{
	sg_servos8_pos8_grados(-90,90,-90,90,-90,90,-90,90);
}

void on_encoger2_button_clicked(GtkWidget *widget, gpointer data)
{
	sg_servos8_pos8_grados(90,-90,90,-90,90,-90,90,-90);
}

void on_cobra1_button_clicked(GtkWidget *widget, gpointer data)
{
  play("manual1.cube",1);
}

void on_cobra2_button_clicked(GtkWidget *widget, gpointer data)
{
  reverse_play("manual1.cube",1);
}

void on_enrollar_button_clicked(GtkWidget *widget, gpointer data)
{
  play("manual2.cube",1);
}

void on_desenrollar_button_clicked(GtkWidget *widget, gpointer data)
{
  reverse_play("manual2.cube",1);
}

void on_cerrar_button_clicked(GtkWidget *widget, gpointer data)
{
	play("manual_cerrar.cube",1);
}
