/*********************************************************/
/* sg-tramas-servos8.c Juan Gonzalez Gomez. Marzo-2004   */
/*-------------------------------------------------------*/
/* Licencia GPL                                          */
/*********************************************************/

#include <math.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <termios.h>
#include <string.h>

#include "sg-serial.h"
#include "sg-tramas.h"
#include "sg-tramas-servos8.h"

/***********************************/
/*          CONSTANTES             */
/***********************************/
#define TRAMA_ENA_CAB 0x45
#define TRAMA_POS_CAB 0x57

/***********************************/
/*             VARIABLES           */
/***********************************/
int serial_fd;

/******************************************************/
/*              FUNCIONES PRIVADAS                    */
/******************************************************/

static int sg_servos8_to_grados_fut(int grados)
/****************************************************************************/
/* Convertir de grados a grados futaba                                      */
/* El angulo del futaba, en grados, esta comprendido en el entorno [-90,90] */
/* El angulo en grados futabas esta comprendido entre 0-230.                */
/* El valor en grados futaba correspondiente a cero grados es 115           */
/* La pendiente de la recta es 115/90 = 1.28.                               */
/****************************************************************************/
{
  return (int) (1.28*grados + 115);
}

/*****************************************************************/
/* Servicio de POSICIONAMIENTO de un servo,directo al StarGate   */
/*---------------------------------------------------------------*/
/* Se construye la trama POS y se env�a al StarGate              */
/*                                                               */
/*****************************************************************/
void sg_servos8_pos1(int servo, int pos)
{
	char trama[4];

  // Construir la trama POS
  trama[0]=TRAMA_POS_CAB;
	trama[1]=(char)servo;
	trama[2]=(char)pos;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,3);
}

/*****************************************************************/
/* Posicionamiento de los 8 servos, en grados futaba             */
/*****************************************************************/
void sg_servos8_pos8(int s1, int s2, int s3, int s4, 
                     int s5, int s6, int s7, int s8)
{
	sg_servos8_pos1(1,s1);
	sg_servos8_pos1(2,s2);
	sg_servos8_pos1(3,s3);
	sg_servos8_pos1(4,s4);
	sg_servos8_pos1(5,s5);
	sg_servos8_pos1(6,s6);
	sg_servos8_pos1(7,s7);
	sg_servos8_pos1(8,s8);
}


/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/**********************************/
/* Inicializar el modulo servos8  */
/**********************************/
void sg_servos8_init(int fd)
{
	serial_fd=fd;
}


/***************************************************/
/* Posicionamiento de un servo, en grados          */
/***************************************************/
void sg_servos8_pos1_grados(int servo, int pos)
{
	int a;
  
  /* Convertir de grados a grados futaba */
  a =  sg_servos8_to_grados_fut(pos);
		
	/* Actuar sobre el servo */
  sg_servos8_pos1(servo,a);
}

/********************************************************/
/* Posicionamiento de los 8 servos, en grados           */
/********************************************************/
void sg_servos8_pos8_grados(int s1, int s2, int s3, int s4,
                            int s5, int s6, int s7, int s8)
{
	int a1,a2,a3,a4,a5,a6,a7,a8;
	
	a1 = sg_servos8_to_grados_fut(s1);
	a2 = sg_servos8_to_grados_fut(s2);
	a3 = sg_servos8_to_grados_fut(s3);
	a4 = sg_servos8_to_grados_fut(s4);
	a5 = sg_servos8_to_grados_fut(s5);
	a6 = sg_servos8_to_grados_fut(s6);
	a7 = sg_servos8_to_grados_fut(s7);
	a8 = sg_servos8_to_grados_fut(s8);
	
	sg_servos8_pos8(a1,a2,a3,a4,a5,a6,a7,a8);
}

/*****************************************************************/
/* Servicio de HABILITACION de los servos, directo al StarGate   */
/*---------------------------------------------------------------*/
/* Se construye la trama ENA, se env�a al StarGate               */
/*                                                               */
/*****************************************************************/
void sg_servos8_enable(int mask)
{
	char trama[3];

  // Construir la trama ENA
  trama[0]=TRAMA_ENA_CAB;
	trama[1]=(char)mask;

  //-- Enviarla al StarGate
  sg_serial_enviar(serial_fd, trama,2);
}
