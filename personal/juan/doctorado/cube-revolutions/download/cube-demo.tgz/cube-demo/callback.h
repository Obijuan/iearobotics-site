/************************************************************/
/* callback.h    (c) Juan Gonzalez Gomez. Agosto 2002       */
/*----------------------------------------------------------*/
/* This project is under GPL license                        */
/************************************************************/

#ifndef _CALLBACK_H
#define _CALLBACK_H

#include <gnome.h>

/*-----------------------------------------*/
/*-   Asociados a la ventana princiapl    -*/
/*-----------------------------------------*/
void on_main_window_destroy(GtkWidget *window, gpointer data);

/*-- Menu de About --*/
void on_about1_activate(GtkMenuItem *menuitem, gpointer user_data);

/*-- Combo de selecci�n del dispositivo serie --*/
void on_combo_serial_port_entry_changed(GtkWidget *widget, gpointer data);

/*-- Boton de acceso a ventana de posicionamiento --*/
void on_pos_button_clicked(GtkWidget *widget, gpointer data);

/*-- Boton de acceso a ventana de control por canvas --*/
void on_canvas_button_clicked(GtkWidget *widget, gpointer data);

/*-- Boton de acceso a la ventana de secuencias --*/
void on_secuencias_button_clicked(GtkWidget *widget, gpointer data);

/*------------------*/
/* Secuencias       */
/*------------------*/
void on_sec1_clicked(GtkWidget *widget, gpointer data);

/*----------------------------------------------------------------------*/
/* Asociados a la ventana de control mediante barras de desplazamiento  */
/*----------------------------------------------------------------------*/
void on_pos_window_destroy(GtkWidget *window, gpointer data);

//-- Boton de salir
void on_pos_salir_button_clicked(GtkWidget *window, gpointer data);

//-- Habilitacion global de los servos
void on_pos_enable_clicked(GtkWidget *widget, gpointer data);

//-- Reset global de los servos
void on_pos_reset_clicked(GtkWidget *widget, gpointer data);

//-- Habilitacion de los diferentes servos
void on_pos_check1_toggled(GtkWidget *widget, gpointer data);
void on_pos_check2_toggled(GtkWidget *widget, gpointer data);
void on_pos_check3_toggled(GtkWidget *widget, gpointer data);
void on_pos_check4_toggled(GtkWidget *widget, gpointer data);
void on_pos_check5_toggled(GtkWidget *widget, gpointer data);
void on_pos_check6_toggled(GtkWidget *widget, gpointer data);
void on_pos_check7_toggled(GtkWidget *widget, gpointer data);
void on_pos_check8_toggled(GtkWidget *widget, gpointer data);


//-- Posicionamiento de los diferentes servos
void on_hscale1_value_changed(GtkWidget *widget, gpointer data);
void on_hscale2_value_changed(GtkWidget *widget, gpointer data);


#endif /* _CALLBALLK_H */
