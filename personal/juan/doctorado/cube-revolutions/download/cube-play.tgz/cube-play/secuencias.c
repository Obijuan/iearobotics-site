/**************************************************************************/
/* SECUENCIAS.C   Juan Gonzalez Gomez.   Octubre 2000                     */
/*------------------------------------------------------------------------*/
/* Modulo para la gestion de secuencias: conjunto de vectores de posicion */
/**************************************************************************/

#include <stdio.h>
#include <unistd.h>
#include <glib.h>

#include "vectores.h"
#include "secuencias.h"

/*************************/
/* VARIABLES DEL MODULO  */
/*************************/

/* Lista para almacenar los vectores de posicion */
static GList *secuencia=NULL;  

/****************/
/* PROTOTIPOS   */
/****************/
static void sec_liberar();

/*---------------------------------------------*/
/*   F U N C I O N E S   D E  I N T E R F A Z  */
/*---------------------------------------------*/

void sec_init()
/*******************************************/
/* Inicializar las variables del modulo    */
/*******************************************/
{
  /* Si la secuencia ya estaba inicializada...*/
  if (secuencia!=NULL) {
    sec_liberar();         /* Se libera */
  }   
}

int sec_num_vectores()
/****************************************************/
/* Devolver el numero de vectores en la secuencia   */
/****************************************************/
{
  return g_list_length(secuencia);
}


vector_pos_t *sec_get_vector(int numvect)
/************************************************/
/* Devolver un puntero al vector solicitado     */
/* ENTRADAS:                                    */
/*   - Numero de vector en la secuencia         */
/*                                              */
/* DEVUELVE:                                    */
/*   - Puntero al vector de posicion solicitado */
/************************************************/
{
  GList *nodo;
  vector_pos_t *vector;
  
  nodo = g_list_nth(secuencia,numvect);
  vector = (vector_pos_t *)nodo->data;
  
  return vector;
}

void sec_anadir_vector(vector_pos_t *v)
/********************************************************************/
/* Añadir un vector de posicion al final de la secuencia            */
/* ENTRADAS:                                                        */
/*   -Puntero al vector de posicion a añadir                        */
/********************************************************************/
{
  secuencia = g_list_append(secuencia,v);
}

void sec_situar_vector(int numvect, vector_pos_t *v)
/***********************************************************************/
/* Situar un vector de posion en la posicion numvect de la secuencia   */
/* El vector que habia en esa posicion se elimina                      */
/* ENTRADAS:                                                           */
/*   - Numero de vector en la secuencia que se quiere sustituir        */
/*   - vector a situar en la posicion numvect                          */
/***********************************************************************/
{
  GList *nodo;
  vector_pos_t *vector;
  
  /* Localizar el vector en la lista */
  nodo = g_list_nth(secuencia,numvect);
  vector = (vector_pos_t *)nodo->data;
  
  /* Liberar el vector actual */
  vector_free(vector);
  
  /* Introducir el nuevo vector */
  nodo->data=(vector_pos_t *)v;
}

void sec_insertar_vector(int numvect, vector_pos_t *v)
/***************************************************************/
/* Insertar un vector de posicion en la posicion indicada      */
/***************************************************************/
{
  secuencia = g_list_insert(secuencia, (vector_pos_t *)v,numvect);
}

void sec_delete_vector(int numvect)
/********************************************/
/* Borrar un vector de la posicion indicada */
/********************************************/
{
  GList *nodo;
  vector_pos_t *vector;
  
  /* Localizar el vector en la lista */
  nodo = g_list_nth(secuencia,numvect);
  vector = (vector_pos_t *)nodo->data;
  
  /* Eliminar el vector de la lista */
  secuencia = g_list_remove(secuencia,vector);
  
  /* Liberar la memoria tomada */
  vector_free(vector);
}


void sec_grabar_vectores(FILE *f)
/****************************************************************************/
/* Grabar la secuencia de vectores de posicion en disco, en el fichero      */
/*  indicado                                                                */
/****************************************************************************/
{
  int num;
  int i;
  int n;
  vector_pos_t *v;
  
  //-- Grabar una secuencia para 8 servos
  n=fprintf (f,"NSERVOS=8\n");
  
  /* Obtener el numero de vectores en la secuencia actual */
  num=sec_num_vectores();
  
  /* Recorrer la lista de vectores de posicion y grabarlos */
  for (i=1; i<num; i++) {
    v=sec_get_vector(i);
    vector_save(f,v);
  }
  
  /* Escribir el epilogo del fichero */
  fprintf (f,"\n");
}

int sec_load_vectores(FILE *f)
/***************************************************************************/
/* Leer la secuencia de vectores de posicion de disco, desde el descriptor */
/* indicado La secuencia actual, si la habia, se elimina.                  */
/* Se crea una nueva lista con los nuevos vectores.                        */
/*                                                                         */
/* DEVUELVE:                                                               */
/*  0 Si el fichero no estaba en formato .f4. Se establece la secuencia    */
/*    nula                                                                 */
/*  1 No ha habido ningun problema                                         */
/***************************************************************************/
{
  vector_pos_t *v;
  int n;
  int nservos;
  
  /* Si ya habia una secuencia, eliminarla */
  if (secuencia!=NULL) {
    sec_liberar();
  }

  //-- Leer el numero de servos, si lo hay. Si no existe, se toma
  //-- por defecto 8
  n=fscanf (f,"NSERVOS=%d\n",&nservos);
  
  //-- Si la linea NSERVOS=X no existe, por defecto se toman 8 servos
  if (n==0) nservos=8;
  
  //-- Anadir el elemento 0
  v=vector_new();
  sec_anadir_vector(v);
  
  /* Recorrer el fichero leyendo los vectores */
  do {
    /* Crear un nuevo vector */
    v=vector_new();  
    
    /* Leer un vector del fichero */
    n=vector_load(f,v);
   
    /* Si se ha leido bien, anadir vector a la secuencia */
    if (n==1) sec_anadir_vector(v);
    
    /* Se ha alcanzado el final del fichero */
    if (n==2) {
      vector_free(v);
      return 1;
    }
   
    /* Error en fichero */
    if (n==0) {
      sec_init();  /* Inicializar con secuencia nula */
      return 0;
    }
    
  } while (n==1);
  
  /* Aqui  nunca deberia llegar */
  g_print ("SECUENCIAS: sec_load_vectores: Este punto no se deberia alcanzar..!!\n");
  
  return 1;
}


/*--------------------------------------------*/
/*   F U N C I O N E S    P R I V A D A S     */
/*--------------------------------------------*/
static void sec_liberar()
/************************************/
/* Liberar la lista de secuencias.  */
/************************************/
{
  int i;
  int num;
  GList *nodo;
  vector_pos_t *vector;
  
  /* Obtener longitud de la lista */
  num = sec_num_vectores();
  
  /* Recorrer la lista liberando todos los vectores */
  for (i=0; i<num; i++) {
    nodo = g_list_nth(secuencia,i);
    vector = (vector_pos_t *)nodo->data;
    
    /* Liberar datos del nodo i */
    vector_free(vector);
  }
  
  /* Liberar la lista */
  g_list_free(secuencia);
  
  secuencia=NULL;
}
