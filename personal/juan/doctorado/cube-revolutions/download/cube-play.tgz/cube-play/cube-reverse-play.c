/************************************************************************/
/* cube-play.   Juan Gonzalez Gomez.   Marzo-2004                       */
/*----------------------------------------------------------------------*/
/* Reproduccion de fichero .cube                                        */
/*----------------------------------------------------------------------*/
/* LICENCIA GPL                                                         */
/************************************************************************/

#include <stdio.h>
#include <math.h>
#include <unistd.h>

#include <stargate/stargate.h>

#include "vectores.h"
#include "secuencias.h"
#include "sg-tramas-servos8.h"
#include "consola_io.h"

/*----------------------------------*/
/* VARIABLES GLOBALES DEL PROGRAMA  */
/*----------------------------------*/

/*----------------------------------*/
/* VARIABLES GLOBALES DEL MODULO    */
/*----------------------------------*/

/*-----------------------------------*/
/*     P R O T O T I P O S           */
/*-----------------------------------*/

/*-------------------------------------------*/
/*    F U N C I O N E S    P R I V A D A S   */
/*-------------------------------------------*/

void vector_posicionar(vector_pos_t *v)
/****************************************/
/* Enviar el vector de posicion a cube  */
/****************************************/
{
	int a1,a2,a3,a4,a5,a6,a7,a8;
	
	a1=-(int)(v->pos[0]);
	a2=-(int)(v->pos[1]);
	a3=-(int)(v->pos[2]);
	a4=-(int)(v->pos[3]);
	a5=-(int)(v->pos[4]);
	a6=-(int)(v->pos[5]);
	a7=-(int)(v->pos[6]);
	a8=-(int)(v->pos[7]);
	
	sg_servos8_pos8_grados(a1,a2,a3,a4,a5,a6,a7,a8);
}

int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}

int inicio()
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Reproduccion de secuencias para CUBE REVOLUTIONS\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) {
    printf ("Conexion establecida\n");
		sg_servos8_enable(0xFF);
		return 1;
  }
  else printf ("Conexion NO establecida\n");
  return 0;
}



/*-----------------------------------------------------------*/
/*                M  A   I   N                               */
/*-----------------------------------------------------------*/
int main(int argc, char *argv[])
{
	FILE *f;
	int tam;
	long  pausa;
	double ct=3.8;
	int i;
	long tt;
	vector_pos_t *v;
	vector_pos_t *vini;
	int serial_fd;  /*-- Descriptor puerto serie */
	char c=0;
	
  printf ("Cube Revolutions!!!\n");
	
	 /* Abrir el fichero */  
  f = fopen(argv[1],"r");
  if (f==NULL) {
    printf ("Error al abrir fichero");
    return 0;
  }
  
  /* Leer los vectores de posicion */
  if (!sec_load_vectores(f)) {
    printf ("Fichero NO esta en formato .cube\n");
  }  
  fclose(f);
	
	//-- Configurar la consola
  abrir_consola();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el módulo sg-tramas
  sg_tramas_init(serial_fd);
	sg_servos8_init(serial_fd);
 
	inicio();
	
	tam=sec_num_vectores();
	printf ("Numero de vectores: %d\n",tam);
	
	//v=vector_crear(90,-90,90,-90,90,-90,90,-90,0);
	//vector_posicionar(v);
	//vector_print(v);
	
	 /* Leeer vector inicial */
  vini = sec_get_vector(tam-1);
	vector_posicionar(vini);
  usleep(342000); 
	
	do {
		for (i=tam-1; i>=0; i--) {
			/* Leer el vector de posicion */
			v=sec_get_vector(i);
			vector_print(v);
			
			/* Calcular tiempo de transito */
			tt = vector_tiempo_trans(vini,v,ct);
			
			/* Obtener la pausa total en useg (Tiempo transito + tiempo espera)*/
			pausa = (long) (tt+v->te)*1000;
			
			/* Mover las articulaciones */
			vector_posicionar(v);
			//ping();
			usleep(pausa);
			//usleep(100000);
			vini=v;
			if (kbhit()) {
				c=getch();
				if (c==27) break;
				switch(c) {
					case 'p': 
						c=getch();
					  break;
					case '4':
						sg_servos8_enable(~0x50);
					  break;
				} 
			}
		}
  } while (c!=27);
	
	 //-- Consola a su estado inicial
  cerrar_consola();
	
	//-- Cerrar puerto serie
  close(serial_fd);
	
  return 0;
}
