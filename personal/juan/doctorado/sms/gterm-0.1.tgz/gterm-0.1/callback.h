/*****************************************************/
/* callback.h    April, 2002                         */
/*---------------------------------------------------*/
/* This project is under GPL license                 */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#ifndef _CALLBACK_H
#define _CALLBACK_H

/*--------------*/
/* PROTOTYPES   */
/*--------------*/

void dialog_sms_button(GtkWidget *widget, gpointer data);

void main_button(GtkWidget *widget,gpointer data);
/****************************************/
/* Normal buttons callback function     */
/****************************************/

void toggle_boton(GtkWidget *widget,gpointer data);
/*****************************************/
/* Toggle button callback function       */
/*****************************************/

void toggle_check_boton(GtkWidget *widget,gpointer data);
/***********************************/
/* CHECK_MENU CALLBACK FUNCTION    */
/***********************************/

void main_quit(GtkWidget *window, gpointer data);
/*******************************************/
/* Main window destroy callback function   */
/*******************************************/

void help_about (GtkMenuItem *menuitem, gpointer user_data);

void spin_button(GtkWidget *spin_button, gpointer data);

void entry_cmd(GtkWidget *widget, gpointer data);
/********************************************************/
/*  Funcion de retrollamada de un comando introducido   */
/********************************************************/


#endif /* _CALLBALLK_H */
