/*****************************************************/
/* interface.c    april 2002                         */
/*---------------------------------------------------*/
/* GPL license                                       */
/*---------------------------------------------------*/
/* GNEWTON                                           */
/*****************************************************/

#include <glade/glade.h>
#include <glade/glade-xml.h>
#include <gnome.h>

#include "interface.h"
#include "callback.h"

extern interface_t interface;

/*---------------------------------------------------------*/
/*          I M P L E M E N T A T I O N                    */
/*---------------------------------------------------------*/

void create_app(interface_t *ifaz)
{
  GladeXML *xml;
  GtkWidget *app;
  GtkWidget *button;
  GtkWidget *menu;
  GtkWidget *entry;

  /* Leer el interfaz en XML */
  xml = glade_xml_new ("./gterm.glade", "app1");

  /* Obtener el widget de la aplicacion */
  app = glade_xml_get_widget (xml, "app1");

  gtk_window_set_default_size(GTK_WINDOW(app),320,200);
  gtk_signal_connect (GTK_OBJECT (app),"destroy",
                      GTK_SIGNAL_FUNC (main_quit),NULL);

  ifaz->main_window=GNOME_APP(app);

  /*-- STATUS BAR -- */
  ifaz->app_bar=glade_xml_get_widget(xml,"appbar1");

  /*-- Obtener el widget terminal --*/
  ifaz->terminal=glade_xml_get_widget(xml,"terminal");

  /*----------------------------------------------------*/
  /* Funcion de retrollamada de la entrada de comandos  */
  /*----------------------------------------------------*/
  entry=glade_xml_get_widget(xml,"entry_cmd");
  gtk_signal_connect(GTK_OBJECT(entry),"activate",
                     GTK_SIGNAL_FUNC(entry_cmd),NULL);
  

  /*---------------------------------------------------*/
  /* Conectar los botones a su funcion de retrollamada */
  /*---------------------------------------------------*/

  /*-----------*/
  /* TOOLBAR   */
  /*-----------*/
  /*-- Boton para limpiar el terminal --*/
  button = glade_xml_get_widget (xml, "clear_terminal");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"1");
  menu = glade_xml_get_widget(xml,"menu_ctr_limpiar_term");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"1");

  /*-- Boton para Listar los telefonos --*/
  button = glade_xml_get_widget (xml, "listar_telefonos");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"2");
  menu = glade_xml_get_widget(xml,"menu_ctr_listar_tlf");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"2");

  /*-- Boton para listar los mensajes cortos --*/
  button = glade_xml_get_widget (xml, "listar_sms");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"3");
  menu = glade_xml_get_widget(xml,"menu_ctr_listar_sms");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"3");

  /*-- Boton para leer un mensaje sms --*/
  button = glade_xml_get_widget (xml, "leer_sms");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"4");
  menu = glade_xml_get_widget(xml,"menu_ctr_leer_sms");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"4");
  
  /*-- Boton para borrar un mensaje sms --*/
  button = glade_xml_get_widget (xml, "borrar_sms");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"5");
  menu = glade_xml_get_widget(xml,"menu_ctr_borrar_sms");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"5");

  /*-- Boton para enviar un mensaje sms --*/
  button = glade_xml_get_widget (xml, "enviar_sms");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"6");
  menu = glade_xml_get_widget(xml,"menu_ctr_enviar_sms");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"6");
  
  /*-- Boton para enviar control-z --*/
  button = glade_xml_get_widget (xml, "control-z");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(main_button),"7");
  menu = glade_xml_get_widget(xml,"menu_ctr_enviar_cz");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
		     GTK_SIGNAL_FUNC(main_button),"7");
  

  /*********************************/
  /* Conectar las se�ales del menu */
  /*********************************/

  /*-------------*/
  /* File Menu   */
  /*-------------*/
  menu = glade_xml_get_widget (xml, "file_quit");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
                     GTK_SIGNAL_FUNC(main_quit),"1");

  /*--------------*/
  /* Help Menu    */
  /*--------------*/
  menu = glade_xml_get_widget (xml,"help_about");
  gtk_signal_connect(GTK_OBJECT(menu),"activate",
                     GTK_SIGNAL_FUNC(help_about),NULL);

  gtk_object_unref (GTK_OBJECT (xml));

  gtk_widget_show_all(app);
}

GtkWidget *create_about()
/*********************************/
/* Create the about window       */
/*********************************/
{
  GladeXML *xml;
  GtkWidget *about;

  xml = glade_xml_new ("gterm.glade", "about1");
  about = glade_xml_get_widget (xml, "about1");

  gtk_object_unref (GTK_OBJECT (xml));

  return about;
}


static void dialog_destroy(GtkWidget *widget, gpointer data)
/*************************************************************/
/* Funcion llamada antes de destruir una ventana de dialogo  */
/*************************************************************/
{
  /* Levantar la restriccion del foco */
  gtk_grab_remove (GTK_WIDGET(widget));

  g_print ("Destroy\n");
}

void create_dialog_send_sms(dialog_t *windialog)
/**************************************/
/* Caja de dialogo de envio de SMS    */
/**************************************/
{
  GladeXML *xml;
  GtkWidget *button;

  xml=glade_xml_new("./gterm.glade","dialog1");
  windialog->dialog=glade_xml_get_widget(xml,"dialog1");

  /* Esta pasa a ser la ventana principal */
  gtk_grab_add(windialog->dialog);

  windialog->entry_tlf    = glade_xml_get_widget(xml,"entry_tlf");  
  windialog->editable_sms = glade_xml_get_widget(xml,"editable_sms");

  /* Conectar la se�al de destruccion de ventana */
  gtk_signal_connect (GTK_OBJECT(windialog->dialog),"destroy",
		      dialog_destroy,NULL);

  /* Conectar las se�ales de OK y Cancel */

  /*-- OK --*/
  button = glade_xml_get_widget (xml, "dialog1_ok");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(dialog_sms_button),"1");
    
  /*-- Cancel --*/
  button = glade_xml_get_widget (xml, "dialog1_cancel");
  gtk_signal_connect(GTK_OBJECT(button),"clicked",
		     GTK_SIGNAL_FUNC(dialog_sms_button),"2");


  gtk_object_unref(GTK_OBJECT(xml));

}

void create_dialog2(dialog2_t *windialog)
/******************************************************************/
/* Crear el cuadro de dialogo para entrada del numero de mensaje  */
/******************************************************************/
{
  GladeXML *xml;

  xml=glade_xml_new("./gterm.glade","dialog2");
  windialog->dialog=glade_xml_get_widget(xml,"dialog2");

  /* Esta pasa a ser la ventana principal */
  gtk_grab_add(windialog->dialog);

  windialog->entry_nm    = glade_xml_get_widget(xml,"entry_nm");  
  windialog->boton_ok     = glade_xml_get_widget(xml,"ok_nm");
  windialog->boton_cancel = glade_xml_get_widget(xml,"cancel_nm");
  
  /* Conectar la se�al de destruccion de ventana */
  gtk_signal_connect (GTK_OBJECT(windialog->dialog),"destroy",
		      dialog_destroy,NULL);

  gtk_object_unref(GTK_OBJECT(xml));
}

