/*****************************************************/
/* interface.h    Junio 2002                         */
/*---------------------------------------------------*/
/* Licencia GPL                                      */
/*****************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

/*-------------------------------*/
/*  DATA STRUCTURES              */
/*-------------------------------*/

/* ---- Estructura de datos del interfaz ---- */
typedef struct interface_s {
  GnomeApp    *main_window;   /* Main_window                              */
  GtkWidget   *app_bar;       /* status bar, at the bottom                */
  GtkWidget   *terminal;      /* Terminal de visualizacion                */

} interface_t;

typedef struct dialog_s {
  GtkWidget *dialog;        /* Ventana de dialogo de envio de sms */
  GtkWidget *entry_tlf;     /* Entrada de datos (tlf)             */
  GtkWidget *editable_sms;  /* Entrada de datos (mensaje)         */
} dialog_t;

typedef struct dialog2_s {
  GtkWidget *dialog;    /* Ventana de dialogo de entrada del numero de sms */
  GtkWidget *entry_nm;  /* Entrada de datos                                */
  GtkWidget *boton_ok;     /* Boton de OK   */
  GtkWidget *boton_cancel; /* Boton de Cancel */
} dialog2_t;

/*--------------*/
/* PROTOTIPOS   */
/*--------------*/

void create_app(interface_t *interface);
GtkWidget *create_about();
void create_dialog_send_sms(dialog_t *windialog);
void create_dialog2(dialog2_t *windialog);

#endif  /* _INTEFACE_H */
