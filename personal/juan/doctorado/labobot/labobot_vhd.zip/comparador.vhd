------------------------------------------------------
-- comparador.vhdl.  Juan Gonzalez. Feb-2002        --
-- Licencia GPL.                                    --
------------------------------------------------------
-- PROYECTO LABOBOT                                 --
------------------------------------------------------
-- Comparador de 8 bits                             --
-- S�lo se ha implementado la salida correspondiente--
-- a G (La funci�n mayor que).                      --
--                                                  --
-- Entradas: opa : Operando A                       --
--           opb : Operando B                       --
-- Salidas:                                         --
--      G  : (A>B)                                  --
------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

entity comparador is
  port (opa : in std_logic_vector(7 downto 0);   -- Operador A
        opb : in std_logic_vector(7 downto 0);   -- Operador B
	G   : out std_logic);                    -- (A>=G)         
end comparador;

architecture beh of comparador is
begin
  process (opa, opb)
  begin
    if (opa<opb) then
      G <= '0'; 
    else
      G <= '1';
    end if;
  end process;
end beh;

