// Downloader.h : main header file for the DOWNLOADER application
//

#if !defined(AFX_DOWNLOADER_H__BB82FC71_3057_42BC_9A80_80D3DB42C6CB__INCLUDED_)
#define AFX_DOWNLOADER_H__BB82FC71_3057_42BC_9A80_80D3DB42C6CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDownloaderApp:
// See Downloader.cpp for the implementation of this class
//

class CDownloaderApp : public CWinApp
{
public:
	CDownloaderApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDownloaderApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDownloaderApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWNLOADER_H__BB82FC71_3057_42BC_9A80_80D3DB42C6CB__INCLUDED_)
