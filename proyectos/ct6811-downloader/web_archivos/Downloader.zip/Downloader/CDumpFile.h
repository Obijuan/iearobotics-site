// CDumpFile.h: interface for the CDumpFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CDUMPFILE_H__D85EF0C3_B9DC_4A57_B02E_BB67856382EA__INCLUDED_)
#define AFX_CDUMPFILE_H__D85EF0C3_B9DC_4A57_B02E_BB67856382EA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CDumpFile  
{
public:
	void AddLine(CString csLine);
	CDumpFile(CString csName);
	virtual ~CDumpFile();

private:
	CString m_csFileName;
	CStringArray m_arrcsLines;
};

#endif // !defined(AFX_CDUMPFILE_H__D85EF0C3_B9DC_4A57_B02E_BB67856382EA__INCLUDED_)
