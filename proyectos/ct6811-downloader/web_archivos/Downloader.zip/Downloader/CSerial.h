// CSerial.h: interface for the CSerial class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CSERIAL_H__E6203E30_ABF0_4352_8B91_1E45AAF1B43D__INCLUDED_)
#define AFX_CSERIAL_H__E6203E30_ABF0_4352_8B91_1E45AAF1B43D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSerial  
{
public:
	bool Write(char* pWrite, int nLen);
	bool Read(char* pRead, int nLen);
	bool SetupPort(bool bDTR);
	bool ClosePort();
	bool OpenPort(CString csPort);
	CSerial();
	virtual ~CSerial();

private:
	HANDLE m_hCommFile;
};

#endif // !defined(AFX_CSERIAL_H__E6203E30_ABF0_4352_8B91_1E45AAF1B43D__INCLUDED_)
