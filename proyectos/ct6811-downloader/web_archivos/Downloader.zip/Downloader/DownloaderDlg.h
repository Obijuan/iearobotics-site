// DownloaderDlg.h : header file
//

#if !defined(AFX_DOWNLOADERDLG_H__BAD3F918_155B_4849_9218_89F2591E6ADE__INCLUDED_)
#define AFX_DOWNLOADERDLG_H__BAD3F918_155B_4849_9218_89F2591E6ADE__INCLUDED_

#include "CSerial.h"	// Added by ClassView
#include "CDumpFile.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDownloaderDlg dialog

class CDownloaderDlg : public CDialog
{
// Construction
public:
	CDownloaderDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDownloaderDlg)
	enum { IDD = IDD_DOWNLOADER_DIALOG };
	CEdit	m_editRange;
	CButton	m_btnDownload;
	CButton	m_RadioPort1;
	CButton	m_RadioPort2;
	CProgressCtrl	m_Progress;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDownloaderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDownloaderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDownload();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nRange;
	CDumpFile* m_fileDump;
	CSerial m_Serial;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWNLOADERDLG_H__BAD3F918_155B_4849_9218_89F2591E6ADE__INCLUDED_)
