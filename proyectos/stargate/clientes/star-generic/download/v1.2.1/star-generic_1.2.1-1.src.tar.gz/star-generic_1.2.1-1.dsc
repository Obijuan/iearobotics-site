Format: 1.0
Source: star-generic
Version: 1.2.1-1
Binary: star-generic-static, star-generic
Maintainer: Juan Gonzalez <juan@iearobotics.com>
Architecture: any
Standards-Version: 3.6.1
Build-Depends: debhelper (>= 4.0.0)
Files: 
 eeb7e7f6e917383b1ed8e60f37a9b4d1 31041 star-generic_1.2.1.orig.tar.gz
 62a6e14a8314921b6ce2c8faa383d38e 2401 star-generic_1.2.1-1.diff.gz
