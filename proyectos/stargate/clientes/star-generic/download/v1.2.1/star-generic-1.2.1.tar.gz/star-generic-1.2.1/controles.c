/*-------------------------------------------------------------------------
 $Id: controles.c,v 1.9 2004/07/31 09:17:43 juan Exp $
 $Revision: 1.9 $
 $Source: /usr/local/cvs/stargate/clientes/star-generic/controles.c,v $
---------------------------------------------------------------------------*/


#include <stdlib.h>
#include <gnome.h>
#include <glade/glade.h>

#include "conversion.h"
#include "callback.h"
#include "stargate/stargate.h"

/*-----------------------------*/
/* Variables globales externas */
/*-----------------------------*/
extern int serial_fd; //-- Descriptor puerto serie 
extern int global_is; //-- Identificacion del servidor

/*-----------------------------*/
/* Variables globales privadas */
/*-----------------------------*/
int direccion=0;
int valor=0;

/*--------------------------------*/
/* PROTOTIPOS FUNCIONES PRIVADAS  */
/*--------------------------------*/
void entrada_binaria(GladeXML *xml, int valor);
int lectura_binaria(GladeXML *xml);


/*--------------------------------------------------------------------------*/
/*             CALLBACK FUNCTIONS                                           */
/*--------------------------------------------------------------------------*/

/*----------------------*/
/* Cerrar la ventana    */
/*----------------------*/
void on_close_button_clicked(GtkWidget *widget, gpointer data)
{
  GtkWidget *win;
  GladeXML *xml; 

  xml=glade_get_widget_tree(widget);
  win = glade_xml_get_widget (xml, "control_window");
  gtk_widget_destroy(win);  
}

/*------------------------------------------*/
/* Lectura de la direccion, en hexadecimal  */
/* Se parsea el valor y se vuelve a colocar */
/* Si hay error sintactico se pone 0000     */
/*------------------------------------------*/
void on_entry_dir_activate(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry;
  gchar cad[80];
  int dir;
	
  xml=glade_get_widget_tree(widget); 
  entry=glade_xml_get_widget(xml,"entry_dir");
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry)));

  //-- Extraer la direccion
  if (cad4_to_xdigit(cad,&dir)) {
    sprintf(cad,"%04X",dir);
    gtk_entry_set_text(GTK_ENTRY(entry),cad);
  }
  else 
    gtk_entry_set_text (GTK_ENTRY(entry),"0000");
  
}

/*------------------------------------*/
/*  Lectura de Datos, en hexadecimal  */
/*------------------------------------*/
void on_entry_hex_activate(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_hex;
  GtkWidget *entry_dir;
  GtkWidget *entry_dec;
  GtkWidget *analog;
  gchar cad[80];
  int valor;

  xml=glade_get_widget_tree(widget); 
  entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
  analog=glade_xml_get_widget(xml,"analog");
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry_hex)));

  //-- Extraer el valor y analizarlo
  if (cad4_to_xdigit(cad,&valor)) {
    sprintf(cad,"%02X",valor);
    gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);
  }
  else 
    gtk_entry_set_text(GTK_ENTRY(entry_hex),"00");
 
  /*--------------------------------------------*/
  /*-- Actualizar los otros widgets de entrada -*/
  /*--------------------------------------------*/
  /* Entrada en decimal */
  sprintf (cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);

  /* Entrada analogica */
  gtk_range_set_value (GTK_RANGE(analog),(gdouble)valor);

  /* Entrada binaria */
  entrada_binaria(xml, valor);
}


/*------------------------------------*/
/* Lectura de datos, en decimal       */
/*------------------------------------*/
void on_entry_dec_activate(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_hex;
  GtkWidget *entry_dir;
  GtkWidget *entry_dec;
  GtkWidget *analog;
  gchar cad[80];
  int valor;

  xml=glade_get_widget_tree(widget); 
  entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
  analog=glade_xml_get_widget(xml,"analog");
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry_dec)));

  /* -- Parsear el valor obtenido -- */
  if (cad_to_int(cad,&valor)) {
    if (valor>255) valor=255;
    sprintf(cad,"%d",valor);
    gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);
  }
  else gtk_entry_set_text(GTK_ENTRY(entry_dec),"0");   

  /*--------------------------------------------*/
  /*-- Actualizar los otros widgets de entrada -*/
  /*--------------------------------------------*/
  /* Entrada en hexa */
  sprintf (cad,"%02X",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);

  /* Entrada analogica */
  gtk_range_set_value (GTK_RANGE(analog),(gdouble)valor);

  /* Entrada binaria */
  entrada_binaria(xml, valor);
  
}

/*-----------------------------------------------*/
/* CALLBACK para los botones de entrada de bits  */
/*-----------------------------------------------*/
void on_button_b0_clicked(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_hex;
  GtkWidget *entry_dir;
  GtkWidget *entry_dec;
  GtkWidget *analog;
  gchar *cad_estado;
  gchar cad[10];
  int valor;

  xml=glade_get_widget_tree(widget);
  entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
  analog=glade_xml_get_widget(xml,"analog");


  //-- Actualizar la etiqueta del boton
  cad_estado=g_strdup(gtk_button_get_label(GTK_BUTTON(widget)));
  if (cad_estado[0]=='0')
    gtk_button_set_label(GTK_BUTTON(widget),"1");
  else
    gtk_button_set_label(GTK_BUTTON(widget),"0");

  g_free(cad_estado);

  /*------------------------------------------*/
  /* Actualizar los otros Widgets de entrada  */
  /*------------------------------------------*/
  valor=lectura_binaria(xml);
  /* Entrada en hexa */
  sprintf (cad,"%02X",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);

  /* Entrada decimal */
  sprintf(cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);

  /* Entrada analogica */
  gtk_range_set_value (GTK_RANGE(analog),(gdouble)valor);
}


/*-------------------------------------*/
/* CALLBACK para la entrada analogica  */
/*-------------------------------------*/
void on_analog_value_changed(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_hex; 
  GtkWidget *entry_dir;
  GtkWidget *entry_dec;
  GtkWidget *analog;
  gchar cad[10];
  int valor;

  xml=glade_get_widget_tree(widget);
  entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
  analog=glade_xml_get_widget(xml,"analog");

  //-- Leer la entrada analogica
  valor=(int)gtk_range_get_value(GTK_RANGE(analog));

  /*------------------------------------------*/
  /* Actualizar los otros Widgets de entrada  */
  /*------------------------------------------*/
  /* Entrada en hexa */
  sprintf (cad,"%02X",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);

  /* Entrada decimal */
  sprintf(cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);

  /* Entrada binaria */
  entrada_binaria(xml, valor);

}

/*--------------------------*/
/* Acceso al servicio STORE */
/*--------------------------*/
void on_button_store_clicked(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_dir;
  GtkWidget *analog;
  char cad[10];
  int dir;
  int valor;

  //-- Obtener arbol de widgets
  xml = glade_get_widget_tree(widget);
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  analog=glade_xml_get_widget(xml,"analog");

  //-- Obtener la direccion
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry_dir)));

  //-- Extraer la direccion
  if (cad4_to_xdigit(cad,&dir)) {
    sprintf(cad,"%04X",dir);
    gtk_entry_set_text(GTK_ENTRY(entry_dir),cad);
  }
  else {  //-- Error sint�ctico en direccion 
    gtk_entry_set_text (GTK_ENTRY(entry_dir),"0000");
    return; //-- No hacer el store
  }

  //-- Leer la entrada analogica para obtener el valor
  valor=(int)gtk_range_get_value(GTK_RANGE(analog));

  //g_print("STORE: %02X --> %04X\n",valor,dir);
  sg_store(dir,valor);

}



/*---------------------------*/
/* Acceso al servicio LOAD   */
/*---------------------------*/
void on_button_load_clicked(GtkWidget *widget, gpointer data)
{
  GladeXML *xml;
  GtkWidget *entry_dir;
  GtkWidget *entry_hex;
  GtkWidget *entry_dec;
  GtkWidget *analog;
  gchar cad[10];
  int dir;
  int valor;
  int status;

  g_print("Load\n");

  xml=glade_get_widget_tree(widget);
  entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
  analog=glade_xml_get_widget(xml,"analog");

  //-- Obtener la direccion
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry_dir)));

  //-- Extraer la direccion
  if (cad4_to_xdigit(cad,&dir)) {
    sprintf(cad,"%04X",dir);
    gtk_entry_set_text(GTK_ENTRY(entry_dir),cad);
  }
  else {  //-- Error sint�ctico en direccion 
    gtk_entry_set_text (GTK_ENTRY(entry_dir),"0000");
    return; //-- No hace load
  }

  //-- Hacer el LOAD
  status=sg_load(dir,&valor);
  valor=(valor&0x00FF);

  //-- Ha ocurrido error... terminar
  if (status!=1) return;

  /*------------------------------------------*/
  /* Actualizar los otros Widgets de entrada  */
  /*------------------------------------------*/
  /* Entrada en hexa */
  sprintf (cad,"%02X",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);

  /* Entrada decimal */
  sprintf(cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);

  /* Entrada binaria */
  entrada_binaria(xml, valor);

  /* Entrada analogica */
  gtk_range_set_value (GTK_RANGE(analog),(gdouble)valor);

}


/*---------------------------------------------------*/
/* Leer el valor de los botones binarios y devolver  */
/* el numero                                         */
/*---------------------------------------------------*/
int lectura_binaria(GladeXML *xml)
{
  GtkWidget *button[8];
  gchar button_name[8][10]={
    "button_b0", "button_b1", "button_b2", "button_b3",
    "button_b4", "button_b5", "button_b6", "button_b7"
  };
  gchar *cad;
  int valor=0;
  int i;
 
  for (i=7; i>=0; i--) {
    valor=(valor<<1);
    button[i]=glade_xml_get_widget(xml,button_name[i]);
    cad=g_strdup(gtk_button_get_label(GTK_BUTTON(button[i])));
    if (cad[0]=='0') {
      valor=(valor&0xFE);  //Meter un '0'
    }
    else {
      valor=(valor|0x01);  //Meter un '1'
    }
  }
  return valor; 
}


/*----------------------------------------------*/
/* Activar los widgets y etiquetas del control  */
/* de entrada binario                           */
/*----------------------------------------------*/
void entrada_binaria(GladeXML *xml, int valor)
{
  GtkWidget *button[8];
  gchar button_name[8][10]={
    "button_b0", "button_b1", "button_b2", "button_b3",
    "button_b4", "button_b5", "button_b6", "button_b7"
  };
  gchar cad[10];
  gboolean estado;
  int i;

  //-- Poner el valor en binario 
  for (i=0; i<8; i++) {

    //-- Actualizar las etiquetas de los botones binarios --
    button[i]=glade_xml_get_widget(xml,button_name[i]);
    if ((valor&0x01)==1) {
      sprintf(cad,"1");
      estado=TRUE;
    }
    else { 
      sprintf(cad,"0");
      estado=FALSE;
    }

    gtk_button_set_label(GTK_BUTTON(button[i]),cad);  

    valor = (valor >> 1);
  }
}
