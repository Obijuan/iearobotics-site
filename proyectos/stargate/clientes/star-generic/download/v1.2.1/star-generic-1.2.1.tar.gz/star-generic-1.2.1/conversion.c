/***************************************************/
/* Funciones de conversion y utilidades generales  */
/***************************************************/
/*-------------------------------------------------------------------------
 $Id: conversion.c,v 1.2 2004/07/31 09:17:43 juan Exp $
 $Revision: 1.2 $
 $Source: /usr/local/cvs/stargate/clientes/star-generic/conversion.c,v $
---------------------------------------------------------------------------*/


#include <gnome.h>
#include "conversion.h"

/*-----------------------------------------------------*/
/* Convertir la cadena decimal a su numero             */
/* ENTRADAS:                                           */
/*   -cad: cadena ASCII decimal                        */
/* SALIDAS:                                            */
/*   -num: Numero correspondiente                      */
/* DEVUELVE:                                           */
/*   1 si la conversion se ha hecho correctamente      */
/*   0 si no es un n�mero en hexadecimal               */
/*-----------------------------------------------------*/
gboolean cad_to_int(gchar *cad, int *num)
{
  int i;

  *num=0;

  //-- Ver si todos los digitos son correctos
  for (i=0; i<strlen(cad); i++) {
    if (! g_ascii_isdigit(cad[i])) {
      *num=0;
      return FALSE;
    }
  }  
  *num=atoi(cad);
  return TRUE;
}

/*-----------------------------------------------------*/
/* Convertir una cadena ascii hexadecimal a su numero  */
/* La cadena como mucho puede ser de 4 digitos hexa.   */
/* ENTRADAS:                                           */
/*    -cad: Cadena ASCII hexadecimal                   */
/* SALIDAS:                                            */
/*    -num: Numero correspondiente                     */
/* DEVUELVE:                                           */
/*    1 si la conversion se ha hecho correctamente     */
/*    0 si no es un n�mero en hexadecimal              */
/*-----------------------------------------------------*/
gboolean cad4_to_xdigit(gchar *cad, int *num)
{
  int i;
  int peso[4]={0x1000,0x100,0x10,0x1};
  
  *num=0;

  //-- Ver si todos los digitos son hexadecimales
  for (i=0; i<strlen(cad); i++) {
    if (!g_ascii_isxdigit(cad[i])) {
      *num=0;
      return FALSE;
    }
    *num+=g_ascii_xdigit_value(cad[i])*peso[4-strlen(cad)+i];
  }

  return TRUE;
}
