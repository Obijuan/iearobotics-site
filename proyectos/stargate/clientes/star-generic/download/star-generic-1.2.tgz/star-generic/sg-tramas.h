
/******************************************************/
/* sg-tramas.h        Juan Gonzalez Gomez.            */
/*----------------------------------------------------*/
/* Definiciones y estructuras de las tramas StarGate  */
/* Licencia GPL                                       */
/******************************************************/

#ifndef SG_TRAMAS_H
#define SG_TRAMAS_H

/*******************/
/* DEFINICIONES    */
/*******************/

/*************************************************/
/* Tipos de tramas y sus c�digos                 */
/*-----------------------------------------------*/
/* SERVICIOS BASICOS                             */
/*-----------------------------------------------*/
/* PING:    0x00                                 */
/* PONG:    0X10 (Respuesta de PING)             */
/* ID:      0x01 (IDENTIFICACION)                */
/* RID:     0X11 (Respuesta identificaci�n)      */
/*-----------------------------------------------*/
/* SERVICIOS ESPECIFICOS                         */
/*-----------------------------------------------*/
/* LOAD:    0x02                                 */
/* RLOAD:   0x12 (Respueras de LOAD)             */
/* STORE:   0x03                                 */
/* RSTORE:  0x13 (Respuesta de STORE)            */
/*************************************************/


/*-- Codigos de identificacion de las tramas --*/
#define TRAMA_PING_IT    0x00
#define TRAMA_PONG_IT    0x10
#define TRAMA_ID_IT      0x01
#define TRAMA_RID_IT     0x11
#define TRAMA_LOAD_IT    0x02
#define TRAMA_RLOAD_IT   0x12
#define TRAMA_STORE_IT   0x03
#define TRAMA_RSTORE_IT  0x13
#define TRAMA_UNKNOW_IT  0xFF // Trama desconocida

/*-- Cabeceras de la trama --*/
#define TRAMA_PING_CAB 'P'
#define TRAMA_ID_CAB   'I'
#define TRAMA_RID_CAB  'I'
#define TRAMA_PONG_CAB 'O'
#define TRAMA_LOAD_CAB 'L'
#define TRAMA_RLOAD_CAB 'L'
#define TRAMA_STORE_CAB 'S'
#define TRAMA_RSTORE_CAB 'S'

//-- Servidor picp
#define TRAMA_RD_CAB 'R'
#define TRAMA_RRD_CAB 'R'
#define TRAMA_INC_CAB 'A'
#define TRAMA_RINC_CAB 'A'
#define TRAMA_CONF_CAB 'C'
#define TRAMA_RCONF_CAB 'C'
#define TRAMA_PROG_CAB 'W'
#define TRAMA_RPROG_CAB 'W'
#define TRAMA_RST_CAB   'T'
#define TRAMA_RRST_CAB  'T'
#define TRAMA_DATA_CAB   'D'
#define TRAMA_RDATA_CAB  'D'
#define TRAMA_BEGIN_CAB  'B'
#define TRAMA_RBEG_CAB   'B'

/*************************************/
/* Identificaci�n de los servidores  */
/*************************************/
#define SG_NULL    0x10
#define SG_GENERIC 0x20
#define SG_SERVOS8 0x30
#define SG_PICP    0x40

/***********************************************/
/* Cadenas de identificaci�n de los servidores */
/***********************************************/
#define SG_NULL_CAD    "NULL"
#define SG_GENERIC_CAD "GENERIC"
#define SG_SERVOS8_CAD "SERVOS8"
#define SG_PICP_CAD    "PICP"

/****************************************/
/* Identificaci�n del Micro.            */
/****************************************/
#define MICRO_68HC11E2  0x10
#define MICRO_68HC08    0x20
#define MICRO_PIC16F876 0x30

/********************************************/
/* Cadenas de identificaci�n de los micros  */
/********************************************/
#define MICRO_68HC11E2_CAD  "68HC11E2"
#define MICRO_68HC08_CAD    "68HC08"
#define MICRO_PIC16F876_CAD "PIC16F876"

/******************************************/
/* Identificacion de las placas           */
/******************************************/
#define PLACA_CT6811 0x101
#define PLACA_GPBOT  0x201

/********************************************/
/* Cadenas de identificacion de las placas  */
/********************************************/
#define PLACA_CT6811_CAD  "CT6811"
#define PLACA_GPBOT_CAD   "GPBOT"
#define PLACA_USER_CAD    "USER"


#ifndef BYTE
  #define BYTE
  typedef unsigned char byte;
#endif

/**************************/
/* ESTRUCTURAS DE DATOS   */
/**************************/

/*-----------------------------*/
/* Respuesta de IDENTIFICACION */
/*-----------------------------*/
struct sg_trama_data_rid_s {
  byte is;  //-- Identificaci�n del servidor
  byte im;  //-- Identificaci�n del microcontrolador
  byte ipv; //-- Version de la placa y del servidor
};
typedef struct sg_trama_data_rid_s sg_trama_data_rid_t;

/*----------------------------------------*/
/* TRAMA GENERICA, para acceder al motor  */
/*----------------------------------------*/
struct sg_trama_s {
  byte it;      //-- Identificador de trama
  int status;   //-- Status. S�lo usado en las respuestas

  //-- Datos de la trama. Dependen del tipo de trama (it)
  union {
    sg_trama_data_rid_t resp_id; /* RESPUESTA DE IDENTIFICACION */
  } data;
};
typedef struct sg_trama_s sg_trama_t;

/**********************************/
/* PROTOTIPOS DEL INTERFAZ        */
/**********************************/

/************************************************************/
/* Inicializacion del m�dulo sg-tramas                      */
/*----------------------------------------------------------*/
/* Simplemente se establece el descriptor del puerto serie  */
/*                                                          */
/* ENTRADAS:                                                */
/*   fd: Descriptor del puerto serie a usar                 */
/************************************************************/
void sg_tramas_init(int fd);

/*********************************************************/
/* Obtenci�n de una cadena con la identificaci�n         */ 
/* del servidor (is)                                     */
/*********************************************************/
void sg_tramas_is_to_string(byte is, char *cad);


/***********************************************/
/* Obtenci�n de la cadena de identificaci�n    */
/* del microcontrolador (im)                   */
/***********************************************/
void sg_tramas_im_to_string(byte im, char *cad);

/**************************************************/
/* Obtencion de la cadena de identificacion de    */
/* la placa                                       */
/**************************************************/
void sg_tramas_ipv_to_string(byte im, byte ipv, char *cad);


/*****************************************************************/
/* Servicio PING directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama PING, se env�a al StarGate y se espera  */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_ping(void);

/*****************************************************************/
/* Servicio ID directo al StarGate                               */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* SALIDAS:                                                      */
/*    is: Identificador de servidor                              */
/*    im: Identificador de micro                                 */
/*    id: Identificador de placa y version del servidor          */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_id(byte *is, byte *im, byte *ipv);

/*****************************************************************/
/* Servicio STORE directo al StarGate                            */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir:   Direccion de almacenamiento                         */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_store(int dir, int valor);


/*****************************************************************/
/* Servicio LOAD directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir: Direccion                                             */
/*                                                               */
/* SALIDAS:                                                      */
/*    valor: Valor leido                                         */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load(int dir, int *valor);


#endif  // SG_TRAMAS_H

