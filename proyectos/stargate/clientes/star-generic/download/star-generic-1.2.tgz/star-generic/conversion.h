gboolean cad_to_int(gchar *cad, int *num);
gboolean cad4_to_xdigit(gchar *cad, int *num);
