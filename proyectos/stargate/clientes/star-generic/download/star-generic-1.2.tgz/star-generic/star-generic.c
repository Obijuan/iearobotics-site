/************************************************************/
/* star-generic.c    (c) Juan Gonzalez Gomez. Agosto  2003  */
/*----------------------------------------------------------*/
/* Cliente gr�fico para el StarGate Nulo                    */
/*----------------------------------------------------------*/
/* Licencia GPL.                                            */
/* mail: juan@iearobotics.com                               */
/************************************************************/

#include <gnome.h>
#include <glib.h>
#include <glade/glade.h>

#include "callback.h"
#include "sg-serial.h"
#include "sg-tramas.h"

/*------------------------*/
/*    CONSTANTS           */
/*------------------------*/
#define PACKAGE "STAR-GENERIC"
#define VERSION "1.2"
#define FICHERO_GLADE "star-generic.glade"

/*----------------------------------------*/
/* VARIABLES GLOBALES DE LA APLICACION    */
/*----------------------------------------*/
int serial_fd=0;  /*-- Descriptor puerto serie */
int global_is=0;  //-- Identificacion del servidor

/*--------------------------------*/
/* VARIABLES GLOBALES DEL MODULO  */
/*--------------------------------*/
static GladeXML *xml_main_window=NULL; //-- Acceso al arbol de widgets
static int       estado_conexion=0;

/*----------------------------------*/
/* PROTOTIPOS FUNCIONES PRIVADAS    */
/*----------------------------------*/
void id(void);

/*---------------------------------------------------------------------*/
/*                             CALLBACK FUNCTIONS                      */
/*---------------------------------------------------------------------*/
void on_main_window_destroy(GtkWidget *window, gpointer data)
{

  /* Cerrar puerto serie si estaba abierto */
  if (serial_fd!=0) close(serial_fd);

  /* Terminar */
  gtk_main_quit();
}

/*------------------------------*/
/* Mostrar la ventana de ABOUT  */
/*------------------------------*/
void on_about1_activate(GtkMenuItem *menuitem, gpointer user_data)
{
  GladeXML *xml;
  GtkWidget *about = NULL;

  xml = glade_xml_new (FICHERO_GLADE, "about1",NULL);
  about = glade_xml_get_widget (xml, "about1");

  gtk_widget_show (about);
  g_object_unref(xml);
}

/*-----------------------------------------------------*/
/* Funcion de retrollamada de la selecci�n del puerto  */
/* Cuando el usuario selecciona un puerto nuevo,       */
/* se realizan dos llamadas a esta funci�n. En la      */
/* primera es debida a que la cadena que hab�a antes   */
/* se elimina. Esto se aprovecha para cerrar el puerto */
/* serie.                                              */
/*  La segunda es debida a la nueva cadena del         */
/* dispositivo serie.                                  */
/*-----------------------------------------------------*/
void on_combo_serial_port_entry_changed(GtkWidget *widget, gpointer data)
{
  GladeXML *xml; 
  GtkWidget *entry;
  GtkWidget *app_bar;
  gchar *disp;
  gchar cad[80];
	
  //-- Obtener el arbol de widgets  
  xml=glade_get_widget_tree(widget);

  //-- Obtener la cadena del dispositivo seleccionado
  entry=glade_xml_get_widget(xml,"combo_serial_port_entry");
  disp=g_strdup(gtk_entry_get_text(GTK_ENTRY(entry)));

  //-- Si es la cadena NUla, se cierra el puerto serie
  //-- Cuando hay un cambio en la entrada combo primero
  //-- se produce una llamada con la cadena nula y 
  //-- otra con la nueva cadena seleccionada por el usuario

  if (*disp==0) {  //-- Si es la cadena nula
    if (serial_fd!=0) close(serial_fd);
    serial_fd=0;
    g_free(disp);
    return;
  }  

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp);
  if (serial_fd==-1) {
    //-- Error al abrir el puerto serie. Se indica
    //-- con serial_fd=0;
    serial_fd=0;
  }

  //-- Inicializar el m�dulo sg-tramas (s�lo si puerto serie abierto)
  if (serial_fd!=0)
    sg_tramas_init(serial_fd);

  /*-- Modificar la barra de estado --*/
  app_bar=glade_xml_get_widget(xml, "appbar1");
  if (serial_fd==0) {
    g_sprintf(cad,"Error al abrir puerto serie: %s",disp);
    gnome_appbar_set_status(GNOME_APPBAR(app_bar), cad);
  }
  else 
    gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Puerto serie Abierto");

  g_free(disp);
} 

/*-----------------------------------------*/
/* Acceso a la ventana de Monitorizacion   */
/*-----------------------------------------*/
void on_monitor_button_clicked(GtkWidget *widget, gpointer data)
{
  GtkWidget *monitor; 
	GtkWidget *app_bar;
  GladeXML *xml;

  xml = glade_xml_new (FICHERO_GLADE, "monitor_window",NULL);
  monitor = glade_xml_get_widget (xml, "monitor_window");
  glade_xml_signal_autoconnect (xml);

	app_bar=glade_xml_get_widget(xml,"monitor_appbar");
  gnome_appbar_set_status(GNOME_APPBAR(app_bar),"PARADO");	
	
	
  gtk_widget_show (monitor); 
}

/*---------------------------------------*/
/* Acceso a la ventana de controles      */
/*---------------------------------------*/
void on_control_button_clicked(GtkWidget *widget, gpointer data)
{
  GtkWidget *control; 
  GladeXML *xml;

  xml = glade_xml_new (FICHERO_GLADE, "control_window",NULL);
  control = glade_xml_get_widget (xml, "control_window");
  glade_xml_signal_autoconnect (xml);

  gtk_widget_show (control);
}


/*-------------------------------*/
/* Servicio de identificacion    */
/*-------------------------------*/
void id()
{
  GtkWidget *entry_id_server;
  static gchar cad[80];
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  //-- Solo se accede si el puerto serie est� abierto
  if (serial_fd!=0) status=sg_id(&is,&im,&ipv);
  else status=0;

  switch(status) {
  case 1: /* OK */
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    sprintf (cad, "SG-%s-%s-%s-%d",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    global_is=is;
    break;
  default: /* Error */
    sprintf (cad,"UNKNOW");
  }
  
  //-- Actualizar el indicador de tipo de Stargate --

  //-- Obtener widget
  entry_id_server = glade_xml_get_widget (xml_main_window, "entry_id_server");
  gtk_entry_set_text (GTK_ENTRY(entry_id_server),cad);  
}


/*----------------------------------------------------*/
/* Comprobar la conexi�n con el Stargate. Se          */
/* actualiza el intefaz y el estado de la aplicacion  */
/*----------------------------------------------------*/
gboolean comprobar_conexion()
{
  int status;
  GtkWidget *imagen;
  GtkWidget *app_bar;
  GtkWidget *frame;
  GtkWidget *control_button;
  GtkWidget *monitor_button;
  GtkWidget *menu_control;
  GtkWidget *menu_monitor;
	
  //-- Obtener la referencia a los widgets a utilizar
  app_bar = glade_xml_get_widget(xml_main_window,"appbar1");
  imagen = glade_xml_get_widget(xml_main_window,"imagen_estado_conexion");
  frame = glade_xml_get_widget(xml_main_window,"frame_load_store");

  //-- Hacer ping, solo si el puerto serie est� abierto
  if (serial_fd!=0) status=sg_ping();
  else status=0;

  //-- Ahora status s�lo vale 0 � 1. Si vale 0 es que
  //-- no se ha establecido conexi�n, bien por timeout
  //-- o bien por error.
  status=(status==1)?1 : 0;

  //-- Si la conexi�n se ha recuperado...
  if (estado_conexion!=status && status==1) {
    //-- Obtener la informaci�n del servidor
    id();
 
    //-- Actualizar el icono que indica el estado
    gtk_image_set_from_file (GTK_IMAGE(imagen),
			     "on.xpm");
    gnome_appbar_set_status(GNOME_APPBAR(app_bar),
			    "ON-LINE");

    //-- Activar los elementos usados, solo si es el gen�rico
    //-- servidor gen�rico
    if (global_is==SG_GENERIC) {
      control_button=glade_xml_get_widget(xml_main_window,"control_button");
      monitor_button=glade_xml_get_widget(xml_main_window,"monitor_button");
      menu_control=glade_xml_get_widget(xml_main_window,"menu_control");
      menu_monitor=glade_xml_get_widget(xml_main_window,"menu_monitor");
      gtk_widget_set_sensitive (control_button, TRUE);
      gtk_widget_set_sensitive (monitor_button, TRUE);
      gtk_widget_set_sensitive (menu_control, TRUE);
      gtk_widget_set_sensitive (menu_monitor, TRUE);
    }
  }

  //-- Si la conexi�n se ha perdido...
  if (estado_conexion!=status && status==0) {

    id();

    //-- Actualizar icono que indica el estado
    gtk_image_set_from_file (GTK_IMAGE(imagen),
			     "off.xpm");
    gnome_appbar_set_status(GNOME_APPBAR(app_bar),
			    "OFF-LINE");

    //-- Desactivar elementos no usados cuando no hay conexion
    control_button=glade_xml_get_widget(xml_main_window,"control_button");
    monitor_button=glade_xml_get_widget(xml_main_window,"monitor_button");
    menu_control=glade_xml_get_widget(xml_main_window,"menu_control");
    menu_monitor=glade_xml_get_widget(xml_main_window,"menu_monitor");
    gtk_widget_set_sensitive (control_button, FALSE);
    gtk_widget_set_sensitive (monitor_button, FALSE);
    gtk_widget_set_sensitive (menu_control, FALSE);
    gtk_widget_set_sensitive (menu_monitor, FALSE);
  }

  /* Guardar estado de la conexi�n */
  estado_conexion=(status==1) ?1 : 0;
  
  return TRUE;
}

/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{
  GtkWidget *main_window;
  GtkWidget *menu_control;
  GtkWidget *menu_monitor;
  GnomeProgram *program;

  if (! (program = gnome_program_init (PACKAGE, VERSION, LIBGNOMEUI_MODULE,
                                       argc, argv, NULL)))
      g_error ("gnome_program_init failed"); 

  /*-- Inicializar GLADE -- */
  glade_gnome_init();

  /*------------------------*/
  /*  Crear el interfaz     */
  /*------------------------*/
  xml_main_window = glade_xml_new ("star-generic.glade", "main_window", NULL);
  g_assert(xml_main_window!=NULL);
  glade_xml_signal_autoconnect (xml_main_window);

  main_window=glade_xml_get_widget(xml_main_window,"main_window");
  g_assert(main_window!=NULL);

  /*----------------------*/
  /* Inicializar interfaz */
  /*----------------------*/
  menu_control=glade_xml_get_widget(xml_main_window,"menu_control");
  menu_monitor=glade_xml_get_widget(xml_main_window,"menu_monitor");
  gtk_widget_set_sensitive (menu_control, FALSE);
  gtk_widget_set_sensitive (menu_monitor, FALSE); 

  /*------------------------------*/
  /* Inicializar el puerto serie  */
  /*------------------------------*/
  on_combo_serial_port_entry_changed(main_window, NULL);

  /*-- Establecer la funci�n peri�dica para comprobar la conexi�n --*/
  gtk_timeout_add (500, comprobar_conexion, NULL);
	
	
  /*-- Que comience la fiesta!!!! -- */
  gtk_main();

  return 0;
}
