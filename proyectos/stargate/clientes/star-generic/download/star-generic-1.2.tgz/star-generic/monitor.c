#include <stdlib.h>
#include <gnome.h>
#include <glade/glade.h>

#include "conversion.h"
#include "callback.h"
#include "sg-serial.h"
#include "sg-tramas.h"

/**********************************************************/
/*                  FUNCIONES PRIVADAS                    */
/**********************************************************/


/*------------------------------------------------*/
/* Detener el temporizador de monitorizacion      */
/* Se accede al widget "invisible" entry_timer    */
/* donde se encuentra almacenado el identificador */
/* del temporizador utilizado                     */
/* Si ya estaba parado, no se hace nada           */
/*------------------------------------------------*/
static void stop_timer(GtkWidget *entry_timer)
{
	gchar cad[80];
	guint timer;
	
	//-- Obtener el identificador del timer
	strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry_timer)));
	timer = (guint) atoi(cad);
	
	//-- Debug
	//g_print("Destroy Timer id: %u\n",timer);
	
	//-- Destruir el temporizador, si estaba creado
	if (timer!=0)
	  gtk_timeout_remove (timer);
	
	//-- En cualquier caso, colocamos un '0' como identificador
	//-- del temporizador
	gtk_entry_set_text(GTK_ENTRY(entry_timer),"0");
}


/*---------------------------------------------------*/
/* Establecer el estado del interfaz cuando estamos  */
/* en mono de NO monitorizacion (Parado)             */
/*---------------------------------------------------*/
static void interfaz_monitor_off(GladeXML *xml)
{
	GtkWidget *entry_dir;
	GtkWidget *stop;
	GtkWidget *go;
	
	/*-- Obtener los widgets --*/
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
	stop=glade_xml_get_widget(xml,"monitor_stop");
	go=glade_xml_get_widget(xml,"monitor_go");
	
	//-- Establecer el estado
	gtk_widget_set_sensitive(entry_dir,TRUE);  //-- Direccion activada
	gtk_widget_set_sensitive(go,TRUE);     //-- Boton de GO activado
	gtk_widget_set_sensitive(stop,FALSE);  //-- Boton de Stop desactivado
}

static void interfaz_monitor_on(GladeXML *xml)
{
	GtkWidget *entry_dir;
	GtkWidget *stop;
	GtkWidget *go;
	
	/*-- Obtener los widgets --*/
  entry_dir=glade_xml_get_widget(xml,"entry_dir");
	stop=glade_xml_get_widget(xml,"monitor_stop");
	go=glade_xml_get_widget(xml,"monitor_go");
	
	/*-- Establecer el estado */
	gtk_widget_set_sensitive(entry_dir,FALSE);  //-- Direccion desactivada
	gtk_widget_set_sensitive(go,FALSE);     //-- Boton de GO desactivado
	gtk_widget_set_sensitive(stop,TRUE);    //-- Boton de Stop activado
}

/*------------------------------------*/
/* Actualizar los widgets binarios    */
/*------------------------------------*/
void print_binario(GladeXML *xml, int valor)
{
  GtkWidget *label[8];
  gchar label_name[8][10]={
    "label_b0", "label_b1", "label_b2", "label_b3",
    "label_b4", "label_b5", "label_b6", "label_b7"
  };
  gchar cad[10];
  gboolean estado;
  int i;

  //-- Poner el valor en binario 
  for (i=0; i<8; i++) {

    //-- Actualizar las etiquetas de los botones binarios --
    label[i]=glade_xml_get_widget(xml,label_name[i]);
    if ((valor&0x01)==1) {
      sprintf(cad,"1");
      estado=TRUE;
    }
    else { 
      sprintf(cad,"0");
      estado=FALSE;
    }

    gtk_label_set_text(GTK_LABEL(label[i]),cad);  

    valor = (valor >> 1);
  }
}

/**************************************************************/
/*      FUNCIONES DE RETROLLAMADA                             */
/**************************************************************/


/*--------------------------------------*/
/* Cerrar la ventana de monitorizacion  */
/*--------------------------------------*/
void on_close_monitor_button_clicked(GtkWidget *widget, gpointer data)
{
	GladeXML *xml; 
	GtkWidget *entry_timer;
	GtkWidget *win;
	
	/*-- Obtener los widgets --*/
	xml=glade_get_widget_tree(widget); 
	win=glade_xml_get_widget(xml,"monitor_window");
	entry_timer=glade_xml_get_widget(xml,"entry_timer");
	
	//-- Parar el temporizador
	stop_timer(entry_timer);
	
	/*-- Destruir ventana de monitorizacion --*/
	gtk_widget_destroy(win);
	
}


/*---------------------------------------------------------*/
/* Funcion de Destruccion de la ventana de monitorizacion  */
/* Se elimina el temporizador, si es que estaba activo y   */
/* se termina                                              */
/*---------------------------------------------------------*/
gboolean on_monitor_window_destroy(GtkWidget *widget, gpointer data)
{
	GladeXML *xml;
	GtkWidget *entry_timer;
	
	/*-- Obtener el widget del timer --*/
	xml=glade_get_widget_tree(widget);
	entry_timer=glade_xml_get_widget(xml,"entry_timer");
	
	//-- Parar el temporizador
	stop_timer(entry_timer);
	
	return FALSE;
}

/*------------------------------------------*/
/* Acceder a la direccion para monitorizar  */
/* Funcion llamada por el temporizador      */
/*------------------------------------------*/
gboolean monitorizar(gpointer data)
{
	GladeXML *xml;
  GtkWidget *entry_hex;
  GtkWidget *entry_dec;
	GtkWidget *entry_timer;
  GtkWidget *analog;
  GtkWidget *entry;
	GtkWidget *app_bar;
  gchar cad[80];
  int dir;
	int valor;
	gdouble valor2;
	int status;
	
	//-- Puesto por seguridad. Si el puntero pasado no es un objeto...
	//-- Terminar... No se deberia cumplir en condiciones normales
	if (!G_IS_OBJECT(data)) {
		g_print("NO Es objeto!!!\n");
		return FALSE;
	}
	
	xml=glade_get_widget_tree(GTK_WIDGET(data)); 
	
	//-- Puesto por seguridad. En condiciones normales no se deberia
	//-- cumplir la condicion
	if (xml==NULL) {
		printf ("Destruido!!\n");
		return FALSE;
	}
	
  entry=glade_xml_get_widget(xml,"entry_dir");
	entry_hex=glade_xml_get_widget(xml,"entry_hex");
  entry_dec=glade_xml_get_widget(xml,"entry_dec");
	entry_timer=glade_xml_get_widget(xml,"entry_timer");
  analog=glade_xml_get_widget(xml,"analog");
	app_bar=glade_xml_get_widget(xml,"monitor_appbar");
		
	//-- Obtener la direccion de monitorizacion
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(entry)));
 
  if (cad4_to_xdigit(cad,&dir)) {
    sprintf(cad,"%04X",dir);
    gtk_entry_set_text(GTK_ENTRY(entry),cad);
  }
  else { //-- Error de sintaxis
    gtk_entry_set_text (GTK_ENTRY(entry),"0000");
		gtk_entry_set_text(GTK_ENTRY(entry_timer),"0");		
		gnome_appbar_set_status(GNOME_APPBAR(app_bar),"PARADO: Direccion errónea");
		interfaz_monitor_off(xml);
		return FALSE;
	}
	
	//-- Hacer el LOAD
  status=sg_load(dir,&valor);
  valor=(valor&0x00FF);

  //-- Ha ocurrido error... No se ha hecho el LOAD
	//-- Seguramente debido a que se perdio la conexion
  if (status!=1) {
		gnome_appbar_set_status(GNOME_APPBAR(app_bar),"PARADO: ERROR de acceso");
		gtk_entry_set_text(GTK_ENTRY(entry_timer),"0");	
    interfaz_monitor_off(xml);			
		return FALSE;
	}	
	
	/*------------------------------------------*/
  /* Actualizar los Widgets de monitorizacion */
  /*------------------------------------------*/
  /* Valor en hexa */
  sprintf (cad,"%02X",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_hex),cad);

  /* Entrada decimal */
  sprintf(cad,"%d",valor);
  gtk_entry_set_text(GTK_ENTRY(entry_dec),cad);

  /* Entrada binaria */
  print_binario(xml, valor);

  /* Entrada analogica */
	valor2=(((gdouble)(valor))/255)*100;
	gtk_progress_set_value (GTK_PROGRESS(analog), valor2);
	
	return TRUE;
}


/*--------------------------------------------*/
/* Funcion de retrollamada del boton GO       */
/* Se arranca el temporizador y su id se      */
/* guarda en el widget invisible entry_timer. */
/* Se actualiza el estado del interfaz        */
/*--------------------------------------------*/
void on_monitor_go_clicked(GtkWidget *widget, gpointer data)
{
	guint timer;
	GladeXML *xml;
	GtkWidget *entry_timer;
	GtkWidget *app_bar;
	gchar cad[80];
	
	/*-- Obtener los widgets --*/
	xml=glade_get_widget_tree(widget); 
	entry_timer=glade_xml_get_widget(xml,"entry_timer");
	app_bar=glade_xml_get_widget(xml,"monitor_appbar");
	
	/* Cambiar el estado del interfaz */
	interfaz_monitor_on(xml);
  gnome_appbar_set_status(GNOME_APPBAR(app_bar),"Monitorizando...");	
	
	/*-- Establecer la función periódica para realizar la monitorizacion --*/
  timer=gtk_timeout_add (200, monitorizar, widget);
	
	/*------------------------------------------------------------------*/
	/* El identificador del timer se almacena en un widget "invisible"  */
	/* Esto permite que cada ventana de monitorirzacion almacene        */
	/* su propia informacion, de modo que no hay que usar variables     */
	/* globales ni gestionar memoria                                    */
	/*------------------------------------------------------------------*/
  sprintf (cad,"%d",timer);
  gtk_entry_set_text(GTK_ENTRY(entry_timer),cad);	
}



/*-----------------------------------------------*/
/* Funcion de retrollamda cuando se pulsa ENTER  */
/* en la entrada de direccion.                   */
/* Se hace exactamente lo mismo que si se pulsa  */
/* el boton de GO!                               */
/*-----------------------------------------------*/
void on_entry_dir_monitor_activate(GtkWidget *widget, gpointer data)
{
	//-- Es equivalente a pulsar el boton de GO!
	on_monitor_go_clicked(widget,NULL);
}



/*------------------------------------------------*/
/* Funcion de retrollamada del boton de DETENCION */
/* Se para el temporizador y cambia el estado     */
/* del interfaz                                   */
/*------------------------------------------------*/
void on_monitor_stop_clicked(GtkWidget *widget, gpointer data)
{
	GladeXML *xml;
	GtkWidget *entry_timer;
  GtkWidget *app_bar;
	
	/*-- Obtener los widgets --*/
	xml=glade_get_widget_tree(widget);
  entry_timer=glade_xml_get_widget(xml,"entry_timer");	
	app_bar=glade_xml_get_widget(xml,"monitor_appbar");
	
	//-- Para el timer
	stop_timer(entry_timer);
	
	//-- Cambiar el interfaz al estado de PARADO
	interfaz_monitor_off(xml);
	
  //-- Informar del estado
  gnome_appbar_set_status(GNOME_APPBAR(app_bar),"PARADO");	
	
}
