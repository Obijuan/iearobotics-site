/************************************************************/
/* callback.h    (c) Juan Gonzalez Gomez. Agosto 2002       */
/*----------------------------------------------------------*/
/* This project is under GPL license                        */
/************************************************************/

#ifndef _CALLBACK_H
#define _CALLBACK_H

#include <gnome.h>

/*-----------------------------------------*/
/*-   Asociados a la ventana princiapl    -*/
/*-----------------------------------------*/
void on_main_window_destroy(GtkWidget *window, gpointer data);

/*-- Menu de About --*/
void on_about1_activate(GtkMenuItem *menuitem, gpointer user_data);

/*-- Combo de selecci�n del dispositivo serie --*/
void on_combo_serial_port_entry_changed(GtkWidget *widget, gpointer data);

/*-- Boton de acceso a ventana de monitorizacion --*/
void on_monitor_button_clicked(GtkWidget *widget, gpointer data);

/*-- Boton de acceso a ventana de controles genericos --*/
void on_control_button_clicked(GtkWidget *widget, gpointer data);

/*---------------------------------------*/
/*- Asociados a la ventana de controles  */
/*---------------------------------------*/

/*- Boton de LOAD --*/
void on_load_button_clicked(GtkWidget *widget, gpointer data);

/*- Boton de STORE --*/
void on_store_button_clicked(GtkWidget *widget, gpointer data);

/*-- Boton de close --*/
void on_close_button_clicked(GtkWidget *widget, gpointer data);

/*-------------------------------------------*/
/* Asociados a la ventana de monitorizacion  */
/*-------------------------------------------*/
/**-- Boton de close --*/
void on_close_monitor_button_clicked(GtkWidget *widget, gpointer data);

/*-- Entrada de direccion --*/
void on_entry_dir_monitor_activate(GtkWidget *widget, gpointer data);

/*-- Boton de GO --*/
void on_monitor_go_clicked(GtkWidget *widget, gpointer data);

gboolean on_monitor_window_destroy(GtkWidget *widget, gpointer data);


#endif /* _CALLBALLK_H */
