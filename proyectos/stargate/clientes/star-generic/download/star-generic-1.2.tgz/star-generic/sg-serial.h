/***********************************************/
/* sg-serial.h       Juan Gonzalez Gomez.     */
/*---------------------------------------------*/
/* Comunicaciones serie para clientes StarGate */
/* Licencia GPL                                */
/***********************************************/

#ifndef SG_SERIAL_H
#define SG_SERIAL_H


/*--------------------------*/
/* PROTOTIPOS DEL INTERFAZ  */
/*--------------------------*/

/********************************************/
/* Enviar una cadena por el puerto serie    */
/********************************************/
void sg_serial_enviar(int serial_fd, char *cadena, int tam);

/********************************************************************/
/* Abrir el puerto serie                                            */
/*------------------------------------------------------------------*/
/* ENTRADA:                                                         */
/*   disp: cadena con el dispositivo serie                          */
/*                                                                  */
/* DEVUELVE:                                                        */
/*   -El descriptor del puerto serie � -1 si ha ocurrido un error   */
/********************************************************************/
int sg_serial_open(char *disp);


#endif  /* del define SG_SERIAL_H */         
