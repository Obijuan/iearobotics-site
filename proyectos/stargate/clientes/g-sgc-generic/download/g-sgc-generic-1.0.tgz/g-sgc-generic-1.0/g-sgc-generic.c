/**********************************************************/
/* g-sgc-null.c    (c) Juan Gonzalez Gomez. Agosto  2003  */
/*--------------------------------------------------------*/
/* Cliente gr�fico para el StarGate Nulo                  */
/*--------------------------------------------------------*/
/* Licencia GPL.                                          */
/* mail: juan@iearobotics.com                             */
/**********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"
#include "sg-serial.h"
#include "sg-tramas.h"


/*------------------------*/
/*    CONSTANTS           */
/*------------------------*/
#define VERSION "1.0"

/*--------------------*/
/*    PROTOTIPOS      */
/*--------------------*/

/*---------------*/
/* VARIABLES     */
/*---------------*/
static gchar app_id[] = {"G-SGC-GENERIC"};
interface_t interface;
int serial_fd;  /*-- Descriptor puerto serie */
int estado_conexion=0;
int direccion=0;
int valor=0;
int global_is=0;  //-- Identificacion del servidor

/**************************/
/* Parametros de usuario  */
/**************************/
static gboolean flag;

/* Parámetros de usuario */
struct poptOption options[]={
  {"flag",'h',POPT_ARG_NONE, &flag, 0, "Activar la opcion Flag", NULL},
  {NULL, '\0', 0, NULL, 0, NULL, NULL}
};

/*----------------------------*/
/* FUNCIONES PARA LA CONSOLA  */
/*----------------------------*/

/*-------------------------*/
/* CALLBACK FUNCTIONS      */
/*-------------------------*/
void main_quit(GtkWidget *window, gpointer data)
{

  printf ("Cerrando puerto serie...\n");

  /* Cerrar puerto serie */
  close(serial_fd);

  /* Terminar */
  gtk_main_quit();
}

void id()
{
  static gchar cad[80];
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    sprintf (cad, "SG-%s-%s-%s-%d",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    global_is=is;
    break;
  default:
    sprintf (cad,"UNKNOW");
  }
  
  gtk_entry_set_text (GTK_ENTRY(interface.entry_id_server),cad);
  
}

/**************************/
/* Analizar la direccion  */
/**************************/
int parse_dir()
{
  gchar cad[80];
  int n;
  int dir;

  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(interface.entry_dir)));
  n=sscanf(cad, "%x",&dir);
  if (n==1) {
    direccion=dir;
    return 1;
  }
  else {
    direccion=0;
    gtk_entry_set_text (GTK_ENTRY(interface.entry_dir),"");
  }

  return 0;

}

/**************************/
/* Analizar el valor      */
/**************************/
int parse_valor()
{
  gchar cad[80];
  int n;
  int val;

  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(interface.entry_valor)));
  n=sscanf(cad, "%x",&val);
  if (n==1) {
    valor=val;
    return 1;
  }
  else {
    valor=0;
    gtk_entry_set_text (GTK_ENTRY(interface.entry_valor),"");
  }

  return 0;

}

void load(void)
{
  char cad[80];
  int okdir;
  int status;
  int val;

  //-- Analizar si la direccion pasada es correcta. En caso de ser
  //-- as� la funcion parse_dir() la deja en la variable global direccion
  okdir=parse_dir();
  if (okdir==1) {
    //-- Hacer el load
    status=sg_load(direccion,&val);
    if (status==1) {
      sprintf (cad,"%hhx",val);
      gtk_entry_set_text (GTK_ENTRY(interface.entry_valor),cad);
    }
  }
}

void store(void)
{
  int okdir;
  int okval;

  //-- Analizar si las direcciones y los valores son correctos
  //-- Los valores obtenidos se dejan en las variales globales
  //-- direccion y valor
  okdir=parse_dir();
  okval=parse_valor();
  if (okdir && okval) {
    //-- Solo si son correctos se hace el store
    sg_store(direccion,valor);
  }  
}


void main_button(GtkWidget *widget,gpointer data)
/********************************************/
/* Funcion de retrollamada de los botones   */
/********************************************/
{
  gint n;

  /* Obtener el numero del boton */
  n=atoi((char *)data);

  switch(n) {
  case 1: /* Identificacion */
    id();
    break;
  case 2: /* Load */
    load();  
    break;
  case 3: /* Store */
    store();
    break;
  default: 
    g_print ("Boton: %d\n",n);
  }
  
}

/***********************************************/
/* Funcion de retrollamada de las entradas     */
/***********************************************/
void main_entry(GtkWidget *widget, gpointer data)
{
  gchar cad[80];
  gint boton;

  /* Obtener el numero del boton */
  boton=atoi((char *)data);
  strcpy(cad,gtk_entry_get_text(GTK_ENTRY(widget)));

  switch(boton) {
  case 1: //--Direccion
    //-- De momento no se usa. Futuros usos
    break;
  case 2:  //--Valor
    //-- Comprobar si la direccion que hab�a antes es correcta.
    //-- Si es as�, la presi�n del bot�n ENTER cuando se est� en 
    //-- la casilla de valor se interpreta como un store
    store();
    break;
  default: 
    g_print ("Entrada: %d\n",boton);
  }
 
}

void main_toggle_button(GtkWidget *widget, gpointer data)
/************************************************/
/* Funcion de retrollamada de botones "toggle"  */
/************************************************/
{
  int n;
  
  /* Obtener el numero del boton */
  n=atoi((char *)data);

  g_print ("Toggle: %d\n",n);     
}


gboolean comprobar_conexion()
{
  int status;

  status=sg_ping();

  //-- Ahora status s�lo vale 0 � 1. Si vale 0 es que
  //-- no se ha establecido conexi�n, bien por timeout
  //-- o bien por error.
  status=(status==1)?1 : 0;


  //-- Si la conexi�n se ha recuperado...
  if (estado_conexion!=status && status==1) {
    //-- Obtener la informaci�n del servidor
    id();
 
    //-- Actualizar el icono que indica el estado 
    gtk_image_set_from_file (GTK_IMAGE(interface.imagen_estado_conexion),
			     "on.xpm");
    gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
			    "ON-LINE");

    //-- Activar el panel de LOAD y STORE s�lo si es el
    //-- servidor gen�rico
    if (global_is==SG_GENERIC) {
      gtk_widget_set_sensitive (interface.frame_load_store, TRUE);
    }
  }

  //-- Si la conexi�n se ha perdido...
  if (estado_conexion!=status && status==0) {

    //-- Actualizar icono que indica el estado
    gtk_image_set_from_file (GTK_IMAGE(interface.imagen_estado_conexion),
			     "off.xpm");
    gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),
			    "OFF-LINE");

    //-- Desactivar panel de LOAD y STORE
    gtk_widget_set_sensitive (interface.frame_load_store, FALSE);
  }

  /* Guardar estado de la conexi�n */
  estado_conexion=(status==1) ?1 : 0;
  
  return TRUE;
}

void help_about (GtkMenuItem *menuitem, gpointer user_data)
/*************************************/
/*  Mostrar la ventana de "ABOUT"    */
/*************************************/
{
  GtkWidget *about = NULL;

  about = interface_create_about();
  gtk_widget_show (about);
}

/*-------------------------------------------------*/
/*     P R O G R A M A    P R I N C I P A L        */
/*-------------------------------------------------*/
gint main (gint argc, gchar *argv[])
{
  poptContext contexto;

  /* Inicializar GNOME, con los parametros del usuario */
  gnome_init_with_popt_table (app_id, VERSION, argc,argv, 
 		              options, 0, &contexto);
  poptFreeContext (contexto);

  /*-- Comprobar parametros de usuario --*/
  if (flag) g_print ("Opcion Flag....\n");

  /*-- Inicializar GLADE -- */
  glade_gnome_init();

  /*------------------------*/
  /*  Crear el interfaz     */
  /*------------------------*/
  /* Obtener los widgets del fichero XML */
  interface_create_app(&interface);

  /* Conectar las se�ales de retrollamada */
  interface_connect_signals(&interface);

  /*------------------------------*/
  /* Inicializar el puerto serie  */
  /*------------------------------*/
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);

  /*-------------------------*/
  /* Inicializar el interfaz */
  /*-------------------------*/
  gnome_appbar_set_status(GNOME_APPBAR(interface.app_bar),"Inicio");

  /*--------------------------------------*/
  /* Inicializar estado de la aplicacion  */
  /*--------------------------------------*/
  estado_conexion=0;

  /*-- Establecer la funci�n peri�dica para comprobar la conexi�n --*/
  gtk_timeout_add (500, comprobar_conexion, NULL);
  
  /*-- Que comience la fiesta!!!! -- */
  gtk_main();

  return 0;
}


