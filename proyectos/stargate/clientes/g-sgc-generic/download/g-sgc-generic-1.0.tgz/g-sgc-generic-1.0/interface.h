/***********************************************************/
/* interface.h   (c) Juan Gonz�lez G�mez. Agosto 2002      */
/*---------------------------------------------------------*/
/* Licencia GPL                                            */
/***********************************************************/
#ifndef _INTERFACE_H
#define _INTERFACE_H

#include <gnome.h>

/*-----------------------*/
/* ESTRUCTURAS DE DATOS  */
/*-----------------------*/

/* ---- Estructura de datos del interfaz ---- */
typedef struct interface_s {
  GtkWidget *main_window;   /* Ventana principal                */
  GtkWidget *app_bar;       /* Barra de aplicaciones            */

  /*-- Barra de herramientas -- */
  GtkWidget *tool_salir;          /* Salir            */
  GtkWidget *tool_identificacion; /* Identificacion   */

  /*-- Menu File ---*/
  GtkWidget *file_quit;  /* Salir  */

  /*-- Menu acciones --*/
  GtkWidget *acciones_identificacion;  /* Identificacion */

  /*-- Entradas de datos --*/
  GtkWidget *entry_dir;
  GtkWidget *entry_valor;

  /*-- FRAME LOAD Y STORE --*/
  GtkWidget *frame_load_store;

  /*-- Botones LOAD y STORE --*/
  GtkWidget *boton_load;
  GtkWidget *boton_store;

  /*-- Identificacion del servidor --*/
  GtkWidget *entry_id_server;

  /*-- Imagen que indica el estado de la conexi�n --*/
  GtkWidget *imagen_estado_conexion;

  /*-- Menu Help --*/
  GtkWidget *help_about;        /* About  */

} interface_t;

/*--------------*/
/* PROTOTIPOS   */
/*--------------*/
void interface_create_app(interface_t *ifaz);
/***********************************************/
/*  Crear el interfaz de la ventana principal  */
/*  S�lo se debe llamar una vez a esta funcion */
/***********************************************/

void interface_connect_signals(interface_t *ifaz);
/*******************************************/
/* Conectar las se�ales de retrollamada    */
/*******************************************/

GtkWidget *interface_create_about();
/********************************/
/* Crear la ventana de ABOUT    */
/********************************/

#endif  /* _INTEFACE_H */
