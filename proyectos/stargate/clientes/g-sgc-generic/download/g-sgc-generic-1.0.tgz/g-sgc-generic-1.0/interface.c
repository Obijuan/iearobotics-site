/*********************************************************/
/* interface.c    (c) Juan Gonz�lez G�mez. Agosto 2002   */
/*-------------------------------------------------------*/
/* Crear el interfaz del modulo g-scterm                 */
/* Licencia GPL                                          */
/*-------------------------------------------------------*/
/* mail: juan@iearobotics.com                            */
/*********************************************************/

#include <gnome.h>
#include <glade/glade.h>

#include "interface.h"
#include "callback.h"

//-- Nombre del fichero con el interfaz 
#define FICHERO_GLADE "g-sgc-generic.glade"

void interface_create_app(interface_t *ifaz)
/***********************************************/
/*  Crear el interfaz de la ventana principal  */
/*  S�lo se debe llamar una vez a esta funcion */
/***********************************************/
{
  GladeXML *xml;
  
  /* Inicializar la estructura del interfaz */
  ifaz->main_window=NULL;
  ifaz->app_bar=NULL;
  ifaz->tool_salir=NULL;
  ifaz->tool_identificacion=NULL;
  ifaz->file_quit=NULL;
  ifaz->acciones_identificacion=NULL;
  ifaz->help_about=NULL;
  ifaz->entry_id_server=NULL;
  ifaz->entry_dir=NULL;
  ifaz->entry_valor=NULL;
  ifaz->boton_load=NULL;
  ifaz->boton_store=NULL;
  ifaz->frame_load_store=NULL;

  /* Leer el interfaz en XML */
  xml = glade_xml_new (FICHERO_GLADE, "app1", "Dominio");

  /*-------------------------------------*/
  /* Rellenar la estructura del interfaz */
  /* Con los widgets del fichero XML     */
  /*-------------------------------------*/
  /* Ventana principal */
  ifaz->main_window=glade_xml_get_widget(xml,"app1");
  /*-- STATUS BAR -- */
  ifaz->app_bar=glade_xml_get_widget(xml,"appbar1");

  /* Widget para la BARRA DE HERRAMIENTAS */
  ifaz->tool_salir=glade_xml_get_widget(xml,"tool_salir");
  ifaz->tool_identificacion=
    glade_xml_get_widget(xml,"tool_identificacion");

  /*-- MENU FILE --*/
  ifaz->file_quit = glade_xml_get_widget (xml, "file_quit");

  /*-- MENU ACCIONES --*/
  ifaz->acciones_identificacion = 
    glade_xml_get_widget (xml,"acciones_identificacion");

  /*-- MENU HELP --*/
  ifaz->help_about = glade_xml_get_widget (xml, "help_about");

  /*-- IDENTIFICACION SERVIDOR --*/
  ifaz->entry_id_server = glade_xml_get_widget (xml, "entry_id_server");

  /*-- IMAGEN QUE INDICA EL ESTADO DE LA CONEXION --*/
  ifaz->imagen_estado_conexion =
    glade_xml_get_widget(xml,"imagen_estado_conexion");

  /*-- FRAME LOAD-STORE --*/
  ifaz->frame_load_store=glade_xml_get_widget(xml,"frame_load_store");

  /*--- ENTRADAS DE DATOS --*/
  ifaz->entry_dir=glade_xml_get_widget(xml,"entry_dir");
  ifaz->entry_valor=glade_xml_get_widget(xml,"entry_valor");

  /*--- BOTONES LOAD Y STORE --*/
  ifaz->boton_load=glade_xml_get_widget(xml,"boton_load");
  ifaz->boton_store=glade_xml_get_widget(xml,"boton_store");


  /*-----------------------*/
  /* Liberar el objeto xml */
  /*-----------------------*/
  g_object_unref (xml);

  /* Mostrar todos los widgets */
  gtk_widget_show_all(ifaz->main_window);
}

void interface_connect_signals(interface_t *ifaz)
/*******************************************/
/* Conectar las se�ales de retrollamada    */
/*******************************************/
{
  /* --- Se�al de DESTRUCCION --- */
  g_signal_connect (G_OBJECT (ifaz->main_window), "destroy",
		    G_CALLBACK (main_quit), NULL);

  /* -- BARRA DE HERRAMIENTAS -- */
  g_signal_connect (G_OBJECT(ifaz->tool_salir),"clicked",
		    G_CALLBACK(main_quit),"1");

  g_signal_connect (G_OBJECT(ifaz->tool_identificacion),"clicked",
		    G_CALLBACK(main_button),"1");

  /*-- MENU FILE --*/
  g_signal_connect (G_OBJECT(ifaz->file_quit), "activate",
		    G_CALLBACK(main_quit),NULL);

  /*-- MENU ACCIONES --*/
  g_signal_connect (G_OBJECT(ifaz->acciones_identificacion),"activate",
		    G_CALLBACK(main_button),"1");

  /*-- MENU HELP --*/
  g_signal_connect (G_OBJECT(ifaz->help_about),"activate",
		    G_CALLBACK(help_about),NULL);

  /*-- BOTONES LOAD Y STORE --*/
  g_signal_connect (G_OBJECT(ifaz->boton_load),"clicked",
		    G_CALLBACK(main_button),"2");
  g_signal_connect (G_OBJECT(ifaz->boton_store),"clicked",
		    G_CALLBACK(main_button),"3");

  /*-- ENTRADAS DE DATOS --*/
  g_signal_connect (G_OBJECT(ifaz->entry_dir),"activate",
		    G_CALLBACK(main_entry),"1");
  g_signal_connect (G_OBJECT(ifaz->entry_valor),"activate",
		    G_CALLBACK(main_entry),"2");

}

GtkWidget *interface_create_about()
/*********************************/
/* Crear la ventana de about     */
/*********************************/
{
  GladeXML *xml;
  GtkWidget *about;

  xml = glade_xml_new (FICHERO_GLADE, "about1","dominio");
  about = glade_xml_get_widget (xml, "about1");

  g_object_unref(xml);

  return about;
}

