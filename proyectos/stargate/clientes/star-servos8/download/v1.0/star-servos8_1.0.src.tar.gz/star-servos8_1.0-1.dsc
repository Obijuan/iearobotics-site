Format: 1.0
Source: star-servos8
Version: 1.0-1
Binary: star-servos8
Maintainer: Juan Gonzalez <juan@iearobotics.com>
Architecture: any
Standards-Version: 3.6.1
Build-Depends: debhelper (>= 4.0.0), libstargate-dev (>=1.0.1-1), libart-2.0-dev (>= 2.3.16-6 ), libatk1.0-dev (>= 1.8.0-4 ),libbonobo2-dev (>= 2.8.0-4 ), libbonoboui2-dev (>= 2.8.0-2 ), libc6-dev (>= 2.3.2.ds1-20 ),libgconf2-dev (>= 2.8.1-4 ), libglade2-dev (>= 1 ), libglib2.0-0 (>= 2.4.8-1), libglib2.0-dev (>= 2.4.8-1 ), libgnome2-dev (>= 2.8.0-6 ),libgnomecanvas2-dev (>= 2.8.0-1 ),libsigc++-2.0-dev (>= 2.0.6-1 ),libgnomeui-dev (>= 2.8.0-3 ), libgnomevfs2-dev (>= 2.8.3-7 ), libgtk2.0-dev(>= 2.4.14-2 ), libncurses5 (>= 5.4-4 ), liborbit2-dev (>= 1 ),libpango1.0-dev (>= 1.6.0-3 )libart-2.0-dev (>= 2.3.16-6 ), libatk1.0-dev(>= 1.8.0-4 ),libbonobo2-dev (>= 2.6.11-5)
Files: 
 0c64d240bf2c11727697ed1ca7922d1b 381769 star-servos8_1.0.orig.tar.gz
 e4ef80293230e01b302ae914e6fdc102 21485 star-servos8_1.0-1.diff.gz
