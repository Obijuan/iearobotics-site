/**************************************************************************/
/* posicion.h  Juan Gonzalez Gomez.   Enero 2005                          */
/*------------------------------------------------------------------------*/
/* Datos y prototipos para el modulo posicion.h                           */
/**************************************************************************/

#ifndef _POSICION_H
#define _POSICION_H

#include <glade/glade.h>

/*-------------*/
/* PROTOTIPOS  */
/*-------------*/
void posicion_servos(vector_pos_t *v);
void posicion_servo(int servo, int pos);

/***************************************************************/
/* Inicializar el modulo de posicionamiento. Se debe llamar    */
/* al abrir la ventana                                         */
/***************************************************************/
void posicion_init(GladeXML *xml);


#endif  /* _POSICION_H */
