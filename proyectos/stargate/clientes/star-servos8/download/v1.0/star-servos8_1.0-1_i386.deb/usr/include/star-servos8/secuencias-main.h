/**************************************************************************/
/* secuencias-main.h  Juan Gonzalez Gomez.   Diciembre 2004               */
/*------------------------------------------------------------------------*/
/* Datos y prototipos para el modulo secuencias-mai.h                     */
/**************************************************************************/

#ifndef _SECUENCIAS_MAIN_H
#define _SECUENCIAS_MAIN_H

/*-------------*/
/* PROTOTIPOS  */
/*-------------*/

void secuencias_win_init(GtkWidget *win);
void secuencias_win_exit();
void sec_status(GladeXML *xml, const char *cad);

#endif  /* _SECUENCIAS_MAIN_H */
