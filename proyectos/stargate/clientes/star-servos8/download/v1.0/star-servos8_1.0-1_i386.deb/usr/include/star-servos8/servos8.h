/****************************************************************/
/* servos8.h   (c) Juan Gonzalez Gomez. Mayo 2004               */
/*--------------------------------------------------------------*/
/* LICENCIA GPL                                                 */
/****************************************************************/

#ifndef _SERVOS8_H
#define _SERVOS8_H

#include "vectores.h"

/***************************************************/
/* Posicionamiento de un servo, en grados          */
/* ENTRADAS:                                       */
/*   -servo: numero de servo (1-8)                 */
/*   -pos  : Posicion del servo (-90,90)           */
/*   -transparente: Acceso en modo transparente.   */
/*     Si se activa este modo, se envia la posicion*/
/*     directamente al servo, como si esta capa    */
/*     intermedia no existiese. Si se desactiva,   */
/*     solo se envia la posicion si es diferente   */
/*     de la actual                                */
/***************************************************/
void servos8_pos1(int servo, int pos, int transparente);

/********************************************/
/* Leer la posicion del servo especificado  */
/********************************************/
int servos8_pos1_read(int servo);

/***************************************************************/
/* Leer la posicion de los 8 servos y devolverla en un vector  */
/* El vector se debe crear antes de llamar a la funcion        */
/***************************************************************/
void servos8_pos8_read(vector_pos_t *v);

/********************************************************/
/* Posicionamiento de los 8 servos, en grados           */
/********************************************************/
void servos8_pos8(int s1, int s2, int s3, int s4,
                  int s5, int s6, int s7, int s8, int transparente);
									
/************************************************************/
/* Posicionamiento de los 8 servos, mediante un vector      */
/************************************************************/
void servos8_pos_vector(vector_pos_t *v, int transparente);

/**********************************************/
/* Servicio de HABILITACION de los servos     */
/**********************************************/
void servos8_enable(int mask, int transparente);

/***************************************/
/* Devolver la mascara de habilitacion */
/***************************************/
int servos8_enable_read();

#endif
