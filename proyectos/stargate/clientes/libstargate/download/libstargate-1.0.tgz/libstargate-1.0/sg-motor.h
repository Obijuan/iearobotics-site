/**********************************************/
/* sg-motor.h       Juan Gonzalez Gomez.      */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/


#ifndef SG_MOTOR_H
#define SG_MOTOR_H

#include "sg-tramas.h"

/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/*******************************************************************/
/* Servicio ID                                                     */
/*-----------------------------------------------------------------*/
/* ENTRADAS: Ninguna                                               */
/* SALIDAS:                                                        */
/*   is: Identificaci�n del servidor                               */
/*   im: Identificacion del micro                                  */
/*   ipv: Identificaci�n placa y versi�n servidor                  */
/*                                                                 */
/* DEVUELVE:                                                       */
/*   1: OK                                                         */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_id(byte *is, byte *im, byte *ipv);

/*******************************************************************/
/* Servicio PING                                                   */
/*                                                                 */
/* ENTRADAS: Ninguna                                               */
/* SALIDAS: Devuelve                                               */
/*   1: Ping recibido correctamente                                */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_ping(void);

/*************************************************/
/* Inicializar el motor del StarGate             */
/*************************************************/
void sgm_motor_init(int fd);

#endif  // SG_MOTOR_H

