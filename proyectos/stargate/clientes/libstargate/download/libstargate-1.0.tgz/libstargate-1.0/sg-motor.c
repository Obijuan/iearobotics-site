/**********************************************/
/* sg-motor.c        Juan Gonzalez Gomez.     */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>

#include "sg-serial.h"
#include "sg-tramas.h"
#include "sg-motor.h"

/***********************************/
/*             VARIABLES           */
/***********************************/
/*---------------------------------------------------*/
/* Sincronizacion entre hilos clientes e hilo motor  */
/*---------------------------------------------------*/

//-- Protecci�n de la peticion al motor: solicitud+respuesta
static pthread_mutex_t peticion_mutex=PTHREAD_MUTEX_INITIALIZER;

//*********  SOLICITUD ***************
//-- Protecci�n de la solicitud
static pthread_mutex_t req_mutex = PTHREAD_MUTEX_INITIALIZER;

//-- Condici�n. Indica cuando se puede realizar la solicitud
static pthread_cond_t  req_cv = PTHREAD_COND_INITIALIZER;

//-- Variable de solicitud
static int  req;  //   req=0--> No hay solicitud
                  //   req=1--> Hay solicitud

//-- Datos de la solicitud
static sg_trama_t *req_data;  //-- Servicio solicitado al motor

//********** RESPUESTA ****************
//-- Proteccion de la respuesta
static pthread_mutex_t resp_mutex= PTHREAD_MUTEX_INITIALIZER;

//-- Condicion para la espera de la respuesta
static pthread_cond_t  resp_cv = PTHREAD_COND_INITIALIZER;

//-- Variable de respuesta
static int  resp;      //-- resp=0 --> No hay respuesta
                       //-- resp=1 --> Respuesta lista

//-- Datos de la respuesta
static sg_trama_t *resp_data;


/*------------------*/
/* Otras variables  */
/*------------------*/
static int       serial_fd;  /*-- Descriptor puerto serie */
static pthread_t motor_id;


/***************************************/
/* PROTOTIPOS FUNCIONES PRIVADAS       */
/***************************************/
static void motor(void);
static void sg_servicio_req(sg_trama_t *trama_req, sg_trama_t *trama_resp);


/*******************************************************/
/*        F U N C I O N E S   P R I V A D A S          */
/*******************************************************/

/******************************************************/
/* Enlace entre el motor y el servicio id             */
/*----------------------------------------------------*/
/* Se solicita el servicio y se devuelve los datos    */
/* de la forma en que el motor lo precisa             */
/*                                                    */
/* SALIDA:                                            */
/*   trama_resp: Datos devueltos                      */
/******************************************************/
static void id(sg_trama_t *trama_resp)
{
  int status;
  byte is, im, ipv;

  //-- Solicitar ID al StarGate
  status=sg_id(&is, &im, &ipv);

  //-- Devolver los datos de respuesta
  switch(status) {
  case 1: //-- OK
    trama_resp->it=TRAMA_RID_IT;
    trama_resp->status=1;
    trama_resp->data.resp_id.is=is;
    trama_resp->data.resp_id.im=im;
    trama_resp->data.resp_id.ipv=ipv;
    break;
  case -1://-- ERROR
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=-1;
    break;
  case 0: //-- TIMEOUT
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=0;
    break;
  default:  //-- Aqu� nunca deber�a llegar
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=-1;
  }
}



/******************************************************/
/* Enlace entre el motor y el servicio ping           */
/*----------------------------------------------------*/
/* Se solicita el servicio y se devuelve los datos    */
/* de la forma en que el motor lo precisa             */
/*                                                    */
/* SALIDA:                                            */
/*   trama_resp: Datos devueltos                      */
/******************************************************/
static void ping(sg_trama_t *trama_resp)
{
  int status;

  //-- Solicitar PING al StarGate
  status=sg_ping();

  //-- Devolver los datos de respuesta
  switch(status) {
  case 1: //-- OK
    trama_resp->it=TRAMA_PONG_IT;
    trama_resp->status=1;
    break;
  case -1://-- ERROR
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=-1;
    break;
  case 0: //-- TIMEOUT
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=0;
    break;
  default:  //-- Aqu� nunca deber�a llegar
    trama_resp->it=TRAMA_UNKNOW_IT;
    trama_resp->status=-1;
  }
}


/*--------------------------------*/
/* Hilo Motor                     */
/* -------------------------------*/
static void motor(void)
{
  sg_trama_t trama_resp;


  for (;;) {
    //-- Esperar a que vengan peticiones
    pthread_mutex_lock(&req_mutex);
    if (req==0) pthread_cond_wait(&req_cv,&req_mutex);

    //-- Procesar la peticion
    switch(req_data->it) {
      case TRAMA_PING_IT: //-- Se solicita PING
	ping(&trama_resp);
	break;
      case TRAMA_ID_IT:  //-- Servicio ID
	id(&trama_resp);
	break;
      default: //--Aqu� no deber�a llegar
	printf ("[Peticion incorrecta!!]\n");
    }
 
    //-- Se�alizar que ya hay respuesta
    pthread_mutex_lock(&resp_mutex);
    resp=1;
        //-- Devolver la respuesta
    memcpy (resp_data, &trama_resp, sizeof(sg_trama_t)); 
    pthread_cond_signal(&resp_cv);
    pthread_mutex_unlock(&resp_mutex);

    //-- Se�alizar peticion realizada
    req=0;
    pthread_mutex_unlock(&req_mutex);
  }

}


/******************************************************/
/* Solicitud de servicios al motor                    */
/*----------------------------------------------------*/
/* ENTRADA:                                           */
/*   trama_req: Datos de la trama a enviar            */
/*                                                    */
/* SALIDA:                                            */
/*   trama_resp: Datos de respuesta                   */
/******************************************************/
static void sg_servicio_req(sg_trama_t *trama_req, sg_trama_t *trama_resp)
{
  //-- Proteger la peticion completa
  pthread_mutex_lock(&peticion_mutex);

  //-- Solicitar el servicio
  pthread_mutex_lock(&req_mutex);
  req=1;
  req_data=trama_req;   //-- Pasar direccion con los datos de solicitudd
  resp_data=trama_resp; //-- Pasar direccion donde dejar la respuesta
  pthread_cond_signal(&req_cv);
  pthread_mutex_unlock(&req_mutex);

  //-- Esperar a que llegue la respuesta
  pthread_mutex_lock(&resp_mutex);
  if (resp==0) pthread_cond_wait(&resp_cv,&resp_mutex);
  // La respuesta se encuentra en trama_resp
  resp=0;
  pthread_mutex_unlock(&resp_mutex);

  //-- Desproteger la peticion: que otros hilos accedan
  pthread_mutex_unlock(&peticion_mutex);
}


/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/*******************************************************************/
/* Servicio ID                                                     */
/*-----------------------------------------------------------------*/
/* ENTRADAS: Ninguna                                               */
/* SALIDAS:                                                        */
/*   is: Identificaci�n del servidor                               */
/*   im: Identificacion del micro                                  */
/*   ipv: Identificaci�n placa y versi�n servidor                  */
/*                                                                 */
/* DEVUELVE:                                                       */
/*   1: OK                                                         */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_id(byte *is, byte *im, byte *ipv)
{
  sg_trama_t trama_req;
  sg_trama_t trama_resp;

  //-- Crear la estructura de datos de la trama
  trama_req.it=TRAMA_ID_IT;
  trama_req.status=0;
  
  //-- Solicitar servicio al motor
  sg_servicio_req(&trama_req, &trama_resp);

  //-- Obtener la respuesta
  if (trama_resp.status==1) {
    *is=trama_resp.data.resp_id.is;
    *im=trama_resp.data.resp_id.im;
    *ipv=trama_resp.data.resp_id.ipv;
  }

  //-- Devolver la respuesta
  return trama_resp.status;
}

/*******************************************************************/
/* Servicio PING                                                   */
/*                                                                 */
/* ENTRADAS: Ninguna                                               */
/* SALIDAS: Devuelve                                               */
/*   1: Ping recibido correctamente                                */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_ping(void)
{
  sg_trama_t trama_req;
  sg_trama_t trama_resp;

  //-- Crear la estructura de datos de la trama
  trama_req.it=TRAMA_PING_IT;
  trama_req.status=0;
  
  //-- Solicitar servicio al motor
  sg_servicio_req(&trama_req, &trama_resp);

  //-- Devolver la respuesta
  return trama_resp.status;
}

/*************************************************/
/* Inicializar el motor del StarGate             */
/*************************************************/
void sgm_motor_init(int fd)
{
  //-- Inicializar el descriptor serie
  serial_fd=fd;

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(fd);

  //-- Lanzar el hilo Motor
  pthread_create(&motor_id, NULL, (void *)motor,NULL);
}


