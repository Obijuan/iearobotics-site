/**********************************************/
/* sgc-null.c        Juan Gonzalez Gomez.     */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>

#include "sg-serial.h"
#include "sg-motor.h"


/***********************************/
/*             VARIABLES           */
/***********************************/

/*-- configuracion de la consola --*/
static struct termios oldconsola,consola;

/*****************************/
/*    FUNCIONES              */
/*****************************/

int config_consola()
/*************************************************************/
/* Configurar la consola                                     */
/*************************************************************/
{
  /* Leer los parametros asociados a la consola */
  if (tcgetattr(STDIN_FILENO,&consola)==-1) {
    perror("Error en tcgetattr");
    return -1;
  }
  oldconsola = consola; /* Almacenar parametros para su posterior recup. */
  
  /* Cambiar parametros */
  consola.c_cc[VMIN]=1;
  consola.c_lflag&=~(ECHO|ICANON); 
  
  if (tcsetattr(STDIN_FILENO,TCSANOW,&consola)==-1) {
    perror("Error en tcsetattr");
    return -1;
  }
  
  return 0;
}

void reset_consola()
/**********************************************/
/* Reestablecer la consola anterior           */
/**********************************************/
{
  if (tcsetattr(STDIN_FILENO,TCSANOW,&oldconsola)==-1) 
    perror("Error en tcsetattr");
}


int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sgm_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

void ping()
{
  int status;

  status=sgm_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}


/*--------------------------------*/
/* Hilo 1: Pendiente del teclado  */
/* -------------------------------*/
void leer_teclado(void)
{
  char c;

  printf ("\n");
  printf ("Men� de Opciones\n");
  printf ("----------------\n");
  printf ("1.-   PING\n");
  printf ("2.-   IDENTIFICACION\n");
  printf ("ESC.- Terminar\n\n");

  do {
    //-- Leer caracter
    fread(&c,1,1,stdin);
    switch(c) {
    case '1': 
      ping();
      break;
    case '2':
      id();
      break;
    }
  } while (c!=27);
  
}


/******************************/
/* Hilo de prueba             */
/******************************/
void check_conexion()
{
  char barra[]={'\\','|','/','-'};
  int status;
  int i=0;

  for (;;) {
    status=sgm_ping();
    if (status==1) {
      printf ("%c\b",barra[i]);
      i=(i+1)%4;
      fflush(stdout);
    }
    
    //-- Esperar hasta hacer otra peticion
    usleep(100000);
  }
}


static void inicio()
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Cliente de prueba para servidor Nulo\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexi�n establecida\n");
  else printf ("Conexi�n NO establecida\n\n");

}


int main (void)
{
  pthread_t tarea1;
  pthread_t tarea2;
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Configurar la consola
  config_consola();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el motor
  sgm_motor_init(serial_fd);
  
  //-- Conexi�n inicial
  inicio();

  //--------- Lanzar los hilos ----------
  //-- Un hilo pendiente del teclado
  pthread_create(&tarea1, NULL, (void *)leer_teclado, NULL);
  //-- Otro hilo hace constantemente PINGs
  pthread_create(&tarea2, NULL, (void *)check_conexion, NULL);

  //-- Esperar a que termine hilo del teclado 
  pthread_join(tarea1,NULL);

  //-- Consola a su estado inicial
  reset_consola();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}

