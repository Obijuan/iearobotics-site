/********************************************************/
/* test-generic-hilos.c        Juan Gonzalez Gomez.     */
/*------------------------------------------------------*/
/* Licencia GPL                                         */
/********************************************************/
/*------------------------------------------------------------------------
 $Id: test-generic-hilos.c,v 1.1 2004/07/07 17:48:28 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/stargate/clientes/libstargate-1.0/src/test-generic-hilos.c,v $
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <termios.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>

#include "stargateh.h"
#include "consola_io.h"
#include "animatxt.h"

//-- Dispositivo serie a utilizar
char disp_serie[255];

/****************/
/* CONSTANTES   */
/****************/

//-------------------------------------------------------
//-- Cambiar estos valores segun las pruebas a realizar
//-------------------------------------------------------

//-- Direccion de donde hacer LOAD
#define DIR_LOAD 0x06

//-- Direccion de donde hacer STORE 
#define DIR_STORE 0x06

//-- Valor para el STORE (1)
#define DATA_STORE1 0x1C

//-- Valor para el STORE (2)
#define DATA_STORE2 0x00

/******************************************/
/* Acceder al servicio de identificacion  */
/******************************************/
int id(void)
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sgm_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}


/******************/
/* Opcion de PING */
/******************/
void ping()
{
  int status;

  status=sgm_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}

/*********************/
/* Opcion de STORE   */
/*********************/
void store(int dir, int valor)
{
  int status;

  status=sgm_store(dir,valor);
  if (status==1) printf ("Store OK\n");
  else printf ("Error en Store. Status: %d\n",status);
}

/********************/
/* Opcion de LOAD   */
/********************/
void load(int dir)
{
  int status;
  int valor;

  status=sgm_load(dir,&valor);
  valor=(valor&0xFF);
  if (status==1) printf ("Load OK. Valor: %x\n",valor);
  else printf ("Error en Load. Status: %d\n",status);

}

/*********************/
/* Imprimir el MENU  */
/*********************/
void print_menu(void)
{
  printf ("\n");
  printf ("Menu de Opciones\n");
  printf ("----------------\n");
  printf ("1.-   PING\n");
  printf ("2.-   IDENTIFICACION\n");
  printf ("3.-   LOAD\n");
  printf ("4.-   STORE 1\n");
  printf ("5.-   STORE 2\n");
  printf ("\n");
  printf ("SP.-  Volver a sacar el menu\n");
  printf ("ESC.- Terminar\n\n");
}

/*--------------------------------*/
/* Hilo 1: Pendiente del teclado  */
/* -------------------------------*/
void leer_teclado(void)
{
  char c;

  //-- Imprimir el menu
  print_menu();

  //-- Bucle principal
  do {
    //-- Leer caracter
    fread(&c,1,1,stdin);
    switch(c) {
    case '1': 
      ping();
      break;
    case '2':
      id();
      break;
    case '3': load(DIR_LOAD);
      break;
    case '4': store(DIR_STORE,DATA_STORE1);
      break;
    case '5': store(DIR_STORE,DATA_STORE2);
      break;
    case ' ':
      print_menu();
      break;
    }
  } while (c!=27);  
}


/******************************/
/* Hilo de prueba             */
/******************************/
void check_conexion()
{
  int status;
  
  //-- Inicializar animacion de la barrita que rota
  animatxt_barra_init();
 
  for (;;) {
    status=sgm_ping();
    if (status==1) {
      //-- Mover la barrita una posicion a la derecha
      animatxt_barra_print();
    }
    
    //-- Esperar hasta hacer otra peticion
    usleep(100000);
  }
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
static void inicio()
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Cliente de prueba para servidor Nulo\n");
  printf ("Dispositivo serie: %s\n",disp_serie);
  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexion establecida\n");
  else printf ("Conexion NO establecida\n\n");
}

/***********************/
/* PROGRAMA PRINCIPAL  */
/***********************/
int main (int argc, char* argv[])
{
  pthread_t tarea1;
  pthread_t tarea2;
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Si no se ha especificado el puerto serie como parametro
  //-- se toma por defecto el /dev/ttyS0
  if (argc<2) {
    strcpy(disp_serie,"/dev/ttyS0");
  }
  else 
    strcpy(disp_serie,argv[1]);

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp_serie);
  
  if (serial_fd==-1) {
    printf ("Error al abrir puerto serie: %s\n",disp_serie);
    perror("OPEN");
    exit(0);
  }
  
  //-- Configurar la consola
  consola_io_open();

  //-- Inicializar el motor
  sgm_motor_init(serial_fd);
  
  //-- Conexi�n inicial
  inicio();

  //--------- Lanzar los hilos ----------
  //-- Un hilo pendiente del teclado
  pthread_create(&tarea1, NULL, (void *)leer_teclado, NULL);
  //-- Otro hilo hace constantemente PINGs
  pthread_create(&tarea2, NULL, (void *)check_conexion, NULL);

  //-- Esperar a que termine hilo del teclado 
  pthread_join(tarea1,NULL);

  //-- Consola a su estado inicial
  consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
