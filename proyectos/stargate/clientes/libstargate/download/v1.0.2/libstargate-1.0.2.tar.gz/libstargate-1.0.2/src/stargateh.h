/******************************************************/
/* stargateh.h        Juan Gonzalez Gomez.            */
/*----------------------------------------------------*/
/* Inclusion de todos los .h necesarios para trabajar */
/* con la libstargateh                                */
/******************************************************/
/*----------------------------------------------------------------------------
 $Id: stargateh.h,v 1.2 2004/07/07 17:48:28 juan Exp $
 $Revision: 1.2 $
 $Source: /var/lib/cvs/stargate/clientes/libstargate-1.0/src/stargateh.h,v $
-----------------------------------------------------------------------------*/

#ifndef STARGATEH_H
#define STARGATEH_H

#ifdef __cplusplus
extern "C"{
#endif

#include "sg-motor.h"
#include "sg-serial.h"
  
#ifdef __cplusplus
}
#endif



#endif  // STARGATEH_H
