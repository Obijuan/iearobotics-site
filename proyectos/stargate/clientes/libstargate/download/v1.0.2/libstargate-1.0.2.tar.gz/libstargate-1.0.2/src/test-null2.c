/**************************************************/
/* test-null.c      Juan Gonzalez Gomez.          */
/*------------------------------------------------*/
/* Ejemplo de cliente para el StarGate Nulo.      */
/* No se utilizan hilos                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/
/*------------------------------------------------------------------------
 $Id: test-null.c,v 1.1 2004/07/09 12:36:40 juan Exp $
 $Revision: 1.1 $
 $Source: /var/lib/cvs/stargate/clientes/libstargate/src/test-null.c,v $
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>

#include "consola_io.h"
#include "stargate.h"

//-- Dispositivo serie a utilizar
char disp_serie[255];

/*****************************/
/*    FUNCIONES              */
/*****************************/

/******************/
/* Opcion de PING */
/******************/
void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}

/********************************/
/* Identificacion del servidor  */
/********************************/
int id(void)
{
  int status;
  int is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    printf ("SG-%s-%s-%s-%d\n",sg_tramas_is_to_string(is),
            sg_tramas_im_to_string(im),
            sg_tramas_ipv_to_string(im, ipv),
            (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}
  

/*********************/
/* Imprimir el MENU  */
/*********************/
void print_menu(void)
{
  printf ("\n");
  printf ("Menu de Opciones\n");
  printf ("----------------\n");
  printf ("1.-   PING\n");
  printf ("2.-   IDENTIFICACION\n");
  printf ("\n");
  printf ("SP.-  Volver a sacar el menu\n");
  printf ("ESC.- Terminar\n\n");
}

/*******************/
/* Menu Principal  */
/*******************/
void menu(void)
{
  char c;

  //-- Imprimir el menu
  print_menu();

  //-- Bucle principal
  do {
    //-- Leer caracter
	  c=consola_io_getch();
    
    //-- Seleccionar la opcion
    switch(c) {
    case '1': ping();
      break;
    case '2': id();
      break;
    case ' ': print_menu();
      break;
    }
  } while (c!=27);
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Cliente de prueba para servidor Nulo\n");

  do {
    printf ("Dispositivo serie: %s\n",disp_serie);
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexion establecida\n");
  else printf ("Conexion NO establecida\n");

}

/***********************/
/* PROGRAMA PRINCIPAL  */
/***********************/
int main (int argc, char* argv[])
{
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Si no se ha especificado el puerto serie como parametro
  //-- se toma por defecto el /dev/ttyS0
  if (argc<2) {
    strcpy(disp_serie,"/dev/ttyS0");
  }
  else 
    strcpy(disp_serie,argv[1]);

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp_serie);
  
  if (serial_fd==-1) {
    printf ("Error al abrir puerto serie: %s\n",disp_serie);
    perror("OPEN");
    exit(0);
  }
  
  //-- Configurar la consola
  consola_io_open();

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  inicio();
  
  //-- Opciones para el usuario
  menu();

  //-- Consola a su estado inicial
  consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
