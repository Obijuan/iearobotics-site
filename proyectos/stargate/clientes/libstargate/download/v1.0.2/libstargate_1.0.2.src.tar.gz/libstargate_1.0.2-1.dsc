Format: 1.0
Source: libstargate
Version: 1.0.2-1
Binary: libstargate-dev, libstargate
Maintainer: Juan Gonzalez <juan@iearobotics.com>
Architecture: any
Standards-Version: 3.6.0
Build-Depends: debhelper (>= 4.0.0)
Files: 
 3c83542472d338ffc4d50e567df899b6 31166 libstargate_1.0.2.orig.tar.gz
 00b6ca78dbd8efd47747f299fb11f19b 2232 libstargate_1.0.2-1.diff.gz
