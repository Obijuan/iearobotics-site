/******************************************************/
/* stargate.h        Juan Gonzalez Gomez.             */
/*----------------------------------------------------*/
/* Inclusion de todos los .h necesarios para trabajar */
/* con la libstargate                                 */
/******************************************************/
/*----------------------------------------------------------------------------
 $Id: stargate.h,v 1.2 2004/07/07 17:48:28 juan Exp $
 $Revision: 1.2 $
 $Source: /var/lib/cvs/stargate/clientes/libstargate-1.0/src/stargate.h,v $
-----------------------------------------------------------------------------*/

#ifndef STARGATE_H
#define STARGATE_H

#ifdef __cplusplus
extern "C"{
#endif

#include "sg-tramas.h"
#include "sg-serial.h"
  
#ifdef __cplusplus
}
#endif

#endif  // STARGATE_H
