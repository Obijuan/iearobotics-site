Format: 1.0
Source: libstargate
Version: 1.0.1-1
Binary: libstargate-dev, libstargate
Maintainer: Juan Gonzalez <juan@iearobotics.com>
Architecture: any
Standards-Version: 3.6.0
Build-Depends: debhelper (>= 4.0.0)
Files: 
 6c8c9ed51283af5f3d3c031487a0ff83 41568 libstargate_1.0.1.orig.tar.gz
 6211593c9f099330966515a52de197b9 2004 libstargate_1.0.1-1.diff.gz
