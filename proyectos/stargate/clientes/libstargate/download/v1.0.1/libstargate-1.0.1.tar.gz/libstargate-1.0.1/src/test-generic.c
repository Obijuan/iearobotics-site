/**************************************************/
/* test-generic.c      Juan Gonzalez Gomez.       */
/*------------------------------------------------*/
/* Ejemplo de cliente para el StarGate generico   */
/* No se utilizan hilos                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/
/*------------------------------------------------------------------------
 $Id: test-generic.c,v 1.2 2004/07/12 18:30:34 juan Exp $
 $Revision: 1.2 $
 $Source: /usr/local/cvs/stargate/clientes/libstargate-1.0/src/test-generic.c,v $
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>

#include "consola_io.h"
#include "stargate.h"

/****************/
/* CONSTANTES   */
/****************/

//-------------------------------------------------------
//-- Cambiar estos valores segun las pruebas a realizar
//-------------------------------------------------------

//-- Direccion de donde hacer LOAD
#define DIR_LOAD 0x06

//-- Direccion de donde hacer STORE 
#define DIR_STORE 0x06

//-- Valor para el STORE (1)
#define DATA_STORE1 0xFF

//-- Valor para el STORE (2)
#define DATA_STORE2 0x00


/*****************************/
/*    FUNCIONES              */
/*****************************/

/******************/
/* Opcion de PING */
/******************/
void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}

/********************************/
/* Identificacion del servidor  */
/********************************/
int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

/*********************/
/* Opcion de STORE   */
/*********************/
void store(int dir, int valor)
{
  int status;

  status=sg_store(dir,valor);
  if (status==1) printf ("Store OK\n");
  else printf ("Error en Store. Status: %d\n",status);
}

/********************/
/* Opcion de LOAD   */
/********************/
void load(int dir)
{
  int status;
  int valor;

  status=sg_load(dir,&valor);
  valor=(valor&0xFF);
  if (status==1) printf ("Load OK. Valor: %x\n",valor);
  else printf ("Error en Load. Status: %d\n",status);

}

/*********************/
/* Imprimir el MENU  */
/*********************/
void print_menu(void)
{
  printf ("\n");
  printf ("Men� de Opciones\n");
  printf ("----------------\n");
  printf ("1.-   PING\n");
  printf ("2.-   IDENTIFICACION\n");
  printf ("3.-   LOAD\n");
  printf ("4.-   STORE 1\n");
  printf ("5.-   STORE 2\n");
  printf ("\n");
  printf ("SP.-  Volver a sacar el menu\n");
  printf ("ESC.- Terminar\n\n");
}

/*******************/
/* Menu Principal  */
/*******************/
void menu(void)
{
  char c;

  //-- Imprimir el menu
  print_menu();

  //-- Bucle principal
  do {
    //-- Leer caracter
	  c=consola_io_getch();
    
    //-- Seleccionar la opcion
    switch(c) {
    case '1': ping();
      break;
    case '2': id();
      break;
    case '3': load(DIR_LOAD);
      break;
    case '4': store(DIR_STORE,DATA_STORE1);
      break;
    case '5': store(DIR_STORE,DATA_STORE2);
      break;
    case ' ': print_menu();
      break;
    }
  } while (c!=27);
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Cliente de prueba para servidores Nulo y Generico\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexi�n establecida\n");
  else printf ("Conexi�n NO establecida\n");

}

int main (void)
{
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Configurar la consola
  consola_io_open();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  inicio();
  
  //-- Opciones para el usuario
  menu();

  //-- Consola a su estado inicial
   consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
