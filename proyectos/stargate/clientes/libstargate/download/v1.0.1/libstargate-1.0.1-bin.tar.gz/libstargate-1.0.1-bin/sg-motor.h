/**********************************************/
/* sg-motor.h       Juan Gonzalez Gomez.      */
/*--------------------------------------------*/
/* Licencia GPL                               */
/**********************************************/
/*----------------------------------------------------------------------------
 $Id: sg-motor.h,v 1.2 2004/07/07 17:48:27 juan Exp $
 $Revision: 1.2 $
 $Source: /usr/local/cvs/stargate/clientes/libstargate-1.0/src/sg-motor.h,v $
-----------------------------------------------------------------------------*/

#ifndef SG_MOTOR_H
#define SG_MOTOR_H

#include "sg-tramas.h"

/*****************************************************/
/*    F U N C I O N E S    D E    I N T E R F A Z    */
/*****************************************************/

/*******************************************************************/
/* Servicio ID                                                     */
/*-----------------------------------------------------------------*/
/* ENTRADAS: Ninguna                                               */
/* SALIDAS:                                                        */
/*   is: Identificaci�n del servidor                               */
/*   im: Identificacion del micro                                  */
/*   ipv: Identificaci�n placa y versi�n servidor                  */
/*                                                                 */
/* DEVUELVE:                                                       */
/*   1: OK                                                         */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_id(byte *is, byte *im, byte *ipv);

/*******************************************************************/
/* Servicio PING                                                   */
/*                                                                 */
/* ENTRADAS: Ninguna                                               */
/* SALIDAS: Devuelve                                               */
/*   1: Ping recibido correctamente                                */
/*   0: TIMEOUT. El servidor no responde                           */
/*  -1: ERROR: Alg�n error ha ocurrido, como por ejemplo que se ha */
/*             recibido una trama de respuesta incorrecta          */
/*******************************************************************/
int sgm_ping(void);

/*****************************************************************/
/* Servicio STORE                                                */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir:   Direccion de almacenamiento                         */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sgm_store(int dir, int valor);

/*****************************************************************/
/* Servicio LOAD                                                 */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    dir:   Direccion de almacenamiento                         */
/*                                                               */
/* SALIDAS:                                                      */
/*    valor: Valor a leer                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sgm_load(int dir, int *valor);

/*************************************************/
/* Inicializar el motor del StarGate             */
/*************************************************/
void sgm_motor_init(int fd);

#endif  // SG_MOTOR_H
