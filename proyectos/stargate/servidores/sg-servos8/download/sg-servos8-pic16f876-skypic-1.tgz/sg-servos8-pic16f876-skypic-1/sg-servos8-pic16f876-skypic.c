/*****************************************************************************/
/* sg-servos8-pic16f876-skypic.c  Enero-2007                                 */
/*---------------------------------------------------------------------------*/
/* Servidor para mover 8 servos                                              */
/* Servidor: sg-servos8                                                      */
/* Implementado para la tarjeta Skypic a 20MHz                               */
/*---------------------------------------------------------------------------*/
/* Implementados los servicios de Identificacion, PING, ENABLE Y POS         */
/*---------------------------------------------------------------------------*/
/*  Andres Prieto-Moreno <andres@iearobotics.com>                            */
/*  Juan Gonzalez <juan@iearobotics.com>                                     */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

/*******************************************************/
/* NOTAS:                                              */
/*-----------------------------------------------------*/
/* Hemos configurado el Timer para tener un prescaler  */
/* de 64. Una vez hecho el automata de estados, tenemos*/
/* los siguientes valores:                             */
/*    valor posici�n - temporizacion                   */
/*               0x0 - 0,3  mseg (extremo A)           */
/*              0x10 - 0,5  mseg                       */ 
/*              0x20 - 0,72 mseg                       */
/*              0x30 - 0,9  mseg                       */
/*              0x40 - 1,1  mseg                       */
/*              0x50 - 1,32 mseg                       */
/*              0x90 - 2,1 mseg                        */
/*              0x99 - 2,3 mseg (extremo B)            */
/*                                                     */
/* Con estos valores tenemos una resolucion de 1,17�   */
/* ya que tenemos 153 valores posibles para mover el   */
/* eje del motor en 180 grados.                        */
/*                                                     */
/*******************************************************/ 


//-- Especificar el pic a emplear
#include <pic16f877.h>


//-- Identificadores de los servicios
#define SID	  'I'   // Servicio de identificacion (0x49)
#define SPING 'P'   // Servicio de PING (0x50)
#define SPOS  'W'   // Servicio de Posicionamiento (0x57)
#define SENA  'E'   // Servicio de Habilitacion (0X45)

//-- Identificadores para la respuesta
#define RPING 'O'   // Respuesta al Servicio de PING (0x4F)
#define RSI	  'I'   // RSI. Codigo de respuesta del servicio de identificacion
	
//----- Datos devueltos por el servicio de identificacion
#define IS	0x30    // IS. Identificacion del servidor
#define IM	0x30    // IM. Identificacion del microcontrolador
#define IPV	0x11    // IPV. SKYPIC v1
	
//------------- RELACIONADAS CON LOS SERVOS -----------------
#define DELAY_0_3ms 0xEA	  // Tiempo 0'3ms, con prescaler a =64
#define DELAY_1_0ms 0xB0	  // Posicion central: 1ms, pres a = 64
#define DELAY_2_2ms 0x52    // Tiempo 2,2ms, con prescaler a =64

#define CENTRO	    DELAY_1_0ms

// --Posicion de los servos
unsigned char pos_servos[8];  // Posicion servo
unsigned char indice       ;  // indice de servo
unsigned char servo_actual;	  // Servo actual

unsigned char salidas;	        // M�scara que indica qu� salidas est�n activas
unsigned char estado;	
	
unsigned char car;   // Caracter recibido por el SCI
unsigned char pos;   // Calculos intermedios

/*********************************************
 Funciones relacionadas con el puerto serie
**********************************************/

/****************************************************/
/* Configurar el puerto serie a N81 y 9600 Baudios  */
/****************************************************/ 

void sci_conf(void)
{
  SPBRG = 0x81;  //-- 9600 baudios (con cristal de 20MHz)
  TXSTA = 0x24;  //-- Configurar transmisor
  RCSTA = 0x90;  //-- Configurar receptor
}

/******************************************/
/* Recibir un caracter por el SCI         */
/*----------------------------------------*/
/* DEVUELVE:                              */
/*   -Caracter recibido                   */
/******************************************/

unsigned char sci_read(void)
{
  //-- Eserar hasta que llegue el dato
  while (!RCIF);
    
  return RCREG;
}

/*****************************************/
/* Transmitir un caracter por el SCI     */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*   -car: Caracter a enviar             */
/*****************************************/

void sci_write(unsigned char car)
{
  //-- Esperar a que Flag de lista para transmitir se active
  while (!TXIF);
    
  //-- Hacer la transmision
  TXREG=car;
}

/***************************************
   Configuracion del Timer 0
****************************************/

void timer0_configure() {
	// TOCS=Modo timer bit5=0
	// PS2:PS9 prescaler a 32
	// PSA=0 para asignar el prescaler al timer0
	OPTION_REG=0x05;   
	
	// Borra flag de interrupcion TIMER0 TOIF
	INTCON=INTCON&0xFB;   // TOIF=0  borra flag interrupcion del timer
	INTCON=INTCON|0x20;   // TOIE=1  activa interrupciones del timer
	INTCON=INTCON|0x80;   // GIE=1   activa interrupciones globales
	TMR0=0;               // Inicializa el registro del timer
}

/******************************************
	Rutina de atenci�n a la interrupci�n
*******************************************/

void intr(void) interrupt 0 {
	
	// Borra flag de interrupcion TIMER0 TOIF
	INTCON=INTCON&0xFB;   // TOIF=0  borra flag interrupcion del timer
	//TMR0=DELAY_2_2ms;
	//PORTB=PORTB^0xFF;

	
	if (estado==0) {
		PORTB=salidas & servo_actual;  // servo activo con mascara de las salidas
		//-- Lanzar temporizador para calcular anchura fija de 0.3ms
		TMR0=DELAY_0_3ms;
		estado=1;
	}
	else if (estado==1) {
		//-- Anchura para situar el servo
		TMR0=pos_servos[indice];
		estado=2;
	}
	else if (estado==2) {
		PORTB=0;
		TMR0=DELAY_2_2ms-pos_servos[indice];   
		estado=0;
		
		//-- Pasar al siguiente servo
		servo_actual=servo_actual<<1;
		indice++;
		if (servo_actual==0x00) { 
			servo_actual=1;
			indice=0;
		}
		
	}	 
	else {
		// si llega aqu� es por error -> vuelvo a estado inicial
		estado=0;
	}
	
}


/****************************
	Servicios del servidor
****************************/

// Servicio PING
void serv_ping() {
	sci_write(RPING);
}

// Servicio de Identificacion
void serv_id() {
	sci_write(RSI);
	sci_write(IS);
	sci_write(IM);
	sci_write(IPV);
}

void serv_pos() {
	unsigned char car2;
	
	// Leer el n�mero de servo
	car = sci_read();  // leer el servo
	
	// Leer la posicion del servo
	car2=sci_read();
	if (car2>=0x99) {    // limite por la configuracion del Timer.
		car2=0x99;
	}
	pos_servos[car-1]=0xFF-car2;
}


void serv_ena() {
	salidas=sci_read();
}


//----------------------------
//- Comienzo del programa  
//----------------------------

void main(void)
{
	unsigned char tecla;
	unsigned char ret=0;
	unsigned char i;
	
	
	//-- configura como salida el Puerto B 
	TRISB=0x00;
	PORTB=0x02;  // enciende el LED
	
	//--inicializacion de variables
	for (i=0; i<8; i++) {
		pos_servos[i]=CENTRO;  // Motores en el centro como inicio
	}
	salidas=0;
	indice=0;
	estado=0;
	servo_actual=1;	// Servo actual	
	
	
	//-- Configurar el puerto serie
	sci_conf();
	
	//-- Configurar el Timer0 para controlar los servos
	//-- y activar su interrupcion
	timer0_configure();
	
	while (1) {
		
		tecla = sci_read();
	
		switch (tecla) {
			case SPING: // servicio SPING
						serv_ping();
						break;
		
			case SID: // Servicio de identificacion
					  serv_id();
					  break;
				  
			case SPOS: // Servicio de posicion
					   serv_pos();
					   break;
				 
			case SENA: // Servicio de activacion de motores
						serv_ena();
						break;
				
			default:
						break;
		}
	}
}
