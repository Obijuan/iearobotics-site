/*************************************************/
/* sci.c    (c) Juan Gonzalez. Julio 2006        */
/*-----------------------------------------------*/
/* Comunicaciones serie con la Skypic            */
/*-----------------------------------------------*/
/* LICENCIA GPL                                  */
/*************************************************/

#include "pic16f877.h"
#include "sci.h"

//-- CONSTANTES
#define B9600_4MHZ   0x19  //-- Vel. 9600 baudios cuando cristal de 4MHz
#define B9600_20MHZ  0x81  //-- vel. 9600 baudios cuando cristal de 20MHz

//---------------------------------------------
//-- CONSTANTES MODIFICABLES POR EL USUARIO
//---------------------------------------------
//-- Establecer la velocidad para un cristal de 20MHZ
//-- La skypic lleva 20Mhz
#define B9600 B9600_20MHZ

/****************************************************/
/* Configurar el puerto serie a N81 y 9600 Baudios  */
/****************************************************/
void sci_init(void)
{
  SPBRG = B9600; //-- 9600 baudios
  TXSTA = 0x24;  //-- Configurar transmisor
  RCSTA = 0x90;  //-- Configurar receptor 
}

/******************************************/
/* Recibir un caracter por el SCI         */
/*----------------------------------------*/
/* DEVUELVE:                              */
/*   -Caracter recibido                   */
/******************************************/
unsigned char sci_read(void)
{
  //-- Eserar hasta que llegue el dato
  while (!RCIF);
    
  return RCREG;
}

/*****************************************/
/* Transmitir un caracter por el SCI     */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*   -car: Caracter a enviar             */
/*****************************************/
void sci_write(unsigned char car)
{
  //-- Esperar a que Flag de lista para transmitir se active
  while (!TXIF);
    
  //-- Hacer la transmision
  TXREG=car;
}
