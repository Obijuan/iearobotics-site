/*************************************************************************** */
/* sg-null-pic16F876A-skypic.c  Julio 2006                                   */
/*---------------------------------------------------------------------------*/
/* Servidor de eco para la tarjeta Skypic (a 20MHZ)                          */
/* Se hace eco de todo lo recibido por el puerto serie y se envia tambien    */
/* por el puerto B para que se pueda ver con una tarjeta de leds, como la    */
/* FREELEDS                                                                  */
/*---------------------------------------------------------------------------*/
/* Servidor NULO                                                             */
/* Servidor: sg-null                                                         */
/* Implementado para la tarjeta Skypic a 20MHz                               */
/*---------------------------------------------------------------------------*/
/* Implementados los servicios de Identificacion y PING.                     */
/* Cada vez que se hace un PING se cambia de estado el led.                  */
/* Inicialmente el led conectado al pin RB1 esta encendido                   */
/* Cualquier otro caracter recibido se ignora                                */
/*---------------------------------------------------------------------------*/
/*  Juan Gonzalez <juan@iearobotics.com>                                     */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

//-- Especificar el pic a emplear
#define __16f877
#include "pic16f877.h"


/*******************************/
/* DEFINICIONES                */
/*******************************/
#define LED 0x02     //-- Bit del puerto B donde se encuentra el LED

#include "sci.h"
#include "pic16f877.h"

/*----------------------------*/
/*   CONSTANTES DEL STARGATE  */
/*----------------------------*/

//-- Datos devueltos por el servicio de identificacion
#define IS  0x10  // IS. Identificacion del servidor
#define IM  0x30  // IM. Identificacion del microcontrolador (pic16F876A)
#define IPV 0x10  // IPV. Placa Skypic. Version 0.

//-- Identificadores de los servicios
#define	SID   0x49 // Servicio de identificacion
#define SPING 0x50 // Servicio de PING (0x50)

//-- Identificadores para la respuesta
#define RPING 0x4F // Respuesta al Servicio de PING (0x4F)
#define RSI   0x49 // RSI. Codigo de respuesta del servicio de identificacion	


/*---------------------*/
/* PROGRAMA PRINCIPAL  */
/*---------------------*/
void main(void)
{
  unsigned char car;
  
  /*----------------------------*/
  /* Configurar el sistema      */
  /*----------------------------*/
  //-- Configurar el led de la skypic
  TRISB=~LED;
  
  //-- Activar LED de la Skypic
  PORTB=LED;
  
  /*-----------------------------*/
  /* Configurar el puerto serie  */
  /*-----------------------------*/
  sci_init();
  
  /*------------------*/
  /* Bucle principal  */
  /*------------------*/
  for (;;) {
    
    //-- Esperar a que se solicite un servicio
    car=sci_read();
    
    switch(car) {
      
      //-- Servicio de identificacion
      case SID: 
        sci_write(RSI);
        sci_write(IS);
        sci_write(IM);
        sci_write(IPV);
        break;
      
      //-- Servicio de PING
      case SPING: 
        sci_write(RPING);
        PORTB^=LED;      //-- Cambiar de estado el LED
        break;
    }
  }
}
