/*************************************************************************** */
/* sg-echo-pic16F876A-skypic.c  Julio 2006                                   */
/*---------------------------------------------------------------------------*/
/* Servidor de eco para la tarjeta Skypic (a 20MHZ)                          */
/* Se hace eco de todo lo recibido por el puerto serie y se envia tambien    */
/* por el puerto B para que se pueda ver con una tarjeta de leds, como la    */
/* FREELEDS                                                                  */
/*---------------------------------------------------------------------------*/
/*  Juan Gonzalez <juan@iearobotics.com>                                     */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

//-- Especificar el pic a emplear
#define __16f877
#include "pic16f877.h"

//-- CONSTANTES
#define B9600_4MHZ   0x19
#define B9600_20MHZ  0x81

//---------------------------------------------
//-- CONSTANTES MODIFICABLES POR EL USUARIO
//---------------------------------------------
//-- Establecer la velocidad para un cristal de 20MHZ
//-- La skypic lleva 20Mhz
#define B9600 B9600_20MHZ


/****************************************************/
/* Configurar el puerto serie a N81 y 9600 Baudios  */
/****************************************************/
void sci_conf(void)
{
  SPBRG = 0x81;  //-- 9600 baudios (con cristal de 20MHz)
  TXSTA = 0x24;  //-- Configurar transmisor
  RCSTA = 0x90;  //-- Configurar receptor 
}

/******************************************/
/* Recibir un caracter por el SCI         */
/*----------------------------------------*/
/* DEVUELVE:                              */
/*   -Caracter recibido                   */
/******************************************/
unsigned char sci_read(void)
{
  //-- Eserar hasta que llegue el dato
  while (!RCIF);
    
  return RCREG;
}

/*****************************************/
/* Transmitir un caracter por el SCI     */
/*---------------------------------------*/
/* ENTRADAS:                             */
/*   -car: Caracter a enviar             */
/*****************************************/
void sci_write(unsigned char car)
{
  //-- Esperar a que Flag de lista para transmitir se active
  while (!TXIF);
    
  //-- Hacer la transmision
  TXREG=car;
}


/*********************************/
/* Programa principal            */
/*********************************/
void main(void)
{
  unsigned char c;

  //-- Configurar el puerto B para salida 
  TRISB=0x00;
  
  //-- Inicialmente activar todos los leds
  PORTB=0xFF;
  
  //-- Configurar las comunicaciones serie
  sci_conf();
  
  //-- Bucle infinito
  for (;;) {
    
    //-- Esperar a que llegue dato del PC
    c=sci_read();
    
    //-- Sacarlo por el puerto B para verlo en los leds
    PORTB=c; 
    
    //-- ...y enviar de vuelta el caracter por el puerto serie
    sci_write(c);
  }

}
