/***************************************************************************
 *            sg-echo-6808-gpbot-0.c
 *
 *  Sun Feb 15 11:41:21 2004
 *  Copyright  2004  Juan Gonzalez
 *  juan@iearobotics.com
 ****************************************************************************/
/* $Revision: 1.1 $ */
/* $Date: 2004/02/15 10:54:04 $     */

/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "sci.h"
#include "mc68hc908gp32.h"

void main(void)
{
	unsigned char car;
	
	/*----------------------------*/
	/* Configurar el sistema      */
  /*----------------------------*/
	CONFIG1|=0x01;  //-- Deshabilitar el COP
  DDRB=0xFF;      //-- Configurar Puerto B para salida
 	PORTB=0x00;     //-- Poner a 0 Puerto B
	
	/*-----------------------------*/
	/* Configurar el puerto serie  */
	/*-----------------------------*/
	sci_init();
	
	/*------------------*/
	/* Bucle principal  */
	/*------------------*/
	for (;;) {
	  car=sci_leer_car();  // Leer caracter
		sci_enviar_car(car); // Hacer eco
		PORTB=car;           // Enviarlo al puerto B
	}	
		
}
