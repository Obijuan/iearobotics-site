#define NEGRO    0
#define AZUL     4
#define VERDE    2
#define CYAN     6
#define ROJO     1
#define MAGENTA  5
#define AMARILLO 3
#define BLANCO   7

#define SIMPLE 0
#define DOBLE  1
