/************************************************************************/
/*  TERMANS.C.  (C) Microbotica, S.L Noviembre 1997.                    */
/* -------------------------------------------------------------------- */
/*  Funciones para actuar sobre terminales ansi: cambiar el color,      */
/*  borrar la pantalla...                                               */
/*                                                                      */
/*----------------------------------------------------------------------*/
/* web:  www.microbotica.es                                             */
/* mail: info@microbotica.es                                            */
/************************************************************************/


#include "termansi.h"

int ansi=1;   /* ANSI SI/NO */

void configansi(int t)
/**************************************************************************/
/* Cambiar el estado del ansi. Cuando el parametro de entrada indica 0    */
/* no se utilizan comandos ansi. Cuando t=1 si.                           */
/**************************************************************************/
{
  if (t==0) ansi=0;
  else ansi=1;
}

void dprint(char *cad)
/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/******************************************************/
{
  int i=0;
  
  while (cad[i]!=0){
    write(1,&cad[i],1);
    i++;
  }
}

void clrscr()
/************************/
/*  Borrar la pantalla  */
/************************/
{
  if (ansi) {
    dprint ("[2J");     /* Borrar la pantalla                        */
    dprint ("[1;1H");   /* Situar cursor en esquina superior derecha */
  }  
}

void locate(char x, char y)
/**********************************************/
/*  Situar el cursor en la posicion indicada  */
/**********************************************/
{
  char s[20];
  
  if (ansi) {
    sprintf(s,"[%d;%dH",y,x);
    dprint(s);
  }  
}

void fondo(char f)
/**********************************/
/* Cambiar el color del fondo     */
/**********************************/
{
  char s[20];
  
  if (ansi) {
    sprintf(s,"[%dm",f+40);
    dprint (s);
  }  
}

void setcolor(char c)
/**************************************/
/*  Cambiar el color del primer plano */
/**************************************/
{
  char s[20];
  
  if (ansi) {
    sprintf(s,"[%dm",c+30);
    dprint(s);
  }  
}

void color(char f,char b)
/***********************************************/
/*  Cambiar color del primer plano y del fondo */
/***********************************************/
{
  char s[20];

  if (ansi) {  
    sprintf(s,"[%d;%dm",f+30,b+40);
    dprint(s);
  }  
}

void high()
/******************************************************************/
/*  Establecer atributos de alta intensidad en color primer plano */
/******************************************************************/
{
  char s[20];
  
  if (ansi) {
    sprintf (s,"[1m");
    dprint(s);
  }  
}

/********************************/
/*  Poner atributos a 'cero'    */
/********************************/
void low()
{
  char s[20];
  
  if (ansi) {
    sprintf(s,"[0m");
    dprint(s);
  } 
}


/************** La siguientes funciones dejaran de formar parte ********/

void marco(x,y,alt,anch,t)
char x,y;
char alt,anch;
char t;
/*********************************************************/
/*  Dibujar un marco.                                    */
/*                                                       */
/*    x,y --> Posicion de la esquina superior izquierda  */
/*    alt --> Altura del marco                           */
/*    anch --> Anchura del marco                         */
/*    t --> Tipo de marco (SIMPLE, DOBLE)                */
/*********************************************************/
{
  static char v[2][6]={218,191,217,192,196,179,
                       201,187,188,200,205,186};
  unsigned int i;
  
  if (t!=SIMPLE && t!=DOBLE) return;
  
  locate(x,y);
  putchar(v[t][0]);
  for (i=1; i<anch-1; i++) {  /* Linea superior */
    putchar(v[t][4]);
  }
  putchar(v[t][1]);
  locate(x,y+alt-1);
  putchar(v[t][3]);
  for (i=1; i<anch-1; i++) {  /* Linea inferior */
    putchar(v[t][4]);
  }
  putchar(v[t][2]);
  for (i=1; i<alt-1; i++) {   /* Linea izquierda */
    locate(x,y+i);
    putchar(v[t][5]);
  }
  for (i=1; i<alt-1; i++) {  /* Linea derecha */
    locate(x+anch-1,y+i);
    putchar(v[t][5]);
  }
}

void lineah(x,y,tam,tipo)
{
  static char v[2] = {196,205};
  unsigned int i;
  
  if (tipo!=SIMPLE && tipo!=DOBLE) return;

  locate(x,y);
  for(i=0; i<tam; i++) {
    putchar(v[tipo]);
  }
}
void lineav(x,y,tam,tipo)
{
  static char v[2] = {179,186};
  unsigned int i;
  
  if (tipo!=SIMPLE && tipo!=DOBLE) return;

  for(i=0; i<tam; i++) {
    locate(x,y+i);
    putchar(v[tipo]);
  }
}

