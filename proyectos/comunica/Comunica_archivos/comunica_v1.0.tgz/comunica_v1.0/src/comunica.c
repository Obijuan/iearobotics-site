#include <stdio.h>
#include <unistd.h>
//#include <curses.h>
#include "serie.h"
#include <time.h>
//#define TAM_ENVIO 239
#define TAM_ENVIO 20

int main(int argc, char *argv[])
{
  char car_envio[2];
  unsigned char car_in;
  int cuantos;
  int temporizer;
  int timeout;
  time_t time_data;
  int target_data[256];
  int index;
  FILE *dump;
  int status;

  // Inicializacion de los datos

  for (index=0;index<TAM_ENVIO;index++)
    {
      target_data[index]=0;
    }


  if (abrir_puerto_serie(COM2)==0)
    {
      printf("Error al abrir el puerto serie: %s\n\n",getserial_error());
      exit(1);
    }

  baudios(7680);
  dtr_off();

  //-- Hacer un reset de la CT6811
  resetct6811();
  if (okreset()) 
    {
      printf ("RESET OK!!!\n");
    }
  else 
    {
      printf ("ERROR\n");
    }
  
  cuantos=0;

  // abrir fichero de resultados
  dump=fopen("./data.txt","w+");

  time_data = time(NULL);

  fprintf(dump,"FICHERO DE MEDIDAS\n");
  fprintf(dump,"======= == =======\n\n");
  fprintf(dump,"%s\n",ctime(&time_data));
  fprintf(dump,"Datos\n");
  fprintf(dump,"-----\n\n");
 
  //-- Saltar a ejecutar el programa de la eeprom
  status=jump_eeprom();
  printf ("Status: %d\n",status);
  
  //-- Limpiar el buffer por si hubiese algo pendiente
  usleep(200000);
  vaciar_buffer_rx();

  // Esperar a finalización del programa en el host
  // printf("Conectar ahora cable serie a la tarjeta CT6811\n\n");  
  printf("Esperando a finalización en CT6811...\n");
  car_in = '\0';
  while (car_in != 'K')
    {
      car_in = leer_car_plazo(1000000,&timeout);
    }

  // Enviar peticion de volcado
  printf("¿Comenzar la descarga de datos? (s/n)? ");
  scanf("%s",&car_envio);
  car_envio[1]='\0';

  if (car_envio[0] == 's')
    {
      enviar_car(car_envio[0]);
      
      printf("Datos recibidos\n");
      printf("===== =========\n");
      while (cuantos < TAM_ENVIO)
	{
	  car_in=leer_car_plazo(1000000,&timeout);
	  if (timeout==1)
	    {
	      printf("TIMEOUT!! Respuesta no recibida\n");
	    }
	  target_data[cuantos] = car_in;
	  printf("%X -- %d\n",car_in,cuantos);
	  cuantos++;
	} // while
      
      printf("Fin del volcado de datos. Total volcado: %d\n",cuantos);
    }
  else
    {
      printf("Volcado de memoria cancelado\n");
    }


  
  // Volcado de datos a fichero

  fprintf(dump,"   CANAL 1                CANAL 2                CANAL 3                CANAL 3\n");
  fprintf(dump,"============           ============           ============           ============\n");
  for (index=0;index<TAM_ENVIO;index=index+4)
    {
      fprintf(dump,"[%3d] - %.2f           [%3d] - %.2f           [%3d] - %.2f           [%3d] - %.2f\n",
	      index,(target_data[index]*5)/255.0,index+1,(target_data[index+1]*5)/255.0,
              index+2,(target_data[index+2]*5)/255.0,index+3,(target_data[index+3]*5)/255.0);
      /*
      fprintf(dump,"[%3d] - %2X  [%3d] - %2X [%3d] - %2X [%3d] - %2X [%3d] -%2X [%3d] - %2X [%3d] - %2X [%3d] - %2X\n",
	     index,target_data[index],index+1,target_data[index+1],index+2,target_data[index+2],index+3,target_data[index+3],
	     index+4,target_data[index+4],index+5,target_data[index+5],index+6,target_data[index+6],index+7,target_data[index+7]);
      */
    }
  
  fclose(dump);
 
  cerrar_puerto_serie();
  return 0;
}
