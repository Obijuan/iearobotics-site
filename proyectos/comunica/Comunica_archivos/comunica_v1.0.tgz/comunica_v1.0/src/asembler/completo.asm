* Definición de constantes
	
BAUD	equ $2b			; registros para comunicaciones serie
SCCR1	equ $2c
SCCR2	equ $2d
SCSR	equ $2e
SCDR	equ $2f
PORTA   equ $00			; registros de puertos
PORTC	equ $03
DDRC	equ $07
BASE    equ $00			; offset base para almacenamiento en RAM
CONTA   equ $f0			; offset del puntero a la posición de RAM
TMSK2	equ $24 		; registros del temporizador
TCNT    equ $0e
TOPE    equ $14
OPTION  equ $39                	; registros del conversor A/D
ADCTL   equ $30
ADR1    equ $31
ADR2	equ $32
ADR3	equ $33
ADR4	equ $34

	org $b600

* Inicializar las variables principales
	ldx #$1000
	ldy #$0000

* Configuración del puerto C como puerto de salida
	ldaa #$ff
	staa DDRC,x
	ldaa #$c3
	staa PORTC,x

* Configuración del temporizador
	bset TMSK2,x $03
        ldaa #$10

* Inicialización del contador y almacenamiento en RAM
	ldaa #$00
	staa CONTA,y

* Configurar el conversor A/D
	ldaa #$80
	staa OPTION,x		; encender el conversor
	ldaa #$30
	staa ADCTL,x		; configuración conversor:
* SCAN=1 => conversion continua
* MULT=1 => varios canales
	
* Inicialización del array de datos en RAM
	clra
fill	staa BASE,y
	iny
	cpy #TOPE
	bne fill
	ldy #$0000

* Bucle principal. Temporización y toma de datos
loop	ldd TCNT,x
	anda #$80
	cmpa #$80

	beq incre
	bra loop

incre	iny
	cpy #$ffff
	bne loop

* Parpadeo del LED durante la toma de datos
	ldaa PORTA,x
	eora #$40
	staa PORTA,x

* Conversion desde A/D. Almacenar valor en RAM
	ldy #$0000
	ldab CONTA,y
	stab PORTC,x
	aby
conv:	brclr ADCTL,x $80 conv
	ldaa ADR1,x
	staa BASE,y
	iny
	incb
	ldaa ADR2,x
	staa BASE,y
	iny
	incb
	lda ADR3,x
	staa BASE,y
	iny
	incb
	lda ADR4,x
	staa BASE,y
	ldy #$0000
	incb
	stab CONTA,y
	cmpb #TOPE
	beq ack
	bra loop

* Envio de ACK al PC para solicitar comienzo de descarga de datos
ack	ldaa #'K'
	bsr send
ack2	bsr read
	cmpa #'s'
	beq dump
	bra ack2

* Volcado de memoria al PC a través del puerto serie
dump    clra
	ldaa #$c3
	staa PORTC,x
	ldy #$0000

empty	ldaa BASE,y
	bsr send
	iny
	cpy #TOPE
	bne empty
	bra fin
	
fin	ldaa #$f0
	staa PORTC,x
	end

* Subrutinas de lectura y envio de caracteres
	
read    brclr SCSR,x $10 read
	ldaa SCDR,x
	rts

send    brclr SCSR,x $80 send
	staa SCDR,x
	rts
