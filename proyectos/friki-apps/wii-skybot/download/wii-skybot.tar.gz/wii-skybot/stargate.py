#! /usr/bin/python
#---------------------------------------------------------------------------
#--  (C)2007 Juan Gonzalez
#--
#--  Modulo Stargate para la comunicacion con lo servidores "stargates"
#--
#--  LICENCIA GPL
#---------------------------------------------------------------------------

import sys;
import getopt
import serial;

#-----------------------------------
#------ Cabeceras de la trama 
#-----------------------------------
TRAMA_PING_CAB   = 'P'
TRAMA_ID_CAB     = 'I'
TRAMA_RID_CAB    = 'I'
TRAMA_PONG_CAB   = 'O'
TRAMA_LOAD_CAB   = 'L'
TRAMA_RLOAD_CAB  = 'L'
TRAMA_STORE_CAB  = 'S'
TRAMA_RSTORE_CAB = 'S'
TRAMA_ENA_CAB    = 'E'
TRAMA_POS_CAB    = 'W'

#-----------------------------------------
#---- Identificacion de los servidores
#-----------------------------------------
SERVIDOR = {0x00:"XXXX",
            0x10:"NULL", 
            0x20:"GENERIC",
            0x30:"SERVOS8",
            0x40:"PICP",
           }

#------------------------------------------------
#--- Identificacion de los microcontroladores
#------------------------------------------------
MICRO = {0x00: "XXXX",
         0x10: "68HC11E2",
         0x20: "68HC08",
         0x30: "PIC16F876",
        }

#--------------------------------------
#-- Identificacion de las placas
#--------------------------------------
PLACA = {0x00 : "USER",
         0x101: "CT6811",
         0x201: "GPBOT",
         0x300: "USER",
         0X301: "SKYPIC",
        } 

#----------------------------------------------------------------------
#-- Valores de los extremos de los servos para diferentes servidores  
#----------------------------------------------------------------------
EXTREMOS = {0x000: (0,0xE6),  # Valores por defecto si no se indica nada

            0x300: (0,0xE6),  # Skypic a 4Mhz
            0x301: (0,0x89),  # Skypic a 20Mhz
            0x101: (0,0xE6),  # CT6811
           }


#------------------------------------------------------------------------------
# FUNCIONES GENERALES DE AYUDA
#------------------------------------------------------------------------------

#---------------------------------------------------------------------------
#-- Imprimir mensaje de ayuda. 
#-- Mensaje de ayuda para todas las aplicaciones que utilicen como unico 
#-- parametro pasado por el usuario el puerto serie a emplear
#---------------------------------------------------------------------------
def help():

    sys.stderr.write("""
Uso: %s [opciones]
    
  opciones:
  -p, --port=PORT: Puerto serie a emplear. Bien un numero o una cadena
    
  Ejemplo:
   %s -p 0          --> Usar el primer puerto serie (Linux/Windos)
   %s -p /dev/ttyS1 --> Especificar el dispositivo serie (Linux) 
      
    """ % (sys.argv[0], sys.argv[0], sys.argv[0]))

#-------------------------------------------------------------------------
#- Leer el puerto serie a partir de los argumentos pasados por el usuario
#- Funcion que sera utilizada en todas las aplicaciones que utilicen como 
#- unico argumento el puerto serie
#- Se puede especificar el valor del puerto por defecto, en caso de que 
#- el usuario no haya especificado ninguno
#-------------------------------------------------------------------------
def Argumentos_Leer_puerto_verbose(puerto=0, verbose=False):
  
  try:
    opts, args = getopt.getopt(sys.argv[1:],
          "p:v",
          ["port=","verbose"]
    )
  except getopt.GetoptError:
    print "Error en argumentos pasados"
    help()
    sys.exit(1)

  #-- Leer argumentos pasados
  for o, a in opts:
    if o in ("-p", "--port"):
      try:    
        puerto = int(a)
      except:
        puerto = a
    elif o in ("-v","--verbose"):
      verbose=True

  return (puerto, verbose)
  
#---------------------------------------------------------------------
#- Abrir una sesion con el servidor especificao
#-
#- ENTRADAS (opcionales)
#    -tipo: Tipo de servidor
#    -verbose: Modo verbose on/off
#    -puerto:  Numero de puerto serie o nombre del dispositivo. 
#---------------------------------------------------------------------
def start_session(tipo="GENERIC", verbose=False, puerto=0):

  #-- Crear un stargate generico y abrir puerto serie
  if tipo=="GENERIC":
    g = Generic(puerto)
  elif tipo=="SERVOS8":
    g = Servos8(puerto)
  else:
    print "Servidor especificado desconocido: %s" % tipo
    sys.exit(1)
  
  #-- Comprobar la conexion. Se hacen "pings" para ver si hay conexion con
  #-- el servidor y se lee su identificacion
  if not(g.check_connection(verbose)):
    print "Abortando..."
    sys.exit(1);
  
  #-- Si No es un servidor generico abortar...
  if not(g.check_server_type(tipo, verbose)):
    print "Abortando..."
    sys.exit(1);
    
  return g
  
#---------------------------------------------------------------------------
# Comenzar una sesion "tipica". Es la que abren las aplicaciones tipicas, 
# en las que se usan solo dos parametros que el usuario pueden
# pasar opcionalmente por la linea de comandos: verbose y puerto
#
# ENTRADA:
#   -tipo: Tipo de servidor al que conectarse
#---------------------------------------------------------------------------
def start_typical_session(tipo="GENERIC"):
  #-- Leer puerto serie pasado por el usuario. Si no se han especificado
  #-- se toman verbose=False y puerto=0 como valores por defecto
  (puerto,verbose) = Argumentos_Leer_puerto_verbose(
                        puerto=0,
                        verbose=False)
                        
  #-- Abrir la sesion son los parametros del usuario
  return start_session(tipo=tipo, puerto=puerto, verbose=verbose)

 
#--------------------------------------------------
# CLASE STARGATE
#--------------------------------------------------
class Stargate:
  def __init__(self, Puerto=0):
   
    #-- Abrir puerto serie
    self.Puerto = Puerto
    
    try:
      self.serial = serial.Serial(Puerto, 9600)
    
      #-- Timeout: 1 seg
      self.serial.timeout=0.5;
      
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput()
      self.serial.flushOutput()
    
    except serial.SerialException:
      #-- Error al abrir el puerto serie
      print "Error al abrir puerto serie: %s" % str(Puerto)
      
      #-- Lanzar una excepcioin del stargate!
      #-- POR HACER!!!
      self.serial=None
  
  #------------------
  #- Servicio PING 
  #------------------
  def ping(self):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Enviar trama PING
    self.serial.write(TRAMA_PING_CAB);
    
    #-- Esperar respuesta
    pong = self.serial.read();
    
    #-- Timeout o dato incorrecto
    if len(pong)==0 or pong!=TRAMA_PONG_CAB: 
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput()
      self.serial.flushOutput()
      return 0
    
    #-- Ping ok
    return 1
    
  #-----------------------------------------------------
  #- Servicio de identificacion. Devolver los bytes
  #- Devuelve la tupla (is, im, id):
  # -    is : identificador de servicio
  #-     im : Identificador de micro
  #-     id : Identificador de placa y version
  #-  Todos son valores enteros
  #-----------------------------------------------------
  def id_bytes(self):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return (0,0,0)
    
    #-- Enviar trama de IDENTIFICACION
    self.serial.write(TRAMA_ID_CAB)
    
    #-- Esperar respuesta
    id = self.serial.read(4)
    
    #-- Timeout o trama incorrecta
    if len(id)!=4 or id[0]!=TRAMA_RID_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput()
      self.serial.flushOutput()
      return (0,0,0)
    
    #-- Trama correcta, devolver valores
    return (ord(id[1]), ord(id[2]), ord(id[3]))
    
  #-----------------------------------------------------
  #- Servicio de identificacion. Devolver la cadena
  #-----------------------------------------------------
  def id(self):
    #-- Leer la identificcion
    (iserv, im, id) = self.id_bytes()
    
    #-- Si hay error sacar la cadena "UNKWON"
    if (iserv==0 and im==0 and id==0): return "UNKWON"
    
    #-- devolver la cadena
    return "SG-%s-%s-%s-%d" % (SERVIDOR[iserv],
                               MICRO[im],
                               PLACA[im<<4 | id>>4],
                               id&0x0F)
                               
  #---------------------------------------------------------------------------
  #-- Comprobar la conexion con el servidor. 
  #-- Esta funcion realiza tres pings. Si el servidor no responde a la tercera,
  #-- devolvera un 0, indicando que no hay conexiond
  #-- En caso de que haya respuesta, se imprime el tipo de servidor y se
  #-- devuelve 1
  #
  #  ENTRADAS: 
  #    -Parametro opcional verbose:
  #       True : Se imprime en pantalla lo que va pasando (opcion por defecto)
  #       False: No se imprime nada
  #
  #  DEVUELVE:
  #     False : No hay conexion con el servidor
  #     True  : Conexion establecida
  #
  #----------------------------------------------------------------------------
  def check_connection(self, verbose=True):
    
    #-- En modo verbose se muestra el numero del puerto y el nombre del
    #-- dispositivo
    if verbose:
      print ""
      
      #-- A la clase serial solo se puede acceder si se ha abierto
      #-- el puerto serie
      if self.serial==None: name="UNKNOW"
      else: name = self.serial.portstr
      print "Puerto (%s) : %s" % (str(self.Puerto), name)
    
    #-- Realizar tres iteraciones
    for i in range(3):
    
      #-- En modo verboso se imprime informacion de lo que se va haciendo
      if verbose:
        sys.stdout.write("Conexion...")
        sys.stdout.flush()
        
      #-- Hacer ping  
      ok=self.ping()
      
      #-- Si hay ping se sale del bucle
      #-- En caso contrario se continua probando
      if ok==1: 
      
        if verbose:
          sys.stdout.write("OK\n")
          
        break;
      else:
        if verbose:
          sys.stdout.write("TIMEOUT\n")
  
    #-- Comprobar que es lo que ha sucedido para devolver el valor de retorno
    if ok==1:
      
      #-- Todo ok
      if verbose:
        print "Servidor: %s" % self.id()
        print "Conexion establecida\n"
        
      return True
      
    else:
      #-- No hay conexion
      if verbose:
        print "Conexion NO establecida\n"
      return False

  #-------------------------------------------------------------------
  #- Comprobar el tipo de servidor para saber si es el 
  #- esperado o no
  #- ENTRADAS:
  #-    -tipo: Cadena identificaiva del servidor. Definidas en el 
  #            diccionario SERVIDOR
  #     -verbose (opcional): Indica si se imprimen mensajes o no
  #  DEVUELVE:
  #     -True : Es el servidor esperado
  #     -False: Otro servidor diferente
  #------------------------------------------------------------------
  def check_server_type(self,tipo,verbose=True):
  
    #-- Solo se imprimen mensajes en modo verbose
    if verbose:
      sys.stdout.write("Esperado Servidor %s. " % tipo)
      sys.stdout.flush()
      
    #-- Solicitar servico de identificacion  
    (iserv,im,ip) = self.id_bytes();
    
    if verbose:
      sys.stdout.write("Localizado %s ---> " % SERVIDOR[iserv])
    
    if (tipo.upper()==SERVIDOR[iserv]):
      if verbose: print "OK!"
      return True
    else:
      if verbose: print "ERROR!!!!!!"
      return False
  
  
#---------------------------------------------------------------------
#  CLASE STARGATE GENERICO
#---------------------------------------------------------------------
class Generic(Stargate):

  #-- Inicializar la clase
  def __init__(self, Puerto=0):
    Stargate.__init__(self, Puerto)
   
  #-----------------------------------
  #-- Servicio LOAD
  #-- Devuelve el valor leido
  #-- POR HACER: si no puede leer el valor, se deberia lanzar una excepcion
  #-----------------------------------
  def load(self,dir):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Enviar trama 
    self.serial.write(TRAMA_LOAD_CAB)
    self.serial.write(chr(dir & 0xFF))
    self.serial.write(chr((dir >>8)&0xFF))
    
    #-- Esperar respuesta
    load = self.serial.read(2);
    
    #-- Timeout o dato incorrecto
    if len(load)==0 or load[0]!=TRAMA_RLOAD_CAB: 
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput()
      self.serial.flushOutput()
      return 0
    
    #-- load ok
    return ord(load[1])
    
  #---------------------------------------
  #- Metodo GET. Equivalente a un LOAD  
  #---------------------------------------
  def __getitem__(self, dir):
    return self.load(dir) 

  #-------------------
  #-- Servicio STORE
  #-------------------
  def store(self, dir, valor):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Enviar trama 
    self.serial.write(TRAMA_STORE_CAB)
    self.serial.write(chr(dir & 0xFF))
    self.serial.write(chr((dir >>8)&0xFF))
    self.serial.write(chr(valor&0xFF))
    
    #-- Esperar respuesta
    store = self.serial.read(1);
    
    #-- Timeout o dato incorrecto
    if len(store)==0 or store!=TRAMA_RSTORE_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput()
      self.serial.flushOutput()
      return 0
    
    #-- Store ok
    return 1
 
  #---------------------------------------
  #- Metodo GET. Equivalente a un STORE
  #---------------------------------------
  def __setitem__(self, dir, valor): 
    return self.store(dir,valor)
  
  
#---------------------------------------------------------------------
#  CLASE STARGATE SERVOS8
#---------------------------------------------------------------------
class Servos8(Stargate):

  #-- Inicializar la clase
  def __init__(self, Puerto=0):
    Stargate.__init__(self, Puerto)
    
    #-- Inicializar los limites superiores e inferiorese por defecto
    (self.__li, self.__ls) = EXTREMOS[0x00]
    
  def id_bytes(self):
    
    #-- Leer la identificcion
    (iserv, im, id) = Stargate.id_bytes(self)
    
    #-- si no se identifica el servidor, no se cambian los limites
    #-- del servo
    if (iserv, im, id)==(0,0,0): return (0,0,0)
    
    #-- Segun el tipo de servidor detectado, modificar los limites 
    #-- supeior e inferior de los valores que se pueden enviar
    placa = im<<4 | id>>4
    (self.__li, self.__ls) = EXTREMOS[placa] 
    
    return (iserv, im, id)

  #-------------------
  #-- Servicio ENABLE
  #-------------------
  def enable(self, mask):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Enviar trama 
    self.serial.write(TRAMA_ENA_CAB)
    self.serial.write(chr(mask&0xFF))
    
    return 1
    
  #------------------------------------------------------------------
  #-- Servicio POS
  #-- Se especifica el angulo del servo en grados, entre -90 y 90
  #------------------------------------------------------------------
  def pos(self, servo, pos):
  
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Convertir de grados al rango del servo
    #-- Esta conversion depende de los valores limites (superior e inferior)
    #-- implementados en el servidor
    pos = int((self.__ls - self.__li + 1)/2  + (self.__ls - self.__li)*pos/180)
    
    #-- Invocar el servicio de posicionamiento de bajo nivel
    self.pos_raw(servo,pos)
    
    return 1
  
  #---------------------------------------
  #- Metodo GET. Equivalente a un POS
  #---------------------------------------
  def __setitem__(self, servo, pos): 
    return self.pos(servo,pos)  
  
  #--------------------------------------------------------------------
  #-- Servicio POS de bajo nivel. Se especifica la posicion como un 
  #-- byte entre 0 y 255. Dependiendo del servidor, el servo se 
  #-- situara en un angulo u otro
  #--------------------------------------------------------------------
  def pos_raw(self, servo, pos):
    #-- Si puerto serie no abierto retornar
    if self.serial==None: return 0
    
    #-- Enviar trama 
    self.serial.write(TRAMA_POS_CAB)
    self.serial.write(chr(servo&0xFF))
    self.serial.write(chr(pos&0xFF))
    
    return 1
  
  
  
  
  
#----------------------
#   MAIN
#----------------------
if __name__ == '__main__':

  print "Probando los Stargates en python...."
  s = Stargate(11)
  #s = Servos8(10)
  
  if s.serial!=None:
    print "Puerto serie: %s" % s.serial.portstr;
  
  
  #-- Hacer un ping de prueba
  sys.stdout.write("Ping: ");
  
  if s.ping():
    print "OK!"
  else:
    print "Error"
    
  sys.stdout.flush()
  
  
  #-- Obtener la identificacion
  sys.stdout.write("Serv: ");
  
  print s.id();
  
  s.check_connection();
  
  s.check_server_type("GENERIC");
  
  
  #s.enable(0xFF);
  #s.pos(1,90);
  #s[1]=90;
  
  #-- Hacer stores
  #s[TRISB]=0x00
  #s[PORTB]=0xAA
  
  #-- Hacer load
  #(valor,ok)=s[PORTB]
  
  #if (ok==1):
  #  print "Valor LOAD: %s" % hex(valor)
