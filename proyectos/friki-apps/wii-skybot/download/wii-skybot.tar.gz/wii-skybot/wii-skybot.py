#! /usr/bin/python
#---------------------------------------------------------------------------
#--  (C)2007 Juan Gonzalez
#--
#--  Modulo Stargate para la comunicacion con lo servidores "stargates"
#--
#--  LICENCIA GPL
#---------------------------------------------------------------------------


import pywii
import sys
import time
import stargate
from bluetooth import BluetoothError
from pic16f876 import * 

dirhw =  "00:19:1D:94:AA:77"

#-- Caracter de escape
ESC = '\x1B'

LED_ON  = 0x02
LED_OFF = 0x00
RELE_ON = 0x00
RELE_OFF= 0x20

ADELANTE = 0x1C
ATRAS = 0x16
STOP = 0x00
DERECHA = 0x14
IZQUIERDA = 0x1E

#define ATRAS     0x16 
#define IZQUIERDA 0x1E 
#define DERECHA   0x14
#define STOP      0x00 



#-----------------
#-- Sacar el menu
#-----------------
def menu():
  print """

     Menu de opciones
     ----------------

     1.- LED: on
     2.- LED: off
     3.- RELE: on
     4.- RELE: off
     5.- FLASH

  SP.- Volver a sacar el menu
  ESC.- Terminar
  """

#--------------------------------------------------
#- Modo flash: hacer parpadear el led y el rele
#--------------------------------------------------
def flash():
  for i in range(5):
    g[PORTB]=LED_OFF; g[PORTA]=RELE_OFF
    time.sleep(0.1);
    g[PORTB]=LED_ON; g[PORTA]=RELE_ON
    time.sleep(0.1);
    


#---------------------
#- Comienzo programa
#---------------------

try:
  wii = pywii.Wiimote ()
except BluetoothError:
  print 'Error al conectar'

try:
  wii.start (dirhw)
except BluetoothError:
  print 'Error al iniciar servicio'
  sys.exit (-1)
except IndexError:
  print 'Uso: %s <address>' % sys.argv [0]
  print 'tomando dir: %s' % dirhw
  wii.start (dirhw)


#-- Establecer conexion con stargate
g = stargate.start_typical_session("GENERIC")
  
  
#-- Configurar puertos
g[TRISB]=0xE1;
g[TRISA]=0xFF;
  
#-- Configurar el puerto A para trabajar con los bumpers
g[ADCON1]=0x0E;     


    #~ g[PORTB]=ADELANTE
  #~ elif c=='a':
    #~ g[PORTB]=ATRAS  
  #~ elif c==' ':
    #~ g[PORTB]=STOP  
    #~ print "stop"
  #~ elif c=='p':
    #~ g[PORTB]=DERECHA
  #~ elif c=='o':
    #~ g[PORTB]=IZQUIERDA
  #~ elif c==ESC: break   #-- Salir del bucle

oldpitch=0

estado = STOP
oldestado = STOP

while 1:
  events = wii.getEvents ()
  for ev in events:
    if ev.type == 'Motion':
      (x,y,z) = wii.normalizeForce(ev.data)
      ##print 'x: %0.3f; y: %.3f; z: %.3f' %  (x,y,z)
      
      #-- Recortar los valores de y a [-1,1]
      if y>1.0: y=1.0
      if y<-1.0: y=-1.0
      
      #-- Recortar los valores de x
      if x>1.0: x=1.0
      if x<-1.0: x=-1.0
      
      #-- Leer el "pitch" en grados
      pitch = int (round(90.0*y))
      
      #-- Leer el roll en grados
      roll = int (round(90.0*x))
      
      if roll<-45: 
        estado=IZQUIERDA
      elif roll>45: 
        estado=DERECHA
      elif pitch<-30:
        estado=ATRAS 
      elif pitch>30:
        estado=ADELANTE      
      else:
        estado=STOP
      
      #~ if pitch<-45: 
        #~ estado=ATRAS
      #~ elif pitch>45: 
        #~ estado=ADELANTE
      #~ elif roll<-45:
        #~ estado=IZQUIERDA 
      #~ elif roll>45:
        #~ estado=DERECHA      
      #~ else:
        #~ estado=STOP
          
      if estado!=oldestado:  
        if estado==ADELANTE:
          g[PORTB]=ADELANTE
          print "adelante"
          
        elif estado==ATRAS:
          g[PORTB]=ATRAS        
          print "Atras"
        
        elif estado==IZQUIERDA:
          g[PORTB]=IZQUIERDA
          print "izquierda"
          
        elif estado==DERECHA:
          g[PORTB]=DERECHA
          print "derecha"          
          
        elif estado==STOP:
          g[PORTB]=STOP
          print "Stop"
          
      oldestado=estado    

      #-- Almacenar pitch actual
      oldpitch=pitch
  time.sleep (0.01)
  
g[PORTB]=STOP  
wii.stop ()
print 'Fin'
