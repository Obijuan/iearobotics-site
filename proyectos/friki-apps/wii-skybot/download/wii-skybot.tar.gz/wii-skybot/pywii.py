#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: pywii is a class to control wiimote
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from bluetooth import BluetoothSocket, BluetoothError, L2CAP
import thread, time, sys

class Event:

	def __init__ (self, type, data):
		self.type = type
		self.data = data

class EventQueue:

	def __init__ (self):
		self.__queue = []
	
	def enqueue (self, element):
		self.__queue.append (element)
	
	def first (self):
		return self.__queue [0]

	def dequeue (self):
		if len (self.__queue) > 0:
			return self.__queue.pop (0)
		else:
			return None
	
	def dequeueAll (self):
		ret = self.__queue
		self.__queue = []
		return ret
	
	def clear (self):
		del self.__queue
		self.__queue = []
	
class Wiimote:

	__gid = [0, 0, 0, 0]
	
	def __init__ (self):
		self.__state = 0
		self.__events = EventQueue ()
		self.__control = EventQueue ()
		self.__address = None
		self.__fdin = None
		self.__fdout = None
		self.__id = 0
		self.__rumble = 0
		self.__motionZero = None
		self.__motionOne = None
		self.__buttonState = [0, 0]
	
	def __listener (self):
		print 'Servidor de eventos listo y a la escucha.'
		while self.__state:
			while 1:
				try:
					msg = self.__fdin.recv (23)
				except BluetoothError:
					break
				else:
					msg = [ord (b) for b in msg]

					if msg [1] == 0x21:
						self.__control.enqueue (Event ('Read', msg [2:]))
						continue
					
					if self.__buttonState != msg [2: 3]:
						pass
						# TODO: lanzar un evento por botón cambiado
						# self.__events.enqueue (Event ('ButtonPress/Release', msg [2: 3]))
						self.__buttonState = msg [2: 3]
		
					if msg [1] == 0x31:
						self.__events.enqueue (Event ('Motion', msg [4: 7]))
			
			time.sleep (0.01)
		
		print 'Servidor de eventos muriendo...'
		self.__state = -1

	def __initEventServer (self):
		thread.start_new_thread (self.__listener, ())
	
	def __initConnection (self):
		# Try to connect to Wiimote
		print 'Conectando a %s, presiona 1 y 2' % self.__address
		self.__fdin = BluetoothSocket (L2CAP)
		try:
			self.__fdin.connect ((self.__address, 0x13))
		except BluetoothError:
			raise
		self.__fdout = BluetoothSocket(L2CAP)
		try:
			self.__fdout.connect ((self.__address, 0x11))
		except BluetoothError:
			raise
	
	def __readMem (self, offset, len):
		address = '%c%c' % (offset >> 8, offset % 256)
		size = '%c%c' % (len >> 8, len % 256)
		self.__fdout.send ("\x52\x17\x00\x00%s%s" % (address, size))

		# Wait answer
		while 1:
			ev = self.__control.dequeue ()
			if ev:
				break
			time.sleep (0.01)
		# print ev.type, ev.data

		return ev.data [5:]
	
	def __readZeroes (self):
		data = self.__readMem (0x16, 0x8)
		
		# Set motion origins
		self.__motionZero = data [:3]
		self.__motionOne = data [4:7]
		for i in xrange (3):
			self.__motionOne [i] -= self.__motionZero [i]

	def __initialMessages (self):
		# Set channel 31 active
		self.__fdout.send ("\x52\x12\x00\x31")

		# Set Player led
		available = [i for i, v in enumerate (self.__gid) if v == 0]
		self.__id = available [0]
		byte = 1 << (self.__id + 4)
		self.__fdout.send ("\x52\x11%c" % chr (byte))

	def start (self, address):
		self.__state = 1
		self.__address = address
		try:
			self.__initConnection ()
		except BluetoothError:
			raise
		self.__initialMessages ()
		self.__initEventServer ()
		self.__readZeroes ()
	
	def stop (self):
		self.__state = 0
		while not self.__state:
			time.sleep (0.01)
		self.__events.clear ()
		self.__fdin.close ()
		self.__fdout.close ()
		self.__gid [self.__id] = 0
	
	def getEvents (self):
		return self.__events.dequeueAll ()

	def normalizeForce (self, g):
		ret = [0, 0, 0]
		for i in xrange (3):
			ret [i] = float ((g [i] - self.__motionZero [i])) / self.__motionOne [i]
		return ret

if __name__ == '__main__':
	try:
		wii = Wiimote ()
	except BluetoothError:
		print 'Error al conectar'

	try:
		wii.start (sys.argv [1])
	except BluetoothError:
		print 'Error al iniciar servicio'
		sys.exit (-1)
	except IndexError:
		print 'Uso: %s <address>' % sys.argv [0]
		sys.exit (-1)

	while 1:
		events = wii.getEvents ()
		for ev in events:
			if ev.type == 'Motion':
				print 'x: %0.3f; y: %.3f; z: %.3f' % tuple (wii.normalizeForce (ev.data))
		time.sleep (0.01)
	
	wii.stop ()
	print 'Fin'
