Para poner en marcha un nuevo mando:

1) Encontrar la direccion del mando:

$ hcitool scan
Scanning ...
        00:19:1D:94:AA:77       Nintendo RVL-CNT-01

  Asegurarse que los leds están parpadeando

2) Editar los ficheros .c para poner la direccion hardware en ellos

3) compilar con make

4) A frikear!!!!!
