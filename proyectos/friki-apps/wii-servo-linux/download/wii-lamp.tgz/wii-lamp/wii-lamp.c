#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h> 
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

#include "wiimote.h"
#include "wiimote_api.h"

#include "consola_io.h"
#include "stargate.h"


GLfloat matBlanco[] = {1.0, 1.0, 1.0, 1.0};

wiimote_t wiimando = WIIMOTE_INIT;
wiimote_report_t estado = WIIMOTE_REPORT_INIT;
float rotx=.0, roty=.0, rotz=.0;
float escala=1.0;
float tx=.0, ty=.0, tz=.0;


/****************/
/* CONSTANTES   */
/****************/
#define TRISA 0x85
#define PORTA 0x05
#define ON    0x08  
#define OFF   0x20

/*****************************/
/*    FUNCIONES              */
/*****************************/

/********************************/
/* Identificacion del servidor  */
/********************************/
int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Prueba de la SKYLAMP\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexión establecida\n");
  else {
    printf ("Conexión NO establecida\n");
    exit(1);
  }
}





void dibujar() 
{ 
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 
    glLoadIdentity(); 
    gluLookAt(0.0, 1.0, 8.0, 0.0, 1.0, 0.0, 0.0, 1.0, 0.0);

	 glTranslatef(tx, ty, tz);
    glPushMatrix();
	 glRotatef (90, 1.0, 0.0, 0.0);
	 glRotatef (-rotx, 1, 0, 0);
	 glRotatef (roty, 0, 1, 0);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, matBlanco);
    glPushMatrix();
    	 glScalef (5.0 * escala, 2.0 * escala, 1.2 * escala);
       glutSolidCube(1.0);
    glPopMatrix();
	 glutSwapBuffers();      
} 

void escalar(int w, int h) 
{ 
  // Viewport para dibujar en toda la ventana 
  glViewport( 0, 0, w, h ); 
  
  // Actualizamos en la matriz de proyección el ratio ancho/alto 
  glMatrixMode( GL_PROJECTION ); 
  glLoadIdentity(); 
  gluPerspective( 60., (double)w/(double)h, 1., 20. ); 
  
  // Volvemos al modo Vista de Modelo 
  glMatrixMode( GL_MODELVIEW ); 
}

void actualizar()
{
  static int oldboton=0;
  static int oldpos=0;
  static int cont=0;
  
	if (wiimote_is_open(&wiimando)) {
		if ((wiimote_update(&wiimando) < 0) || (wiimando.keys.home)) {
			wiimote_disconnect(&wiimando); exit(1);
		}

		estado.channel = WIIMOTE_RID_STATUS;
		wiimote_report(&wiimando, &estado, sizeof(estado.status));

		if ((wiimando.tilt.x > -180) && (wiimando.tilt.x < 180))
			rotx = wiimando.tilt.x;
		if ((wiimando.tilt.y > -180) && (wiimando.tilt.y < 180))
			roty = wiimando.tilt.y;
    
    if (roty>=60 && oldpos!=2) {
      printf ("D");
      fflush(stdout);
      oldpos=2;
     
      
      sg_store(TRISA,0x1F);
		  sg_store(PORTA,0x20);  //-- OFF
    }
    
    if (roty<=-60 && oldpos!=1) {
      printf ("U");
      fflush(stdout);
      oldpos=1;
      
      sg_store(TRISA,0x1F);
			sg_store(PORTA,0x00);  //-- ON
      
     
    }

    
    
    
		if (wiimando.keys.one && oldboton!=1) {
      escala+=0.01;
      printf ("."); fflush(stdout);
      oldboton=1;
      sg_store(TRISA,0x1F);
			sg_store(PORTA,0x00);  //-- ON
    }  
    
		if (wiimando.keys.two && oldboton!=2) {
      escala-=0.01;
      printf ("*"); fflush(stdout);
      oldboton=2;
      sg_store(TRISA,0x1F);
		  sg_store(PORTA,0x20);  //-- OFF
    }  
    
    
		if (wiimando.keys.up && cont==0) {
      printf ("+"); fflush(stdout);
      cont = (cont + 1) % 20;
    };
      
    
		if (wiimando.keys.down)  tx+=0.03;
		if (wiimando.keys.right) ty+=0.03;
		if (wiimando.keys.left)  ty-=0.03;
	}
	glutPostRedisplay();
}


int main( int argc, char** argv ) 
{ 
  char c=0;
  int i;
  int est=0;
  int serial_fd;  /*-- Descriptor puerto serie */
  
  //-- Configurar la consola
  //consola_io_open();
  
   //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el módulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  inicio();
  
  //-- Configurar SKYPIC
  sg_store(TRISA,0x1F);
  
  GLfloat posluz[] = {0.0, 4.0, 8.0, 0.0}; 
  GLfloat luz[] = {1.0, 1.0, 1.0, 1.0};

  glutInit( &argc, argv ); 
  
  glutInitDisplayMode( GLUT_DEPTH | GLUT_RGB | GLUT_DOUBLE ); 
  glutInitWindowSize(640, 480); 
  glutCreateWindow( "Ejemplo WiiMando" ); 
  
  glClearColor(0.2, 0.2, 0.2, 1.0);
  glShadeModel(GL_SMOOTH);
  glLightfv(GL_LIGHT0, GL_POSITION, posluz);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, luz);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);
  glEnable(GL_DEPTH_TEST);

  printf ("Pulsa los botones 1 y 2 del WiiMando simultáneamente para conectar...\n");

  // Conectamos con el wiimando
  if (wiimote_connect(&wiimando, "00:19:1D:94:AA:77") < 0) {
		printf ("No se pudo conectar con wiimando: %s\n", 
    wiimote_get_error());
    //-- Consola a su estado inicial
    consola_io_close();

    //-- Cerrar puerto serie
    close(serial_fd);
    exit(1);
  }

  printf ("Conectado!!\n");

  wiimando.led.one = 1;  // Activamos el primer led del wiimando	
  wiimando.rumble = 0;   
  wiimando.mode.acc = 1; // Activamos el acelerometro

  // Registro de funciones de callback
  glutDisplayFunc(dibujar); 
  glutReshapeFunc(escalar); 
  glutIdleFunc(actualizar); 
  glutMainLoop();  
  
   //-- Bucle principal
  do {
   // if (consola_io_kbhit())
      //-- Leer caracter
	 //   c=consola_io_getch();
    
    if (wiimote_is_open(&wiimando)) {
      if ((wiimote_update(&wiimando) < 0) || (wiimando.keys.home)) {
        wiimote_disconnect(&wiimando);
        //-- Consola a su estado inicial
        consola_io_close();

        //-- Cerrar puerto serie
        close(serial_fd);
        exit(1);
      }
  
      estado.channel = WIIMOTE_RID_STATUS;
      wiimote_report(&wiimando, &estado, sizeof(estado.status));
  
      if ((wiimando.tilt.x > -180) && (wiimando.tilt.x < 180))
        rotx = wiimando.tilt.x;
      if ((wiimando.tilt.y > -180) && (wiimando.tilt.y < 180))
        roty = wiimando.tilt.y;
  
      if (wiimando.keys.one) {
        printf ("ENCENDIDO!!!\n");
        //sg_store(TRISA,0x1F);
			  //sg_store(PORTA,0x00);  //-- ON
      }
      if (wiimando.keys.two) {
        printf ("APAGADO!!\n");
        //sg_store(TRISA,0x1F);
		    //sg_store(PORTA,0x20);  //-- OFF
      }
      
     if (wiimando.keys.up) {
       for (i=0; i<100; i++) {
					sg_store(TRISA,0x1F);
					if (est==1) 
					  sg_store(PORTA,0x20);  //-- OFF
					else
						sg_store(PORTA,0x08);  //-- ON
					est=(est+1) % 2;
					usleep(50000);
				}
     }
     
     // if (wiimando.keys.down)  tx+=0.03;
     // if (wiimando.keys.right) ty+=0.03;
     // if (wiimando.keys.left)  ty-=0.03;
	  }
    
    usleep(5000); 
    
  } while (c!=27);
  
  
  
  //-- Consola a su estado inicial
  //consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
  
}
