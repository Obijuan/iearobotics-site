#!/usr/bin/python
# -*- coding: iso-8859-15 -*-

#***********************************************************************#
#* setup.py.  Rafael Treviño. Junio 2006                               *#
#*---------------------------------------------------------------------*#
#* LICENCIA GPL                                                        *#
#*---------------------------------------------------------------------*#
#* Script de construccion de la extension drawstuff.so usando las      *#
#* distutils de Python                                                 *#
#*---------------------------------------------------------------------*#
#* Para usarlo basta con ejecutar:                                     *#
#*   ./setup.py build                                                  *#
#***********************************************************************#

from distutils.core import setup, Extension

# LDFLAGS = -lpthread -lglut -lGLU -lGL -lm -lXi -lX11 -lXmu -lXext

module1 = Extension('drawstuff',
		    include_dirs = ['/usr/X11R6/include'],
		    libraries = ['GLU', 'GL'],
		    library_dirs = ['/usr/X11R6/lib'],
                    sources = ['drawstuff.cpp', 'x11.cpp'])

setup (name = 'drawstuff',
       version = '1.0',
       description = 'This is a drawing package.',
       ext_modules = [module1])
