
/***********************************************************************/
/*  		Gd_ifaz.c: interfaz GTK para downmcu.		       */
/*				 				       */
/*	Microb�tica, S.L. ---- GDOWNMCU ---- Marzo 2000		       */
/***********************************************************************/

#include <gtk/gtk.h>

// Prototipos de SELFILE.C
char *GetFilename (char *sTitle);

// Prototipos de DMCUGTK.C
int downm(char *nomfich, char pcom[6]);

// Prototipos de VCARGA.C
//void crea_vent_carga(char *fich, char *port);
void cierra_load();
void crece_barra(long pos, long len);

// Prototipos de CREA_WDIGETS.C
//GtkWidget *crea_pixmap();
GtkWidget *CreateCombobox();
void crea_frames();
void crea_selec_com();
void crea_grupo_selfich();
void crea_grupo_bot();
void mensaje_ayuda();

// Prototipos en GD-IFAZ.C
// fichero_clicked(...) 
// cargar_clicked(...)
// ayuda_clicked(...)
// mensaje_ayuda(..) 
// cierra_ayuda(..)

// Vars globales
GtkWidget *entrada1;
GtkWidget *entrada2;
GtkWidget *window;
GtkWidget *table;

/*---------------------------------------------------------------------*/

void fichero_clicked (GtkWidget *widget, gpointer data)
{
  char *sFile = GetFilename ("Selecci�n de fichero");  
  gtk_entry_set_text(GTK_ENTRY(entrada2), sFile);
}

/*--------------------------------------------------------------------*/

void cargar_clicked (GtkWidget *widget, gpointer data)
/*
Llamar a la ventana con barra de progreso y pasarle el parametro
del nombre del fichero y COM para ejecutar el downmcu)
*/
{
 char *fichero;
 char *puerto;

 fichero=gtk_entry_get_text(GTK_ENTRY (entrada2));
 puerto=gtk_entry_get_text(GTK_ENTRY (GTK_COMBO(entrada1)->entry));  
 downm(fichero, puerto);
}

/*--------------------------------------------------------------------*/

void ayuda_clicked (GtkWidget *widget, gpointer data)
{
 mensaje_ayuda();
}

/*--------------------------------------------------------------------*/

int CloseApp (GtkWidget *widget, gpointer *data)
{
 g_print("Fin del programa\n");
 gtk_main_quit();
 return(FALSE);
}

/*---------------------------------------------------------------------*/

int main (int argc, char *argv[])
{
    // Inicializaci�n de GTK
    gtk_init (&argc, &argv);   	        	

    // VENTANA PRINCIPAL
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "     GDOWNMCU     ");
    gtk_widget_set_usize (window, 450, 100);
    gtk_widget_set_uposition (window, 250, 125);
    gtk_container_set_border_width (GTK_CONTAINER (window), 20);
    gtk_signal_connect (GTK_OBJECT (window), "delete_event",
				GTK_SIGNAL_FUNC (CloseApp), NULL);

    //TABLA
    table= gtk_table_new (2, 2, FALSE);	//tabla de 3 filas y 2 columnas con espaciado homogeneo o no (True/False)


   /*--------------------------------------------------------------------*/
    //Si hay par�metros 
    if (argc>=3) { 
     crea_selec_com(argv[2]);
     crea_grupo_selfich(argv[1]); 
    }
    else if (argc==2) {
     crea_selec_com("-com2");
     crea_grupo_selfich(argv[1]); 
    }
    else if (argc<=1) {
     crea_selec_com("-com2");
     crea_grupo_selfich("fichero.s19"); 
    } 
    crea_grupo_bot();

   /*---------------------------------------------------------------------*/

    //CONTENEDORES
    gtk_container_add (GTK_CONTAINER (window), table);

    // SHOW
    gtk_widget_show (table);
    gtk_widget_show (window);
    
    gtk_main ();
    return (0);
}



