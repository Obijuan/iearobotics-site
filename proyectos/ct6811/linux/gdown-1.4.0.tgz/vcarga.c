
/***********************************************************************/
/*  Vcarga.c: creaci�n y manejo de la ventana de carga de fichero s19, */
/*  (creaci�n y manejo de barra de progreso)			       */
/*				 				       */
/*	Microb�tica, S.L. ---- GDOWNMCU ---- Marzo 2000		       */
/***********************************************************************/

#include <gtk/gtk.h>

GtkWidget *barra_prog;
guint iter=0;

/*--------------------------------------------------------------------*/

void crece_barra()
{
 gfloat porcent;
  
  	// El incremento de 15 lo marca la ctlib (o el downmcu)
  iter=iter+1; 
  if (iter==16) iter=0;
  porcent= (6.66*iter)/100;			//(100/15)=6.66  
	
	// Redibujar la barra y su entorno
  gtk_progress_set_percentage(GTK_PROGRESS (barra_prog), porcent);
  while (gtk_events_pending ()) { 
     gtk_main_iteration ();  
    } 
}


/*--------------------------------------------------------------------*/

void cierra_load (GtkWidget *widget, gpointer data)
{
 gtk_grab_remove(GTK_WIDGET (data));		// Devuelve el control atrapado por gtk_grab_add()
 gtk_widget_destroy (GTK_WIDGET (data));	
}

/*--------------------------------------------------------------------*/

GtkWidget* crea_vent_carga(char *fich, char *port)
{
 GtkWidget *vent_load;
 GtkWidget *label;
 GtkWidget *boton_cancel;
// GtkWidget *barra_prog;
 GtkWidget *label_fich;
 GtkWidget *label_port;
 
	vent_load = gtk_dialog_new();	// Ventana con 'vbox' (para mensaje) y 'action_area'  (para botones)
	
        gtk_window_set_title(GTK_WINDOW(vent_load), "   Carga de fichero   ");
	gtk_container_border_width(GTK_CONTAINER(vent_load), 0);
	gtk_widget_set_uposition(vent_load, 240,260);
	
		//Label y barra de progreso y entry con parametros
	label = gtk_label_new("Cargando con par�metros:");
	gtk_misc_set_padding (GTK_MISC(label), 10,10); //Dar algo de espacio

	label_fich = gtk_label_new("");	
	gtk_label_set_text(GTK_LABEL(label_fich), fich); 
	label_port = gtk_label_new("");
	gtk_label_set_text(GTK_LABEL(label_port), port); 

	barra_prog = gtk_progress_bar_new();
	gtk_progress_set_percentage(GTK_PROGRESS(barra_prog), 0);
	gtk_progress_set_show_text(GTK_PROGRESS(barra_prog), 0); //Pone el porcentaje
	
	gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_load)->vbox), label, TRUE, TRUE,0);
	gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_load)->vbox), label_port, TRUE, TRUE,0);	
	gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_load)->vbox), label_fich, TRUE, TRUE,0);	
	gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_load)->vbox), barra_prog, TRUE, TRUE,10);

		//Bot�n
	boton_cancel= gtk_button_new_with_label(" Cerrar ");
	gtk_signal_connect(GTK_OBJECT(boton_cancel), "clicked",
					GTK_SIGNAL_FUNC(cierra_load), vent_load);
	gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_load)->action_area), boton_cancel, FALSE, FALSE,0);
	GTK_WIDGET_SET_FLAGS(boton_cancel, GTK_CAN_DEFAULT);	// Permitir que sea Marcado por defecto
	gtk_widget_grab_default(boton_cancel);					//  Marcarlo por defecto
	
    gtk_grab_add(vent_load);	// Coge el control ('Atrapa el foco'). Hay que cerrar la ventana antes de poder seguir
		
	gtk_widget_show(label);
	gtk_widget_show(label_port);	
	gtk_widget_show(label_fich);	
	gtk_widget_show(barra_prog);
	gtk_widget_show(boton_cancel);
	gtk_widget_show(vent_load);	
  return (vent_load);	
}


/*--------------------------------------------------------------------*/


