/***********************************************************************/
/*  Crea_widgets.c: creaci�n de los widgets de la ventana principal:   */
/*  pixmap, combobox, grupo botones, dialogo de seleccion de fichero,  */
/*  combo seleccion de COM, frames.				       */				   
/*				 				       */
/*	Microb�tica, S.L. ---- GDOWNMCU ---- Marzo 2000		       */
/***********************************************************************/

#include <gtk/gtk.h>
#include <string.h>
#include "pixmaps.h"

extern GtkWidget *window;
extern GtkWidget *table;
extern GtkWidget *entrada1;
extern GtkWidget *entrada2;

// Prototipos de GD-IFAZ.C
void fichero_clicked (GtkWidget *widget, gpointer data);
void cargar_clicked (GtkWidget *widget, gpointer data);
void ayuda_clicked (GtkWidget *widget, gpointer data);
int CloseApp (GtkWidget *widget, gpointer *data);
                                            
/*-----------------------------------------------------------------------*/

// Crea los iconos a partir de los datos en pixmap.h
GtkWidget *crea_icono_data (GtkWidget *widget, gchar **xpm_data)
{
    GdkColormap *colormap;
    GdkBitmap *mask;
    GdkPixmap *pixmap_data;
    GtkWidget *pixmap_widget;

    colormap = gtk_widget_get_colormap (widget);
    pixmap_data = gdk_pixmap_colormap_create_from_xpm_d (
                                 NULL, colormap, 
                                 &mask, NULL,
                                 (gchar **) xpm_data);

    pixmap_widget = gtk_pixmap_new (pixmap_data, mask);
    gtk_widget_show (pixmap_widget);

    return (pixmap_widget);
}


/*----------------------------------------------------------------------*/

GtkWidget *CreateCombobox ()
{
    GList *cbitems = NULL;
    GtkWidget *combo;

    cbitems = g_list_append (cbitems, "-com1");
    cbitems = g_list_append (cbitems, "-com2");

    combo = gtk_combo_new ();
    gtk_combo_set_popdown_strings (GTK_COMBO(combo), cbitems);
    // gtk_entry_set_text (GTK_ENTRY (GTK_COMBO(combo)->entry), "-com2"); //Por defecto
    gtk_entry_set_editable (GTK_ENTRY (GTK_COMBO (combo)->entry), FALSE);

    gtk_widget_show (combo);
    return (combo);
}

/*---------------------------------------------------------------------*/

void crea_selec_com(char *param_com)
{
   //Seleccion COM
   entrada1 = CreateCombobox ();    
   gtk_widget_set_usize(entrada1, 80, 0); // '0' indica tam por defecto.
   gtk_entry_set_text(GTK_ENTRY(GTK_COMBO(entrada1)->entry), param_com);
   
   gtk_table_attach (GTK_TABLE (table), entrada1,
                      0, 1,
                      1, 2,
                      GTK_SHRINK,						
                      GTK_SHRINK,			//FILL
                      0, 0);		
    gtk_widget_show(entrada1);
}
     	 
/*------------------------------------------------------------*/  

void crea_grupo_selfich(char *param_fich)
{	
   GtkWidget *boton_fichero; 
   GtkWidget *box2;       
 
   //EMPAQ horizontal con Entry y Boton (Selecci�n fichero)
    box2= gtk_hbox_new (FALSE, 0);
	
	boton_fichero = gtk_button_new_with_label(" Seleccionar ");
	gtk_widget_set_usize(boton_fichero, 85, 15);
	gtk_signal_connect (GTK_OBJECT (boton_fichero), "clicked",
				fichero_clicked, NULL);	
	gtk_widget_show(boton_fichero);

	entrada2 = gtk_entry_new_with_max_length(125);
	gtk_widget_set_usize(entrada2, 300, 0);
	gtk_entry_set_text(GTK_ENTRY(entrada2), param_fich);	
	gtk_widget_show(entrada2);

	gtk_box_pack_start( GTK_BOX(box2), entrada2, FALSE, FALSE, 0);
	gtk_box_pack_start( GTK_BOX(box2), boton_fichero, FALSE, FALSE, 5);

	gtk_table_attach (GTK_TABLE (table), box2,
                      0, 2,
                      0, 1,							// Ocupa 2 celdas!!
                      GTK_SHRINK,						
                      GTK_SHRINK,
                      0, 0);							// xpadding, ypadding
	 gtk_widget_show (box2);
}

/*---------------------------------------------------------------------*/


void crea_grupo_bot()
{
   GtkWidget *barra_bot; 
   GtkWidget *boton_c;
   
   
   barra_bot = gtk_toolbar_new (GTK_ORIENTATION_HORIZONTAL, GTK_TOOLBAR_BOTH);   
   boton_c=gtk_toolbar_append_item (GTK_TOOLBAR(barra_bot),  
                            " Cargar ", NULL, NULL, 
                             crea_icono_data (window, (gchar**) jmove_xpm), 
                             cargar_clicked,             
                             NULL);             
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));

   gtk_toolbar_append_item (GTK_TOOLBAR(barra_bot),  
                            " Ayuda ", NULL, NULL, 
                             crea_icono_data (window, (gchar**) info), 
                             ayuda_clicked,             
                             NULL);             
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));


   gtk_toolbar_append_item (GTK_TOOLBAR(barra_bot),  
                            " Salir ", NULL, NULL, 
                             crea_icono_data (window, (gchar**) mini_exit), 
                             GTK_SIGNAL_FUNC(CloseApp),             
                             NULL);             
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));
   gtk_toolbar_append_space(GTK_TOOLBAR(barra_bot));

   // Marcado por defecto el de cargar
   /* No Func
   GTK_WIDGET_SET_FLAGS(boton_c, GTK_CAN_DEFAULT);  
   gtk_widget_grab_default(boton_c);  
   */

   gtk_table_attach (GTK_TABLE (table), barra_bot,
                      1, 2,
                      1, 2,
                      GTK_SHRINK,	//EXPAND				
                      GTK_SHRINK,	//EXPAND
                      0, 50);       	// xpadding, ypadding   

   gtk_widget_show (barra_bot);
}


/*--------------------------------------------------------------------------*/

void cierra_ayuda (GtkWidget *widget, gpointer data) 
{
 gtk_grab_remove(GTK_WIDGET (data));            // Devuelve el control atrapado 
 gtk_widget_destroy (GTK_WIDGET (data));       
}


void mensaje_ayuda()
{
 GtkWidget *vent_ayuda;
 GtkWidget *label_ayuda;
 GtkWidget *boton_ayuda;
 GtkWidget *icono_logo;
 GdkColor azul = {0, 0x00FF, 0x00FF, 0xCFFF};
 GtkStyle *estilo_orig;
 GtkStyle *estilo_ayuda;
 char *parrafo;
 
 estilo_orig = gtk_widget_get_default_style();  
 estilo_ayuda = gtk_style_copy (estilo_orig);
 gdk_color_alloc (gdk_colormap_get_system(), &azul);    
 estilo_ayuda->fg[GTK_STATE_NORMAL] = azul;

 vent_ayuda = gtk_dialog_new();	 // Ventana con 'vbox' (para mensaje) y 'action_area'  (para botones)
 gtk_widget_set_usize(vent_ayuda, 300,375);
 gtk_window_set_title(GTK_WINDOW(vent_ayuda), "  Ayuda  ");
 gtk_container_border_width(GTK_CONTAINER(vent_ayuda), 5); 
 gtk_widget_set_uposition(vent_ayuda, 240,260);

   //PIXMAP 
   //icono_logo = crea_pixmap(window, "logom.xpm"); 
 icono_logo= crea_icono_data(window, (gchar **)final_peq);
 
   //LABEL
 parrafo="Gdowmncu v1.0. Marzo 2000.  \
  \n Basado en el Downmcu version 1.4.0 \
  \n\n Microb�tica, S.L.   www.microbotica.es \
  \n   __________________________________________ \
  \n\n Forma de uso del downmcu: \
  \n downmcu fichero.s19 [opciones] \
  \n\n [opciones]: \
  \n -com1 Utilizar el COM1 \
  \n -com2 Utilizar el COM2 \
  \n -h    Ayuda \
  \n\n Ejemplo: downmcu ledp.s19 -com2"; 

 label_ayuda = gtk_label_new(parrafo);
 gtk_widget_set_style(label_ayuda, estilo_ayuda); // Colores
 gtk_misc_set_padding (GTK_MISC(label_ayuda), 10,10);		//Dar algo de espacio
 
   //Situar Label e Icono
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ayuda)->vbox), icono_logo, TRUE, TRUE,0);
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ayuda)->vbox), label_ayuda, TRUE, TRUE,0);


   //Bot�n
 boton_ayuda= gtk_button_new_with_label(" Cerrar ");
 gtk_signal_connect(GTK_OBJECT(boton_ayuda), "clicked",
				GTK_SIGNAL_FUNC(cierra_ayuda), vent_ayuda);
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ayuda)->action_area), boton_ayuda, FALSE, FALSE,0);
 GTK_WIDGET_SET_FLAGS(boton_ayuda, GTK_CAN_DEFAULT);	// Permitir que sea Marcado por defecto
 gtk_widget_grab_default(boton_ayuda);			//  Marcarlo por defecto

 gtk_widget_show(label_ayuda);
 gtk_widget_show(icono_logo);
 gtk_widget_show(boton_ayuda);
 gtk_widget_show(vent_ayuda);	
}


