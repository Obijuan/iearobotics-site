
/***********************************************************************/
/*  Selfile.c: creaci�n y manejo del di�logo de selecci�n de fichero   */
/*								       */
/*	Microb�tica, S.L. ---- GDOWNMCU ---- Marzo 2000		       */
/***********************************************************************/

#include <gtk/gtk.h>

static   GtkWidget     *filew;
static   char          *sFilename = NULL; 
    
/*---------------------------------------------------------------------*/

void file_ok_sel (GtkWidget *w, GtkFileSelection *fs)
{
  char *sTempFile;

  sTempFile = gtk_file_selection_get_filename (GTK_FILE_SELECTION (fs));
	// g_print ("Getting %s\n", sTempFile);
  sFilename = g_malloc (sizeof (char) * (strlen (sTempFile) + 1));
  strcpy (sFilename, sTempFile);

  gtk_widget_destroy (filew);
}


void file_cancel_sel (GtkWidget *w, GtkFileSelection *fs)
{
  gtk_widget_destroy (filew);
}


/*--------------------------------------------------------------------*/

int DestroyDialog (GtkWidget *widget, gpointer *data)
{
    gtk_grab_remove (widget);
    gtk_main_quit ();
    return (FALSE);
}


/*--------------------------------------------------------------------*/

char *GetFilename (char *sTitle)
{ 
    filew = gtk_file_selection_new (sTitle);
    gtk_file_selection_hide_fileop_buttons (GTK_FILE_SELECTION(filew));
    // Valor predeterminado
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(filew), "");    
    gtk_widget_set_uposition(filew, 525,260);
    
    gtk_signal_connect (GTK_OBJECT (filew), "destroy",
            (GtkSignalFunc) DestroyDialog, &filew);

    gtk_signal_connect (
            GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button),
            "clicked", (GtkSignalFunc) file_ok_sel, filew );
    gtk_signal_connect (
             GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
             "clicked", (GtkSignalFunc) file_cancel_sel, filew);
    
    
    gtk_widget_show (filew);
    gtk_grab_add (filew);
    gtk_main ();
    return (sFilename);
}


/*-----------------------------------------------------------------------*/


