**************************************************************************
* 		MICROBOTICA, S.L. --	Marzo 2000 	                 *
* ---------------------------------------------------------------------- *
* 		http://www.microbotica.es                                *
* 		e-mail: microbot@microbotica.es                          *
**************************************************************************

	
	El GDOWN es la versi�n con interfaz gr�fico (GTK) del programa 
DOWNMCU de Microb�tica,S.L. perteneciente a las CTTOOLS.


  LICENCIA
  ---------
  Licencia GPL.

  Las CTTOOLS son un producto FREEWARE y se distribuyen junto con los 
ficheros fuente. El objetivo de que las fuentes sean 'abiertas' es permitir
que la gente se implique en el desarrollo de aplicaciones con la tarjeta
CT6811 o similares y que cada vez se vaya obteniendo un software mas 
robusto y de mayor calidad.


  MICROBOTICA
  -----------

  MICROBOTICA,S.L es una empresa joven que se dedica a realizar proyectos
de ingenieria, tanto hardware como software. El 90% de nuestros desarrollos
los hacemos en LINUX y por ello nos unimos al movimiento de 'Open Sources'.
Las fuentes que realicemos estaran disponibles siempre y cuando nuestros
clientes esten de acuerdo :-) , puesto que si pagan dinero por un proyecto
no es justo que otros se aprovechen de su inversion.

  MICROBOTICA, S.L tambien apuesta por el Free HARDWARE o Hardware libre. La
idea que hay detras de esto es la de la libre circulacion de los esquematicos
y PCBs de los diferentes dise�os electronicos. Esto, a la largo, contribuira
a mejorar el hardware y a que cada vez mas gente tenga acceso al enrevesado
mundo del hardware, que hoy por hoy esta reservado para unos pocos elegidos.

  Al igual que Linux es Gratis, pero existen empresas que venden distribuciones
de Linux, MICROBOTICA, S.L pretende hacer lo mismo con el Hardware: Crear
dise�os freeware, en donde los circuitos y pcb's son gratis y todo el mundo
los puede ver y modificar, pero si los quieren ya construidos, montados y 
probados, MICROBOTICA, S.L los vende.

  Para cualquier sugerencia pueden enviar un mail a:

      microbot@microbotica.es


  Toda la informacion sobre el Free Hardware y el Free Software de MICROBOTICA
se ira publicando poco a poco en nuestra pagina Web. Si no lo hacemos antes
es porque no tenemos tiempo!! Asi que por favor, si quieres obtener informacion
sobre nuestros desarrollos hardware deberas esperar a que lo publiquemos en
la web.



