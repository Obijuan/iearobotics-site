
/***********************************************************************/
/*  Dmcugtk.c:    						       */
/*  Adaptaci�n del downmcu.c al entorno gr�fico de GTK		       */
/*  El 'main' paso a ser downm(fich, pcom)                             */
/*				 				       */
/*	Microb�tica, S.L. ---- GDOWNMCU ---- Marzo 2000		       */
/***********************************************************************/

#include <gtk/gtk.h>
#include <stdio.h>   
#include "serie.h"
#include "s19.h"
#include "bootstrp.h"

// -- Prototipos ---
// de TERMANSI.C
void configansi(int t);
void setcolor(char c);
void high();
void low();

//de IO.C
void print(char *cad);

//de VCARGA.C
GtkWidget* crea_vent_carga(char *fich, char *port); 
void crece_barra();
void cierra_load(GtkWidget *widget, gpointer data);

//de CREA_WIDGETS.C
void mensaje_ayuda();

//------------------------------------

GtkWidget *label_error;

int puerto;
char fich[80];

 // Para carga()
int i=0;
int n=0;

//--------------------------------------------------------

void cierra_aviso (GtkWidget *widget, gpointer data) 
{
 gtk_grab_remove(GTK_WIDGET (data));            // Devuelve el control atrapado 
 gtk_widget_destroy (GTK_WIDGET (data));       
}

//----------------------------------------------------------

void mensaje_error(guint codigo)
{
 GtkWidget *vent_error;
 //GtkWidget *label_error;
 GtkWidget *boton_error;
 GdkColor rojo = {0, 0xDFFF, 0x00FF, 0x00FF};
 GtkStyle *estilo_orig;
 GtkStyle *estilo_error;
 
 estilo_orig = gtk_widget_get_default_style();  
 estilo_error = gtk_style_copy (estilo_orig);
 gdk_color_alloc (gdk_colormap_get_system(), &rojo);    
 estilo_error->fg[GTK_STATE_NORMAL] = rojo;
 
 vent_error = gtk_dialog_new();	 // Ventana con 'vbox' (para mensaje) y 'action_area'  (para botones)
 gtk_window_set_title(GTK_WINDOW(vent_error), "  Error  ");
 gtk_container_border_width(GTK_CONTAINER(vent_error), 5); 
 gtk_widget_set_uposition(vent_error, 240,260);
 
 //Mensaje
 switch (codigo) { 
 case 1: label_error = gtk_label_new("ERROR: El programa NO es para la RAM interna"); 
 	 break;
 case 2: label_error = gtk_label_new("ERROR: El programa desborda la RAM interna");
 	 break;
 case 3: label_error = gtk_label_new("Error al abrir puerto serie ");
 	 break; 	 
 default: break; 
 }
 gtk_widget_set_style(label_error, estilo_error); // Colores
 gtk_misc_set_padding (GTK_MISC(label_error), 10,10);		//Dar algo de espacio
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_error)->vbox), label_error, TRUE, TRUE,0);

 //Bot�n
 boton_error= gtk_button_new_with_label(" Cerrar ");
 gtk_signal_connect(GTK_OBJECT(boton_error), "clicked",
				GTK_SIGNAL_FUNC(cierra_aviso), vent_error);
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_error)->action_area), boton_error, FALSE, FALSE,0);
 GTK_WIDGET_SET_FLAGS(boton_error, GTK_CAN_DEFAULT);	// Permitir que sea Marcado por defecto
 gtk_widget_grab_default(boton_error);			//  Marcarlo por defecto
	
 gtk_grab_add(vent_error);	// Coge el control ('Atrapa el foco'). Hay que cerrar la ventana antes de poder seguir
		
 gtk_widget_show(label_error);
 gtk_widget_show(boton_error);
 gtk_widget_show(vent_error);	
}


//----------------------------------------------------------

void mensaje_ok(S19 fs19)
{
 GtkWidget *vent_ok;
 GtkWidget *label_ok;
 GtkWidget *label2_ok;
 GtkWidget *boton_ok;
 GdkColor verde = {0, 0x00FF, 0xAFFF, 0x0FFF};
 GtkStyle *estilo_orig;
 GtkStyle *estilo_ok;
 char cadena[11];	// 5 posibles digitos + ' bytes'
 gint nbytes;
 
 estilo_orig = gtk_widget_get_default_style();  
 estilo_ok = gtk_style_copy (estilo_orig);
 gdk_color_alloc (gdk_colormap_get_system(), &verde);    
 estilo_ok->fg[GTK_STATE_NORMAL] = verde;
 
 vent_ok = gtk_dialog_new();	 // Ventana con 'vbox' (para mensaje) y 'action_area'  (para botones)
 gtk_window_set_title(GTK_WINDOW(vent_ok), "  OK  ");
 gtk_container_border_width(GTK_CONTAINER(vent_ok), 5); 
 gtk_widget_set_uposition(vent_ok, 525,260);
 
 //Mensaje
 label_ok = gtk_label_new("Env�o correcto\n\nTama�o del programa: ");
 gtk_widget_set_style(label_ok, estilo_ok); // Colores
 gtk_misc_set_padding (GTK_MISC(label_ok), 10,10);  //Dar algo de espacio

 nbytes=getnbytes19(fs19);
 sprintf(cadena, "%i bytes", nbytes);			// Transf en cadena un entero
 label2_ok = gtk_label_new("");
 gtk_label_set_text(GTK_LABEL(label2_ok), cadena);
 
 gtk_widget_set_style(label2_ok, estilo_ok); // Colores
 gtk_misc_set_padding (GTK_MISC(label2_ok), 10,10);  //Dar algo de espacio
 
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ok)->vbox), label_ok, TRUE, TRUE,0);
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ok)->vbox), label2_ok, TRUE, TRUE,0);
 
 //Bot�n
 boton_ok= gtk_button_new_with_label(" Cerrar ");
 gtk_signal_connect(GTK_OBJECT(boton_ok), "clicked",
				GTK_SIGNAL_FUNC(cierra_aviso), vent_ok);
 gtk_box_pack_start (GTK_BOX(GTK_DIALOG(vent_ok)->action_area), boton_ok, FALSE, FALSE,0);
 GTK_WIDGET_SET_FLAGS(boton_ok, GTK_CAN_DEFAULT);	// Permitir que sea Marcado por defecto
 gtk_widget_grab_default(boton_ok);			//  Marcarlo por defecto
	
 gtk_grab_add(vent_ok);	// Coge el control ('Atrapa el foco'). Hay que cerrar la ventana antes de poder seguir
		
 gtk_widget_show(label_ok);
 gtk_widget_show(label2_ok);
 gtk_widget_show(boton_ok);
 gtk_widget_show(vent_ok);	
}


//----------------------------------

void carga()
{
  if (n==16 || i==255) {
    n=0;
    crece_barra();		//old printf("*");
  }
  i++;
  n++;
}

//----------------------------------------------------------

void analizar_parametros(char *nomfich, char pcom[6])
{
    puerto=COM2;  /* Por defecto COM2 */

    strcpy(fich,nomfich);
   
    switch (pcom[0]) {
  	  case '-':
                    if (strcmp("-com2",pcom)==0) puerto=COM2;
                    else if (strcmp("-com1",pcom)==0) puerto=COM1;
                    else {
                     label_error=gtk_label_new("Parametro incorrecto"); 
                     mensaje_error(0); 
                    } 
	            break;	    
	   default: mensaje_ayuda();  
	  	    break;
	}
}


//-----------------------------------------------------


int downm(char *nomfich, char pcom[6])
{
  char *caderror;
  S19 fs19;
  int ov;
  GtkWidget *vent_carga;

  analizar_parametros(nomfich,pcom);

  if (abrir_s19(fich,&fs19, 1)==0) {
    caderror=(char *)geterrors19();
    label_error=gtk_label_new(caderror);
    mensaje_error(0);
    return 0;
  }
  
  if (situacion_progs19(fs19,&ov)!=1) {
    mensaje_error(1);
    cerrar_s19(fs19);
    return 0;
  }
  
  if (ov==1) {
    mensaje_error(2);
    cerrar_s19(fs19);
    return 0;
  }
  
  if (abrir_puerto_serie(puerto)==0) {
    mensaje_error(3);
    	// mensaje getserial
    printf ("\n%s\n",getserial_error()); 
    label_error=gtk_label_new(getserial_error());
    mensaje_error(0);
    return 0;
  }
  set_break_timeout(100000);
  
  // Barra de progreso de carga del .s19
  vent_carga=crea_vent_carga(nomfich, pcom); 

  if (cargars19_ramint(fs19,carga)==0) {
    cierra_load(NULL, vent_carga);
    label_error=gtk_label_new(getloaderror());  
    mensaje_error(0);
  }
  else {
   mensaje_ok(fs19);
  }

  cerrar_s19(fs19);
  cerrar_puerto_serie();
  return 1;
}

//----------------------------------------------
