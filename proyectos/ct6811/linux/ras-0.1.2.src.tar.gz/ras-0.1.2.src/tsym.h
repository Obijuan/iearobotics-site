/*
 * tsym.h			2001/03/04
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * Symbol table definitions
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _tsym_h
#define _tsym_h 1

#define SYM_UNK 0		/* Desconocido */
#define SYM_SYM 1		/* S�mbolo definido en EQU, constante */
#define SYM_ETQ 2		/* Etiqueta */
#define SYM_VAR 3		/* Variable */

#define SYM_NUL (struct symrec *)0

struct symrec {
  char *name;			/* Nombre del s�mbolo */
  char *fsrc;			/* Nombre del fichero fuente */
  int  line;			/* L�nea del s�mbolo en el fuente */
  int  type;			/* NUL, EQU, ETQ, VAR */
  int  addr;			/* Direcci�n del s�mbolo */
  int  value;			/* Valor del s�mbolo */
  //  int  is16;		/* Si la variable es de 16 bits */
  struct symrec *next;
};

typedef struct symrec symrec;

extern symrec *sym_table;

symrec *putsym(char *sname, int stype, char *sfsrc, int sline);
symrec *modsym(symrec *s, char *sfsrc, int sline);
symrec *getsym(char *sname);

int show_sym_table();

#endif
