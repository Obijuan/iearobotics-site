/*
 * tcod.h			2001/01/30
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * (Intermediate) code definitions
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _tcod_h
#define _tcod_h 1

#include "tsym.h"
#include "tins.h"

#define COD_VAL    0
#define COD_SYM    1
#define COD_ETQ    2
#define COD_INS    3
#define COD_ORG    4
#define COD_VAR8   5
#define COD_VAR16  6
#define COD_RMB    7

#define COD_NUL  (struct codrec *)0

struct codrec {
  int type;			/* VAL, ETQ, SYM, INS, VAR */
  int line;			/* N�mero de l�nea en el fuente */
  union {
    unsigned int  code;		/* C�digo de la instrucci�n, operando */
    struct symrec *sptr;	/* S�mbolo en la tabla de s�mbolos */
    struct insrec *iptr;	/* S�mbolo en la tabla de instrucciones */
  } value;
  struct codrec *next;		/* Siguiente c�digo */
};

typedef struct codrec codrec;

/* extern codrec *cod_table; */

codrec *newcod_v(int ctype, int cline, int ccode, codrec *cnext);
codrec *newcod_s(int ctype, int cline, symrec *sptr, codrec *cnext);
codrec *newcod_i(int ctype, int cline, insrec *iptr, codrec *cnext);

codrec *codcat(codrec *c1, codrec *c2);

int show_cod_table(codrec *cptr);
int show_codrec   (codrec *cptr);

#endif
