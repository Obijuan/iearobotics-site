* -----------------------------------------------------------------------
* pall2.asm
*
* Prueba todas las instrucciones de ras.
* No cargar en el micro!!!
* -----------------------------------------------------------------------


PORTA	EQU $0			; Puerto A
PORTD	EQU $08			; Direccion del puerto D


	ORG $0000		; Programa en RAM interna

	SUBB #$30
	SUBB $20
	SUBB $1000
	SUBB $10,X
	SUBB $10,Y

	SUBD #$30
	SUBD $20
	SUBD $1000
	SUBD $10,X
	SUBD $10,Y

	SWI
	TAB
	TAP
	TBA
*	TEST
	TPA

	TST $30
	TST $02,X
	TST $01,Y

	TSTA
	TSTB
	TSX
	TSY
	TXS
	TYS
	WAI
	XGDX
	XGDY

	END
