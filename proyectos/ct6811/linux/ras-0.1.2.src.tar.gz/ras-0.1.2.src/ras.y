/*
 * ras.y			2001/04/15
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * Parser, main function and general code
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* ---------------------------------------------------------------------
 * Declaraciones
 */

%{
#include "tsym.h"
#include "tins.h"
#include "tcod.h"
%}

%union {
  int    val;
  symrec *sptr;
  insrec *iptr;
  codrec *cptr;
}

/* ---------------------------------------------------------------------
 * Tokens
 */

%start prog

%token ORG EQU FCB FDB FCC RMB ZMB STR END
%token ERR INM COLON COMMA RX RY FL

%token <val>  NUM
%token <sptr> ETQ SIM
%token <iptr> INS

%type  <cptr> lines line directv memres memzero memdir oplist strdir strlist
%type  <cptr> instr etq etq1 code ins op num sim

%%

/* ---------------------------------------------------------------------
 * Estructura
 */

prog	: lines {
	    if (show_tsym)  show_sym_table();
	    if (numerr == 0) {
	      if ($1->type != COD_ORG)
		$1 = newcod_v(COD_ORG, 0, 0, $1);
	      if (show_debug) show_cod_table($1);
	      pass2($1);
	      if (numerr == 0) {
		if (show_verb)
		  fprintf(stderr, "%s: No se han detectado errores\n", fname);
		gencode(fpout, $1);
	      }
	    }
	    else {
	      if (show_verb)
		fprintf(stderr, "%s: %d error(es) detectado(s)\n",
			fname, numerr);
	    }
	  }

lines	: line 	     { $$ = $1; }
	| lines line { $$ = codcat($1, $2); }

line	: instr FL   { $$ = $1; }
	| directv FL { $$ = $1; }
	| FL	     { $$ = COD_NUL; }

/* ---------------------------------------------------------------------
 * Directivas
 */

directv	: END {
	    $$ = COD_NUL;
	  }
	| ETQ EQU NUM {
	    $1->type = SYM_SYM;
	    $1->addr = $3;
	    $$ = COD_NUL;
	  }
	| ORG NUM {
	    posic = $2;
	    $$ = newcod_v(COD_ORG, lineno, $2, COD_NUL);
	  }
	| memres op {
	    // $1->value.sptr->value = $2->value.code;
	    $$ = $1;
	    posic += $2->value.code - 1;
	    $$->next = newcod_v(COD_ORG, lineno, posic, COD_NUL);
	  }
	| memzero op {
	    codrec *cptr;
	    int    i;
	    $$ = cptr = $1;
	    // printf("<ZMB %d>\n", $2->value.code);
	    for (i = 0; i < $2->value.code; i++) {
	      cptr->next = newcod_v(COD_VAL, lineno, 0, COD_NUL);
	      cptr = cptr->next;
	    }
	  }
	| memdir oplist {
	    $$ = $1;
	    $1->next = $2;
	  }
	| strdir strlist {
	    $$ = $1;
	    $1->next = $2;
	  }
/*
	| ETQ FCB NUM {
	    $$ = newcod_s(COD_VAR, lineno, $1, COD_NUL);
	    $1->type  = SYM_VAR;
	    $1->addr  = posic++;
	    $1->value = $3;
	    $1->is16  = 0;
	}
	| ETQ FDB NUM {
	    $$ = newcod_s(COD_VAR, lineno, $1, COD_NUL);
	    $1->type  = SYM_VAR;
	    $1->addr  = posic++;
	    $1->value = $3;
	    $1->is16  = 1;
	}
*/

memres	: ETQ RMB {
	    $$ = newcod_s(COD_RMB, lineno, $1, COD_NUL);
	    $1->type = SYM_VAR;
	    $1->addr = posic;
	  }
	| RMB {
	    $$ = newcod_s(COD_RMB, lineno, SYM_NUL, COD_NUL);
	  }

memzero	: ETQ ZMB {
	    $$ = newcod_s(COD_VAR8, lineno, $1, COD_NUL);
	    $1->type = SYM_VAR;
	    $1->addr = posic;
	  }
	| ZMB {
	    $$ = newcod_s(COD_VAR8, lineno, SYM_NUL, COD_NUL);
	  }

memdir	: ETQ FCB {
	    $$ = newcod_s(COD_VAR8, lineno, $1, COD_NUL);
	    $1->type  = SYM_VAR;
	    $1->addr  = posic;
	    // $1->is16  = 0;
	  }
	| FCB {
	    $$ = newcod_s(COD_VAR8, lineno, SYM_NUL, COD_NUL);
	    /*
	    $1->type  = SYM_VAR;
	    $1->addr  = posic;
	    $1->is16  = 0;
	    */
	  }
	| ETQ FDB {
	    $$ = newcod_s(COD_VAR16, lineno, $1, COD_NUL);
	    $1->type  = SYM_VAR;
	    $1->addr  = posic;
	    // $1->is16  = 1;
	  }
	| FDB {
	    $$ = newcod_s(COD_VAR16, lineno, SYM_NUL, COD_NUL);
	  }

oplist	: op {
	    $$ = $1;
	  }
	| oplist COMMA op {
	    $$ = codcat($1, $3);
	  }

strdir	: ETQ FCC {
	    $$ = newcod_s(COD_VAR8, lineno, $1, COD_NUL);
	    $1->type  = SYM_VAR;
	    $1->addr  = posic;
	  }
	| FCC {
	    $$ = newcod_s(COD_VAR8, lineno, SYM_NUL, COD_NUL);
	  }

strlist	: STR {
	    char   *ptr;
	    codrec *cptr;
	    $$ = COD_NUL;
	    if (strlen(yytext) > 2) {
	      $$ = newcod_v(COD_VAL, lineno, (int)(*(yytext + 1)), COD_NUL);
	      cptr = $$;
	      // printf("<%c %02X>", *(yytext + 1), *(yytext + 1));
	      for (ptr = yytext + 2; *ptr != *yytext; ptr++) {
		cptr->next = newcod_v(COD_VAL, lineno, (int)*ptr, COD_NUL);
		cptr = cptr->next;
		// printf("<%c %02X>", *ptr, *ptr);
	      }
	      // printf("\n");
	    }
	  }
	| strlist STR {
	    char   *ptr;
	    codrec *cptr;
	    $$ = $1;
	    if (strlen(yytext) > 2) {
	      for (cptr = $1; cptr->next != COD_NUL; cptr = cptr->next);
	      cptr->next = newcod_v(COD_VAL, lineno, '"', COD_NUL);
	      cptr = cptr->next;
	      // printf("<%c %02X>", '"', '"');
	      for (ptr = yytext + 1; *ptr != *yytext; ptr++) {
		cptr->next = newcod_v(COD_VAL, lineno, (int)*ptr, COD_NUL);
		cptr = cptr->next;
		// printf("<%c %02X>", *ptr, *ptr);
	      }
	      // printf("\n");
	    }
	  }

/* ---------------------------------------------------------------------
 * Instrucciones
 */

instr	: code        { $$ = $1; }
	| etq code    { $$ = $1; $1->next = $2; }
	| etq FL code { $$ = $1; $1->next = $3; }

etq	: etq1	      { $$ = $1; }
	| etq1 COLON  { $$ = $1; }

etq1	: ETQ {
	    $$ = newcod_s(COD_ETQ, lineno, $1, COD_NUL);
	    $1->type = SYM_ETQ;
	    $1->addr = posic;
	  }

code	: ins {
	    if ($1->value.iptr->type != INS_INH)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    $$ = $1;
	  }
	| ins op {
	    $1->value.iptr = getinstype($1->value.iptr,
					INS_DIR | INS_REL | INS_EXT);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $$ = $1;
	  }
	| ins op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_DIR_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $3;
	    $$ = $1;
	  }
	| ins op op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_BR_DIR_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $3;
	    $3->next = $4;
	    $$ = $1;
	  }
	| ins op RX {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDX);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "direccionamiento incorrecto");
	    $1->next = $2;
	    $$ = $1;
	  }
	| ins RX {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDX);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "direccionamiento incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, COD_NUL);
	    $$ = $1;
	  }
	| ins op RY {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDY);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "direccionamiento incorrecto");
	    $1->next = $2;
	    $$ = $1;
	  }
	| ins RY {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDY);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "direccionamiento incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, COD_NUL);
	    $$ = $1;
	  }
	| ins op RX op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDX_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $4;
	    $$ = $1;
	  }
	| ins RX op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDX_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, $3);
	    $$ = $1;
	  }
	| ins op RY op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDY_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $4;
	    $$ = $1;
	  }
	| ins RY op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INDY_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno-1, "n�mero de operandos incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, $3);
	    $$ = $1;
	  }
	| ins op RX op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_BR_INDX_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $4;
	    $4->next = $5;
	    $$ = $1;
	  }
	| ins RX op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_BR_INDX_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "n�mero de operandos incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, $3);
	    $3->next = $4;
	    $$ = $1;
	  }
	| ins op RY op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_BR_INDY_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "n�mero de operandos incorrecto");
	    $1->next = $2;
	    $2->next = $4;
	    $4->next = $5;
	    $$ = $1;
	  }
	| ins RY op op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_BR_INDY_M);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "n�mero de operandos incorrecto");
	    posic++;
	    $1->next = newcod_v(COD_VAL, lineno, 0, $3);
	    $3->next = $4;
	    $$ = $1;
	  }
	| ins INM op {
	    $1->value.iptr = getinstype($1->value.iptr, INS_INM8 | INS_INM16);
	    if ($1->value.iptr == INS_NUL)
	      show_err(lineno, "direccionamiento incorrecto");
	    $1->next = $3;
	    $$ = $1;
	  }
	| error {
	    if (*yytext != '\n')
	      sprintf(str, "mnem�nico `%s' no reconocido", yytext);
	    else
	      sprintf(str, "error sint�ctico", yytext);
	    show_err(lineno, str);
	    $$ = COD_NUL;
	}

ins	: INS {
	    posic++;
	    $$ = newcod_i(COD_INS, lineno, $1, COD_NUL);
	  }


/* ---------------------------------------------------------------------
 * Operandos
 */

op	: num { $$ = $1; }
	| sim { $$ = $1; }
	| ERR { $$ = COD_NUL; }

num	: NUM {
	    posic++;
	    $$ = newcod_v(COD_VAL, lineno, $1, COD_NUL);
	  }

sim	: SIM {
	    if ($1->type == SYM_UNK) {
	      // sprintf(str, "s�mbolo `%s' no definido (pass1)", yytext);
	      // show_warn(lineno, str);
	    }
	    posic++;
	    $$ = newcod_s(COD_SYM, lineno, $1, COD_NUL);
	  }
	| INS {
	    symrec *s;
	    sprintf(str, "el s�mbolo `%s' tambi�n es un mnem�nico", yytext);
	    show_warn(lineno, str);
	    if ((s = getsym(yytext)) == 0)
	      s = putsym(yytext, SYM_UNK, fname, lineno);
	    posic++;
	    $$ = newcod_s(COD_SYM, lineno, s, COD_NUL);
	}

%%

/* ---------------------------------------------------------------------
 * Variables globales e includes
 */

#include <stdio.h>
#include <getopt.h>
#include "lex.yy.c"

char *get_fnameout(char *fname);

symrec *sym_table = (symrec *)0;	/* Tabla de s�mbolos */
insrec *ins_table = (insrec *)0;	/* Tabla de instrucciones */

int    posic  = 0;			/* Posici�n del c�digo en bytes */
int    numerr = 0;			/* N�mero de errores */

FILE   *fpin, *fpout;			/* Descriptores de ficheros */
// char   *fname;			/* Nombre del fichero de entrada */
char   fname[256];			/* Nombre del fichero de entrada */
char   *fnout = '\0';			/* Nombre del fichero de salida */
char   str[256];			/* String para errores */

int    show_debug = 0;			/* Muestra info de debug -d */
int    show_tsym  = 0;			/* Muestra info de tsym  -s */
int    show_verb  = 0;			/* Muestra info de resultados -v */

/* ---------------------------------------------------------------------
 * Principal
 */

main(int argc, char *argv[]) {
  int c;

  opterr = 0;
  while (1) {
    c = getopt(argc, argv, "hVsdvo:");
    if (c == -1)
      break;
    switch (c) {
    case 'h':
      usage();
      return 1;
      break;
    case 'V':
      version();
      return 1;
      break;
    case 's':
      show_tsym  = 1;
      break;
    case 'd':
      show_debug = 1;
      break;
    case 'v':
      show_verb  = 1;
      break;
    case 'o':
      fnout = optarg;
      break;
    default:
      if (optopt == 'o')
	fprintf(stderr, "%s: requiere un argumento -- %c\n", argv[0], optopt);
      else
	fprintf(stderr, "%s: opci�n no v�lida -- %c\n", argv[0], optopt);
      return 1;
    }
  }

  if ((optind + 1) != argc) {
    fprintf(stderr, "%s: error especificando el fichero de entrada\n",
	    argv[0]);
    // usage();
    return 1;
  }

  // fname = argv[optind];
  strcpy(fname, argv[optind]);
  if (! (fpin = fopen(fname, "r")) ) {
    fprintf(stderr, "%s: no se puede abrir el fichero `%s'\n",
	    argv[0], fname);
    return 1;
  }

  if (fnout == NULL)
    fnout = get_fnameout(fname);
  if (! (fpout = fopen(fnout, "w")) ) {
    fprintf(stderr, "%s: no se puede abrir el fichero `%s'\n",
	    argv[0], fnout);
    return 1;
  }

  // if (show_debug)
  //   printf("in = %s, out = %s\n", fname, fnout);

  init_ins();
  // show_ins_table();

  yyin = fpin;
  yyparse();

  fclose(fpin);
  fclose(fpout);

  return (numerr != 0);
}

/* ---------------------------------------------------------------------
 * Funciones
 */

extern int yyerror(char *s) {
  if (strcmp(s, "syntax error") != 0)
    show_err(lineno, s);
}

int show_err(int line, char *s) {
  show_err_fn(fname, line, s);
}

int show_err_fn(char *filename, int line, char *s) {
  numerr++;
  fprintf(stderr, "%s:%d: %s\n", filename, line, s);
}

int show_warn(int line, char *s) {
  fprintf(stderr, "%s:%d: warning: %s\n", fname, line, s);
}

int usage() {
  fprintf(stderr, "Uso: ras [opciones] <fichero>

  -h		muestra esta ayuda y finaliza
  -V		muestra la versi�n y finaliza
  -v		muestra informaci�n variada del ensamblaje (verbose)
  -s		muestra la tabla de s�mbolos
  -d		muestra informaci�n de debug (c�digo intermedio)
  -o <fichero>	deja la salida en <fichero>

Comunicar 'bugs' a <jdlope@eui.upm.es>\n");
}

int version() {
  fprintf(stderr, "ras (Mobile Robot Assembler) 0.1.2

Copyright (C) 2001 Javier de Lope Asia�n
Esto es software libre; vea el c�digo fuente para las condiciones de copia.
No hay NINGUNA garant�a; ni siquiera de COMERCIABILIDAD o IDONEIDAD PARA UN
FIN DETERMINADO.\n\n");
}

char *get_fnameout(char *fname) {
  char *fnout = (char *) malloc(strlen(fname)+4);
  char *ptr;
  strcpy(fnout, fname);
  if ((ptr = (char *)strrchr(fnout, '.')) != NULL)
    *ptr = '\0';
  return (char *)strcat(fnout, ".s19");
}

int pass2(codrec *cptr) {
  codrec *ptr;
  int    incpos = 0;

  for (ptr = cptr; ptr != COD_NUL; ptr = ptr->next) {
    switch (ptr->type) {
    case COD_ORG:
      incpos = 0;
      break;
    case COD_ETQ:
      ptr->value.sptr->addr += incpos;
      break;
    case COD_VAR8:
      if (ptr->value.sptr != SYM_NUL)
	ptr->value.sptr->addr += incpos;
      break;
    case COD_VAR16:
      if (ptr->value.sptr != SYM_NUL) {
	ptr->value.sptr->addr += incpos;
	incpos++;
      }
      break;
    /*
    case COD_VAR:
      if (ptr->value.sptr != SYM_NUL) {
	ptr->value.sptr->addr += incpos;
	if (ptr->value.sptr->is16)
	  incpos++;
      }
      break;
    */
    case COD_INS:
      if (is16bits(ptr->value.iptr->code))
	incpos++;
      switch (ptr->value.iptr->type) {
      case INS_INH:
	break;
      case INS_DIR:
	if (checkop16(ptr->next)) {
	  // Todo INS_DIR tiene versi�n INS_EXT y tiene que ser la siguiente
	  // y el c�digo de operaci�n tiene el mismo tama�o
	  ptr->value.iptr = ptr->value.iptr->list;
	  incpos++;
	}
	break;
      case INS_REL:
	// El salto se comprueba en la generaci�n de c�digo,
	// el valor (dir absoluta destino) aqu� puede ser de m�s de 8 bits
	checksym(ptr->next);
	break;
      case INS_EXT:
	// Esto es un checkop16
	// checksym(ptr->next);
	// Puede quedarse como checksym
	checkop16(ptr->next);
	incpos++;
	break;
      case INS_INDX:
      case INS_INDY:
	checkop8(ptr->next);
	break;
      case INS_DIR_M:
      case INS_INDX_M:
      case INS_INDY_M:
	checkop8(ptr->next);
	checkop8(ptr->next->next);
	break;
      case INS_BR_DIR_M:
      case INS_BR_INDX_M:
      case INS_BR_INDY_M:
	checkop8(ptr->next);
	checkop8(ptr->next->next);
	// El salto se comprueba en la generaci�n de c�digo,
	// el valor (dir absoluta destino) aqu� puede ser de m�s de 8 bits
	// checkop8(ptr->next->next->next); // Esto es un bug!
	checksym(ptr->next->next->next);
	break;
      case INS_INM8:
	checkop8(ptr->next);
	break;
      case INS_INM16:
	// checksym(ptr->next);
	// Puede quedarse como checksym
	checkop16(ptr->next);
	incpos++;
	break;
      }
      break;
    default:
      break;
    }
  }
}

int is16bits(unsigned int x) {
  return x != (x & 0xFF);
}

int checkop8(codrec *ptr) {
  int ok = 1;
  if (ptr->type == COD_VAL) {
    if (is16bits(ptr->value.code)) {
      sprintf(str, "se esperaba un valor de 8 bits ($%X)",
	      ptr->value.code);
      show_err(ptr->line, str);
      ok = 0;
    }
  }
  else {
    ok = checksym(ptr);
    if (is16bits(ptr->value.sptr->addr)) {
      sprintf(str, "se esperaba un valor de 8 bits (%s)",
	      ptr->value.sptr->name);
      show_err(ptr->line, str);
      ok = 0;
    }
  }
  return ok;
}

int checkop16(codrec *ptr) {
  if (ptr->type == COD_VAL)
    return is16bits(ptr->value.code);
  else
    return checksym(ptr) && is16bits(ptr->value.sptr->addr);
}

int checksym(codrec *ptr) {
  if ( (ptr->type == COD_SYM) && (ptr->value.sptr->type == SYM_UNK) ) {
    sprintf(str, "s�mbolo `%s' no definido (pass2)",
	    ptr->value.sptr->name);
    show_err_fn(ptr->value.sptr->fsrc, ptr->line, str);
    return 0;
  }
  return 1;
}

int gencode(FILE *fp, codrec *cptr) {
  codrec   *ptr;
  unsigned int length   = 0;		/* Longitud de la l�nea actual */
  unsigned int posic    = 0;		/* Posici�n del c�digo en volcado */
  unsigned int orghole  = 0;		/* Huecos provocados por ORG */
  unsigned int dirini   = 0;		/* Direcci�n de inicio */
  int      op16   = 0;			/* El siguiente es un op16 */
  int      var16  = 0;			/* Se est� en variables de 16 */
  int      rmb    = 0;			/* Se est� en una RMB */
  int      branch = 0;			/* Bifurcaci�n pendiente */
  char     linea[128];			/* L�nea actual */
  char     overl[128];			/* Tratamiento de desbordamiento lin */
  int      inc;				/* Tama�o del c�digo generado */

  *linea = '\0';
  for (ptr = cptr; ptr != COD_NUL; ptr = ptr->next) {
    switch (ptr->type) {
    case COD_VAL:
      if (branch != 1)
	inc = gencode_value(ptr->value.code,
			    op16 | var16, linea);
      else
	inc = gencode_value(calc_salto(ptr->line, ptr->value.code, posic),
			    op16 | var16, linea);
      length += inc;
      posic  += inc;
      if (branch > 0) branch--;
      op16 = 0;
      break;
    case COD_SYM:
      if (branch != 1)
	inc = gencode_value(ptr->value.sptr->addr,
			    op16 | var16, linea);
      else
	inc = gencode_value(calc_salto(ptr->line,ptr->value.sptr->addr,posic),
			    op16 | var16, linea);
      length += inc;
      posic  += inc;
      if (branch > 0) branch--;
      op16 = 0;
      break;
    case COD_INS:
      // op16 = (ptr->value.iptr->type == INS_EXT)   ||
      //        (ptr->value.iptr->type == INS_INM16);
      if (op16 = ( (ptr->value.iptr->type == INS_EXT)   ||
		   (ptr->value.iptr->type == INS_INM16) ))
	;
      else if (branch = (ptr->value.iptr->type == INS_REL))
	;
	// branch = 1;
      else if (ptr->value.iptr->type &
	       (INS_BR_DIR_M | INS_BR_INDX_M | INS_BR_INDY_M) )
	branch = 3;
      /*
      else
	branch = 0;
      */
      inc = gencode_value(ptr->value.iptr->code, 0, linea);
      length += inc;
      posic  += inc;
      var16   = 0;
      break;
    case COD_ORG:
      if ( (ptr->next != COD_NUL) &&
	   ((ptr->next->type == COD_RMB) || (ptr->next->type == COD_ORG)) )
	break;
      // if (*linea != '\0')
      if (strlen(linea) != 0)
	gencode_line1(fp, length, linea);
      if (posic == 0)
	dirini = ptr->value.code;
      length   = gencode_value(ptr->value.code + rmb, 1, linea);
      orghole += ptr->value.code - posic + rmb;
      posic    = ptr->value.code + rmb;
      var16    = 0;
      rmb      = 0;
      break;
    case COD_VAR8:
      var16 = 0;
      break;
    case COD_VAR16:
      var16 = 1;
      break;
    case COD_RMB:
      // ptr->value.sptr->addr++;
      if (strlen(linea) != 0)
	// posic += ptr->value.sptr->value; // -1 ???
	rmb = 1;
      break;
    /*
    case COD_VAR:
      if (ptr->value.sptr != SYM_NUL)
	var16 = ptr->value.sptr->is16;
      inc = gencode_value(ptr->value.sptr->value,
			  ptr->value.sptr->is16, linea);
      length += inc;
      posic  += inc;
      break;      
    */
    }
    // Constante 34 de longitud de linea de datos (realmente 35 bytes)
    if (length == 34) {
      gencode_line1(fp, length, linea);
      length  = gencode_value(posic, 1, linea);
    }
    else if (length > 34) {
      strcpy(overl, linea+2*34);
      *(linea+2*34) = '\0';
      gencode_line1(fp, 34, linea);
      length  = gencode_value(posic - strlen(overl) / 2, 1, linea);
      strcat(linea, overl);
      length += strlen(overl) / 2;
    }
  }
  // printf("%d - <%s>\n", strlen(linea), linea);
  if (strlen(linea) > 4)  // S�lo tiene el c�digo de un ORG
    gencode_line1(fp, length, linea);
  gencode_line9(fp);
  if (show_verb) {
    fprintf(stderr, "%s: %d bytes generados\n", fname, posic - orghole);
    fprintf(stderr, "%s: direcci�n de inicio $%04X", fname, dirini);
    if (dirini == 0x0000)
      fprintf(stderr, " (RAM interna)");
    else if (dirini ==  0xB600)
      fprintf(stderr, " (EEPROM interna)");
    else if (dirini == 0x8000)
      fprintf(stderr, " (RAM externa)");
    fprintf(stderr, "\n");
    /*
    if (orghole != 0)
      fprintf(stderr, "%s: usando directivas ORG\n", fname);
    */
  }
}

int gencode_value(unsigned int value, int is16, char *line) {
  char codigo[5];
  int  length;

  if (is16 || is16bits(value)) {
    sprintf(codigo, "%04X", value);
    length = 2;
  }
  else {
    sprintf(codigo, "%02X", value);
    length = 1;
  }
  strcat(line, codigo);
  return length;
}

int gencode_line1(FILE *fp, unsigned int length, char *line) {
  fprintf(fp, "S1%02X%s%02X\n", length + 1, line, calc_checksum(length, line));
  *line = '\0';
}

int gencode_line9(FILE *fp) {
  fprintf(fp, "S9030000FC\n");
}

int calc_salto(int line, unsigned int value, unsigned int posic) {
  int s = value - posic - 1;
  if ((s < -128) || (s > 127)) {
    show_err(line, "ramificaci�n fuera de rango");
    return 0xFE;  // Parece que siempre devuelve este valor
  }
  else {
    if (s < 0)
      s = (~(-s) + 1) & 0xFF;
    return (s &= 0xFF);
  }
}

int char2hex(char c) {
  int x = c - '0';
  return (x < 10) ? x : x - 7;
}

int calc_checksum(int length, char *line) {
  char *ptr      = line + 2;
  int   checksum = length + 1;
  int   i;

  for (i = 0; i < length; i++) {
    ptr = line + 2 * i;
    checksum += (char2hex(*ptr) << 4) | char2hex(*(ptr+1));
  }
  return (~ (checksum & 0xFF)) & 0xFF;
}
