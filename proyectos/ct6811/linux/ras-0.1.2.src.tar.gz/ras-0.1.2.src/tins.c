/*
 * tins.c			2001/02/05
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * Instruction table code
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "tins.h"

insrec *init_ins() {
  insrec *ptr;
  
        putins("ABA",   INS_INH,       0x1B);
        putins("ABX",   INS_INH,       0x3A);
        putins("ABY",   INS_INH,       0x183A);
  ptr = putins("ADCA",  INS_INM8,      0x89);
  ptr = addins(ptr,     INS_DIR,       0x99);
  ptr = addins(ptr,     INS_EXT,       0xB9);
  ptr = addins(ptr,     INS_INDX,      0xA9);
  ptr = addins(ptr,     INS_INDY,      0x18A9);
  ptr = putins("ADCB",  INS_INM8,      0xC9);
  ptr = addins(ptr,     INS_DIR,       0xD9);
  ptr = addins(ptr,     INS_EXT,       0xF9);
  ptr = addins(ptr,     INS_INDX,      0xE9);
  ptr = addins(ptr,     INS_INDY,      0x18E9);
  ptr = putins("ADDA",  INS_INM8,      0x8B);
  ptr = addins(ptr,     INS_DIR,       0x9B);
  ptr = addins(ptr,     INS_EXT,       0xBB);
  ptr = addins(ptr,     INS_INDX,      0xAB);
  ptr = addins(ptr,     INS_INDY,      0x18AB);
  ptr = putins("ADDB",  INS_INM8,      0xCB);
  ptr = addins(ptr,     INS_DIR,       0xDB);
  ptr = addins(ptr,     INS_EXT,       0xFB);
  ptr = addins(ptr,     INS_INDX,      0xEB);
  ptr = addins(ptr,     INS_INDY,      0x18EB);
  ptr = putins("ADDD",  INS_INM16,     0xC3);
  ptr = addins(ptr,     INS_DIR,       0xD3);
  ptr = addins(ptr,     INS_EXT,       0xF3);
  ptr = addins(ptr,     INS_INDX,      0xE3);
  ptr = addins(ptr,     INS_INDY,      0x18E3);
  ptr = putins("ANDA",  INS_INM8,      0x84);
  ptr = addins(ptr,     INS_DIR,       0x94);
  ptr = addins(ptr,     INS_EXT,       0xB4);
  ptr = addins(ptr,     INS_INDX,      0xA4);
  ptr = addins(ptr,     INS_INDY,      0x18A4);
  ptr = putins("ANDB",  INS_INM8,      0xC4);
  ptr = addins(ptr,     INS_DIR,       0xD4);
  ptr = addins(ptr,     INS_EXT,       0xF4);
  ptr = addins(ptr,     INS_INDX,      0xE4);
  ptr = addins(ptr,     INS_INDY,      0x18E4);
  ptr = putins("ASL",   INS_EXT,       0x78);
  ptr = addins(ptr,     INS_INDX,      0x68);
  ptr = addins(ptr,     INS_INDY,      0x1868);
        putins("ASLA",  INS_INH,       0x48);
        putins("ASLB",  INS_INH,       0x58);
        putins("ASLD",  INS_INH,       0x05);
  ptr = putins("ASR",   INS_EXT,       0x77);
  ptr = addins(ptr,     INS_INDX,      0x67);
  ptr = addins(ptr,     INS_INDY,      0x1867);
        putins("ASRA",  INS_INH,       0x47);
        putins("ASRB",  INS_INH,       0x57);

	putins("BCC",   INS_REL,       0x24);
  ptr = putins("BCLR",  INS_DIR_M,     0x15);
  ptr = addins(ptr,     INS_INDX_M,    0x1D);
  ptr = addins(ptr,     INS_INDY_M,    0x181D);
	putins("BCS",   INS_REL,       0x25);
	putins("BEQ",   INS_REL,       0x27);
	putins("BGE",   INS_REL,       0x2C);
	putins("BGT",   INS_REL,       0x2E);
	putins("BHI",   INS_REL,       0x22);
	putins("BHS",   INS_REL,       0x24);
  ptr = putins("BITA",  INS_INM8,      0x85);
  ptr = addins(ptr,     INS_DIR,       0x95);
  ptr = addins(ptr,     INS_EXT,       0xB5);
  ptr = addins(ptr,     INS_INDX,      0xA5);
  ptr = addins(ptr,     INS_INDY,      0x18A5);
  ptr = putins("BITB",  INS_INM8,      0xC5);
  ptr = addins(ptr,     INS_DIR,       0xD5);
  ptr = addins(ptr,     INS_EXT,       0xF5);
  ptr = addins(ptr,     INS_INDX,      0xE5);
  ptr = addins(ptr,     INS_INDY,      0x18E5);
	putins("BLE",   INS_REL,       0x2F);
	putins("BLO",   INS_REL,       0x25);
	putins("BLS",   INS_REL,       0x23);
	putins("BLT",   INS_REL,       0x2D);
	putins("BMI",   INS_REL,       0x2B);
	putins("BNE",   INS_REL,       0x26);
	putins("BPL",   INS_REL,       0x2A);
	putins("BRA",   INS_REL,       0x20);
  ptr = putins("BRCLR", INS_BR_DIR_M,  0x13);
  ptr = addins(ptr,     INS_BR_INDX_M, 0x1F);
  ptr = addins(ptr,     INS_BR_INDY_M, 0x181F);
	putins("BRN",   INS_REL,       0x21);
  ptr = putins("BRSET", INS_BR_DIR_M,  0x12);
  ptr = addins(ptr,     INS_BR_INDX_M, 0x1E);
  ptr = addins(ptr,     INS_BR_INDY_M, 0x181E);
  ptr = putins("BSET",  INS_DIR_M,     0x14);
  ptr = addins(ptr,     INS_INDX_M,    0x1C);
  ptr = addins(ptr,     INS_INDY_M,    0x181C);
	putins("BSR",   INS_REL,       0x8D);
	putins("BVC",   INS_REL,       0x28);
	putins("BVS",   INS_REL,       0x29);

	putins("CBA",   INS_INH,       0x11);
	putins("CLC",   INS_INH,       0x0C);
	putins("CLI",   INS_INH,       0x0E);
  ptr = putins("CLR",   INS_EXT,       0x7F);
  ptr = addins(ptr,     INS_INDX,      0x6F);
  ptr = addins(ptr,     INS_INDY,      0x186F);
	putins("CLRA",  INS_INH,       0x4F);
	putins("CLRB",  INS_INH,       0x5F);
	putins("CLV",   INS_INH,       0x0A);
  ptr = putins("CMPA",  INS_INM8,      0x81);
  ptr = addins(ptr,     INS_DIR,       0x91);
  ptr = addins(ptr,     INS_EXT,       0xB1);
  ptr = addins(ptr,     INS_INDX,      0xA1);
  ptr = addins(ptr,     INS_INDY,      0x18A1);
  ptr = putins("CMPB",  INS_INM8,      0xC1);
  ptr = addins(ptr,     INS_DIR,       0xD1);
  ptr = addins(ptr,     INS_EXT,       0xF1);
  ptr = addins(ptr,     INS_INDX,      0xE1);
  ptr = addins(ptr,     INS_INDY,      0x18E1);
  ptr = putins("COM",   INS_EXT,       0x73);
  ptr = addins(ptr,     INS_INDX,      0x63);
  ptr = addins(ptr,     INS_INDY,      0x1863);
	putins("COMA",  INS_INH,       0x43);
	putins("COMB",  INS_INH,       0x53);
  ptr = putins("CPD",   INS_INM16,     0x1A83);
  ptr = addins(ptr,     INS_DIR,       0x1A93);
  ptr = addins(ptr,     INS_EXT,       0x1AB3);
  ptr = addins(ptr,     INS_INDX,      0x1AA3);
  ptr = addins(ptr,     INS_INDY,      0xCDA3);
  ptr = putins("CPX",   INS_INM16,     0x8C);
  ptr = addins(ptr,     INS_DIR,       0x9C);
  ptr = addins(ptr,     INS_EXT,       0xBC);
  ptr = addins(ptr,     INS_INDX,      0xAC);
  ptr = addins(ptr,     INS_INDY,      0xCDAC);   // *** Revisar Ok!
  ptr = putins("CPY",   INS_INM16,     0x188C);
  ptr = addins(ptr,     INS_DIR,       0x189C);
  ptr = addins(ptr,     INS_EXT,       0x18BC);
  ptr = addins(ptr,     INS_INDX,      0x1AAC);
  ptr = addins(ptr,     INS_INDY,      0x18AC);   // *** Revisar Ok!

	putins("DAA",   INS_INH,       0x19);
  ptr = putins("DEC",   INS_EXT,       0x7A);
  ptr = addins(ptr,     INS_INDX,      0x6A);
  ptr = addins(ptr,     INS_INDY,      0x186A);
	putins("DECA",  INS_INH,       0x4A);
	putins("DECB",  INS_INH,       0x5A);
	putins("DES",   INS_INH,       0x34);
	putins("DEX",   INS_INH,       0x09);
	putins("DEY",   INS_INH,       0x1809);   // *** Revisar *** Ok!

  ptr = putins("EORA",  INS_INM8,      0x88);
  ptr = addins(ptr,     INS_DIR,       0x98);
  ptr = addins(ptr,     INS_EXT,       0xB8);
  ptr = addins(ptr,     INS_INDX,      0xA8);
  ptr = addins(ptr,     INS_INDY,      0x18A8);
  ptr = putins("EORB",  INS_INM8,      0xC8);
  ptr = addins(ptr,     INS_DIR,       0xD8);
  ptr = addins(ptr,     INS_EXT,       0xF8);
  ptr = addins(ptr,     INS_INDX,      0xE8);
  ptr = addins(ptr,     INS_INDY,      0x18E8);

	putins("FDIV",  INS_INH,       0x03);

	putins("IDIV",  INS_INH,       0x02);
  ptr = putins("INC",   INS_EXT,       0x7C);
  ptr = addins(ptr,     INS_INDX,      0x6C);
  ptr = addins(ptr,     INS_INDY,      0x186C);
	putins("INCA",  INS_INH,       0x4C);
	putins("INCB",  INS_INH,       0x5C);
	putins("INS",   INS_INH,       0x31);
	putins("INX",   INS_INH,       0x08);
	putins("INY",   INS_INH,       0x1808);   // *** Revisar Ok!

  ptr = putins("JMP",   INS_EXT,       0x7E);
  ptr = addins(ptr,     INS_INDX,      0x6E);
  ptr = addins(ptr,     INS_INDY,      0x186E);
  ptr = putins("JSR",   INS_DIR,       0x9D);
  ptr = addins(ptr,     INS_EXT,       0xBD);
  ptr = addins(ptr,     INS_INDX,      0xAD);
  ptr = addins(ptr,     INS_INDY,      0x18AD);

  ptr = putins("LDAA",  INS_INM8,      0x86);
  ptr = addins(ptr,     INS_DIR,       0x96);
  ptr = addins(ptr,     INS_EXT,       0xB6);
  ptr = addins(ptr,     INS_INDX,      0xA6);
  ptr = addins(ptr,     INS_INDY,      0x18A6);
  ptr = putins("LDAB",  INS_INM8,      0xC6);
  ptr = addins(ptr,     INS_DIR,       0xD6);
  ptr = addins(ptr,     INS_EXT,       0xF6);
  ptr = addins(ptr,     INS_INDX,      0xE6);
  ptr = addins(ptr,     INS_INDY,      0x18E6);
  ptr = putins("LDD",   INS_INM16,     0xCC);
  ptr = addins(ptr,     INS_DIR,       0xDC);
  ptr = addins(ptr,     INS_EXT,       0xFC);
  ptr = addins(ptr,     INS_INDX,      0xEC);
  ptr = addins(ptr,     INS_INDY,      0x18EC);
  ptr = putins("LDS",   INS_INM16,     0x8E);
  ptr = addins(ptr,     INS_DIR,       0x9E);
  ptr = addins(ptr,     INS_EXT,       0xBE);
  ptr = addins(ptr,     INS_INDX,      0xAE);
  ptr = addins(ptr,     INS_INDY,      0x18AE);
  ptr = putins("LDX",   INS_INM16,     0xCE);
  ptr = addins(ptr,     INS_DIR,       0xDE);
  ptr = addins(ptr,     INS_EXT,       0xFE);
  ptr = addins(ptr,     INS_INDX,      0xEE);
  ptr = addins(ptr,     INS_INDY,      0xCDEE);
  ptr = putins("LDY",   INS_INM16,     0x18CE);
  ptr = addins(ptr,     INS_DIR,       0x18DE);
  ptr = addins(ptr,     INS_EXT,       0x18FE);
  ptr = addins(ptr,     INS_INDX,      0x1AEE);
  ptr = addins(ptr,     INS_INDY,      0x18EE);
  ptr = putins("LSL",   INS_EXT,       0x78);
  ptr = addins(ptr,     INS_INDX,      0x68);
  ptr = addins(ptr,     INS_INDY,      0x1868);
	putins("LSLA",  INS_INH,       0x48);
	putins("LSLB",  INS_INH,       0x58);
	putins("LSLD",  INS_INH,       0x05);
  ptr = putins("LSR",   INS_EXT,       0x74);
  ptr = addins(ptr,     INS_INDX,      0x64);
  ptr = addins(ptr,     INS_INDY,      0x1864);
	putins("LSRA",  INS_INH,       0x44);
	putins("LSRB",  INS_INH,       0x54);
	putins("LSRD",  INS_INH,       0x04);

	putins("MUL",   INS_INH,       0x3D);

  ptr = putins("NEG",   INS_EXT,       0x70);
  ptr = addins(ptr,     INS_INDX,      0x60);
  ptr = addins(ptr,     INS_INDY,      0x1860);
	putins("NEGA",  INS_INH,       0x40);
	putins("NEGB",  INS_INH,       0x50);
	putins("NOP",   INS_INH,       0x01);

  ptr = putins("ORAA",  INS_INM8,      0x8A);
  ptr = addins(ptr,     INS_DIR,       0x9A);
  ptr = addins(ptr,     INS_EXT,       0xBA);
  ptr = addins(ptr,     INS_INDX,      0xAA);
  ptr = addins(ptr,     INS_INDY,      0x18AA);
  ptr = putins("ORAB",  INS_INM8,      0xCA);
  ptr = addins(ptr,     INS_DIR,       0xDA);
  ptr = addins(ptr,     INS_EXT,       0xFA);
  ptr = addins(ptr,     INS_INDX,      0xEA);
  ptr = addins(ptr,     INS_INDY,      0x18EA);

	putins("PSHA",  INS_INH,       0x36);
	putins("PSHB",  INS_INH,       0x37);
	putins("PSHX",  INS_INH,       0x3C);
	putins("PSHY",  INS_INH,       0x183C);
	putins("PULA",  INS_INH,       0x32);
	putins("PULB",  INS_INH,       0x33);
	putins("PULX",  INS_INH,       0x38);
	putins("PULY",  INS_INH,       0x1838);

  ptr = putins("ROL",   INS_EXT,       0x79);
  ptr = addins(ptr,     INS_INDX,      0x69);
  ptr = addins(ptr,     INS_INDY,      0x1869);
	putins("ROLA",  INS_INH,       0x49);
	putins("ROLB",  INS_INH,       0x59);
  ptr = putins("ROR",   INS_EXT,       0x76);
  ptr = addins(ptr,     INS_INDX,      0x66);
  ptr = addins(ptr,     INS_INDY,      0x1866);
	putins("RORA",  INS_INH,       0x46);
	putins("RORB",  INS_INH,       0x56);
	putins("RTI",   INS_INH,       0x3B);
	putins("RTS",   INS_INH,       0x39);

	putins("SBA",   INS_INH,       0x10);
  ptr = putins("SBCA",  INS_INM8,      0x82);
  ptr = addins(ptr,     INS_DIR,       0x92);
  ptr = addins(ptr,     INS_EXT,       0xB2);
  ptr = addins(ptr,     INS_INDX,      0xA2);
  ptr = addins(ptr,     INS_INDY,      0x18A2);
  ptr = putins("SBCB",  INS_INM8,      0xC2);
  ptr = addins(ptr,     INS_DIR,       0xD2);
  ptr = addins(ptr,     INS_EXT,       0xF2);
  ptr = addins(ptr,     INS_INDX,      0xE2);
  ptr = addins(ptr,     INS_INDY,      0x18E2);
	putins("SEC",   INS_INH,       0x0D);
	putins("SEI",   INS_INH,       0x0F);
	putins("SEV",   INS_INH,       0x0B);
  ptr = putins("STAA",  INS_DIR,       0x97);
  ptr = addins(ptr,     INS_EXT,       0xB7);
  ptr = addins(ptr,     INS_INDX,      0xA7);
  ptr = addins(ptr,     INS_INDY,      0x18A7);
  ptr = putins("STAB",  INS_DIR,       0xD7);
  ptr = addins(ptr,     INS_EXT,       0xF7);
  ptr = addins(ptr,     INS_INDX,      0xE7);
  ptr = addins(ptr,     INS_INDY,      0x18E7);
  ptr = putins("STD",   INS_DIR,       0xDD);
  ptr = addins(ptr,     INS_EXT,       0xFD);
  ptr = addins(ptr,     INS_INDX,      0xED);
  ptr = addins(ptr,     INS_INDY,      0x18ED);
	putins("STOP",  INS_INH,       0xCF);
  ptr = putins("STS",   INS_DIR,       0x9F);
  ptr = addins(ptr,     INS_EXT,       0xBF);
  ptr = addins(ptr,     INS_INDX,      0xAF);
  ptr = addins(ptr,     INS_INDY,      0x18AF);
  ptr = putins("STX",   INS_DIR,       0xDF);
  ptr = addins(ptr,     INS_EXT,       0xFF);
  ptr = addins(ptr,     INS_INDX,      0xEF);
  ptr = addins(ptr,     INS_INDY,      0xCDEF);   // *** Revisar Ok!
  ptr = putins("STY",   INS_DIR,       0x18DF);
  ptr = addins(ptr,     INS_EXT,       0x18FF);
  ptr = addins(ptr,     INS_INDX,      0x1AEF);
  ptr = addins(ptr,     INS_INDY,      0x18EF);   // *** Revisar Ok!
  ptr = putins("SUBA",  INS_INM8,      0x80);
  ptr = addins(ptr,     INS_DIR,       0x90);
  ptr = addins(ptr,     INS_EXT,       0xB0);
  ptr = addins(ptr,     INS_INDX,      0xA0);
  ptr = addins(ptr,     INS_INDY,      0x18A0);
  ptr = putins("SUBB",  INS_INM8,      0xC0);
  ptr = addins(ptr,     INS_DIR,       0xD0);
  ptr = addins(ptr,     INS_EXT,       0xF0);
  ptr = addins(ptr,     INS_INDX,      0xE0);
  ptr = addins(ptr,     INS_INDY,      0x18E0);
  ptr = putins("SUBD",  INS_INM16,     0x83);     // *** Revisar INM8? Ok!
  ptr = addins(ptr,     INS_DIR,       0x93);
  ptr = addins(ptr,     INS_EXT,       0xB3);
  ptr = addins(ptr,     INS_INDX,      0xA3);
  ptr = addins(ptr,     INS_INDY,      0x18A3);
	putins("SWI",   INS_INH,       0x3F);

	putins("TAB",   INS_INH,       0x16);
	putins("TAP",   INS_INH,       0x06);
	putins("TBA",   INS_INH,       0x17);
	putins("TEST",  INS_INH,       0x00);
	putins("TPA",   INS_INH,       0x07);
  ptr = putins("TST",   INS_EXT,       0x7D);
  ptr = addins(ptr,     INS_INDX,      0x6D);
  ptr = addins(ptr,     INS_INDY,      0x186D);
	putins("TSTA",  INS_INH,       0x4D);
	putins("TSTB",  INS_INH,       0x5D);
	putins("TSX",   INS_INH,       0x30);
	putins("TSY",   INS_INH,       0x1830);
	putins("TXS",   INS_INH,       0x35);
	putins("TYS",   INS_INH,       0x1835);

	putins("WAI",   INS_INH,       0x3E);

	putins("XGDX",  INS_INH,       0x8F);
	putins("XGDY",  INS_INH,       0x188F);
}

insrec *putins(char *iname, int itype, int icode) {
  insrec *ptr;
  ptr = (insrec *) malloc(sizeof(insrec));
  ptr->name = (char *) malloc(strlen(iname) + 1);
  strcpy(ptr->name, iname);
  ptr->type = itype;
  ptr->code = icode;
  ptr->list = INS_NUL;
  ptr->next = ins_table;
  ins_table = ptr;
  return ptr;
}

insrec *addins(insrec *iptr, int itype, int icode) {
  iptr->list = (insrec *) malloc(sizeof(insrec));
  iptr->list->name = iptr->name;
  iptr->list->type = itype;
  iptr->list->code = icode;
  iptr->list->list = INS_NUL;
  iptr->list->next = iptr->next;
  return iptr->list;
}

insrec *getins(char *iname) {
  insrec *ptr;
  for (ptr = ins_table; ptr != INS_NUL; ptr = ptr->next)
    if (strcmp(ptr->name, iname) == 0)
      return ptr;
  return 0;
}

insrec *getinstype(insrec *iptr, unsigned int types) {
  while ( (iptr != INS_NUL) && ! (iptr->type & types) )
    iptr = iptr->list;
  return iptr;
}

int show_ins_table() {
  insrec *iptr, *iptr2;
  for (iptr = ins_table; iptr != (insrec *)0; iptr = iptr->next) {
    printf("%s\t%d\t%X\n", iptr->name, iptr->type, iptr->code);
    for (iptr2 = iptr->list; iptr2 != (insrec *)0; iptr2 = iptr2->list) {
      printf("%s\t%d\t%X\n", iptr2->name, iptr2->type, iptr2->code);
    }
  }
}
