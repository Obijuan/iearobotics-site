Vendor:       Javier de Lope
Distribution: GPL
Name:         ras
Version:      0.1.2
Release:      1
Packager:     Javier de Lope <jdlope@eui.upm.es>
URL:          http://www.sia.eui.upm.es/~jdlope/robot/ras.shtml

Copyright:    Copyright (C) 2001 Javier de Lope Asia�n. Licencia GPL.
Group:        Microbotica
Provides:     ras
Summary:      Ensamblador para robots basados en el 68HC11
Source:       ras-0.1.2.tar.gz

%description
Ensamblador para robots m�viles y, en general, cualquier sistema basado
en microcontroladores Motorola 68HC11, multiplataforma, ampliable y libre.

Esto es software libre; vea el c�digo fuente para las condiciones de copia.
No hay NINGUNA garant�a; ni siquiera de COMERCIABILIDAD o IDONEIDAD PARA UN
FIN DETERMINADO.

Autor: Javier de Lope Asia�n.

Agradecimientos: Juan Gonz�lez de Microb�tica por las pruebas, porting a
DOS/Windows y preparaci�n de esta distribuci�n rpm. Cecilio Ruiz por las
pruebas y sugerencias.

%prep

%setup

%build
make

%install
make install

%clean
rm -rf $RPM_BUILD_DIR/src

%files
/usr/local/bin/ras
/usr/local/man/man1/ras.1
