/*
 * tins.h			2001/01/30
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * Instruction table definitions
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _tins_h
#define _tins_h 1

#define INS_INH		1 	/* Inherente */
#define INS_DIR		2	/* Directo 8 bits */
#define INS_REL		4	/* Relativo */
#define INS_EXT		8	/* Extendido 16 bits */
#define INS_INDX	16	/* Indexado X */
#define INS_INDY	32	/* Indexado Y */
#define INS_DIR_M	64	/* Directo con m�scara */
#define INS_INDX_M	128	/* Indexado X con m�scara */
#define INS_INDY_M	256	/* Indexado Y con m�scara */
#define INS_BR_DIR_M	512	/* Bifurcaci�n Directo con m�scara */
#define INS_BR_INDX_M	1024	/* Bifurcaci�n Indexado X con m�scara */
#define INS_BR_INDY_M	2048	/* Bifurcaci�n Indexado X con m�scara */
#define INS_INM8	4096	/* Inmediato 8 bits */
#define INS_INM16	8192	/* Inmediato 16 bits */

#define INS_NUL		(insrec *)0

struct insrec {
  char *name;			/* Nombre de la instrucci�n */
  unsigned int  type;		/* Tipo de operandos y direccionamiento */
  unsigned int  code;		/* C�digo de instrucci�n */
  struct insrec *list;		/* Lista de c�digos para el mismo mnem�nico */
  struct insrec *next;		/* Siguiente mnem�nico */
};

typedef struct insrec insrec;

extern insrec *ins_table;

insrec *init_ins();
insrec *putins(char *iname,  int itype, int icode);
insrec *addins(insrec *iptr, int itype, int icode);
insrec *getins(char *iname);

insrec *getinstype(insrec *iptr, unsigned int types);

int show_ins_table();

#endif  // _tins_h
