/*
 * tsym.c			2001/02/26
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * Symbol table code
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "tsym.h"

symrec *putsym(char *sname, int stype, char *sfsrc, int sline) {
  symrec *ptr;
  ptr = (symrec *) malloc(sizeof(symrec));
  ptr->name = (char *) malloc(strlen(sname) + 1);
  strcpy(ptr->name, sname);
  ptr->fsrc = (char *) malloc(strlen(sfsrc) + 1);
  strcpy(ptr->fsrc, sfsrc);
  ptr->line  = sline;
  ptr->type  = stype;
  ptr->addr  = 0;
  ptr->value = 0;
  // ptr->is16  = 0;
  ptr->next  = (struct symrec *)sym_table;
  sym_table  = ptr;
  return ptr;
}

symrec *modsym(symrec *s, char *sfsrc, int sline) {
  free(s->fsrc);
  s->fsrc = (char *) malloc(strlen(sfsrc) + 1);
  strcpy(s->fsrc, sfsrc);
  s->line = sline;
}

symrec *getsym(char *sname) {
  symrec *ptr;
  for (ptr = sym_table; ptr != (symrec *)0; ptr = (symrec *)ptr->next)
    if (strcmp(ptr->name, sname) == 0)
      return ptr;
  return 0;
}

int show_sym_table() {
  symrec *sptr;
  printf("Id\tType\tAddr\tValue\tLine\tSrc\n");
  for (sptr = sym_table; sptr != (symrec *)0; sptr = sptr->next)
    printf("%s\t%d\t$%02X\t$%04X\t%d\t%s\n",
	   sptr->name, sptr->type, sptr->addr, sptr->value,
	   sptr->line, sptr->fsrc);

}
