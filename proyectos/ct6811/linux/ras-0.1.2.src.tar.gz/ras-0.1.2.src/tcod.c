/*
 * tcod.c			2001/03/04
 *
 * ras - Mobile Robot Assembler (MC68HC11)
 * (Intermediate) code
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include "tcod.h"

codrec *newcod_v(int ctype, int cline, int ccode, codrec *cnext) {
  codrec *ptr;
  ptr = (codrec *) malloc(sizeof(codrec));
  ptr->type = ctype;
  ptr->line = cline;
  ptr->value.code = ccode;
  ptr->next = cnext;
  return ptr;
}

codrec *newcod_s(int ctype, int cline, symrec *sptr, codrec *cnext) {
  codrec *ptr;
  ptr = (codrec *) malloc(sizeof(codrec));
  ptr->type = ctype;
  ptr->line = cline;
  ptr->value.sptr = sptr;
  ptr->next = cnext;
  return ptr;
}

codrec *newcod_i(int ctype, int cline, insrec *iptr, codrec *cnext) {
  codrec *ptr;
  ptr = (codrec *) malloc(sizeof(codrec));
  ptr->type = ctype;
  ptr->line = cline;
  ptr->value.iptr = iptr;
  ptr->next = cnext;
  return ptr;
}

codrec *codcat(codrec *c1, codrec *c2) {
  if (c1 == COD_NUL)
    c1 = c2;
  else {
    if (c2 != COD_NUL) {
      codrec *ptr;
      for (ptr = c1; ptr->next != (codrec *)0; ptr = (codrec *)ptr->next);
      ptr->next = c2;
    }
  }
  return c1;
}

int show_cod_table(codrec *cptr) {
  codrec *ptr;
  printf("Type  Line\tName\tAdd/op\tCode\n");
  for (ptr = cptr; ptr != COD_NUL; ptr = ptr->next)
    show_codrec(ptr);
}

int show_codrec(codrec *cptr) {
  switch (cptr->type) {
  case COD_VAL:
    printf("VAL  %5d\t\t\t%04X\n",
	   cptr->line,
	   cptr->value.code);
    break;
  case COD_SYM:
    printf("SYM  %5d\t%s\t\t%04X\n",
	   cptr->line,
	   cptr->value.sptr->name,
	   cptr->value.sptr->addr);
    break;
  case COD_ETQ:
    printf("ETQ  %5d\t%s\t\t%04X\n",
	   cptr->line,
	   cptr->value.sptr->name,
	   cptr->value.sptr->addr);
    break;
  case COD_INS:
    printf("INS  %5d\t%s\t%d\t%X\n",
	   cptr->line,
	   cptr->value.iptr->name,
	   cptr->value.iptr->type,
	   cptr->value.iptr->code);
    break;
  case COD_ORG:
    printf("ORG  %5d\t\t\t%04X\n",
	   cptr->line,
	   cptr->value.code);
    break;
  case COD_VAR8:
  case COD_VAR16:
    if (cptr->value.sptr == SYM_NUL)
      printf("VAR  %5d\n", cptr->line);
    else
      printf("VAR  %5d\t%s\t\t%04X\t%04X\n",
	     cptr->line,
	     cptr->value.sptr->name,
	     cptr->value.sptr->addr,
	     cptr->value.sptr->value);
    break;
  case COD_RMB:
    if (cptr->value.sptr == SYM_NUL)
      printf("RMB  %5d\n", cptr->line);
    else
      printf("RMB  %5d\t%s\t\t%04X\t%04X\n",
	     cptr->line,
	     cptr->value.sptr->name,
	     cptr->value.sptr->addr,
	     cptr->value.sptr->value);
    break;
  }
}
