

/* do0.c */
int localinit (void);
int do_op (int opcode, int class);
int do_gen (int op, int mode);
int do_indexed (int op);

