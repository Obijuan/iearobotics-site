

/* as.c */
int initialize (void);
int re_init (void);
int make_pass (void);
int parse_line (void);
int process (void);

