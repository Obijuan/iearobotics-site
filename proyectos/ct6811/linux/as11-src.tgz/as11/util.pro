

/* util.c */
int fatal (char *str);
int error (char *str);
int warn (char *str);
int suggest (char *str);
int delim (int c);
char *skip_white (char *ptr);
int eword (int wd);
int emit (int byte);
int f_record (void);
int hexout (int byte);
int print_line (void);
int any (int c, char *str);
char mapdn (int c);
int lobyte (int i);
int hibyte (int i);
int head (char *str1, char *str2);
int alpha (int c);
int alphan (int c);
int white (int c);
char *alloc (int nbytes);

