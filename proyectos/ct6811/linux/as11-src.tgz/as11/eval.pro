

/* eval.c */
int eval (void);
int is_op (int c);
int get_term (void);

