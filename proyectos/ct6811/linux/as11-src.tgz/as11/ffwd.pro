

/* ffwd.c */
int fwdinit (void);
int fwdreinit (void);
int fwdmark (void);
int fwdnext (void);

