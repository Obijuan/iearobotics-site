

/* do4.c */
int localinit (void);
int do_op (int opcode, int class);
int mvi (int op, int to, int from);

