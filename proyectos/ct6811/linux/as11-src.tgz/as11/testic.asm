	ORG	ZERO_PAGE_START
temp1:	RMB	2
temp2:	RMB	2

	ORG	MAIN_START
variable_foo:
	RMB	2
variable_bar:
	RMB	2
subroutine_init:
	LDD	variable_foo
	STD	temp1
	LDD	variable_bar
	STD	temp2
	JSR	delaysome
	RTS
delaysome:
	LDX	#0
delaysomemore:
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	NOP
	INX
	BNE	delaysomemore
	RTS
