

/* do9.c */
int localinit (void);
int do_op (int opcode, int class);
int do_gen (int op, int mode);
int do_indexed (int op);
int abd_index (int pbyte);
int rtype (int r);
int set_mode (void);
int regnum (void);

