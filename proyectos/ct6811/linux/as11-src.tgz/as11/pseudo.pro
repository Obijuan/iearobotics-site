

/* pseudo.c */
int do_pseudo (int op);

