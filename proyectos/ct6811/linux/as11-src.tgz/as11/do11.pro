

/* do11.c */
int localinit (void);
int do_op (int opcode, int class);
int bitop (int op, int mode, int class);
int do_gen (int op, int mode, int pnorm, int px, int py);
int do_indexed (int op);
int epage (int p);

