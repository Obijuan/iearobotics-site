char *skip_white();
