

/* output.c */
int stable (struct nlist *ptr);
int cross (struct nlist *point);

