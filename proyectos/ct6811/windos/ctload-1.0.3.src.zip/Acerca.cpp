/*
 * Acerca.cpp                     2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Acerca.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAcercaDe *AcercaDe;
//---------------------------------------------------------------------------
__fastcall TAcercaDe::TAcercaDe(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TAcercaDe::TimerTimer(TObject *Sender)
{
  if (firstTime) {
    Panel->Visible = true;
    ProgressBar->Position = 0;
    ProgressBar->Visible = true;
    Update();
    Sleep(400);
    for (int i = 0; i < 210; i++) {
      ProgressBar->Position = i;
      Sleep(10);
    }
    Panel->Visible = false;
    ProgressBar->Visible = false;
    Timer->Interval = 600;
    firstTime = false;
  }
  else {
    Image1->Visible = ! Image1->Visible;
    Image2->Visible = ! Image2->Visible;
  }
}
//---------------------------------------------------------------------------
void __fastcall TAcercaDe::FormShow(TObject *Sender)
{
  Image1->Visible = true;
  Image2->Visible = false;
  Timer->Interval = 2500;
  firstTime = true;
  Timer->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TAcercaDe::FormHide(TObject *Sender)
{
  Timer->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TAcercaDe::FormKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
  if (Key == VK_ESCAPE)
    Close();
}
//---------------------------------------------------------------------------


