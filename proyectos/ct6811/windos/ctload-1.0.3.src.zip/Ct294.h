/*
 * Ct294.h			  2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#ifndef Ct294H
#define Ct294H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFormCT294 : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TPanel *LabelPortA;
    TGroupBox *GroupBox2;
    TPanel *LabelPortE;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *Label4;
    TLabel *Label5;
    TLabel *Label6;
    TLabel *Label7;
    TLabel *Label8;
    TPanel *LabelCh1;
    TPanel *LabelCh2;
    TPanel *LabelCh3;
    TPanel *LabelCh4;
    TPanel *LabelCh5;
    TPanel *LabelCh6;
    TPanel *LabelCh7;
    TPanel *LabelCh8;
    TShape *Shape6;
    TShape *BkShape6;
    TShape *SPE1;
    TShape *SPE0;
    TShape *SPE2;
    TShape *SPE3;
    TShape *SPE4;
    TShape *SPE5;
    TShape *SPE6;
    TShape *SPE7;
    TLabel *LabelPE7;
    TLabel *LabelPE6;
    TLabel *LabelPE5;
    TLabel *LabelPE4;
    TLabel *LabelPE3;
    TLabel *LabelPE2;
    TLabel *LabelPE1;
    TLabel *LabelPE0;
    TShape *BkShape1;
    TShape *BkShape2;
    TShape *BkShape3;
    TShape *BkShape4;
    TShape *BkShape5;
    TShape *BkShape7;
    TShape *BkShape8;
    TShape *Shape1;
    TShape *Shape2;
    TShape *Shape3;
    TShape *Shape4;
    TShape *Shape5;
    TShape *Shape7;
    TShape *Shape8;
    TTimer *Timer;
    TLabel *LabelPA7;
    TShape *SPA7;
    TShape *SPA6;
    TLabel *LabelPA6;
    TLabel *LabelPA5;
    TShape *SPA5;
    TShape *SPA4;
    TLabel *LabelPA4;
    TLabel *LabelPA3;
    TShape *SPA3;
    TShape *SPA2;
    TLabel *LabelPA2;
    TLabel *LabelPA1;
    TShape *SPA1;
    TShape *SPA0;
    TLabel *LabelPA0;
    void __fastcall FormShow(TObject *Sender);
    void __fastcall FormHide(TObject *Sender);
    void __fastcall OnTimer(TObject *Sender);
    void __fastcall PA6Click(TObject *Sender);
    void __fastcall PA5Click(TObject *Sender);
    void __fastcall PA4Click(TObject *Sender);
    void __fastcall PA3Click(TObject *Sender);
    void __fastcall SPA6MouseDown(TObject *Sender, TMouseButton Button,
	  TShiftState Shift, int X, int Y);
    void __fastcall SPA5MouseDown(TObject *Sender, TMouseButton Button,
	  TShiftState Shift, int X, int Y);
    void __fastcall SPA4MouseDown(TObject *Sender, TMouseButton Button,
	  TShiftState Shift, int X, int Y);
    void __fastcall SPA3MouseDown(TObject *Sender, TMouseButton Button,
	  TShiftState Shift, int X, int Y);
    void __fastcall FormKeyDown(TObject *Sender, WORD &Key,
	  TShiftState Shift);
private:	// User declarations
    int turno, /* hideSending, */ error;
    unsigned char portA, portE, ch[8];
public: 	// User declarations
    __fastcall TFormCT294(TComponent* Owner);

    int WriteData ();
    int ShowData  ();
};
//---------------------------------------------------------------------------
extern PACKAGE TFormCT294 *FormCT294;
//---------------------------------------------------------------------------
#endif
