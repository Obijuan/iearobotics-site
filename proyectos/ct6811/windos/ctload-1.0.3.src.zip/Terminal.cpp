/*
 * Terminal.cpp                   2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Terminal.h"
#include "Main.h"
#include "ReadTh.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormTerminal *FormTerminal;
//---------------------------------------------------------------------------
__fastcall TFormTerminal::TFormTerminal(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFormTerminal::FormShow(TObject *Sender)
{
  Memo->Clear();
  Memo->ReadOnly = ! FormMain->termEco;
  readThread = new TReadThread(false, FormMain->termHex);
}
//---------------------------------------------------------------------------
void __fastcall TFormTerminal::FormHide(TObject *Sender)
{
  readThread->Terminate();
  Sleep(250);
}
//---------------------------------------------------------------------------
void __fastcall TFormTerminal::MemoKeyPress(TObject *Sender, char &Key)
{
  if (Key == VK_ESCAPE)
    Close();
  else
    FormMain->ct6811.WriteChar(Key);
}
//---------------------------------------------------------------------------

