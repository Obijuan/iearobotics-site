/*
 * Errors.h                       2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#ifndef ErrorsH
#define ErrorsH
//---------------------------------------------------------------------------
#define NO_ERR      0
#define NO_RESET    1  // "No es posible realizar un reset de la tarjeta"
#define NO_OPEN     2  // "No es posible abrir el puerto de comunicaciones"
#define NO_ANSWER   3
#define NO_ECHO     4
//---------------------------------------------------------------------------
#endif
