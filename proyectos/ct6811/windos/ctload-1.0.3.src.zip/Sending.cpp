/*
 * Sending.cpp                    2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Sending.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormSending *FormSending;
//---------------------------------------------------------------------------
__fastcall TFormSending::TFormSending(TComponent* Owner) : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TFormSending::InitComm()
{
  FormSending->ProgressBar->Position = 0;
  FormSending->Info->Caption = "Inicializando de comunicaciones";
  FormSending->Show();
  FormSending->Update();
}
//---------------------------------------------------------------------------
void TFormSending::CloseComm()
{
  FormSending->Hide();
}
//---------------------------------------------------------------------------
void TFormSending::SendingServer()
{
  FormSending->ProgressBar->Position = 0;
  FormSending->Info->Caption = "Enviando datos del servidor";
  FormSending->Update();
}
//---------------------------------------------------------------------------
void TFormSending::SendingProgram()
{
  FormSending->ProgressBar->Position = 0;
  FormSending->Info->Caption = "Enviando datos del programa";
  FormSending->Update();
}
//---------------------------------------------------------------------------
void BarPosition(int delta)
{
  FormSending->ProgressBar->Position = FormSending->ProgressBar->Position + delta;
}
//---------------------------------------------------------------------------
