/*
 * Main.h			  2001/09/05
 *
 * Ctload para Windows
 *
 * Copyright (C) 2001 Javier de Lope Asia�n <jdlope@eui.upm.es>
 *
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

//---------------------------------------------------------------------------
#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include "Ct6811.h"
//---------------------------------------------------------------------------
class TFormMain : public TForm
{
__published:	// IDE-managed Components
    TPanel *Panel;
    TLabel *Label1;
    TLabel *Label2;
    TLabel *Label3;
    TLabel *LabelFilename;
    TLabel *LabelMemory;
    TLabel *LabelSize;
    TBitBtn *BtnSend;
    TBitBtn *BtnResend;
    TBitBtn *BtnOptions;
    TBitBtn *BtnAbout;
    TOpenDialog *OpenDialog;
    void __fastcall BtnSendClick(TObject *Sender);
    void __fastcall BtnResendClick(TObject *Sender);
    void __fastcall BtnOptionsClick(TObject *Sender);
    void __fastcall BtnAboutClick(TObject *Sender);

    void __fastcall FormDestroy(TObject *Sender);
private:	// User declarations

public: 	// User declarations
    TCT6811 ct6811;
    char port[5];
    bool openTerm;
    bool termHex;
    bool termEco; 

    __fastcall TFormMain(TComponent* Owner);

    void SendFile    (const char *filename);
    void ResetResend ();
    void ShowError   (int err);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormMain *FormMain;
//---------------------------------------------------------------------------
#endif
