# Microsoft Developer Studio Generated NMAKE File, Based on dllcts.dsp
!IF "$(CFG)" == ""
CFG=dllcts - Win32 Debug
!MESSAGE No configuration specified. Defaulting to dllcts - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "dllcts - Win32 Release" && "$(CFG)" != "dllcts - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "dllcts.mak" CFG="dllcts - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "dllcts - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "dllcts - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "dllcts - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\dllcts.dll"

!ELSE 

ALL : "$(OUTDIR)\dllcts.dll"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\dllcts.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\dllcts.dll"
	-@erase "$(OUTDIR)\dllcts.exp"
	-@erase "$(OUTDIR)\dllcts.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS"\
 /Fp"$(INTDIR)\dllcts.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\dllcts.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib\
 advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib\
 odbccp32.lib /nologo /subsystem:windows /dll /incremental:no\
 /pdb:"$(OUTDIR)\dllcts.pdb" /machine:I386 /out:"$(OUTDIR)\dllcts.dll"\
 /implib:"$(OUTDIR)\dllcts.lib" 
LINK32_OBJS= \
	"$(INTDIR)\dllcts.obj"

"$(OUTDIR)\dllcts.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "dllcts - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\dllcts.dll"

!ELSE 

ALL : "$(OUTDIR)\dllcts.dll"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\dllcts.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\dllcts.dll"
	-@erase "$(OUTDIR)\dllcts.exp"
	-@erase "$(OUTDIR)\dllcts.ilk"
	-@erase "$(OUTDIR)\dllcts.lib"
	-@erase "$(OUTDIR)\dllcts.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_WINDLL" /Fp"$(INTDIR)\dllcts.pch" /YX /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\"\
 /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\dllcts.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:yes\
 /pdb:"$(OUTDIR)\dllcts.pdb" /debug /machine:I386 /out:"$(OUTDIR)\dllcts.dll"\
 /implib:"$(OUTDIR)\dllcts.lib" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\dllcts.obj"

"$(OUTDIR)\dllcts.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(CFG)" == "dllcts - Win32 Release" || "$(CFG)" == "dllcts - Win32 Debug"
SOURCE=.\dllcts.cpp

"$(INTDIR)\dllcts.obj" : $(SOURCE) "$(INTDIR)"



!ENDIF 

