struct registros1 {  /* Estructura registros del tipo 1 */

	  unsigned short int tam;        /* Tama�o codigo/datos  */
	  unsigned int dir;              /* Direccion            */
	  unsigned short int codigo[37]; /* Codigo/datos         */
	  struct registros1 *sig;        /* Siguiente registro   */

};

struct sfichs19 {   /* Estructura ficheros S19 */

	 unsigned int nbytes;        /* N� bytes total de codigo fich. S19 */
	 unsigned int nreg;          /* N� registros del tipo 1            */
	 struct registros1 *cabeza;  /* Lista de registros del tipo 1      */

};

typedef struct sfichs19 S19;  /* TIPO S19 */