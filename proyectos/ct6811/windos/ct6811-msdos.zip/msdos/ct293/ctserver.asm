* ..........................................................................
* . CTSERVER. v2.0.                             MICROBOTICA  DICIEMBRE 1999.
* ..........................................................................
* .  Programa servidor para la conexi�n de tarjetas entrenadoras basadas   .
* .  en el 68HC11 con el PC.                                               .
* .                                                                        .
* .    El servidor ofrece una serie de servicios a un programa cliente     .
* .  que se encuentra en el PC y que se comunica con el servidor a trav�s  .
* .  del puerto serie.                                                     .
* .                                                                        .
* .    Los servicios que ofrece el servidor son los siguientes:            .
* .    - Transferencia de bloques de hasta 64K del micro al PC             .
* .    - Transferencia de bloques de hasta 64K del PC al micro             .
* .    - Grabaci�n de datos en la memoria EEPROM                           .
* .    - Ejecuci�n de programas. (JUMP & EXECUTE)                          .
* .    - Control de supervivencia                                          .
* .                                                                        .
* .   Para la solicitud de estos servicios existe un protocolo. En primer  .
* .  lugar el cliente (programa en el PC) debe enviar un c�digo que        .
* .  identifique el servicio que quiere obtener del servidor. Seg�n el     .
* .  servicio solicitado, el intercambio de datos entre cliente y servidor .
* .  sera de una forma u otra.                                             .
* .                                                                        .
* ..........................................................................

* ..........................................................................
* . DESCRIPCION DETALLADA DE LOS SERVICIOS DEL SERVIDOR                    .
* ..........................................................................
* .   CONTROL DE SUPERVIVENCIA:                                            .
* .                                                                        .
* .   Este servicio lo utiliza el cliente para saber si el servidor        .
* .  se est� ejecutando en el micro o no. Si el servidor no responde se    .
* .  puede deber a una de las siguientes causas:                           .
* .       * Placa entrenadora no alimentada                                .
* .       * Placa entrenadora no conectada al PC                           .
* .       * El micro est� ejecutando un programa que no es el CTSERVER     .
* .       * Se ha 'reseteado' el micro                                     .
* .                                                                        .
* .  El protocolo entre cliente y servidor es el siguiente:                .
* .                                                                        .
* .  Cliente:  Env�a c�digo 68 para solicitar control de supervivencia     .
* .  Servidor: Responde enviando el car�cter 'J'                           .
* ..........................................................................
* .  TRANSFERENCIA DE BLOQUES DEL MICRO AL PC                              .
* .                                                                        .
* .    Con este servicio se pueden volcar bloques de longitud comprendida  .
* . entre 1 y 65535 bytes desde el micro al PC.                            .
* .                                                                        .
* .  Protocolo entre cliente y servidor:                                   .
* .                                                                        .
* .  Cliente: env�a c�digo 65 para solicitar servicio de transferencia     .
* .  Cliente: Env�a la direcci�n de comienzo del bloque que se quiere      .
* .           Transferir.  Las direcciones ocupan 2 bytes. Primero se      .
* .           envia el byte de menor peso y luego el de mayor peso.        .
* .  Cliente: Env�a la longitud del bloque a transferir. Este valor es de  .
* .           2 bytes. Primero se env�a el de menor peso y luego el de     .
* .           mayor peso.                                                  .
* .  Servidor: Env�a el bloque de memoria solicitado. Se env�an tantos     .
* .            bytes como sea el tama�o del bloque solicitado (entre 1 y   .
* .            65535 bytes)                                                .
* ..........................................................................
* .  TRANSFERENCIA DE BLOQUES DEL PC AL MICRO                              .
* .                                                                        .
* .    Con este servicio se pueden volcar bloques de longitud comprendida  .
* .  entre 1 y 65535 bytes desde el PC al micro.                           .
* .                                                                        .
* .  Protocolo entre cliente y servidor:                                   .
* .                                                                        .
* .   Cliente: Env�a c�digo 66 para solicitar servico de transferencia     . 
* .   Cliente: Env�a la direcci�n de comienzo donde situar el bloque. Las  . 
* .            direcciones ocupan 2 bytes. Primero se env�a el byte de     .
* .            menor peso y luego el de mayor peso.                        .
* .   Cliente: Env�a la longitud del bloque a transferir. Este valor es de .
* .            2 bytes. Primero se env�a el de menor peso y luego el de    .
* .            mayor peso.                                                 .
* .   Cliente: Comienza a enviar el bloque de datos. El servidor ir�       .
* .            leyendo los bytes y los ir� colocando a partir de la        .
* .            direcci�n de memoria indicada.                              .
* ..........................................................................
* .  GRABACION DE UN BLOQUE EN LA MEMORIA EEPROM                           .
* .                                                                        .
* .     Con este servicio se pueden grabar datos en la memoria EEPROM      .
* .  interna del micro.  Antes de grabar un dato en una direcci�n de la    .
* .  memoria EEPROM se borra primero dicha posici�n y despu�s se escribe   .
* .  el dato.                                                              .
* .                                                                        .
* .   Protocolo entre cliente y servidor:                                  .
* .                                                                        .
* .   Cliente: Env�a c�digo 69 para solicitar servicio de grabaci�n EEPROM .
* .   Cliente: Env�a la direcci�n de comienzo donde grabar el bloque. Es   .
* .            responsabilidad del programa cliente enviar una direcci�n   .
* .            que se corresponda con la EEPROM. Primero se env�a el       .
* .            byte de menor peso y luego el de mayor peso.                .
* .   Cliente: Env�a la longitud del bloque a grabar. Primero se env�a el  .
* .            byte de menor peso y luego el de mayor peso.                .
* .   Cliente: Comienza a enviar el bloque de datos. El cliente debe tener .
* .            en cuenta que grabar un byte en la eeprom lleva m�s tiempo  .
* .            que guardarlo en RAM. Por ello el SERVIDOR HACE ECO de      .
* .            cada byte enviado una vez grabado.                          .
* ..........................................................................
* .   EJECUCION DE PROGRAMAS                                               .
* .                                                                        .
* .     Con este servicio se salta a programas que se encuentren en otras  .
* .  direcciones de memoria. Hay que tener en cuenta que cuando se ejecute .
* .  otro programa, el servidor se deja de ejecutar y por tanto el programa.
* .  cliente perder� la conexi�n con el servidor.                          .
* .                                                                        .
* .   Protocolo entre cliente y servidor:                                  .
* .                                                                        .
* .   Cliente: Env�a c�digo 67 para solicitar servicio de ejecuci�n        .
* .   Cliente: Env�a la direcci�n a la que saltar. Primero se env�a el
* .            byte de menor peso y luego el de mayor peso.                .
* .                                                                        .
* ..........................................................................

       ORG $0000

* ---- Definici�n de los servicios
TMPC    EQU 65         ; Transferencia de bloques del micro al PC
TPCM    EQU 66         ; Transferencia de bloques del PC al micro
JEXE    EQU 67         ; Servicio JUMP & EXECUTE
ALIVE   EQU 68         ; Servicio de supervivencia
GBEE    EQU 69         ; Grabar un bloque en la EEPROM

OKALIVE EQU 'J'

* --- Registros del SCI

BAUD    equ  $2B
SCCR1   equ  $2C
SCCR2   equ  $2D
SCSR    equ  $2E
SCDR    equ  $2F
PACTL   equ  $26

* ---- REGISTROS DE LA EEPROM  -----

PPROG   equ $103b       ; Control de programacion de la EEPROM
CONFIG  equ $103f       ; Registro de Configuraci�n del MICRO


        BRA inicializar

dirini   RMB  2   ; Direcci�n inicio
longbloq RMB  2   ; Tama�o bloque
codigo   RMB  1   ; C�digo de servicio solicitado

inicializar
        LDX #$1000

waitt   BRCLR SCSR,X  $40 waitt  ; Esperar a que se termine en enviar
        LDAA  #$30
        STAA  BAUD,X      ; Configurar velocidad transmisi�n a 9600 baudios
	BSET  PACTL,X $08 ; el PA3 configurado como salida


begin_server            
        LDX #$1000
        BSR leer_car    ; Esperar a que el PC solicite un servicio
        STAA codigo     ; Almacenar temporalmente el c�digo
        CMPA #ALIVE     ; �Servicio de supervivencia?
        BEQ serv_alive
        CMPA #JEXE      ; �Servicio JUMP & EXECUTE?
        BEQ serv_jexec
        CMPA #TMPC      ; �Servicio Transmisi�n micro-PC?
        BEQ serv_tmpc
        CMPA #TPCM      ; �Servicio Transmision PC-micro?
        BEQ serv_tpcm
        CMPA #GBEE      ;  �Servicio Grabacion de EEPROM?
        BEQ serv_gbee

        JMP begin_server

serv_alive              
        LDAA #OKALIVE
        BSR enviar
        JMP begin_server

serv_tpcm
        INC codigo
        BRA comun
serv_tmpc
        CLR codigo
comun
        BSR leer_dir
        STY dirini
        BSR leer_dir    ; Leer tama�o del bloque
        STY longbloq    ; Almacenar tama�o bloque
bucle_tmpc
        CPY #0                  ; �Bloque transferido?
        BEQ fin_ser_tmpc        ; si -> fin
        LDY dirini
        LDAA codigo
        TSTA
        BNE tpcm                ; Transferencia micro->pc
        LDAA 0,Y                ; Leer un byte
        BSR enviar              ; Enviar byte
        BRA sigue               ; Transferencia pc->micro
tpcm    BSR leer_car            ; Leer un byte
        STAA 0,Y                ; Almacenar byte

sigue   INY
        STY dirini              ; Apuntar siguiente direcci�n
        LDY longbloq
        DEY
        STY longbloq            ; Un byte menos queda por enviar
        BRA bucle_tmpc
fin_ser_tmpc
        JMP begin_server

serv_jexec
        BSR leer_dir    ; Leer direcci�n de inicio
        STY dirini      ; Almacenar direcci�n inicio
        JMP 0,Y

***********************************************************
*  Rutina para leer un car�cter del puerto serie (SCI)    *
*  La rutina espera hasta que llega alg�n car�cter        *
*  ENTRADAS: Ninguna                                      *
*  SALIDAS: El acumulador A contiene el car�cter recibido *
***********************************************************

leer_car BRCLR SCSR,X $10 leer_car   ; Esperar hasta que llegue un car�cter
        LDAA SCDR,X
        RTS

******************************************************************
*  Enviar un car�cter por el puerto serie (SCI).                 *
*  ENTRADAS: El acumulador A contiene el car�cter a enviar       *
*  SALIDAS: Ninguna                                              *
******************************************************************

enviar  BRCLR SCSR,X $80 enviar
        STAA SCDR,X
        RTS

************
* LEER_DIR *
**********************************************************************
*  Leer una direcci�n por el SCI y devolverla en el registro Y       *
* ENTRADAS: Ninguna                                                  *
* SALIDAS: El registro Y contiene la direcci�n leida                 *
**********************************************************************
leer_dir
        PSHA            ; Salvar registros utilizados
        PSHB

        BSR leer_car    ; Leer byte bajo de la direcci�n
        TAB             ; B contiene byte bajo direcci�n
        BSR leer_car    ; A contiene byte alto de la direcci�n
        XGDY            ; Ahora Y contiene la direcci�n leida

        PULB            ; Recuperar registros utilizados
        PULA
        RTS

serv_gbee
        BSR leer_dir
        STY dirini
        BSR leer_dir    ; Leer tama�o del bloque
        STY longbloq    ; Almacenar tama�o bloque
bucle_gbee
        CPY #0                  ; �Bloque transferido?
        BEQ fin_ser_gbee        ; si -> fin
        LDY dirini

        LDAB #$16
        STAB PPROG  ; ponemos modo borrar BYTE
        STAB $0,Y
        LDAB #$17   ;
        STAB PPROG  ; Activo programaci�n
        BSR  PAUSA  ; Realizo la pausa de 10ms

        LDAB #$02
        STAB PPROG  ; ponemos EELAT=1 (EEPGM=0)
        BSR  leer_car
        BSR  enviar
        STAA $0,Y
        LDAB #$03   ; 
        STAB PPROG  ; Activo programaci�n EEPGM=1  (EELAT=1)
        BSR  PAUSA  ; Realizo la pausa de 10ms

        INY
        STY dirini              ; Apuntar siguiente direcci�n 
        LDY longbloq
        DEY
        STY longbloq            ; Un byte menos queda por enviar
        BRA bucle_gbee
fin_ser_gbee
        CLR  PPROG  ; Desactivo programacion y pongo modo READ
        JMP begin_server

*************************************************
*   Realizar una pausa prefijada                *
*************************************************

PAUSA
        PSHY
        LDY   #$0D10
SIGUE   DEY
        CPY #$00
        BNE SIGUE
        PULY
        RTS

        END
