/*********************************************************************/
/*  J&J  Soft-Hard Company.  Noviembre 1995.  ETSI Telecomunicacion  */
/*********************************************************************/
/*                                                                   */
/*  CADENAS.C  -->  Librer�as para el manejo de cadenas              */
/*                                                                   */
/*********************************************************************/


void input_cad(char cad[],int maxcar);
/***********************************************************************/
/*  Pedir una cadena por el teclado. La cadena se devuelve en "cad".   */
/*  S�lo se pueden introducir como m�ximo "maxcar" caracteres.         */
/*  Si se pulsa la tecla ESC se aborta y se devuelve un 0 en cad[0].   */
/*  Si se pulsa ENTER y no hay cadena introducida tambi�n se devuelve  */
/*  un 0 en cad[0]                                                     */
/***********************************************************************/


int input_numero(void);
/***********************************************************************/
/*  S�lo se pueden introducir como m�ximo "maxcar" caracteres.         */
/*  Si se pulsa la tecla ESC se aborta                                 */
/***********************************************************************/

