Utilidades para la CT6811 desarrolladas para MS-DOS:

ct293 : Manejo de la tarjeta CT293 (Version obsoleta)
ct294 : Manejo de la tarjeta CT293+
ctdialog: Dialogo con la ct6811
ctmap   : Mostrar el mapa de memoria de fichero .S19
downmcu : Envio de programas a la CT6811
mcboot2 : Terminal de comunicaciones
s19toc  : Filtro para convertir programas .S19 en programas .C
twb2	: Programa integrado que engloba muchas utilidades

Estan realizadas con el compilador Turbo-C de Borland.


