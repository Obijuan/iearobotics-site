# Microsoft Developer Studio Generated NMAKE File, Based on ctwin.dsp
!IF "$(CFG)" == ""
CFG=ctwin - Win32 Debug
!MESSAGE No configuration specified. Defaulting to ctwin - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "ctwin - Win32 Release" && "$(CFG)" != "ctwin - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ctwin.mak" CFG="ctwin - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ctwin - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "ctwin - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ctwin - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\ctwin.exe"

!ELSE 

ALL : "$(OUTDIR)\ctwin.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ctwin.obj"
	-@erase "$(INTDIR)\ctwin.pch"
	-@erase "$(INTDIR)\ctwin.res"
	-@erase "$(INTDIR)\ctwinDlg.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(OUTDIR)\ctwin.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_AFXDLL" /Fp"$(INTDIR)\ctwin.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Release/
CPP_SBRS=.
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /o NUL /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\ctwin.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ctwin.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:no\
 /pdb:"$(OUTDIR)\ctwin.pdb" /machine:I386 /out:"$(OUTDIR)\ctwin.exe" 
LINK32_OBJS= \
	"$(INTDIR)\ctwin.obj" \
	"$(INTDIR)\ctwin.res" \
	"$(INTDIR)\ctwinDlg.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\ctwin.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "ctwin - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

!IF "$(RECURSE)" == "0" 

ALL : "$(OUTDIR)\ctwin.exe"

!ELSE 

ALL : "$(OUTDIR)\ctwin.exe"

!ENDIF 

CLEAN :
	-@erase "$(INTDIR)\ctwin.obj"
	-@erase "$(INTDIR)\ctwin.pch"
	-@erase "$(INTDIR)\ctwin.res"
	-@erase "$(INTDIR)\ctwinDlg.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\vc50.idb"
	-@erase "$(INTDIR)\vc50.pdb"
	-@erase "$(OUTDIR)\ctwin.exe"
	-@erase "$(OUTDIR)\ctwin.ilk"
	-@erase "$(OUTDIR)\ctwin.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_AFXDLL" /Fp"$(INTDIR)\ctwin.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /o NUL /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\ctwin.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ctwin.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=wincts.lib /nologo /subsystem:windows /incremental:yes\
 /pdb:"$(OUTDIR)\ctwin.pdb" /debug /machine:I386 /out:"$(OUTDIR)\ctwin.exe"\
 /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\ctwin.obj" \
	"$(INTDIR)\ctwin.res" \
	"$(INTDIR)\ctwinDlg.obj" \
	"$(INTDIR)\StdAfx.obj"

"$(OUTDIR)\ctwin.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_OBJS)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(CPP_SBRS)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(CFG)" == "ctwin - Win32 Release" || "$(CFG)" == "ctwin - Win32 Debug"
SOURCE=.\ctwin.cpp
DEP_CPP_CTWIN=\
	".\ctwin.h"\
	".\ctwinDlg.h"\
	".\StdAfx.h"\
	

"$(INTDIR)\ctwin.obj" : $(SOURCE) $(DEP_CPP_CTWIN) "$(INTDIR)"\
 "$(INTDIR)\ctwin.pch"


SOURCE=.\ctwin.rc
DEP_RSC_CTWIN_=\
	".\res\ctwin.ico"\
	".\res\ctwin.rc2"\
	

"$(INTDIR)\ctwin.res" : $(SOURCE) $(DEP_RSC_CTWIN_) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\ctwinDlg.cpp

!IF  "$(CFG)" == "ctwin - Win32 Release"

DEP_CPP_CTWIND=\
	".\ctwin.h"\
	".\ctwinDlg.h"\
	".\StdAfx.h"\
	{$(INCLUDE)}"wincts.h"\
	

"$(INTDIR)\ctwinDlg.obj" : $(SOURCE) $(DEP_CPP_CTWIND) "$(INTDIR)"\
 "$(INTDIR)\ctwin.pch"


!ELSEIF  "$(CFG)" == "ctwin - Win32 Debug"


"$(INTDIR)\ctwinDlg.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\ctwin.pch"


!ENDIF 

SOURCE=.\StdAfx.cpp
DEP_CPP_STDAF=\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "ctwin - Win32 Release"

CPP_SWITCHES=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_AFXDLL" /Fp"$(INTDIR)\ctwin.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ctwin.pch" : $(SOURCE) $(DEP_CPP_STDAF)\
 "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ctwin - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D\
 "_WINDOWS" /D "_AFXDLL" /Fp"$(INTDIR)\ctwin.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\"\
 /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ctwin.pch" : $(SOURCE) $(DEP_CPP_STDAF)\
 "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 


!ENDIF 

