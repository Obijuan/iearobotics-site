; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CCtwinApp
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ctwin.h"

ClassCount=3
Class1=CCtwinApp
Class2=CCtwinDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_CTWIN_DIALOG

[CLS:CCtwinApp]
Type=0
HeaderFile=ctwin.h
ImplementationFile=ctwin.cpp
Filter=N
LastObject=CCtwinApp

[CLS:CCtwinDlg]
Type=0
HeaderFile=ctwinDlg.h
ImplementationFile=ctwinDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CCtwinDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=ctwinDlg.h
ImplementationFile=ctwinDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_CTWIN_DIALOG]
Type=1
Class=CCtwinDlg
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDC_DTR,button,1342242816
Control3=IDC_STATIC,static,1342308352

