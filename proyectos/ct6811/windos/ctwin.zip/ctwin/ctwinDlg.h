// ctwinDlg.h : header file
//

#if !defined(AFX_CTWINDLG_H__7E6468BB_A9E3_11D4_997D_005004FE0831__INCLUDED_)
#define AFX_CTWINDLG_H__7E6468BB_A9E3_11D4_997D_005004FE0831__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CCtwinDlg dialog

class CCtwinDlg : public CDialog
{
// Construction
public:
	BOOL m_bdtr;
	CCtwinDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCtwinDlg)
	enum { IDD = IDD_CTWIN_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtwinDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCtwinDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDtr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTWINDLG_H__7E6468BB_A9E3_11D4_997D_005004FE0831__INCLUDED_)
