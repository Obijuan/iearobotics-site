// ctdownDlg.h : header file
//

#if !defined(AFX_CTDOWNDLG_H__AB66B46A_9E8A_11D4_9965_005004FE0831__INCLUDED_)
#define AFX_CTDOWNDLG_H__AB66B46A_9E8A_11D4_9965_005004FE0831__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


#define WM_EVENTO_COM WM_USER+100  // mensaje de notificaci�n
UINT ControlarEventos(LPVOID p); // hilo 


/////////////////////////////////////////////////////////////////////////////
// CCtdownDlg dialog

class CCtdownDlg : public CDialog
{
// Construction
public:
	int m_ibaud;
	CHAR lpBuf[1];
	void LeerCar();
	OVERLAPPED m_sOverRead;
	OVERLAPPED m_sOverWrite;
	HANDLE m_hDisComm;           // handle al dispositivo de comunicaciones	
	BOOL m_ConexionEstablecida;  // TRUE si el puerto fue abierto
	BOOL m_bHiloActivo;   // TRUE si el hilo est� activo
	BOOL CortarConexion(int m_indPuerto);
	BOOL ConfigurarDisCom();
	void MensajeDeError( DWORD nError);
	BOOL EstablecerConexion(int m_indPuerto);
	int m_idtr;
	CCtdownDlg(CWnd* pParent = NULL);	// standard constructor

	// Dialog Data
	//{{AFX_DATA(CCtdownDlg)
	enum { IDD = IDD_CTDOWN_DIALOG };
	CSpinButtonCtrl	m_spin;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtdownDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCtdownDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnDtr();
	afx_msg long OnEventoCom(UINT wParam, long lparam);
	afx_msg void OnEnviar();
	afx_msg void OnDeltaposSpin2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBaud();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTDOWNDLG_H__AB66B46A_9E8A_11D4_9965_005004FE0831__INCLUDED_)
