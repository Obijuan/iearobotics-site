; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CCtdownDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ctdown.h"

ClassCount=3
Class1=CCtdownApp
Class2=CCtdownDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_CTDOWN_DIALOG
Resource2=IDR_MAINFRAME
Resource3=IDD_ABOUTBOX

[CLS:CCtdownApp]
Type=0
HeaderFile=ctdown.h
ImplementationFile=ctdown.cpp
Filter=N
LastObject=CCtdownApp

[CLS:CCtdownDlg]
Type=0
HeaderFile=ctdownDlg.h
ImplementationFile=ctdownDlg.cpp
Filter=D
LastObject=IDC_BAUD
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=ctdownDlg.h
ImplementationFile=ctdownDlg.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=8
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,button,1342177287
Control6=IDC_STATIC,static,1342308352
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352

[DLG:IDD_CTDOWN_DIALOG]
Type=1
Class=CCtdownDlg
ControlCount=11
Control1=IDC_EXIT,button,1342242816
Control2=IDC_DTR,button,1342242816
Control3=IDC_ENVIAR,button,1342242816
Control4=IDC_STATIC,static,1342308353
Control5=IDC_MTX,edit,1350633600
Control6=IDC_MRX,edit,1350633600
Control7=IDC_STATIC,static,1342308353
Control8=IDC_SPIN2,msctls_updown32,1342177312
Control9=IDC_LETRA,static,1342308353
Control10=IDC_STATIC,button,1342177287
Control11=IDC_BAUD,button,1342242816

