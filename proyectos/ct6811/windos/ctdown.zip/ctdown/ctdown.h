// ctdown.h : main header file for the CTDOWN application
//

#if !defined(AFX_CTDOWN_H__AB66B468_9E8A_11D4_9965_005004FE0831__INCLUDED_)
#define AFX_CTDOWN_H__AB66B468_9E8A_11D4_9965_005004FE0831__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCtdownApp:
// See ctdown.cpp for the implementation of this class
//

class CCtdownApp : public CWinApp
{
public:
	CCtdownApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCtdownApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCtdownApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CTDOWN_H__AB66B468_9E8A_11D4_9965_005004FE0831__INCLUDED_)
