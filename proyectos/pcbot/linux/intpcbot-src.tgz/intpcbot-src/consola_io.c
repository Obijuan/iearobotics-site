/**************************************************************************/
/*  CONSOLA_IO.C   (C) Microbotica, S.L. NOVIEMBRE 1997.                  */
/* Antes io.c                                                             */
/* ---------------------------------------------------------------------- */
/*  Rutinas de E/S para la pantalla y el teclado. Las funciones de        */
/*  interfaz son:                                                         */
/*                                                                        */
/*    * abrir_consola()                                                   */
/*    * cerrar_consola()                                                  */
/*    * getch()                                                           */
/*    * kbhit()                                                           */
/*    * printcar()  ; OBSOLETA                                            */
/*    * print()     ; OBSOLETA                                            */
/*                                                                        */
/*------------------------------------------------------------------------*/
/* Este modulo cumple el estandar POSIX.1, salvo en la implementacion de  */
/*  la funcion kbhit, que se emplea la llamada al sistem select.          */
/*                                                                        */
/* Este modulo deberia ser totalmente portable a Windows, utilizando la   */
/*  libreria Cygwin                                                       */
/*------------------------------------------------------------------------*/
/* web: www.microbotica.es                                                */
/* mail: info@microbotica.es                                              */
/**************************************************************************/

#include <string.h>
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>

#include "consola_io.h"

#define TIMEOUT 0  /* Tiempo de espera para el select */


/*------------*/
/* VARIABLES  */
/*------------*/
static struct termios oldconsola,consola;


int abrir_consola()
/*************************************************************/
/* Abrir la consola. Configurar el terminal de entrada para  */
/* soportar la funcion getch.                                */
/*                                                           */
/* DEVUELVE:                                                 */
/*  -  0 Si no ha habido error                               */
/*  - -1 Si ha ocurrido algun error                          */
/*************************************************************/
{
  /* Leer los parametros asociados a la consola */
  if (tcgetattr(STDIN_FILENO,&consola)==-1) {
    perror("Error en tcgetattr");
    return -1;
  }
  oldconsola = consola; /* Almacenar parametros para su posterior recup. */
  
  /* Cambiar parametros */
  consola.c_cc[VMIN]=0;
  consola.c_lflag&=~(ECHO|ICANON); 
  
  if (tcsetattr(STDIN_FILENO,TCSANOW,&consola)==-1) {
    perror("Error en tcsetattr");
    return -1;
  }
  
  return 0;
}

void cerrar_consola()
/**********************************************/
/* Cerrar la consola y recuperar la anterior  */
/**********************************************/
{
  if (tcsetattr(STDIN_FILENO,TCSANOW,&oldconsola)==-1) 
    perror("Error en tcsetattr");
}

int kbhit()
/************************************************************************/
/*  Indicar si hay un caracter pendiente de ser leido. La funcion       */
/*  devuelve:                                                           */
/*    0 --> No hay caracteres pendientes                                */
/*    1 --> Si hay caracteres pendientes                                */
/************************************************************************/
{
  int n;
  fd_set rfd;
  struct timeval timeout;
  
  timeout.tv_sec  = 0;
  timeout.tv_usec = TIMEOUT;
  
  FD_ZERO(&rfd);
  FD_SET(STDIN_FILENO,&rfd);
  
  n = select(STDIN_FILENO+1,&rfd,NULL,NULL,&timeout);
  
  return n;
}

char getch()
/******************************************************************/
/*  Devolver el caracter leido por el teclado. Si no hay ningun   */
/*  caracter pendiente de ser leido se espera hasta que lo haya.  */
/******************************************************************/
{
  int n;
  char c;
    
  while (!kbhit());
  
  n = read(STDIN_FILENO,&c,1);
  
  return c;
}

void printcar(char c)
/****************************************************/
/* Imprimir un caracter directamente en la pantalla */
/* Funcion obsoleta, mantenida por compatibilidad   */
/****************************************************/
{
  printf ("%c",c);
  fflush(stdout);
}

void print(char *cad)
/******************************************************/
/* Imprimir una cadena directamente en la pantalla    */
/* Funcion obsoleta, mantenida por compatibilidad     */
/******************************************************/
{
  printf (cad);
  fflush(stdout);
}


