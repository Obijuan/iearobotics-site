/*********************************************************************/
/* PINT.C   (C) MICROBOTICA, S.L.      Diciembre 1998.               */
/*-------------------------------------------------------------------*/
/* Programa de prueba del modulo INT.C                               */
/*********************************************************************/

#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


/* Modulos incluidos del analizador */
#include "sin.h"
#include "sem.h"
#include "int.h"

/* Modulos de la libreria CTS */
#include "r6811pc.h"
#include "serie.h"
#include "bootstrp.h"
#include "ctclient.h"

int i=0;
int n=0;
extern int errno;

 
void accion_load()
/********************************************/
/* Accion al realiar al cargar el servidor  */
/********************************************/
{
  if (n==16 || i==255) {
    n=0;
    printf ("*");
    fflush(stdout);
  }
  i++;
  n++;
}

int cargar_ctserver()
/******************************************************************/
/* Cargar el CTSERVER. El CTSERVER que se carga esta configurado  */
/* para la velocidad de 7680 baudios.                             */
/******************************************************************/
{
  /* Matriz con el CTserver. La version es para 7680 Baudios */
byte programint[256]={
0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0xCE,
0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,0x43,0x27,0x54,0x81,
0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,0x7E,0x00,0x0E,0x86,
0x4A,0x8D,0x50,0x7E,0x00,0x0E,0x7C,0x00,0x06,0x20,0x03,0x7F,0x00,0x06,0x8D,
0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x23,
0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,0x8D,0x28,0x20,0x05,
0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x0E,0x8D,0x14,0x18,0xDF,0x02,0x18,0x6E,
0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,0xFC,0xA7,0x2F,0x39,
0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,0x39,0x8D,0xF2,0x18,
0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x34,0x18,0xDE,
0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,0xF7,0x10,0x3B,0x8D,
0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x8D,0xC2,0x18,0xA7,0x00,0xC6,0x03,
0xF7,0x10,0x3B,0x8D,0x15,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x0E,0x18,0x3C,0x18,0xCE,
0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,0x38,0x39,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,};

  printf ("\nCargando CTSERVER:\n\n");
  set_break_timeout(500000);
  printf("0%%     50%%   100%%\n");
  printf ("................\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
  fflush(stdout);  

  if (cargar_ramint(programint,accion_load)==0) {
    printf ("\nError: %s\n",getloaderror());
    return 0;
  };
  printf ("\nOK!\n");
  return 1;
}

int procesar_argumentos(int argc, char **argv)
/***************************************************************/
/* Abrir el fichero que se pasa como argumento. Si no se pasa  */
/* ninguno se toma la entrada estandar (teclado).              */
/*  Se devuelve el descriptor del fichero o -1 si ha habido    */
/*  algun error.                                               */
/***************************************************************/
{
  int fd;
  
  printf ("\n");
  if (argc==2){
    fd=open(argv[1],O_RDONLY);
    if (fd==-1) {
      printf ("Error!: %s\n",strerror(errno));
    }
    else printf ("Abierto fichero: %s\n",argv[1]);
  }
  else {
    printf ("Entrada estandar\n");
    fd=0;
  }
  return fd;
}

lista_sentencias *analisis(int fd, int *error)
/**************************************************************/
/* Realizar analisis sintactico y semantico y devolver el     */
/* ast.                                                       */
/**************************************************************/
{
  int linea;
  lista_sentencias *ls;
  
  printf ("Analisis sintactico..");
  ls=crear_ast(fd,error);
  if (*error) {
    linea=get_linea_error();
    printf ("\nError en linea %u!! %s\n",linea,getsin_error());
    return NULL;
  }
  printf ("OK!\n");
  printf ("Analisis semantico..");
  verificar_ast(ls,error);
  if (*error) {
    printf ("\nError semantico!! %s\n",getsem_error());
    return NULL;
  }
  printf ("OK|\n");
  return ls;
}

int ready_ct()
/***********************************************************/
/* Abrir puerto serie y cargar programa servidor.          */
/* Se devuelve 1 si se ha cargado sin problemas, 0 en caso */
/* contrario.                                              */
/***********************************************************/
{
  if (abrir_puerto_serie(COM1)==0) {
    printf ("Error al abrir puerto serie: %s\n",getserial_error());
    return 0;
  }  
  baudios(7680);
  if (cargar_ctserver()==0) {
    cerrar_puerto_serie();
    return 0;
  }
  usleep(200000);

  check_conexion();        /* Comprobar conexion */
  if (!hay_conexion()) {
    printf("No hay conexion");
    cerrar_puerto_serie();
    return 0;
  }
  return 1;
}

int main(int argc, char **argv)
{
  int error;
  lista_sentencias *ls;
  int fd;                 /* Descriptor del fichero */ 
  int linea;
  
  fd=procesar_argumentos(argc,argv);
  if (fd==-1) exit(1);

  /* Analizar el programa fuente */
  ls=analisis(fd,&error);
  if (error)  return 1;
  
  /* Cargar el CTSERVER */
  if (!ready_ct()) return 1;
  
  printf ("Interpretando...\n\n");
  if (!interpreta_ast(ls)) {
    linea=get_int_linea_error();
    printf ("\nLinea %u: %s\n",linea,getint_error());
  }
  else {
    printf ("OK\n\n");
  }

/*  print_ast(ls); */
  free(ls);  
  close(fd);
  return 0;
}

