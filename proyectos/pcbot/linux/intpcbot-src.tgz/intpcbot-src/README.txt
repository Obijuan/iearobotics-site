Es necesario tener instalada la libreria CTS
Para compilar, ejecutar make

Esto creará los siguientes programas:

-plex : Pruebas para el modulo lexico
-psin : Pruebas para el modulo sintactico
-psem : Pruebas para el modulo semantico
-pint : Pruebas para el modulo interprete

  El programa final es pint. Para probarlo hacer lo siguiente:

1) Alimentar PCBOT y conectarlo al PC (COM1)
2) ejecutar lo siguiente:
   ./pint < pint.pru

  Esto cargara el ctserver en el 6811 y comenzara a ejecutar el programa
  pint.pru, que lo que hace es activar 5 salidas de PCBOT.

  Con PINT se puede probar cualquier programa para PCBOT (.bot)

  
