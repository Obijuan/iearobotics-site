/*********************************************************************/
/* INT.H   (c) Microbotica, S.L            Diciembre 1998            */
/*-------------------------------------------------------------------*/
/* Definiciones y estructuras de datos del modulo interprete.        */
/*********************************************************************/

int interpreta_ast(lista_sentencias *ls);
/***********************/
/* Interpretar un AST  */
/***********************/

int get_num_int_error();
/***********************************/
/*  Devolver el numero de error    */
/***********************************/

int get_int_linea_error();
/*************************************************************/
/* Obtener el numero de linea donde se ha producido el error */
/*************************************************************/

char *getint_error();
/*****************************************************************/
/* Devolver la cadena de error del ultimo error producido.       */
/*****************************************************************/

