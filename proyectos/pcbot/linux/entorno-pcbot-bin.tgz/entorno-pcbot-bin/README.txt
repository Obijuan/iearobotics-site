Entorno para la programacion de PCBOT

Es necesario tener la libreria CTS instalada

Para probarlo:

  1) Alimentar PCBOT y conectarlo al PC
  2) Ejecutar:

   ./micro -com1  (o -com2)

  Una vez cargado el entorno, pulsar F3 para cargar un programa. Probar con
  el programa proporcionado salida.bot. Una vez cargado pulsar F5 para 
  que se empiece a ejecutar (el cursor debe estar en la ventana del programa).
  El programa salida.bot activa y desactiva las 8 salidas de PCBOT, en un 
  bucle infinito.
