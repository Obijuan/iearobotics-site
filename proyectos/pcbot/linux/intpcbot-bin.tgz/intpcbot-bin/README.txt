Para probar hay que hacer lo siguiente:

1) Alimentar PCBOT y conectarlo al PC (COM1)
2) Ejecutar:

    intpcbot prueba.bot

  Se cargara el ctserver y luego se comenzara a ejecutar el programa.
  Este programa en las fuentes se llama pint, pero intpcbot es el mismo
  programa.

