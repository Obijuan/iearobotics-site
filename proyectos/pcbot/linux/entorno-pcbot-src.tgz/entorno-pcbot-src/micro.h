void ventana_mensajes(char *cad);
/*
** Imprime la cadena que pasamos como argumento en la ventana de mensajes
*/

void ventana_estado(char *cad);
/*
** Imprime la cadena que pasamos como argumento en la ventana de estado
*/
