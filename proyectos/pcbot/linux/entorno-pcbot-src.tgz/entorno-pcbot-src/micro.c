/****************************************************************************
* 	 MICROLOG:  INTERPRETE DE COMANDOS 'PCBOT'      MICROBOTICA S.L.    *
****************************************************************************/

#include <unistd.h>                                                                          
#include <curses.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

#include "serie.h"
#include "r6811pc.h"
#include "bootstrp.h"
#include "ctclient.h"
#include "sin.h"
#include "sem.h"
#include "microint.h"
#include "consola_io.h"

/*******************************************************************
* Variables del sistema y estructura de datos                      *
********************************************************************/

#define ANCHO  58
#define ALTO   14
#define LINEAS 1000    // lineas de texto que podemos escribir
#define SEGURIDAD 25   // margen de seguridad para el buffer de escritura
#define MODE644 (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)


extern int errno;

struct caracter {    /* cada caracter tiene asociado el valor del */
   unsigned char c;  /* caracter y el color                       */
   int  color;
};

struct posicion {    /* posicion de un caracter en el buffer */
  int x;
  int y;
};

struct posicion b_inicio,b_final,pos_final,pos_actual;
struct caracter buffer[LINEAS+SEGURIDAD+1][ANCHO+1];  // buffer texto
struct caracter blanco;    // posicion vacia

char nombre[13];
int desp=0,insert=1,bloque,tamano;
static int puerto;
int fd;


WINDOW *ventana[15];

/* PROTOTIPOS */
int confirmar(char cad1[],char cad2[]);



/********************************************************************
*     SUBRUTINAS DE CONTROL DEL PROGRAMA                            *
********************************************************************/

void accion_rxcar()
{
}

void accion_break()
{
}


void accion_load()
{
}


void dprint(char *cad)
/* Imprimir una cadena directamente en la pantalla  */
{
  int i=0;
  
  while (cad[i]!=0){
    write(1,&cad[i],1);
    i++;
  }
}


void clrscr()
/*  Borrar la pantalla  */
{
    dprint ("[2J");     /* Borrar la pantalla                        */
    dprint ("[1;1H");   /* Situar cursor en esquina superior derecha */
  
}


void analiza_parametros(int argc, char *argv[])
/* 
** Analizar los parametros de la linea de argumentos. Si se encuentran  
** errores se aborta el programa. Se actualizan las siguientes variables:                
** puerto --> Numero del puerto especificado.                         
*/
{
  char c;

  if (argc>2) {
    printf ("Demasiados parametros\n");
    exit(1);
  }
  while ((c = getopt(argc, argv, "c:h"))!=EOF) {
    switch (c) {
      case 'c': if (strcmp("om2",optarg)==0) puerto=COM2;
                else 
                  if (strcmp("om1",optarg)==0) puerto=COM1;
                  else puerto=COM2;  /* Por defecto COM2 */
                break;
      case 'h':
      default: 
               printf("\nParametros permtidos:\n\n");
               printf("-com1 : Establece puerto de comunicaciones COM1\n");
               printf("-com2 : Establece puerto de comunicaciones COM2\n");
               printf("-h    : Saca este menu\n");
               exit (0);
     }
  }
}


void inicia()
/*
** inicia el modo grafico, define los colores
*/
{
 if(!(initscr())){
  fprintf(stderr,"Error en la inicializacion.\n\n");
  exit(1);
 }
 start_color();
 noecho();
 raw();
  
 init_pair(1,COLOR_BLUE,COLOR_WHITE);
 init_pair(2,COLOR_WHITE,COLOR_BLUE);
 init_pair(3,COLOR_GREEN,COLOR_BLUE);
 init_pair(4,COLOR_RED,COLOR_WHITE); 
 init_pair(5,COLOR_CYAN,COLOR_BLUE);
 init_pair(6,COLOR_YELLOW,COLOR_BLUE);
 init_pair(7,COLOR_RED,COLOR_BLUE); 
 init_pair(8,COLOR_BLACK,COLOR_WHITE);
}

/****************************************************************************
 *   SUBRUTINAS DE DIALOGO CON EL SERVIDOR                                  *
 ***************************************************************************/

void comprueba_conexion()
/* 
**  verifica la conexion con la CT6811, utiliza la funcion 'hay_conexion()'
** implementada en la libcts 
*/
{
  check_conexion();
  leaveok(ventana[6],TRUE);
  mvwprintw(ventana[8],0,0,"%c",'A'*hay_conexion()+(1-hay_conexion())*' ');
  wnoutrefresh(ventana[8]);
  leaveok(ventana[6],FALSE);    
}


int detecta_ct6811()
/*
** procedimiento para detectar la CT6811 
*/
{
  resetct6811();
  if (wait_break(100000)==0) {
    return 0;  /* No se detecta CT6811 */
  }
  return 1;    /* CT6811 detectada  */
}


int cargar_ctserver(int flag)
/*
** Cargar el CTSERVER. El CTSERVER que se carga esta configurado  
** para la velocidad de 7680 baudios.                             
*/
{
  /* Matriz con el CTserver. La version es para 7680 Baudios */
byte programint[256]={
0x20,0x05,0x00,0x00,0x00,0x00,0x00,0xCE,0x10,0x00,0x1F,0x2E,0x40,0xFC,0xCE,
0x10,0x00,0x8D,0x66,0x97,0x06,0x81,0x44,0x27,0x13,0x81,0x43,0x27,0x54,0x81,
0x41,0x27,0x17,0x81,0x42,0x27,0x0E,0x81,0x45,0x27,0x6A,0x7E,0x00,0x0E,0x86,
0x4A,0x8D,0x50,0x7E,0x00,0x0E,0x7C,0x00,0x06,0x20,0x03,0x7F,0x00,0x06,0x8D,
0x4A,0x18,0xDF,0x02,0x8D,0x45,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x23,
0x18,0xDE,0x02,0x96,0x06,0x4D,0x26,0x07,0x18,0xA6,0x00,0x8D,0x28,0x20,0x05,
0x8D,0x1D,0x18,0xA7,0x00,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
0x18,0xDF,0x04,0x20,0xD7,0x7E,0x00,0x0E,0x8D,0x14,0x18,0xDF,0x02,0x18,0x6E,
0x00,0x1F,0x2E,0x20,0xFC,0xA6,0x2F,0x39,0x1F,0x2E,0x80,0xFC,0xA7,0x2F,0x39,
0x36,0x37,0x8D,0xEE,0x16,0x8D,0xEB,0x18,0x8F,0x33,0x32,0x39,0x8D,0xF2,0x18,
0xDF,0x02,0x8D,0xED,0x18,0xDF,0x04,0x18,0x8C,0x00,0x00,0x27,0x34,0x18,0xDE,
0x02,0xC6,0x16,0xF7,0x10,0x3B,0x18,0xE7,0x00,0xC6,0x17,0xF7,0x10,0x3B,0x8D,
0x28,0xC6,0x02,0xF7,0x10,0x3B,0x8D,0xBD,0x8D,0xC2,0x18,0xA7,0x00,0xC6,0x03,
0xF7,0x10,0x3B,0x8D,0x15,0x18,0x08,0x18,0xDF,0x02,0x18,0xDE,0x04,0x18,0x09,
0x18,0xDF,0x04,0x20,0xC6,0x7F,0x10,0x3B,0x7E,0x00,0x0E,0x18,0x3C,0x18,0xCE,
0x0D,0x10,0x18,0x09,0x18,0x8C,0x00,0x00,0x26,0xF8,0x18,0x38,0x39,0x00,0x00,
0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
0x00,};

  set_break_timeout(500000);
  if (flag==0) printf("\nCargando el servidor en la tarjeta PCBOT.\n");
  else {
   wprintw(ventana[5],"Cargando el servidor en PCBOT.\n");
   wnoutrefresh(ventana[5]);
  }
  if (cargar_ramint(programint,accion_load)==0) return 0;
  if (!check_conexion()) return 0 ;
  return 1;
}

/*********************************************************************
* PROCEDIMIENTOS DEL PROGRAMA PRINCIPAL                              *
**********************************************************************/

void menu()
/*   Dibuja el marco de trabajo */
{
  int i=0;

  /* define la pantalla completa */
  
  ventana[1]=newwin(0,0,0,0);
  wbkgdset(ventana[1],COLOR_PAIR(4));
  werase(ventana[1]);
  wattrset(ventana[1],COLOR_PAIR(4));
  mvwprintw(ventana[1],0,0," PCBOT 1.0.");
  wattrset(ventana[1],COLOR_PAIR(4) );
  mvwprintw(ventana[1],0,35,"                             MICROBOTICA -  ");
  wattrset(ventana[1],COLOR_PAIR(8));
  mvwprintw(ventana[1],24,0," F1 Ayuda   F2 Grabar  F3 Cargar  F4 Borrar  F5 Ejecutar              F10 Salir");   
  wattrset(ventana[1],COLOR_PAIR(4) );
  for (i=0; i<=4; i++) { 
    mvwprintw(ventana[1],24,1+i*11,"F%i",i+1);   
  }
  mvwprintw(ventana[1],24,70,"F10");
  wnoutrefresh(ventana[1]);
  ventana[8]=subwin(ventana[1],1,1,0,78);
  wattrset(ventana[8],COLOR_PAIR(4));
  wnoutrefresh(ventana[8]);
  
  /* define cada uno de los cuadros de texto */
    
  ventana[2]=newwin(17,61,1,0);  
  wbkgdset(ventana[2],COLOR_PAIR(3));
  werase(ventana[2]);
  wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);
  box(ventana[2],0,0);
  wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);
  mvwprintw(ventana[2],0,5,"[ Interprete de comandos ]");
  mvwprintw(ventana[2],0,38,"[ %s ]",nombre);
  mvwprintw(ventana[2],0,56,"[ ]");
  wattrset(ventana[2],COLOR_PAIR(3) | A_BOLD);
  mvwprintw(ventana[2],0,7,"Interprete de comandos");
  mvwprintw(ventana[2],16,2,"I");
  mvwprintw(ventana[2],0,57,"Z");
  ventana[6]=subwin(ventana[2],15,59,2,1);  /* ventana del interprete */
  wattrset(ventana[6],COLOR_PAIR(6) | A_BOLD );
  wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD );
  wnoutrefresh(ventana[2]); 
      
  ventana[3]=newwin(17,19,1,61);
  wbkgdset(ventana[3],COLOR_PAIR(3));
  werase(ventana[3]);
  wattrset(ventana[3],COLOR_PAIR(2) | A_BOLD);
  box(ventana[3],0,0);
  wattrset(ventana[3],COLOR_PAIR(2) | A_BOLD);
  mvwprintw(ventana[3],0,5,"[ Estado ]");
  wattrset(ventana[3],COLOR_PAIR(3) | A_BOLD);
  mvwprintw(ventana[3],0,7,"Estado");  
  ventana[7]=subwin(ventana[3],15,17,2,62);
  wattrset(ventana[7],COLOR_PAIR(5)|A_BOLD);
  scrollok(ventana[7],TRUE);
  wnoutrefresh(ventana[3]);    

  ventana[4]=newwin(6,80,18,0);
  wbkgdset(ventana[4],COLOR_PAIR(3));
  werase(ventana[4]);
  wattrset(ventana[4],COLOR_PAIR(2) | A_BOLD);
  box(ventana[4],0,0);
  wattrset(ventana[4],COLOR_PAIR(2) | A_BOLD);
  mvwprintw(ventana[4],0,5,"[ Mensajes ]");
  wattrset(ventana[4],COLOR_PAIR(3) | A_BOLD);
  mvwprintw(ventana[4],0,7,"Mensajes");
  wattrset(ventana[4],COLOR_PAIR(5) | A_BOLD);
  ventana[5]=subwin(ventana[4],4,78,19,1);
  scrollok(ventana[5],TRUE);
  wnoutrefresh(ventana[4]); 
  doupdate();
}


void pinta_pantalla_texto()
/*
** vuelca el trozo de buffer en la pantalla de texto, se utiliza la variable 
** global tamano para saber si la pantalla es grande o pequena
*/
{
  int i,j;

  for (i=0;i<=(14*(1-tamano)+20*tamano);i++) {     
    for (j=0;j<=58;j++) {
     wattrset(ventana[6],buffer[i+desp][j].color);     
     if (i+desp<=LINEAS) { 
       if ( (bloque==1) && (i+desp>=b_inicio.y) && (i+desp<=b_final.y) ) {
         wattrset(ventana[6],COLOR_PAIR(1)|A_BOLD);     
       }  
       mvwprintw(ventana[6],i,j,"%c",buffer[i+desp][j].c);
     }
     else {  /* estamos fuera del area de texto */
       wattrset(ventana[6],COLOR_PAIR(7)|A_BOLD);     
       mvwprintw(ventana[6],i,j,"%c",'.');        
     }  
    }
   }                        
}

void ventana_estado(char *cad)
/*
** Imprime la cadena que pasamos como argumento en la ventana de estado
*/
{
   char tcad[18];

   if (strlen(cad)>17) {
    strncpy(tcad,cad,17);
    tcad[17]=0;
   }
   else strcpy(tcad,cad);
   wprintw(ventana[7],"%s",tcad);
   wrefresh(ventana[7]);
}


void ventana_mensajes(char *cad)
/*
** Imprime la cadena que pasamos como argumento en la ventana de mensajes
*/
{
   char tcad[75];

   if (strlen(cad)>73) {
    strncpy(tcad,cad,73);
    tcad[73]=0;
   }
   else strcpy(tcad,cad);
   wprintw(ventana[5],"%s",tcad);
   wrefresh(ventana[5]);
}


void cambio_pantalla()
/*
** Procedimiento que pasa de la pantalla pequena a la grande y viceversa
*/
{
   delwin(ventana[6]);
   delwin(ventana[2]);
   ventana[2]=newwin(23*(1-tamano)+17*tamano,61,1,0);
   wbkgdset(ventana[2],COLOR_PAIR(3));
   werase(ventana[2]);
   wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);
   box(ventana[2],0,0);
   wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD);
   mvwprintw(ventana[2],0,5,"[ Interprete de comandos ]");
   mvwprintw(ventana[2],0,38,"[ %s ]",nombre);
   mvwprintw(ventana[2],0,56,"[ ]");
   wattrset(ventana[2],COLOR_PAIR(3) | A_BOLD);
   mvwprintw(ventana[2],0,7,"Interprete de comandos");
   mvwprintw(ventana[2],22*(1-tamano)+16*tamano,2,"%c",'O'*(1-insert)+'I'*insert);
   mvwprintw(ventana[2],0,57,"%c",'z'*(1-tamano)+'Z'*tamano);
   ventana[6]=subwin(ventana[2],21*(1-tamano)*15*tamano,59,2,1);
   wattrset(ventana[6],COLOR_PAIR(6) | A_BOLD );
   wattrset(ventana[2],COLOR_PAIR(2) | A_BOLD );
   keypad(ventana[6],TRUE);
   meta(ventana[6],TRUE);
   wnoutrefresh(ventana[2]); 
   if (tamano==1) {
     touchwin(ventana[4]); 
     wnoutrefresh(ventana[4]);
     pos_actual.y=8;
   }
   tamano=(tamano+1)*(1-tamano);
}


void insertar_linea(int linea)
/*
**   Subrutina que inserta una linea en blanco en la linea pasada como
** argumento. La manera de insertar es copiando la linea siguiente a la actual
** en la de abajo suya.
*/
{
  int i,j;
  
  for (i=LINEAS-1;i>=linea+desp+1;i--) {     
   for (j=0;j<=58;j++) {
    buffer[i+1][j]=buffer[i][j];
   }
  }
  for (j=0;j<=58;j++) {
    buffer[linea+desp+1][j]=blanco;
  }
  i=0;  
  for (j=pos_actual.x;j<=58;j++) {     
    buffer[linea+desp+1][i++]=buffer[linea+desp][j];
    buffer[linea+desp][j]=blanco;
  }    
}
 
void borrar_linea(int linea)
/*
**   Subrutina que borra una linea. Borra la linea  desplazando todo el 
** buffer una posicion hacia arriba (empezando en la linea que se le pasa
** como argumento)   
*/
{ 
  int i,j;
 
  for (i=linea+desp;i<=LINEAS;i++) {     
   for (j=0;j<=58;j++) {
    if (i<=LINEAS-1) buffer[i][j]=buffer[i+1][j];
    else buffer[i][j]=blanco;
   }
  } 
}


int linea_en_blanco(int linea)
/*
**   Subrutina que revisa que una linea este en blanco, los espacios y
** los indicadores de retorno de carro se consideran como nulos
** Devuelve un 1 si esta vacia y un 0 si esta llena
*/
{
   int i;
   
   for (i=0;i<=58;i++) {
     switch (buffer[linea+desp][i].c) {
       case '\n':break;
       case ' ' :break;
       default  : return 0;
     }
   }
   return 1;
}


int poner_al_final(int linea)
/*
**   Subrutina que me indica la posicion del ultimo caracter del texto 
** situado en la linea pasada como argumento 
*/
{
   int temp;
   temp=59;
   do {  
     temp=temp-1;
   } while (buffer[linea+desp][temp].c==' ' &&
            temp>=1) ;              
   if (temp==58) return temp;
   else return ++temp;
}


void ejecuta_sup()
/*
**   Opcion suprimir, borra el caracter de la posicion actual y desplaza
** los siguientes una posicion hacia la izquierda. Si la linea esta en 
** blanco realiza un scroll hacia arriba
*/
{
  int i,j=0,final;
  
  final=poner_al_final(pos_actual.y);
  if (final<=pos_actual.x) {
    for (i=pos_actual.x;i<=58;i++) { /* subo la linea de abajo */
     buffer[pos_actual.y+desp][i]=buffer[pos_actual.y+1+desp][j++];
    }
    for (i=0;i<=58-j;i++) { /* borro los caracteres subidos */
     buffer[pos_actual.y+1+desp][i]=buffer[pos_actual.y+1+desp][j+i];
    }     
    for (j=i;j<=58;j++) { /* los caracteres desplazados de abajo los borro */
     buffer[pos_actual.y+1+desp][j]=blanco;
    }
    if (linea_en_blanco(pos_actual.y+1)==1) {  /* si la linea de abajo esta */
      borrar_linea(pos_actual.y+1);          /* en blanco la  borro */  
      if (pos_actual.y<b_inicio.y) {  /* desplazamos el indicador de bloque */
        b_inicio.y--; b_final.y--;
      }
    }                                      
  }
  else {
   if (linea_en_blanco(pos_actual.y)==1) {
      borrar_linea(pos_actual.y);
   }
   else {
     for (i=pos_actual.x;i<=57;i++) {
      buffer[pos_actual.y+desp][i]=buffer[pos_actual.y+desp][i+1];
      wattrset(ventana[6],buffer[pos_actual.y+desp][i].color);     
      mvwprintw(ventana[6],pos_actual.y,i,"%c",buffer[pos_actual.y+desp][i].c);
     }  
     buffer[pos_actual.y+desp][58]=blanco;
     wattrset(ventana[6],buffer[pos_actual.y+desp][58].color);          
     mvwprintw(ventana[6],pos_actual.y,58,"%c",buffer[pos_actual.y+desp][58].c);
  }
 } 
}

void desplaza_buffer(int cantidad)
/*
**   Desplaza el buffer la cantidad de lineas pasada como argumento ,
**  ademas refresca la pantalla visual
*/
{

  if ( desp+cantidad>=0 && desp+cantidad<=LINEAS ) {  
      desp=desp+cantidad;
      return;
  }
  if ( desp+cantidad<=-7) { 
    pos_actual.y=0 ;desp=0; 
    return;
  }
  if ( desp+cantidad<=-1) {
    pos_actual.y=pos_actual.y+desp+cantidad; desp=0;
    return;
  }
}



void ejecuta_del()
/*
***********************************************************************
   Subrutina que procesa el comando DEL. Este consiste en borrar el
  caracter situado a la izquierda del cursor. Si estamos al principio
  de una linea se produce un scroll hacia arriba.
************************************************************************
*/
{
  struct posicion pos_temp;
  int i,j,k,temp;
  
  if (pos_actual.x-1>=0) {  /* El cursor esta en medio de una linea */
   for (i=pos_actual.x-1;i<=57;i++) {
    buffer[pos_actual.y+desp][i]=buffer[pos_actual.y+desp][i+1];
    wattrset(ventana[6],buffer[pos_actual.y+desp][i].color);     
    mvwprintw(ventana[6],pos_actual.y,i,"%c",buffer[pos_actual.y+desp][i].c);
   }  
   buffer[pos_actual.y+desp][58]=blanco;
   wattrset(ventana[6],buffer[pos_actual.y+desp][58].color);     
   mvwprintw(ventana[6],pos_actual.y,58,"%c",buffer[pos_actual.y+desp][58].c);
   pos_actual.x=pos_actual.x-1;
  }
  else { /* El cursor esta al principio de la linea */
   if (pos_actual.y-1>=0) {   /* situamos la linea primero */
     pos_actual.y=pos_actual.y-1; }  
   else {
     pos_actual.y=7*(1-tamano)+10*tamano;
     desplaza_buffer(8*(tamano-1)-11*tamano); 
   }   
   /* utilizamos variables auxiliares */
    
   pos_temp.y=pos_actual.y;
   pos_temp.x=poner_al_final(pos_temp.y);  
   temp=pos_temp.x;   

   /* desplazamos lo que quede de fila a la fila superior */

   for (j=pos_temp.x;j<=58;j++) {
    buffer[pos_temp.y+desp][j]=buffer[pos_temp.y+1+desp][0];
    for (k=0;k<=58;k++) {
     if (k<=57) buffer[pos_temp.y+1+desp][k]=buffer[pos_temp.y+1+desp][k+1];
     else buffer[pos_temp.y+1+desp][k]=blanco;
    }
   }                        
   pos_actual.x=temp;

   if (linea_en_blanco(pos_temp.y+1)==1) {   /* si la linea esta en blanco */
     borrar_linea(pos_temp.y+1);             /* la borramos                */
     if (pos_actual.y<b_inicio.y) {  /* desplazamos el indicador de bloque */
       b_inicio.y--; b_final.y--;
     }
   }
  } 
}


void inserta_caracter(struct posicion pos, struct caracter car)
/*
**   Inserta el caracter 'car' en la posicion 'pos' de la linea 'lin'
**   No se produce sobreescritura  
*/
{
   int i,final;
   struct caracter tcar;
   struct posicion tpos;
    
   final=poner_al_final(pos.y);

   if (final<=57) { 
     for (i=final;i>=pos.x;i--) {
       if (i!=0) buffer[pos.y+desp][i]=buffer[pos.y+desp][i-1];
     } 
     buffer[pos.y+desp][pos.x]=car;
     return;
   }

   tcar=buffer[pos.y+desp][58];
   for (i=58;i>=pos.x;i--) {
     buffer[pos.y+desp][i]=buffer[pos.y+desp][i-1];
   } 
   buffer[pos.y+desp][pos.x]=car;
   if (pos.y+desp<=LINEAS) {
     tpos.x=0;
     tpos.y=pos.y+1; 
     inserta_caracter(tpos,tcar);
   }
}


void ejecutar_copiar_bloque()
/* copia el bloque marcado en la linea actual */
{
   int i,j,k;

   pos_actual.x=0;
  
   if ((bloque==1) && (pos_actual.y+desp<=b_inicio.y))  {                      
    for (i=b_inicio.y,j=0;i<=b_final.y;i++,j++) {
     insertar_linea(pos_actual.y);
     for (k=0;k<=58;k++) {
       buffer[pos_actual.y+desp][k]=buffer[b_final.y+1][k];
     }
    } 
    if ( (b_inicio.y+j<=LINEAS) && (b_final.y+j<=LINEAS)) {
     b_inicio.y=b_inicio.y+j;
     b_final.y=b_final.y+j;
    }
   }

   if ((bloque==1) && (pos_actual.y+desp>b_final.y))  {                      
    for (i=b_inicio.y,j=0;i<=b_final.y;i++,j++) {
     insertar_linea(pos_actual.y);
     for (k=0;k<=58;k++) {
       buffer[pos_actual.y+desp][k]=buffer[b_final.y-j][k];
     }
    } 
   }   
} 


void ejecutar_borrar_bloque()
/* borra el bloque seleccionado */
{
  if (bloque==1) {  	
    do {
      borrar_linea(b_inicio.y-desp);
    } while (b_inicio.y<b_final.y--);
    bloque=0;
   }
}

/****************************************************************************
 *   SUBRUTINAS DE PROCESAMIENTO DE FICHEROS                                *
 ***************************************************************************/

int grabar_fichero(char cad[],int flag)
/*
**   grabamos el buffer en un fichero de texto, cuyo nombre se indica como
** argumento, por defecto se pone 'nuevo.pru'.
**  El argumento 'i' indica si chequeamos o no la existencia del fichero
*/
{
   char tcad[13];
   char texto[40];
      
   char enter='\n';
   int  n,i,j;
  
   strcpy(tcad,"nuevo.pru");

   if (!strlen(cad)==0) {
     if (strlen(cad)>12) {
      strncpy(tcad,cad,12);
      tcad[12]=0;
     }
     else strcpy(tcad,cad);
   }

   if (flag==TRUE ) {  /* chequeamos la existencia del fichero */
     fd=open(tcad,O_WRONLY | O_CREAT | O_EXCL | O_TRUNC , MODE644);
     if (errno==17) {  
       sprintf(texto,"El fichero '%s' ya existe.",tcad);
       if (!confirmar(texto,"Grabar encima? ") ) {
        wprintw(ventana[5],"\nNo se ha grabado el fichero.");
        wrefresh(ventana[5]);
        return 0;
       }
     }
   }

   /* grabamos a pesar de la existencia previa del fichero */

   fd=open(tcad,O_WRONLY | O_CREAT | O_TRUNC , MODE644);
      
   if (fd==-1) {  /* error al abrir el fichero */
      wprintw(ventana[5],"\nError %s",strerror(errno));
      wrefresh(ventana[5]);
      return 0;
   }  
   
   for (i=0;i<=LINEAS;i++) {
     for (j=0;j<=58;j++) {
       n=write(fd,&(buffer[i][j].c),1);
       if (n==-1) { /* error al escribir en el fichero */
         wprintw(ventana[5],"\nError %s",strerror(errno));       
         wrefresh(ventana[5]);
         return 0;
       }     
     }
     n=write(fd,&enter,1);
   }
   close(fd);

   /* ponemos el nombre del fichero en pantalla */

   wprintw(ventana[5],"\nPrograma grabado en '%s' ",tcad);
   wnoutrefresh(ventana[5]);

   wmove(ventana[2],0,38);
   whline(ventana[2],0,18);
   wprintw(ventana[2],"[ %s ]",tcad);
   wnoutrefresh(ventana[2]);
   doupdate();
   
   return 1;
}

int cargar_fichero(char cad[])
/*
**   rutina que carga el fichero cuyo nombre se pasa como argumento 
**  por defecto se llama 'nuevo.pru'
*/
{
   struct caracter car;
   char tcad[13];
   int n,i,j;

   strcpy(tcad,"nuevo.pru");

   if (!strlen(cad)==0) {
     if (strlen(cad)>12) {
      strncpy(tcad,cad,12);
      tcad[12]=0;
     }
     else strcpy(tcad,cad);
   }

   fd=open(tcad,O_RDONLY);
   
   if (fd==-1) {  /* error al abrir el fichero */
      wprintw(ventana[5],"\nError %s",strerror(errno));
      wrefresh(ventana[5]);      
      return 0;
   }  

   for (i=0;i<=LINEAS;i++) {  /* borramos el anterior fichero */
     for (j=0;j<=58;j++) {
       buffer[i][j]=blanco;
     }
   }        

   i=0;j=0;
   do {
       n=read(fd,&(buffer[i][j].c),1);
       if (n==-1) { /* error al leer del fichero */
         wprintw(ventana[5],"\nError %s",strerror(errno));
         wrefresh(ventana[5]);
         return 0; 
       }  
       car=buffer[i][j];
       car.color=COLOR_PAIR(2)|A_BOLD;
       if ((car.c>=48) && (car.c<=57))  car.color=COLOR_PAIR(5)|A_BOLD;
       if ((car.c>=65) && (car.c<=90))  car.color=COLOR_PAIR(6)|A_BOLD;
       if ((car.c>=97) && (car.c<=122)) car.color=COLOR_PAIR(6)|A_BOLD;   
       buffer[i][j].color=car.color;   

       if (buffer[i][j].c=='\n') {
         buffer[i][j].c=' ';  /* borra el retorno de carro */
         j=j-1;               
         if (j!=-1) i++;
         j=-1;
       }
       if (j>=58) { /* salto a la linea siguiente */
         j=0; 
         i++;
        }
       else {       /* caracter siguiente */ 
         j++;
       }
   } while (i<=LINEAS);   /*@ falta detectar el EOF */

   
   /* ponemos el nombre del fichero en pantalla */

   wmove(ventana[2],0,38);
   whline(ventana[2],0,18);
   wprintw(ventana[2],"[ %s ]",tcad);
   wnoutrefresh(ventana[2]);
   
   /* actualizamos la pantalla con los nuevos datos */
   
   pinta_pantalla_texto();
   wnoutrefresh(ventana[6]);
   touchwin(ventana[4]);
   wnoutrefresh(ventana[4]);
   wprintw(ventana[5],"\nPrograma '%s' cargado. ",tcad);
   wnoutrefresh(ventana[5]);
   doupdate();
   close(fd);   
   return 1;
}

/****************************************************************************
*  EJECUCION DE LOS OTROS MODULOS DEL PROGRAMA:                             *
*  PRUEBA: es un programa de control de la tarjeta desde el teclado del PC  *
*  EJECUTAR: Ejecuta el programa realizado en el editor                     *
*  HELP: Pantalla de ayuda de las teclas del interprete                     *

****************************************************************************/

void ejecutar_programa()
/*
** realiza el analisis lexico, sintactico, semantico y ejecuta
*/
{
  int error;
  lista_sentencias *ls;
  int fd;                 /* Descriptor del fichero */
  int linea;
  char tcad[13];
  
  strcpy(tcad,nombre);

  grabar_fichero("temp.pru",FALSE);

  wmove(ventana[2],0,38);
  whline(ventana[2],0,18);
  wprintw(ventana[2],"[ %s ]",nombre);
  wnoutrefresh(ventana[2]);
  werase(ventana[5]);
  wnoutrefresh(ventana[5]);
  doupdate();

  fd=open("temp.pru",O_RDONLY);
   
  if (fd==-1) {  /* error al abrir el fichero */
    wprintw(ventana[5],"Error %s\n",strerror(errno));
    return;
  }  

  wprintw(ventana[5],"Analisis sintactico..");
  ls=crear_ast(fd,&error);
  close(fd);
  
  if (error) {  /* error en el sintactico */
    linea=get_linea_error();
    wprintw(ventana[5],"\nError en linea %u!! %s\n",linea,getsin_error());
    wrefresh(ventana[5]); 
    return;
  }
  wprintw(ventana[5],"OK!\n");
  wprintw(ventana[5],"Analisis semantico..");
  verificar_ast(ls,&error);

  if (error) {
    linea=get_sem_linea_error();
    wprintw(ventana[5],"\nError en linea %u!! %s\n",linea,getsem_error());
    wrefresh(ventana[5]);
    free(ls);
    return;
  }
  wprintw(ventana[5],"OK!\n");  
    
  check_conexion();
  if (!hay_conexion()) {
    if (!cargar_ctserver(TRUE)) {
      wprintw(ventana[5],"Error: no hay conexion con la CT6811");
      wrefresh(ventana[5]);
      free(ls);
      return;  
    }  
  }  
  
  wprintw(ventana[5],"Interpretando...\n");
  wnoutrefresh(ventana[5]);
  doupdate();
  
  interpreta_ast(ls);

  wprintw(ventana[5],"OK!");  
  wrefresh(ventana[5]);
  free(ls);      
}


int pedir_nombre(char cad[],char titulo[])
/*
** Pide un nombre y lo devuelve en la cadena 'cad'
** devuelve '0' si se a cancelado la entrada
** devuelve '1' si es correcta la entrada de datos
*/
{
   int  flag,err;
   char tcad[13];   
   char c;

   ventana[9]=newwin(4,50,7,9);
   wbkgdset(ventana[9],COLOR_PAIR(4));
   wattrset(ventana[9],COLOR_PAIR(4));
   werase(ventana[9]);
   box(ventana[9],0,0);
   mvwprintw(ventana[9],0,16,"[ %s ]",titulo);
   mvwprintw(ventana[9],2,2,"Introducir nombre archivo: ");
   wattrset(ventana[9],COLOR_PAIR(5));
   mvwprintw(ventana[9],2,29,"                ");
   wattrset(ventana[9],COLOR_PAIR(5)|A_REVERSE);
   mvwprintw(ventana[9],2,29,"%s",cad); 
   wrefresh(ventana[9]);
   c=wgetch(ventana[9]);

   if (c=='\n') { /* aceptamos nombre por defecto */
     flag=1;
   }
   else { /* queremos otro nombre para el archivo */
    wattrset(ventana[9],COLOR_PAIR(5)|A_BOLD);
    mvwprintw(ventana[9],2,29,"                ");
    wmove(ventana[9],2,29); 
    wrefresh(ventana[9]);
               
    /* acepta una cadena de 13 caracteres formados por A-Z, a-z,
       '.' '_' '-' y los almacena en tcad */

    echo();
    noraw();      
    err=wscanw(ventana[9],"%13[A-Za-z._0-9-]s",tcad) ;  
    raw();
    noecho();

    if (err<=0 || strlen(tcad)==0 ) {
     flag=0;
    }
    else {
     strcpy(cad,tcad);                
     wmove(ventana[9],2,29);          
     wprintw(ventana[9],"%s",cad);
     wnoutrefresh(ventana[9]);
     flag=1; /* el nombre esta bien introducido */
    }
  }  
  delwin(ventana[9]);   
  return flag;
}


int confirmar(char cad1[],char cad2[])
/*
** Procedimiento que pide confirmacion, devuelve un 1 si se acepta o 
** un '0' si se rechaza.
** los argumentos 'cad1' y 'cad2' sirven para colocar texto en las dos
** primeras lineas
*/
{
  char c;
  int i=0;
  
  ventana[9]=newwin(6,50,7,9);
  wbkgdset(ventana[9],COLOR_PAIR(4));
  wattrset(ventana[9],COLOR_PAIR(4));
  werase(ventana[9]);
  box(ventana[9],0,0);
  mvwprintw(ventana[9],0,16,"[ Advertencia ]");
  mvwprintw(ventana[9],2,8,"%s",cad1);
  wattrset(ventana[9],COLOR_PAIR(8));
  mvwprintw(ventana[9],4,13,"%s",cad2); 
  mvwprintw(ventana[9],4,33,"No");     
  wattrset(ventana[9],COLOR_PAIR(4));
  mvwprintw(ventana[9],4,29,"Si");
  wrefresh(ventana[9]);
     
  /* chequeamos la respuesta */

  do {
   c=wgetch(ventana[9]);
   switch (c) {
    case '\n': delwin(ventana[9]);
               if (i==1) 
               return 0; /* hemos pulsado el 'NO' */
               return 1; /* hemos pulsado el 'SI' */
    case '\t': wattrset(ventana[9],COLOR_PAIR(8)*i+COLOR_PAIR(4)*(1-i));
               mvwprintw(ventana[9],4,33,"No");     
               wattrset(ventana[9],COLOR_PAIR(4)*i+COLOR_PAIR(8)*(1-i));
               mvwprintw(ventana[9],4,29,"Si"); 
               i=(1-i)*(i+1);
               break;  
    case 'n' :
    case 'N' : delwin(ventana[9]);return 0;
    case 's' :
    case 'S' : delwin(ventana[9]);return 1;
    default  : break;      
   }
  } while (TRUE);
}

/***********************************************************************
*   FUNCIONES DE PROCESAMIENTO DE LAS TECLAS                           *
***********************************************************************/

void tecla_normal(char c)
/*
**    Se ha introducido una tecla normal de texto, la imprimimos en la 
**  pantalla y segun este o no activo el modo INSERT habra desplazamiento
*/
{
   struct caracter car;

   car.color=COLOR_PAIR(2)|A_BOLD;
   if ((c>=48) && (c<=57))  car.color=COLOR_PAIR(5)|A_BOLD;
   if ((c>=65) && (c<=90))  car.color=COLOR_PAIR(6)|A_BOLD;
   if ((c>=97) && (c<=122)) car.color=COLOR_PAIR(6)|A_BOLD;   
   car.c=c;

   if (pos_actual.y+desp>LINEAS) return; /* estoy fuera del rango */      
   if (insert==0) {  /* insert off, sobreescribo */
     buffer[pos_actual.y+desp][pos_actual.x]=car;
   }
   else {  /* insert ON, desplazamos */
     inserta_caracter(pos_actual,car);   
   }
   
   /* insertar aqui el analisis lexico para detectar los comandos */

   if (pos_actual.x+1<=ANCHO) {
     pos_actual.x=pos_actual.x+1;
   }
   else {
     pos_actual.x=0;
     if (pos_actual.y+1<=(14*(1-tamano)+20*tamano)) {
       pos_actual.y=pos_actual.y+1;}
     else {
       pos_actual.y=8*(1-tamano)+11*tamano; 
       desplaza_buffer(7*(1-tamano)+10*tamano);}
   }
}


int tecla_especial(int c) 
/*
**  Subrutina que detecta cual de las teclas especiales ha sido pulsada y
** pasa a ejecutar la accion pertinente
*/
{
  char tnombre[13];
  int i=0,j=0;
  
  strcpy(tnombre,nombre);  /* tnombre = nombre */
  switch(c) {
   case 260: /* retrocede cursor */
             if (pos_actual.x-1>=0) {      	
               pos_actual.x=pos_actual.x-1;
             }
             else {
              if (pos_actual.y-1>=0) {
                pos_actual.y=pos_actual.y-1;
              }
              else {
                pos_actual.y=8*(1-tamano)+11*tamano;
                desplaza_buffer(7*(tamano-1)-10*tamano); 
              }
              pos_actual.x=poner_al_final(pos_actual.y);
             }
             break;
   case 261: /* avanza cursor */
             if (pos_actual.x+1<=ANCHO) {      	
              pos_actual.x=pos_actual.x+1;
             }
             else {
              pos_actual.x=0;
              if (pos_actual.y+1<=(14*(1-tamano)+20*tamano)) {
               pos_actual.y=pos_actual.y+1;}
              else {
               pos_actual.y=0;
               desplaza_buffer(7*(1-tamano)+10*tamano);}
             }
             break;
   case 259: /* sube cursor */ 
             if (pos_actual.y-1>=0) {      	
              pos_actual.y=pos_actual.y-1;
             }
             else {
              pos_actual.y=7*(1-tamano)+10*tamano;
              desplaza_buffer(8*(tamano-1)-11*tamano);
             }
             break;
   case 258: /* baja cursor */
             if (pos_actual.y+1<=(14*(1-tamano)+20*tamano)) {      	
              pos_actual.y=pos_actual.y+1;
             }
             else {
              pos_actual.y=8*(1-tamano)+11*tamano;
              desplaza_buffer(7*(1-tamano)+10*tamano);
             }
             break;
   case 266: /* F2: grabar fichero */
             if(pedir_nombre(tnombre,"Grabar fichero")==0) break;
             leaveok(ventana[6],TRUE);  
             touchwin(ventana[4]);      
             wrefresh(ventana[4]);    /* no quitar es necesario */
             if (grabar_fichero(tnombre,TRUE)==1) {strcpy(nombre,tnombre);}      
             while (!kbhit());  /* espera a pulsar una tecla */
             wgetch(ventana[6]);
             werase(ventana[5]);
             wnoutrefresh(ventana[5]);
             touchwin(ventana[2]);
             wnoutrefresh(ventana[2]);
             leaveok(ventana[6],FALSE);
             break;
   case 267: /* F3: cargar fichero */ 
             if (pedir_nombre(tnombre,"Cargar fichero")==0) break;   
             leaveok(ventana[6],TRUE); 
             touchwin(ventana[4]);      
             wrefresh(ventana[4]);    /* no quitar es necesario */
             if (cargar_fichero(tnombre)==1) {strcpy(nombre,tnombre);}      
             while (!kbhit());  /* espera a pulsar una tecla */
             wgetch(ventana[6]);
             werase(ventana[5]);
             wnoutrefresh(ventana[5]);
             touchwin(ventana[2]);
             wnoutrefresh(ventana[2]);
             leaveok(ventana[6],FALSE);
             break;             
   case 268: /* F4: borra el actual programa */
             leaveok(ventana[6],TRUE);
             if (confirmar("El programa actual se va a borrar","Desea borrar?")) {
              for (i=0;i<=LINEAS;i++) {     
               for (j=0;j<=58;j++) {
                buffer[i][j]=blanco;
               }
              }        
             }
             leaveok(ventana[6],FALSE);
             break;
   case 269: /* F5: ejecuta el programa */
             leaveok(ventana[6],TRUE); /* quita el cursor */
      	     touchwin(ventana[4]); 
             wrefresh(ventana[4]);     /* no quitar es necesario */
             werase(ventana[7]);
             ejecutar_programa();      
             while (!kbhit());   /* espera a pulsar una tecla */
             wgetch(ventana[6]);
             werase(ventana[5]);
             wnoutrefresh(ventana[5]);
             touchwin(ventana[2]);
             wnoutrefresh(ventana[2]);
             leaveok(ventana[6],FALSE); /* deja el cursor */
             break;
   case 274: /* F10: salir del programa */
             return 0; break ;         
   case 262: /* INICIO */
             pos_actual.x=-1;    
             do {
              pos_actual.x=pos_actual.x+1;
             } while (buffer[pos_actual.y+desp][pos_actual.x].c==' ' &&
                      pos_actual.x<=57) ;
             if ( pos_actual.x>=58 ) pos_actual.x=0;         
             break;       
   case 330: /* SUPR */
             ejecuta_sup(); 
             break;              
   case 263: /* DEL */
             ejecuta_del();   
             break;              
   case 360: pos_actual.x=poner_al_final(pos_actual.y);  /* FIN */
             break;    
   case 339:  /* Page UP */
             desplaza_buffer((15*(tamano-1)-21*tamano));
             break;
   case 338:  /* Page DOWN */
             desplaza_buffer(15*(1-tamano)+21*tamano);
             break;              
   case 331:  /* INSERT */
      	     wattrset(ventana[2],COLOR_PAIR(3)|A_BOLD);
             if (insert==0 ) {  /* insert ON */
              mvwprintw(ventana[2],16*(1-tamano)+22*tamano,2,"I");
              insert=1;
             }
             else {   /* insert OFF */
              mvwprintw(ventana[2],16*(1-tamano)+22*tamano,2,"O");     
              insert=0;
             }
       	     wattrset(ventana[2],COLOR_PAIR(2)|A_BOLD);
             break;
   default : wprintw(ventana[7],"\nEspecial %i ",c);
             wrefresh(ventana[7]);
             break;   
  }
  return 1;
}


void procesar_alt_tecla()
/*
** se encarga de procesar la tecla ALT, al pulsarla se introduce un caracter 
** especial detectado en 'procesar tecla' y ahora analizamos el resto que 
** se corresponde con la letra pulsada despues de 'alt'.
**  La variable estatica 'flag' se utiliza para saber si se debe o no marcar
** el bloque seleccionado
*/
{
  static int flag=1;
  int c;
  
  c=wgetch(ventana[6]);
  switch (c) {                                        
    case 'b' : /* principio bloque */
               b_inicio.y=pos_actual.y+desp;
               bloque=1;flag=1; 
               break;
    case 'k' : /* final bloque */
               b_final.y=pos_actual.y+desp;
               if (flag==0) {flag=1; bloque=0;}
               else  {flag=0; bloque=1;}
               break;
    case 'd' : /* borrar bloque */
               ejecutar_borrar_bloque();
               break;
    case 'c' : /* copiar bloque */
               ejecutar_copiar_bloque();
               break;
    case 'm' : /* mover bloque */
               ejecutar_copiar_bloque();
               ejecutar_borrar_bloque();
               break;
    case 'z' : /* pantalla grande */
               cambio_pantalla();                       
               break;
    case 'y' : /* ALT-Y : borra linea */  
               if (pos_actual.y<b_inicio.y) {
                 b_inicio.y--; b_final.y--;
               }
               borrar_linea(pos_actual.y);
               break;
     default:
               beep();
               break;
     }  
}

   
int procesar_tecla()
/*
**  se encarga de leer la tecla, si es una funcion llama a `tecla_especial'
** en caso contrario la procesa, y si es un caracter normal lo inserta en
** la pantalla mediante la funcion 'tecla_normal,
*/
{
 int c;

 if ( kbhit() ) {  
  c=wgetch(ventana[6]);
  if ( has_key(c) ) return tecla_especial(c);  /* tecla especial */
   else {  /* tecla normal */
    switch (c) {                                        
      case '\n' : /* pulsado el enter */
         if ((pos_actual.y<=b_inicio.y) && (b_inicio.y+1<LINEAS)) {
           b_inicio.y++;b_final.y++;
         }
         insertar_linea(pos_actual.y);
         if (pos_actual.y+1<=(14*(1-tamano)+20*tamano)) {
           pos_actual.x=0;
           pos_actual.y=pos_actual.y+1;
         }
         else {
           pos_actual.x=0;
           pos_actual.y=8*(1-tamano)+11*tamano;
           desplaza_buffer(7*(1-tamano)+10*tamano);
         }
         break;
      case '':   /* detectada tecla ALT */
         procesar_alt_tecla();
         break;
      case '\t':  /* pulsado el tab */ 
         tecla_normal(' ');
         tecla_normal(' ');
         tecla_normal(' ');
         break;   
      default:  
         tecla_normal(c);
         break;
   }
  }
 }
 return 1;
}


/****************************************************************************
 *      PROCEDIMIENTO PRINCIPAL. PRINCIPIO DEL PROGRAMA.                    *     
 *                                                                          *
 ****************************************************************************/

int main(int argc,char *argv[])
/*
*************************************************************
*  Procedimiento principal.                                 *
*************************************************************
*/
{    
   int i,j;
   
   puerto=COM2;
   analiza_parametros(argc,argv);

   if (abrir_puerto_serie(puerto)==0) {
    printf ("Error al abrir puerto serie: %s\n\n",getserial_error());
    cerrar_puerto_serie();
    exit(1);
   }  
   baudios(7680);

   cargar_ctserver(FALSE); // indicamos que estamos fuera de las ncurses
   inicia();		   // En inicia se establece el Noecho y raw, luego
        		   // se vuelve a la normalidad


    /* iniciamos las variables */
    
   strcpy(nombre,"nuevo.pru");
   bloque=0;
   tamano=0;
   blanco.c=' ';
   blanco.color=COLOR_PAIR(6)|A_BOLD;

   pos_actual.x=0;
   pos_actual.y=0;
   pos_final=pos_actual; 
   
   for (i=0;i<=LINEAS+SEGURIDAD;i++) { /* Inicializacion del buffer */
     for (j=0;j<=58;j++) {
       buffer[i][j]=blanco;
     }
   }        
   
   /* dibujamos el entorno */

   menu();

   /* iniciamos el teclado */

   keypad(ventana[6],TRUE);
   meta(ventana[6],TRUE);

   /* Bucle principal */

   do {   
//     comprueba_conexion();
     i=16*(1-tamano)+22*tamano;
     mvwprintw(ventana[2],i,4," L:%i -", pos_actual.y+1+desp);
     mvwprintw(ventana[2],i,12," C:%i ", pos_actual.x+1);      
     wnoutrefresh(ventana[2]);
     pinta_pantalla_texto();
     wmove(ventana[6],pos_actual.y,pos_actual.x); 
     wnoutrefresh(ventana[6]);
     doupdate();
   } while ( procesar_tecla() );	

   /* Salida del programa */

   keypad(ventana[6],FALSE);
   meta(ventana[6],FALSE);
   echo();
   noraw();
   endwin();
   clrscr();   
   printf("Fin de programa\n") ;
   cerrar_puerto_serie();
   return 0;
}                     

