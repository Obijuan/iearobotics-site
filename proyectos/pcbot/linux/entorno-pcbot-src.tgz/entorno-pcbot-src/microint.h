
int interpreta_ast(lista_sentencias *ls);

