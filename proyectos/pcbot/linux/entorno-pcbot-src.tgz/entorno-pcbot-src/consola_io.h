/*****************************************************************************/
/* consola_io.c    MICROBOTICA, S.L     GPL      Octubre-2000                */
/*---------------------------------------------------------------------------*/
/* Prototipos y definiciones del modulo consola_io.c                         */
/*****************************************************************************/

#ifndef _CONSOLA_IO_H
#define _CONSOLA_IO_H

#define ESC 27

/*-----------------*/
/*   PROTOTIPOS    */
/*-----------------*/

int abrir_consola(void);
void cerrar_consola(void);
int kbhit(void);
//char getch();


#endif


