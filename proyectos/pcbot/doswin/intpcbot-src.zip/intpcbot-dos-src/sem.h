/************************************************************************/
/* SEM.H   (c) MICROBOTICA, S.L        Diciembre 1998.                  */
/*----------------------------------------------------------------------*/
/* Estructuras de datos e interfaz del modulo SEM.C                     */
/************************************************************************/

#define MAXENTRADAS 8    /* Numero de entradas digitales de PC-BOT */
#define MAXSALIDAS  8    /* Numero de salidas digitales de PC-BOT  */
#define MAXMOTORS   4    /* Numero de motores en PC-BOT            */

/* ------------------- ESTRUCTURAS DE DATOS ---------------------------*/

/* -------------------------- INTERFAZ ------------------------------ */

extern void verificar_ast(lista_sentencias *,int *);
/*********************************************/
/* Realizar el analisis semantico            */
/*********************************************/

extern char *getsem_error();
/*****************************************************************/
/* Devolver la cadena de error del ultimo error producido.       */
/*****************************************************************/

extern int get_num_sem_error();
/***********************************/
/*  Devolver el numero de error    */
/***********************************/

extern int get_sem_linea_error();
/***************************************************/
/*  Devolver linea donde se ha producido el error  */
/***************************************************/
