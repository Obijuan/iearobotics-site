/*********************************************************************/
/* INT.H   (c) Microbotica, S.L            Diciembre 1998            */
/*-------------------------------------------------------------------*/
/* Definiciones y estructuras de datos del modulo interprete.        */
/*********************************************************************/

extern char *getint_error();
extern int get_num_int_error();
extern int get_int_linea_error();
extern int interpreta_ast(lista_sentencias *ls);

