intpcbot -com2 %1
