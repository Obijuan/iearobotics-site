Para probar:

1) Alimente PCBOT y conectelo al PC
2) ejecute: pcbot test.bot

(Configure adecuadamente el puerto serie en el fichero pcbot.bat)

