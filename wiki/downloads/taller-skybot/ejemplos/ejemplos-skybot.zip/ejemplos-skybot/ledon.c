/*************************************************************************** */
/* hola_mundo.c                                                              */
/*---------------------------------------------------------------------------*/
/* Ejemplo para la tarjeta SKYPIC                                            */
/*---------------------------------------------------------------------------*/
/* Poner a 1 el bit 1 (RB1) del puerto B. Se enciende el led de la Skypic    */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

#include <pic16f876a.h>

//-- Definiciones
#define ENTRADA 1
#define SALIDA  0

//-- El led esta en el bit RB1
#define LED RB1

//-- Definir la etiqueta ON
#define ON   1

void main(void)
{
  //-- Configurar el bit 1 del puerto B para Salida
  TRISB1 = SALIDA;

  //-- Encender el led
  LED = ON;

  //-- Bucle infinito
  while(1);
}

