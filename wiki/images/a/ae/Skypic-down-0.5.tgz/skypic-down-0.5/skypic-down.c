/**************************************************/
/* skypic-down.c      Juan Gonzalez Gomez.        */
/*------------------------------------------------*/
/* Cliente del StarGate PICP                      */
/* Grabaci�n de programas en PICs 16F84           */
/* No se utilizan hilos                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <stargate/stargate.h>

#include "sg-tramas-picp.h"
#include "intelHex.h"

#define DEF_PORT "/dev/ttyS0"

/*-- Tama�o del buffer para la lectura de fichero .hex --*/
#define TAM_BUFFER 1024*8 + 7  + 1
#define COM1 0
#define COM2 1
#define ESC 27

char version[]={"0.4"};
char fecha[]={"Julio 2007"};

/************************/
/* VARIABLES GLOBALES   */
/************************/
int puerto;  // Puerto serie a utilizar
int flag_16f87xa;
char fich_name[80];
char serial_name[255];

//-- Direccion de comienzo de cada bloque
unsigned int bloque_address[5];

//-- Tamano de cada bloque
unsigned int bloque_size[5];

//-- Numero de bloques
unsigned int nbloques=0; 

//-- Salto para llegar a los respectivos bloques desde el bloque anterior
unsigned int bloque_salto[5];


/*****************************/
/*    FUNCIONES              */
/*****************************/

/*************************************************************/
/* Identificar el servidor, imprimiendo el nombre completo.  */
/* Se devuelve el estado de la conexion y la identifiacion   */
/*************************************************************/
int id(byte *server_id)
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is, im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    *server_id=is;
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    *server_id=0;
    break;
  default:
    printf ("[ERROR]\n");
    *server_id=0;
  }

  return status;
}

/**************************************************/
/* Verificar la memoria de un pic contra un       */
/* buffer de memoria                              */
/* -----------------------------------------------*/
/* DEVUELVE:                                      */
/*   0 : Error de verificacion                    */
/*   1 : Verificacion OK                          */
/**************************************************/
int program_verify(unsigned int *buffer, int tam)
{
  int status;
  int i=0;
  int valor;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  }

  //-------- Comenzar la VERIFICACION
  for (i=0; i<tam; i++) {
    status=sg_read_data(&valor);
    if (status==1) {
      if (valor==buffer[i]) {
        printf ("O");
        fflush(stdout);
      }
      else {
        printf ("\nERROR!. Posicion: %x\n",i);
        printf ("Leido: %x\n",valor);
        printf ("Valor correcto: %x\n",buffer[i]);
        return 0;
      }
    }
    else {
      printf ("X\n");
      break;
    }
    //-- Pasar a la siguiente posicion
    status=sg_increment_address();
    if (status!=1) {
      printf ("X\n");
      break;
    }
  }

  printf ("\n");
  if (i==tam) {  //-- Programa correctamente verificado
    return 1;
  }
  else {
    return 0;
  }
 
}

/*****************************************************/
/* Grabar en un pic de la familia 16F8X              */
/*---------------------------------------------------*/
/* DEVUELVE:                                         */
/*   0: Error                                        */
/*   1: OK, aunque no se hace verificacion           */
/*****************************************************/
int program_16f8x(unsigned int *buffer, int tam)
{
  int status;
  int i;

  //-- Comenzar la programacion
  for (i=0; i<tam; i++) {
    status=sg_prog(buffer[i]);
    if (status==1) {
      printf (".");
      fflush(stdout);
    }
    else {
      printf ("X\n");
      break;
    }
    //-- Pasar a la siguiente posicion
    status=sg_increment_address();
    if (status!=1) {
      printf ("X\n");
      break;
    }
  }
  
  printf ("\n");
  if (i==tam) {  //-- Programa grabado
    return 1;
  }
  else {
    return 0;
  }
}



/*****************************************************/
/* Grabar en un pic de la familia 16F8X              */
/*---------------------------------------------------*/
/* DEVUELVE:                                         */
/*   0: Error                                        */
/*   1: OK, aunque no se hace verificacion           */
/* Funcion obsoleta..                                */
/*****************************************************/
int program_16f87xa_old(unsigned int *buffer, int tam)
{
  int status;
  int i=0;
  int valor;
  int base;
  int error=0;

  error=0;
  for (base=0;  base<tam; base+=8) {

    //-- Cargar un bloque de 8 bytes
    for (i=0; i<8; i++) {

      //--Ver si hay que poner caracteres de relleno
      if ((base+i)>tam) valor=0x00;
      else valor=buffer[base+i];

      //-- Enviar valor
      status=sg_load_data(valor);
      if (status==1) {
	      printf (".");
	      fflush(stdout);
      }
      else {
	      printf ("X");
        fflush(stdout);
	      error=1;
	      break;
      }

      //-- Pasar a la siguiente posicion
      //-- Si es el �ltimo valor no se incrementa
      if (i<7) {
	      //-- Pasar a la siguiente posicion
	      status=sg_increment_address();
	      if (status!=1) {
	        printf ("Error...\n");
	        error=1;
	        break;
	      }
      }
    }

    //-- Grabar el bloque
    status=sg_begin_pec();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }

    //-- Apuntar al comienzo de la siguiente posicion a grabar
    status=sg_increment_address();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }
  }
  
  printf ("\n");
  
  if (error) return 0;
  return 1;
}




/*******************************************/
/* Leer la identificacion del pic          */
/*******************************************/
int leer_pic_id()
{
  int status;
  int valor;
  int i;
  
  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 

  //-- Acceder a la memoria de configuracion
  status=sg_load_config();
  if (status!=1) {
    return 0;
  }

  //-- Avanzar hasta la posicion 6
  for (i=0; i<6; i++) {
    status=sg_increment_address();
    if (status!=1) {
      return 0;
    }
  }

  //-- Mostrar el valor actual
  status=sg_read_data(&valor);
  if (status!=1) {
    return 0;
  }
  
  return valor;
}


/***********************************************/
/* Grabar la palabra de configuracion          */
/* (y verificarla)                             */
/*---------------------------------------------*/
/* ENTRADAS:                                   */
/*   config: Valor a grabar                    */
/* DEVUELVE:                                   */
/*    0: Error                                 */
/*    1: OK. Se hace verificacion              */
/***********************************************/
int prog_config(int config)
{
  int status;
  int valor;
  int i;

  //-- Acceder a la memoria de configuracion
  status=sg_load_config();
  if (status!=1) {
    return 0;
  }

  //-- Avanzar hasta la posicion 7
  for (i=0; i<7; i++) {
    status=sg_increment_address();
    if (status!=1) {
      return 0;
    }
  }

  //-- Mostrar el valor actual
  status=sg_read_data(&valor);
  if (status!=1) {
    return 0;
  }
  //printf ("Valor Actual: %x\n",valor);

  //-- Grabar el nuevo valor
  status=sg_prog(config);
  if (status!=1) {
    return 0;
  }

  //-- Leer el valor grabado
  status=sg_read_data(&valor);
  if (status!=1) {
    return 0;
  }
  printf ("Palabra de configuracion grabada: %x\n",valor);
  
  //-- Si lo leido es distinto de lo grabado.. error
  if (config!=valor) return 0;

  return 1;
}

/*******************************************/
/* Establecer la conexion con el StarGate  */
/*-----------------------------------------*/
/* Devuelve:                               */
/*    0 : Error                            */
/*    1 : OK                               */
/*******************************************/
int conexion_servidor()
{
  int status;
  int intentos=0;
  byte is;

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id(&is);
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) return 1;
  else return 0;
}


/***********************************************************/
/* Leer un fichero, meterlo en el buffer y devolver el     */
/* tama�o                                                  */
/*---------------------------------------------------------*/
/* ENTRADAS:                                               */
/*    Descriptor fichero entrada                           */
/* SALIDAS:                                                */
/*    buffer: Contiene el programa leido                   */
/*    tam   : Tama�o (en palabras)                         */
/*    conf  : Valor de la palabra de configuracion         */
/*        Si vale 0xFFFF es que no esta definida           */
/*          en el fichero .hex                             */
/* DEVUELVE:                                               */
/*    0 : Error al procesar fichero .hex                   */
/*    1 : OK                                               */
/***********************************************************/
int leer_fichero_hex(FILE *fich, unsigned int *buffer, int *tam)
{
  int status;
  int i;
  int max,min;

  //--- Poner el buffer a '0'
  for (i=0; i<=TAM_BUFFER; i++) {
    buffer[i]=0;
  }

  //-- Leer el fichero .hex
  status=readihex(fich, buffer, &min, &max,bloque_address, bloque_size, &nbloques);
  if (status!=1) return 0; 

  *tam=max;

  return 1;
}

void print_error(char *cad)
/*******************************/
/* Imprimir cadena de error    */
/*******************************/
{

  printf ("\n  ---> ERROR: %s\n\n",cad);
}

void print_info(char *nombre, int tam)
/********************************************************/
/* Imprimir informacion sobre los parametros actuales   */
/********************************************************/
{
  printf ("Fichero              : %s\n",nombre);
  printf ("Tamano               : %d palabras\n",tam);
}


/***************************/
/* Sacar la ayuda          */
/***************************/
static void help()
{
  printf ("\n");
  printf ("Forma de uso:\n");
  printf ("  skypic_down fichero.hex [-Pdispositivo_serie]\n");
  printf ("\n");
  printf ("Ejemplo: skypic_down ledp.hex -P/dev/ttyS0\n");
  printf ("\n");
}


/******************************/
/* Analizar los parametros    */
/******************************/
static void analizar_parametros(int argc, char ** argv)
{
  //-- Al menos debe haber un parametro
  if (argc<2) {
    printf ("Fichero .hex no especificado\n");
    help();
    exit(1);
  }
  
  //-- Leer nombre del fichero
  strcpy(fich_name,argv[1]);
  
  //-- El siguiente argumento, si lo hay, es el puerto serie
  if (argc>2) {
    strcpy(serial_name,&argv[2][2]);
  }
  else {
    strcpy(serial_name,DEF_PORT);
  }
  
  //-- Indicar que es un PIC16F876A
  flag_16f87xa=1;
}

int verificar_bloque(unsigned int num, unsigned int *buffer)
{
  
  int status;
  int i=0;
  int valor;
  unsigned int addr;
  unsigned int *buffer2;
  unsigned int tam;

  addr=bloque_address[num];
  buffer2 = &(buffer[addr]);
  
  //-- calcular el tamano alineado a 8 palabras
  if ((bloque_size[num]%8)==0) 
    tam = bloque_size[num];
  else
    tam = (bloque_size[num]/8 + 1)*8;

  //-------- Comenzar la VERIFICACION
  for (i=0; i<tam; i++) {
    status=sg_read_data(&valor);
    if (status==1) {
      if (valor==buffer2[i]) {
        printf ("O");
        fflush(stdout);
      }
      else {
        printf ("\nERROR!. Posicion: %x\n",i);
        printf ("Leido: %x\n",valor);
        printf ("Valor correcto: %x\n",buffer2[i]);
        return 0;
      }
    }
    else {
      printf ("X\n");
      break;
    }
    //-- Pasar a la siguiente posicion
    status=sg_increment_address();
    if (status!=1) {
      printf ("X\n");
      break;
    }
  }

  printf ("\n");
  if (i==tam) {  //-- Programa correctamente verificado
    return 1;
  }
  else {
    return 0;
  }
 
  
}


int grabar_bloque(unsigned int num, unsigned int *buffer, int *block8_cont)
{
  int status;
  int i=0;
  int valor;
  int base;
  int error=0;
  int tam;
  unsigned int addr;
  unsigned int *buffer2;

  error=0;
  tam =bloque_size[num];
  addr=bloque_address[num];
  buffer2 = &(buffer[addr]);
  *block8_cont=0;
  
  for (base=0;  base<tam; base+=8) {

    //-- Cargar un bloque de 8 bytes
    for (i=0; i<8; i++) {

      //--Ver si hay que poner caracteres de relleno
      if ((base+i)>tam) valor=0x00;
      else valor=buffer2[base+i];

      //-- Enviar valor
      status=sg_load_data(valor);
      if (status==1) {
	      printf (".");
	      fflush(stdout);
      }
      else {
	      printf ("X");
        fflush(stdout);
	      error=1;
	      break;
      }

      //-- Pasar a la siguiente posicion
      //-- Si es el �ltimo valor no se incrementa
      if (i<7) {
	      //-- Pasar a la siguiente posicion
	      status=sg_increment_address();
	      if (status!=1) {
	        printf ("Error...\n");
	        error=1;
	        break;
	      }
      }
    }

    //-- Grabar el bloque
    status=sg_begin_pec();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }
    
    //-- Aumentar contador de bloques de 8 palabras
    (*block8_cont)++;

    //-- Apuntar al comienzo de la siguiente posicion a grabar
    status=sg_increment_address();
    if (status!=1) {
      printf ("Error...\n");
      error=1;
      break;
    }
  }
  
  printf ("\n");
  
  if (error) return 0;
  return 1;
}


int verificar_16f87xa(unsigned int *buffer)
{
  int status;
  int i;
  int salto=0;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 
  
  for (i=0; i<nbloques; i++) {
    
    //-- Saltar al siguiente bloque
    //-- Si es el primer bloque no hay salto
    if (i==0) {
      salto=0;
    }  
    else {
      status=sg_jump(bloque_salto[i]);
      //printf ("Salto: %X\n",bloque_salto[i]);
      if (status!=1) {
        printf ("Error en jump\n");
        return 0;
      }   
    }
    
    printf ("-->Bloque %d\n",i+1);
    
    //-- Grabar el bloque
    status=verificar_bloque(i,buffer);
    if (status!=1) {
      return 0;
    }
  }
  
  return status;
  
  
}

/******************************************/
/* Grabar PIC16F876A                      */
/******************************************/
int program_16f87xa(unsigned int *buffer)
{
  int status;
  int i;
  int dir_final;
  int b8_count;
  int salto=0;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 
  
  for (i=0; i<nbloques; i++) {
    
    //-- Saltar al siguiente bloque
    //-- Si es el primer bloque no hay salto
    if (i==0) {
      salto=0;
    }  
    else {
      salto=bloque_address[i]-dir_final;
      status=sg_jump(salto);
      
      //-- Guardamos el salto para luego usarlo en la verificacion
      bloque_salto[i]=salto;
      //printf ("Salto: %X\n",salto);
      if (status!=1) {
        printf ("Error en jump\n");
        return 0;
      }   
    }
    
    printf ("-->Bloque %d\n",i+1);
    
    //-- Grabar el bloque
    status=grabar_bloque(i,buffer,&b8_count);
    if (status!=1) {
      printf ("Error al grabar bloque 1\n");
      return 0;
    }
    
    dir_final=bloque_address[i]+b8_count*8;
  }
  
  return status;
}



int test(unsigned int *buffer)
{
  printf ("Frikeo!!!\n");
  int status;
  int b8count;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 
  
  //-- Grabar primer bloque
  status=grabar_bloque(0,buffer,&b8count);
  if (status!=1) {
    printf ("Error al grabar bloque 1\n");
    return 0;
  } 
  
  //-- Hacer un jump de 0x1E80>>3 bloques
  status=sg_jump(0x1E80-8);
  if (status!=1) {
    printf ("Error en jump\n");
    return 0;
  }
  
  //-- Grabar segundo bloque
  status=grabar_bloque(1,buffer,&b8count);
  if (status!=1) {
    printf ("Error al grabar bloque 2\n");
    return 0;
  } 
  
  status=prog_config(0x3F3A);
  if (status!=1) {
    printf ("---> [ERROR]. Grabacion configuracion incorrecta \n\n");
    return 0;
  }
  printf ("OK!!\n");
  
  
  return status;
}

/****************************************************/
/* Grabar en la memoria del pic el programa que se  */
/* encuentra en el buffer.                          */
/*--------------------------------------------------*/
/* DEVUELVE:                                        */
/*   0 : Error                                      */
/*   1 : OK, aunque no se hace verificacion         */
/****************************************************/
int program(unsigned int *buffer, int tam)
{
  int status;

  //-- Hacer RESET
  status=sg_reset();
  if (status!=1) {
    printf ("Error al hacer RESET\n");
    return 0;
  } 

  //-- Seleccionar la forma de programaci�n en funci�n
  //-- del tipo de pic

  if (flag_16f87xa) 
    return program_16f87xa(buffer); //-- Familia 16F87XA
  else 
    return program_16f8x(buffer,tam); //-- Familia 16F8X  
}





/************************/
/* PROGRAMA PRINCIPAL   */
/************************/
int main(int argc, char* argv[])
{
  int serial_fd;  /*-- Descriptor puerto serie */
  int status;
  FILE *fich;
  unsigned int buffer[TAM_BUFFER];
  int tam;
  char cad[80];
  char cad2[80];
  int picid;
  int j;

  analizar_parametros(argc,argv);
  printf ("\n");
  
  printf ("Puerto serie: %s\n",serial_name);

  //-- Abrir el fichero
  fich=fopen(fich_name,"r");
  if (fich==NULL) {
    sprintf (cad,"Fichero: %s no encontrado\n\n",fich_name);
    print_error (cad);
    return 0;
  }

  //-- Leer el buffer
  status = leer_fichero_hex(fich,buffer,&tam);
  if (status!=1) {
    sprintf (cad,"Formato no reconocido. Fichero: %s\n\n",fich_name);
    print_error (cad);
    fclose(fich);
    return 0;
  }
  
  //-- Ya podemos cerrar el fichero.
  fclose(fich);
	
	//printf ("Palabra configuracion: %x\n",buffer[0x2007]);
  
  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(serial_name);
  if (serial_fd==-1) {
    sprintf (cad2,"No se puede abrir puerto serie (%s)\n\n",cad);
    print_error(cad2);
    return 0;
  }

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  sg_tramas_picp_init(serial_fd);
  
  //-- Establecer conexi�n el servidor
  status=conexion_servidor();
  if (status!=1) {
    sprintf (cad,"No se estable conexi�n con el grabador\n\n");
    print_error(cad);
    printf ("Aseg�rese de que est� conectado y correctamente alimentado\n\n");
    return 0;  //-- Terminar
  }

  printf ("Grabador detectado\n");
  print_info(fich_name,tam);
  
  printf ("Numero de bloques: %d\n",nbloques);
  
  for (j=0; j<nbloques; j++) {
    printf ("Bloque %d, Dir: %X, Tam: %d\n",j,bloque_address[j],
                                                bloque_size[j]);
     
  }  
  
  /*----------------------------------------------*/
  /* Comprobar primero que hay un pic conectado.  */
  /* Para ello se lee su identificador            */
  /*----------------------------------------------*/
  picid=leer_pic_id(); 
  printf ("\n");
  
  if (picid==0x3fff) {
    printf ("   ERROR ----> PIC NO DETECTADO.\n");
    close(serial_fd);
    return 0;
  }
  
  printf ("Identificacion pic: %X\n",picid);
  
  /*----------------------------------------------*/
  /* Comienzo de la grabacion                     */
  /*----------------------------------------------*/
  
  printf ("\n");
  printf ("GRABANDO\n");
  //test(buffer);
  //program_16f87xa(buffer);
  //exit(1);
  
 status=program_16f87xa(buffer);
  if (status!=1) {
    sprintf (cad,"No se ha podido realizar la grabaci�n\n\n");
    print_error(cad);
    close(serial_fd);
    return 0;
  }
  
  //exit(1);
  
  /*-------------------------------------------*/
  /* Realizar la verificacion                  */
  /*-------------------------------------------*/
  printf ("\n");
  printf ("VERIFICANDO\n");
  status=verificar_16f87xa(buffer);
  if (status!=1) {
    printf ("---> [ERROR], Verificacion incorrecta\n\n");
    close(serial_fd);
    return 0;
  }
  printf ("PROGRAMA GRABADO CORRECTAMENTE\n\n");
  
  
  /*--------------------------------------------*/
  /* Grabar palabra de configuracion            */
  /*--------------------------------------------*/
  
  //-- Grabar la palabra de configuracion
  
  //-- Para 20MHz: 3F3A / 3F32
  //-- Para 4Mhz: 3F39
  
  status=prog_config(0x3F3A);
  if (status!=1) {
    printf ("---> [ERROR]. Grabacion configuracion incorrecta \n\n");
    close(serial_fd);
    return 0;
  }
  printf ("OK!!\n");

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
