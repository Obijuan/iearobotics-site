/********************************************************/
/* intelHex.c    Alvaro Mar�n <alvaro@rigel.deusto.es>  */
/*------------------------------------------------------*/
/* Cliente del StarGate PICP                      */
/* Grabaci�n de programas en PICs 16F84           */
/* No se utilizan hilos                           */
/*------------------------------------------------*/
/* Licencia GPL                                   */
/**************************************************/

#include "intelHex.h"
#include <string.h>

/************************************************************************/
/* Lectura de un archivo INHX16 o INHX8M, detectandose automaticamente  */
/* el formato.                                                          */
/*----------------------------------------------------------------------*/
/* Entradas:                                                            */
/* Salidas:                                                             */
/*     -mem: Datos del .hex                                             */
/*      -min: Direccion minima de comienzo                              */
/*      -max: Direccion maxima (la mas alta)                            */
/*      -conf: Palabra de configuracion.                                */
/*               Si tiene el valor 0xFFFF es que no se habia especi-    */
/*                ficado ninguna                                        */
/* Devuelve:                                                            */
/************************************************************************/
int readihex(FILE *fp, unsigned int *mem, int *min, int *max)
{
  char  buf[81];
  char  *bptr;
  int   count, addr, cksum, type, x, data, line;
  
  *min = MAXPICSIZE;
  *max = 0;
  line = 0;  
  
  // vamos cogiendo del archivo 81 caracteres hasta EOF
  while( fgets( buf, 81, fp ) != NULL )
  {
    line++;
    
    bptr = buf;
    // Si no es una linea valida para intelHex, continuamos con la sgte linea
    if( *bptr != ':' )
      continue;

    // Comprobamos dos veces si hay presente un CR/LF
    // para eliminarlos
    if( ( buf[strlen(buf)-1] == 0x0D ) || ( buf[strlen(buf)-1] == 0x0A) )
      buf[strlen(buf)-1] = 0x00;
    if( ( buf[strlen(buf)-1] == 0x0D ) || ( buf[strlen(buf)-1] == 0x0A) )
      buf[strlen(buf)-1] = 0x00;
      
    // Cogemos el byte contador para esta linea
    bptr++;
    if( !sscanf( bptr, "%02X", &count ) )
      continue;
      
    // Cogemos la direccion
    bptr += 2;
    if( !sscanf( bptr, "%04X", &addr ) )
      continue;
    
		//-- Si es parte de la memoria de configuracion, no hacer nada...
		if(addr>=0x4000) continue;
		  
      
    if(addr > *max )
      *max = addr;
      
    if( addr < *min )
      *min = addr;
	 	
      
    // Recogemos el tipo de campo
    bptr += 4;
    if( !sscanf( bptr, "%02X", &type ) )
      continue;

    // Es el campo EOF,por lo que salimos
    if( type == 0x01 ) {
      *max=(*max/2);
      *min=(*min/2);
      return 1;
    }

    // -- Cualquier otro tipo que no sea 0x00 lo ignoramos
    if (type!=0x00) continue;

    // Empezamos a calcular el checksum
    cksum = (count & 0xFF);
    cksum += ((addr >> 8) & 0xFF);
    cksum += (addr & 0xFF);
    cksum += (type & 0xFF);

    // Apuntamos al primer byte de datos
    bptr += 2; 
      
    // Si el tama�o del string-11 es count =>INHX8M
    // si es == count => INHX16
    if( (strlen(buf) - 11) == (count * 2) )
    {
      // Procesando una l�nea de INHX8M
      for( x = 0; x < (count/2); x++ )
      {
          if( !sscanf( bptr, "%02X", &data ) )
          continue;
					
					//-- Se trata de un dato normal
					
        mem[(addr/2)+x] = data;
        
        cksum += (data & 0xFF);
        
        bptr += 2;
      
        if( !sscanf( bptr, "%02X", &data ) )
          continue;
          
        mem[(addr/2)+x] += (data << 8);
        
        cksum += (data & 0xFF);
        
        bptr += 2;

				//-- Si no es memoria de configuracion, incrementar la
				//-- Direccion maxima
				if (addr!=0x400E) { 
	        (*max)+=2;
				}	

      }
    } else if( (strlen(buf) - 11) == (count * 4) ) {
      // Procesando INHX16
      for( x = 0; x < count; x++ )
      {
        if( !sscanf( bptr, "%04X", &data ) )
          continue;
          
        mem[addr+x] = data;
        cksum += ((data >> 8) & 0xFF);
        cksum += (data & 0xFF);
        
        bptr += 4;
      }
    } else {
      continue;
    }

    // Procesamos el checksum
    if( !sscanf( bptr, "%02X", &data ) )
      continue;
        
    if( ((-cksum) & 0xFF) != (data & 0xFF) ) {
      printf("Error de checksum en linea %d (%02X != %02X)\n", 
	     line, data & 0xFF, cksum & 0xFF );
      return 0;
    }
  }
  printf ("ERROR, no hay l�nea de terminaci�n\n");
  return 0;
}


/*
	Escritura de un archivo formateado como INHX16
*/
int writeihex16( FILE *fp, unsigned int *mem, int min, int max )
{
  int x, i, cksum;

  x = min; // Direccion de comienzo
  while(1)
  {
    cksum = 0;
    
    if( x + 7 < max ) // podemos sacar una linea de 8
    {
      // Sacamos count, la direccion y el tipo
			fprintf( fp, ":08%04X00", x );
      cksum = 8;
      cksum += (x >> 8) & 0xFF;
      cksum += x & 0xFF;

      // Sacamos las 8 "words" de datos
      for( i = x; i < x+8; i++ )
      {
        fprintf( fp, "%04X", mem[i] );
        cksum += (mem[i] >> 8) & 0xFF;
        cksum += mem[i] & 0xFF;
      }
      x += 8;
    } else {
      fprintf( fp, ":%02X%04X00", max - x, x );
      cksum = (max - x) & 0xFF;
      cksum += (x >> 8) & 0xFF;
      cksum += x & 0xFF;

      
      for( i = x; i <= max; i++ )
      {
        fprintf( fp, "%04X", mem[i] );
        cksum += (mem[i] >> 8) & 0xFF;
        cksum += mem[i] & 0xFF;
      }
      x = max;
    }
    // Sacamos el complemento a 2 del checksum
    fprintf( fp, "%02X\n", (-cksum) & 0xFF );
    
    if( x >= max )
      return 1;
  }
  return 1;
}


/*
	Escritura del final del archivo INHX16
*/
int writeiend16( FILE *fp )
{
  return( fputs( ":00000001FF\n", fp ) );
}
