#include <stdio.h>
#include <unistd.h>

#define flushall() fflush(NULL)

#define NUM_PORTS       10             // N�mero m�ximo de puertos paralelos lp0->lp9
#define MAXPATHLEN      1024           // Longitud m�xima del PATH para los archivos

#define PIC16C84        0							// Tipo de PIC

#define OPT_QUIET       0x0001  // Diferentes modos de operacion
#define OPT_VERIFY      0x0002
#define OPT_DEBUG       0x0004

#define MAXPICSIZE 65535 // Tama�o m�ximo del PIC

// Funciones implementadas en intelHex.c

int readihex( FILE *, unsigned int *, int *, int *);
int writeihex16( FILE *, unsigned int *, int, int );
int writeiend16( FILE * );
