/******************************************************/
/* sg-tramas-picp.h   Juan Gonzalez Gomez.            */
/*----------------------------------------------------*/
/* Definiciones y estructuras de las tramas StarGate  */
/* Licencia GPL                                       */
/******************************************************/

#ifndef SG_TRAMAS_PICP_H
#define SG_TRAMAS_PICP_H


/**********************************/
/* PROTOTIPOS DEL INTERFAZ        */
/**********************************/

/*****************************************************************/
/* Servicio RESET directo al StarGate                            */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_reset();


/************************************************************/
/* Inicializacion del m�dulo sg-tramas_picp                 */
/*----------------------------------------------------------*/
/* Simplemente se establece el descriptor del puerto serie  */
/*                                                          */
/* ENTRADAS:                                                */
/*   fd: Descriptor del puerto serie a usar                 */
/************************************************************/
void sg_tramas_picp_init(int fd);


/*****************************************************************/
/* Servicio READ_DATA directo al StarGate                        */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* SALIDAS:                                                      */
/*    valor: Valor de 14 bits leido                              */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_read_data(int *valor);

/*****************************************************************/
/* Servicio INCREMENT-ADDRESS directo al StarGate                */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_increment_address();

/*****************************************************************/
/* Servicio LOAD CONFIG directo al StarGate                      */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load_config();

/*****************************************************************/
/* Servicio PROG directo al StarGate                             */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_prog(int valor);

/*****************************************************************/
/* Servicio LOAD-DATA directo al StarGate                        */
/*---------------------------------------------------------------*/
/* Se construye la trama se env�a al StarGate y se espera        */
/* la trama de respuesta.                                        */
/*                                                               */
/* ENTRADAS:                                                     */
/*    valor: Valor a almacenar                                   */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_load_data(int valor);

/*****************************************************************/
/* Servicio BEGIN PROGRAM/ERASE CYCLE                            */
/*---------------------------------------------------------------*/
/* Se construye la trama , se env�a al StarGate y se espera      */
/* la trama de respuesta.                                        */
/*                                                               */
/* DEVUELVE:                                                     */
/*   -1 Si ha ocurrido alg�n error                               */
/*    0 Si ha habido un TIMEOUT                                  */
/*    1 OK                                                       */
/*****************************************************************/
int sg_begin_pec();


#endif  // SG_TRAMAS_PICP_H

