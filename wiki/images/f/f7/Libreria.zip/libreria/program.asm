;/---------------------------------------------/
;/ Practicas de ETC-II                    UAM  /
;/ Andres Prieto-Moreno           21-oct-2008  /
;/ ETC-II                                      /
;/                                             /
;/---------------------------------------------/

	
	extrn GetKey:far
	

; SEGMENTO DE DATOS
datosg SEGMENT
	TEXTO	DB 	"Pulse una tecla para salir",13,10,'$'
datosg ENDS

; SEGMENTO DE PILA

stacksg SEGMENT STACK "STACK"
	DB 400H DUP (0)
stacksg ends


; CODIGO DEL PROGRAMA

codesg  SEGMENT
    assume  cs:codesg, DS:datosg, SS:stacksg


;=======================
;= Programa princpal   =                   
;=======================

program  proc far
	; Configuracion inicial de los registros
	MOV  AX,datosg
	MOV  DS,AX

	MOV  AX,stacksg
	MOV  SS,AX
	
	MOV  SP,0400H;

	; imprime mensaje
	MOV DX, OFFSET TEXTO	
	MOV AH,9
	INT 21H
	
    ; espera a que se pulse una tecla
	CALL GetKey


fin:    ; devuelve el control al DOS
    MOV  AX, 4C00H
    INT  21H

program  endp


codesg  ends
		end     program
		

