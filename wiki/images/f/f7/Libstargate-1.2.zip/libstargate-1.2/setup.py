#!/usr/bin/env python

from distutils.core import setup

setup(name         = 'libstargate',
      version      = '1.2',
      description  = 'Libreria para la comunicacion con los servidores stargates',
      author       = 'Juan Gonzalez, Rafael Trevino',
      author_email = 'juan@iearobotics.com>',
      url          = 'http://www.iearobotics.com/wiki/index.php?title=LibStargate',
      packages     = ['libStargate'],
      license      = 'GPL v2 or later',
      data_files   = [('share/man/man3',['man/libstargate.3'])],
      )
