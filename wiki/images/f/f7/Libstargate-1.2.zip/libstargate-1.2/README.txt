Libreria LibIris
----------------


-----------------
INSTALACION
-----------------

Para instalar ejecutar:

  > python setup.py install
  
En Linux hay que ejecutarlo como root o bien usar sudo:

  $ sudo python setup.py install




-----------------------------
ORGANIZACION DE DIRECTORIOS 
-----------------------------

  * debian --> Ficheros de control para empaquetar para Debian/Ubuntu
  * libStargate --> Ficheros python con la libstargate
  * man         --> Paginas man
  * test-generic --> Programas de prueba para el servidor generico
  * test-servos8 --> Programas de prueba para el servidor servos8
  * test-picp    --> Programas de prueba para el servidor picp
  * libIris-utils--> Utilidades incluidas con la libiris
