Format: 1.0
Source: libstargate
Version: 1.2-1
Binary: python-libstargate
Maintainer: Juan Gonzalez <juan@iearobotics.com>
Architecture: any
Standards-Version: 3.7.2
Build-Depends: debhelper (>= 5.0.38)
Build-Depends-Indep: cdbs, python-central, docbook-xsl
Python-Version: all
Files: 
 55094e3a3d93173ada0d26bda860fb53 17377 libstargate_1.2-1.tar.gz
