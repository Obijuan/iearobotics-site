;/---------------------------------------------/
;/ Practicas de ETC-II                    UAM  /
;/ Andres Prieto-Moreno           12-oct-2008  /
;/ ETC-II                                      /
;/                                             /
;/ Programa de Ejemplo del DRVRTC              /
;/  1 - Activa los efectos (lo hace el RTC)    /
;/  2 - Desactiva los efectos                  / 
;/  q - Sale del programa                      /
;/---------------------------------------------/


	extrn IsKey:far
	extrn ClearKeyBuffer:far
	extrn ReadKey:far
	extrn GetKey:far

; SEGMENTO DE PILA
stacksg	SEGMENT STACK "STACK"
		DB 4000H DUP (0)
stacksg	ends


; SEGMENTO DE DATOS
datossg	SEGMENT
		DIR_BASE  DW 0    
datossg	ends


; CODIGO DEL PROGRAMA

codesg	SEGMENT
		assume  cs:codesg, DS:datossg, SS:codesg, ES:datossg


;/***********************************************
;/* Funciones para probar el driver
;/***********************************************

; Efecto ON
; AH=7 ; AL=1 ; INT 61H
efecto_on:
	PUSH AX
	MOV  AH, 7
	MOV  AL, 1
	INT  61H
	POP  DX
	JMP  bucle

; Efecto OFF
; AH=7 ; AL=0 ; INT 61H
efecto_off:
	PUSH AX
	MOV  AH, 7
	MOV  AL, 0
	INT  61H
	POP  AX
	JMP  bucle


;*****************************************
;* Programa princpal                     *
;*****************************************

test_rtc  proc far

	; Configuracion inicial

	MOV  AX, datossg
	MOV  DS, AX
	MOV  ES, AX

	MOV  AX, stacksg
	MOV  SS, AX

	MOV  SP, 04000H
	
	; comprobamos que hay driver
	
	XOR AX,AX
	MOV ES,AX
	MOV AX, ES:[61H*4]
	MOV BX, ES:[61H*4+2]
	ADD AX,BX
	;CMP AX,0
	JE fin
	
	; Comprobacion para rizar el rizo
	; Voy a ver si el codigo maquina del driver es lo que espero que sea
	MOV BX, ES:[61H*4]  ; Offset
	MOV AX, ES:[61H*4+2]; Segmento
	MOV ES,AX
	MOV CX,ES:[BX+3]
	CMP CX,0CAFEH
	JNE fin
		
	; comprobamos que me responde
	MOV AH,0
	INT 61H
	CMP AX,0EE01H
	JNE fin


	; configuracion inicial
	CALL ClearKeyBuffer ; vaciamos el buffer del teclado
   

	; El bucle principal hace lo siguiente
	; Mira por si hemos pulsado una tecla para salir del programa

bucle:
	CALL GetKey
	cmp  AL, '1'
	JE   efecto_on
	cmp  AL, '2'
	JE   efecto_off
	cmp  AL, 'q'
	JE   fin
	JMP  bucle

fin: 
	; vacio buffer teclado
	CALL ClearKeyBuffer

	; salgo del programa
	MOV  AX, 4C00H
	INT  21H
test_rtc endp



codesg  ends
end     test_rtc


