Archivos de fabricaci�n de la placa Chronopic v3.0

Los ficheros Gerber est�n en formato Gerber 274R y son:
	* chronopic_v3.0-Component.pho		->	Trazado de las pistas de la cara de componentes
	* chronopic_v3.0-Copper.pho		->	Trazado de las pistas de la cara de soldadura
	* chronopic_v3.0-MaskCmp.pho		->	M�scara de soldadura de la cara de componentes
	* chronopic_v3.0-MaskCop.pho		->	M�scara de soldadura de la cara de soldadura
	* chronopic_v3.0-SilkSCmp.pho		->	Serigraf�a de la cara de componentes

El archivo de taladros est� en formato excellon
	* chronopic_v3.0.drl