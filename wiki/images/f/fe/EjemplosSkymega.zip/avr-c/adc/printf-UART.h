#define F_CPU 16000000UL

#include <avr/io.h>
#include <stdint.h>
#include <stdio.h>

void uart_init();
int uart_putchar(char, FILE *stream);
int serialConfig(long);

