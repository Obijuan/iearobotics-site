/*
      printf-UART.c
      
Copyright (C) 2011 Juan Gonzalez-Gomez, modified by Sergio Vilches Exposito.
This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
Contact: s.vilches.e@gmail.com
   
   Usage:
   serialConfig(baudRate); 
   printf ();
   
   Example:
   serialConfig(9600);
   printf ("test");
   
*/


#include "printf-UART.h"

long uart_baud;

//-- Usar la UART como un stream de salida
FILE uart_str = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);

int serialConfig(long bauds)
{
  uart_baud = bauds;
  //-- configurar uart
  uart_init();
  //-- La uart es el strem de salida por defecto
  stdout = &uart_str;
  //-- Imprimir mensaje
  printf ("UART Working\n");
  return 0;
}

void uart_init()
{
  //-- Config the UART (9600 bauds)
  UBRR0L = (F_CPU / (16UL * uart_baud)) - 1;
  UCSR0B = _BV(TXEN0) | _BV(RXEN0); /* tx/rx enable */
}

int uart_putchar(char c, FILE *stream)
{
  loop_until_bit_is_set(UCSR0A, UDRE0);
  UDR0 = c;

  return 0;
}

