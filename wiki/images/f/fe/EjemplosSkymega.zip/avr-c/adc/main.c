//***************************************************************************
//  File Name	 : ADC.c
//  Version	 : 1.0
//  Description  : Using AVR ADC Peripheral
//  Author	 : RWB
//  Target	 : AVRJazz Mega168 Learning Board
//  Compiler     : AVR-GCC 4.3.0; avr-libc 1.6.2 (WinAVR 20080610)
//  IDE          : Atmel AVR Studio 4.14
//  Programmer   : AVRJazz Mega168 STK500 v2.0 Bootloader
//               : AVR Visual Studio 4.14, STK500 programmer
//  Last Updated : 21 March 2008
//***************************************************************************

#define F_CPU 16000000
#include <avr/io.h>
#include <util/delay.h>
#include "printf-UART.h"

int main(void)
{
	serialConfig(9600);
	int adcValue = 10;
	// Set ADCSRA Register in ATMega168: Enable and 128 prescaler
	ADCSRA = (1<<ADEN) | (1<<ADPS2) | (1<<ADPS1)| (1<<ADPS0);

	// Set ADMUX Register in ATMega168. The input is PORTC0
	ADMUX = (1<<REFS0);	// The reference is VCC

	for(;;) {                     // Loop Forever
		// Start conversion by setting ADSC in ADCSRA Register
		ADCSRA |= (1<<ADSC);

		// wait until conversion complete ADSC=0 -> Complete
		while (ADCSRA & (1<<ADSC));

		// Get ADC the Result, combining ADCL and ADCH 8bits registers (this is done by ADCW, a macro)
		adcValue = ADCW; 
		
		printf("ADC Value:%d\r\n",adcValue);
		
	}

	return 0;	                    // Standard Return Code
}
