//-- UART Test!
#define F_CPU 16000000UL
#include <avr/io.h>
#include <stdint.h>
#include <stdio.h>
#include "printf-UART.h"

int main(){
	serialConfig(9600);
	while(1){
		printf ("test");
	}
	return 0;
}
