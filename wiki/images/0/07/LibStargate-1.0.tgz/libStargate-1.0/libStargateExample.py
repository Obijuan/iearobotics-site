#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: Example of use of libStargate.
# Copyright: (C) 2007 by Rafael Treviño Menéndez
# Authors: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

#----------------------
#   MAIN
#----------------------
if __name__ == '__main__':

  print "Probando los Stargates en python...."
  try:
    port = sys.argv [1]
  except IndexError:
    print 'Uso: %s <port>' % sys.argv [0]
    sys.exit (-1)

  try:
    s = Generic (port)
  except StargateError:
    print 'No se puede conectar a %s.' % port
    sys.exit (-1)
  
  s.checkConnection ();
