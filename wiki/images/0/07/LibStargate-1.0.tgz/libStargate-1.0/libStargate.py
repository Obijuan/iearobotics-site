#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: libStargate is a library for comunication to stargates
# Copyright: (C) 2007 by Juan González Gómez
#            (C) 2007 by Rafael Treviño Menéndez
# Authors: Juan González Gómez     <juan@iearobotics.com>
#          Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys
import serial

try:
  import libIris
except ImportError:
  pass

#-----------------------------------
#------ Cabeceras de la trama 
#-----------------------------------
TRAMA_PING_CAB   = 'P'
TRAMA_ID_CAB     = 'I'
TRAMA_RID_CAB    = 'I'
TRAMA_PONG_CAB   = 'O'
TRAMA_LOAD_CAB   = 'L'
TRAMA_RLOAD_CAB  = 'L'
TRAMA_STORE_CAB  = 'S'
TRAMA_RSTORE_CAB = 'S'
TRAMA_ENA_CAB    = 'E'
TRAMA_POS_CAB    = 'W'
TRAMA_RESET_CAB  = 'T'
TRAMA_RRESET_CAB = 'T'
TRAMA_CONF_CAB   = 'C'
TRAMA_RCONF_CAB  = 'C'
TRAMA_DATA_CAB   = 'D'
TRAMA_RDATA_CAB  = 'D'
TRAMA_RD_CAB     = 'R'
TRAMA_RRD_CAB    = 'R'
TRAMA_INC_CAB     = 'A'
TRAMA_RINC_CAB    = 'A'
TRAMA_BEG_CAB     = 'B'
TRAMA_RBEG_CAB    = 'B'

#-----------------------------------------
#---- Identificacion de los servidores
#-----------------------------------------
SERVIDOR = {0x00: "XXXX",
            0x10: "NULL", 
            0x20: "GENERIC",
            0x30: "SERVOS8",
            0x40: "PICP",
           }


#------------------------------------------------
#--- Identificacion de los microcontroladores
#------------------------------------------------
MICRO = {0x00: "XXXX",
         0x10: "68HC11E2",
         0x20: "68HC08",
         0x30: "PIC16F876",
        }

#--------------------------------------
#-- Identificacion de las placas
#--------------------------------------
PLACA = {0x00 : "USER",
         0x101: "CT6811",
         0x201: "GPBOT",
         0x300: "USER",
         0X301: "SKYPIC",
        } 

#----------------------------------------------------------------------
#-- Valores de los extremos de los servos para diferentes servidores  
#----------------------------------------------------------------------
EXTREMOS = {'USER':   (0, 0xE6),  # Valores por defecto si no se indica nada
            'SKYPIC': (0, 0x89),  # Skypic a 20Mhz
            'CT6811': (0, 0xE6),  # CT6811
           }

#--------------------------------------------------
# CLASS STARGATEERROR (general exception raising)
#--------------------------------------------------
class StargateError (Exception):
  pass

#--------------------------------------------------
# CLASS COMERROR (comunication exception raising)
#--------------------------------------------------
class ComError (Exception):
  pass

#--------------------------------------------------
# CLASS STARGATE
#--------------------------------------------------
class Stargate: 

  def __init__ (self, firmware, port = 0):
   
    #-- Port to open
    self.__port = port
    self.serial = None
    
    try:
      self.serial = serial.Serial (self.__port, 9600)
    
    except serial.SerialException:
      #-- Error: Unable to open serial port
      raise StargateError, 'Unable to open serial port %s' % str (self.__port)

    #-- Timeout: 0.5 seg
    self.serial.timeout = 0.5;
      
    #-- Empty buffers
    self.serial.flushInput ()
    self.serial.flushOutput ()

    #-- Update firmware if needed
    if firmware:
      if self.__checkServerType (firmware, True):
        print 'Correct firmware.'
      else:
        print 'Invalid firmware.'
  
  #------------------
  #- PING service
  #------------------
  def ping (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Send PING
    self.serial.write (TRAMA_PING_CAB);
    
    #-- Wait reply
    pong = self.serial.read (1);

    #-- Timeout o incorrect reply
    if not len (pong) or pong != TRAMA_PONG_CAB: 
    
      #-- Empty buffers
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to ping'
    
  #-----------------------------------------------------
  #- IDENT service.
  #- return identify tuple:
  #-     is : service identifier
  #-     im : microprocessor identifier
  #-     id : card identifier
  #-     iv : version identifier
  #-  Todos son valores enteros
  #-----------------------------------------------------
  def ident (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'

    #-- Send IDENTIFICATION
    self.serial.write (TRAMA_ID_CAB);
    
    #-- Wait reply
    id = self.serial.read (4);
    
    #-- Timeout o incorrect reply
    if not len (id) or id [0] != TRAMA_RID_CAB: 
    
      #-- Empty buffers
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to identify'

    iserv, im, id = ord (id [1]), ord (id [2]), ord (id [3])
    
    #-- Reply ok
    return (SERVIDOR [iserv], MICRO [im], PLACA [im << 4 | id >> 4], str (id & 0x0F))
                               
  #---------------------------------------------------------------------------
  #-- Check server connection. 
  #-- Three pings are made. If no reply at third, return False, in other case
  #-- print server type and return True
  #
  #  INPUT: 
  #    -Optional parameter verbose:
  #       True : print all the information
  #       False: don'f print the information
  #
  #  Return:
  #     False : No hay conexion con el servidor
  #     True  : Conexion establecida
  #
  #----------------------------------------------------------------------------
# TODO: Traducido hasta aqui (ya me he cansado :P)
  def checkConnection (self, verbose = True):
    
    #-- En modo verbose se muestra el numero del puerto y el nombre del
    #-- dispositivo
    if verbose:
      print
      
      #-- If not open, exception
      if not self.serial:
        raise StargateError, 'Serial port not open'
      else:
        print "Port (%s) : %s." % (str (self.__port), self.serial.portstr)
    
    #-- Realizar tres iteraciones
    for i in xrange (3):
    
      #-- En modo verboso se imprime informacion de lo que se va haciendo
      if verbose:
        sys.stdout.write ("Conection...")
        sys.stdout.flush ()
        
      #-- Hacer ping
      try:
        self.ping ()
      except ComError:
        if verbose:
          print 'TIMEOUT.'
      else:
        if verbose:
          print 'OK.'
        break
    # else executes if not make break call in the loop
    else:
      #-- No hay conexion
      if verbose:
        print "Conexion NO establecida."

      return False
    
    #-- Todo ok
    if verbose:
      print "Servidor: SG-%s-%s-%s-%s." % self.ident ()
      print "Conexion establecida."
        
    return True

  #-------------------------------------------------------------------
  #- Comprobar el tipo de servidor para saber si es el 
  #- esperado o no y descargar el adecuado si se solicita
  #- ENTRADAS:
  #-    -tipo: Cadena identificaiva del servidor. Definidas en el 
  #            diccionario SERVIDOR
  #     -verbose (opcional): Indica si se imprimen mensajes o no
  #------------------------------------------------------------------
  def __checkServerType (self, type, replace = False, verbose = True):
  
    #-- Solo se imprimen mensajes en modo verbose
    if verbose:
      print 'Needed firmware: sg-%s.' % type
      sys.stdout.flush ()
      
    #-- Solicitar servicio de identificacion
    (server, microprocessor, card, version) = self.ident ();
    
    if verbose:
      print 'Installed firmware: sg-%s.' % server
    
    if (type.upper () == server):
      return True
 
    else:
      if replace:
        try:
          iris = libIris.Iris (self.__port, self.serial)
        except NameError:
          return False
        try:
          iris.download ('sg-%s' % type.lower ())
        except libIris.IrisError:
          print >> sys.stderr, 'Error: Unable to download correct firmware.'
          return False
        else:
          print 'Firmware updated!'
          return True
      else:
        return False
  
#---------------------------------------------------------------------
#  CLASE STARGATE GENERICO
#---------------------------------------------------------------------
class Generic (Stargate):

  #-- Inicializar la clase
  def __init__ (self, port = 0):
    Stargate.__init__ (self, 'GENERIC', port)
    
  #-----------------------------------
  #-- Servicio LOAD
  #-- Devuelve el valor leido
  #-----------------------------------
  def load (self, dir):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama
    self.serial.write (TRAMA_LOAD_CAB)
    self.serial.write (chr (dir & 0xFF))
    self.serial.write (chr ((dir >> 8) & 0xFF))
    
    #-- Esperar respuesta
    load = self.serial.read (2);
    
    #-- Timeout o dato incorrecto
    if not len (load) or load[0] != TRAMA_RLOAD_CAB: 
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to load'
    
    #-- load ok
    return ord (load [1])
    
  #-------------------
  #-- Servicio STORE
  #-------------------
  def store (self, dir, valor):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_STORE_CAB)
    self.serial.write (chr (dir & 0xFF))
    self.serial.write (chr ((dir >> 8) & 0xFF))
    self.serial.write (chr (valor & 0xFF))
    
    #-- Esperar respuesta
    store = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (store) or store != TRAMA_RSTORE_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to store'
 
#---------------------------------------------------------------------
#  CLASE STARGATE SERVOS8
#---------------------------------------------------------------------
class Servos8 (Stargate):

  #-- Inicializar la clase
  def __init__(self, port = 0):
    Stargate.__init__(self, 'SERVOS8', port)

    #-- Inicializar los limites superiores e inferiores por defecto
    server, microprocessor, card, version = self.ident ()
    self.__li, self.__ls = EXTREMOS [card]
    self.__zero = (self.__ls + self.__li) / 2
    self.__range = self.__ls - self.__li

  #-------------------
  #-- Servicio ENABLE
  #-------------------
  def enable (self, mask):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_ENA_CAB)
    self.serial.write (chr (mask & 0xFF))
    
  #------------------------------------------------------------------
  #-- Servicio POS
  #-- Se especifica el angulo del servo en grados, entre -90 y 90
  #------------------------------------------------------------------
  def position (self, servo, pos):
    
    #-- Convertir de grados al rango del servo
    #-- Esta conversion depende de los valores limites (superior e inferior)
    #-- implementados en el servidor
    pos = self.__zero + self.__range * pos / 180
    
    #-- Invocar el servicio de posicionamiento de bajo nivel
    self.__posRaw (servo, pos)
  
  #--------------------------------------------------------------------
  #-- Servicio POS de bajo nivel. Se especifica la posicion como un 
  #-- byte entre 0 y 255. Dependiendo del servidor, el servo se 
  #-- situara en un angulo u otro
  #--------------------------------------------------------------------
  def __posRaw (self, servo, pos):

    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_POS_CAB)
    self.serial.write (chr (servo & 0xFF))
    self.serial.write (chr (int (pos) & 0xFF))

#---------------------------------------------------------------------
#  CLASS STARGATE PICP
#---------------------------------------------------------------------
class PicP (Stargate):

  #-- Inicializar la clase
  def __init__(self, port = 0):
    Stargate.__init__(self, 'PICP', port)
    self.__pc = 0 # Program counter

  #-------------------
  #-- Service RESET
  #-------------------
  def reset (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_RESET_CAB)
    
    #-- Esperar respuesta
    reset = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (reset) or reset != TRAMA_RRESET_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to reset'

    self.__pc = 0x0

  #----------------------
  #-- Service LOAD CONFIG
  #----------------------
  def loadConfig (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_CONF_CAB)
    
    #-- Esperar respuesta
    reset = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (reset) or reset != TRAMA_RCONF_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to load configuration'

    self.__pc = 0x2000

  #--------------------
  #-- Service LOAD DATA (PROGRAM MEMORY)
  #--------------------
  def loadDataPM (self, data):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_DATA_CAB)
    self.serial.write (data & 0xFF)
    self.serial.write (data >> 8 & 0xFF)
    
    #-- Esperar respuesta
    data = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (data) or data != TRAMA_RDATA_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to store'

  #--------------------
  #-- Service READ DATA (PROGRAM MEMORY)
  #--------------------
  def readDataPM (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_RD_CAB)
    
    #-- Esperar respuesta
    data = self.serial.read (3);
    
    #-- Timeout o dato incorrecto
    if not len (data) or data [0] != TRAMA_RRD_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to store'
    
    return ((data [2] & 0x3F) << 8) + data [1]

  #---------------------
  #-- Service INC ADDR
  #---------------------
  def incAddr (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_INC_CAB)
    
    #-- Esperar respuesta
    data = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (data) or data != TRAMA_RINC_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to store'

    self.__pc += 1

  #----------------------
  #-- Service BEGIN CYCLE
  #----------------------
  def beginCycle (self):
  
    #-- If not open, exception
    if not self.serial:
      raise StargateError, 'Serial port not open'
    
    #-- Enviar trama 
    self.serial.write (TRAMA_BEG_CAB)
    
    #-- Esperar respuesta
    data = self.serial.read (1);
    
    #-- Timeout o dato incorrecto
    if not len (data) or data != TRAMA_RBEG_CAB:
    
      #-- Vaciar los buffers de entrada y salida
      self.serial.flushInput ()
      self.serial.flushOutput ()
      raise ComError, 'Unable to store'

  #---------------------
  #-- Method READ CONFIG
  #---------------------
  def readConfig (self):
    self.loadConfig ()
    for i in xrange (6):
      self.incAddr ()
      id = self.readDataPM ()
      self.incAddr ()
      config = self.readDataPM ()

  #--------------------
  #-- Method WRITE DATA
  #--------------------
  # Write a contiguos block of data 
  def writeData (self, data): # PIC16F87XA version
    self.reset ()
    rem = len (data) % 8
    if rem:
      data.extend ((8 - rem) * [0])

    for i, data in enumerate (data):
      self.loadDataPM (data)
      if i % 8 == 0:
        self.beginCycle ()
        self.incAddr ()

  #----------------------
  #-- Method WRITE CONFIG
  #----------------------
  def writeConfig (self, config):
    self.loadConfig ()
    
    for i in xrange (7):
      self.incAddr ()
    
    self.loadDataPM (config)
    self.beginCycle ()
  
  #-----------------------
  #-- Method WRITE PROGRAM
  #-----------------------
  def writeProgram (self, file): # Development TODO
    # Can raise NameError if libIris can't be imported
    hr = libIris.HexReader ()
    fd = open (file)
    data = hr.readHex (fd)
    self.writeData (data)
