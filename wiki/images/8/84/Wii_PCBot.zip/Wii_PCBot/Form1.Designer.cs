﻿namespace Wii_PCBot
{
    partial class Wii_PCBot
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Joystick = new System.Windows.Forms.CheckBox();
            this.Analog = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.progressBarZ = new System.Windows.Forms.ProgressBar();
            this.progressBarY = new System.Windows.Forms.ProgressBar();
            this.progressBarX = new System.Windows.Forms.ProgressBar();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM2";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Joystick
            // 
            this.Joystick.AutoSize = true;
            this.Joystick.Location = new System.Drawing.Point(179, 12);
            this.Joystick.Name = "Joystick";
            this.Joystick.Size = new System.Drawing.Size(65, 17);
            this.Joystick.TabIndex = 0;
            this.Joystick.Text = "WiiMote";
            this.Joystick.UseVisualStyleBackColor = true;
            this.Joystick.CheckedChanged += new System.EventHandler(this.Joystick_CheckedChanged);
            // 
            // Analog
            // 
            this.Analog.AutoSize = true;
            this.Analog.Location = new System.Drawing.Point(179, 35);
            this.Analog.Name = "Analog";
            this.Analog.Size = new System.Drawing.Size(59, 17);
            this.Analog.TabIndex = 1;
            this.Analog.Text = "Analog";
            this.Analog.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // progressBarZ
            // 
            this.progressBarZ.Location = new System.Drawing.Point(45, 120);
            this.progressBarZ.Maximum = 256;
            this.progressBarZ.Name = "progressBarZ";
            this.progressBarZ.Size = new System.Drawing.Size(100, 23);
            this.progressBarZ.TabIndex = 3;
            // 
            // progressBarY
            // 
            this.progressBarY.Location = new System.Drawing.Point(45, 91);
            this.progressBarY.Maximum = 256;
            this.progressBarY.Name = "progressBarY";
            this.progressBarY.Size = new System.Drawing.Size(100, 23);
            this.progressBarY.TabIndex = 4;
            // 
            // progressBarX
            // 
            this.progressBarX.Location = new System.Drawing.Point(45, 62);
            this.progressBarX.Maximum = 255;
            this.progressBarX.Name = "progressBarX";
            this.progressBarX.Size = new System.Drawing.Size(100, 23);
            this.progressBarX.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Pad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "X";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Z";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(167, 64);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(45, 20);
            this.textBox1.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(167, 94);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(45, 20);
            this.textBox2.TabIndex = 13;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(167, 123);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(45, 20);
            this.textBox3.TabIndex = 14;
            // 
            // Wii_PCBot
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 152);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.progressBarX);
            this.Controls.Add(this.progressBarY);
            this.Controls.Add(this.progressBarZ);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Analog);
            this.Controls.Add(this.Joystick);
            this.Name = "Wii_PCBot";
            this.Text = "Wii_PCBot";
            this.Load += new System.EventHandler(this.Wii_PCBot_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox Joystick;
        private System.Windows.Forms.CheckBox Analog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar progressBarZ;
        private System.Windows.Forms.ProgressBar progressBarY;
        private System.Windows.Forms.ProgressBar progressBarX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
    }
}

