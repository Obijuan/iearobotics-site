pcode dump


	New pBlock

internal pblock, dbName =M
;; Starting pCode block
_main	;Function start
; 2 exit points
;	.line	6; "ejemplo.c"	RGB_init();          // arranco la placa RGB
	PAGESEL	_RGB_init
	CALL	_RGB_init
	PAGESEL	$
;	.line	7; "ejemplo.c"	ConfigurarSkybot();  // configuro el SkyBot
	PAGESEL	_ConfigurarSkybot
	CALL	_ConfigurarSkybot
	PAGESEL	$
;	.line	9; "ejemplo.c"	Avanzar();           // Avanza
	PAGESEL	_Avanzar
	CALL	_Avanzar
	PAGESEL	$
;	.line	10; "ejemplo.c"	Latido(1,66,255,1);  // Late en Rojo 
	MOVLW	0x01
	MOVWF	STK02
	MOVLW	0xff
	MOVWF	STK01
	MOVLW	0x42
	MOVWF	STK00
	MOVLW	0x01
	PAGESEL	_Latido
	CALL	_Latido
	PAGESEL	$
_00106_DS_
	GOTO	_00106_DS_
	RETURN	
; exit point of _main
