;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Thu Oct 30 09:38:38 2008
;--------------------------------------------------------
; PIC port for the 14-bit core
;--------------------------------------------------------
;	.module libRGB
	list	p=16f876a
	radix dec
	include "p16f876a.inc"
;--------------------------------------------------------
; publics variables in this module
;--------------------------------------------------------
	global _Write_RGB
	global _i2c_RStart
	global _i2c_CheckIdle
	global _i2c_SendStart
	global _i2c_SendStop
	global _i2c_SendByte
	global _i2c_SendNack
	global _i2c_SendAck
	global _i2c_CheckACK
	global _i2c_ReadByte
	global _pausa_1ms
	global _vel
	global _flag
	global _i2c_configure
	global _RGB_init
	global _RGB
	global _Blue
	global _Red
	global _Green
	global _Latido
;--------------------------------------------------------
; extern variables in this module
;--------------------------------------------------------
	extern _EECON2
	extern _EECON1
	extern _EEADRH
	extern _EEDATH
	extern _EEADR
	extern _EEDATA
	extern _ADCON1
	extern _ADRESL
	extern _CVRCON
	extern _CMCON
	extern _SPBRG
	extern _TXSTA
	extern _SSPSTAT
	extern _SSPADD
	extern _PR2
	extern _SSPCON2
	extern _PCON
	extern _PIE2
	extern _PIE1
	extern _TRISC
	extern _TRISB
	extern _TRISA
	extern _OPTION_REG
	extern _ADCON0
	extern _ADRESH
	extern _CCP2CON
	extern _CCPR2H
	extern _CCPR2L
	extern _RCREG
	extern _TXREG
	extern _RCSTA
	extern _CCP1CON
	extern _CCPR1H
	extern _CCPR1L
	extern _SSPCON
	extern _SSPBUF
	extern _T2CON
	extern _TMR2
	extern _T1CON
	extern _TMR1H
	extern _TMR1L
	extern _PIR2
	extern _PIR1
	extern _INTCON
	extern _PCLATH
	extern _PORTC
	extern _PORTB
	extern _PORTA
	extern _FSR
	extern _STATUS
	extern _TMR0
	extern _TXSTA_bits
	extern _T2CON_bits
	extern _T1CON_bits
	extern _STATUS_bits
	extern _SSPSTAT_bits
	extern _SSPCON2_bits
	extern _SSPCON_bits
	extern _RCSTA_bits
	extern _PIR2_bits
	extern _PIR1_bits
	extern _PIE2_bits
	extern _PIE1_bits
	extern _PCON_bits
	extern _OPTION_REG_bits
	extern _INTCON_bits
	extern _EECON1_bits
	extern _CVRCON_bits
	extern _CMCON_bits
	extern _CCP2CON_bits
	extern _CCP1CON_bits
	extern _ADCON1_bits
	extern _ADCON0_bits
	extern _PCL
	extern _INDF
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; absolute symbol definitions
;--------------------------------------------------------

	extern PSAVE
	extern SSAVE
	extern WSAVE
	extern STK12
	extern STK11
	extern STK10
	extern STK09
	extern STK08
	extern STK07
	extern STK06
	extern STK05
	extern STK04
	extern STK03
	extern STK02
	extern STK01
	extern STK00
;	.area	RSEG    (DATA)
;--------------------------------------------------------
; udata
;--------------------------------------------------------
data_libRGB	udata
;	.area	DSEG    (DATA)
udata_libRGB_0	udata
_flag	res	1
udata_libRGB_1	udata
_vel	res	1
udata_libRGB_2	udata
r0x5B	res	1
udata_libRGB_3	udata
r0x5C	res	1
udata_libRGB_4	udata
r0x5A	res	1
udata_libRGB_5	udata
r0x58	res	1
udata_libRGB_6	udata
r0x54	res	1
udata_libRGB_7	udata
r0x55	res	1
udata_libRGB_8	udata
r0x4C	res	1
udata_libRGB_9	udata
r0x4D	res	1
udata_libRGB_10	udata
r0x4E	res	1
udata_libRGB_11	udata
r0x4F	res	1
udata_libRGB_12	udata
r0x42	res	1
udata_libRGB_13	udata
r0x38	res	1
udata_libRGB_14	udata
r0x2E	res	1
udata_libRGB_15	udata
r0x20	res	1
udata_libRGB_16	udata
r0x21	res	1
udata_libRGB_17	udata
r0x22	res	1
udata_libRGB_18	udata
r0x23	res	1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
;	udata_ovr
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
;	.area	BSEG    (BIT)
;--------------------------------------------------------
; code
;--------------------------------------------------------
code_libRGB	code
;***
;  pBlock Stats: dbName = C
;***
;entry:  _Latido	;Function start
; 2 exit points
;has an exit
;functions called:
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Red
;   _Write_RGB
;   _Green
;   _Write_RGB
;   _Blue
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Red
;   _Write_RGB
;   _Green
;   _Write_RGB
;   _Blue
;   _Write_RGB
;7 compiler assigned registers:
;   r0x20
;   STK00
;   r0x21
;   STK01
;   r0x22
;   STK02
;   r0x23
;; Starting pCode block
_Latido	;Function start
; 2 exit points
;	.line	213; "libRGB.c"	void Latido(unsigned char tipo, unsigned char min, unsigned char max, unsigned char velocidad) {
	BANKSEL	r0x20
	MOVWF	r0x20
	MOVF	STK00,W
	MOVWF	r0x21
	MOVF	STK01,W
	MOVWF	r0x22
	MOVF	STK02,W
	MOVWF	r0x23
;;     peep 7 - Removed redundant move
;	.line	215; "libRGB.c"	if (tipo==0) {
	MOVF	r0x20,W
	BTFSS	STATUS,2
	GOTO	_00208_DS_
;	.line	216; "libRGB.c"	Write_RGB(2 , 0);  // patron
	MOVLW	0x00
	MOVWF	STK00
	MOVLW	0x02
	CALL	_Write_RGB
;	.line	217; "libRGB.c"	Write_RGB(7 , 0);  // patron 
	MOVLW	0x00
	MOVWF	STK00
	MOVLW	0x07
	CALL	_Write_RGB
;	.line	218; "libRGB.c"	Write_RGB(12, 0);  // patron
	MOVLW	0x00
	MOVWF	STK00
	MOVLW	0x0c
	CALL	_Write_RGB
;	.line	219; "libRGB.c"	RGB(0,0,0,0);
	MOVLW	0x00
	MOVWF	STK02
	MOVLW	0x00
	MOVWF	STK01
	MOVLW	0x00
	MOVWF	STK00
	MOVLW	0x00
	CALL	_RGB
	GOTO	_00210_DS_
_00208_DS_
;	.line	222; "libRGB.c"	Write_RGB(3 ,max);
	BANKSEL	r0x22
	MOVF	r0x22,W
	MOVWF	STK00
	MOVLW	0x03
	CALL	_Write_RGB
;	.line	223; "libRGB.c"	Write_RGB(4 ,min);
	BANKSEL	r0x21
	MOVF	r0x21,W
	MOVWF	STK00
	MOVLW	0x04
	CALL	_Write_RGB
;	.line	224; "libRGB.c"	Write_RGB(8 ,max);
	BANKSEL	r0x22
	MOVF	r0x22,W
	MOVWF	STK00
	MOVLW	0x08
	CALL	_Write_RGB
;	.line	225; "libRGB.c"	Write_RGB(9 ,min);
	BANKSEL	r0x21
	MOVF	r0x21,W
	MOVWF	STK00
	MOVLW	0x09
	CALL	_Write_RGB
;	.line	226; "libRGB.c"	Write_RGB(13,max);
	BANKSEL	r0x22
	MOVF	r0x22,W
	MOVWF	STK00
	MOVLW	0x0d
	CALL	_Write_RGB
;	.line	227; "libRGB.c"	Write_RGB(14,min);
	BANKSEL	r0x21
	MOVF	r0x21,W
	MOVWF	STK00
	MOVLW	0x0e
	CALL	_Write_RGB
;	.line	229; "libRGB.c"	if (tipo==1) {
	BANKSEL	r0x20
	MOVF	r0x20,W
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00205_DS_
;	.line	230; "libRGB.c"	Red(250,velocidad);
	MOVF	r0x23,W
	MOVWF	STK00
	MOVLW	0xfa
	CALL	_Red
;	.line	231; "libRGB.c"	Write_RGB(2 , 1);
	MOVLW	0x01
	MOVWF	STK00
	MOVLW	0x02
	CALL	_Write_RGB
	GOTO	_00210_DS_
_00205_DS_
;	.line	234; "libRGB.c"	else if (tipo==2) {
	BANKSEL	r0x20
	MOVF	r0x20,W
	XORLW	0x02
	BTFSS	STATUS,2
	GOTO	_00202_DS_
;	.line	235; "libRGB.c"	Green(250,velocidad);
	MOVF	r0x23,W
	MOVWF	STK00
	MOVLW	0xfa
	CALL	_Green
;	.line	236; "libRGB.c"	Write_RGB(7 , 1);
	MOVLW	0x01
	MOVWF	STK00
	MOVLW	0x07
	CALL	_Write_RGB
	GOTO	_00210_DS_
_00202_DS_
;	.line	239; "libRGB.c"	else if (tipo==3) {
	BANKSEL	r0x20
	MOVF	r0x20,W
	XORLW	0x03
	BTFSS	STATUS,2
	GOTO	_00210_DS_
;	.line	240; "libRGB.c"	Blue(250,velocidad);
	MOVF	r0x23,W
	MOVWF	STK00
	MOVLW	0xfa
	CALL	_Blue
;	.line	241; "libRGB.c"	Write_RGB(12, 1);
	MOVLW	0x01
	MOVWF	STK00
	MOVLW	0x0c
	CALL	_Write_RGB
_00210_DS_
	RETURN	
; exit point of _Latido

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Green	;Function start
; 2 exit points
;has an exit
;functions called:
;   _RGB
;   _RGB
;5 compiler assigned registers:
;   r0x2E
;   STK00
;   r0x2F
;   STK02
;   STK01
;; Starting pCode block
_Green	;Function start
; 2 exit points
;	.line	204; "libRGB.c"	void Green(unsigned char intensidad, unsigned char velocidad) {
	BANKSEL	r0x2E
	MOVWF	r0x2E
	MOVF	STK00,W
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x2F
;	.line	205; "libRGB.c"	RGB(0,intensidad, 0, velocidad);
	MOVWF	STK02
	MOVLW	0x00
	MOVWF	STK01
	MOVF	r0x2E,W
	MOVWF	STK00
	MOVLW	0x00
	CALL	_RGB
	RETURN	
; exit point of _Green

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Red	;Function start
; 2 exit points
;has an exit
;functions called:
;   _RGB
;   _RGB
;5 compiler assigned registers:
;   r0x38
;   STK00
;   r0x39
;   STK02
;   STK01
;; Starting pCode block
_Red	;Function start
; 2 exit points
;	.line	199; "libRGB.c"	void Red(unsigned char intensidad, unsigned char velocidad) {
	BANKSEL	r0x38
	MOVWF	r0x38
	MOVF	STK00,W
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x39
;	.line	200; "libRGB.c"	RGB(intensidad,0,0, velocidad);
	MOVWF	STK02
	MOVLW	0x00
	MOVWF	STK01
	MOVLW	0x00
	MOVWF	STK00
	MOVF	r0x38,W
	CALL	_RGB
	RETURN	
; exit point of _Red

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Blue	;Function start
; 2 exit points
;has an exit
;functions called:
;   _RGB
;   _RGB
;5 compiler assigned registers:
;   r0x42
;   STK00
;   r0x43
;   STK02
;   STK01
;; Starting pCode block
_Blue	;Function start
; 2 exit points
;	.line	194; "libRGB.c"	void Blue(unsigned char intensidad, unsigned char velocidad) {
	BANKSEL	r0x42
	MOVWF	r0x42
	MOVF	STK00,W
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x43
;	.line	195; "libRGB.c"	RGB(0,0,intensidad, velocidad);
	MOVWF	STK02
	MOVF	r0x42,W
	MOVWF	STK01
	MOVLW	0x00
	MOVWF	STK00
	MOVLW	0x00
	CALL	_RGB
	RETURN	
; exit point of _Blue

;***
;  pBlock Stats: dbName = C
;***
;entry:  _RGB	;Function start
; 2 exit points
;has an exit
;functions called:
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;   _Write_RGB
;7 compiler assigned registers:
;   r0x4C
;   STK00
;   r0x4D
;   STK01
;   r0x4E
;   STK02
;   r0x4F
;; Starting pCode block
_RGB	;Function start
; 2 exit points
;	.line	182; "libRGB.c"	void RGB(unsigned char red, unsigned char green, unsigned char blue, unsigned char velocidad) {
	BANKSEL	r0x4C
	MOVWF	r0x4C
	MOVF	STK00,W
	MOVWF	r0x4D
	MOVF	STK01,W
	MOVWF	r0x4E
	MOVF	STK02,W
;;     peep 2 - Removed redundant move
;	.line	183; "libRGB.c"	Write_RGB(11,velocidad);
	MOVWF	r0x4F
	MOVWF	STK00
	MOVLW	0x0b
	CALL	_Write_RGB
;	.line	184; "libRGB.c"	Write_RGB(6,velocidad);	
	BANKSEL	r0x4F
	MOVF	r0x4F,W
	MOVWF	STK00
	MOVLW	0x06
	CALL	_Write_RGB
;	.line	185; "libRGB.c"	Write_RGB(1,velocidad);
	BANKSEL	r0x4F
	MOVF	r0x4F,W
	MOVWF	STK00
	MOVLW	0x01
	CALL	_Write_RGB
;	.line	187; "libRGB.c"	Write_RGB(10,blue);
	BANKSEL	r0x4E
	MOVF	r0x4E,W
	MOVWF	STK00
	MOVLW	0x0a
	CALL	_Write_RGB
;	.line	188; "libRGB.c"	Write_RGB(5,green);
	BANKSEL	r0x4D
	MOVF	r0x4D,W
	MOVWF	STK00
	MOVLW	0x05
	CALL	_Write_RGB
;	.line	189; "libRGB.c"	Write_RGB(0,red);
	BANKSEL	r0x4C
	MOVF	r0x4C,W
	MOVWF	STK00
	MOVLW	0x00
	CALL	_Write_RGB
	RETURN	
; exit point of _RGB

;***
;  pBlock Stats: dbName = C
;***
;entry:  _RGB_init	;Function start
; 2 exit points
;has an exit
;functions called:
;   _i2c_configure
;   _i2c_configure
;; Starting pCode block
_RGB_init	;Function start
; 2 exit points
;	.line	173; "libRGB.c"	i2c_configure();
	CALL	_i2c_configure
	RETURN	
; exit point of _RGB_init

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Write_RGB	;Function start
; 2 exit points
;has an exit
;functions called:
;   _i2c_CheckIdle
;   _i2c_SendStart
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendStop
;   _i2c_CheckIdle
;   _i2c_CheckIdle
;   _i2c_SendStart
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendByte
;   _pausa_1ms
;   _i2c_SendStop
;   _i2c_CheckIdle
;3 compiler assigned registers:
;   r0x54
;   STK00
;   r0x55
;; Starting pCode block
_Write_RGB	;Function start
; 2 exit points
;	.line	136; "libRGB.c"	void Write_RGB(unsigned char reg, unsigned char rgb )
	BANKSEL	r0x54
	MOVWF	r0x54
	MOVF	STK00,W
	MOVWF	r0x55
;	.line	140; "libRGB.c"	SSPIF=0;
	BCF	_PIR1_bits,3
;	.line	143; "libRGB.c"	i2c_CheckIdle();
	CALL	_i2c_CheckIdle
;	.line	144; "libRGB.c"	i2c_SendStart();	
	CALL	_i2c_SendStart
;	.line	147; "libRGB.c"	i2c_SendByte(RGB_W);
	MOVLW	0xa2
	CALL	_i2c_SendByte
;	.line	148; "libRGB.c"	pausa_1ms();  // espero a que llegue el ACK
	CALL	_pausa_1ms
;	.line	149; "libRGB.c"	SSPCON2 = SSPCON2 & 0xBF;  // borro ACK	
	BSF	STATUS,5
	BCF	STATUS,6
	BCF	_SSPCON2,6
;	.line	152; "libRGB.c"	i2c_SendByte(reg); 
	BANKSEL	r0x54
	MOVF	r0x54,W
	CALL	_i2c_SendByte
;	.line	153; "libRGB.c"	pausa_1ms();  // espero a que llegue el ACK
	CALL	_pausa_1ms
;	.line	154; "libRGB.c"	SSPCON2 = SSPCON2 & 0xBF;  // borro ACK
	BSF	STATUS,5
	BCF	STATUS,6
	BCF	_SSPCON2,6
;	.line	157; "libRGB.c"	i2c_SendByte(rgb); 
	BANKSEL	r0x55
	MOVF	r0x55,W
	CALL	_i2c_SendByte
;	.line	158; "libRGB.c"	pausa_1ms();  // espero a que llegue el ACK
	CALL	_pausa_1ms
;	.line	159; "libRGB.c"	SSPCON2 = SSPCON2 & 0xBF;  // borro ACK
	BSF	STATUS,5
	BCF	STATUS,6
	BCF	_SSPCON2,6
;	.line	163; "libRGB.c"	i2c_SendStop();
	CALL	_i2c_SendStop
;	.line	164; "libRGB.c"	i2c_CheckIdle();  
	CALL	_i2c_CheckIdle
	RETURN	
; exit point of _Write_RGB

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_configure	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_configure	;Function start
; 2 exit points
;	.line	116; "libRGB.c"	TRISC=TRISC | 0x18;  // 1 entrada / 0 salida  
	MOVLW	0x18
	BSF	STATUS,5
	BCF	STATUS,6
	IORWF	_TRISC,F
;	.line	118; "libRGB.c"	SSPSTAT=0x0;  
	CLRF	_SSPSTAT
;	.line	119; "libRGB.c"	SSPSTAT=SSPSTAT | 0x80;  // SMP=1 Slew rate disable for 100Kh
	BSF	_SSPSTAT,7
;	.line	122; "libRGB.c"	SSPCON=0x08;	 		 // I2C master mode (uso la formula del reloj con SSPAD)  
	MOVLW	0x08
	BCF	STATUS,5
	MOVWF	_SSPCON
;	.line	123; "libRGB.c"	SSPCON=SSPCON | 0x20;	 // enable I2C  SSPEN=1
	BSF	_SSPCON,5
;	.line	125; "libRGB.c"	SSPCON2=0x00;   // no se usa por ahora
	BSF	STATUS,5
	CLRF	_SSPCON2
;	.line	128; "libRGB.c"	SSPADD=49;  // 49->100Khz 
	MOVLW	0x31
	MOVWF	_SSPADD
;	.line	131; "libRGB.c"	PIR1=0;  //Limpia flag de eventos SSP 
	BCF	STATUS,5
	CLRF	_PIR1
	RETURN	
; exit point of _i2c_configure

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_RStart	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_RStart	;Function start
; 2 exit points
;	.line	102; "libRGB.c"	SSPCON2=SSPCON2 |0x02;  // RSEN=1;
	BSF	STATUS,5
	BCF	STATUS,6
	BSF	_SSPCON2,1
_00166_DS_
;	.line	103; "libRGB.c"	while ( RSEN );
	BTFSC	_SSPCON2_bits,1
	GOTO	_00166_DS_
	RETURN	
; exit point of _i2c_RStart

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_CheckIdle	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x58
;; Starting pCode block
_i2c_CheckIdle	;Function start
; 2 exit points
_00161_DS_
;	.line	96; "libRGB.c"	while ( (SSPCON2 & 0x1F ) != 0 );   // esperamos a que termine cualquier operacion
	MOVLW	0x1f
	BSF	STATUS,5
	BCF	STATUS,6
	ANDWF	_SSPCON2,W
	BANKSEL	r0x58
	MOVWF	r0x58
	MOVF	r0x58,W
	BTFSS	STATUS,2
	GOTO	_00161_DS_
;	.line	97; "libRGB.c"	PIR1=PIR1 & 0xF7;                   // Limpio el Flag de eventos
	BCF	STATUS,5
	BCF	STATUS,6
	BCF	_PIR1,3
	RETURN	
; exit point of _i2c_CheckIdle

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_SendStart	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_SendStart	;Function start
; 2 exit points
;	.line	91; "libRGB.c"	SSPCON2=SSPCON2 |0x01;   // send start bit  SEN=1
	BSF	STATUS,5
	BCF	STATUS,6
	BSF	_SSPCON2,0
_00156_DS_
;	.line	92; "libRGB.c"	while(SEN);	// and wait for it to clear 
	BTFSC	_SSPCON2_bits,0
	GOTO	_00156_DS_
	RETURN	
; exit point of _i2c_SendStart

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_SendStop	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_SendStop	;Function start
; 2 exit points
;	.line	85; "libRGB.c"	SSPCON2=SSPCON2 | 0x04; // send stop bit (PEN = 1)
	BSF	STATUS,5
	BCF	STATUS,6
	BSF	_SSPCON2,2
_00151_DS_
;	.line	86; "libRGB.c"	while(PEN);			
	BTFSC	_SSPCON2_bits,2
	GOTO	_00151_DS_
	RETURN	
; exit point of _i2c_SendStop

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_SendByte	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x59
;; Starting pCode block
_i2c_SendByte	;Function start
; 2 exit points
;	.line	72; "libRGB.c"	unsigned char i2c_SendByte(char dato) {
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_SSPBUF
;	.line	75; "libRGB.c"	if ( (SSPCON & 0x80)==0x80 ) {  // WCOL activado (colision) ? 
	MOVLW	0x80
	ANDWF	_SSPCON,W
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x59
	XORLW	0x80
	BTFSS	STATUS,2
	GOTO	_00140_DS_
;	.line	76; "libRGB.c"	return -1;
	MOVLW	0xff
	GOTO	_00146_DS_
_00140_DS_
;	.line	78; "libRGB.c"	while (SSPSTAT&0x01) ;// mientras que el buffer esta lleno BF=1 espero  
	BSF	STATUS,5
	BTFSC	_SSPSTAT,0
	GOTO	_00140_DS_
;	.line	79; "libRGB.c"	return 0;
	MOVLW	0x00
_00146_DS_
	RETURN	
; exit point of _i2c_SendByte

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_SendNack	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_SendNack	;Function start
; 2 exit points
;	.line	66; "libRGB.c"	SSPCON2= SSPCON2 | 0x20;  // Establece un NACK
	BSF	STATUS,5
	BCF	STATUS,6
	BSF	_SSPCON2,5
;	.line	67; "libRGB.c"	SSPCON2= SSPCON2 | 0x10;  // Lo envia
	BSF	_SSPCON2,4
	RETURN	
; exit point of _i2c_SendNack

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_SendAck	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_SendAck	;Function start
; 2 exit points
;	.line	60; "libRGB.c"	SSPCON2= SSPCON2 & 0xDF;  // Establece un ACK
	BSF	STATUS,5
	BCF	STATUS,6
	BCF	_SSPCON2,5
;	.line	61; "libRGB.c"	SSPCON2= SSPCON2 | 0x10;  // Lo envia
	BSF	_SSPCON2,4
	RETURN	
; exit point of _i2c_SendAck

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_CheckACK	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_i2c_CheckACK	;Function start
; 2 exit points
;	.line	52; "libRGB.c"	if ( (SSPCON2 & 0x40) ==0 ) 
	BSF	STATUS,5
	BCF	STATUS,6
	BTFSC	_SSPCON2,6
	GOTO	_00125_DS_
;	.line	53; "libRGB.c"	return 0;   // correcto (lo he recibido )
	MOVLW	0x00
	GOTO	_00127_DS_
_00125_DS_
;	.line	55; "libRGB.c"	return 1;	// incorrecto (no lo he recibido)
	MOVLW	0x01
_00127_DS_
	RETURN	
; exit point of _i2c_CheckACK

;***
;  pBlock Stats: dbName = C
;***
;entry:  _i2c_ReadByte	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x5A
;; Starting pCode block
_i2c_ReadByte	;Function start
; 2 exit points
;	.line	38; "libRGB.c"	SSPCON2=SSPCON2 | 0x08;           // Activar el RCEN
	BSF	STATUS,5
	BCF	STATUS,6
	BSF	_SSPCON2,3
_00113_DS_
;	.line	39; "libRGB.c"	while  ((SSPCON2 & 0x08)!=0 ) ;   // esperar hasta que RCEN = 0  
	MOVLW	0x08
	BSF	STATUS,5
	BCF	STATUS,6
	ANDWF	_SSPCON2,W
	BANKSEL	r0x5A
	MOVWF	r0x5A
	MOVF	r0x5A,W
	BTFSS	STATUS,2
	GOTO	_00113_DS_
;	.line	40; "libRGB.c"	if ( (SSPSTAT & 0x01) == 0x01 ) {
	MOVLW	0x01
	BSF	STATUS,5
	BCF	STATUS,6
	ANDWF	_SSPSTAT,W
;;     peep 2 - Removed redundant move
	BANKSEL	r0x5A
	MOVWF	r0x5A
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00117_DS_
;	.line	41; "libRGB.c"	return SSPBUF;                // Leo el registro de datos
	BCF	STATUS,5
	BCF	STATUS,6
	MOVF	_SSPBUF,W
;;     peep 2 - Removed redundant move
	BANKSEL	r0x5A
	MOVWF	r0x5A
	GOTO	_00119_DS_
_00117_DS_
;	.line	44; "libRGB.c"	return 0;
	MOVLW	0x00
_00119_DS_
	RETURN	
; exit point of _i2c_ReadByte

;***
;  pBlock Stats: dbName = C
;***
;entry:  _pausa_1ms	;Function start
; 2 exit points
;has an exit
;2 compiler assigned registers:
;   r0x5B
;   r0x5C
;; Starting pCode block
_pausa_1ms	;Function start
; 2 exit points
;	.line	27; "libRGB.c"	while (tmp>0) {
	MOVLW	0xf4
	BANKSEL	r0x5B
	MOVWF	r0x5B
	MOVLW	0x01
	MOVWF	r0x5C
_00105_DS_
	MOVF	r0x5B,W
	IORWF	r0x5C,W
	BTFSC	STATUS,2
	GOTO	_00108_DS_
;	.line	28; "libRGB.c"	tmp--;
	MOVLW	0xff
	ADDWF	r0x5B,F
	BTFSS	STATUS,0
	DECF	r0x5C,F
	GOTO	_00105_DS_
_00108_DS_
	RETURN	
; exit point of _pausa_1ms


;	code size estimation:
;	  304+   27 =   331 instructions (  716 byte)

	end
