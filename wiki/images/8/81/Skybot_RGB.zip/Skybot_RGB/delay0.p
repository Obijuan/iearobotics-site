pcode dump


	New pBlock

code, dbName =C
;; Starting pCode block
_delay0	;Function start
; 2 exit points
;	.line	39; "delay0.c"	void delay0(unsigned char pausa)
	MOVWF	r0x20
_00112_DS_
;	.line	43; "delay0.c"	while(pausa>0) {
	MOVLW	0x00
	IORWF	r0x20,W
	BTFSC	STATUS,2
	GOTO	_00115_DS_
;	.line	44; "delay0.c"	TMR0=TICKS10;   // Inicializar contador
	MOVLW	0x3d
	MOVWF	_TMR0
;	.line	45; "delay0.c"	T0IF=0;         // Quitar flag overflow
	BCF	_INTCON_bits,2
_00109_DS_
;	.line	48; "delay0.c"	while (!T0IF);
	BTFSS	_INTCON_bits,2
	GOTO	_00109_DS_
;	.line	51; "delay0.c"	pausa--;
	DECF	r0x20,F
	GOTO	_00112_DS_
_00115_DS_
	RETURN	
; exit point of _delay0

	New pBlock

code, dbName =C
;; Starting pCode block
_timer0_configurar	;Function start
; 2 exit points
;	.line	31; "delay0.c"	OPTION_REG=0x87;
	MOVLW	0x87
	MOVWF	_OPTION_REG
	RETURN	
; exit point of _timer0_configurar
