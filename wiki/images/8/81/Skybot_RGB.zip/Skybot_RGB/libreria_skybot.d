newReg: Created register STK00 (004FC4AE).
newReg: Created register STK01 (004FC4AE).
newReg: Created register STK02 (004FC4AE).
newReg: Created register STK03 (004FC4AE).
newReg: Created register STK04 (004FC4AE).
newReg: Created register STK05 (004FC4AE).
newReg: Created register STK06 (004FC4AE).
newReg: Created register STK07 (004FC4AE).
newReg: Created register STK08 (004FC4AE).
newReg: Created register STK09 (004FC4AE).
newReg: Created register STK10 (004FC4AE).
newReg: Created register STK11 (004FC4AE).
newReg: Created register STK12 (004FC4AE).
newReg: Created register STATUS (004FC441).
newReg: Created register PCL (004FC441).
newReg: Created register PCLATH (004FC441).
newReg: Created register FSR (004FC441).
newReg: Created register INDF (004FC441).
newReg: Created register INTCON (004FC441).
newReg: Created register WSAVE (004FC3F0).
newReg: Created register SSAVE (004FC3F0).
newReg: Created register PSAVE (004FC3F0).
newReg: Created register r0x20 (004F6C52).
newReg: Created register r0x21 (004F6C52).
newReg: Created register r0x22 (004F6C52).
newReg: Created register r0x23 (004F6C52).
newReg: Created register r0x24 (004F6C52).
newReg: Created register r0x25 (004F6C52).
newReg: Created register r0x26 (004F6C52).
Found a Processor Register!
newReg: Created register r0x27 (004F6C52).
newReg: Created register r0x28 (004F6C52).
newReg: Created register r0x29 (004F6C52).
newReg: Created register r0x2A (004F6C52).
newReg: Created register r0x2B (004F6C52).
newReg: Created register r0x2C (004F6C52).
newReg: Created register r0x2D (004F6C52).
newReg: Created register r0x2E (004F6C52).
newReg: Created register r0x2F (004F6C52).
newReg: Created register r0x30 (004F6C52).
newReg: Created register r0x31 (004F6C52).
newReg: Created register r0x32 (004F6C52).
newReg: Created register r0x33 (004F6C52).
newReg: Created register r0x34 (004F6C52).
newReg: Created register r0x35 (004F6C52).
newReg: Created register r0x36 (004F6C52).
newReg: Created register r0x37 (004F6C52).
newReg: Created register r0x38 (004F6C52).
newReg: Created register r0x39 (004F6C52).
newReg: Created register r0x3A (004F6C52).
newReg: Created register r0x3B (004F6C52).
newReg: Created register r0x3C (004F6C52).
newReg: Created register r0x3D (004F6C52).
newReg: Created register r0x3E (004F6C52).
newReg: Created register r0x3F (004F6C52).
newReg: Created register r0x40 (004F6C52).
newReg: Created register r0x41 (004F6C52).
newReg: Created register r0x42 (004F6C52).
newReg: Created register r0x43 (004F6C52).
newReg: Created register r0x44 (004F6C52).
newReg: Created register r0x45 (004F6C52).
newReg: Created register r0x46 (004F6C52).
newReg: Created register r0x47 (004F6C52).
newReg: Created register r0x48 (004F6C52).
newReg: Created register r0x49 (004F6C52).
newReg: Created register r0x4A (004F6C52).
newReg: Created register r0x4B (004F6C52).
newReg: Created register r0x4C (004F6C52).
newReg: Created register r0x4D (004F6C52).
newReg: Created register r0x4E (004F6C52).
newReg: Created register r0x4F (004F6C52).
newReg: Created register r0x50 (004F6C52).
newReg: Created register r0x51 (004F6C52).
newReg: Created register r0x52 (004F6C52).
newReg: Created register r0x53 (004F6C52).
newReg: Created register r0x54 (004F6C52).
newReg: Created register r0x55 (004F6C52).
newReg: Created register r0x56 (004F6C52).
newReg: Created register r0x57 (004F6C52).
newReg: Created register r0x58 (004F6C52).
newReg: Created register r0x59 (004F6C52).
Found a Processor Register!
newReg: Created register r0x5A (004F6C52).
newReg: Created register r0x5B (004F6C52).
newReg: Created register r0x5C (004F6C52).
Found a Processor Register!
newReg: Created register r0x5D (004F6C52).
newReg: Created register r0x5E (004F6C52).
newReg: Created register r0x5F (004F6C52).
newReg: Created register r0x60 (004F6C52).
newReg: Created register r0x61 (004F6C52).
newReg: Created register r0x62 (004F6C52).
Found a Processor Register!
newReg: Created register r0x63 (004F6C52).
newReg: Created register r0x64 (004F6C52).
newReg: Created register r0x65 (004F6C52).
Found a Processor Register!
newReg: Created register r0x66 (004F6C52).
newReg: Created register r0x67 (004F6C52).
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (4) }

----------------------------------------------------------------
libreria_skybot.c(l43:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l43:s2:k1:d0:s0)		proc _ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l48:s3:k2:d0:s0)		_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe1 {literal-unsigned-char}
libreria_skybot.c(l52:s4:k3:d0:s0)		_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe {literal-unsigned-char}
libreria_skybot.c(l55:s5:k4:d0:s0)		iTemp0 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _timer0_configurar [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 7 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

outDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l55:s6:k5:d0:s0)	 _return($1) :
libreria_skybot.c(l55:s7:k6:d0:s0)		eproc _ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe1 {literal-unsigned-char}
allocDirReg symbol name _TRISB
  703  storage class 3 
 708  integral
 712  specifier
_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _TRISB (004F829D).
  -- added _TRISB to hash, size = 1
  -- and it is at a fixed address 0x86
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe1 {literal-unsigned-char}
packRegsForAssign
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
allocDirReg symbol name _ADCON1
  703  storage class 3 
 708  integral
 712  specifier
_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _ADCON1 (004F829D).
  -- added _ADCON1 to hash, size = 1
  -- and it is at a fixed address 0x9f
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
  left:_ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  left:_timer0_configurar [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp0 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = r0x20  key 26, rIdx = 32, size 1
  -- #3 reg = r0x21  key 27, rIdx = 33, size 1
  -- #4 reg = r0x30  key 27, rIdx = 48, size 1
  -- #5 reg = r0x22  key 28, rIdx = 34, size 1
  -- #6 reg = r0x31  key 28, rIdx = 49, size 1
  -- #7 reg = r0x40  key 28, rIdx = 64, size 1
  -- #8 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #20 reg = r0x25  key 31, rIdx = 37, size 1
  -- #21 reg = r0x34  key 31, rIdx = 52, size 1
  -- #22 reg = r0x43  key 31, rIdx = 67, size 1
  -- #23 reg = r0x52  key 31, rIdx = 82, size 1
  -- #24 reg = r0x61  key 31, rIdx = 97, size 1
  -- #25 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #26 reg = r0x26  key 32, rIdx = 38, size 1
  -- #27 reg = r0x35  key 32, rIdx = 53, size 1
  -- #28 reg = r0x44  key 32, rIdx = 68, size 1
  -- #29 reg = r0x53  key 32, rIdx = 83, size 1
  -- #30 reg = r0x62  key 32, rIdx = 98, size 1
  -- #31 reg = r0x27  key 33, rIdx = 39, size 1
  -- #32 reg = r0x36  key 33, rIdx = 54, size 1
  -- #33 reg = r0x45  key 33, rIdx = 69, size 1
  -- #34 reg = r0x54  key 33, rIdx = 84, size 1
  -- #35 reg = r0x63  key 33, rIdx = 99, size 1
  -- #36 reg = r0x28  key 34, rIdx = 40, size 1
  -- #37 reg = r0x37  key 34, rIdx = 55, size 1
  -- #38 reg = r0x46  key 34, rIdx = 70, size 1
  -- #39 reg = r0x55  key 34, rIdx = 85, size 1
  -- #40 reg = r0x64  key 34, rIdx = 100, size 1
  -- #41 reg = r0x29  key 35, rIdx = 41, size 1
  -- #42 reg = r0x38  key 35, rIdx = 56, size 1
  -- #43 reg = r0x47  key 35, rIdx = 71, size 1
  -- #44 reg = r0x56  key 35, rIdx = 86, size 1
  -- #45 reg = r0x65  key 35, rIdx = 101, size 1
  -- #46 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #47 reg = r0x39  key 36, rIdx = 57, size 1
  -- #48 reg = r0x48  key 36, rIdx = 72, size 1
  -- #49 reg = r0x57  key 36, rIdx = 87, size 1
  -- #50 reg = r0x66  key 36, rIdx = 102, size 1
  -- #51 reg = r0x49  key 37, rIdx = 73, size 1
  -- #52 reg = r0x58  key 37, rIdx = 88, size 1
  -- #53 reg = r0x67  key 37, rIdx = 103, size 1
  -- #54 reg = r0x59  key 38, rIdx = 89, size 1
  -- #55 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #56 reg = STK00  key 45, rIdx = 127, size 1
  -- #57 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #58 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #59 reg = STK01  key 46, rIdx = 126, size 1
  -- #60 reg = STK10  key 46, rIdx = 117, size 1
  -- #61 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #62 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #63 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #64 reg = STK02  key 47, rIdx = 125, size 1
  -- #65 reg = STK11  key 47, rIdx = 116, size 1
  -- #66 reg = INTCON  key 47, rIdx = 11, size 1
  -- #67 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #68 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #69 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #70 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #71 reg = STK03  key 48, rIdx = 124, size 1
  -- #72 reg = STK12  key 48, rIdx = 115, size 1
  -- #73 reg = PCL  key 48, rIdx = 2, size 1
  -- #74 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #75 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #76 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #77 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #78 reg = STK04  key 49, rIdx = 123, size 1
  -- #79 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #80 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #81 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #82 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #83 reg = STK05  key 50, rIdx = 122, size 1
  -- #84 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #85 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #86 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #87 reg = STK06  key 51, rIdx = 121, size 1
  -- #88 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #89 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #90 reg = STK07  key 52, rIdx = 120, size 1
  -- #91 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #92 reg = STK08  key 53, rIdx = 119, size 1
  -- #93 reg = STK09  key 55, rIdx = 118, size 1
  -- #94 reg = INDF  key 56, rIdx = 0, size 1
  -- #95 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: =
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (4) }

----------------------------------------------------------------
libreria_skybot.c(l43:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l43:s2:k1:d0:s0)		proc _ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l48:s3:k2:d0:s0)		_TRISB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe1 {literal-unsigned-char}
libreria_skybot.c(l52:s4:k3:d0:s0)		_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe {literal-unsigned-char}
libreria_skybot.c(l55:s5:k4:d0:s0)		iTemp0 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _timer0_configurar [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l55:s6:k5:d0:s0)	 _return($1) :
libreria_skybot.c(l55:s7:k6:d0:s0)		eproc _ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 7 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

outDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 7 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l55:s6:k5:d0:s0)	 _return($1) :
libreria_skybot.c(l55:s7:k6:d0:s0)		eproc _ConfigurarSkybot [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l78:s1:k0:d0:s0)	 _entry($13) :
libreria_skybot.c(l78:s2:k1:d0:s0)		proc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
libreria_skybot.c(l78:s3:k2:d0:s0)	iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1} = recv _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
libreria_skybot.c(l78:s4:k3:d0:s0)	iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1} = recv _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (49) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (49) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) }

----------------------------------------------------------------
libreria_skybot.c(l81:s5:k47:d0:s0)	 preHeaderLbl0($15) :
libreria_skybot.c(l81:s6:k49:d0:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} := iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (5) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (5) (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l81:s7:k4:d1:s0)	 _whilecontinue_0($1) :
libreria_skybot.c(l81:s8:k5:d1:s0)		iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} > 0xff {literal-unsigned-int}
libreria_skybot.c(l81:s9:k6:d1:s0)		if iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto loopExitLbl2($20)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 13
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (11) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (10) (11) (12) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (10) (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l83:s10:k9:d1:s0)		send 0xff {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l83:s11:k10:d1:s0)		iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l84:s12:k11:d1:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} - 0xff {literal-unsigned-int}
libreria_skybot.c(l84:s13:k13:d1:s0)		 goto _whilecontinue_0($1)

----------------------------------------------------------------
Basic Block loopExitLbl2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 14 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (51) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l84:s14:k50:d0:s0)	 loopExitLbl2($20) :

----------------------------------------------------------------
Basic Block _whilebreak_0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 15 , last iCode = 18
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (15) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (15) (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (49) (51) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (11) (15) (17) (49) }

----------------------------------------------------------------
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block preHeaderLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 19 , last iCode = 20
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (52) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (52) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l88:s19:k48:d0:s0)	 preHeaderLbl1($17) :
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 21 , last iCode = 23
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (19) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (19) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (19) (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto loopExitLbl3($21)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 9 : bbnum = 8 1st iCode = 24 , last iCode = 27
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (25) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (24) (25) (26) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (24) (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)

----------------------------------------------------------------
Basic Block loopExitLbl3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 10 : bbnum = 9 1st iCode = 28 , last iCode = 28
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (54) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l91:s28:k53:d0:s0)	 loopExitLbl3($21) :

----------------------------------------------------------------
Basic Block _whilebreak_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 11 : bbnum = 10 1st iCode = 29 , last iCode = 31
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (29) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (29) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (29) (52) }

----------------------------------------------------------------
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 12 : bbnum = 11 1st iCode = 32 , last iCode = 34
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (34) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (34) }

----------------------------------------------------------------
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)

----------------------------------------------------------------
Basic Block _iffalse_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 13 : bbnum = 12 1st iCode = 35 , last iCode = 37
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (37) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (37) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (37) (52) }

----------------------------------------------------------------
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int} == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 14 : bbnum = 13 1st iCode = 38 , last iCode = 39
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (42) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (42) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (42) }

----------------------------------------------------------------
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 15 : bbnum = 14 1st iCode = 40 , last iCode = 41
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (37) (42) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (37) (42) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
packRegisters
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
        Symbol type: void function    ( unsigned-int, unsigned-int) 
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
        Symbol type: void function    ( unsigned-int, unsigned-int) 
  result:iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
  right:
  hey we can remove this unnecessary assign
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
        Symbol type: void function    ( unsigned-int, unsigned-int) 
  result:iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
  right:
packRegisters
packRegsForAssign
  result:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
  left:
  right:iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}
  result:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
  left:
  right:iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}
  right:iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}
         Symbol type: unsigned-int
  result:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegisters
  left:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:_delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegsForSupport
packRegsForAccUse
packRegisters
packRegisters
  right:iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
         Symbol type: unsigned-int
  result:iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  4017 - casting
packRegsForOneuse
  left:iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
  left:
  right:iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}
  result:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
  left:
  right:iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}
  right:iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}
         Symbol type: unsigned-int
  result:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegisters
  left:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:_delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegsForSupport
packRegsForAccUse
packRegisters
packRegisters
  left:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:_delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}
        Symbol type: unsigned-int
  result:iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:_delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
        Symbol type: void function    ( unsigned-int, unsigned-int) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = r0x20  key 26, rIdx = 32, size 1
  -- #3 reg = r0x21  key 27, rIdx = 33, size 1
  -- #4 reg = r0x30  key 27, rIdx = 48, size 1
  -- #5 reg = r0x22  key 28, rIdx = 34, size 1
  -- #6 reg = r0x31  key 28, rIdx = 49, size 1
  -- #7 reg = r0x40  key 28, rIdx = 64, size 1
  -- #8 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #20 reg = r0x25  key 31, rIdx = 37, size 1
  -- #21 reg = r0x34  key 31, rIdx = 52, size 1
  -- #22 reg = r0x43  key 31, rIdx = 67, size 1
  -- #23 reg = r0x52  key 31, rIdx = 82, size 1
  -- #24 reg = r0x61  key 31, rIdx = 97, size 1
  -- #25 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #26 reg = r0x26  key 32, rIdx = 38, size 1
  -- #27 reg = r0x35  key 32, rIdx = 53, size 1
  -- #28 reg = r0x44  key 32, rIdx = 68, size 1
  -- #29 reg = r0x53  key 32, rIdx = 83, size 1
  -- #30 reg = r0x62  key 32, rIdx = 98, size 1
  -- #31 reg = r0x27  key 33, rIdx = 39, size 1
  -- #32 reg = r0x36  key 33, rIdx = 54, size 1
  -- #33 reg = r0x45  key 33, rIdx = 69, size 1
  -- #34 reg = r0x54  key 33, rIdx = 84, size 1
  -- #35 reg = r0x63  key 33, rIdx = 99, size 1
  -- #36 reg = r0x28  key 34, rIdx = 40, size 1
  -- #37 reg = r0x37  key 34, rIdx = 55, size 1
  -- #38 reg = r0x46  key 34, rIdx = 70, size 1
  -- #39 reg = r0x55  key 34, rIdx = 85, size 1
  -- #40 reg = r0x64  key 34, rIdx = 100, size 1
  -- #41 reg = r0x29  key 35, rIdx = 41, size 1
  -- #42 reg = r0x38  key 35, rIdx = 56, size 1
  -- #43 reg = r0x47  key 35, rIdx = 71, size 1
  -- #44 reg = r0x56  key 35, rIdx = 86, size 1
  -- #45 reg = r0x65  key 35, rIdx = 101, size 1
  -- #46 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #47 reg = r0x39  key 36, rIdx = 57, size 1
  -- #48 reg = r0x48  key 36, rIdx = 72, size 1
  -- #49 reg = r0x57  key 36, rIdx = 87, size 1
  -- #50 reg = r0x66  key 36, rIdx = 102, size 1
  -- #51 reg = r0x49  key 37, rIdx = 73, size 1
  -- #52 reg = r0x58  key 37, rIdx = 88, size 1
  -- #53 reg = r0x67  key 37, rIdx = 103, size 1
  -- #54 reg = r0x59  key 38, rIdx = 89, size 1
  -- #55 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #56 reg = STK00  key 45, rIdx = 127, size 1
  -- #57 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #58 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #59 reg = STK01  key 46, rIdx = 126, size 1
  -- #60 reg = STK10  key 46, rIdx = 117, size 1
  -- #61 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #62 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #63 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #64 reg = STK02  key 47, rIdx = 125, size 1
  -- #65 reg = STK11  key 47, rIdx = 116, size 1
  -- #66 reg = INTCON  key 47, rIdx = 11, size 1
  -- #67 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #68 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #69 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #70 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #71 reg = STK03  key 48, rIdx = 124, size 1
  -- #72 reg = STK12  key 48, rIdx = 115, size 1
  -- #73 reg = PCL  key 48, rIdx = 2, size 1
  -- #74 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #75 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #76 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #77 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #78 reg = STK04  key 49, rIdx = 123, size 1
  -- #79 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #80 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #81 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #82 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #83 reg = STK05  key 50, rIdx = 122, size 1
  -- #84 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #85 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #86 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #87 reg = STK06  key 51, rIdx = 121, size 1
  -- #88 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #89 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #90 reg = STK07  key 52, rIdx = 120, size 1
  -- #91 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #92 reg = STK08  key 53, rIdx = 119, size 1
  -- #93 reg = STK09  key 55, rIdx = 118, size 1
  -- #94 reg = INDF  key 56, rIdx = 0, size 1
  -- #95 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  2697 - iTemp3
  2697 - iTemp4
  2707 - itemp register
  reg name iTemp4,  reg type REG_GPR
  2697 - iTemp5
  2707 - itemp register
  reg name iTemp5,  reg type REG_GPR
  2697 - iTemp6
  2697 - iTemp7
  2707 - itemp register
  2697 - iTemp8
  2697 - iTemp9
  2707 - itemp register
  reg name iTemp9,  reg type REG_GPR
  2697 - iTemp10
  2707 - itemp register
  2697 - iTemp11
  2697 - iTemp12
  2707 - itemp register
  2697 - iTemp13
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x68 (004F6C52).
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x69 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6A (004F6C52).
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6B (004F6C52).
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: =
deassignLRs
freeReg
freeReg
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (9) }
getRegGpr
allocReg of type REG_GPR
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: >
deassignLRs
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: -
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: CAST
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (9) (10) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6C (004F6C52).
  2378 - 
positionRegs
  2394 - 
  op: SEND
deassignLRs
freeReg
freeReg
freeReg
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: =
deassignLRs
freeReg
freeReg
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (14) }
getRegGpr
allocReg of type REG_GPR
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: >
deassignLRs
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: -
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
freeReg
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l78:s1:k0:d0:s0)	 _entry($13) :
libreria_skybot.c(l78:s2:k1:d0:s0)		proc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
libreria_skybot.c(l78:s3:k2:d0:s0)	iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ] = recv _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
libreria_skybot.c(l78:s4:k3:d0:s0)	iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}[r0x6A r0x6B ] = recv _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
libreria_skybot.c(l81:s6:k49:d0:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] := iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}[r0x6A r0x6B ]
libreria_skybot.c(l81:s7:k4:d1:s0)	 _whilecontinue_0($1) :
libreria_skybot.c(l81:s8:k5:d1:s0)		iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] > 0xff {literal-unsigned-int}
libreria_skybot.c(l81:s9:k6:d1:s0)		if iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_0($3)
libreria_skybot.c(l83:s10:k9:d1:s0)		send 0xff {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l83:s11:k10:d1:s0)		iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l84:s12:k11:d1:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] - 0xff {literal-unsigned-int}
libreria_skybot.c(l84:s13:k13:d1:s0)		 goto _whilecontinue_0($1)
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (49) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (49) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) }

----------------------------------------------------------------
libreria_skybot.c(l81:s5:k47:d0:s0)	 preHeaderLbl0($15) :
libreria_skybot.c(l81:s6:k49:d0:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] := iTemp1 [k4 lr4:6 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_centesimas_1_1}[r0x6A r0x6B ]
libreria_skybot.c(l81:s7:k4:d1:s0)	 _whilecontinue_0($1) :
libreria_skybot.c(l81:s8:k5:d1:s0)		iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] > 0xff {literal-unsigned-int}
libreria_skybot.c(l81:s9:k6:d1:s0)		if iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_0($3)
libreria_skybot.c(l83:s10:k9:d1:s0)		send 0xff {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l83:s11:k10:d1:s0)		iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l84:s12:k11:d1:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] - 0xff {literal-unsigned-int}
libreria_skybot.c(l84:s13:k13:d1:s0)		 goto _whilecontinue_0($1)
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (5) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (5) (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l81:s7:k4:d1:s0)	 _whilecontinue_0($1) :
libreria_skybot.c(l81:s8:k5:d1:s0)		iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] > 0xff {literal-unsigned-int}
libreria_skybot.c(l81:s9:k6:d1:s0)		if iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_0($3)
libreria_skybot.c(l83:s10:k9:d1:s0)		send 0xff {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l83:s11:k10:d1:s0)		iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l84:s12:k11:d1:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] - 0xff {literal-unsigned-int}
libreria_skybot.c(l84:s13:k13:d1:s0)		 goto _whilecontinue_0($1)
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 13
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (11) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (10) (11) (12) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (10) (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l83:s10:k9:d1:s0)		send 0xff {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l83:s11:k10:d1:s0)		iTemp3 [k8 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l84:s12:k11:d1:s0)		iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] = iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ] - 0xff {literal-unsigned-int}
libreria_skybot.c(l84:s13:k13:d1:s0)		 goto _whilecontinue_0($1)
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block loopExitLbl2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 14 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (51) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (49) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (49) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (11) (49) }

----------------------------------------------------------------
libreria_skybot.c(l84:s14:k50:d0:s0)	 loopExitLbl2($20) :
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _whilebreak_0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 15 , last iCode = 18
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (15) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (15) (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (49) (51) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (11) (15) (17) (49) }

----------------------------------------------------------------
libreria_skybot.c(l84:s15:k14:d0:s0)	 _whilebreak_0($3) :
libreria_skybot.c(l86:s16:k15:d0:s0)		iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = (unsigned-char)iTemp4 [k9 lr6:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x6A r0x6B ]
libreria_skybot.c(l86:s17:k16:d0:s0)		send iTemp5 [k10 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ]{argreg = 1}
libreria_skybot.c(l86:s18:k17:d0:s0)		iTemp6 [k11 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block preHeaderLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 19 , last iCode = 20
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (52) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (52) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (5) (10) (11) (15) (17) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l88:s19:k48:d0:s0)	 preHeaderLbl1($17) :
libreria_skybot.c(l88:s20:k52:d0:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] := iTemp0 [k2 lr3:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _PausaTiempo_segundos_1_1}[r0x68 r0x69 ]
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 21 , last iCode = 23
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (19) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (19) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (19) (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l88:s21:k18:d1:s0)	 _whilecontinue_1($4) :
libreria_skybot.c(l88:s22:k19:d1:s0)		iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] > 0x2 {literal-unsigned-int}
libreria_skybot.c(l88:s23:k20:d1:s0)		if iTemp7 [k12 lr22:23 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilebreak_1($6)
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 9 : bbnum = 8 1st iCode = 24 , last iCode = 27
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (25) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (24) (25) (26) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (24) (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l90:s24:k23:d1:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l90:s25:k24:d1:s0)		iTemp8 [k13 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l91:s26:k25:d1:s0)		iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] - 0x2 {literal-unsigned-int}
libreria_skybot.c(l91:s27:k27:d1:s0)		 goto _whilecontinue_1($4)
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block loopExitLbl3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 10 : bbnum = 9 1st iCode = 28 , last iCode = 28
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (54) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (2) (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (26) (49) (51) (52) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) (52) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (52) }

----------------------------------------------------------------
libreria_skybot.c(l91:s28:k53:d0:s0)	 loopExitLbl3($21) :
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _whilebreak_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 11 : bbnum = 10 1st iCode = 29 , last iCode = 31
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (29) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (29) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (29) (52) }

----------------------------------------------------------------
libreria_skybot.c(l91:s29:k28:d0:s0)	 _whilebreak_1($6) :
libreria_skybot.c(l93:s30:k29:d0:s0)		iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x2 {literal-unsigned-int}
libreria_skybot.c(l93:s31:k30:d0:s0)		if iTemp10 [k15 lr30:31 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_1($10)
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 12 : bbnum = 11 1st iCode = 32 , last iCode = 34
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (34) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (34) }

----------------------------------------------------------------
libreria_skybot.c(l94:s32:k33:d0:s0)		send 0xc8 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l94:s33:k34:d0:s0)		iTemp11 [k16 lr33:33 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l94:s34:k35:d0:s0)		 goto _return($12)
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _iffalse_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 13 : bbnum = 12 1st iCode = 35 , last iCode = 37
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (37) }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (37) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (25) (37) (52) }

----------------------------------------------------------------
libreria_skybot.c(l94:s35:k36:d0:s0)	 _iffalse_1($10) :
libreria_skybot.c(l96:s36:k37:d0:s0)		iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp9 [k14 lr20:36 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}[r0x68 r0x69 ] == 0x1 {literal-unsigned-int}
libreria_skybot.c(l96:s37:k38:d0:s0)		if iTemp12 [k17 lr36:37 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 14 : bbnum = 13 1st iCode = 38 , last iCode = 39
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :bitvector Size = 55 bSize = 7
Bits on { (42) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (37) (42) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (42) }

----------------------------------------------------------------
libreria_skybot.c(l97:s38:k41:d0:s0)		send 0x64 {literal-unsigned-char}{argreg = 1}
libreria_skybot.c(l97:s39:k42:d0:s0)		iTemp13 [k18 lr39:39 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _delay0 [k7 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 15 : bbnum = 14 1st iCode = 40 , last iCode = 41
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 55 bSize = 7
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (37) (42) (49) (51) (52) (54) }

outDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { (3) (5) (10) (11) (12) (15) (17) (19) (24) (25) (29) (34) (37) (42) (49) (51) (52) (54) }

usesDefs Set bitvector :bitvector Size = 55 bSize = 7
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l97:s40:k45:d0:s0)	 _return($12) :
libreria_skybot.c(l97:s41:k46:d0:s0)		eproc _PausaTiempo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-int, unsigned-int) }
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l117:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l117:s2:k1:d0:s0)		proc _Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l120:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1c {literal-unsigned-char}
libreria_skybot.c(l121:s4:k3:d0:s0)		ret

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l121:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l121:s6:k5:d0:s0)		eproc _Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1c {literal-unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _PORTB (004F829D).
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1c {literal-unsigned-char}
  left:_Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
packRegisters
  left:_Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l117:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l117:s2:k1:d0:s0)		proc _Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l120:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1c {literal-unsigned-char}
libreria_skybot.c(l121:s4:k3:d0:s0)		ret
libreria_skybot.c(l121:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l121:s6:k5:d0:s0)		eproc _Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l121:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l121:s6:k5:d0:s0)		eproc _Avanzar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l139:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l139:s2:k1:d0:s0)		proc _GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l142:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1e {literal-unsigned-char}
libreria_skybot.c(l143:s4:k3:d0:s0)		ret

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l143:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l143:s6:k5:d0:s0)		eproc _GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1e {literal-unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1e {literal-unsigned-char}
  left:_GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
packRegisters
  left:_GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l139:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l139:s2:k1:d0:s0)		proc _GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l142:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1e {literal-unsigned-char}
libreria_skybot.c(l143:s4:k3:d0:s0)		ret
libreria_skybot.c(l143:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l143:s6:k5:d0:s0)		eproc _GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l143:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l143:s6:k5:d0:s0)		eproc _GirarIzq [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l161:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l161:s2:k1:d0:s0)		proc _GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l164:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x14 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l164:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l164:s5:k4:d0:s0)		eproc _GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x14 {literal-unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x14 {literal-unsigned-char}
  left:_GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l161:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l161:s2:k1:d0:s0)		proc _GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l164:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x14 {literal-unsigned-char}
libreria_skybot.c(l164:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l164:s5:k4:d0:s0)		eproc _GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l164:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l164:s5:k4:d0:s0)		eproc _GirarDer [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l182:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l182:s2:k1:d0:s0)		proc _Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l185:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x16 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l185:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l185:s5:k4:d0:s0)		eproc _Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x16 {literal-unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x16 {literal-unsigned-char}
  left:_Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l182:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l182:s2:k1:d0:s0)		proc _Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l185:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x16 {literal-unsigned-char}
libreria_skybot.c(l185:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l185:s5:k4:d0:s0)		eproc _Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l185:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l185:s5:k4:d0:s0)		eproc _Retroceder [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l203:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l203:s2:k1:d0:s0)		proc _Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l206:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l206:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l206:s5:k4:d0:s0)		eproc _Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
  left:_Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l203:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l203:s2:k1:d0:s0)		proc _Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l206:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libreria_skybot.c(l206:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l206:s5:k4:d0:s0)		eproc _Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l206:s4:k3:d0:s0)	 _return($1) :
libreria_skybot.c(l206:s5:k4:d0:s0)		eproc _Parar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l224:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l224:s2:k1:d0:s0)		proc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l226:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l226:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l226:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_2($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l226:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l226:s7:k8:d0:s0)	 _iffalse_2($2) :
libreria_skybot.c(l227:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l227:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l227:s10:k11:d0:s0)		eproc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6D (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l224:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l224:s2:k1:d0:s0)		proc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l226:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6D ] = call _LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l226:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6D ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l226:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_2($2)
libreria_skybot.c(l226:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l226:s7:k8:d0:s0)	 _iffalse_2($2) :
libreria_skybot.c(l227:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l227:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l227:s10:k11:d0:s0)		eproc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l226:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l226:s7:k8:d0:s0)	 _iffalse_2($2) :
libreria_skybot.c(l227:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l227:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l227:s10:k11:d0:s0)		eproc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l226:s7:k8:d0:s0)	 _iffalse_2($2) :
libreria_skybot.c(l227:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l227:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l227:s10:k11:d0:s0)		eproc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l227:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l227:s10:k11:d0:s0)		eproc _SensorIR_Izq_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l245:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l245:s2:k1:d0:s0)		proc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l247:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l247:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l247:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_3($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l247:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l247:s7:k8:d0:s0)	 _iffalse_3($2) :
libreria_skybot.c(l248:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l248:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l248:s10:k11:d0:s0)		eproc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #97 reg = STK07  key 52, rIdx = 120, size 1
  -- #98 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #99 reg = STK08  key 53, rIdx = 119, size 1
  -- #100 reg = STK09  key 55, rIdx = 118, size 1
  -- #101 reg = INDF  key 56, rIdx = 0, size 1
  -- #102 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6E (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l245:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l245:s2:k1:d0:s0)		proc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l247:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6E ] = call _LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l247:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6E ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l247:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_3($2)
libreria_skybot.c(l247:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l247:s7:k8:d0:s0)	 _iffalse_3($2) :
libreria_skybot.c(l248:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l248:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l248:s10:k11:d0:s0)		eproc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l247:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l247:s7:k8:d0:s0)	 _iffalse_3($2) :
libreria_skybot.c(l248:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l248:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l248:s10:k11:d0:s0)		eproc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l247:s7:k8:d0:s0)	 _iffalse_3($2) :
libreria_skybot.c(l248:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l248:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l248:s10:k11:d0:s0)		eproc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l248:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l248:s10:k11:d0:s0)		eproc _SensorIR_Der_Lee_Negro [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l266:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l266:s2:k1:d0:s0)		proc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l268:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l268:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_4($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l268:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l268:s6:k7:d0:s0)	 _iffalse_4($2) :
libreria_skybot.c(l269:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l269:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l269:s9:k10:d0:s0)		eproc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #97 reg = STK07  key 52, rIdx = 120, size 1
  -- #98 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #99 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #100 reg = STK08  key 53, rIdx = 119, size 1
  -- #101 reg = STK09  key 55, rIdx = 118, size 1
  -- #102 reg = INDF  key 56, rIdx = 0, size 1
  -- #103 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6F (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l266:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l266:s2:k1:d0:s0)		proc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l268:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6F ] = call _LeerSensor3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l268:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6F ] != 0 goto _iffalse_4($2)
libreria_skybot.c(l268:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l268:s6:k7:d0:s0)	 _iffalse_4($2) :
libreria_skybot.c(l269:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l269:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l269:s9:k10:d0:s0)		eproc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l268:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l268:s6:k7:d0:s0)	 _iffalse_4($2) :
libreria_skybot.c(l269:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l269:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l269:s9:k10:d0:s0)		eproc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l268:s6:k7:d0:s0)	 _iffalse_4($2) :
libreria_skybot.c(l269:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l269:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l269:s9:k10:d0:s0)		eproc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l269:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l269:s9:k10:d0:s0)		eproc _SensorIR_Izq_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l287:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l287:s2:k1:d0:s0)		proc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l289:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l289:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_5($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l289:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_5 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l289:s6:k7:d0:s0)	 _iffalse_5($2) :
libreria_skybot.c(l290:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l290:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l290:s9:k10:d0:s0)		eproc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #88 reg = STK05  key 50, rIdx = 122, size 1
  -- #89 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #90 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #91 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #92 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #97 reg = STK07  key 52, rIdx = 120, size 1
  -- #98 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #99 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #100 reg = STK08  key 53, rIdx = 119, size 1
  -- #101 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #102 reg = STK09  key 55, rIdx = 118, size 1
  -- #103 reg = INDF  key 56, rIdx = 0, size 1
  -- #104 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x70 (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l287:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l287:s2:k1:d0:s0)		proc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l289:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x70 ] = call _LeerSensor4 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l289:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x70 ] != 0 goto _iffalse_5($2)
libreria_skybot.c(l289:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l289:s6:k7:d0:s0)	 _iffalse_5($2) :
libreria_skybot.c(l290:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l290:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l290:s9:k10:d0:s0)		eproc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l289:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l289:s6:k7:d0:s0)	 _iffalse_5($2) :
libreria_skybot.c(l290:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l290:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l290:s9:k10:d0:s0)		eproc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_5 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l289:s6:k7:d0:s0)	 _iffalse_5($2) :
libreria_skybot.c(l290:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l290:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l290:s9:k10:d0:s0)		eproc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l290:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l290:s9:k10:d0:s0)		eproc _SensorIR_Der_Lee_Blanco [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (4) }

----------------------------------------------------------------
libreria_skybot.c(l314:s1:k0:d0:s0)	 _entry($12) :
libreria_skybot.c(l314:s2:k1:d0:s0)		proc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l316:s3:k2:d0:s0)		iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1} := 0x0 {literal-unsigned-char}
libreria_skybot.c(l316:s4:k3:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1} := 0x0 {literal-unsigned-char}
libreria_skybot.c(l318:s5:k4:d0:s0)		iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _SensorIR_Izq_Lee_Negro [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l318:s6:k5:d0:s0)		if iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _iffalse_6($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (8) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (4) (8) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l318:s7:k8:d0:s0)		iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1} := 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_6 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 8 , last iCode = 10
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (10) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (10) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (10) }

----------------------------------------------------------------
libreria_skybot.c(l318:s8:k9:d0:s0)	 _iffalse_6($2) :
libreria_skybot.c(l319:s9:k10:d0:s0)		iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _SensorIR_Der_Lee_Negro [k8 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l319:s10:k11:d0:s0)		if iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _iffalse_7($4)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (14) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (14) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l319:s11:k14:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1} := 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_7 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 12 , last iCode = 13
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (8) }

----------------------------------------------------------------
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1} == 0 goto _iffalse_9($8)

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 14 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (14) }

----------------------------------------------------------------
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1} == 0 goto _iffalse_9($8)

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 15 , last iCode = 15
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_9 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 16 , last iCode = 17
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (14) }

----------------------------------------------------------------
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1} == 0 goto _ifend_9($9)

----------------------------------------------------------------
Basic Block _eBBlock4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 18 , last iCode = 18
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _ifend_9 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 10 : bbnum = 9 1st iCode = 19 , last iCode = 20
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 11 : bbnum = 10 1st iCode = 21 , last iCode = 22
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
packRegsForAssign
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
  left:
  right:0x0 {literal-unsigned-char}
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
  left:
  right:0x0 {literal-unsigned-char}
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
  left:
  right:0x0 {literal-unsigned-char}
  left:_LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_SensorIR_Izq_Lee_Negro [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
  left:
  right:0x1 {literal-unsigned-char}
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
  left:
  right:0x1 {literal-unsigned-char}
  result:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_SensorIR_Der_Lee_Negro [k8 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
  left:
  right:0x1 {literal-unsigned-char}
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
  left:
  right:0x1 {literal-unsigned-char}
  result:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x27  key 33, rIdx = 39, size 1
  -- #34 reg = r0x36  key 33, rIdx = 54, size 1
  -- #35 reg = r0x45  key 33, rIdx = 69, size 1
  -- #36 reg = r0x54  key 33, rIdx = 84, size 1
  -- #37 reg = r0x63  key 33, rIdx = 99, size 1
  -- #38 reg = r0x28  key 34, rIdx = 40, size 1
  -- #39 reg = r0x37  key 34, rIdx = 55, size 1
  -- #40 reg = r0x46  key 34, rIdx = 70, size 1
  -- #41 reg = r0x55  key 34, rIdx = 85, size 1
  -- #42 reg = r0x64  key 34, rIdx = 100, size 1
  -- #43 reg = r0x29  key 35, rIdx = 41, size 1
  -- #44 reg = r0x38  key 35, rIdx = 56, size 1
  -- #45 reg = r0x47  key 35, rIdx = 71, size 1
  -- #46 reg = r0x56  key 35, rIdx = 86, size 1
  -- #47 reg = r0x65  key 35, rIdx = 101, size 1
  -- #48 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #49 reg = r0x39  key 36, rIdx = 57, size 1
  -- #50 reg = r0x48  key 36, rIdx = 72, size 1
  -- #51 reg = r0x57  key 36, rIdx = 87, size 1
  -- #52 reg = r0x66  key 36, rIdx = 102, size 1
  -- #53 reg = r0x49  key 37, rIdx = 73, size 1
  -- #54 reg = r0x58  key 37, rIdx = 88, size 1
  -- #55 reg = r0x67  key 37, rIdx = 103, size 1
  -- #56 reg = r0x59  key 38, rIdx = 89, size 1
  -- #57 reg = r0x68  key 38, rIdx = 104, size 1
  -- #58 reg = r0x69  key 39, rIdx = 105, size 1
  -- #59 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #60 reg = STK00  key 45, rIdx = 127, size 1
  -- #61 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #62 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #63 reg = STK01  key 46, rIdx = 126, size 1
  -- #64 reg = STK10  key 46, rIdx = 117, size 1
  -- #65 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #66 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #67 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #68 reg = STK02  key 47, rIdx = 125, size 1
  -- #69 reg = STK11  key 47, rIdx = 116, size 1
  -- #70 reg = INTCON  key 47, rIdx = 11, size 1
  -- #71 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #72 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #73 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #74 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #75 reg = STK03  key 48, rIdx = 124, size 1
  -- #76 reg = STK12  key 48, rIdx = 115, size 1
  -- #77 reg = PCL  key 48, rIdx = 2, size 1
  -- #78 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #79 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #80 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #81 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #82 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #83 reg = STK04  key 49, rIdx = 123, size 1
  -- #84 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #85 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #86 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #87 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #88 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #89 reg = STK05  key 50, rIdx = 122, size 1
  -- #90 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #91 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #92 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #93 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #94 reg = STK06  key 51, rIdx = 121, size 1
  -- #95 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #96 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #97 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #98 reg = STK07  key 52, rIdx = 120, size 1
  -- #99 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #100 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #101 reg = STK08  key 53, rIdx = 119, size 1
  -- #102 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #103 reg = STK09  key 55, rIdx = 118, size 1
  -- #104 reg = INDF  key 56, rIdx = 0, size 1
  -- #105 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x71 (004F6C52).
  2378 - 
  2394 - 
  op: =
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x72 (004F6C52).
  2378 - 
  2394 - 
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (4) (7) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x73 (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
  op: =
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (2) (4) (9) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: IFX
deassignLRs
  op: =
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: IFX
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: IFX
deassignLRs
  op: RETURN
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (4) }

----------------------------------------------------------------
libreria_skybot.c(l314:s1:k0:d0:s0)	 _entry($12) :
libreria_skybot.c(l314:s2:k1:d0:s0)		proc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l316:s3:k2:d0:s0)		iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] := 0x0 {literal-unsigned-char}
libreria_skybot.c(l316:s4:k3:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] := 0x0 {literal-unsigned-char}
libreria_skybot.c(l318:s5:k4:d0:s0)		iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] = call _SensorIR_Izq_Lee_Negro [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l318:s6:k5:d0:s0)		if iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] == 0 goto _iffalse_6($2)
libreria_skybot.c(l318:s7:k8:d0:s0)		iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l318:s8:k9:d0:s0)	 _iffalse_6($2) :
libreria_skybot.c(l319:s9:k10:d0:s0)		iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] = call _SensorIR_Der_Lee_Negro [k8 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l319:s10:k11:d0:s0)		if iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] == 0 goto _iffalse_7($4)
libreria_skybot.c(l319:s11:k14:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (8) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (4) (8) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l318:s7:k8:d0:s0)		iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l318:s8:k9:d0:s0)	 _iffalse_6($2) :
libreria_skybot.c(l319:s9:k10:d0:s0)		iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] = call _SensorIR_Der_Lee_Negro [k8 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l319:s10:k11:d0:s0)		if iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] == 0 goto _iffalse_7($4)
libreria_skybot.c(l319:s11:k14:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_6 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 8 , last iCode = 10
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (10) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (10) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (10) }

----------------------------------------------------------------
libreria_skybot.c(l318:s8:k9:d0:s0)	 _iffalse_6($2) :
libreria_skybot.c(l319:s9:k10:d0:s0)		iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] = call _SensorIR_Der_Lee_Negro [k8 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l319:s10:k11:d0:s0)		if iTemp3 [k9 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x73 ] == 0 goto _iffalse_7($4)
libreria_skybot.c(l319:s11:k14:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (14) }

local defines bitVector :bitvector Size = 34 bSize = 5
Bits on { (14) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l319:s11:k14:d0:s0)		iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] := 0x1 {literal-unsigned-char}
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_7 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 12 , last iCode = 13
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (8) }

----------------------------------------------------------------
libreria_skybot.c(l319:s12:k15:d0:s0)	 _iffalse_7($4) :
libreria_skybot.c(l321:s13:k16:d0:s0)		if iTemp0 [k2 lr3:13 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sI_1_1}[r0x71 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 14 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (14) }

----------------------------------------------------------------
libreria_skybot.c(l321:s14:k19:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _iffalse_9($8)
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 15 , last iCode = 15
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l321:s15:k22:d0:s0)		ret 0x3 {literal-unsigned-char}
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_9 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 16 , last iCode = 17
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (3) (14) }

----------------------------------------------------------------
libreria_skybot.c(l321:s16:k24:d0:s0)	 _iffalse_9($8) :
libreria_skybot.c(l322:s17:k25:d0:s0)		if iTemp1 [k4 lr4:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _LeerInfrarrojos_sD_1_1}[r0x72 ] == 0 goto _ifend_9($9)
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 18 , last iCode = 18
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l322:s18:k28:d0:s0)		ret 0x2 {literal-unsigned-char}
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _ifend_9 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 10 : bbnum = 9 1st iCode = 19 , last iCode = 20
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l322:s19:k30:d0:s0)	 _ifend_9($9) :
libreria_skybot.c(l323:s20:k31:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 11 : bbnum = 10 1st iCode = 21 , last iCode = 22
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 34 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

outDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { (2) (3) (4) (8) (10) (14) }

usesDefs Set bitvector :bitvector Size = 34 bSize = 5
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l323:s21:k32:d0:s0)	 _return($11) :
libreria_skybot.c(l323:s22:k33:d0:s0)		eproc _LeerInfrarrojos [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x71
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x71
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x71
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l340:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l340:s2:k1:d0:s0)		proc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l342:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l342:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l342:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_10($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l342:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_10 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l342:s7:k8:d0:s0)	 _iffalse_10($2) :
libreria_skybot.c(l343:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l343:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l343:s10:k11:d0:s0)		eproc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #52 reg = r0x39  key 36, rIdx = 57, size 1
  -- #53 reg = r0x48  key 36, rIdx = 72, size 1
  -- #54 reg = r0x57  key 36, rIdx = 87, size 1
  -- #55 reg = r0x66  key 36, rIdx = 102, size 1
  -- #56 reg = r0x49  key 37, rIdx = 73, size 1
  -- #57 reg = r0x58  key 37, rIdx = 88, size 1
  -- #58 reg = r0x67  key 37, rIdx = 103, size 1
  -- #59 reg = r0x59  key 38, rIdx = 89, size 1
  -- #60 reg = r0x68  key 38, rIdx = 104, size 1
  -- #61 reg = r0x69  key 39, rIdx = 105, size 1
  -- #62 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #63 reg = STK00  key 45, rIdx = 127, size 1
  -- #64 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #65 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #66 reg = STK01  key 46, rIdx = 126, size 1
  -- #67 reg = STK10  key 46, rIdx = 117, size 1
  -- #68 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #69 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #70 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #71 reg = STK02  key 47, rIdx = 125, size 1
  -- #72 reg = STK11  key 47, rIdx = 116, size 1
  -- #73 reg = INTCON  key 47, rIdx = 11, size 1
  -- #74 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #75 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #76 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #77 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #78 reg = STK03  key 48, rIdx = 124, size 1
  -- #79 reg = STK12  key 48, rIdx = 115, size 1
  -- #80 reg = PCL  key 48, rIdx = 2, size 1
  -- #81 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #82 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #83 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #84 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #85 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #86 reg = STK04  key 49, rIdx = 123, size 1
  -- #87 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #88 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #89 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #90 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #91 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #92 reg = STK05  key 50, rIdx = 122, size 1
  -- #93 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #94 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #95 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #96 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #97 reg = STK06  key 51, rIdx = 121, size 1
  -- #98 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #99 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #100 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #101 reg = STK07  key 52, rIdx = 120, size 1
  -- #102 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #103 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #104 reg = STK08  key 53, rIdx = 119, size 1
  -- #105 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #106 reg = STK09  key 55, rIdx = 118, size 1
  -- #107 reg = INDF  key 56, rIdx = 0, size 1
  -- #108 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x74 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l340:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l340:s2:k1:d0:s0)		proc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l342:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x74 ] = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l342:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x74 ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l342:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_10($2)
libreria_skybot.c(l342:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l342:s7:k8:d0:s0)	 _iffalse_10($2) :
libreria_skybot.c(l343:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l343:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l343:s10:k11:d0:s0)		eproc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l342:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l342:s7:k8:d0:s0)	 _iffalse_10($2) :
libreria_skybot.c(l343:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l343:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l343:s10:k11:d0:s0)		eproc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_10 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l342:s7:k8:d0:s0)	 _iffalse_10($2) :
libreria_skybot.c(l343:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l343:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l343:s10:k11:d0:s0)		eproc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l343:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l343:s10:k11:d0:s0)		eproc _LeerSensor1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l360:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l360:s2:k1:d0:s0)		proc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l362:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x20 {literal-unsigned-char}
libreria_skybot.c(l362:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l362:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_11($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l362:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_11 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l362:s7:k8:d0:s0)	 _iffalse_11($2) :
libreria_skybot.c(l363:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l363:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l363:s10:k11:d0:s0)		eproc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x49  key 37, rIdx = 73, size 1
  -- #58 reg = r0x58  key 37, rIdx = 88, size 1
  -- #59 reg = r0x67  key 37, rIdx = 103, size 1
  -- #60 reg = r0x59  key 38, rIdx = 89, size 1
  -- #61 reg = r0x68  key 38, rIdx = 104, size 1
  -- #62 reg = r0x69  key 39, rIdx = 105, size 1
  -- #63 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #64 reg = STK00  key 45, rIdx = 127, size 1
  -- #65 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #66 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #67 reg = STK01  key 46, rIdx = 126, size 1
  -- #68 reg = STK10  key 46, rIdx = 117, size 1
  -- #69 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #70 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #71 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #72 reg = STK02  key 47, rIdx = 125, size 1
  -- #73 reg = STK11  key 47, rIdx = 116, size 1
  -- #74 reg = INTCON  key 47, rIdx = 11, size 1
  -- #75 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #76 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #77 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #78 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #79 reg = STK03  key 48, rIdx = 124, size 1
  -- #80 reg = STK12  key 48, rIdx = 115, size 1
  -- #81 reg = PCL  key 48, rIdx = 2, size 1
  -- #82 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #83 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #84 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #85 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #86 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #87 reg = STK04  key 49, rIdx = 123, size 1
  -- #88 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #89 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #90 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #91 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #92 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #93 reg = STK05  key 50, rIdx = 122, size 1
  -- #94 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #95 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #96 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #97 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #98 reg = STK06  key 51, rIdx = 121, size 1
  -- #99 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #100 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #101 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #102 reg = STK07  key 52, rIdx = 120, size 1
  -- #103 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #104 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #105 reg = STK08  key 53, rIdx = 119, size 1
  -- #106 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #107 reg = STK09  key 55, rIdx = 118, size 1
  -- #108 reg = INDF  key 56, rIdx = 0, size 1
  -- #109 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x75 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l360:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l360:s2:k1:d0:s0)		proc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l362:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x75 ] = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x20 {literal-unsigned-char}
libreria_skybot.c(l362:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x75 ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l362:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_11($2)
libreria_skybot.c(l362:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l362:s7:k8:d0:s0)	 _iffalse_11($2) :
libreria_skybot.c(l363:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l363:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l363:s10:k11:d0:s0)		eproc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l362:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l362:s7:k8:d0:s0)	 _iffalse_11($2) :
libreria_skybot.c(l363:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l363:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l363:s10:k11:d0:s0)		eproc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_11 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l362:s7:k8:d0:s0)	 _iffalse_11($2) :
libreria_skybot.c(l363:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l363:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l363:s10:k11:d0:s0)		eproc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l363:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l363:s10:k11:d0:s0)		eproc _LeerSensor2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l380:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l380:s2:k1:d0:s0)		proc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l382:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x40 {literal-unsigned-char}
libreria_skybot.c(l382:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l382:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_12($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l382:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_12 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l382:s7:k8:d0:s0)	 _iffalse_12($2) :
libreria_skybot.c(l383:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l383:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l383:s10:k11:d0:s0)		eproc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x59  key 38, rIdx = 89, size 1
  -- #62 reg = r0x68  key 38, rIdx = 104, size 1
  -- #63 reg = r0x69  key 39, rIdx = 105, size 1
  -- #64 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #65 reg = STK00  key 45, rIdx = 127, size 1
  -- #66 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #67 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #68 reg = STK01  key 46, rIdx = 126, size 1
  -- #69 reg = STK10  key 46, rIdx = 117, size 1
  -- #70 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #71 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #72 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #73 reg = STK02  key 47, rIdx = 125, size 1
  -- #74 reg = STK11  key 47, rIdx = 116, size 1
  -- #75 reg = INTCON  key 47, rIdx = 11, size 1
  -- #76 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #77 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #78 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #79 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #80 reg = STK03  key 48, rIdx = 124, size 1
  -- #81 reg = STK12  key 48, rIdx = 115, size 1
  -- #82 reg = PCL  key 48, rIdx = 2, size 1
  -- #83 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #84 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #85 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #86 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #87 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #88 reg = STK04  key 49, rIdx = 123, size 1
  -- #89 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #90 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #91 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #92 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #93 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #94 reg = STK05  key 50, rIdx = 122, size 1
  -- #95 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #96 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #97 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #98 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #99 reg = STK06  key 51, rIdx = 121, size 1
  -- #100 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #101 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #102 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #103 reg = STK07  key 52, rIdx = 120, size 1
  -- #104 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #105 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #106 reg = STK08  key 53, rIdx = 119, size 1
  -- #107 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #108 reg = STK09  key 55, rIdx = 118, size 1
  -- #109 reg = INDF  key 56, rIdx = 0, size 1
  -- #110 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x76 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l380:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l380:s2:k1:d0:s0)		proc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l382:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x76 ] = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x40 {literal-unsigned-char}
libreria_skybot.c(l382:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x76 ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l382:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_12($2)
libreria_skybot.c(l382:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l382:s7:k8:d0:s0)	 _iffalse_12($2) :
libreria_skybot.c(l383:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l383:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l383:s10:k11:d0:s0)		eproc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l382:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l382:s7:k8:d0:s0)	 _iffalse_12($2) :
libreria_skybot.c(l383:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l383:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l383:s10:k11:d0:s0)		eproc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_12 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l382:s7:k8:d0:s0)	 _iffalse_12($2) :
libreria_skybot.c(l383:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l383:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l383:s10:k11:d0:s0)		eproc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l383:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l383:s10:k11:d0:s0)		eproc _LeerSensor3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l400:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l400:s2:k1:d0:s0)		proc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l402:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x80 {literal-unsigned-char}
libreria_skybot.c(l402:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l402:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_13($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l402:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_13 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l402:s7:k8:d0:s0)	 _iffalse_13($2) :
libreria_skybot.c(l403:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l403:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l403:s10:k11:d0:s0)		eproc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x69  key 39, rIdx = 105, size 1
  -- #65 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #66 reg = STK00  key 45, rIdx = 127, size 1
  -- #67 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #68 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #69 reg = STK01  key 46, rIdx = 126, size 1
  -- #70 reg = STK10  key 46, rIdx = 117, size 1
  -- #71 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #72 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #73 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #74 reg = STK02  key 47, rIdx = 125, size 1
  -- #75 reg = STK11  key 47, rIdx = 116, size 1
  -- #76 reg = INTCON  key 47, rIdx = 11, size 1
  -- #77 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #78 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #79 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #80 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #81 reg = STK03  key 48, rIdx = 124, size 1
  -- #82 reg = STK12  key 48, rIdx = 115, size 1
  -- #83 reg = PCL  key 48, rIdx = 2, size 1
  -- #84 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #85 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #86 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #87 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #88 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #89 reg = STK04  key 49, rIdx = 123, size 1
  -- #90 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #91 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #92 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #93 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #94 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #95 reg = STK05  key 50, rIdx = 122, size 1
  -- #96 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #97 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #98 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #99 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #100 reg = STK06  key 51, rIdx = 121, size 1
  -- #101 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #102 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #103 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #104 reg = STK07  key 52, rIdx = 120, size 1
  -- #105 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #106 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #107 reg = STK08  key 53, rIdx = 119, size 1
  -- #108 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #109 reg = STK09  key 55, rIdx = 118, size 1
  -- #110 reg = INDF  key 56, rIdx = 0, size 1
  -- #111 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x77 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l400:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l400:s2:k1:d0:s0)		proc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l402:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x77 ] = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x80 {literal-unsigned-char}
libreria_skybot.c(l402:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x77 ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l402:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_13($2)
libreria_skybot.c(l402:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l402:s7:k8:d0:s0)	 _iffalse_13($2) :
libreria_skybot.c(l403:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l403:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l403:s10:k11:d0:s0)		eproc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l402:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l402:s7:k8:d0:s0)	 _iffalse_13($2) :
libreria_skybot.c(l403:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l403:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l403:s10:k11:d0:s0)		eproc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_13 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l402:s7:k8:d0:s0)	 _iffalse_13($2) :
libreria_skybot.c(l403:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l403:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l403:s10:k11:d0:s0)		eproc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l403:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l403:s10:k11:d0:s0)		eproc _LeerSensor4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l420:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l420:s2:k1:d0:s0)		proc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l422:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerBumperIzquierdo [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l422:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l422:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_14($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l422:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_14 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l422:s7:k8:d0:s0)	 _iffalse_14($2) :
libreria_skybot.c(l423:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l423:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l423:s10:k11:d0:s0)		eproc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerBumperIzquierdo [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x77  key 38, rIdx = 119, size 1
  -- #65 reg = r0x69  key 39, rIdx = 105, size 1
  -- #66 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #67 reg = STK00  key 45, rIdx = 127, size 1
  -- #68 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #69 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #70 reg = STK01  key 46, rIdx = 126, size 1
  -- #71 reg = STK10  key 46, rIdx = 117, size 1
  -- #72 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #73 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #74 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #75 reg = STK02  key 47, rIdx = 125, size 1
  -- #76 reg = STK11  key 47, rIdx = 116, size 1
  -- #77 reg = INTCON  key 47, rIdx = 11, size 1
  -- #78 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #79 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #80 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #81 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #82 reg = STK03  key 48, rIdx = 124, size 1
  -- #83 reg = STK12  key 48, rIdx = 115, size 1
  -- #84 reg = PCL  key 48, rIdx = 2, size 1
  -- #85 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #86 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #87 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #88 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #89 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #90 reg = STK04  key 49, rIdx = 123, size 1
  -- #91 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #92 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #93 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #94 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #95 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #96 reg = STK05  key 50, rIdx = 122, size 1
  -- #97 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #98 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #99 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #100 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #101 reg = STK06  key 51, rIdx = 121, size 1
  -- #102 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #103 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #104 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #105 reg = STK07  key 52, rIdx = 120, size 1
  -- #106 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #107 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #108 reg = STK08  key 53, rIdx = 119, size 1
  -- #109 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #110 reg = STK09  key 55, rIdx = 118, size 1
  -- #111 reg = INDF  key 56, rIdx = 0, size 1
  -- #112 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x78 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l420:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l420:s2:k1:d0:s0)		proc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l422:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x78 ] = call _LeerBumperIzquierdo [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l422:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x78 ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l422:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_14($2)
libreria_skybot.c(l422:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l422:s7:k8:d0:s0)	 _iffalse_14($2) :
libreria_skybot.c(l423:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l423:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l423:s10:k11:d0:s0)		eproc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l422:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l422:s7:k8:d0:s0)	 _iffalse_14($2) :
libreria_skybot.c(l423:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l423:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l423:s10:k11:d0:s0)		eproc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_14 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l422:s7:k8:d0:s0)	 _iffalse_14($2) :
libreria_skybot.c(l423:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l423:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l423:s10:k11:d0:s0)		eproc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l423:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l423:s10:k11:d0:s0)		eproc _Bumper_Izq_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l440:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l440:s2:k1:d0:s0)		proc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l442:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerBumperDerecho [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l442:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l442:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_15($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l442:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_15 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l442:s7:k8:d0:s0)	 _iffalse_15($2) :
libreria_skybot.c(l443:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l443:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l443:s10:k11:d0:s0)		eproc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerBumperDerecho [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x77  key 38, rIdx = 119, size 1
  -- #65 reg = r0x69  key 39, rIdx = 105, size 1
  -- #66 reg = r0x78  key 39, rIdx = 120, size 1
  -- #67 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #68 reg = STK00  key 45, rIdx = 127, size 1
  -- #69 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #70 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #71 reg = STK01  key 46, rIdx = 126, size 1
  -- #72 reg = STK10  key 46, rIdx = 117, size 1
  -- #73 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #74 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #75 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #76 reg = STK02  key 47, rIdx = 125, size 1
  -- #77 reg = STK11  key 47, rIdx = 116, size 1
  -- #78 reg = INTCON  key 47, rIdx = 11, size 1
  -- #79 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #80 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #81 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #82 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #83 reg = STK03  key 48, rIdx = 124, size 1
  -- #84 reg = STK12  key 48, rIdx = 115, size 1
  -- #85 reg = PCL  key 48, rIdx = 2, size 1
  -- #86 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #87 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #88 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #89 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #90 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #91 reg = STK04  key 49, rIdx = 123, size 1
  -- #92 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #93 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #94 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #95 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #96 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #97 reg = STK05  key 50, rIdx = 122, size 1
  -- #98 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #99 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #100 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #101 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #102 reg = STK06  key 51, rIdx = 121, size 1
  -- #103 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #104 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #105 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #106 reg = STK07  key 52, rIdx = 120, size 1
  -- #107 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #108 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #109 reg = STK08  key 53, rIdx = 119, size 1
  -- #110 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #111 reg = STK09  key 55, rIdx = 118, size 1
  -- #112 reg = INDF  key 56, rIdx = 0, size 1
  -- #113 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x79 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l440:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l440:s2:k1:d0:s0)		proc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l442:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x79 ] = call _LeerBumperDerecho [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l442:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x79 ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l442:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_15($2)
libreria_skybot.c(l442:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l442:s7:k8:d0:s0)	 _iffalse_15($2) :
libreria_skybot.c(l443:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l443:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l443:s10:k11:d0:s0)		eproc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l442:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l442:s7:k8:d0:s0)	 _iffalse_15($2) :
libreria_skybot.c(l443:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l443:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l443:s10:k11:d0:s0)		eproc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_15 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l442:s7:k8:d0:s0)	 _iffalse_15($2) :
libreria_skybot.c(l443:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l443:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l443:s10:k11:d0:s0)		eproc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l443:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l443:s10:k11:d0:s0)		eproc _Bumper_Der_esta_apretado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l461:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l461:s2:k1:d0:s0)		proc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l463:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerPuertoALinea3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l463:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l463:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_16($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l463:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_16 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l463:s7:k8:d0:s0)	 _iffalse_16($2) :
libreria_skybot.c(l464:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l464:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l464:s10:k11:d0:s0)		eproc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerPuertoALinea3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x77  key 38, rIdx = 119, size 1
  -- #65 reg = r0x69  key 39, rIdx = 105, size 1
  -- #66 reg = r0x78  key 39, rIdx = 120, size 1
  -- #67 reg = r0x79  key 40, rIdx = 121, size 1
  -- #68 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #69 reg = STK00  key 45, rIdx = 127, size 1
  -- #70 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #71 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #72 reg = STK01  key 46, rIdx = 126, size 1
  -- #73 reg = STK10  key 46, rIdx = 117, size 1
  -- #74 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #75 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #76 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #77 reg = STK02  key 47, rIdx = 125, size 1
  -- #78 reg = STK11  key 47, rIdx = 116, size 1
  -- #79 reg = INTCON  key 47, rIdx = 11, size 1
  -- #80 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #81 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #82 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #83 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #84 reg = STK03  key 48, rIdx = 124, size 1
  -- #85 reg = STK12  key 48, rIdx = 115, size 1
  -- #86 reg = PCL  key 48, rIdx = 2, size 1
  -- #87 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #88 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #89 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #90 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #91 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #92 reg = STK04  key 49, rIdx = 123, size 1
  -- #93 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #94 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #95 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #96 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #97 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #98 reg = STK05  key 50, rIdx = 122, size 1
  -- #99 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #100 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #101 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #102 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #103 reg = STK06  key 51, rIdx = 121, size 1
  -- #104 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #105 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #106 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #107 reg = STK07  key 52, rIdx = 120, size 1
  -- #108 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #109 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #110 reg = STK08  key 53, rIdx = 119, size 1
  -- #111 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #112 reg = STK09  key 55, rIdx = 118, size 1
  -- #113 reg = INDF  key 56, rIdx = 0, size 1
  -- #114 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7A (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l461:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l461:s2:k1:d0:s0)		proc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l463:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7A ] = call _LeerPuertoALinea3 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l463:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7A ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l463:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_16($2)
libreria_skybot.c(l463:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l463:s7:k8:d0:s0)	 _iffalse_16($2) :
libreria_skybot.c(l464:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l464:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l464:s10:k11:d0:s0)		eproc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l463:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l463:s7:k8:d0:s0)	 _iffalse_16($2) :
libreria_skybot.c(l464:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l464:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l464:s10:k11:d0:s0)		eproc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_16 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l463:s7:k8:d0:s0)	 _iffalse_16($2) :
libreria_skybot.c(l464:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l464:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l464:s10:k11:d0:s0)		eproc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l464:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l464:s10:k11:d0:s0)		eproc _LeerBumperIzquierdo [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l482:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l482:s2:k1:d0:s0)		proc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l484:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerPuertoALinea2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l484:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l484:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_17($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l484:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_17 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l484:s7:k8:d0:s0)	 _iffalse_17($2) :
libreria_skybot.c(l485:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l485:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l485:s10:k11:d0:s0)		eproc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerPuertoALinea2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x77  key 38, rIdx = 119, size 1
  -- #65 reg = r0x69  key 39, rIdx = 105, size 1
  -- #66 reg = r0x78  key 39, rIdx = 120, size 1
  -- #67 reg = r0x79  key 40, rIdx = 121, size 1
  -- #68 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #69 reg = STK00  key 45, rIdx = 127, size 1
  -- #70 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #71 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #72 reg = STK01  key 46, rIdx = 126, size 1
  -- #73 reg = STK10  key 46, rIdx = 117, size 1
  -- #74 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #75 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #76 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #77 reg = STK02  key 47, rIdx = 125, size 1
  -- #78 reg = STK11  key 47, rIdx = 116, size 1
  -- #79 reg = INTCON  key 47, rIdx = 11, size 1
  -- #80 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #81 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #82 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #83 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #84 reg = STK03  key 48, rIdx = 124, size 1
  -- #85 reg = STK12  key 48, rIdx = 115, size 1
  -- #86 reg = PCL  key 48, rIdx = 2, size 1
  -- #87 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #88 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #89 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #90 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #91 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #92 reg = STK04  key 49, rIdx = 123, size 1
  -- #93 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #94 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #95 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #96 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #97 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #98 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #99 reg = STK05  key 50, rIdx = 122, size 1
  -- #100 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #101 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #102 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #103 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #104 reg = STK06  key 51, rIdx = 121, size 1
  -- #105 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #106 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #107 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #108 reg = STK07  key 52, rIdx = 120, size 1
  -- #109 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #110 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #111 reg = STK08  key 53, rIdx = 119, size 1
  -- #112 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #113 reg = STK09  key 55, rIdx = 118, size 1
  -- #114 reg = INDF  key 56, rIdx = 0, size 1
  -- #115 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7B (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l482:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l482:s2:k1:d0:s0)		proc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l484:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7B ] = call _LeerPuertoALinea2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l484:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7B ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l484:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_17($2)
libreria_skybot.c(l484:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l484:s7:k8:d0:s0)	 _iffalse_17($2) :
libreria_skybot.c(l485:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l485:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l485:s10:k11:d0:s0)		eproc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l484:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l484:s7:k8:d0:s0)	 _iffalse_17($2) :
libreria_skybot.c(l485:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l485:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l485:s10:k11:d0:s0)		eproc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_17 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l484:s7:k8:d0:s0)	 _iffalse_17($2) :
libreria_skybot.c(l485:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l485:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l485:s10:k11:d0:s0)		eproc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l485:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l485:s10:k11:d0:s0)		eproc _LeerBumperDerecho [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l502:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l502:s2:k1:d0:s0)		proc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l504:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l504:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l504:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_18($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l504:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_18 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l504:s7:k8:d0:s0)	 _iffalse_18($2) :
libreria_skybot.c(l505:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l505:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l505:s10:k11:d0:s0)		eproc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = r0x70  key 31, rIdx = 112, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x71  key 32, rIdx = 113, size 1
  -- #34 reg = r0x27  key 33, rIdx = 39, size 1
  -- #35 reg = r0x36  key 33, rIdx = 54, size 1
  -- #36 reg = r0x45  key 33, rIdx = 69, size 1
  -- #37 reg = r0x54  key 33, rIdx = 84, size 1
  -- #38 reg = r0x63  key 33, rIdx = 99, size 1
  -- #39 reg = r0x72  key 33, rIdx = 114, size 1
  -- #40 reg = r0x28  key 34, rIdx = 40, size 1
  -- #41 reg = r0x37  key 34, rIdx = 55, size 1
  -- #42 reg = r0x46  key 34, rIdx = 70, size 1
  -- #43 reg = r0x55  key 34, rIdx = 85, size 1
  -- #44 reg = r0x64  key 34, rIdx = 100, size 1
  -- #45 reg = r0x73  key 34, rIdx = 115, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = r0x74  key 35, rIdx = 116, size 1
  -- #52 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #53 reg = r0x39  key 36, rIdx = 57, size 1
  -- #54 reg = r0x48  key 36, rIdx = 72, size 1
  -- #55 reg = r0x57  key 36, rIdx = 87, size 1
  -- #56 reg = r0x66  key 36, rIdx = 102, size 1
  -- #57 reg = r0x75  key 36, rIdx = 117, size 1
  -- #58 reg = r0x49  key 37, rIdx = 73, size 1
  -- #59 reg = r0x58  key 37, rIdx = 88, size 1
  -- #60 reg = r0x67  key 37, rIdx = 103, size 1
  -- #61 reg = r0x76  key 37, rIdx = 118, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x77  key 38, rIdx = 119, size 1
  -- #65 reg = r0x69  key 39, rIdx = 105, size 1
  -- #66 reg = r0x78  key 39, rIdx = 120, size 1
  -- #67 reg = r0x79  key 40, rIdx = 121, size 1
  -- #68 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #69 reg = STK00  key 45, rIdx = 127, size 1
  -- #70 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #71 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #72 reg = STK01  key 46, rIdx = 126, size 1
  -- #73 reg = STK10  key 46, rIdx = 117, size 1
  -- #74 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #75 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #76 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #77 reg = STK02  key 47, rIdx = 125, size 1
  -- #78 reg = STK11  key 47, rIdx = 116, size 1
  -- #79 reg = INTCON  key 47, rIdx = 11, size 1
  -- #80 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #81 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #82 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #83 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #84 reg = STK03  key 48, rIdx = 124, size 1
  -- #85 reg = STK12  key 48, rIdx = 115, size 1
  -- #86 reg = PCL  key 48, rIdx = 2, size 1
  -- #87 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #88 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #89 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #90 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #91 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #92 reg = STK04  key 49, rIdx = 123, size 1
  -- #93 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #94 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #95 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #96 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #97 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #98 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #99 reg = STK05  key 50, rIdx = 122, size 1
  -- #100 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #101 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #102 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #103 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #104 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #105 reg = STK06  key 51, rIdx = 121, size 1
  -- #106 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #107 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #108 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #109 reg = STK07  key 52, rIdx = 120, size 1
  -- #110 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #111 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #112 reg = STK08  key 53, rIdx = 119, size 1
  -- #113 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #114 reg = STK09  key 55, rIdx = 118, size 1
  -- #115 reg = INDF  key 56, rIdx = 0, size 1
  -- #116 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7C (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l502:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l502:s2:k1:d0:s0)		proc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l504:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7C ] = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l504:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7C ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l504:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_18($2)
libreria_skybot.c(l504:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l504:s7:k8:d0:s0)	 _iffalse_18($2) :
libreria_skybot.c(l505:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l505:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l505:s10:k11:d0:s0)		eproc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l504:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l504:s7:k8:d0:s0)	 _iffalse_18($2) :
libreria_skybot.c(l505:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l505:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l505:s10:k11:d0:s0)		eproc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_18 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l504:s7:k8:d0:s0)	 _iffalse_18($2) :
libreria_skybot.c(l505:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l505:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l505:s10:k11:d0:s0)		eproc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l505:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l505:s10:k11:d0:s0)		eproc _LeerPuertoALinea1 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
newReg: Created register _PORTA (004F7FE5).
  -- added _PORTA to hash, size = 1
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l522:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l522:s2:k1:d0:s0)		proc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l524:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x2 {literal-unsigned-char}
libreria_skybot.c(l524:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l524:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_19($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l524:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_19 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l524:s7:k8:d0:s0)	 _iffalse_19($2) :
libreria_skybot.c(l525:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l525:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l525:s10:k11:d0:s0)		eproc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = STK08  key 53, rIdx = 119, size 1
  -- #115 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #116 reg = STK09  key 55, rIdx = 118, size 1
  -- #117 reg = INDF  key 56, rIdx = 0, size 1
  -- #118 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7D (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l522:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l522:s2:k1:d0:s0)		proc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l524:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7D ] = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x2 {literal-unsigned-char}
libreria_skybot.c(l524:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7D ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l524:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_19($2)
libreria_skybot.c(l524:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l524:s7:k8:d0:s0)	 _iffalse_19($2) :
libreria_skybot.c(l525:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l525:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l525:s10:k11:d0:s0)		eproc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l524:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l524:s7:k8:d0:s0)	 _iffalse_19($2) :
libreria_skybot.c(l525:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l525:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l525:s10:k11:d0:s0)		eproc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_19 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l524:s7:k8:d0:s0)	 _iffalse_19($2) :
libreria_skybot.c(l525:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l525:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l525:s10:k11:d0:s0)		eproc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l525:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l525:s10:k11:d0:s0)		eproc _LeerPuertoALinea2 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l542:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l542:s2:k1:d0:s0)		proc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l544:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l544:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l544:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_20($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l544:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_20 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l544:s7:k8:d0:s0)	 _iffalse_20($2) :
libreria_skybot.c(l545:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l545:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l545:s10:k11:d0:s0)		eproc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #115 reg = STK08  key 53, rIdx = 119, size 1
  -- #116 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #117 reg = STK09  key 55, rIdx = 118, size 1
  -- #118 reg = INDF  key 56, rIdx = 0, size 1
  -- #119 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7E (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l542:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l542:s2:k1:d0:s0)		proc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l544:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7E ] = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l544:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7E ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l544:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_20($2)
libreria_skybot.c(l544:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l544:s7:k8:d0:s0)	 _iffalse_20($2) :
libreria_skybot.c(l545:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l545:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l545:s10:k11:d0:s0)		eproc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l544:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l544:s7:k8:d0:s0)	 _iffalse_20($2) :
libreria_skybot.c(l545:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l545:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l545:s10:k11:d0:s0)		eproc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_20 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l544:s7:k8:d0:s0)	 _iffalse_20($2) :
libreria_skybot.c(l545:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l545:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l545:s10:k11:d0:s0)		eproc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l545:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l545:s10:k11:d0:s0)		eproc _LeerPuertoALinea3 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l562:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l562:s2:k1:d0:s0)		proc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l564:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libreria_skybot.c(l564:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l564:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_21($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l564:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_21 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l564:s7:k8:d0:s0)	 _iffalse_21($2) :
libreria_skybot.c(l565:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l565:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l565:s10:k11:d0:s0)		eproc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #115 reg = STK08  key 53, rIdx = 119, size 1
  -- #116 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #117 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #118 reg = STK09  key 55, rIdx = 118, size 1
  -- #119 reg = INDF  key 56, rIdx = 0, size 1
  -- #120 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7F (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l562:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l562:s2:k1:d0:s0)		proc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l564:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7F ] = _PORTA [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libreria_skybot.c(l564:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x7F ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l564:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_21($2)
libreria_skybot.c(l564:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l564:s7:k8:d0:s0)	 _iffalse_21($2) :
libreria_skybot.c(l565:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l565:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l565:s10:k11:d0:s0)		eproc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l564:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l564:s7:k8:d0:s0)	 _iffalse_21($2) :
libreria_skybot.c(l565:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l565:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l565:s10:k11:d0:s0)		eproc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_21 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l564:s7:k8:d0:s0)	 _iffalse_21($2) :
libreria_skybot.c(l565:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l565:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l565:s10:k11:d0:s0)		eproc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l565:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l565:s10:k11:d0:s0)		eproc _LeerPuertoALinea4 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l590:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l590:s2:k1:d0:s0)		proc _EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l592:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x2 {literal-unsigned-char}
libreria_skybot.c(l592:s4:k3:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l592:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l592:s6:k5:d0:s0)		eproc _EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
  left:_EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #115 reg = STK08  key 53, rIdx = 119, size 1
  -- #116 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #117 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #118 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #119 reg = STK09  key 55, rIdx = 118, size 1
  -- #120 reg = INDF  key 56, rIdx = 0, size 1
  -- #121 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l590:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l590:s2:k1:d0:s0)		proc _EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l592:s3:k2:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x2 {literal-unsigned-char}
libreria_skybot.c(l592:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l592:s6:k5:d0:s0)		eproc _EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 6 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 6 bSize = 1
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l592:s5:k4:d0:s0)	 _return($1) :
libreria_skybot.c(l592:s6:k5:d0:s0)		eproc _EncenderLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l609:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l609:s2:k1:d0:s0)		proc _ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l611:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char} := _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l611:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char} & 0xfffffffd {literal-char}
libreria_skybot.c(l611:s5:k5:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l611:s6:k6:d0:s0)	 _return($1) :
libreria_skybot.c(l611:s7:k7:d0:s0)		eproc _ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  2991 - not packing - right is not temp
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
packRegsForAssign
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
allocDirReg symbol name _PORTB
  703  storage class 3 
 708  integral
 712  specifier
_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PORTB to hash, size = 1
  -- and it is at a fixed address 0x06
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
packRegsForAssign
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  2991 - not packing - right is not temp
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:_ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  right:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
          Symbol type: sfr-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
sfr         Symbol type: sfr-char
  result:_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
  left:_ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #115 reg = STK08  key 53, rIdx = 119, size 1
  -- #116 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #117 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #118 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #119 reg = STK09  key 55, rIdx = 118, size 1
  -- #120 reg = INDF  key 56, rIdx = 0, size 1
  -- #121 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l609:s1:k0:d0:s0)	 _entry($2) :
libreria_skybot.c(l609:s2:k1:d0:s0)		proc _ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l611:s4:k3:d0:s0)		_PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xfffffffd {literal-char}
libreria_skybot.c(l611:s6:k6:d0:s0)	 _return($1) :
libreria_skybot.c(l611:s7:k7:d0:s0)		eproc _ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l611:s6:k6:d0:s0)	 _return($1) :
libreria_skybot.c(l611:s7:k7:d0:s0)		eproc _ApagarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l629:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l629:s2:k1:d0:s0)		proc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l631:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l631:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l631:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_22($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l631:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_22 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l631:s7:k8:d0:s0)	 _iffalse_22($2) :
libreria_skybot.c(l632:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l632:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l632:s10:k11:d0:s0)		eproc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = r0x72  key 33, rIdx = 114, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x73  key 34, rIdx = 115, size 1
  -- #47 reg = r0x29  key 35, rIdx = 41, size 1
  -- #48 reg = r0x38  key 35, rIdx = 56, size 1
  -- #49 reg = r0x47  key 35, rIdx = 71, size 1
  -- #50 reg = r0x56  key 35, rIdx = 86, size 1
  -- #51 reg = r0x65  key 35, rIdx = 101, size 1
  -- #52 reg = r0x74  key 35, rIdx = 116, size 1
  -- #53 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #54 reg = r0x39  key 36, rIdx = 57, size 1
  -- #55 reg = r0x48  key 36, rIdx = 72, size 1
  -- #56 reg = r0x57  key 36, rIdx = 87, size 1
  -- #57 reg = r0x66  key 36, rIdx = 102, size 1
  -- #58 reg = r0x75  key 36, rIdx = 117, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x76  key 37, rIdx = 118, size 1
  -- #63 reg = r0x59  key 38, rIdx = 89, size 1
  -- #64 reg = r0x68  key 38, rIdx = 104, size 1
  -- #65 reg = r0x77  key 38, rIdx = 119, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x78  key 39, rIdx = 120, size 1
  -- #68 reg = r0x79  key 40, rIdx = 121, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #100 reg = STK05  key 50, rIdx = 122, size 1
  -- #101 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #102 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #103 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #104 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #105 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #111 reg = STK07  key 52, rIdx = 120, size 1
  -- #112 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #113 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #114 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #115 reg = STK08  key 53, rIdx = 119, size 1
  -- #116 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #117 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #118 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #119 reg = STK09  key 55, rIdx = 118, size 1
  -- #120 reg = INDF  key 56, rIdx = 0, size 1
  -- #121 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x80 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l629:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l629:s2:k1:d0:s0)		proc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l631:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x80 ] = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l631:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x80 ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l631:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_22($2)
libreria_skybot.c(l631:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l631:s7:k8:d0:s0)	 _iffalse_22($2) :
libreria_skybot.c(l632:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l632:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l632:s10:k11:d0:s0)		eproc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l631:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l631:s7:k8:d0:s0)	 _iffalse_22($2) :
libreria_skybot.c(l632:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l632:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l632:s10:k11:d0:s0)		eproc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_22 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l631:s7:k8:d0:s0)	 _iffalse_22($2) :
libreria_skybot.c(l632:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l632:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l632:s10:k11:d0:s0)		eproc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l632:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l632:s10:k11:d0:s0)		eproc _Led_esta_encendido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x80
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x80
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l650:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l650:s2:k1:d0:s0)		proc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l652:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l652:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_23($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l652:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_23 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l652:s6:k7:d0:s0)	 _iffalse_23($2) :
libreria_skybot.c(l653:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l653:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l653:s9:k10:d0:s0)		eproc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x28  key 34, rIdx = 40, size 1
  -- #43 reg = r0x37  key 34, rIdx = 55, size 1
  -- #44 reg = r0x46  key 34, rIdx = 70, size 1
  -- #45 reg = r0x55  key 34, rIdx = 85, size 1
  -- #46 reg = r0x64  key 34, rIdx = 100, size 1
  -- #47 reg = r0x73  key 34, rIdx = 115, size 1
  -- #48 reg = r0x29  key 35, rIdx = 41, size 1
  -- #49 reg = r0x38  key 35, rIdx = 56, size 1
  -- #50 reg = r0x47  key 35, rIdx = 71, size 1
  -- #51 reg = r0x56  key 35, rIdx = 86, size 1
  -- #52 reg = r0x65  key 35, rIdx = 101, size 1
  -- #53 reg = r0x74  key 35, rIdx = 116, size 1
  -- #54 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #55 reg = r0x39  key 36, rIdx = 57, size 1
  -- #56 reg = r0x48  key 36, rIdx = 72, size 1
  -- #57 reg = r0x57  key 36, rIdx = 87, size 1
  -- #58 reg = r0x66  key 36, rIdx = 102, size 1
  -- #59 reg = r0x75  key 36, rIdx = 117, size 1
  -- #60 reg = r0x49  key 37, rIdx = 73, size 1
  -- #61 reg = r0x58  key 37, rIdx = 88, size 1
  -- #62 reg = r0x67  key 37, rIdx = 103, size 1
  -- #63 reg = r0x76  key 37, rIdx = 118, size 1
  -- #64 reg = r0x59  key 38, rIdx = 89, size 1
  -- #65 reg = r0x68  key 38, rIdx = 104, size 1
  -- #66 reg = r0x77  key 38, rIdx = 119, size 1
  -- #67 reg = r0x69  key 39, rIdx = 105, size 1
  -- #68 reg = r0x78  key 39, rIdx = 120, size 1
  -- #69 reg = r0x79  key 40, rIdx = 121, size 1
  -- #70 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #71 reg = STK00  key 45, rIdx = 127, size 1
  -- #72 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #73 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #74 reg = STK01  key 46, rIdx = 126, size 1
  -- #75 reg = STK10  key 46, rIdx = 117, size 1
  -- #76 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #77 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #78 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #79 reg = STK02  key 47, rIdx = 125, size 1
  -- #80 reg = STK11  key 47, rIdx = 116, size 1
  -- #81 reg = INTCON  key 47, rIdx = 11, size 1
  -- #82 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #83 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #84 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #85 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #86 reg = STK03  key 48, rIdx = 124, size 1
  -- #87 reg = STK12  key 48, rIdx = 115, size 1
  -- #88 reg = PCL  key 48, rIdx = 2, size 1
  -- #89 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #90 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #91 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #92 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #93 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #94 reg = STK04  key 49, rIdx = 123, size 1
  -- #95 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #96 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #97 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #98 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #99 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #100 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #101 reg = STK05  key 50, rIdx = 122, size 1
  -- #102 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #103 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #104 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #105 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #106 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #107 reg = STK06  key 51, rIdx = 121, size 1
  -- #108 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #109 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #110 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #111 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #112 reg = STK07  key 52, rIdx = 120, size 1
  -- #113 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #114 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #115 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #116 reg = STK08  key 53, rIdx = 119, size 1
  -- #117 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #118 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #119 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #120 reg = STK09  key 55, rIdx = 118, size 1
  -- #121 reg = INDF  key 56, rIdx = 0, size 1
  -- #122 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x81 (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l650:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l650:s2:k1:d0:s0)		proc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l652:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x81 ] = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l652:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x81 ] != 0 goto _iffalse_23($2)
libreria_skybot.c(l652:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l652:s6:k7:d0:s0)	 _iffalse_23($2) :
libreria_skybot.c(l653:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l653:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l653:s9:k10:d0:s0)		eproc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l652:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l652:s6:k7:d0:s0)	 _iffalse_23($2) :
libreria_skybot.c(l653:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l653:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l653:s9:k10:d0:s0)		eproc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_23 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l652:s6:k7:d0:s0)	 _iffalse_23($2) :
libreria_skybot.c(l653:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l653:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l653:s9:k10:d0:s0)		eproc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l653:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l653:s9:k10:d0:s0)		eproc _Led_esta_apagado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l670:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l670:s2:k1:d0:s0)		proc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l672:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x2 {literal-unsigned-char}
libreria_skybot.c(l672:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_24($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l672:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_24 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l672:s6:k7:d0:s0)	 _iffalse_24($2) :
libreria_skybot.c(l673:s7:k8:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l673:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l673:s9:k10:d0:s0)		eproc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  3964
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x81  key 33, rIdx = 129, size 1
  -- #43 reg = r0x28  key 34, rIdx = 40, size 1
  -- #44 reg = r0x37  key 34, rIdx = 55, size 1
  -- #45 reg = r0x46  key 34, rIdx = 70, size 1
  -- #46 reg = r0x55  key 34, rIdx = 85, size 1
  -- #47 reg = r0x64  key 34, rIdx = 100, size 1
  -- #48 reg = r0x73  key 34, rIdx = 115, size 1
  -- #49 reg = r0x29  key 35, rIdx = 41, size 1
  -- #50 reg = r0x38  key 35, rIdx = 56, size 1
  -- #51 reg = r0x47  key 35, rIdx = 71, size 1
  -- #52 reg = r0x56  key 35, rIdx = 86, size 1
  -- #53 reg = r0x65  key 35, rIdx = 101, size 1
  -- #54 reg = r0x74  key 35, rIdx = 116, size 1
  -- #55 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #56 reg = r0x39  key 36, rIdx = 57, size 1
  -- #57 reg = r0x48  key 36, rIdx = 72, size 1
  -- #58 reg = r0x57  key 36, rIdx = 87, size 1
  -- #59 reg = r0x66  key 36, rIdx = 102, size 1
  -- #60 reg = r0x75  key 36, rIdx = 117, size 1
  -- #61 reg = r0x49  key 37, rIdx = 73, size 1
  -- #62 reg = r0x58  key 37, rIdx = 88, size 1
  -- #63 reg = r0x67  key 37, rIdx = 103, size 1
  -- #64 reg = r0x76  key 37, rIdx = 118, size 1
  -- #65 reg = r0x59  key 38, rIdx = 89, size 1
  -- #66 reg = r0x68  key 38, rIdx = 104, size 1
  -- #67 reg = r0x77  key 38, rIdx = 119, size 1
  -- #68 reg = r0x69  key 39, rIdx = 105, size 1
  -- #69 reg = r0x78  key 39, rIdx = 120, size 1
  -- #70 reg = r0x79  key 40, rIdx = 121, size 1
  -- #71 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #72 reg = STK00  key 45, rIdx = 127, size 1
  -- #73 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #74 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #75 reg = STK01  key 46, rIdx = 126, size 1
  -- #76 reg = STK10  key 46, rIdx = 117, size 1
  -- #77 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #78 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #79 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #80 reg = STK02  key 47, rIdx = 125, size 1
  -- #81 reg = STK11  key 47, rIdx = 116, size 1
  -- #82 reg = INTCON  key 47, rIdx = 11, size 1
  -- #83 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #84 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #85 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #86 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #87 reg = STK03  key 48, rIdx = 124, size 1
  -- #88 reg = STK12  key 48, rIdx = 115, size 1
  -- #89 reg = PCL  key 48, rIdx = 2, size 1
  -- #90 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #91 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #92 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #93 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #94 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #95 reg = STK04  key 49, rIdx = 123, size 1
  -- #96 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #97 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #98 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #99 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #100 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #101 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #102 reg = STK05  key 50, rIdx = 122, size 1
  -- #103 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #104 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #105 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #106 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #107 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #108 reg = STK06  key 51, rIdx = 121, size 1
  -- #109 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #110 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #111 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #112 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #113 reg = STK07  key 52, rIdx = 120, size 1
  -- #114 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #115 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #116 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #117 reg = STK08  key 53, rIdx = 119, size 1
  -- #118 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #119 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #120 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #121 reg = STK09  key 55, rIdx = 118, size 1
  -- #122 reg = INDF  key 56, rIdx = 0, size 1
  -- #123 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
  op: IFX
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l670:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l670:s2:k1:d0:s0)		proc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l672:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x2 {literal-unsigned-char}
libreria_skybot.c(l672:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_24($2)
libreria_skybot.c(l672:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l672:s6:k7:d0:s0)	 _iffalse_24($2) :
libreria_skybot.c(l673:s7:k8:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l673:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l673:s9:k10:d0:s0)		eproc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l672:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l672:s6:k7:d0:s0)	 _iffalse_24($2) :
libreria_skybot.c(l673:s7:k8:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l673:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l673:s9:k10:d0:s0)		eproc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_24 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l672:s6:k7:d0:s0)	 _iffalse_24($2) :
libreria_skybot.c(l673:s7:k8:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l673:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l673:s9:k10:d0:s0)		eproc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l673:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l673:s9:k10:d0:s0)		eproc _EstadoLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l691:s1:k0:d0:s0)	 _entry($5) :
libreria_skybot.c(l691:s2:k1:d0:s0)		proc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l693:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l693:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_25($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (6) }

----------------------------------------------------------------
libreria_skybot.c(l694:s5:k6:d0:s0)		iTemp1 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _EncenderLed [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l694:s6:k7:d0:s0)		 goto _return($4)

----------------------------------------------------------------
Basic Block _iffalse_25 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (9) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (9) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (9) }

----------------------------------------------------------------
libreria_skybot.c(l694:s7:k8:d0:s0)	 _iffalse_25($2) :
libreria_skybot.c(l697:s8:k9:d0:s0)		iTemp2 [k7 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _ApagarLed [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) (9) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) (9) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l697:s9:k11:d0:s0)	 _return($4) :
libreria_skybot.c(l697:s10:k12:d0:s0)		eproc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
  left:_CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_EncenderLed [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp1 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_ApagarLed [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp2 [k7 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x81  key 33, rIdx = 129, size 1
  -- #43 reg = r0x28  key 34, rIdx = 40, size 1
  -- #44 reg = r0x37  key 34, rIdx = 55, size 1
  -- #45 reg = r0x46  key 34, rIdx = 70, size 1
  -- #46 reg = r0x55  key 34, rIdx = 85, size 1
  -- #47 reg = r0x64  key 34, rIdx = 100, size 1
  -- #48 reg = r0x73  key 34, rIdx = 115, size 1
  -- #49 reg = r0x29  key 35, rIdx = 41, size 1
  -- #50 reg = r0x38  key 35, rIdx = 56, size 1
  -- #51 reg = r0x47  key 35, rIdx = 71, size 1
  -- #52 reg = r0x56  key 35, rIdx = 86, size 1
  -- #53 reg = r0x65  key 35, rIdx = 101, size 1
  -- #54 reg = r0x74  key 35, rIdx = 116, size 1
  -- #55 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #56 reg = r0x39  key 36, rIdx = 57, size 1
  -- #57 reg = r0x48  key 36, rIdx = 72, size 1
  -- #58 reg = r0x57  key 36, rIdx = 87, size 1
  -- #59 reg = r0x66  key 36, rIdx = 102, size 1
  -- #60 reg = r0x75  key 36, rIdx = 117, size 1
  -- #61 reg = r0x49  key 37, rIdx = 73, size 1
  -- #62 reg = r0x58  key 37, rIdx = 88, size 1
  -- #63 reg = r0x67  key 37, rIdx = 103, size 1
  -- #64 reg = r0x76  key 37, rIdx = 118, size 1
  -- #65 reg = r0x59  key 38, rIdx = 89, size 1
  -- #66 reg = r0x68  key 38, rIdx = 104, size 1
  -- #67 reg = r0x77  key 38, rIdx = 119, size 1
  -- #68 reg = r0x69  key 39, rIdx = 105, size 1
  -- #69 reg = r0x78  key 39, rIdx = 120, size 1
  -- #70 reg = r0x79  key 40, rIdx = 121, size 1
  -- #71 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #72 reg = STK00  key 45, rIdx = 127, size 1
  -- #73 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #74 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #75 reg = STK01  key 46, rIdx = 126, size 1
  -- #76 reg = STK10  key 46, rIdx = 117, size 1
  -- #77 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #78 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #79 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #80 reg = STK02  key 47, rIdx = 125, size 1
  -- #81 reg = STK11  key 47, rIdx = 116, size 1
  -- #82 reg = INTCON  key 47, rIdx = 11, size 1
  -- #83 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #84 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #85 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #86 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #87 reg = STK03  key 48, rIdx = 124, size 1
  -- #88 reg = STK12  key 48, rIdx = 115, size 1
  -- #89 reg = PCL  key 48, rIdx = 2, size 1
  -- #90 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #91 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #92 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #93 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #94 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #95 reg = STK04  key 49, rIdx = 123, size 1
  -- #96 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #97 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #98 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #99 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #100 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #101 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #102 reg = STK05  key 50, rIdx = 122, size 1
  -- #103 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #104 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #105 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #106 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #107 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #108 reg = STK06  key 51, rIdx = 121, size 1
  -- #109 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #110 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #111 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #112 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #113 reg = STK07  key 52, rIdx = 120, size 1
  -- #114 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #115 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #116 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #117 reg = STK08  key 53, rIdx = 119, size 1
  -- #118 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #119 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #120 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #121 reg = STK09  key 55, rIdx = 118, size 1
  -- #122 reg = INDF  key 56, rIdx = 0, size 1
  -- #123 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2697 - iTemp2
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x82 (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l691:s1:k0:d0:s0)	 _entry($5) :
libreria_skybot.c(l691:s2:k1:d0:s0)		proc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l693:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x82 ] = call _EstadoLed [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l693:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x82 ] != 0 goto _iffalse_25($2)
libreria_skybot.c(l694:s5:k6:d0:s0)		iTemp1 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _EncenderLed [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l694:s6:k7:d0:s0)		 goto _return($4)
libreria_skybot.c(l694:s7:k8:d0:s0)	 _iffalse_25($2) :
libreria_skybot.c(l697:s8:k9:d0:s0)		iTemp2 [k7 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _ApagarLed [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l697:s9:k11:d0:s0)	 _return($4) :
libreria_skybot.c(l697:s10:k12:d0:s0)		eproc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (6) }

----------------------------------------------------------------
libreria_skybot.c(l694:s5:k6:d0:s0)		iTemp1 [k5 lr5:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _EncenderLed [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l694:s6:k7:d0:s0)		 goto _return($4)
libreria_skybot.c(l694:s7:k8:d0:s0)	 _iffalse_25($2) :
libreria_skybot.c(l697:s8:k9:d0:s0)		iTemp2 [k7 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _ApagarLed [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l697:s9:k11:d0:s0)	 _return($4) :
libreria_skybot.c(l697:s10:k12:d0:s0)		eproc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_25 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (9) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (9) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (9) }

----------------------------------------------------------------
libreria_skybot.c(l694:s7:k8:d0:s0)	 _iffalse_25($2) :
libreria_skybot.c(l697:s8:k9:d0:s0)		iTemp2 [k7 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _ApagarLed [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libreria_skybot.c(l697:s9:k11:d0:s0)	 _return($4) :
libreria_skybot.c(l697:s10:k12:d0:s0)		eproc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) (9) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) (6) (9) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l697:s9:k11:d0:s0)	 _return($4) :
libreria_skybot.c(l697:s10:k12:d0:s0)		eproc _CambiarLed [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l724:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l724:s2:k1:d0:s0)		proc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l726:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l726:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libreria_skybot.c(l726:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_26($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l726:s6:k7:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_26 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l726:s7:k8:d0:s0)	 _iffalse_26($2) :
libreria_skybot.c(l727:s8:k9:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l727:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l727:s10:k11:d0:s0)		eproc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x81  key 33, rIdx = 129, size 1
  -- #43 reg = r0x28  key 34, rIdx = 40, size 1
  -- #44 reg = r0x37  key 34, rIdx = 55, size 1
  -- #45 reg = r0x46  key 34, rIdx = 70, size 1
  -- #46 reg = r0x55  key 34, rIdx = 85, size 1
  -- #47 reg = r0x64  key 34, rIdx = 100, size 1
  -- #48 reg = r0x73  key 34, rIdx = 115, size 1
  -- #49 reg = r0x82  key 34, rIdx = 130, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #57 reg = r0x39  key 36, rIdx = 57, size 1
  -- #58 reg = r0x48  key 36, rIdx = 72, size 1
  -- #59 reg = r0x57  key 36, rIdx = 87, size 1
  -- #60 reg = r0x66  key 36, rIdx = 102, size 1
  -- #61 reg = r0x75  key 36, rIdx = 117, size 1
  -- #62 reg = r0x49  key 37, rIdx = 73, size 1
  -- #63 reg = r0x58  key 37, rIdx = 88, size 1
  -- #64 reg = r0x67  key 37, rIdx = 103, size 1
  -- #65 reg = r0x76  key 37, rIdx = 118, size 1
  -- #66 reg = r0x59  key 38, rIdx = 89, size 1
  -- #67 reg = r0x68  key 38, rIdx = 104, size 1
  -- #68 reg = r0x77  key 38, rIdx = 119, size 1
  -- #69 reg = r0x69  key 39, rIdx = 105, size 1
  -- #70 reg = r0x78  key 39, rIdx = 120, size 1
  -- #71 reg = r0x79  key 40, rIdx = 121, size 1
  -- #72 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #73 reg = STK00  key 45, rIdx = 127, size 1
  -- #74 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #75 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #76 reg = STK01  key 46, rIdx = 126, size 1
  -- #77 reg = STK10  key 46, rIdx = 117, size 1
  -- #78 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #79 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #80 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #81 reg = STK02  key 47, rIdx = 125, size 1
  -- #82 reg = STK11  key 47, rIdx = 116, size 1
  -- #83 reg = INTCON  key 47, rIdx = 11, size 1
  -- #84 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #85 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #86 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #87 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #88 reg = STK03  key 48, rIdx = 124, size 1
  -- #89 reg = STK12  key 48, rIdx = 115, size 1
  -- #90 reg = PCL  key 48, rIdx = 2, size 1
  -- #91 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #92 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #93 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #94 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #95 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #96 reg = STK04  key 49, rIdx = 123, size 1
  -- #97 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #98 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #99 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #100 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #101 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #102 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #103 reg = STK05  key 50, rIdx = 122, size 1
  -- #104 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #105 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #106 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #107 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #108 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #109 reg = STK06  key 51, rIdx = 121, size 1
  -- #110 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #111 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #112 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #113 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #114 reg = STK07  key 52, rIdx = 120, size 1
  -- #115 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #116 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #117 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #118 reg = STK08  key 53, rIdx = 119, size 1
  -- #119 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #120 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #121 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #122 reg = STK09  key 55, rIdx = 118, size 1
  -- #123 reg = INDF  key 56, rIdx = 0, size 1
  -- #124 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x83 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l724:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l724:s2:k1:d0:s0)		proc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l726:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x83 ] = _PORTB [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libreria_skybot.c(l726:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x83 ] == 0x0 {literal-unsigned-char}
libreria_skybot.c(l726:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} != 0 goto _iffalse_26($2)
libreria_skybot.c(l726:s6:k7:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l726:s7:k8:d0:s0)	 _iffalse_26($2) :
libreria_skybot.c(l727:s8:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l727:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l727:s10:k11:d0:s0)		eproc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l726:s6:k7:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l726:s7:k8:d0:s0)	 _iffalse_26($2) :
libreria_skybot.c(l727:s8:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l727:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l727:s10:k11:d0:s0)		eproc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_26 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l726:s7:k8:d0:s0)	 _iffalse_26($2) :
libreria_skybot.c(l727:s8:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l727:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l727:s10:k11:d0:s0)		eproc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l727:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l727:s10:k11:d0:s0)		eproc _LeerPulsador [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l745:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l745:s2:k1:d0:s0)		proc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l747:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l747:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libreria_skybot.c(l747:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_27($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l747:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_27 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l747:s7:k8:d0:s0)	 _iffalse_27($2) :
libreria_skybot.c(l748:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l748:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l748:s10:k11:d0:s0)		eproc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x81  key 33, rIdx = 129, size 1
  -- #43 reg = r0x28  key 34, rIdx = 40, size 1
  -- #44 reg = r0x37  key 34, rIdx = 55, size 1
  -- #45 reg = r0x46  key 34, rIdx = 70, size 1
  -- #46 reg = r0x55  key 34, rIdx = 85, size 1
  -- #47 reg = r0x64  key 34, rIdx = 100, size 1
  -- #48 reg = r0x73  key 34, rIdx = 115, size 1
  -- #49 reg = r0x82  key 34, rIdx = 130, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = r0x83  key 35, rIdx = 131, size 1
  -- #57 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #58 reg = r0x39  key 36, rIdx = 57, size 1
  -- #59 reg = r0x48  key 36, rIdx = 72, size 1
  -- #60 reg = r0x57  key 36, rIdx = 87, size 1
  -- #61 reg = r0x66  key 36, rIdx = 102, size 1
  -- #62 reg = r0x75  key 36, rIdx = 117, size 1
  -- #63 reg = r0x49  key 37, rIdx = 73, size 1
  -- #64 reg = r0x58  key 37, rIdx = 88, size 1
  -- #65 reg = r0x67  key 37, rIdx = 103, size 1
  -- #66 reg = r0x76  key 37, rIdx = 118, size 1
  -- #67 reg = r0x59  key 38, rIdx = 89, size 1
  -- #68 reg = r0x68  key 38, rIdx = 104, size 1
  -- #69 reg = r0x77  key 38, rIdx = 119, size 1
  -- #70 reg = r0x69  key 39, rIdx = 105, size 1
  -- #71 reg = r0x78  key 39, rIdx = 120, size 1
  -- #72 reg = r0x79  key 40, rIdx = 121, size 1
  -- #73 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #74 reg = STK00  key 45, rIdx = 127, size 1
  -- #75 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #76 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #77 reg = STK01  key 46, rIdx = 126, size 1
  -- #78 reg = STK10  key 46, rIdx = 117, size 1
  -- #79 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #80 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #81 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #82 reg = STK02  key 47, rIdx = 125, size 1
  -- #83 reg = STK11  key 47, rIdx = 116, size 1
  -- #84 reg = INTCON  key 47, rIdx = 11, size 1
  -- #85 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #86 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #87 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #88 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #89 reg = STK03  key 48, rIdx = 124, size 1
  -- #90 reg = STK12  key 48, rIdx = 115, size 1
  -- #91 reg = PCL  key 48, rIdx = 2, size 1
  -- #92 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #93 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #94 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #95 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #96 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #97 reg = STK04  key 49, rIdx = 123, size 1
  -- #98 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #99 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #100 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #101 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #102 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #103 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #104 reg = STK05  key 50, rIdx = 122, size 1
  -- #105 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #106 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #107 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #108 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #109 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #110 reg = STK06  key 51, rIdx = 121, size 1
  -- #111 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #112 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #113 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #114 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #115 reg = STK07  key 52, rIdx = 120, size 1
  -- #116 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #117 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #118 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #119 reg = STK08  key 53, rIdx = 119, size 1
  -- #120 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #121 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #122 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #123 reg = STK09  key 55, rIdx = 118, size 1
  -- #124 reg = INDF  key 56, rIdx = 0, size 1
  -- #125 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x84 (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 5
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

----------------------------------------------------------------
libreria_skybot.c(l745:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l745:s2:k1:d0:s0)		proc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l747:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x84 ] = call _LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l747:s4:k3:d0:s0)		iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x84 ] == 0x1 {literal-unsigned-char}
libreria_skybot.c(l747:s5:k4:d0:s0)		if iTemp1 [k4 lr4:5 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_27($2)
libreria_skybot.c(l747:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l747:s7:k8:d0:s0)	 _iffalse_27($2) :
libreria_skybot.c(l748:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l748:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l748:s10:k11:d0:s0)		eproc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 6 , last iCode = 6
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l747:s6:k7:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l747:s7:k8:d0:s0)	 _iffalse_27($2) :
libreria_skybot.c(l748:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l748:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l748:s10:k11:d0:s0)		eproc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_27 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l747:s7:k8:d0:s0)	 _iffalse_27($2) :
libreria_skybot.c(l748:s8:k9:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l748:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l748:s10:k11:d0:s0)		eproc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 9 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 12 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 12 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l748:s9:k10:d0:s0)	 _return($3) :
libreria_skybot.c(l748:s10:k11:d0:s0)		eproc _Pulsador_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x84
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x84
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l766:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l766:s2:k1:d0:s0)		proc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l768:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l768:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_28($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l768:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_28 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l768:s6:k7:d0:s0)	 _iffalse_28($2) :
libreria_skybot.c(l769:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l769:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l769:s9:k10:d0:s0)		eproc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #11 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #12 reg = r0x23  key 29, rIdx = 35, size 1
  -- #13 reg = r0x32  key 29, rIdx = 50, size 1
  -- #14 reg = r0x41  key 29, rIdx = 65, size 1
  -- #15 reg = r0x50  key 29, rIdx = 80, size 1
  -- #16 reg = r0x24  key 30, rIdx = 36, size 1
  -- #17 reg = r0x33  key 30, rIdx = 51, size 1
  -- #18 reg = r0x42  key 30, rIdx = 66, size 1
  -- #19 reg = r0x51  key 30, rIdx = 81, size 1
  -- #20 reg = r0x60  key 30, rIdx = 96, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = r0x70  key 31, rIdx = 112, size 1
  -- #28 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #29 reg = r0x26  key 32, rIdx = 38, size 1
  -- #30 reg = r0x35  key 32, rIdx = 53, size 1
  -- #31 reg = r0x44  key 32, rIdx = 68, size 1
  -- #32 reg = r0x53  key 32, rIdx = 83, size 1
  -- #33 reg = r0x62  key 32, rIdx = 98, size 1
  -- #34 reg = r0x71  key 32, rIdx = 113, size 1
  -- #35 reg = r0x80  key 32, rIdx = 128, size 1
  -- #36 reg = r0x27  key 33, rIdx = 39, size 1
  -- #37 reg = r0x36  key 33, rIdx = 54, size 1
  -- #38 reg = r0x45  key 33, rIdx = 69, size 1
  -- #39 reg = r0x54  key 33, rIdx = 84, size 1
  -- #40 reg = r0x63  key 33, rIdx = 99, size 1
  -- #41 reg = r0x72  key 33, rIdx = 114, size 1
  -- #42 reg = r0x81  key 33, rIdx = 129, size 1
  -- #43 reg = r0x28  key 34, rIdx = 40, size 1
  -- #44 reg = r0x37  key 34, rIdx = 55, size 1
  -- #45 reg = r0x46  key 34, rIdx = 70, size 1
  -- #46 reg = r0x55  key 34, rIdx = 85, size 1
  -- #47 reg = r0x64  key 34, rIdx = 100, size 1
  -- #48 reg = r0x73  key 34, rIdx = 115, size 1
  -- #49 reg = r0x82  key 34, rIdx = 130, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = r0x83  key 35, rIdx = 131, size 1
  -- #57 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #58 reg = r0x39  key 36, rIdx = 57, size 1
  -- #59 reg = r0x48  key 36, rIdx = 72, size 1
  -- #60 reg = r0x57  key 36, rIdx = 87, size 1
  -- #61 reg = r0x66  key 36, rIdx = 102, size 1
  -- #62 reg = r0x75  key 36, rIdx = 117, size 1
  -- #63 reg = r0x84  key 36, rIdx = 132, size 1
  -- #64 reg = r0x49  key 37, rIdx = 73, size 1
  -- #65 reg = r0x58  key 37, rIdx = 88, size 1
  -- #66 reg = r0x67  key 37, rIdx = 103, size 1
  -- #67 reg = r0x76  key 37, rIdx = 118, size 1
  -- #68 reg = r0x59  key 38, rIdx = 89, size 1
  -- #69 reg = r0x68  key 38, rIdx = 104, size 1
  -- #70 reg = r0x77  key 38, rIdx = 119, size 1
  -- #71 reg = r0x69  key 39, rIdx = 105, size 1
  -- #72 reg = r0x78  key 39, rIdx = 120, size 1
  -- #73 reg = r0x79  key 40, rIdx = 121, size 1
  -- #74 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #75 reg = STK00  key 45, rIdx = 127, size 1
  -- #76 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #77 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #78 reg = STK01  key 46, rIdx = 126, size 1
  -- #79 reg = STK10  key 46, rIdx = 117, size 1
  -- #80 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #81 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #82 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #83 reg = STK02  key 47, rIdx = 125, size 1
  -- #84 reg = STK11  key 47, rIdx = 116, size 1
  -- #85 reg = INTCON  key 47, rIdx = 11, size 1
  -- #86 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #87 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #88 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #89 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #90 reg = STK03  key 48, rIdx = 124, size 1
  -- #91 reg = STK12  key 48, rIdx = 115, size 1
  -- #92 reg = PCL  key 48, rIdx = 2, size 1
  -- #93 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #94 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #95 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #96 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #97 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #98 reg = STK04  key 49, rIdx = 123, size 1
  -- #99 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #100 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #101 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #102 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #103 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #104 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #105 reg = STK05  key 50, rIdx = 122, size 1
  -- #106 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #107 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #108 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #109 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #110 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #111 reg = STK06  key 51, rIdx = 121, size 1
  -- #112 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #113 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #114 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #115 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #116 reg = STK07  key 52, rIdx = 120, size 1
  -- #117 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #118 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #119 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #120 reg = STK08  key 53, rIdx = 119, size 1
  -- #121 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #122 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #123 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #124 reg = STK09  key 55, rIdx = 118, size 1
  -- #125 reg = INDF  key 56, rIdx = 0, size 1
  -- #126 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 55 bSize = 7
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x85 (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libreria_skybot.c(l766:s1:k0:d0:s0)	 _entry($4) :
libreria_skybot.c(l766:s2:k1:d0:s0)		proc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l768:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x85 ] = call _LeerPulsador [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l768:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x85 ] != 0 goto _iffalse_28($2)
libreria_skybot.c(l768:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l768:s6:k7:d0:s0)	 _iffalse_28($2) :
libreria_skybot.c(l769:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l769:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l769:s9:k10:d0:s0)		eproc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l768:s5:k6:d0:s0)		ret 0x1 {literal-unsigned-char}
libreria_skybot.c(l768:s6:k7:d0:s0)	 _iffalse_28($2) :
libreria_skybot.c(l769:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l769:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l769:s9:k10:d0:s0)		eproc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_28 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l768:s6:k7:d0:s0)	 _iffalse_28($2) :
libreria_skybot.c(l769:s7:k8:d0:s0)		ret 0x0 {literal-unsigned-char}
libreria_skybot.c(l769:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l769:s9:k10:d0:s0)		eproc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l769:s8:k9:d0:s0)	 _return($3) :
libreria_skybot.c(l769:s9:k10:d0:s0)		eproc _Pulsador_no_esta_pulsado [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
Found a Processor Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (2) (3) (4) (5) (6) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (2) (4) (5) (6) }

----------------------------------------------------------------
libreria_skybot.c(l802:s1:k0:d0:s0)	 _entry($5) :
libreria_skybot.c(l802:s2:k1:d0:s0)		proc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l807:s3:k2:d0:s0)		_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1 {literal-unsigned-char}
libreria_skybot.c(l808:s4:k3:d0:s0)		_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe {literal-unsigned-char}
libreria_skybot.c(l812:s5:k4:d0:s0)		iTemp0 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x4 {literal-unsigned-char}
libreria_skybot.c(l812:s6:k5:d0:s0)		_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l815:s7:k6:d0:s0)		iTemp1 [k6 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l815:s8:k8:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := iTemp1 [k6 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l817:s9:k21:d0:s0)	 preHeaderLbl0($6) :

----------------------------------------------------------------
Basic Block _whilecontinue_2 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 10 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (10) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (10) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (5) (10) }

----------------------------------------------------------------
libreria_skybot.c(l817:s10:k9:d1:s0)	 _whilecontinue_2($1) :
libreria_skybot.c(l817:s11:k10:d1:s0)		iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l817:s12:k11:d1:s0)		if iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _whilecontinue_2($1)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 13 , last iCode = 15
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

----------------------------------------------------------------
libreria_skybot.c(l825:s13:k16:d0:s0)		iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := _ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l825:s14:k17:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l826:s15:k18:d0:s0)		ret _tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 16 , last iCode = 17
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
packRegsForAssign
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1 {literal-unsigned-char}
allocDirReg symbol name _ADCON0
  703  storage class 3 
 708  integral
 712  specifier
_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _ADCON0 (004F829D).
  -- added _ADCON0 to hash, size = 1
  -- and it is at a fixed address 0x1f
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1 {literal-unsigned-char}
packRegsForAssign
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
allocDirReg symbol name _ADCON1
  703  storage class 3 
 708  integral
 712  specifier
_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _ADCON1 to hash, size = 1
  -- and it is at a fixed address 0x9f
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
packRegsForAssign
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _ADCON0
  703  storage class 3 
 708  integral
 712  specifier
_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _ADCON0 to hash, size = 1
  -- and it is at a fixed address 0x1f
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp1 [k6 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _tmp
  703  storage class 0 
 708  integral
 712  specifier
_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
newReg: Created register _tmp (004F829D).
  -- added _tmp to hash, size = 1
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp1 [k6 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1 {literal-unsigned-char}
allocDirReg symbol name _ADCON0
  703  storage class 3 
 708  integral
 712  specifier
_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _ADCON0 to hash, size = 1
  -- and it is at a fixed address 0x1f
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x1 {literal-unsigned-char}
packRegsForAssign
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
allocDirReg symbol name _ADCON1
  703  storage class 3 
 708  integral
 712  specifier
_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _ADCON1 to hash, size = 1
  -- and it is at a fixed address 0x9f
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0xe {literal-unsigned-char}
  left:_LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  result:_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  left:_ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:_ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
packRegisters
  left:_ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  3964
  left:iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:_ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  2991 - not packing - right is not temp
  result:iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:_ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
packRegsForAssign
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _tmp
  703  storage class 0 
 708  integral
 712  specifier
_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp4
  replacing with iTemp4
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp4 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:_ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
allocDirReg symbol name _tmp
  703  storage class 0 
 708  integral
 712  specifier
_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  2981 - result is not temp
  2991 - not packing - right is not temp
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:_ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  right:_ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
         Symbol type: sfr-volatile-unsigned-char
  result:_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #3 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #4 reg = _tmp  key 16, rIdx = 1, size 1
  -- #5 reg = r0x20  key 26, rIdx = 32, size 1
  -- #6 reg = r0x21  key 27, rIdx = 33, size 1
  -- #7 reg = r0x30  key 27, rIdx = 48, size 1
  -- #8 reg = _ADCON0  key 27, rIdx = 31, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #13 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #14 reg = r0x23  key 29, rIdx = 35, size 1
  -- #15 reg = r0x32  key 29, rIdx = 50, size 1
  -- #16 reg = r0x41  key 29, rIdx = 65, size 1
  -- #17 reg = r0x50  key 29, rIdx = 80, size 1
  -- #18 reg = r0x24  key 30, rIdx = 36, size 1
  -- #19 reg = r0x33  key 30, rIdx = 51, size 1
  -- #20 reg = r0x42  key 30, rIdx = 66, size 1
  -- #21 reg = r0x51  key 30, rIdx = 81, size 1
  -- #22 reg = r0x60  key 30, rIdx = 96, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = r0x70  key 31, rIdx = 112, size 1
  -- #30 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #31 reg = r0x26  key 32, rIdx = 38, size 1
  -- #32 reg = r0x35  key 32, rIdx = 53, size 1
  -- #33 reg = r0x44  key 32, rIdx = 68, size 1
  -- #34 reg = r0x53  key 32, rIdx = 83, size 1
  -- #35 reg = r0x62  key 32, rIdx = 98, size 1
  -- #36 reg = r0x71  key 32, rIdx = 113, size 1
  -- #37 reg = r0x80  key 32, rIdx = 128, size 1
  -- #38 reg = r0x27  key 33, rIdx = 39, size 1
  -- #39 reg = r0x36  key 33, rIdx = 54, size 1
  -- #40 reg = r0x45  key 33, rIdx = 69, size 1
  -- #41 reg = r0x54  key 33, rIdx = 84, size 1
  -- #42 reg = r0x63  key 33, rIdx = 99, size 1
  -- #43 reg = r0x72  key 33, rIdx = 114, size 1
  -- #44 reg = r0x81  key 33, rIdx = 129, size 1
  -- #45 reg = r0x28  key 34, rIdx = 40, size 1
  -- #46 reg = r0x37  key 34, rIdx = 55, size 1
  -- #47 reg = r0x46  key 34, rIdx = 70, size 1
  -- #48 reg = r0x55  key 34, rIdx = 85, size 1
  -- #49 reg = r0x64  key 34, rIdx = 100, size 1
  -- #50 reg = r0x73  key 34, rIdx = 115, size 1
  -- #51 reg = r0x82  key 34, rIdx = 130, size 1
  -- #52 reg = r0x29  key 35, rIdx = 41, size 1
  -- #53 reg = r0x38  key 35, rIdx = 56, size 1
  -- #54 reg = r0x47  key 35, rIdx = 71, size 1
  -- #55 reg = r0x56  key 35, rIdx = 86, size 1
  -- #56 reg = r0x65  key 35, rIdx = 101, size 1
  -- #57 reg = r0x74  key 35, rIdx = 116, size 1
  -- #58 reg = r0x83  key 35, rIdx = 131, size 1
  -- #59 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #60 reg = r0x39  key 36, rIdx = 57, size 1
  -- #61 reg = r0x48  key 36, rIdx = 72, size 1
  -- #62 reg = r0x57  key 36, rIdx = 87, size 1
  -- #63 reg = r0x66  key 36, rIdx = 102, size 1
  -- #64 reg = r0x75  key 36, rIdx = 117, size 1
  -- #65 reg = r0x84  key 36, rIdx = 132, size 1
  -- #66 reg = r0x49  key 37, rIdx = 73, size 1
  -- #67 reg = r0x58  key 37, rIdx = 88, size 1
  -- #68 reg = r0x67  key 37, rIdx = 103, size 1
  -- #69 reg = r0x76  key 37, rIdx = 118, size 1
  -- #70 reg = r0x85  key 37, rIdx = 133, size 1
  -- #71 reg = r0x59  key 38, rIdx = 89, size 1
  -- #72 reg = r0x68  key 38, rIdx = 104, size 1
  -- #73 reg = r0x77  key 38, rIdx = 119, size 1
  -- #74 reg = r0x69  key 39, rIdx = 105, size 1
  -- #75 reg = r0x78  key 39, rIdx = 120, size 1
  -- #76 reg = r0x79  key 40, rIdx = 121, size 1
  -- #77 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #78 reg = STK00  key 45, rIdx = 127, size 1
  -- #79 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #80 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #81 reg = STK01  key 46, rIdx = 126, size 1
  -- #82 reg = STK10  key 46, rIdx = 117, size 1
  -- #83 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #84 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #85 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #86 reg = STK02  key 47, rIdx = 125, size 1
  -- #87 reg = STK11  key 47, rIdx = 116, size 1
  -- #88 reg = INTCON  key 47, rIdx = 11, size 1
  -- #89 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #90 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #91 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #92 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #93 reg = STK03  key 48, rIdx = 124, size 1
  -- #94 reg = STK12  key 48, rIdx = 115, size 1
  -- #95 reg = PCL  key 48, rIdx = 2, size 1
  -- #96 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #97 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #98 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #99 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #100 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #101 reg = STK04  key 49, rIdx = 123, size 1
  -- #102 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #103 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #104 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #105 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #106 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #107 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #108 reg = STK05  key 50, rIdx = 122, size 1
  -- #109 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #110 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #111 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #112 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #113 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #114 reg = STK06  key 51, rIdx = 121, size 1
  -- #115 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #116 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #117 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #118 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #119 reg = STK07  key 52, rIdx = 120, size 1
  -- #120 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #121 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #122 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #123 reg = STK08  key 53, rIdx = 119, size 1
  -- #124 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #125 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #126 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #127 reg = STK09  key 55, rIdx = 118, size 1
  -- #128 reg = INDF  key 56, rIdx = 0, size 1
  -- #129 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  2697 - iTemp4
  2707 - itemp register
  reg name iTemp4,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: =
deassignLRs
  op: |
deassignLRs
  op: BITWISEAND
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: BITWISEAND
deassignLRs
  op: IFX
deassignLRs
  op: =
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (2) (3) (4) (5) (6) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (2) (4) (5) (6) }

----------------------------------------------------------------
libreria_skybot.c(l802:s1:k0:d0:s0)	 _entry($5) :
libreria_skybot.c(l802:s2:k1:d0:s0)		proc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libreria_skybot.c(l807:s3:k2:d0:s0)		_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x1 {literal-unsigned-char}
libreria_skybot.c(l808:s4:k3:d0:s0)		_ADCON1 [k3 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0xe {literal-unsigned-char}
libreria_skybot.c(l812:s5:k4:d0:s0)		_ADCON0 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x4 {literal-unsigned-char}
libreria_skybot.c(l815:s7:k6:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l817:s10:k9:d1:s0)	 _whilecontinue_2($1) :
libreria_skybot.c(l817:s11:k10:d1:s0)		iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l817:s12:k11:d1:s0)		if iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _whilecontinue_2($1)
libreria_skybot.c(l825:s13:k16:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := _ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l826:s15:k18:d0:s0)		ret _tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (8) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l817:s9:k21:d0:s0)	 preHeaderLbl0($6) :
libreria_skybot.c(l817:s10:k9:d1:s0)	 _whilecontinue_2($1) :
libreria_skybot.c(l817:s11:k10:d1:s0)		iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l817:s12:k11:d1:s0)		if iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _whilecontinue_2($1)
libreria_skybot.c(l825:s13:k16:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := _ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l826:s15:k18:d0:s0)		ret _tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_2 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 10 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (10) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (10) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (5) (10) }

----------------------------------------------------------------
libreria_skybot.c(l817:s10:k9:d1:s0)	 _whilecontinue_2($1) :
libreria_skybot.c(l817:s11:k10:d1:s0)		iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _ADCON0 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x4 {literal-unsigned-char}
libreria_skybot.c(l817:s12:k11:d1:s0)		if iTemp3 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto _whilecontinue_2($1)
libreria_skybot.c(l825:s13:k16:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := _ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l826:s15:k18:d0:s0)		ret _tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 13 , last iCode = 15
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

local defines bitVector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (8) (10) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (16) (17) }

----------------------------------------------------------------
libreria_skybot.c(l825:s13:k16:d0:s0)		_tmp [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := _ADRESH [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libreria_skybot.c(l826:s15:k18:d0:s0)		ret _tmp [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 16 , last iCode = 17
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 22 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

outDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { (3) (4) (5) (6) (7) (10) (16) (17) }

usesDefs Set bitvector :bitvector Size = 22 bSize = 3
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l826:s16:k19:d0:s0)	 _return($4) :
libreria_skybot.c(l826:s17:k20:d0:s0)		eproc _LeerLDR [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
Found a Direct Register!
Found a Direct Register!
newReg: Created register _ADRESH (004F7FE5).
  -- added _ADRESH to hash, size = 1
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 1
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 24 bSize = 4
Bits on { (23) }

local defines bitVector :bitvector Size = 24 bSize = 4
Bits on { (23) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 24 bSize = 4
Bits on { (23) }

usesDefs Set bitvector :bitvector Size = 24 bSize = 4
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l828:s1:k23:d0:s0)		_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := 0x0 {literal-unsigned-char}
packRegisters
packRegsForAssign
  result:_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _tmp
  703  storage class 0 
 708  integral
 712  specifier
_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
  result:_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
dir registers allocated so far:
  -- #0 reg = _ADRESH  key 0, rIdx = 2, size 1
  -- #1 reg = _TRISB  key 8, rIdx = 134, size 1
  -- #2 reg = STATUS  key 9, rIdx = 3, size 1
  -- #3 reg = _PORTA  key 10, rIdx = 0, size 1
  -- #4 reg = _PORTB  key 11, rIdx = 6, size 1
  -- #5 reg = _tmp  key 16, rIdx = 1, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = _ADCON0  key 27, rIdx = 31, size 1
  -- #10 reg = r0x22  key 28, rIdx = 34, size 1
  -- #11 reg = r0x31  key 28, rIdx = 49, size 1
  -- #12 reg = r0x40  key 28, rIdx = 64, size 1
  -- #13 reg = _ADCON1  key 28, rIdx = 159, size 1
  -- #14 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #15 reg = r0x23  key 29, rIdx = 35, size 1
  -- #16 reg = r0x32  key 29, rIdx = 50, size 1
  -- #17 reg = r0x41  key 29, rIdx = 65, size 1
  -- #18 reg = r0x50  key 29, rIdx = 80, size 1
  -- #19 reg = r0x24  key 30, rIdx = 36, size 1
  -- #20 reg = r0x33  key 30, rIdx = 51, size 1
  -- #21 reg = r0x42  key 30, rIdx = 66, size 1
  -- #22 reg = r0x51  key 30, rIdx = 81, size 1
  -- #23 reg = r0x60  key 30, rIdx = 96, size 1
  -- #24 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #25 reg = r0x25  key 31, rIdx = 37, size 1
  -- #26 reg = r0x34  key 31, rIdx = 52, size 1
  -- #27 reg = r0x43  key 31, rIdx = 67, size 1
  -- #28 reg = r0x52  key 31, rIdx = 82, size 1
  -- #29 reg = r0x61  key 31, rIdx = 97, size 1
  -- #30 reg = r0x70  key 31, rIdx = 112, size 1
  -- #31 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #32 reg = r0x26  key 32, rIdx = 38, size 1
  -- #33 reg = r0x35  key 32, rIdx = 53, size 1
  -- #34 reg = r0x44  key 32, rIdx = 68, size 1
  -- #35 reg = r0x53  key 32, rIdx = 83, size 1
  -- #36 reg = r0x62  key 32, rIdx = 98, size 1
  -- #37 reg = r0x71  key 32, rIdx = 113, size 1
  -- #38 reg = r0x80  key 32, rIdx = 128, size 1
  -- #39 reg = r0x27  key 33, rIdx = 39, size 1
  -- #40 reg = r0x36  key 33, rIdx = 54, size 1
  -- #41 reg = r0x45  key 33, rIdx = 69, size 1
  -- #42 reg = r0x54  key 33, rIdx = 84, size 1
  -- #43 reg = r0x63  key 33, rIdx = 99, size 1
  -- #44 reg = r0x72  key 33, rIdx = 114, size 1
  -- #45 reg = r0x81  key 33, rIdx = 129, size 1
  -- #46 reg = r0x28  key 34, rIdx = 40, size 1
  -- #47 reg = r0x37  key 34, rIdx = 55, size 1
  -- #48 reg = r0x46  key 34, rIdx = 70, size 1
  -- #49 reg = r0x55  key 34, rIdx = 85, size 1
  -- #50 reg = r0x64  key 34, rIdx = 100, size 1
  -- #51 reg = r0x73  key 34, rIdx = 115, size 1
  -- #52 reg = r0x82  key 34, rIdx = 130, size 1
  -- #53 reg = r0x29  key 35, rIdx = 41, size 1
  -- #54 reg = r0x38  key 35, rIdx = 56, size 1
  -- #55 reg = r0x47  key 35, rIdx = 71, size 1
  -- #56 reg = r0x56  key 35, rIdx = 86, size 1
  -- #57 reg = r0x65  key 35, rIdx = 101, size 1
  -- #58 reg = r0x74  key 35, rIdx = 116, size 1
  -- #59 reg = r0x83  key 35, rIdx = 131, size 1
  -- #60 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #61 reg = r0x39  key 36, rIdx = 57, size 1
  -- #62 reg = r0x48  key 36, rIdx = 72, size 1
  -- #63 reg = r0x57  key 36, rIdx = 87, size 1
  -- #64 reg = r0x66  key 36, rIdx = 102, size 1
  -- #65 reg = r0x75  key 36, rIdx = 117, size 1
  -- #66 reg = r0x84  key 36, rIdx = 132, size 1
  -- #67 reg = r0x49  key 37, rIdx = 73, size 1
  -- #68 reg = r0x58  key 37, rIdx = 88, size 1
  -- #69 reg = r0x67  key 37, rIdx = 103, size 1
  -- #70 reg = r0x76  key 37, rIdx = 118, size 1
  -- #71 reg = r0x85  key 37, rIdx = 133, size 1
  -- #72 reg = r0x59  key 38, rIdx = 89, size 1
  -- #73 reg = r0x68  key 38, rIdx = 104, size 1
  -- #74 reg = r0x77  key 38, rIdx = 119, size 1
  -- #75 reg = r0x69  key 39, rIdx = 105, size 1
  -- #76 reg = r0x78  key 39, rIdx = 120, size 1
  -- #77 reg = r0x79  key 40, rIdx = 121, size 1
  -- #78 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #79 reg = STK00  key 45, rIdx = 127, size 1
  -- #80 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #81 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #82 reg = STK01  key 46, rIdx = 126, size 1
  -- #83 reg = STK10  key 46, rIdx = 117, size 1
  -- #84 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #85 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #86 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #87 reg = STK02  key 47, rIdx = 125, size 1
  -- #88 reg = STK11  key 47, rIdx = 116, size 1
  -- #89 reg = INTCON  key 47, rIdx = 11, size 1
  -- #90 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #91 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #92 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #93 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #94 reg = STK03  key 48, rIdx = 124, size 1
  -- #95 reg = STK12  key 48, rIdx = 115, size 1
  -- #96 reg = PCL  key 48, rIdx = 2, size 1
  -- #97 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #98 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #99 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #100 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #101 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #102 reg = STK04  key 49, rIdx = 123, size 1
  -- #103 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #104 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #105 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #106 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #107 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #108 reg = r0x7A  key 49, rIdx = 122, size 1
  -- #109 reg = STK05  key 50, rIdx = 122, size 1
  -- #110 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #111 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #112 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #113 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #114 reg = r0x7B  key 50, rIdx = 123, size 1
  -- #115 reg = STK06  key 51, rIdx = 121, size 1
  -- #116 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #117 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #118 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #119 reg = r0x7C  key 51, rIdx = 124, size 1
  -- #120 reg = STK07  key 52, rIdx = 120, size 1
  -- #121 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #122 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #123 reg = r0x7D  key 52, rIdx = 125, size 1
  -- #124 reg = STK08  key 53, rIdx = 119, size 1
  -- #125 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #126 reg = r0x7E  key 53, rIdx = 126, size 1
  -- #127 reg = r0x7F  key 54, rIdx = 127, size 1
  -- #128 reg = STK09  key 55, rIdx = 118, size 1
  -- #129 reg = INDF  key 56, rIdx = 0, size 1
  -- #130 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: =
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 1
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 24 bSize = 4
Bits on { (23) }

local defines bitVector :bitvector Size = 24 bSize = 4
Bits on { (23) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 24 bSize = 4
Bits on { (23) }

usesDefs Set bitvector :bitvector Size = 24 bSize = 4
Bits on { }

----------------------------------------------------------------
libreria_skybot.c(l828:s1:k23:d0:s0)		_tmp [k11 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := 0x0 {literal-unsigned-char}
leaving
<><><><><><><><><><><><><><><><><>
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x84
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x84
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x80
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x80
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x85
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x83
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x82
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x81
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x28
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x32
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x35
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x31
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x34
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x44
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x46
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x46
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x44
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x34
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x31
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x35
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x32
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x28
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x25
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x26
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x27
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x29
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x36
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x33
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x45
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x47
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x3c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x40
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x4b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x49
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x48
Found a Dynamic Register!
