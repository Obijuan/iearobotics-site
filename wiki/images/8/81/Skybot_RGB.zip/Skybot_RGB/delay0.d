newReg: Created register STK00 (004FC4AE).
newReg: Created register STK01 (004FC4AE).
newReg: Created register STK02 (004FC4AE).
newReg: Created register STK03 (004FC4AE).
newReg: Created register STK04 (004FC4AE).
newReg: Created register STK05 (004FC4AE).
newReg: Created register STK06 (004FC4AE).
newReg: Created register STK07 (004FC4AE).
newReg: Created register STK08 (004FC4AE).
newReg: Created register STK09 (004FC4AE).
newReg: Created register STK10 (004FC4AE).
newReg: Created register STK11 (004FC4AE).
newReg: Created register STK12 (004FC4AE).
newReg: Created register STATUS (004FC441).
newReg: Created register PCL (004FC441).
newReg: Created register PCLATH (004FC441).
newReg: Created register FSR (004FC441).
newReg: Created register INDF (004FC441).
newReg: Created register INTCON (004FC441).
newReg: Created register WSAVE (004FC3F0).
newReg: Created register SSAVE (004FC3F0).
newReg: Created register PSAVE (004FC3F0).
newReg: Created register r0x20 (004F6C52).
newReg: Created register r0x21 (004F6C52).
newReg: Created register r0x22 (004F6C52).
newReg: Created register r0x23 (004F6C52).
newReg: Created register r0x24 (004F6C52).
newReg: Created register r0x25 (004F6C52).
newReg: Created register r0x26 (004F6C52).
Found a Processor Register!
newReg: Created register r0x27 (004F6C52).
newReg: Created register r0x28 (004F6C52).
newReg: Created register r0x29 (004F6C52).
newReg: Created register r0x2A (004F6C52).
newReg: Created register r0x2B (004F6C52).
newReg: Created register r0x2C (004F6C52).
newReg: Created register r0x2D (004F6C52).
newReg: Created register r0x2E (004F6C52).
newReg: Created register r0x2F (004F6C52).
newReg: Created register r0x30 (004F6C52).
newReg: Created register r0x31 (004F6C52).
newReg: Created register r0x32 (004F6C52).
newReg: Created register r0x33 (004F6C52).
newReg: Created register r0x34 (004F6C52).
newReg: Created register r0x35 (004F6C52).
newReg: Created register r0x36 (004F6C52).
newReg: Created register r0x37 (004F6C52).
newReg: Created register r0x38 (004F6C52).
newReg: Created register r0x39 (004F6C52).
newReg: Created register r0x3A (004F6C52).
newReg: Created register r0x3B (004F6C52).
newReg: Created register r0x3C (004F6C52).
newReg: Created register r0x3D (004F6C52).
newReg: Created register r0x3E (004F6C52).
newReg: Created register r0x3F (004F6C52).
newReg: Created register r0x40 (004F6C52).
newReg: Created register r0x41 (004F6C52).
newReg: Created register r0x42 (004F6C52).
newReg: Created register r0x43 (004F6C52).
newReg: Created register r0x44 (004F6C52).
newReg: Created register r0x45 (004F6C52).
newReg: Created register r0x46 (004F6C52).
newReg: Created register r0x47 (004F6C52).
newReg: Created register r0x48 (004F6C52).
newReg: Created register r0x49 (004F6C52).
newReg: Created register r0x4A (004F6C52).
newReg: Created register r0x4B (004F6C52).
newReg: Created register r0x4C (004F6C52).
newReg: Created register r0x4D (004F6C52).
newReg: Created register r0x4E (004F6C52).
newReg: Created register r0x4F (004F6C52).
newReg: Created register r0x50 (004F6C52).
newReg: Created register r0x51 (004F6C52).
newReg: Created register r0x52 (004F6C52).
newReg: Created register r0x53 (004F6C52).
newReg: Created register r0x54 (004F6C52).
newReg: Created register r0x55 (004F6C52).
newReg: Created register r0x56 (004F6C52).
newReg: Created register r0x57 (004F6C52).
newReg: Created register r0x58 (004F6C52).
newReg: Created register r0x59 (004F6C52).
Found a Processor Register!
newReg: Created register r0x5A (004F6C52).
newReg: Created register r0x5B (004F6C52).
newReg: Created register r0x5C (004F6C52).
Found a Processor Register!
newReg: Created register r0x5D (004F6C52).
newReg: Created register r0x5E (004F6C52).
newReg: Created register r0x5F (004F6C52).
newReg: Created register r0x60 (004F6C52).
newReg: Created register r0x61 (004F6C52).
newReg: Created register r0x62 (004F6C52).
Found a Processor Register!
newReg: Created register r0x63 (004F6C52).
newReg: Created register r0x64 (004F6C52).
newReg: Created register r0x65 (004F6C52).
Found a Processor Register!
newReg: Created register r0x66 (004F6C52).
newReg: Created register r0x67 (004F6C52).
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
delay0.c(l28:s1:k0:d0:s0)	 _entry($2) :
delay0.c(l28:s2:k1:d0:s0)		proc _timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
delay0.c(l31:s3:k2:d0:s0)		_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x87 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
delay0.c(l31:s4:k3:d0:s0)	 _return($1) :
delay0.c(l31:s5:k4:d0:s0)		eproc _timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x87 {literal-unsigned-char}
allocDirReg symbol name _OPTION_REG
  703  storage class 3 
 708  integral
 712  specifier
_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _OPTION_REG (004F829D).
  -- added _OPTION_REG to hash, size = 1
  -- and it is at a fixed address 0x81
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x87 {literal-unsigned-char}
  left:_timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = STATUS  key 9, rIdx = 3, size 1
  -- #1 reg = r0x20  key 26, rIdx = 32, size 1
  -- #2 reg = r0x21  key 27, rIdx = 33, size 1
  -- #3 reg = r0x30  key 27, rIdx = 48, size 1
  -- #4 reg = r0x22  key 28, rIdx = 34, size 1
  -- #5 reg = r0x31  key 28, rIdx = 49, size 1
  -- #6 reg = r0x40  key 28, rIdx = 64, size 1
  -- #7 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #8 reg = r0x23  key 29, rIdx = 35, size 1
  -- #9 reg = r0x32  key 29, rIdx = 50, size 1
  -- #10 reg = r0x41  key 29, rIdx = 65, size 1
  -- #11 reg = r0x50  key 29, rIdx = 80, size 1
  -- #12 reg = r0x24  key 30, rIdx = 36, size 1
  -- #13 reg = r0x33  key 30, rIdx = 51, size 1
  -- #14 reg = r0x42  key 30, rIdx = 66, size 1
  -- #15 reg = r0x51  key 30, rIdx = 81, size 1
  -- #16 reg = r0x60  key 30, rIdx = 96, size 1
  -- #17 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #18 reg = r0x25  key 31, rIdx = 37, size 1
  -- #19 reg = r0x34  key 31, rIdx = 52, size 1
  -- #20 reg = r0x43  key 31, rIdx = 67, size 1
  -- #21 reg = r0x52  key 31, rIdx = 82, size 1
  -- #22 reg = r0x61  key 31, rIdx = 97, size 1
  -- #23 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #24 reg = r0x26  key 32, rIdx = 38, size 1
  -- #25 reg = r0x35  key 32, rIdx = 53, size 1
  -- #26 reg = r0x44  key 32, rIdx = 68, size 1
  -- #27 reg = r0x53  key 32, rIdx = 83, size 1
  -- #28 reg = r0x62  key 32, rIdx = 98, size 1
  -- #29 reg = r0x27  key 33, rIdx = 39, size 1
  -- #30 reg = r0x36  key 33, rIdx = 54, size 1
  -- #31 reg = r0x45  key 33, rIdx = 69, size 1
  -- #32 reg = r0x54  key 33, rIdx = 84, size 1
  -- #33 reg = r0x63  key 33, rIdx = 99, size 1
  -- #34 reg = r0x28  key 34, rIdx = 40, size 1
  -- #35 reg = r0x37  key 34, rIdx = 55, size 1
  -- #36 reg = r0x46  key 34, rIdx = 70, size 1
  -- #37 reg = r0x55  key 34, rIdx = 85, size 1
  -- #38 reg = r0x64  key 34, rIdx = 100, size 1
  -- #39 reg = r0x29  key 35, rIdx = 41, size 1
  -- #40 reg = r0x38  key 35, rIdx = 56, size 1
  -- #41 reg = r0x47  key 35, rIdx = 71, size 1
  -- #42 reg = r0x56  key 35, rIdx = 86, size 1
  -- #43 reg = r0x65  key 35, rIdx = 101, size 1
  -- #44 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #45 reg = r0x39  key 36, rIdx = 57, size 1
  -- #46 reg = r0x48  key 36, rIdx = 72, size 1
  -- #47 reg = r0x57  key 36, rIdx = 87, size 1
  -- #48 reg = r0x66  key 36, rIdx = 102, size 1
  -- #49 reg = r0x49  key 37, rIdx = 73, size 1
  -- #50 reg = r0x58  key 37, rIdx = 88, size 1
  -- #51 reg = r0x67  key 37, rIdx = 103, size 1
  -- #52 reg = r0x59  key 38, rIdx = 89, size 1
  -- #53 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #54 reg = STK00  key 45, rIdx = 127, size 1
  -- #55 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #56 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #57 reg = STK01  key 46, rIdx = 126, size 1
  -- #58 reg = STK10  key 46, rIdx = 117, size 1
  -- #59 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #60 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #61 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #62 reg = STK02  key 47, rIdx = 125, size 1
  -- #63 reg = STK11  key 47, rIdx = 116, size 1
  -- #64 reg = INTCON  key 47, rIdx = 11, size 1
  -- #65 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #66 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #67 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #68 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #69 reg = STK03  key 48, rIdx = 124, size 1
  -- #70 reg = STK12  key 48, rIdx = 115, size 1
  -- #71 reg = PCL  key 48, rIdx = 2, size 1
  -- #72 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #73 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #74 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #75 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #76 reg = STK04  key 49, rIdx = 123, size 1
  -- #77 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #78 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #79 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #80 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #81 reg = STK05  key 50, rIdx = 122, size 1
  -- #82 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #83 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #84 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #85 reg = STK06  key 51, rIdx = 121, size 1
  -- #86 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #87 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #88 reg = STK07  key 52, rIdx = 120, size 1
  -- #89 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #90 reg = STK08  key 53, rIdx = 119, size 1
  -- #91 reg = STK09  key 55, rIdx = 118, size 1
  -- #92 reg = INDF  key 56, rIdx = 0, size 1
  -- #93 reg = _OPTION_REG  key 59, rIdx = 129, size 1
  -- #94 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
delay0.c(l28:s1:k0:d0:s0)	 _entry($2) :
delay0.c(l28:s2:k1:d0:s0)		proc _timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
delay0.c(l31:s3:k2:d0:s0)		_OPTION_REG [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x87 {literal-unsigned-char}
delay0.c(l31:s4:k3:d0:s0)	 _return($1) :
delay0.c(l31:s5:k4:d0:s0)		eproc _timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
delay0.c(l31:s4:k3:d0:s0)	 _return($1) :
delay0.c(l31:s5:k4:d0:s0)		eproc _timer0_configurar [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (2) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

----------------------------------------------------------------
delay0.c(l39:s1:k0:d0:s0)	 _entry($8) :
delay0.c(l39:s2:k1:d0:s0)		proc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
delay0.c(l39:s3:k2:d0:s0)	iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1} = recv _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block preHeaderLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (29) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (29) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

----------------------------------------------------------------
delay0.c(l43:s4:k28:d0:s0)	 preHeaderLbl1($12) :
delay0.c(l43:s5:k29:d0:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} := iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l43:s6:k3:d1:s0)	 _whilecontinue_0($4) :
delay0.c(l43:s7:k4:d1:s0)		if iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0 goto loopExitLbl2($13)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) (9) }

----------------------------------------------------------------
delay0.c(l44:s8:k7:d1:s0)		_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x3d {literal-unsigned-char}
delay0.c(l45:s9:k8:d1:s0)		iTemp1 [k6 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l45:s10:k9:d1:s0)		iTemp2 [k8 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } := iTemp1 [k6 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
delay0.c(l45:s11:k10:d1:s0)		*(iTemp2 [k8 lr10:11 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }) := 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 12 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { }

----------------------------------------------------------------
delay0.c(l48:s12:k27:d1:s0)	 preHeaderLbl0($10) :

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 2 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 13 , last iCode = 17
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

----------------------------------------------------------------
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp3 [k9 lr14:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s15:k13:d2:s0)		iTemp4 [k11 lr15:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } := iTemp3 [k9 lr14:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}} = @[iTemp4 [k11 lr15:16 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}} == 0 goto _whilecontinue_1($1)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 7 : bbnum = 6 1st iCode = 18 , last iCode = 19
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (21) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (21) (22) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)

----------------------------------------------------------------
Basic Block loopExitLbl2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 20 , last iCode = 20
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (31) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l51:s20:k30:d0:s0)	 loopExitLbl2($13) :

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 21 , last iCode = 22
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) (31) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) (31) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { }

----------------------------------------------------------------
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
packRegisters
  left:_delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  left:_delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
  result:iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}
  left:_delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
  right:
packRegisters
packRegsForAssign
  result:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}
  result:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:
  right:iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}
  right:iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}
         Symbol type: unsigned-char
  result:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x3d {literal-unsigned-char}
allocDirReg symbol name _TMR0
  703  storage class 3 
 708  integral
 712  specifier
_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _TMR0 (004F829D).
  -- added _TMR0 to hash, size = 1
  -- and it is at a fixed address 0x01
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x3d {literal-unsigned-char}
packRegsForAssign
  result:iTemp2 [k8 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp1 [k6 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp1 [k6 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
pointer is set
  result:iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x3d {literal-unsigned-char}
allocDirReg symbol name _TMR0
  703  storage class 3 
 708  integral
 712  specifier
_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _TMR0 to hash, size = 1
  -- and it is at a fixed address 0x01
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x3d {literal-unsigned-char}
pointer is set
  result:iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:0x0 {literal-unsigned-char}
  result:_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  left:_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}
    is volatile
        Symbol type: volatile-struct __00010042
  result:iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
          Symbol type: volatile-unsigned-bitfield {2,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  result:iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
          Symbol type: volatile-unsigned-bitfield {2,1} near* 
  3818 - Pointer set
  marking as a pointer (set) =>  result:iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3947 - pointer reg req = 0
packRegisters
packRegisters
packRegsForAssign
  result:iTemp4 [k11 lr15:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp3 [k9 lr14:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp3
  replacing with iTemp3
  result:iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp3 [k9 lr14:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}
    is volatile
        Symbol type: volatile-struct __00010042
  result:iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
          Symbol type: volatile-unsigned-bitfield {2,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  left:iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
        Symbol type: volatile-unsigned-bitfield {2,1} near* 
  result:iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}
          Symbol type: volatile-unsigned-bitfield {2,1}
  marking as a pointer (get) =>  left:iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3947 - pointer reg req = 0
  left:iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}
        Symbol type: volatile-unsigned-bitfield {2,1}
  3947 - pointer reg req = 0
packRegisters
  left:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegsForSupport
packRegsForAccUse
packRegisters
packRegisters
  left:_delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
        Symbol type: void function    ( unsigned-char) 
dir registers allocated so far:
  -- #0 reg = STATUS  key 9, rIdx = 3, size 1
  -- #1 reg = r0x20  key 26, rIdx = 32, size 1
  -- #2 reg = r0x21  key 27, rIdx = 33, size 1
  -- #3 reg = r0x30  key 27, rIdx = 48, size 1
  -- #4 reg = r0x22  key 28, rIdx = 34, size 1
  -- #5 reg = r0x31  key 28, rIdx = 49, size 1
  -- #6 reg = r0x40  key 28, rIdx = 64, size 1
  -- #7 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #8 reg = r0x23  key 29, rIdx = 35, size 1
  -- #9 reg = r0x32  key 29, rIdx = 50, size 1
  -- #10 reg = r0x41  key 29, rIdx = 65, size 1
  -- #11 reg = r0x50  key 29, rIdx = 80, size 1
  -- #12 reg = r0x24  key 30, rIdx = 36, size 1
  -- #13 reg = r0x33  key 30, rIdx = 51, size 1
  -- #14 reg = r0x42  key 30, rIdx = 66, size 1
  -- #15 reg = r0x51  key 30, rIdx = 81, size 1
  -- #16 reg = r0x60  key 30, rIdx = 96, size 1
  -- #17 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #18 reg = r0x25  key 31, rIdx = 37, size 1
  -- #19 reg = r0x34  key 31, rIdx = 52, size 1
  -- #20 reg = r0x43  key 31, rIdx = 67, size 1
  -- #21 reg = r0x52  key 31, rIdx = 82, size 1
  -- #22 reg = r0x61  key 31, rIdx = 97, size 1
  -- #23 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #24 reg = r0x26  key 32, rIdx = 38, size 1
  -- #25 reg = r0x35  key 32, rIdx = 53, size 1
  -- #26 reg = r0x44  key 32, rIdx = 68, size 1
  -- #27 reg = r0x53  key 32, rIdx = 83, size 1
  -- #28 reg = r0x62  key 32, rIdx = 98, size 1
  -- #29 reg = _TMR0  key 32, rIdx = 1, size 1
  -- #30 reg = r0x27  key 33, rIdx = 39, size 1
  -- #31 reg = r0x36  key 33, rIdx = 54, size 1
  -- #32 reg = r0x45  key 33, rIdx = 69, size 1
  -- #33 reg = r0x54  key 33, rIdx = 84, size 1
  -- #34 reg = r0x63  key 33, rIdx = 99, size 1
  -- #35 reg = r0x28  key 34, rIdx = 40, size 1
  -- #36 reg = r0x37  key 34, rIdx = 55, size 1
  -- #37 reg = r0x46  key 34, rIdx = 70, size 1
  -- #38 reg = r0x55  key 34, rIdx = 85, size 1
  -- #39 reg = r0x64  key 34, rIdx = 100, size 1
  -- #40 reg = r0x29  key 35, rIdx = 41, size 1
  -- #41 reg = r0x38  key 35, rIdx = 56, size 1
  -- #42 reg = r0x47  key 35, rIdx = 71, size 1
  -- #43 reg = r0x56  key 35, rIdx = 86, size 1
  -- #44 reg = r0x65  key 35, rIdx = 101, size 1
  -- #45 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #46 reg = r0x39  key 36, rIdx = 57, size 1
  -- #47 reg = r0x48  key 36, rIdx = 72, size 1
  -- #48 reg = r0x57  key 36, rIdx = 87, size 1
  -- #49 reg = r0x66  key 36, rIdx = 102, size 1
  -- #50 reg = r0x49  key 37, rIdx = 73, size 1
  -- #51 reg = r0x58  key 37, rIdx = 88, size 1
  -- #52 reg = r0x67  key 37, rIdx = 103, size 1
  -- #53 reg = r0x59  key 38, rIdx = 89, size 1
  -- #54 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #55 reg = STK00  key 45, rIdx = 127, size 1
  -- #56 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #57 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #58 reg = STK01  key 46, rIdx = 126, size 1
  -- #59 reg = STK10  key 46, rIdx = 117, size 1
  -- #60 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #61 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #62 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #63 reg = STK02  key 47, rIdx = 125, size 1
  -- #64 reg = STK11  key 47, rIdx = 116, size 1
  -- #65 reg = INTCON  key 47, rIdx = 11, size 1
  -- #66 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #67 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #68 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #69 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #70 reg = STK03  key 48, rIdx = 124, size 1
  -- #71 reg = STK12  key 48, rIdx = 115, size 1
  -- #72 reg = PCL  key 48, rIdx = 2, size 1
  -- #73 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #74 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #75 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #76 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #77 reg = STK04  key 49, rIdx = 123, size 1
  -- #78 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #79 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #80 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #81 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #82 reg = STK05  key 50, rIdx = 122, size 1
  -- #83 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #84 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #85 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #86 reg = STK06  key 51, rIdx = 121, size 1
  -- #87 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #88 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #89 reg = STK07  key 52, rIdx = 120, size 1
  -- #90 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #91 reg = STK08  key 53, rIdx = 119, size 1
  -- #92 reg = STK09  key 55, rIdx = 118, size 1
  -- #93 reg = INDF  key 56, rIdx = 0, size 1
  -- #94 reg = _OPTION_REG  key 59, rIdx = 129, size 1
  -- #95 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
  2697 - iTemp4
  2707 - itemp register
  reg name iTemp4,  reg type REG_GPR
  2697 - iTemp5
  2707 - itemp register
  reg name iTemp5,  reg type REG_GPR
  2697 - iTemp7
  2707 - itemp register
  reg name iTemp7,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 32 bSize = 5
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x68 (004F6C52).
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: =
deassignLRs
freeReg
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 32 bSize = 5
Bits on { (14) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: IFX
deassignLRs
  op: =
deassignLRs
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp2
isSpiltOnStack
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp4
isSpiltOnStack
  op: GET_VALUE_AT_ADDRESS
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 32 bSize = 5
Bits on { (12) (14) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x69 (004F6C52).
  2378 - 
positionRegs
  2394 - 
  2397 - 
  op: IFX
deassignLRs
  op: -
deassignLRs
freeReg
  op: GOTO
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (2) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

----------------------------------------------------------------
delay0.c(l39:s1:k0:d0:s0)	 _entry($8) :
delay0.c(l39:s2:k1:d0:s0)		proc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
delay0.c(l39:s3:k2:d0:s0)	iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}[r0x68 ] = recv _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
delay0.c(l43:s5:k29:d0:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] := iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}[r0x68 ]
delay0.c(l43:s6:k3:d1:s0)	 _whilecontinue_0($4) :
delay0.c(l43:s7:k4:d1:s0)		if iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] == 0 goto _return($7)
delay0.c(l44:s8:k7:d1:s0)		_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x3d {literal-unsigned-char}
delay0.c(l45:s9:k8:d1:s0)		iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l45:s11:k10:d1:s0)		*(iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]) := 0x0 {literal-unsigned-char}
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block preHeaderLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (29) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (29) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) }

----------------------------------------------------------------
delay0.c(l43:s4:k28:d0:s0)	 preHeaderLbl1($12) :
delay0.c(l43:s5:k29:d0:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] := iTemp0 [k2 lr3:5 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _delay0_pausa_1_1}[r0x68 ]
delay0.c(l43:s6:k3:d1:s0)	 _whilecontinue_0($4) :
delay0.c(l43:s7:k4:d1:s0)		if iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] == 0 goto _return($7)
delay0.c(l44:s8:k7:d1:s0)		_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x3d {literal-unsigned-char}
delay0.c(l45:s9:k8:d1:s0)		iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l45:s11:k10:d1:s0)		*(iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]) := 0x0 {literal-unsigned-char}
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l43:s6:k3:d1:s0)	 _whilecontinue_0($4) :
delay0.c(l43:s7:k4:d1:s0)		if iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] == 0 goto _return($7)
delay0.c(l44:s8:k7:d1:s0)		_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x3d {literal-unsigned-char}
delay0.c(l45:s9:k8:d1:s0)		iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l45:s11:k10:d1:s0)		*(iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]) := 0x0 {literal-unsigned-char}
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) (9) }

----------------------------------------------------------------
delay0.c(l44:s8:k7:d1:s0)		_TMR0 [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x3d {literal-unsigned-char}
delay0.c(l45:s9:k8:d1:s0)		iTemp2 [k8 lr9:11 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l45:s11:k10:d1:s0)		*(iTemp2 [k8 lr9:11 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]) := 0x0 {literal-unsigned-char}
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 12 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { }

----------------------------------------------------------------
delay0.c(l48:s12:k27:d1:s0)	 preHeaderLbl0($10) :
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 2 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 13 , last iCode = 17
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (12) (13) (14) }

----------------------------------------------------------------
delay0.c(l48:s13:k11:d2:s0)	 _whilecontinue_1($1) :
delay0.c(l48:s14:k12:d2:s0)		iTemp4 [k11 lr14:16 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}]
delay0.c(l48:s16:k14:d2:s0)		iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] = @[iTemp4 [k11 lr14:16 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
delay0.c(l48:s17:k15:d2:s0)		if iTemp5 [k12 lr16:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x69 ] == 0 goto _whilecontinue_1($1)
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 7 : bbnum = 6 1st iCode = 18 , last iCode = 19
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (21) }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (21) (22) }

pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

in pointers Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (8) }

inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l51:s18:k21:d1:s0)		iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] = iTemp7 [k14 lr5:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x68 ] - 0x1 {literal-unsigned-char}
delay0.c(l51:s19:k23:d1:s0)		 goto _whilecontinue_0($4)
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block loopExitLbl2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 20 , last iCode = 20
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :bitvector Size = 32 bSize = 5
Bits on { (31) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (2) (7) (8) (9) (12) (13) (14) (20) (21) (22) (29) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (21) (29) }

----------------------------------------------------------------
delay0.c(l51:s20:k30:d0:s0)	 loopExitLbl2($13) :
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 21 , last iCode = 22
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 32 bSize = 5
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) (31) }

outDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { (7) (8) (9) (12) (13) (14) (20) (21) (29) (31) }

usesDefs Set bitvector :bitvector Size = 32 bSize = 5
Bits on { }

----------------------------------------------------------------
delay0.c(l51:s21:k25:d0:s0)	 _return($7) :
delay0.c(l51:s22:k26:d0:s0)		eproc _delay0 [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char) }
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
allocDirReg symbol name _INTCON_bits
  703  storage class 0 
 712  specifier
_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}
  -- and it is at a fixed address 0x0b
allocDirReg symbol name _INTCON_bits
  703  storage class 0 
 712  specifier
_INTCON_bits [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010042}
  -- and it is at a fixed address 0x0b
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
leaving
<><><><><><><><><><><><><><><><><>
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
