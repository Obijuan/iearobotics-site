;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Thu Oct 30 09:38:38 2008
;--------------------------------------------------------
; PIC port for the 14-bit core
;--------------------------------------------------------
;	.module libreria_skybot
	list	p=16f876a
	radix dec
	include "p16f876a.inc"
;--------------------------------------------------------
; publics variables in this module
;--------------------------------------------------------
	global _tmp
	global _ConfigurarSkybot
	global _PausaTiempo
	global _Avanzar
	global _GirarIzq
	global _GirarDer
	global _Retroceder
	global _Parar
	global _SensorIR_Izq_Lee_Negro
	global _SensorIR_Der_Lee_Negro
	global _SensorIR_Izq_Lee_Blanco
	global _SensorIR_Der_Lee_Blanco
	global _LeerInfrarrojos
	global _LeerSensor1
	global _LeerSensor2
	global _LeerSensor3
	global _LeerSensor4
	global _Bumper_Izq_esta_apretado
	global _Bumper_Der_esta_apretado
	global _LeerBumperIzquierdo
	global _LeerBumperDerecho
	global _LeerPuertoALinea1
	global _LeerPuertoALinea2
	global _LeerPuertoALinea3
	global _LeerPuertoALinea4
	global _EncenderLed
	global _ApagarLed
	global _Led_esta_encendido
	global _Led_esta_apagado
	global _EstadoLed
	global _CambiarLed
	global _LeerPulsador
	global _Pulsador_esta_pulsado
	global _Pulsador_no_esta_pulsado
	global _LeerLDR
;--------------------------------------------------------
; extern variables in this module
;--------------------------------------------------------
	extern _delay0
	extern _timer0_configurar
	extern _EECON2
	extern _EECON1
	extern _EEADRH
	extern _EEDATH
	extern _EEADR
	extern _EEDATA
	extern _ADCON1
	extern _ADRESL
	extern _CVRCON
	extern _CMCON
	extern _SPBRG
	extern _TXSTA
	extern _SSPSTAT
	extern _SSPADD
	extern _PR2
	extern _SSPCON2
	extern _PCON
	extern _PIE2
	extern _PIE1
	extern _TRISC
	extern _TRISB
	extern _TRISA
	extern _OPTION_REG
	extern _ADCON0
	extern _ADRESH
	extern _CCP2CON
	extern _CCPR2H
	extern _CCPR2L
	extern _RCREG
	extern _TXREG
	extern _RCSTA
	extern _CCP1CON
	extern _CCPR1H
	extern _CCPR1L
	extern _SSPCON
	extern _SSPBUF
	extern _T2CON
	extern _TMR2
	extern _T1CON
	extern _TMR1H
	extern _TMR1L
	extern _PIR2
	extern _PIR1
	extern _INTCON
	extern _PCLATH
	extern _PORTC
	extern _PORTB
	extern _PORTA
	extern _FSR
	extern _STATUS
	extern _TMR0
	extern _TXSTA_bits
	extern _T2CON_bits
	extern _T1CON_bits
	extern _STATUS_bits
	extern _SSPSTAT_bits
	extern _SSPCON2_bits
	extern _SSPCON_bits
	extern _RCSTA_bits
	extern _PIR2_bits
	extern _PIR1_bits
	extern _PIE2_bits
	extern _PIE1_bits
	extern _PCON_bits
	extern _OPTION_REG_bits
	extern _INTCON_bits
	extern _EECON1_bits
	extern _CVRCON_bits
	extern _CMCON_bits
	extern _CCP2CON_bits
	extern _CCP1CON_bits
	extern _ADCON1_bits
	extern _ADCON0_bits
	extern _PCL
	extern _INDF
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; absolute symbol definitions
;--------------------------------------------------------

	extern PSAVE
	extern SSAVE
	extern WSAVE
	extern STK12
	extern STK11
	extern STK10
	extern STK09
	extern STK08
	extern STK07
	extern STK06
	extern STK05
	extern STK04
	extern STK03
	extern STK02
	extern STK01
	extern STK00
;	.area	RSEG    (DATA)
;--------------------------------------------------------
; udata
;--------------------------------------------------------
data_libreria_skybot	udata
;	.area	DSEG    (DATA)
udata_libreria_skybot_0	udata
_tmp	res	1
udata_libreria_skybot_1	udata
r0x49	res	1
udata_libreria_skybot_2	udata
r0x48	res	1
udata_libreria_skybot_3	udata
r0x4B	res	1
udata_libreria_skybot_4	udata
r0x4A	res	1
udata_libreria_skybot_5	udata
r0x42	res	1
udata_libreria_skybot_6	udata
r0x40	res	1
udata_libreria_skybot_7	udata
r0x3B	res	1
udata_libreria_skybot_8	udata
r0x3C	res	1
udata_libreria_skybot_9	udata
r0x3D	res	1
udata_libreria_skybot_10	udata
r0x3A	res	1
udata_libreria_skybot_11	udata
r0x39	res	1
udata_libreria_skybot_12	udata
r0x47	res	1
udata_libreria_skybot_13	udata
r0x45	res	1
udata_libreria_skybot_14	udata
r0x2C	res	1
udata_libreria_skybot_15	udata
r0x33	res	1
udata_libreria_skybot_16	udata
r0x36	res	1
udata_libreria_skybot_17	udata
r0x29	res	1
udata_libreria_skybot_18	udata
r0x27	res	1
udata_libreria_skybot_19	udata
r0x26	res	1
udata_libreria_skybot_20	udata
r0x25	res	1
udata_libreria_skybot_21	udata
r0x21	res	1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
;	udata_ovr
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
;	.area	BSEG    (BIT)
;--------------------------------------------------------
; code
;--------------------------------------------------------
code_libreria_skybot	code
;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerLDR	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_LeerLDR	;Function start
; 2 exit points
;	.line	807; "libreria_skybot.c"	ADCON0 = 0x01;  // enciendo el conversor
	MOVLW	0x01
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_ADCON0
;	.line	808; "libreria_skybot.c"	ADCON1 = 0x0E;  // configuro AN0 como entrada analogica, resto digital
	MOVLW	0x0e
	BSF	STATUS,5
	MOVWF	_ADCON1
;	.line	812; "libreria_skybot.c"	ADCON0 |= 0x04;
	BCF	STATUS,5
	BSF	_ADCON0,2
;	.line	815; "libreria_skybot.c"	tmp = ADCON0 & 0x04;
	MOVLW	0x04
	ANDWF	_ADCON0,W
	BANKSEL	_tmp
	MOVWF	_tmp
_00368_DS_
;	.line	817; "libreria_skybot.c"	while ( (ADCON0 & 0x04) == 0);
	BCF	STATUS,5
	BCF	STATUS,6
	BTFSS	_ADCON0,2
	GOTO	_00368_DS_
;	.line	825; "libreria_skybot.c"	tmp = ADRESH;
	MOVF	_ADRESH,W
	BANKSEL	_tmp
	MOVWF	_tmp
;	.line	826; "libreria_skybot.c"	return tmp;
	MOVF	_tmp,W
	RETURN	
; exit point of _LeerLDR

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Pulsador_no_esta_pulsado	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerPulsador
;   _LeerPulsador
;1 compiler assigned register :
;   r0x21
;; Starting pCode block
_Pulsador_no_esta_pulsado	;Function start
; 2 exit points
;	.line	768; "libreria_skybot.c"	if (LeerPulsador() == SIN_PULSAR) return VERDADERO;
	CALL	_LeerPulsador
	BANKSEL	r0x21
	MOVWF	r0x21
;;     peep 7 - Removed redundant move
	MOVF	r0x21,W
	BTFSS	STATUS,2
	GOTO	_00362_DS_
	MOVLW	0x01
	GOTO	_00363_DS_
_00362_DS_
;	.line	769; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00363_DS_
	RETURN	
; exit point of _Pulsador_no_esta_pulsado

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Pulsador_esta_pulsado	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerPulsador
;   _LeerPulsador
;1 compiler assigned register :
;   r0x23
;; Starting pCode block
_Pulsador_esta_pulsado	;Function start
; 2 exit points
;	.line	747; "libreria_skybot.c"	if (LeerPulsador() == PULSADO) return VERDADERO;
	CALL	_LeerPulsador
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x23
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00355_DS_
	MOVLW	0x01
	GOTO	_00356_DS_
_00355_DS_
;	.line	748; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00356_DS_
	RETURN	
; exit point of _Pulsador_esta_pulsado

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerPulsador	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x25
;; Starting pCode block
_LeerPulsador	;Function start
; 2 exit points
;	.line	726; "libreria_skybot.c"	if ((PORTB & SENSOR1) != 0) return SIN_PULSAR;
	MOVLW	0x01
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTB,W
	BANKSEL	r0x25
	MOVWF	r0x25
;;     peep 1 - test/jump to test/skip
	MOVF	r0x25,W
	BTFSC	STATUS,2
	GOTO	_00345_DS_
	MOVLW	0x00
	GOTO	_00346_DS_
_00345_DS_
;	.line	727; "libreria_skybot.c"	return PULSADO;
	MOVLW	0x01
_00346_DS_
	RETURN	
; exit point of _LeerPulsador

;***
;  pBlock Stats: dbName = C
;***
;entry:  _CambiarLed	;Function start
; 2 exit points
;has an exit
;functions called:
;   _EstadoLed
;   _EncenderLed
;   _ApagarLed
;   _EstadoLed
;   _EncenderLed
;   _ApagarLed
;1 compiler assigned register :
;   r0x26
;; Starting pCode block
_CambiarLed	;Function start
; 2 exit points
;	.line	693; "libreria_skybot.c"	if (EstadoLed()==0) {
	CALL	_EstadoLed
	BANKSEL	r0x26
	MOVWF	r0x26
;;     peep 7 - Removed redundant move
	MOVF	r0x26,W
	BTFSS	STATUS,2
	GOTO	_00337_DS_
;	.line	694; "libreria_skybot.c"	EncenderLed();
	CALL	_EncenderLed
	GOTO	_00339_DS_
_00337_DS_
;	.line	697; "libreria_skybot.c"	ApagarLed();
	CALL	_ApagarLed
_00339_DS_
	RETURN	
; exit point of _CambiarLed

;***
;  pBlock Stats: dbName = C
;***
;entry:  _EstadoLed	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_EstadoLed	;Function start
; 2 exit points
;	.line	672; "libreria_skybot.c"	if ( (PORTB&0x02)==0 ) return APAGADO;
	BCF	STATUS,5
	BCF	STATUS,6
	BTFSC	_PORTB,1
	GOTO	_00330_DS_
	MOVLW	0x00
	GOTO	_00331_DS_
_00330_DS_
;	.line	673; "libreria_skybot.c"	return ENCENDIDO;
	MOVLW	0x01
_00331_DS_
	RETURN	
; exit point of _EstadoLed

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Led_esta_apagado	;Function start
; 2 exit points
;has an exit
;functions called:
;   _EstadoLed
;   _EstadoLed
;1 compiler assigned register :
;   r0x27
;; Starting pCode block
_Led_esta_apagado	;Function start
; 2 exit points
;	.line	652; "libreria_skybot.c"	if (EstadoLed() == APAGADO) return VERDADERO;
	PAGESEL	_EstadoLed
	CALL	_EstadoLed
	PAGESEL	$
	BANKSEL	r0x27
	MOVWF	r0x27
;;     peep 7 - Removed redundant move
	MOVF	r0x27,W
	BTFSS	STATUS,2
	GOTO	_00323_DS_
	MOVLW	0x01
	GOTO	_00324_DS_
_00323_DS_
;	.line	653; "libreria_skybot.c"	return APAGADO;
	MOVLW	0x00
_00324_DS_
	RETURN	
; exit point of _Led_esta_apagado

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Led_esta_encendido	;Function start
; 2 exit points
;has an exit
;functions called:
;   _EstadoLed
;   _EstadoLed
;1 compiler assigned register :
;   r0x28
;; Starting pCode block
_Led_esta_encendido	;Function start
; 2 exit points
;	.line	631; "libreria_skybot.c"	if (EstadoLed() == ENCENDIDO) return VERDADERO;
	PAGESEL	_EstadoLed
	CALL	_EstadoLed
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x28
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00316_DS_
	MOVLW	0x01
	GOTO	_00317_DS_
_00316_DS_
;	.line	632; "libreria_skybot.c"	return APAGADO;
	MOVLW	0x00
_00317_DS_
	RETURN	
; exit point of _Led_esta_encendido

;***
;  pBlock Stats: dbName = C
;***
;entry:  _ApagarLed	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_ApagarLed	;Function start
; 2 exit points
;	.line	611; "libreria_skybot.c"	PORTB &= ~LED;
	BCF	STATUS,5
	BCF	STATUS,6
	BCF	_PORTB,1
	RETURN	
; exit point of _ApagarLed

;***
;  pBlock Stats: dbName = C
;***
;entry:  _EncenderLed	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_EncenderLed	;Function start
; 2 exit points
;	.line	592; "libreria_skybot.c"	PORTB |= LED;
	BCF	STATUS,5
	BCF	STATUS,6
	BSF	_PORTB,1
	RETURN	
; exit point of _EncenderLed

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerPuertoALinea4	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x29
;; Starting pCode block
_LeerPuertoALinea4	;Function start
; 2 exit points
;	.line	564; "libreria_skybot.c"	if ((PORTA & 0x08) != 0) return 1;
	MOVLW	0x08
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTA,W
	BANKSEL	r0x29
	MOVWF	r0x29
;;     peep 1 - test/jump to test/skip
	MOVF	r0x29,W
	BTFSC	STATUS,2
	GOTO	_00298_DS_
	MOVLW	0x01
	GOTO	_00299_DS_
_00298_DS_
;	.line	565; "libreria_skybot.c"	return 0;
	MOVLW	0x00
_00299_DS_
	RETURN	
; exit point of _LeerPuertoALinea4

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerPuertoALinea3	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x36
;; Starting pCode block
_LeerPuertoALinea3	;Function start
; 2 exit points
;	.line	544; "libreria_skybot.c"	if ((PORTA & 0x04) != 0) return 1;
	MOVLW	0x04
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTA,W
	BANKSEL	r0x36
	MOVWF	r0x36
;;     peep 1 - test/jump to test/skip
	MOVF	r0x36,W
	BTFSC	STATUS,2
	GOTO	_00288_DS_
	MOVLW	0x01
	GOTO	_00289_DS_
_00288_DS_
;	.line	545; "libreria_skybot.c"	return 0;
	MOVLW	0x00
_00289_DS_
	RETURN	
; exit point of _LeerPuertoALinea3

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerPuertoALinea2	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x33
;; Starting pCode block
_LeerPuertoALinea2	;Function start
; 2 exit points
;	.line	524; "libreria_skybot.c"	if ((PORTA & 0x02) != 0) return 1;
	MOVLW	0x02
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTA,W
	BANKSEL	r0x33
	MOVWF	r0x33
;;     peep 1 - test/jump to test/skip
	MOVF	r0x33,W
	BTFSC	STATUS,2
	GOTO	_00278_DS_
	MOVLW	0x01
	GOTO	_00279_DS_
_00278_DS_
;	.line	525; "libreria_skybot.c"	return 0;
	MOVLW	0x00
_00279_DS_
	RETURN	
; exit point of _LeerPuertoALinea2

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerPuertoALinea1	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x2C
;; Starting pCode block
_LeerPuertoALinea1	;Function start
; 2 exit points
;	.line	504; "libreria_skybot.c"	if ((PORTA & 0x01) != 0) return 1;
	MOVLW	0x01
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTA,W
	BANKSEL	r0x2C
	MOVWF	r0x2C
;;     peep 1 - test/jump to test/skip
	MOVF	r0x2C,W
	BTFSC	STATUS,2
	GOTO	_00268_DS_
	MOVLW	0x01
	GOTO	_00269_DS_
_00268_DS_
;	.line	505; "libreria_skybot.c"	return 0;
	MOVLW	0x00
_00269_DS_
	RETURN	
; exit point of _LeerPuertoALinea1

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerBumperDerecho	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerPuertoALinea2
;   _LeerPuertoALinea2
;1 compiler assigned register :
;   r0x32
;; Starting pCode block
_LeerBumperDerecho	;Function start
; 2 exit points
;	.line	484; "libreria_skybot.c"	if (LeerPuertoALinea2() == 1) return APRETADO;
	PAGESEL	_LeerPuertoALinea2
	CALL	_LeerPuertoALinea2
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x32
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00261_DS_
	MOVLW	0x01
	GOTO	_00262_DS_
_00261_DS_
;	.line	485; "libreria_skybot.c"	return SIN_APRETAR;
	MOVLW	0x00
_00262_DS_
	RETURN	
; exit point of _LeerBumperDerecho

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerBumperIzquierdo	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerPuertoALinea3
;   _LeerPuertoALinea3
;1 compiler assigned register :
;   r0x35
;; Starting pCode block
_LeerBumperIzquierdo	;Function start
; 2 exit points
;	.line	463; "libreria_skybot.c"	if (LeerPuertoALinea3() == 1) return APRETADO;
	PAGESEL	_LeerPuertoALinea3
	CALL	_LeerPuertoALinea3
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x35
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00254_DS_
	MOVLW	0x01
	GOTO	_00255_DS_
_00254_DS_
;	.line	464; "libreria_skybot.c"	return SIN_APRETAR;
	MOVLW	0x00
_00255_DS_
	RETURN	
; exit point of _LeerBumperIzquierdo

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Bumper_Der_esta_apretado	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerBumperDerecho
;   _LeerBumperDerecho
;1 compiler assigned register :
;   r0x31
;; Starting pCode block
_Bumper_Der_esta_apretado	;Function start
; 2 exit points
;	.line	442; "libreria_skybot.c"	if (LeerBumperDerecho() == APRETADO) return VERDADERO;
	PAGESEL	_LeerBumperDerecho
	CALL	_LeerBumperDerecho
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x31
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00247_DS_
	MOVLW	0x01
	GOTO	_00248_DS_
_00247_DS_
;	.line	443; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00248_DS_
	RETURN	
; exit point of _Bumper_Der_esta_apretado

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Bumper_Izq_esta_apretado	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerBumperIzquierdo
;   _LeerBumperIzquierdo
;1 compiler assigned register :
;   r0x34
;; Starting pCode block
_Bumper_Izq_esta_apretado	;Function start
; 2 exit points
;	.line	422; "libreria_skybot.c"	if (LeerBumperIzquierdo() == APRETADO) return VERDADERO;
	PAGESEL	_LeerBumperIzquierdo
	CALL	_LeerBumperIzquierdo
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x34
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00240_DS_
	MOVLW	0x01
	GOTO	_00241_DS_
_00240_DS_
;	.line	423; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00241_DS_
	RETURN	
; exit point of _Bumper_Izq_esta_apretado

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerSensor4	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x45
;; Starting pCode block
_LeerSensor4	;Function start
; 2 exit points
;	.line	402; "libreria_skybot.c"	if ((PORTB & SENSOR4) != 0) return NEGRO;
	MOVLW	0x80
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTB,W
	BANKSEL	r0x45
	MOVWF	r0x45
;;     peep 1 - test/jump to test/skip
	MOVF	r0x45,W
	BTFSC	STATUS,2
	GOTO	_00230_DS_
	MOVLW	0x01
	GOTO	_00231_DS_
_00230_DS_
;	.line	403; "libreria_skybot.c"	return BLANCO;
	MOVLW	0x00
_00231_DS_
	RETURN	
; exit point of _LeerSensor4

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerSensor3	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x47
;; Starting pCode block
_LeerSensor3	;Function start
; 2 exit points
;	.line	382; "libreria_skybot.c"	if ((PORTB & SENSOR3) != 0) return NEGRO;
	MOVLW	0x40
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTB,W
	BANKSEL	r0x47
	MOVWF	r0x47
;;     peep 1 - test/jump to test/skip
	MOVF	r0x47,W
	BTFSC	STATUS,2
	GOTO	_00220_DS_
	MOVLW	0x01
	GOTO	_00221_DS_
_00220_DS_
;	.line	383; "libreria_skybot.c"	return BLANCO;
	MOVLW	0x00
_00221_DS_
	RETURN	
; exit point of _LeerSensor3

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerSensor2	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x39
;; Starting pCode block
_LeerSensor2	;Function start
; 2 exit points
;	.line	362; "libreria_skybot.c"	if ((PORTB & SENSOR2) != 0) return NEGRO;
	MOVLW	0x20
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTB,W
	BANKSEL	r0x39
	MOVWF	r0x39
;;     peep 1 - test/jump to test/skip
	MOVF	r0x39,W
	BTFSC	STATUS,2
	GOTO	_00210_DS_
	MOVLW	0x01
	GOTO	_00211_DS_
_00210_DS_
;	.line	363; "libreria_skybot.c"	return BLANCO;
	MOVLW	0x00
_00211_DS_
	RETURN	
; exit point of _LeerSensor2

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerSensor1	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x3A
;; Starting pCode block
_LeerSensor1	;Function start
; 2 exit points
;	.line	342; "libreria_skybot.c"	if ((PORTB & SENSOR1) != 0) return NEGRO;
	MOVLW	0x01
	BCF	STATUS,5
	BCF	STATUS,6
	ANDWF	_PORTB,W
	BANKSEL	r0x3A
	MOVWF	r0x3A
;;     peep 1 - test/jump to test/skip
	MOVF	r0x3A,W
	BTFSC	STATUS,2
	GOTO	_00200_DS_
	MOVLW	0x01
	GOTO	_00201_DS_
_00200_DS_
;	.line	343; "libreria_skybot.c"	return BLANCO;
	MOVLW	0x00
_00201_DS_
	RETURN	
; exit point of _LeerSensor1

;***
;  pBlock Stats: dbName = C
;***
;entry:  _LeerInfrarrojos	;Function start
; 2 exit points
;has an exit
;functions called:
;   _SensorIR_Izq_Lee_Negro
;   _SensorIR_Der_Lee_Negro
;   _SensorIR_Izq_Lee_Negro
;   _SensorIR_Der_Lee_Negro
;3 compiler assigned registers:
;   r0x3B
;   r0x3C
;   r0x3D
;; Starting pCode block
_LeerInfrarrojos	;Function start
; 2 exit points
;	.line	316; "libreria_skybot.c"	unsigned char sI=0,sD=0;
	BANKSEL	r0x3B
	CLRF	r0x3B
	CLRF	r0x3C
;	.line	318; "libreria_skybot.c"	if (SensorIR_Izq_Lee_Negro()) sI=1;
	CALL	_SensorIR_Izq_Lee_Negro
	BANKSEL	r0x3D
	MOVWF	r0x3D
;;     peep 7 - Removed redundant move
	MOVF	r0x3D,W
	BTFSC	STATUS,2
	GOTO	_00185_DS_
	MOVLW	0x01
	MOVWF	r0x3B
_00185_DS_
;	.line	319; "libreria_skybot.c"	if (SensorIR_Der_Lee_Negro()) sD=1;
	CALL	_SensorIR_Der_Lee_Negro
	BANKSEL	r0x3D
	MOVWF	r0x3D
;;     peep 7 - Removed redundant move
	MOVF	r0x3D,W
	BTFSC	STATUS,2
	GOTO	_00187_DS_
	MOVLW	0x01
	MOVWF	r0x3C
_00187_DS_
;	.line	321; "libreria_skybot.c"	if (sI && sD) return 3;
	MOVLW	0x00
	IORWF	r0x3B,W
	BTFSC	STATUS,2
	GOTO	_00191_DS_
;;     peep 7 - Removed redundant move
	MOVF	r0x3C,W
	BTFSC	STATUS,2
	GOTO	_00191_DS_
	MOVLW	0x03
	GOTO	_00194_DS_
_00191_DS_
;	.line	322; "libreria_skybot.c"	else if (sD) return 2;
	MOVLW	0x00
	IORWF	r0x3C,W
	BTFSC	STATUS,2
	GOTO	_00192_DS_
	MOVLW	0x02
	GOTO	_00194_DS_
_00192_DS_
;	.line	323; "libreria_skybot.c"	return 1;
	MOVLW	0x01
_00194_DS_
	RETURN	
; exit point of _LeerInfrarrojos

;***
;  pBlock Stats: dbName = C
;***
;entry:  _SensorIR_Der_Lee_Blanco	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerSensor4
;   _LeerSensor4
;1 compiler assigned register :
;   r0x40
;; Starting pCode block
_SensorIR_Der_Lee_Blanco	;Function start
; 2 exit points
;	.line	289; "libreria_skybot.c"	if (LeerSensor4() == BLANCO) return VERDADERO;
	PAGESEL	_LeerSensor4
	CALL	_LeerSensor4
	PAGESEL	$
	BANKSEL	r0x40
	MOVWF	r0x40
;;     peep 7 - Removed redundant move
	MOVF	r0x40,W
	BTFSS	STATUS,2
	GOTO	_00178_DS_
	MOVLW	0x01
	GOTO	_00179_DS_
_00178_DS_
;	.line	290; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00179_DS_
	RETURN	
; exit point of _SensorIR_Der_Lee_Blanco

;***
;  pBlock Stats: dbName = C
;***
;entry:  _SensorIR_Izq_Lee_Blanco	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerSensor3
;   _LeerSensor3
;1 compiler assigned register :
;   r0x42
;; Starting pCode block
_SensorIR_Izq_Lee_Blanco	;Function start
; 2 exit points
;	.line	268; "libreria_skybot.c"	if (LeerSensor3() == BLANCO) return VERDADERO;
	PAGESEL	_LeerSensor3
	CALL	_LeerSensor3
	PAGESEL	$
	BANKSEL	r0x42
	MOVWF	r0x42
;;     peep 7 - Removed redundant move
	MOVF	r0x42,W
	BTFSS	STATUS,2
	GOTO	_00171_DS_
	MOVLW	0x01
	GOTO	_00172_DS_
_00171_DS_
;	.line	269; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00172_DS_
	RETURN	
; exit point of _SensorIR_Izq_Lee_Blanco

;***
;  pBlock Stats: dbName = C
;***
;entry:  _SensorIR_Der_Lee_Negro	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerSensor4
;   _LeerSensor4
;1 compiler assigned register :
;   r0x44
;; Starting pCode block
_SensorIR_Der_Lee_Negro	;Function start
; 2 exit points
;	.line	247; "libreria_skybot.c"	if (LeerSensor4() == NEGRO) return VERDADERO;
	PAGESEL	_LeerSensor4
	CALL	_LeerSensor4
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x44
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00164_DS_
	MOVLW	0x01
	GOTO	_00165_DS_
_00164_DS_
;	.line	248; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00165_DS_
	RETURN	
; exit point of _SensorIR_Der_Lee_Negro

;***
;  pBlock Stats: dbName = C
;***
;entry:  _SensorIR_Izq_Lee_Negro	;Function start
; 2 exit points
;has an exit
;functions called:
;   _LeerSensor3
;   _LeerSensor3
;1 compiler assigned register :
;   r0x46
;; Starting pCode block
_SensorIR_Izq_Lee_Negro	;Function start
; 2 exit points
;	.line	226; "libreria_skybot.c"	if (LeerSensor3() == NEGRO) return VERDADERO;
	PAGESEL	_LeerSensor3
	CALL	_LeerSensor3
	PAGESEL	$
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x46
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00157_DS_
	MOVLW	0x01
	GOTO	_00158_DS_
_00157_DS_
;	.line	227; "libreria_skybot.c"	return FALSO;
	MOVLW	0x00
_00158_DS_
	RETURN	
; exit point of _SensorIR_Izq_Lee_Negro

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Parar	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_Parar	;Function start
; 2 exit points
;	.line	206; "libreria_skybot.c"	PORTB=STOP;
	BCF	STATUS,5
	BCF	STATUS,6
	CLRF	_PORTB
	RETURN	
; exit point of _Parar

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Retroceder	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_Retroceder	;Function start
; 2 exit points
;	.line	185; "libreria_skybot.c"	PORTB=ATRAS;
	MOVLW	0x16
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_PORTB
	RETURN	
; exit point of _Retroceder

;***
;  pBlock Stats: dbName = C
;***
;entry:  _GirarDer	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_GirarDer	;Function start
; 2 exit points
;	.line	164; "libreria_skybot.c"	PORTB=DERECHA;
	MOVLW	0x14
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_PORTB
	RETURN	
; exit point of _GirarDer

;***
;  pBlock Stats: dbName = C
;***
;entry:  _GirarIzq	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_GirarIzq	;Function start
; 2 exit points
;	.line	142; "libreria_skybot.c"	PORTB=IZQUIERDA;
	MOVLW	0x1e
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_PORTB
;	.line	143; "libreria_skybot.c"	return;
	RETURN	
; exit point of _GirarIzq

;***
;  pBlock Stats: dbName = C
;***
;entry:  _Avanzar	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_Avanzar	;Function start
; 2 exit points
;	.line	120; "libreria_skybot.c"	PORTB=AVANZA;
	MOVLW	0x1c
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_PORTB
;	.line	121; "libreria_skybot.c"	return;
	RETURN	
; exit point of _Avanzar

;***
;  pBlock Stats: dbName = C
;***
;entry:  _PausaTiempo	;Function start
; 2 exit points
;has an exit
;functions called:
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;   _delay0
;8 compiler assigned registers:
;   r0x48
;   STK00
;   r0x49
;   STK01
;   r0x4A
;   STK02
;   r0x4B
;   r0x4C
;; Starting pCode block
_PausaTiempo	;Function start
; 2 exit points
;	.line	78; "libreria_skybot.c"	void PausaTiempo(unsigned int segundos,unsigned int centesimas)
	BANKSEL	r0x48
	MOVWF	r0x48
	MOVF	STK00,W
	MOVWF	r0x49
	MOVF	STK01,W
	MOVWF	r0x4A
	MOVF	STK02,W
	MOVWF	r0x4B
;swapping arguments (AOP_TYPEs 1/2)
;unsigned compare: left >= lit(0x100=256), size=2
_00109_DS_
;	.line	81; "libreria_skybot.c"	while (centesimas > 255)
	MOVLW	0x01
	SUBWF	r0x4A,W
	BTFSS	STATUS,2
	GOTO	_00130_DS_
	MOVLW	0x00
	SUBWF	r0x4B,W
_00130_DS_
	BTFSS	STATUS,0
	GOTO	_00111_DS_
;genSkipc:3831: created from rifx:002256BC
;	.line	83; "libreria_skybot.c"	delay0(255);
	MOVLW	0xff
	PAGESEL	_delay0
	CALL	_delay0
	PAGESEL	$
;	.line	84; "libreria_skybot.c"	centesimas-=255;
	BANKSEL	r0x4B
	INCFSZ	r0x4B,F
	DECF	r0x4A,F
	GOTO	_00109_DS_
_00111_DS_
;	.line	86; "libreria_skybot.c"	delay0(centesimas);
	MOVF	r0x4B,W
;;     peep 2 - Removed redundant move
;;1	MOVWF	r0x4C
	PAGESEL	_delay0
	CALL	_delay0
	PAGESEL	$
;swapping arguments (AOP_TYPEs 1/2)
;unsigned compare: left >= lit(0x3=3), size=2
_00112_DS_
;	.line	88; "libreria_skybot.c"	while (segundos > 2)
	MOVLW	0x00
	BANKSEL	r0x48
	SUBWF	r0x48,W
	BTFSS	STATUS,2
	GOTO	_00131_DS_
	MOVLW	0x03
	SUBWF	r0x49,W
_00131_DS_
	BTFSS	STATUS,0
	GOTO	_00114_DS_
;genSkipc:3831: created from rifx:002256BC
;	.line	90; "libreria_skybot.c"	delay0(200);
	MOVLW	0xc8
	PAGESEL	_delay0
	CALL	_delay0
	PAGESEL	$
;	.line	91; "libreria_skybot.c"	segundos-=2;
	MOVLW	0xfe
	BANKSEL	r0x49
	ADDWF	r0x49,F
	BTFSS	STATUS,0
	DECF	r0x48,F
	GOTO	_00112_DS_
_00114_DS_
;	.line	93; "libreria_skybot.c"	if (segundos==2) {
	MOVF	r0x49,W
	XORLW	0x02
	BTFSS	STATUS,2
	GOTO	_00118_DS_
	MOVF	r0x48,W
	XORLW	0x00
	BTFSS	STATUS,2
	GOTO	_00118_DS_
;	.line	94; "libreria_skybot.c"	delay0(200);
	MOVLW	0xc8
	PAGESEL	_delay0
	CALL	_delay0
	PAGESEL	$
	GOTO	_00120_DS_
_00118_DS_
;	.line	96; "libreria_skybot.c"	else if (segundos==1) {
	BANKSEL	r0x49
	MOVF	r0x49,W
	XORLW	0x01
	BTFSS	STATUS,2
	GOTO	_00120_DS_
	MOVF	r0x48,W
	XORLW	0x00
	BTFSS	STATUS,2
	GOTO	_00120_DS_
;	.line	97; "libreria_skybot.c"	delay0(100);
	MOVLW	0x64
	PAGESEL	_delay0
	CALL	_delay0
	PAGESEL	$
_00120_DS_
	RETURN	
; exit point of _PausaTiempo

;***
;  pBlock Stats: dbName = C
;***
;entry:  _ConfigurarSkybot	;Function start
; 2 exit points
;has an exit
;functions called:
;   _timer0_configurar
;   _timer0_configurar
;; Starting pCode block
_ConfigurarSkybot	;Function start
; 2 exit points
;	.line	48; "libreria_skybot.c"	TRISB=0xE1;
	MOVLW	0xe1
	BSF	STATUS,5
	BCF	STATUS,6
	MOVWF	_TRISB
;	.line	52; "libreria_skybot.c"	ADCON1 = 0x0E;
	MOVLW	0x0e
	MOVWF	_ADCON1
;	.line	55; "libreria_skybot.c"	timer0_configurar();
	PAGESEL	_timer0_configurar
	CALL	_timer0_configurar
	PAGESEL	$
	RETURN	
; exit point of _ConfigurarSkybot


;	code size estimation:
;	  377+   56 =   433 instructions (  978 byte)

	end
