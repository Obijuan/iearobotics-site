newReg: Created register STK00 (004FC4AE).
newReg: Created register STK01 (004FC4AE).
newReg: Created register STK02 (004FC4AE).
newReg: Created register STK03 (004FC4AE).
newReg: Created register STK04 (004FC4AE).
newReg: Created register STK05 (004FC4AE).
newReg: Created register STK06 (004FC4AE).
newReg: Created register STK07 (004FC4AE).
newReg: Created register STK08 (004FC4AE).
newReg: Created register STK09 (004FC4AE).
newReg: Created register STK10 (004FC4AE).
newReg: Created register STK11 (004FC4AE).
newReg: Created register STK12 (004FC4AE).
newReg: Created register STATUS (004FC441).
newReg: Created register PCL (004FC441).
newReg: Created register PCLATH (004FC441).
newReg: Created register FSR (004FC441).
newReg: Created register INDF (004FC441).
newReg: Created register INTCON (004FC441).
newReg: Created register WSAVE (004FC3F0).
newReg: Created register SSAVE (004FC3F0).
newReg: Created register PSAVE (004FC3F0).
newReg: Created register r0x20 (004F6C52).
newReg: Created register r0x21 (004F6C52).
newReg: Created register r0x22 (004F6C52).
newReg: Created register r0x23 (004F6C52).
newReg: Created register r0x24 (004F6C52).
newReg: Created register r0x25 (004F6C52).
newReg: Created register r0x26 (004F6C52).
Found a Processor Register!
newReg: Created register r0x27 (004F6C52).
newReg: Created register r0x28 (004F6C52).
newReg: Created register r0x29 (004F6C52).
newReg: Created register r0x2A (004F6C52).
newReg: Created register r0x2B (004F6C52).
newReg: Created register r0x2C (004F6C52).
newReg: Created register r0x2D (004F6C52).
newReg: Created register r0x2E (004F6C52).
newReg: Created register r0x2F (004F6C52).
newReg: Created register r0x30 (004F6C52).
newReg: Created register r0x31 (004F6C52).
newReg: Created register r0x32 (004F6C52).
newReg: Created register r0x33 (004F6C52).
newReg: Created register r0x34 (004F6C52).
newReg: Created register r0x35 (004F6C52).
newReg: Created register r0x36 (004F6C52).
newReg: Created register r0x37 (004F6C52).
newReg: Created register r0x38 (004F6C52).
newReg: Created register r0x39 (004F6C52).
newReg: Created register r0x3A (004F6C52).
newReg: Created register r0x3B (004F6C52).
newReg: Created register r0x3C (004F6C52).
newReg: Created register r0x3D (004F6C52).
newReg: Created register r0x3E (004F6C52).
newReg: Created register r0x3F (004F6C52).
newReg: Created register r0x40 (004F6C52).
newReg: Created register r0x41 (004F6C52).
newReg: Created register r0x42 (004F6C52).
newReg: Created register r0x43 (004F6C52).
newReg: Created register r0x44 (004F6C52).
newReg: Created register r0x45 (004F6C52).
newReg: Created register r0x46 (004F6C52).
newReg: Created register r0x47 (004F6C52).
newReg: Created register r0x48 (004F6C52).
newReg: Created register r0x49 (004F6C52).
newReg: Created register r0x4A (004F6C52).
newReg: Created register r0x4B (004F6C52).
newReg: Created register r0x4C (004F6C52).
newReg: Created register r0x4D (004F6C52).
newReg: Created register r0x4E (004F6C52).
newReg: Created register r0x4F (004F6C52).
newReg: Created register r0x50 (004F6C52).
newReg: Created register r0x51 (004F6C52).
newReg: Created register r0x52 (004F6C52).
newReg: Created register r0x53 (004F6C52).
newReg: Created register r0x54 (004F6C52).
newReg: Created register r0x55 (004F6C52).
newReg: Created register r0x56 (004F6C52).
newReg: Created register r0x57 (004F6C52).
newReg: Created register r0x58 (004F6C52).
newReg: Created register r0x59 (004F6C52).
Found a Processor Register!
newReg: Created register r0x5A (004F6C52).
newReg: Created register r0x5B (004F6C52).
newReg: Created register r0x5C (004F6C52).
Found a Processor Register!
newReg: Created register r0x5D (004F6C52).
newReg: Created register r0x5E (004F6C52).
newReg: Created register r0x5F (004F6C52).
newReg: Created register r0x60 (004F6C52).
newReg: Created register r0x61 (004F6C52).
newReg: Created register r0x62 (004F6C52).
Found a Processor Register!
newReg: Created register r0x63 (004F6C52).
newReg: Created register r0x64 (004F6C52).
newReg: Created register r0x65 (004F6C52).
Found a Processor Register!
newReg: Created register r0x66 (004F6C52).
newReg: Created register r0x67 (004F6C52).
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 2
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l23:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l23:s2:k1:d0:s0)		proc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 3 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (15) }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (15) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l27:s3:k14:d0:s0)	 preHeaderLbl0($7) :
libRGB.c(l27:s4:k15:d0:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1} := 0x1f4 {literal-unsigned-int}

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l27:s5:k3:d1:s0)	 _whilecontinue_0($1) :
libRGB.c(l27:s6:k4:d1:s0)		if iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1} == 0 goto loopExitLbl1($8)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 4 : bbnum = 3 1st iCode = 7 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (8) }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (8) (9) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l28:s7:k8:d1:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1} = iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1} - 0x1 {literal-unsigned-char}
libRGB.c(l28:s8:k10:d1:s0)		 goto _whilecontinue_0($1)

----------------------------------------------------------------
Basic Block loopExitLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l28:s9:k16:d0:s0)	 loopExitLbl1($8) :

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 10 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) (17) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) (17) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
  left:_pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
packRegisters
packRegsForAssign
  result:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
  left:
  right:0x1f4 {literal-unsigned-int}
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
  left:
  right:0x1f4 {literal-unsigned-int}
  result:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegisters
  left:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
        Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegisters
  left:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
        Symbol type: unsigned-int
  result:iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}
          Symbol type: unsigned-int
  3947 - pointer reg req = 0
packRegsForSupport
packRegsForAccUse
packRegisters
packRegisters
  left:_pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = STATUS  key 9, rIdx = 3, size 1
  -- #1 reg = r0x20  key 26, rIdx = 32, size 1
  -- #2 reg = r0x21  key 27, rIdx = 33, size 1
  -- #3 reg = r0x30  key 27, rIdx = 48, size 1
  -- #4 reg = r0x22  key 28, rIdx = 34, size 1
  -- #5 reg = r0x31  key 28, rIdx = 49, size 1
  -- #6 reg = r0x40  key 28, rIdx = 64, size 1
  -- #7 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #8 reg = r0x23  key 29, rIdx = 35, size 1
  -- #9 reg = r0x32  key 29, rIdx = 50, size 1
  -- #10 reg = r0x41  key 29, rIdx = 65, size 1
  -- #11 reg = r0x50  key 29, rIdx = 80, size 1
  -- #12 reg = r0x24  key 30, rIdx = 36, size 1
  -- #13 reg = r0x33  key 30, rIdx = 51, size 1
  -- #14 reg = r0x42  key 30, rIdx = 66, size 1
  -- #15 reg = r0x51  key 30, rIdx = 81, size 1
  -- #16 reg = r0x60  key 30, rIdx = 96, size 1
  -- #17 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #18 reg = r0x25  key 31, rIdx = 37, size 1
  -- #19 reg = r0x34  key 31, rIdx = 52, size 1
  -- #20 reg = r0x43  key 31, rIdx = 67, size 1
  -- #21 reg = r0x52  key 31, rIdx = 82, size 1
  -- #22 reg = r0x61  key 31, rIdx = 97, size 1
  -- #23 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #24 reg = r0x26  key 32, rIdx = 38, size 1
  -- #25 reg = r0x35  key 32, rIdx = 53, size 1
  -- #26 reg = r0x44  key 32, rIdx = 68, size 1
  -- #27 reg = r0x53  key 32, rIdx = 83, size 1
  -- #28 reg = r0x62  key 32, rIdx = 98, size 1
  -- #29 reg = r0x27  key 33, rIdx = 39, size 1
  -- #30 reg = r0x36  key 33, rIdx = 54, size 1
  -- #31 reg = r0x45  key 33, rIdx = 69, size 1
  -- #32 reg = r0x54  key 33, rIdx = 84, size 1
  -- #33 reg = r0x63  key 33, rIdx = 99, size 1
  -- #34 reg = r0x28  key 34, rIdx = 40, size 1
  -- #35 reg = r0x37  key 34, rIdx = 55, size 1
  -- #36 reg = r0x46  key 34, rIdx = 70, size 1
  -- #37 reg = r0x55  key 34, rIdx = 85, size 1
  -- #38 reg = r0x64  key 34, rIdx = 100, size 1
  -- #39 reg = r0x29  key 35, rIdx = 41, size 1
  -- #40 reg = r0x38  key 35, rIdx = 56, size 1
  -- #41 reg = r0x47  key 35, rIdx = 71, size 1
  -- #42 reg = r0x56  key 35, rIdx = 86, size 1
  -- #43 reg = r0x65  key 35, rIdx = 101, size 1
  -- #44 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #45 reg = r0x39  key 36, rIdx = 57, size 1
  -- #46 reg = r0x48  key 36, rIdx = 72, size 1
  -- #47 reg = r0x57  key 36, rIdx = 87, size 1
  -- #48 reg = r0x66  key 36, rIdx = 102, size 1
  -- #49 reg = r0x49  key 37, rIdx = 73, size 1
  -- #50 reg = r0x58  key 37, rIdx = 88, size 1
  -- #51 reg = r0x67  key 37, rIdx = 103, size 1
  -- #52 reg = r0x59  key 38, rIdx = 89, size 1
  -- #53 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #54 reg = STK00  key 45, rIdx = 127, size 1
  -- #55 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #56 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #57 reg = STK01  key 46, rIdx = 126, size 1
  -- #58 reg = STK10  key 46, rIdx = 117, size 1
  -- #59 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #60 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #61 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #62 reg = STK02  key 47, rIdx = 125, size 1
  -- #63 reg = STK11  key 47, rIdx = 116, size 1
  -- #64 reg = INTCON  key 47, rIdx = 11, size 1
  -- #65 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #66 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #67 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #68 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #69 reg = STK03  key 48, rIdx = 124, size 1
  -- #70 reg = STK12  key 48, rIdx = 115, size 1
  -- #71 reg = PCL  key 48, rIdx = 2, size 1
  -- #72 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #73 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #74 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #75 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #76 reg = STK04  key 49, rIdx = 123, size 1
  -- #77 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #78 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #79 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #80 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #81 reg = STK05  key 50, rIdx = 122, size 1
  -- #82 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #83 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #84 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #85 reg = STK06  key 51, rIdx = 121, size 1
  -- #86 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #87 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #88 reg = STK07  key 52, rIdx = 120, size 1
  -- #89 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #90 reg = STK08  key 53, rIdx = 119, size 1
  -- #91 reg = STK09  key 55, rIdx = 118, size 1
  -- #92 reg = INDF  key 56, rIdx = 0, size 1
  -- #93 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: LABEL
deassignLRs
  op: =
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (5) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x68 (004F6C52).
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x69 (004F6C52).
  2378 - 
  2394 - 
  op: LABEL
deassignLRs
  op: IFX
deassignLRs
  op: -
deassignLRs
  op: GOTO
deassignLRs
freeReg
freeReg
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 2
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l23:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l23:s2:k1:d0:s0)		proc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l27:s4:k15:d0:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] := 0x1f4 {literal-unsigned-int}
libRGB.c(l27:s5:k3:d1:s0)	 _whilecontinue_0($1) :
libRGB.c(l27:s6:k4:d1:s0)		if iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] == 0 goto _return($4)
libRGB.c(l28:s7:k8:d1:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] = iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] - 0x1 {literal-unsigned-char}
libRGB.c(l28:s8:k10:d1:s0)		 goto _whilecontinue_0($1)
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 3 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (15) }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (15) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l27:s3:k14:d0:s0)	 preHeaderLbl0($7) :
libRGB.c(l27:s4:k15:d0:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] := 0x1f4 {literal-unsigned-int}
libRGB.c(l27:s5:k3:d1:s0)	 _whilecontinue_0($1) :
libRGB.c(l27:s6:k4:d1:s0)		if iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] == 0 goto _return($4)
libRGB.c(l28:s7:k8:d1:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] = iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] - 0x1 {literal-unsigned-char}
libRGB.c(l28:s8:k10:d1:s0)		 goto _whilecontinue_0($1)
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_0 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 5 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l27:s5:k3:d1:s0)	 _whilecontinue_0($1) :
libRGB.c(l27:s6:k4:d1:s0)		if iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] == 0 goto _return($4)
libRGB.c(l28:s7:k8:d1:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] = iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] - 0x1 {literal-unsigned-char}
libRGB.c(l28:s8:k10:d1:s0)		 goto _whilecontinue_0($1)
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 1 noPath = 0 , lastinLoop = 1
depth 1st num 4 : bbnum = 3 1st iCode = 7 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (8) }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (8) (9) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l28:s7:k8:d1:s0)		iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] = iTemp2 [k5 lr4:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-int}{ sir@ _pausa_1ms_tmp_1_1}[r0x68 r0x69 ] - 0x1 {literal-unsigned-char}
libRGB.c(l28:s8:k10:d1:s0)		 goto _whilecontinue_0($1)
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block loopExitLbl1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :bitvector Size = 18 bSize = 3
Bits on { (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (2) (8) (9) (15) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) }

----------------------------------------------------------------
libRGB.c(l28:s9:k16:d0:s0)	 loopExitLbl1($8) :
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 10 , last iCode = 11
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 18 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) (17) }

outDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { (8) (15) (17) }

usesDefs Set bitvector :bitvector Size = 18 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l28:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l28:s11:k13:d0:s0)		eproc _pausa_1ms [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x68
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x69
Found a Dynamic Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l37:s1:k0:d0:s0)	 _entry($8) :
libRGB.c(l37:s2:k1:d0:s0)		proc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
libRGB.c(l38:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x8 {literal-unsigned-char}
libRGB.c(l38:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l39:s5:k25:d0:s0)	 preHeaderLbl0($9) :

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (5) (6) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (5) (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (3) (5) (6) }

----------------------------------------------------------------
libRGB.c(l39:s6:k4:d1:s0)	 _whilecontinue_1($1) :
libRGB.c(l39:s7:k5:d1:s0)		iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libRGB.c(l39:s8:k6:d1:s0)		iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libRGB.c(l39:s9:k7:d1:s0)		if iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_1($1)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

----------------------------------------------------------------
libRGB.c(l40:s10:k12:d0:s0)		iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l40:s11:k13:d0:s0)		iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x1 {literal-unsigned-char}
libRGB.c(l40:s12:k14:d0:s0)		if iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_0($5)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 13 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (17) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (17) }

----------------------------------------------------------------
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char} := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}

----------------------------------------------------------------
Basic Block _iffalse_0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 15 , last iCode = 16
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 17 , last iCode = 18
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _SSPCON2 (004F829D).
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
        Symbol type: char function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
packRegisters
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  left:_SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  2991 - not packing - right is not temp
  result:iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
  left:
  right:_SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  right:_SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
         Symbol type: sfr-volatile-unsigned-char
  result:iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
          Symbol type: sfr-char
  3947 - pointer reg req = 0
  left:iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}
sfr         Symbol type: sfr-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
        Symbol type: char function    ( ) 
dir registers allocated so far:
  -- #0 reg = STATUS  key 9, rIdx = 3, size 1
  -- #1 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #2 reg = r0x20  key 26, rIdx = 32, size 1
  -- #3 reg = r0x21  key 27, rIdx = 33, size 1
  -- #4 reg = r0x30  key 27, rIdx = 48, size 1
  -- #5 reg = r0x22  key 28, rIdx = 34, size 1
  -- #6 reg = r0x31  key 28, rIdx = 49, size 1
  -- #7 reg = r0x40  key 28, rIdx = 64, size 1
  -- #8 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #9 reg = r0x23  key 29, rIdx = 35, size 1
  -- #10 reg = r0x32  key 29, rIdx = 50, size 1
  -- #11 reg = r0x41  key 29, rIdx = 65, size 1
  -- #12 reg = r0x50  key 29, rIdx = 80, size 1
  -- #13 reg = r0x24  key 30, rIdx = 36, size 1
  -- #14 reg = r0x33  key 30, rIdx = 51, size 1
  -- #15 reg = r0x42  key 30, rIdx = 66, size 1
  -- #16 reg = r0x51  key 30, rIdx = 81, size 1
  -- #17 reg = r0x60  key 30, rIdx = 96, size 1
  -- #18 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #19 reg = r0x25  key 31, rIdx = 37, size 1
  -- #20 reg = r0x34  key 31, rIdx = 52, size 1
  -- #21 reg = r0x43  key 31, rIdx = 67, size 1
  -- #22 reg = r0x52  key 31, rIdx = 82, size 1
  -- #23 reg = r0x61  key 31, rIdx = 97, size 1
  -- #24 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #25 reg = r0x26  key 32, rIdx = 38, size 1
  -- #26 reg = r0x35  key 32, rIdx = 53, size 1
  -- #27 reg = r0x44  key 32, rIdx = 68, size 1
  -- #28 reg = r0x53  key 32, rIdx = 83, size 1
  -- #29 reg = r0x62  key 32, rIdx = 98, size 1
  -- #30 reg = r0x27  key 33, rIdx = 39, size 1
  -- #31 reg = r0x36  key 33, rIdx = 54, size 1
  -- #32 reg = r0x45  key 33, rIdx = 69, size 1
  -- #33 reg = r0x54  key 33, rIdx = 84, size 1
  -- #34 reg = r0x63  key 33, rIdx = 99, size 1
  -- #35 reg = r0x28  key 34, rIdx = 40, size 1
  -- #36 reg = r0x37  key 34, rIdx = 55, size 1
  -- #37 reg = r0x46  key 34, rIdx = 70, size 1
  -- #38 reg = r0x55  key 34, rIdx = 85, size 1
  -- #39 reg = r0x64  key 34, rIdx = 100, size 1
  -- #40 reg = r0x29  key 35, rIdx = 41, size 1
  -- #41 reg = r0x38  key 35, rIdx = 56, size 1
  -- #42 reg = r0x47  key 35, rIdx = 71, size 1
  -- #43 reg = r0x56  key 35, rIdx = 86, size 1
  -- #44 reg = r0x65  key 35, rIdx = 101, size 1
  -- #45 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #46 reg = r0x39  key 36, rIdx = 57, size 1
  -- #47 reg = r0x48  key 36, rIdx = 72, size 1
  -- #48 reg = r0x57  key 36, rIdx = 87, size 1
  -- #49 reg = r0x66  key 36, rIdx = 102, size 1
  -- #50 reg = r0x49  key 37, rIdx = 73, size 1
  -- #51 reg = r0x58  key 37, rIdx = 88, size 1
  -- #52 reg = r0x67  key 37, rIdx = 103, size 1
  -- #53 reg = r0x59  key 38, rIdx = 89, size 1
  -- #54 reg = r0x68  key 38, rIdx = 104, size 1
  -- #55 reg = r0x69  key 39, rIdx = 105, size 1
  -- #56 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #57 reg = STK00  key 45, rIdx = 127, size 1
  -- #58 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #59 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #60 reg = STK01  key 46, rIdx = 126, size 1
  -- #61 reg = STK10  key 46, rIdx = 117, size 1
  -- #62 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #63 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #64 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #65 reg = STK02  key 47, rIdx = 125, size 1
  -- #66 reg = STK11  key 47, rIdx = 116, size 1
  -- #67 reg = INTCON  key 47, rIdx = 11, size 1
  -- #68 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #69 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #70 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #71 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #72 reg = STK03  key 48, rIdx = 124, size 1
  -- #73 reg = STK12  key 48, rIdx = 115, size 1
  -- #74 reg = PCL  key 48, rIdx = 2, size 1
  -- #75 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #76 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #77 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #78 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #79 reg = STK04  key 49, rIdx = 123, size 1
  -- #80 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #81 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #82 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #83 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #84 reg = STK05  key 50, rIdx = 122, size 1
  -- #85 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #86 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #87 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #88 reg = STK06  key 51, rIdx = 121, size 1
  -- #89 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #90 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #91 reg = STK07  key 52, rIdx = 120, size 1
  -- #92 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #93 reg = STK08  key 53, rIdx = 119, size 1
  -- #94 reg = STK09  key 55, rIdx = 118, size 1
  -- #95 reg = INDF  key 56, rIdx = 0, size 1
  -- #96 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
  2697 - iTemp4
  2707 - itemp register
  2697 - iTemp5
  2707 - itemp register
  reg name iTemp5,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6A (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (7) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: =
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (10) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: RETURN
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l37:s1:k0:d0:s0)	 _entry($8) :
libRGB.c(l37:s2:k1:d0:s0)		proc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
libRGB.c(l38:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x8 {literal-unsigned-char}
libRGB.c(l39:s6:k4:d1:s0)	 _whilecontinue_1($1) :
libRGB.c(l39:s7:k5:d1:s0)		iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libRGB.c(l39:s8:k6:d1:s0)		iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x0 {literal-unsigned-char}
libRGB.c(l39:s9:k7:d1:s0)		if iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_1($1)
libRGB.c(l40:s10:k12:d0:s0)		iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l40:s11:k13:d0:s0)		iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x1 {literal-unsigned-char}
libRGB.c(l40:s12:k14:d0:s0)		if iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_0($5)
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ] := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ]
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l39:s5:k25:d0:s0)	 preHeaderLbl0($9) :
libRGB.c(l39:s6:k4:d1:s0)	 _whilecontinue_1($1) :
libRGB.c(l39:s7:k5:d1:s0)		iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libRGB.c(l39:s8:k6:d1:s0)		iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x0 {literal-unsigned-char}
libRGB.c(l39:s9:k7:d1:s0)		if iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_1($1)
libRGB.c(l40:s10:k12:d0:s0)		iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l40:s11:k13:d0:s0)		iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x1 {literal-unsigned-char}
libRGB.c(l40:s12:k14:d0:s0)		if iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_0($5)
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ] := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ]
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_1 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (5) (6) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (5) (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (3) (5) (6) }

----------------------------------------------------------------
libRGB.c(l39:s6:k4:d1:s0)	 _whilecontinue_1($1) :
libRGB.c(l39:s7:k5:d1:s0)		iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x8 {literal-unsigned-char}
libRGB.c(l39:s8:k6:d1:s0)		iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp1 [k4 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x0 {literal-unsigned-char}
libRGB.c(l39:s9:k7:d1:s0)		if iTemp2 [k5 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_1($1)
libRGB.c(l40:s10:k12:d0:s0)		iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l40:s11:k13:d0:s0)		iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x1 {literal-unsigned-char}
libRGB.c(l40:s12:k14:d0:s0)		if iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_0($5)
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ] := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ]
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 12
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (12) (13) }

----------------------------------------------------------------
libRGB.c(l40:s10:k12:d0:s0)		iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] = _SSPSTAT [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l40:s11:k13:d0:s0)		iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp3 [k7 lr10:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6A ] == 0x1 {literal-unsigned-char}
libRGB.c(l40:s12:k14:d0:s0)		if iTemp4 [k8 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_0($5)
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ] := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ]
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 13 , last iCode = 14
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (17) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (17) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (17) }

----------------------------------------------------------------
libRGB.c(l41:s13:k17:d0:s0)		iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ] := _SSPBUF [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
libRGB.c(l41:s14:k18:d0:s0)		ret iTemp5 [k10 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-char}[r0x6A ]
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 15 , last iCode = 16
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l41:s15:k20:d0:s0)	 _iffalse_0($5) :
libRGB.c(l44:s16:k21:d0:s0)		ret 0x0 {literal-char}
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 17 , last iCode = 18
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (5) (6) (12) (13) (17) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l44:s17:k23:d0:s0)	 _return($7) :
libRGB.c(l44:s18:k24:d0:s0)		eproc _i2c_ReadByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char function    ( ) }
Found a Direct Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
Found a Processor Register!
newReg: Created register _SSPSTAT (004F7FE5).
  -- added _SSPSTAT to hash, size = 1
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
Found a Processor Register!
newReg: Created register _SSPBUF (004F7FE5).
  -- added _SSPBUF to hash, size = 1
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l51:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l51:s2:k1:d0:s0)		proc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libRGB.c(l52:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x40 {literal-unsigned-char}
libRGB.c(l52:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_1($2)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l53:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _iffalse_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l53:s6:k8:d0:s0)	 _iffalse_1($2) :
libRGB.c(l55:s7:k9:d0:s0)		ret 0x1 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l55:s8:k11:d0:s0)	 _return($4) :
libRGB.c(l55:s9:k12:d0:s0)		eproc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
packRegisters
  left:_i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  3964
  left:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
        Symbol type: unsigned-char function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = STK05  key 50, rIdx = 122, size 1
  -- #88 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #89 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #90 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #91 reg = STK06  key 51, rIdx = 121, size 1
  -- #92 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #93 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #94 reg = STK07  key 52, rIdx = 120, size 1
  -- #95 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #96 reg = STK08  key 53, rIdx = 119, size 1
  -- #97 reg = STK09  key 55, rIdx = 118, size 1
  -- #98 reg = INDF  key 56, rIdx = 0, size 1
  -- #99 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
  op: IFX
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

local defines bitVector :bitvector Size = 13 bSize = 2
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l51:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l51:s2:k1:d0:s0)		proc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
libRGB.c(l52:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x40 {literal-unsigned-char}
libRGB.c(l52:s4:k3:d0:s0)		if iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _iffalse_1($2)
libRGB.c(l53:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l53:s6:k8:d0:s0)	 _iffalse_1($2) :
libRGB.c(l55:s7:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libRGB.c(l55:s8:k11:d0:s0)	 _return($4) :
libRGB.c(l55:s9:k12:d0:s0)		eproc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l53:s5:k6:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l53:s6:k8:d0:s0)	 _iffalse_1($2) :
libRGB.c(l55:s7:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libRGB.c(l55:s8:k11:d0:s0)	 _return($4) :
libRGB.c(l55:s9:k12:d0:s0)		eproc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _iffalse_1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 7
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l53:s6:k8:d0:s0)	 _iffalse_1($2) :
libRGB.c(l55:s7:k9:d0:s0)		ret 0x1 {literal-unsigned-char}
libRGB.c(l55:s8:k11:d0:s0)	 _return($4) :
libRGB.c(l55:s9:k12:d0:s0)		eproc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 13 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 13 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l55:s8:k11:d0:s0)	 _return($4) :
libRGB.c(l55:s9:k12:d0:s0)		eproc _i2c_CheckACK [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( ) }
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) }

----------------------------------------------------------------
libRGB.c(l59:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l59:s2:k1:d0:s0)		proc _i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l60:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xdf {literal-unsigned-char}
libRGB.c(l60:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l61:s5:k4:d0:s0)		iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x10 {literal-unsigned-char}
libRGB.c(l61:s6:k5:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l61:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l61:s8:k7:d0:s0)		eproc _i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
  left:_i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = STK05  key 50, rIdx = 122, size 1
  -- #88 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #89 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #90 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #91 reg = STK06  key 51, rIdx = 121, size 1
  -- #92 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #93 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #94 reg = STK07  key 52, rIdx = 120, size 1
  -- #95 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #96 reg = STK08  key 53, rIdx = 119, size 1
  -- #97 reg = STK09  key 55, rIdx = 118, size 1
  -- #98 reg = INDF  key 56, rIdx = 0, size 1
  -- #99 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: BITWISEAND
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) }

----------------------------------------------------------------
libRGB.c(l59:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l59:s2:k1:d0:s0)		proc _i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l60:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xdf {literal-unsigned-char}
libRGB.c(l61:s5:k4:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x10 {literal-unsigned-char}
libRGB.c(l61:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l61:s8:k7:d0:s0)		eproc _i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l61:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l61:s8:k7:d0:s0)		eproc _i2c_SendAck [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) }

----------------------------------------------------------------
libRGB.c(l65:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l65:s2:k1:d0:s0)		proc _i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l66:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x20 {literal-unsigned-char}
libRGB.c(l66:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l67:s5:k4:d0:s0)		iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x10 {literal-unsigned-char}
libRGB.c(l67:s6:k5:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l67:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l67:s8:k7:d0:s0)		eproc _i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k4 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
  left:_i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = STK05  key 50, rIdx = 122, size 1
  -- #88 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #89 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #90 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #91 reg = STK06  key 51, rIdx = 121, size 1
  -- #92 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #93 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #94 reg = STK07  key 52, rIdx = 120, size 1
  -- #95 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #96 reg = STK08  key 53, rIdx = 119, size 1
  -- #97 reg = STK09  key 55, rIdx = 118, size 1
  -- #98 reg = INDF  key 56, rIdx = 0, size 1
  -- #99 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 6
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

local defines bitVector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (3) (4) }

----------------------------------------------------------------
libRGB.c(l65:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l65:s2:k1:d0:s0)		proc _i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l66:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x20 {literal-unsigned-char}
libRGB.c(l67:s5:k4:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x10 {literal-unsigned-char}
libRGB.c(l67:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l67:s8:k7:d0:s0)		eproc _i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 7 , last iCode = 8
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 8 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

outDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { (2) (4) (5) }

usesDefs Set bitvector :bitvector Size = 8 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l67:s7:k6:d0:s0)	 _return($1) :
libRGB.c(l67:s8:k7:d0:s0)		eproc _i2c_SendNack [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

local defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (5) (6) }

----------------------------------------------------------------
libRGB.c(l72:s1:k0:d0:s0)	 _entry($8) :
libRGB.c(l72:s2:k1:d0:s0)		proc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l72:s3:k2:d0:s0)	iTemp0 [k2 lr3:4 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{char}{ sir@ _i2c_SendByte_dato_1_1} = recv _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l73:s4:k4:d0:s0)		_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k2 lr3:4 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{char}{ sir@ _i2c_SendByte_dato_1_1}
libRGB.c(l75:s5:k5:d0:s0)		iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x80 {literal-unsigned-char}
libRGB.c(l75:s6:k6:d0:s0)		iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x80 {literal-unsigned-char}
libRGB.c(l75:s7:k7:d0:s0)		if iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto preHeaderLbl0($10)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 8 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l76:s8:k10:d0:s0)		ret 0xff {literal-unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l78:s9:k24:d0:s0)	 preHeaderLbl0($10) :

----------------------------------------------------------------
Basic Block _whilecontinue_2 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (14) }

local defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (14) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (14) }

----------------------------------------------------------------
libRGB.c(l78:s10:k13:d1:s0)	 _whilecontinue_2($1) :
libRGB.c(l78:s11:k14:d1:s0)		iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l78:s12:k15:d1:s0)		if iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _whilecontinue_2($1)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 13 , last iCode = 13
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 14 , last iCode = 15
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
packRegisters
packRegsForAssign
  result:_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k2 lr3:4 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{char}{ sir@ _i2c_SendByte_dato_1_1}
allocDirReg symbol name _SSPBUF
  703  storage class 3 
 708  integral
 712  specifier
_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPBUF to hash, size = 1
  -- and it is at a fixed address 0x13
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k2 lr3:4 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{char}{ sir@ _i2c_SendByte_dato_1_1}
  left:_i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
  left:_i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
  result:_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:_i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
  right:
  hey we can remove this unnecessary assign
  left:_SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
packRegisters
  left:_SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  3964
  left:iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = r0x28  key 34, rIdx = 40, size 1
  -- #38 reg = r0x37  key 34, rIdx = 55, size 1
  -- #39 reg = r0x46  key 34, rIdx = 70, size 1
  -- #40 reg = r0x55  key 34, rIdx = 85, size 1
  -- #41 reg = r0x64  key 34, rIdx = 100, size 1
  -- #42 reg = r0x29  key 35, rIdx = 41, size 1
  -- #43 reg = r0x38  key 35, rIdx = 56, size 1
  -- #44 reg = r0x47  key 35, rIdx = 71, size 1
  -- #45 reg = r0x56  key 35, rIdx = 86, size 1
  -- #46 reg = r0x65  key 35, rIdx = 101, size 1
  -- #47 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #48 reg = r0x39  key 36, rIdx = 57, size 1
  -- #49 reg = r0x48  key 36, rIdx = 72, size 1
  -- #50 reg = r0x57  key 36, rIdx = 87, size 1
  -- #51 reg = r0x66  key 36, rIdx = 102, size 1
  -- #52 reg = r0x49  key 37, rIdx = 73, size 1
  -- #53 reg = r0x58  key 37, rIdx = 88, size 1
  -- #54 reg = r0x67  key 37, rIdx = 103, size 1
  -- #55 reg = r0x59  key 38, rIdx = 89, size 1
  -- #56 reg = r0x68  key 38, rIdx = 104, size 1
  -- #57 reg = r0x69  key 39, rIdx = 105, size 1
  -- #58 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #59 reg = STK00  key 45, rIdx = 127, size 1
  -- #60 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #61 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #62 reg = STK01  key 46, rIdx = 126, size 1
  -- #63 reg = STK10  key 46, rIdx = 117, size 1
  -- #64 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #65 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #66 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #67 reg = STK02  key 47, rIdx = 125, size 1
  -- #68 reg = STK11  key 47, rIdx = 116, size 1
  -- #69 reg = INTCON  key 47, rIdx = 11, size 1
  -- #70 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #71 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #72 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #73 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #74 reg = STK03  key 48, rIdx = 124, size 1
  -- #75 reg = STK12  key 48, rIdx = 115, size 1
  -- #76 reg = PCL  key 48, rIdx = 2, size 1
  -- #77 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #78 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #79 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #80 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #81 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #82 reg = STK04  key 49, rIdx = 123, size 1
  -- #83 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #84 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #85 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #86 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #87 reg = STK05  key 50, rIdx = 122, size 1
  -- #88 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #89 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #90 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #91 reg = STK06  key 51, rIdx = 121, size 1
  -- #92 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #93 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #94 reg = STK07  key 52, rIdx = 120, size 1
  -- #95 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #96 reg = STK08  key 53, rIdx = 119, size 1
  -- #97 reg = STK09  key 55, rIdx = 118, size 1
  -- #98 reg = INDF  key 56, rIdx = 0, size 1
  -- #99 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  2697 - iTemp4
  2707 - itemp register
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (7) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6B (004F6C52).
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: BITWISEAND
deassignLRs
  op: IFX
deassignLRs
  op: RETURN
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

local defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (5) (6) }

----------------------------------------------------------------
libRGB.c(l72:s1:k0:d0:s0)	 _entry($8) :
libRGB.c(l72:s2:k1:d0:s0)		proc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l72:s3:k2:d0:s0)	_SSPBUF [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = recv _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l75:s5:k5:d0:s0)		iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6B ] = _SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x80 {literal-unsigned-char}
libRGB.c(l75:s6:k6:d0:s0)		iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6B ] == 0x80 {literal-unsigned-char}
libRGB.c(l75:s7:k7:d0:s0)		if iTemp3 [k8 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_2($1)
libRGB.c(l76:s8:k10:d0:s0)		ret 0xff {literal-unsigned-char}
libRGB.c(l78:s10:k13:d1:s0)	 _whilecontinue_2($1) :
libRGB.c(l78:s11:k14:d1:s0)		iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l78:s12:k15:d1:s0)		if iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _whilecontinue_2($1)
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 8 , last iCode = 8
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l76:s8:k10:d0:s0)		ret 0xff {literal-unsigned-char}
libRGB.c(l78:s10:k13:d1:s0)	 _whilecontinue_2($1) :
libRGB.c(l78:s11:k14:d1:s0)		iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l78:s12:k15:d1:s0)		if iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _whilecontinue_2($1)
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 9 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (4) (5) (6) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l78:s9:k24:d0:s0)	 preHeaderLbl0($10) :
libRGB.c(l78:s10:k13:d1:s0)	 _whilecontinue_2($1) :
libRGB.c(l78:s11:k14:d1:s0)		iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l78:s12:k15:d1:s0)		if iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _whilecontinue_2($1)
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }

----------------------------------------------------------------
Basic Block _whilecontinue_2 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 10 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (14) }

local defines bitVector :bitvector Size = 25 bSize = 4
Bits on { (14) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (14) }

----------------------------------------------------------------
libRGB.c(l78:s10:k13:d1:s0)	 _whilecontinue_2($1) :
libRGB.c(l78:s11:k14:d1:s0)		iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k9 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1 {literal-unsigned-char}
libRGB.c(l78:s12:k15:d1:s0)		if iTemp4 [k10 lr11:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} != 0 goto _whilecontinue_2($1)
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 13 , last iCode = 13
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l79:s13:k20:d0:s0)		ret 0x0 {literal-unsigned-char}
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 14 , last iCode = 15
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 25 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

outDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { (2) (3) (4) (5) (6) (14) }

usesDefs Set bitvector :bitvector Size = 25 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l79:s14:k22:d0:s0)	 _return($7) :
libRGB.c(l79:s15:k23:d0:s0)		eproc _i2c_SendByte [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
newReg: Created register _SSPCON (004F7FE5).
  -- added _SSPCON to hash, size = 1
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
Found a Processor Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l84:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l84:s2:k1:d0:s0)		proc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l85:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x4 {literal-unsigned-char}
libRGB.c(l85:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l86:s5:k15:d0:s0)	 preHeaderLbl0($6) :

----------------------------------------------------------------
Basic Block _whilecontinue_3 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l86:s6:k4:d1:s0)	 _whilecontinue_3($1) :
libRGB.c(l86:s7:k5:d1:s0)		iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l86:s8:k6:d1:s0)		iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* } := iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
libRGB.c(l86:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}} = @[iTemp2 [k7 lr8:9 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }]
libRGB.c(l86:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}} != 0 goto _whilecontinue_3($1)

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l86:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l86:s12:k14:d0:s0)		eproc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
packRegisters
packRegsForAssign
  result:iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  left:_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
    is volatile
        Symbol type: volatile-struct __00010107
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
          Symbol type: volatile-unsigned-bitfield {2,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
        Symbol type: volatile-unsigned-bitfield {2,1} near* 
  result:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}
          Symbol type: volatile-unsigned-bitfield {2,1}
  marking as a pointer (get) =>  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}
        Symbol type: volatile-unsigned-bitfield {2,1}
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #38 reg = r0x28  key 34, rIdx = 40, size 1
  -- #39 reg = r0x37  key 34, rIdx = 55, size 1
  -- #40 reg = r0x46  key 34, rIdx = 70, size 1
  -- #41 reg = r0x55  key 34, rIdx = 85, size 1
  -- #42 reg = r0x64  key 34, rIdx = 100, size 1
  -- #43 reg = r0x29  key 35, rIdx = 41, size 1
  -- #44 reg = r0x38  key 35, rIdx = 56, size 1
  -- #45 reg = r0x47  key 35, rIdx = 71, size 1
  -- #46 reg = r0x56  key 35, rIdx = 86, size 1
  -- #47 reg = r0x65  key 35, rIdx = 101, size 1
  -- #48 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #49 reg = r0x39  key 36, rIdx = 57, size 1
  -- #50 reg = r0x48  key 36, rIdx = 72, size 1
  -- #51 reg = r0x57  key 36, rIdx = 87, size 1
  -- #52 reg = r0x66  key 36, rIdx = 102, size 1
  -- #53 reg = r0x49  key 37, rIdx = 73, size 1
  -- #54 reg = r0x58  key 37, rIdx = 88, size 1
  -- #55 reg = r0x67  key 37, rIdx = 103, size 1
  -- #56 reg = r0x59  key 38, rIdx = 89, size 1
  -- #57 reg = r0x68  key 38, rIdx = 104, size 1
  -- #58 reg = r0x69  key 39, rIdx = 105, size 1
  -- #59 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #60 reg = STK00  key 45, rIdx = 127, size 1
  -- #61 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #62 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #63 reg = STK01  key 46, rIdx = 126, size 1
  -- #64 reg = STK10  key 46, rIdx = 117, size 1
  -- #65 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #66 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #67 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #68 reg = STK02  key 47, rIdx = 125, size 1
  -- #69 reg = STK11  key 47, rIdx = 116, size 1
  -- #70 reg = INTCON  key 47, rIdx = 11, size 1
  -- #71 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #72 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #73 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #74 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #75 reg = STK03  key 48, rIdx = 124, size 1
  -- #76 reg = STK12  key 48, rIdx = 115, size 1
  -- #77 reg = PCL  key 48, rIdx = 2, size 1
  -- #78 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #79 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #80 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #81 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #82 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #83 reg = STK04  key 49, rIdx = 123, size 1
  -- #84 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #85 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #86 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #87 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #88 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #89 reg = STK05  key 50, rIdx = 122, size 1
  -- #90 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #91 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #92 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #93 reg = STK06  key 51, rIdx = 121, size 1
  -- #94 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #95 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #96 reg = STK07  key 52, rIdx = 120, size 1
  -- #97 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #98 reg = STK08  key 53, rIdx = 119, size 1
  -- #99 reg = STK09  key 55, rIdx = 118, size 1
  -- #100 reg = INDF  key 56, rIdx = 0, size 1
  -- #101 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp2
isSpiltOnStack
  op: GET_VALUE_AT_ADDRESS
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (8) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6C (004F6C52).
  2378 - 
positionRegs
  2394 - 
  2397 - 
  op: IFX
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l84:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l84:s2:k1:d0:s0)		proc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l85:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x4 {literal-unsigned-char}
libRGB.c(l86:s6:k4:d1:s0)	 _whilecontinue_3($1) :
libRGB.c(l86:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l86:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
libRGB.c(l86:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] != 0 goto _whilecontinue_3($1)
libRGB.c(l86:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l86:s12:k14:d0:s0)		eproc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l86:s5:k15:d0:s0)	 preHeaderLbl0($6) :
libRGB.c(l86:s6:k4:d1:s0)	 _whilecontinue_3($1) :
libRGB.c(l86:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l86:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
libRGB.c(l86:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] != 0 goto _whilecontinue_3($1)
libRGB.c(l86:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l86:s12:k14:d0:s0)		eproc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_3 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l86:s6:k4:d1:s0)	 _whilecontinue_3($1) :
libRGB.c(l86:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l86:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1} near* }[remat]]
libRGB.c(l86:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {2,1}}[r0x6C ] != 0 goto _whilecontinue_3($1)
libRGB.c(l86:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l86:s12:k14:d0:s0)		eproc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l86:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l86:s12:k14:d0:s0)		eproc _i2c_SendStop [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
allocDirReg symbol name _SSPCON2_bits
  703  storage class 0 
 712  specifier
_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
  -- added _SSPCON2_bits to hash, size = 1
  -- and it is at a fixed address 0x91
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l90:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l90:s2:k1:d0:s0)		proc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l91:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x1 {literal-unsigned-char}
libRGB.c(l91:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l92:s5:k15:d0:s0)	 preHeaderLbl0($6) :

----------------------------------------------------------------
Basic Block _whilecontinue_4 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l92:s6:k4:d1:s0)	 _whilecontinue_4($1) :
libRGB.c(l92:s7:k5:d1:s0)		iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* } = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l92:s8:k6:d1:s0)		iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* } := iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
libRGB.c(l92:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}} = @[iTemp2 [k7 lr8:9 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }]
libRGB.c(l92:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}} != 0 goto _whilecontinue_4($1)

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l92:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l92:s12:k14:d0:s0)		eproc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
packRegisters
packRegsForAssign
  result:iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
  left:_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
    is volatile
        Symbol type: volatile-struct __00010107
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
          Symbol type: volatile-unsigned-bitfield {0,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
        Symbol type: volatile-unsigned-bitfield {0,1} near* 
  result:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}
          Symbol type: volatile-unsigned-bitfield {0,1}
  marking as a pointer (get) =>  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}
        Symbol type: volatile-unsigned-bitfield {0,1}
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = r0x20  key 26, rIdx = 32, size 1
  -- #4 reg = r0x21  key 27, rIdx = 33, size 1
  -- #5 reg = r0x30  key 27, rIdx = 48, size 1
  -- #6 reg = r0x22  key 28, rIdx = 34, size 1
  -- #7 reg = r0x31  key 28, rIdx = 49, size 1
  -- #8 reg = r0x40  key 28, rIdx = 64, size 1
  -- #9 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #10 reg = r0x23  key 29, rIdx = 35, size 1
  -- #11 reg = r0x32  key 29, rIdx = 50, size 1
  -- #12 reg = r0x41  key 29, rIdx = 65, size 1
  -- #13 reg = r0x50  key 29, rIdx = 80, size 1
  -- #14 reg = r0x24  key 30, rIdx = 36, size 1
  -- #15 reg = r0x33  key 30, rIdx = 51, size 1
  -- #16 reg = r0x42  key 30, rIdx = 66, size 1
  -- #17 reg = r0x51  key 30, rIdx = 81, size 1
  -- #18 reg = r0x60  key 30, rIdx = 96, size 1
  -- #19 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #20 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #21 reg = r0x25  key 31, rIdx = 37, size 1
  -- #22 reg = r0x34  key 31, rIdx = 52, size 1
  -- #23 reg = r0x43  key 31, rIdx = 67, size 1
  -- #24 reg = r0x52  key 31, rIdx = 82, size 1
  -- #25 reg = r0x61  key 31, rIdx = 97, size 1
  -- #26 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #27 reg = r0x26  key 32, rIdx = 38, size 1
  -- #28 reg = r0x35  key 32, rIdx = 53, size 1
  -- #29 reg = r0x44  key 32, rIdx = 68, size 1
  -- #30 reg = r0x53  key 32, rIdx = 83, size 1
  -- #31 reg = r0x62  key 32, rIdx = 98, size 1
  -- #32 reg = r0x27  key 33, rIdx = 39, size 1
  -- #33 reg = r0x36  key 33, rIdx = 54, size 1
  -- #34 reg = r0x45  key 33, rIdx = 69, size 1
  -- #35 reg = r0x54  key 33, rIdx = 84, size 1
  -- #36 reg = r0x63  key 33, rIdx = 99, size 1
  -- #37 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #38 reg = r0x28  key 34, rIdx = 40, size 1
  -- #39 reg = r0x37  key 34, rIdx = 55, size 1
  -- #40 reg = r0x46  key 34, rIdx = 70, size 1
  -- #41 reg = r0x55  key 34, rIdx = 85, size 1
  -- #42 reg = r0x64  key 34, rIdx = 100, size 1
  -- #43 reg = r0x29  key 35, rIdx = 41, size 1
  -- #44 reg = r0x38  key 35, rIdx = 56, size 1
  -- #45 reg = r0x47  key 35, rIdx = 71, size 1
  -- #46 reg = r0x56  key 35, rIdx = 86, size 1
  -- #47 reg = r0x65  key 35, rIdx = 101, size 1
  -- #48 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #49 reg = r0x39  key 36, rIdx = 57, size 1
  -- #50 reg = r0x48  key 36, rIdx = 72, size 1
  -- #51 reg = r0x57  key 36, rIdx = 87, size 1
  -- #52 reg = r0x66  key 36, rIdx = 102, size 1
  -- #53 reg = r0x49  key 37, rIdx = 73, size 1
  -- #54 reg = r0x58  key 37, rIdx = 88, size 1
  -- #55 reg = r0x67  key 37, rIdx = 103, size 1
  -- #56 reg = r0x59  key 38, rIdx = 89, size 1
  -- #57 reg = r0x68  key 38, rIdx = 104, size 1
  -- #58 reg = r0x69  key 39, rIdx = 105, size 1
  -- #59 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #60 reg = STK00  key 45, rIdx = 127, size 1
  -- #61 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #62 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #63 reg = STK01  key 46, rIdx = 126, size 1
  -- #64 reg = STK10  key 46, rIdx = 117, size 1
  -- #65 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #66 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #67 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #68 reg = STK02  key 47, rIdx = 125, size 1
  -- #69 reg = STK11  key 47, rIdx = 116, size 1
  -- #70 reg = INTCON  key 47, rIdx = 11, size 1
  -- #71 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #72 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #73 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #74 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #75 reg = STK03  key 48, rIdx = 124, size 1
  -- #76 reg = STK12  key 48, rIdx = 115, size 1
  -- #77 reg = PCL  key 48, rIdx = 2, size 1
  -- #78 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #79 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #80 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #81 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #82 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #83 reg = STK04  key 49, rIdx = 123, size 1
  -- #84 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #85 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #86 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #87 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #88 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #89 reg = STK05  key 50, rIdx = 122, size 1
  -- #90 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #91 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #92 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #93 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #94 reg = STK06  key 51, rIdx = 121, size 1
  -- #95 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #96 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #97 reg = STK07  key 52, rIdx = 120, size 1
  -- #98 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #99 reg = STK08  key 53, rIdx = 119, size 1
  -- #100 reg = STK09  key 55, rIdx = 118, size 1
  -- #101 reg = INDF  key 56, rIdx = 0, size 1
  -- #102 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp2
isSpiltOnStack
  op: GET_VALUE_AT_ADDRESS
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (8) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
positionRegs
  2394 - 
  2397 - 
  op: IFX
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l90:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l90:s2:k1:d0:s0)		proc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l91:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x1 {literal-unsigned-char}
libRGB.c(l92:s6:k4:d1:s0)	 _whilecontinue_4($1) :
libRGB.c(l92:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l92:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat]]
libRGB.c(l92:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] != 0 goto _whilecontinue_4($1)
libRGB.c(l92:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l92:s12:k14:d0:s0)		eproc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l92:s5:k15:d0:s0)	 preHeaderLbl0($6) :
libRGB.c(l92:s6:k4:d1:s0)	 _whilecontinue_4($1) :
libRGB.c(l92:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l92:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat]]
libRGB.c(l92:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] != 0 goto _whilecontinue_4($1)
libRGB.c(l92:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l92:s12:k14:d0:s0)		eproc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_4 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l92:s6:k4:d1:s0)	 _whilecontinue_4($1) :
libRGB.c(l92:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l92:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1} near* }[remat]]
libRGB.c(l92:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {0,1}}[r0x6C ] != 0 goto _whilecontinue_4($1)
libRGB.c(l92:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l92:s12:k14:d0:s0)		eproc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l92:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l92:s12:k14:d0:s0)		eproc _i2c_SendStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
allocDirReg symbol name _SSPCON2_bits
  703  storage class 0 
 712  specifier
_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
  -- added _SSPCON2_bits to hash, size = 1
  -- and it is at a fixed address 0x91
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 2
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l95:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l95:s2:k1:d0:s0)		proc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 3 , last iCode = 3
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l96:s3:k14:d0:s0)	 preHeaderLbl0($6) :

----------------------------------------------------------------
Basic Block _whilecontinue_5 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 4 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

----------------------------------------------------------------
libRGB.c(l96:s4:k2:d1:s0)	 _whilecontinue_5($1) :
libRGB.c(l96:s5:k3:d1:s0)		iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1f {literal-unsigned-char}
libRGB.c(l96:s6:k4:d1:s0)		iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} == 0x0 {literal-unsigned-char}
libRGB.c(l96:s7:k5:d1:s0)		if iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_5($1)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (10) (11) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (10) (11) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (10) }

----------------------------------------------------------------
libRGB.c(l97:s8:k10:d0:s0)		iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xf7 {literal-unsigned-char}
libRGB.c(l97:s9:k11:d0:s0)		_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
  left:_i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
packRegisters
packRegisters
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegsForAccUse
  left:iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
        Symbol type: unsigned-char
  result:iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
packRegsForAssign
  result:_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _PIR1
  703  storage class 3 
 708  integral
 712  specifier
_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _PIR1 (004F829D).
  -- added _PIR1 to hash, size = 1
  -- and it is at a fixed address 0x0c
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp2
  replacing with iTemp2
  result:_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp2 [k6 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
  left:_i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x27  key 33, rIdx = 39, size 1
  -- #34 reg = r0x36  key 33, rIdx = 54, size 1
  -- #35 reg = r0x45  key 33, rIdx = 69, size 1
  -- #36 reg = r0x54  key 33, rIdx = 84, size 1
  -- #37 reg = r0x63  key 33, rIdx = 99, size 1
  -- #38 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #39 reg = r0x28  key 34, rIdx = 40, size 1
  -- #40 reg = r0x37  key 34, rIdx = 55, size 1
  -- #41 reg = r0x46  key 34, rIdx = 70, size 1
  -- #42 reg = r0x55  key 34, rIdx = 85, size 1
  -- #43 reg = r0x64  key 34, rIdx = 100, size 1
  -- #44 reg = r0x29  key 35, rIdx = 41, size 1
  -- #45 reg = r0x38  key 35, rIdx = 56, size 1
  -- #46 reg = r0x47  key 35, rIdx = 71, size 1
  -- #47 reg = r0x56  key 35, rIdx = 86, size 1
  -- #48 reg = r0x65  key 35, rIdx = 101, size 1
  -- #49 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #50 reg = r0x39  key 36, rIdx = 57, size 1
  -- #51 reg = r0x48  key 36, rIdx = 72, size 1
  -- #52 reg = r0x57  key 36, rIdx = 87, size 1
  -- #53 reg = r0x66  key 36, rIdx = 102, size 1
  -- #54 reg = r0x49  key 37, rIdx = 73, size 1
  -- #55 reg = r0x58  key 37, rIdx = 88, size 1
  -- #56 reg = r0x67  key 37, rIdx = 103, size 1
  -- #57 reg = r0x59  key 38, rIdx = 89, size 1
  -- #58 reg = r0x68  key 38, rIdx = 104, size 1
  -- #59 reg = r0x69  key 39, rIdx = 105, size 1
  -- #60 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #61 reg = STK00  key 45, rIdx = 127, size 1
  -- #62 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #63 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #64 reg = STK01  key 46, rIdx = 126, size 1
  -- #65 reg = STK10  key 46, rIdx = 117, size 1
  -- #66 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #67 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #68 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #69 reg = STK02  key 47, rIdx = 125, size 1
  -- #70 reg = STK11  key 47, rIdx = 116, size 1
  -- #71 reg = INTCON  key 47, rIdx = 11, size 1
  -- #72 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #73 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #74 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #75 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #76 reg = STK03  key 48, rIdx = 124, size 1
  -- #77 reg = STK12  key 48, rIdx = 115, size 1
  -- #78 reg = PCL  key 48, rIdx = 2, size 1
  -- #79 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #80 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #81 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #82 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #83 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #84 reg = STK04  key 49, rIdx = 123, size 1
  -- #85 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #86 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #87 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #88 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #89 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #90 reg = STK05  key 50, rIdx = 122, size 1
  -- #91 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #92 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #93 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #94 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #95 reg = STK06  key 51, rIdx = 121, size 1
  -- #96 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #97 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #98 reg = STK07  key 52, rIdx = 120, size 1
  -- #99 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #100 reg = STK08  key 53, rIdx = 119, size 1
  -- #101 reg = STK09  key 55, rIdx = 118, size 1
  -- #102 reg = INDF  key 56, rIdx = 0, size 1
  -- #103 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: BITWISEAND
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (3) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: BITWISEAND
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 2
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l95:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l95:s2:k1:d0:s0)		proc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l96:s4:k2:d1:s0)	 _whilecontinue_5($1) :
libRGB.c(l96:s5:k3:d1:s0)		iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1f {literal-unsigned-char}
libRGB.c(l96:s6:k4:d1:s0)		iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] == 0x0 {literal-unsigned-char}
libRGB.c(l96:s7:k5:d1:s0)		if iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_5($1)
libRGB.c(l97:s8:k10:d0:s0)		_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xf7 {literal-unsigned-char}
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 3 , last iCode = 3
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l96:s3:k14:d0:s0)	 preHeaderLbl0($6) :
libRGB.c(l96:s4:k2:d1:s0)	 _whilecontinue_5($1) :
libRGB.c(l96:s5:k3:d1:s0)		iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1f {literal-unsigned-char}
libRGB.c(l96:s6:k4:d1:s0)		iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] == 0x0 {literal-unsigned-char}
libRGB.c(l96:s7:k5:d1:s0)		if iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_5($1)
libRGB.c(l97:s8:k10:d0:s0)		_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xf7 {literal-unsigned-char}
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_5 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 4 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

----------------------------------------------------------------
libRGB.c(l96:s4:k2:d1:s0)	 _whilecontinue_5($1) :
libRGB.c(l96:s5:k3:d1:s0)		iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0x1f {literal-unsigned-char}
libRGB.c(l96:s6:k4:d1:s0)		iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k3 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}[r0x6C ] == 0x0 {literal-unsigned-char}
libRGB.c(l96:s7:k5:d1:s0)		if iTemp1 [k4 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _whilecontinue_5($1)
libRGB.c(l97:s8:k10:d0:s0)		_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xf7 {literal-unsigned-char}
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 8 , last iCode = 9
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (10) (11) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (10) (11) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (10) }

----------------------------------------------------------------
libRGB.c(l97:s8:k10:d0:s0)		_PIR1 [k5 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _PIR1 [k5 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xf7 {literal-unsigned-char}
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (3) (4) (10) (11) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l97:s10:k12:d0:s0)	 _return($4) :
libRGB.c(l97:s11:k13:d0:s0)		eproc _i2c_CheckIdle [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
Found a Processor Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l101:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l101:s2:k1:d0:s0)		proc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l102:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x2 {literal-unsigned-char}
libRGB.c(l102:s4:k3:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l103:s5:k15:d0:s0)	 preHeaderLbl0($6) :

----------------------------------------------------------------
Basic Block _whilecontinue_6 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l103:s6:k4:d1:s0)	 _whilecontinue_6($1) :
libRGB.c(l103:s7:k5:d1:s0)		iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* } = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l103:s8:k6:d1:s0)		iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* } := iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
libRGB.c(l103:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}} = @[iTemp2 [k7 lr8:9 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }]
libRGB.c(l103:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}} != 0 goto _whilecontinue_6($1)

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l103:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l103:s12:k14:d0:s0)		eproc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
  left:_i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
packRegisters
packRegisters
packRegsForAssign
  result:iTemp2 [k7 lr8:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
  left:
  right:iTemp1 [k5 lr7:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
  left:_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
    is volatile
        Symbol type: volatile-struct __00010107
  result:iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
          Symbol type: volatile-unsigned-bitfield {1,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
        Symbol type: volatile-unsigned-bitfield {1,1} near* 
  result:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}
          Symbol type: volatile-unsigned-bitfield {1,1}
  marking as a pointer (get) =>  left:iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}
        Symbol type: volatile-unsigned-bitfield {1,1}
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #3 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #4 reg = r0x20  key 26, rIdx = 32, size 1
  -- #5 reg = r0x21  key 27, rIdx = 33, size 1
  -- #6 reg = r0x30  key 27, rIdx = 48, size 1
  -- #7 reg = r0x22  key 28, rIdx = 34, size 1
  -- #8 reg = r0x31  key 28, rIdx = 49, size 1
  -- #9 reg = r0x40  key 28, rIdx = 64, size 1
  -- #10 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #11 reg = r0x23  key 29, rIdx = 35, size 1
  -- #12 reg = r0x32  key 29, rIdx = 50, size 1
  -- #13 reg = r0x41  key 29, rIdx = 65, size 1
  -- #14 reg = r0x50  key 29, rIdx = 80, size 1
  -- #15 reg = r0x24  key 30, rIdx = 36, size 1
  -- #16 reg = r0x33  key 30, rIdx = 51, size 1
  -- #17 reg = r0x42  key 30, rIdx = 66, size 1
  -- #18 reg = r0x51  key 30, rIdx = 81, size 1
  -- #19 reg = r0x60  key 30, rIdx = 96, size 1
  -- #20 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #21 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #22 reg = r0x25  key 31, rIdx = 37, size 1
  -- #23 reg = r0x34  key 31, rIdx = 52, size 1
  -- #24 reg = r0x43  key 31, rIdx = 67, size 1
  -- #25 reg = r0x52  key 31, rIdx = 82, size 1
  -- #26 reg = r0x61  key 31, rIdx = 97, size 1
  -- #27 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #28 reg = r0x26  key 32, rIdx = 38, size 1
  -- #29 reg = r0x35  key 32, rIdx = 53, size 1
  -- #30 reg = r0x44  key 32, rIdx = 68, size 1
  -- #31 reg = r0x53  key 32, rIdx = 83, size 1
  -- #32 reg = r0x62  key 32, rIdx = 98, size 1
  -- #33 reg = r0x27  key 33, rIdx = 39, size 1
  -- #34 reg = r0x36  key 33, rIdx = 54, size 1
  -- #35 reg = r0x45  key 33, rIdx = 69, size 1
  -- #36 reg = r0x54  key 33, rIdx = 84, size 1
  -- #37 reg = r0x63  key 33, rIdx = 99, size 1
  -- #38 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #39 reg = r0x28  key 34, rIdx = 40, size 1
  -- #40 reg = r0x37  key 34, rIdx = 55, size 1
  -- #41 reg = r0x46  key 34, rIdx = 70, size 1
  -- #42 reg = r0x55  key 34, rIdx = 85, size 1
  -- #43 reg = r0x64  key 34, rIdx = 100, size 1
  -- #44 reg = r0x29  key 35, rIdx = 41, size 1
  -- #45 reg = r0x38  key 35, rIdx = 56, size 1
  -- #46 reg = r0x47  key 35, rIdx = 71, size 1
  -- #47 reg = r0x56  key 35, rIdx = 86, size 1
  -- #48 reg = r0x65  key 35, rIdx = 101, size 1
  -- #49 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #50 reg = r0x39  key 36, rIdx = 57, size 1
  -- #51 reg = r0x48  key 36, rIdx = 72, size 1
  -- #52 reg = r0x57  key 36, rIdx = 87, size 1
  -- #53 reg = r0x66  key 36, rIdx = 102, size 1
  -- #54 reg = r0x49  key 37, rIdx = 73, size 1
  -- #55 reg = r0x58  key 37, rIdx = 88, size 1
  -- #56 reg = r0x67  key 37, rIdx = 103, size 1
  -- #57 reg = r0x59  key 38, rIdx = 89, size 1
  -- #58 reg = r0x68  key 38, rIdx = 104, size 1
  -- #59 reg = r0x69  key 39, rIdx = 105, size 1
  -- #60 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #61 reg = STK00  key 45, rIdx = 127, size 1
  -- #62 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #63 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #64 reg = STK01  key 46, rIdx = 126, size 1
  -- #65 reg = STK10  key 46, rIdx = 117, size 1
  -- #66 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #67 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #68 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #69 reg = STK02  key 47, rIdx = 125, size 1
  -- #70 reg = STK11  key 47, rIdx = 116, size 1
  -- #71 reg = INTCON  key 47, rIdx = 11, size 1
  -- #72 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #73 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #74 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #75 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #76 reg = STK03  key 48, rIdx = 124, size 1
  -- #77 reg = STK12  key 48, rIdx = 115, size 1
  -- #78 reg = PCL  key 48, rIdx = 2, size 1
  -- #79 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #80 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #81 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #82 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #83 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #84 reg = STK04  key 49, rIdx = 123, size 1
  -- #85 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #86 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #87 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #88 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #89 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #90 reg = STK05  key 50, rIdx = 122, size 1
  -- #91 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #92 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #93 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #94 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #95 reg = STK06  key 51, rIdx = 121, size 1
  -- #96 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #97 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #98 reg = STK07  key 52, rIdx = 120, size 1
  -- #99 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #100 reg = STK08  key 53, rIdx = 119, size 1
  -- #101 reg = STK09  key 55, rIdx = 118, size 1
  -- #102 reg = INDF  key 56, rIdx = 0, size 1
  -- #103 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: LABEL
deassignLRs
  op: LABEL
deassignLRs
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp2
isSpiltOnStack
  op: GET_VALUE_AT_ADDRESS
deassignLRs
willCauseSpill
computeSpillable
  2363 - 
bitvector Size = 18 bSize = 3
Bits on { (8) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6D (004F6C52).
  2378 - 
positionRegs
  2394 - 
  2397 - 
  op: IFX
deassignLRs
freeReg
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 4
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l101:s1:k0:d0:s0)	 _entry($5) :
libRGB.c(l101:s2:k1:d0:s0)		proc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l102:s3:k2:d0:s0)		_SSPCON2 [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x2 {literal-unsigned-char}
libRGB.c(l103:s6:k4:d1:s0)	 _whilecontinue_6($1) :
libRGB.c(l103:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l103:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat]]
libRGB.c(l103:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] != 0 goto _whilecontinue_6($1)
libRGB.c(l103:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l103:s12:k14:d0:s0)		eproc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block preHeaderLbl0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 5 , last iCode = 5
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l103:s5:k15:d0:s0)	 preHeaderLbl0($6) :
libRGB.c(l103:s6:k4:d1:s0)	 _whilecontinue_6($1) :
libRGB.c(l103:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l103:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat]]
libRGB.c(l103:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] != 0 goto _whilecontinue_6($1)
libRGB.c(l103:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l103:s12:k14:d0:s0)		eproc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _whilecontinue_6 : loop Depth = 1 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 6 , last iCode = 10
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

local defines bitVector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (5) (6) (7) }

----------------------------------------------------------------
libRGB.c(l103:s6:k4:d1:s0)	 _whilecontinue_6($1) :
libRGB.c(l103:s7:k5:d1:s0)		iTemp2 [k7 lr7:9 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat] = &[_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}]
libRGB.c(l103:s9:k7:d1:s0)		iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] = @[iTemp2 [k7 lr7:9 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1} near* }[remat]]
libRGB.c(l103:s10:k8:d1:s0)		if iTemp3 [k8 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {1,1}}[r0x6D ] != 0 goto _whilecontinue_6($1)
libRGB.c(l103:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l103:s12:k14:d0:s0)		eproc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 11 , last iCode = 12
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 16 bSize = 3
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

outDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { (2) (3) (5) (6) (7) }

usesDefs Set bitvector :bitvector Size = 16 bSize = 3
Bits on { }

----------------------------------------------------------------
libRGB.c(l103:s11:k13:d0:s0)	 _return($4) :
libRGB.c(l103:s12:k14:d0:s0)		eproc _i2c_RStart [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
allocDirReg symbol name _SSPCON2_bits
  703  storage class 0 
 712  specifier
_SSPCON2_bits [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010107}
  -- added _SSPCON2_bits to hash, size = 1
  -- and it is at a fixed address 0x91
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 13
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (4) (5) (7) (8) }

----------------------------------------------------------------
libRGB.c(l114:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l114:s2:k1:d0:s0)		proc _i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l116:s3:k2:d0:s0)		iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _TRISC [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x18 {literal-unsigned-char}
libRGB.c(l116:s4:k3:d0:s0)		_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l118:s5:k4:d0:s0)		_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libRGB.c(l119:s6:k5:d0:s0)		iTemp1 [k5 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPSTAT [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x80 {literal-unsigned-char}
libRGB.c(l119:s7:k6:d0:s0)		_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp1 [k5 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l122:s8:k7:d0:s0)		_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x8 {literal-unsigned-char}
libRGB.c(l123:s9:k8:d0:s0)		iTemp2 [k7 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x20 {literal-unsigned-char}
libRGB.c(l123:s10:k9:d0:s0)		_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp2 [k7 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l125:s11:k10:d0:s0)		_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libRGB.c(l128:s12:k11:d0:s0)		_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x31 {literal-unsigned-char}
libRGB.c(l131:s13:k12:d0:s0)		_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 14 , last iCode = 15
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l131:s14:k13:d0:s0)	 _return($1) :
libRGB.c(l131:s15:k14:d0:s0)		eproc _i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
packRegsForAssign
  result:_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _TRISC
  703  storage class 3 
 708  integral
 712  specifier
_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _TRISC (004F829D).
  -- added _TRISC to hash, size = 1
  -- and it is at a fixed address 0x87
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp0
  replacing with iTemp0
  result:_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp0 [k3 lr3:4 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _SSPSTAT
  703  storage class 3 
 708  integral
 712  specifier
_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPSTAT to hash, size = 1
  -- and it is at a fixed address 0x94
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k5 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPSTAT
  703  storage class 3 
 708  integral
 712  specifier
_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPSTAT to hash, size = 1
  -- and it is at a fixed address 0x94
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp1
  replacing with iTemp1
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp1 [k5 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x8 {literal-unsigned-char}
allocDirReg symbol name _SSPCON
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON to hash, size = 1
  -- and it is at a fixed address 0x14
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x8 {literal-unsigned-char}
packRegsForAssign
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp2 [k7 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON to hash, size = 1
  -- and it is at a fixed address 0x14
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp2
  replacing with iTemp2
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp2 [k7 lr9:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x31 {literal-unsigned-char}
allocDirReg symbol name _SSPADD
  703  storage class 3 
 708  integral
 712  specifier
_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
newReg: Created register _SSPADD (004F829D).
  -- added _SSPADD to hash, size = 1
  -- and it is at a fixed address 0x93
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x31 {literal-unsigned-char}
packRegsForAssign
  result:_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _PIR1
  703  storage class 3 
 708  integral
 712  specifier
_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PIR1 to hash, size = 1
  -- and it is at a fixed address 0x0c
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _SSPSTAT
  703  storage class 3 
 708  integral
 712  specifier
_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPSTAT to hash, size = 1
  -- and it is at a fixed address 0x94
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x8 {literal-unsigned-char}
allocDirReg symbol name _SSPCON
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON to hash, size = 1
  -- and it is at a fixed address 0x14
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x8 {literal-unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x31 {literal-unsigned-char}
allocDirReg symbol name _SSPADD
  703  storage class 3 
 708  integral
 712  specifier
_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPADD to hash, size = 1
  -- and it is at a fixed address 0x93
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x31 {literal-unsigned-char}
packRegsForAssign
  result:_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
allocDirReg symbol name _PIR1
  703  storage class 3 
 708  integral
 712  specifier
_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _PIR1 to hash, size = 1
  -- and it is at a fixed address 0x0c
  2981 - result is not temp
  2991 - not packing - right is not temp
allocDirReg BAD, op is NULL
  result:_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:0x0 {literal-unsigned-char}
  left:_i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_TRISC [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  left:_SSPSTAT [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  left:_SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  result:_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  result:_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
  result:_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
packRegisters
  left:_i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #30 reg = r0x26  key 32, rIdx = 38, size 1
  -- #31 reg = r0x35  key 32, rIdx = 53, size 1
  -- #32 reg = r0x44  key 32, rIdx = 68, size 1
  -- #33 reg = r0x53  key 32, rIdx = 83, size 1
  -- #34 reg = r0x62  key 32, rIdx = 98, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #52 reg = r0x39  key 36, rIdx = 57, size 1
  -- #53 reg = r0x48  key 36, rIdx = 72, size 1
  -- #54 reg = r0x57  key 36, rIdx = 87, size 1
  -- #55 reg = r0x66  key 36, rIdx = 102, size 1
  -- #56 reg = r0x49  key 37, rIdx = 73, size 1
  -- #57 reg = r0x58  key 37, rIdx = 88, size 1
  -- #58 reg = r0x67  key 37, rIdx = 103, size 1
  -- #59 reg = r0x59  key 38, rIdx = 89, size 1
  -- #60 reg = r0x68  key 38, rIdx = 104, size 1
  -- #61 reg = r0x69  key 39, rIdx = 105, size 1
  -- #62 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #63 reg = STK00  key 45, rIdx = 127, size 1
  -- #64 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #65 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #66 reg = STK01  key 46, rIdx = 126, size 1
  -- #67 reg = STK10  key 46, rIdx = 117, size 1
  -- #68 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #69 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #70 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #71 reg = STK02  key 47, rIdx = 125, size 1
  -- #72 reg = STK11  key 47, rIdx = 116, size 1
  -- #73 reg = INTCON  key 47, rIdx = 11, size 1
  -- #74 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #75 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #76 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #77 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #78 reg = STK03  key 48, rIdx = 124, size 1
  -- #79 reg = STK12  key 48, rIdx = 115, size 1
  -- #80 reg = PCL  key 48, rIdx = 2, size 1
  -- #81 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #82 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #83 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #84 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #85 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #86 reg = STK04  key 49, rIdx = 123, size 1
  -- #87 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #88 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #89 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #90 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #91 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #92 reg = STK05  key 50, rIdx = 122, size 1
  -- #93 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #94 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #95 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #96 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #97 reg = STK06  key 51, rIdx = 121, size 1
  -- #98 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #99 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #100 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #101 reg = STK07  key 52, rIdx = 120, size 1
  -- #102 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #103 reg = STK08  key 53, rIdx = 119, size 1
  -- #104 reg = STK09  key 55, rIdx = 118, size 1
  -- #105 reg = INDF  key 56, rIdx = 0, size 1
  -- #106 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: |
deassignLRs
  op: =
deassignLRs
  op: |
deassignLRs
  op: =
deassignLRs
  op: |
deassignLRs
  op: =
deassignLRs
  op: =
deassignLRs
  op: =
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 13
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

local defines bitVector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (4) (5) (6) (7) (8) (9) (10) (11) (12) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (4) (5) (7) (8) }

----------------------------------------------------------------
libRGB.c(l114:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l114:s2:k1:d0:s0)		proc _i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l116:s3:k2:d0:s0)		_TRISC [k2 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _TRISC [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x18 {literal-unsigned-char}
libRGB.c(l118:s5:k4:d0:s0)		_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libRGB.c(l119:s6:k5:d0:s0)		_SSPSTAT [k4 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPSTAT [k4 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x80 {literal-unsigned-char}
libRGB.c(l122:s8:k7:d0:s0)		_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x8 {literal-unsigned-char}
libRGB.c(l123:s9:k8:d0:s0)		_SSPCON [k6 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} | 0x20 {literal-unsigned-char}
libRGB.c(l125:s11:k10:d0:s0)		_SSPCON2 [k8 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libRGB.c(l128:s12:k11:d0:s0)		_SSPADD [k9 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x31 {literal-unsigned-char}
libRGB.c(l131:s13:k12:d0:s0)		_PIR1 [k10 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := 0x0 {literal-unsigned-char}
libRGB.c(l131:s14:k13:d0:s0)	 _return($1) :
libRGB.c(l131:s15:k14:d0:s0)		eproc _i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 14 , last iCode = 15
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 15 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

outDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { (2) (3) (5) (6) (8) (9) (10) (11) (12) }

usesDefs Set bitvector :bitvector Size = 15 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l131:s14:k13:d0:s0)	 _return($1) :
libRGB.c(l131:s15:k14:d0:s0)		eproc _i2c_configure [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
Found a Direct Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 26
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (12) (18) (24) (25) }

local defines bitVector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (13) (16) (17) (18) (19) (22) (23) (24) (25) (26) (27) }

pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

usesDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (13) (16) (17) (18) (19) (22) (23) (24) (26) (27) }

----------------------------------------------------------------
libRGB.c(l136:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l136:s2:k1:d0:s0)		proc _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l136:s3:k2:d0:s0)	iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1} = recv _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l136:s4:k3:d0:s0)	iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1} = recv _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l140:s5:k4:d0:s0)		iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* } = &[_PIR1_bits [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010071}]
libRGB.c(l140:s6:k5:d0:s0)		iTemp3 [k9 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* } := iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
libRGB.c(l140:s7:k6:d0:s0)		*(iTemp3 [k9 lr6:7 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }) := 0x0 {literal-unsigned-char}
libRGB.c(l143:s8:k7:d0:s0)		iTemp4 [k11 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l144:s9:k8:d0:s0)		iTemp5 [k13 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_SendStart [k12 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l147:s10:k9:d0:s0)		send 0xffffffa2 {literal-char}{argreg = 1}
libRGB.c(l147:s11:k10:d0:s0)		iTemp6 [k15 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l148:s12:k11:d0:s0)		iTemp7 [k17 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l149:s13:k12:d0:s0)		iTemp8 [k19 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l149:s14:k13:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp8 [k19 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l152:s15:k15:d0:s0)		send iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}{argreg = 1}
libRGB.c(l152:s16:k16:d0:s0)		iTemp10 [k21 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l153:s17:k17:d0:s0)		iTemp11 [k22 lr17:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l154:s18:k18:d0:s0)		iTemp12 [k23 lr18:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l154:s19:k19:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp12 [k23 lr18:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l157:s20:k21:d0:s0)		send iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}{argreg = 1}
libRGB.c(l157:s21:k22:d0:s0)		iTemp14 [k25 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l158:s22:k23:d0:s0)		iTemp15 [k26 lr22:22 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l159:s23:k24:d0:s0)		iTemp16 [k27 lr23:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l159:s24:k25:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} := iTemp16 [k27 lr23:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
libRGB.c(l163:s25:k26:d0:s0)		iTemp17 [k29 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_SendStop [k28 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l164:s26:k27:d0:s0)		iTemp18 [k30 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 27 , last iCode = 28
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 30 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

in pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

inDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

outDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

usesDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l164:s27:k28:d0:s0)	 _return($1) :
libRGB.c(l164:s28:k29:d0:s0)		eproc _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
packRegisters
packRegsForAssign
  result:iTemp3 [k9 lr6:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  left:
  right:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp2
  replacing with iTemp2
  result:iTemp3 [k9 lr5:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  left:
  right:iTemp2 [k7 lr5:6 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
pointer is set
  result:iTemp3 [k9 lr5:7 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  left:
  right:0x0 {literal-unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp8 [k19 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp8
  replacing with iTemp8
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp8 [k19 lr13:14 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp12 [k23 lr18:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp12
  replacing with iTemp12
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp12 [k23 lr18:19 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
packRegsForAssign
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp16 [k27 lr23:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
allocDirReg symbol name _SSPCON2
  703  storage class 3 
 708  integral
 712  specifier
_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  -- added _SSPCON2 to hash, size = 1
  -- and it is at a fixed address 0x91
  2981 - result is not temp
  3049 - dic result key == ic right key -- pointer set=N
  packing. removing iTemp16
  replacing with iTemp16
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
  left:
  right:iTemp16 [k27 lr23:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
pointer is set
  result:iTemp3 [k9 lr5:7 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  left:
  right:0x0 {literal-unsigned-char}
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:_PIR1_bits [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010071}
    is volatile
        Symbol type: volatile-struct __00010071
  result:iTemp3 [k9 lr5:7 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
          Symbol type: volatile-unsigned-bitfield {3,1} near* 
  3869 - packRegisters. result is rematerializable
  3947 - pointer reg req = 0
  result:iTemp3 [k9 lr5:7 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
          Symbol type: volatile-unsigned-bitfield {3,1} near* 
  3818 - Pointer set
  marking as a pointer (set) =>  result:iTemp3 [k9 lr5:7 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }
  3947 - pointer reg req = 0
  left:_i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp4 [k11 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:_i2c_SendStart [k12 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp5 [k13 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
  result:iTemp6 [k15 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp7 [k17 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:_SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
  result:iTemp10 [k21 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp11 [k22 lr17:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:_SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
        Symbol type: unsigned-char function    ( char) 
  result:iTemp14 [k25 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp15 [k26 lr22:22 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:_SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
    is volatile
sfr         Symbol type: sfr-volatile-unsigned-char
  result:_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char}
          Symbol type: sfr-volatile-unsigned-char
  3947 - pointer reg req = 0
isBitwiseOptimizable
  left:_i2c_SendStop [k28 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp17 [k29 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:_i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp18 [k30 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #30 reg = r0x26  key 32, rIdx = 38, size 1
  -- #31 reg = r0x35  key 32, rIdx = 53, size 1
  -- #32 reg = r0x44  key 32, rIdx = 68, size 1
  -- #33 reg = r0x53  key 32, rIdx = 83, size 1
  -- #34 reg = r0x62  key 32, rIdx = 98, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #52 reg = r0x39  key 36, rIdx = 57, size 1
  -- #53 reg = r0x48  key 36, rIdx = 72, size 1
  -- #54 reg = r0x57  key 36, rIdx = 87, size 1
  -- #55 reg = r0x66  key 36, rIdx = 102, size 1
  -- #56 reg = r0x49  key 37, rIdx = 73, size 1
  -- #57 reg = r0x58  key 37, rIdx = 88, size 1
  -- #58 reg = r0x67  key 37, rIdx = 103, size 1
  -- #59 reg = r0x59  key 38, rIdx = 89, size 1
  -- #60 reg = r0x68  key 38, rIdx = 104, size 1
  -- #61 reg = r0x69  key 39, rIdx = 105, size 1
  -- #62 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #63 reg = STK00  key 45, rIdx = 127, size 1
  -- #64 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #65 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #66 reg = STK01  key 46, rIdx = 126, size 1
  -- #67 reg = STK10  key 46, rIdx = 117, size 1
  -- #68 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #69 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #70 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #71 reg = STK02  key 47, rIdx = 125, size 1
  -- #72 reg = STK11  key 47, rIdx = 116, size 1
  -- #73 reg = INTCON  key 47, rIdx = 11, size 1
  -- #74 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #75 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #76 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #77 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #78 reg = STK03  key 48, rIdx = 124, size 1
  -- #79 reg = STK12  key 48, rIdx = 115, size 1
  -- #80 reg = PCL  key 48, rIdx = 2, size 1
  -- #81 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #82 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #83 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #84 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #85 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #86 reg = STK04  key 49, rIdx = 123, size 1
  -- #87 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #88 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #89 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #90 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #91 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #92 reg = STK05  key 50, rIdx = 122, size 1
  -- #93 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #94 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #95 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #96 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #97 reg = STK06  key 51, rIdx = 121, size 1
  -- #98 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #99 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #100 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #101 reg = STK07  key 52, rIdx = 120, size 1
  -- #102 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #103 reg = STK08  key 53, rIdx = 119, size 1
  -- #104 reg = STK09  key 55, rIdx = 118, size 1
  -- #105 reg = INDF  key 56, rIdx = 0, size 1
  -- #106 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
  2697 - iTemp4
  2697 - iTemp5
  2697 - iTemp6
  2697 - iTemp7
  2697 - iTemp8
  2707 - itemp register
  reg name iTemp8,  reg type REG_GPR
  2697 - iTemp10
  2697 - iTemp11
  2697 - iTemp12
  2707 - itemp register
  reg name iTemp12,  reg type REG_GPR
  2697 - iTemp14
  2697 - iTemp15
  2697 - iTemp16
  2707 - itemp register
  reg name iTemp16,  reg type REG_GPR
  2697 - iTemp17
  2697 - iTemp18
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6E (004F6C52).
  2378 - 
  2394 - 
  op: ADDRESS_OF
deassignLRs
willCauseSpill
computeSpillable
spillThis : iTemp3
isSpiltOnStack
  op: =
deassignLRs
  op: CALL
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: CALL
deassignLRs
  op: BITWISEAND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: CALL
deassignLRs
  op: BITWISEAND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: CALL
deassignLRs
  op: BITWISEAND
deassignLRs
  op: CALL
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 26
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (12) (18) (24) (25) }

local defines bitVector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (13) (16) (17) (18) (19) (22) (23) (24) (25) (26) (27) }

pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

usesDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (13) (16) (17) (18) (19) (22) (23) (24) (26) (27) }

----------------------------------------------------------------
libRGB.c(l136:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l136:s2:k1:d0:s0)		proc _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l136:s3:k2:d0:s0)	iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}[r0x6D ] = recv _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l136:s4:k3:d0:s0)	iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}[r0x6E ] = recv _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l140:s5:k4:d0:s0)		iTemp3 [k9 lr5:7 so:0]{ ia0 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }[remat] = &[_PIR1_bits [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010071}]
libRGB.c(l140:s7:k6:d0:s0)		*(iTemp3 [k9 lr5:7 so:0]{ ia1 a2p0 re0 rm1 nos0 ru0 dp0}{volatile-unsigned-bitfield {3,1} near* }[remat]) := 0x0 {literal-unsigned-char}
libRGB.c(l143:s8:k7:d0:s0)		iTemp4 [k11 lr8:8 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l144:s9:k8:d0:s0)		iTemp5 [k13 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_SendStart [k12 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l147:s10:k9:d0:s0)		send 0xffffffa2 {literal-char}{argreg = 1}
libRGB.c(l147:s11:k10:d0:s0)		iTemp6 [k15 lr11:11 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l148:s12:k11:d0:s0)		iTemp7 [k17 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l149:s13:k12:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l152:s15:k15:d0:s0)		send iTemp0 [k2 lr3:15 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_reg_1_1}[r0x6D ]{argreg = 1}
libRGB.c(l152:s16:k16:d0:s0)		iTemp10 [k21 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l153:s17:k17:d0:s0)		iTemp11 [k22 lr17:17 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l154:s18:k18:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l157:s20:k21:d0:s0)		send iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Write_RGB_rgb_1_1}[r0x6E ]{argreg = 1}
libRGB.c(l157:s21:k22:d0:s0)		iTemp14 [k25 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char} = call _i2c_SendByte [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{unsigned-char function    ( char) }
libRGB.c(l158:s22:k23:d0:s0)		iTemp15 [k26 lr22:22 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _pausa_1ms [k16 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l159:s23:k24:d0:s0)		_SSPCON2 [k18 lr0:0 so:0]{ ia1 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} = _SSPCON2 [k18 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{sfr-volatile-unsigned-char} & 0xbf {literal-unsigned-char}
libRGB.c(l163:s25:k26:d0:s0)		iTemp17 [k29 lr25:25 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_SendStop [k28 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l164:s26:k27:d0:s0)		iTemp18 [k30 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_CheckIdle [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l164:s27:k28:d0:s0)	 _return($1) :
libRGB.c(l164:s28:k29:d0:s0)		eproc _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 27 , last iCode = 28
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 30 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

in pointers Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (9) }

inDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

outDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { (2) (3) (4) (5) (7) (8) (10) (11) (12) (16) (17) (18) (22) (23) (24) (25) (26) (27) }

usesDefs Set bitvector :bitvector Size = 30 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l164:s27:k28:d0:s0)	 _return($1) :
libRGB.c(l164:s28:k29:d0:s0)		eproc _Write_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
allocDirReg symbol name _PIR1_bits
  703  storage class 0 
 712  specifier
_PIR1_bits [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{volatile-struct __00010071}
  -- added _PIR1_bits to hash, size = 1
  -- and it is at a fixed address 0x0c
Found a Direct Register!
typeRegWithIdx - requesting index = 0x6d
Found a Dynamic Register!
Found a Direct Register!
typeRegWithIdx - requesting index = 0x6e
Found a Dynamic Register!
Found a Direct Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l172:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l172:s2:k1:d0:s0)		proc _RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l173:s3:k2:d0:s0)		iTemp0 [k3 lr3:3 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_configure [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libRGB.c(l173:s4:k3:d0:s0)	 _return($1) :
libRGB.c(l173:s5:k4:d0:s0)		eproc _RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
packRegisters
  left:_RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  left:_i2c_configure [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
  result:iTemp0 [k3 lr3:3 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
        Symbol type: void function    ( ) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #30 reg = r0x26  key 32, rIdx = 38, size 1
  -- #31 reg = r0x35  key 32, rIdx = 53, size 1
  -- #32 reg = r0x44  key 32, rIdx = 68, size 1
  -- #33 reg = r0x53  key 32, rIdx = 83, size 1
  -- #34 reg = r0x62  key 32, rIdx = 98, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #52 reg = r0x39  key 36, rIdx = 57, size 1
  -- #53 reg = r0x48  key 36, rIdx = 72, size 1
  -- #54 reg = r0x57  key 36, rIdx = 87, size 1
  -- #55 reg = r0x66  key 36, rIdx = 102, size 1
  -- #56 reg = r0x49  key 37, rIdx = 73, size 1
  -- #57 reg = r0x58  key 37, rIdx = 88, size 1
  -- #58 reg = r0x67  key 37, rIdx = 103, size 1
  -- #59 reg = r0x59  key 38, rIdx = 89, size 1
  -- #60 reg = r0x68  key 38, rIdx = 104, size 1
  -- #61 reg = r0x69  key 39, rIdx = 105, size 1
  -- #62 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #63 reg = STK00  key 45, rIdx = 127, size 1
  -- #64 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #65 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #66 reg = STK01  key 46, rIdx = 126, size 1
  -- #67 reg = STK10  key 46, rIdx = 117, size 1
  -- #68 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #69 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #70 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #71 reg = STK02  key 47, rIdx = 125, size 1
  -- #72 reg = STK11  key 47, rIdx = 116, size 1
  -- #73 reg = INTCON  key 47, rIdx = 11, size 1
  -- #74 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #75 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #76 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #77 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #78 reg = STK03  key 48, rIdx = 124, size 1
  -- #79 reg = STK12  key 48, rIdx = 115, size 1
  -- #80 reg = PCL  key 48, rIdx = 2, size 1
  -- #81 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #82 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #83 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #84 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #85 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #86 reg = STK04  key 49, rIdx = 123, size 1
  -- #87 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #88 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #89 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #90 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #91 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #92 reg = STK05  key 50, rIdx = 122, size 1
  -- #93 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #94 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #95 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #96 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #97 reg = STK06  key 51, rIdx = 121, size 1
  -- #98 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #99 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #100 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #101 reg = STK07  key 52, rIdx = 120, size 1
  -- #102 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #103 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #104 reg = STK08  key 53, rIdx = 119, size 1
  -- #105 reg = STK09  key 55, rIdx = 118, size 1
  -- #106 reg = INDF  key 56, rIdx = 0, size 1
  -- #107 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 3
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :bitvector Size = 5 bSize = 1
Bits on { (2) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

----------------------------------------------------------------
libRGB.c(l172:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l172:s2:k1:d0:s0)		proc _RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l173:s3:k2:d0:s0)		iTemp0 [k3 lr3:3 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _i2c_configure [k2 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
libRGB.c(l173:s4:k3:d0:s0)	 _return($1) :
libRGB.c(l173:s5:k4:d0:s0)		eproc _RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 4 , last iCode = 5
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 5 bSize = 1
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

outDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { (2) }

usesDefs Set bitvector :bitvector Size = 5 bSize = 1
Bits on { }

----------------------------------------------------------------
libRGB.c(l173:s4:k3:d0:s0)	 _return($1) :
libRGB.c(l173:s5:k4:d0:s0)		eproc _RGB_init [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( ) }
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 24
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

----------------------------------------------------------------
libRGB.c(l182:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l182:s2:k1:d0:s0)		proc _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s3:k2:d0:s0)	iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1} = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s4:k3:d0:s0)	iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1} = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s5:k4:d0:s0)	iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1} = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s6:k5:d0:s0)	iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1} = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l183:s7:k6:d0:s0)		send 0xb {literal-unsigned-char}{argreg = 1}
libRGB.c(l183:s8:k7:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}{argreg = 1}
libRGB.c(l183:s9:k8:d0:s0)		iTemp4 [k11 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l184:s10:k9:d0:s0)		send 0x6 {literal-unsigned-char}{argreg = 1}
libRGB.c(l184:s11:k10:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}{argreg = 1}
libRGB.c(l184:s12:k11:d0:s0)		iTemp5 [k12 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l185:s13:k12:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l185:s14:k13:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}{argreg = 1}
libRGB.c(l185:s15:k14:d0:s0)		iTemp6 [k13 lr15:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l187:s16:k15:d0:s0)		send 0xa {literal-unsigned-char}{argreg = 1}
libRGB.c(l187:s17:k16:d0:s0)		send iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}{argreg = 1}
libRGB.c(l187:s18:k17:d0:s0)		iTemp7 [k14 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l188:s19:k18:d0:s0)		send 0x5 {literal-unsigned-char}{argreg = 1}
libRGB.c(l188:s20:k19:d0:s0)		send iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}{argreg = 1}
libRGB.c(l188:s21:k20:d0:s0)		iTemp8 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l189:s22:k21:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l189:s23:k22:d0:s0)		send iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}{argreg = 1}
libRGB.c(l189:s24:k23:d0:s0)		iTemp9 [k16 lr24:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 25 , last iCode = 26
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l189:s25:k24:d0:s0)	 _return($1) :
libRGB.c(l189:s26:k25:d0:s0)		eproc _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
packRegisters
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
    used on left
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
    used on left
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
    used on left
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
    used on left
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp4 [k11 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp5 [k12 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp6 [k13 lr15:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp7 [k14 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp8 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp9 [k16 lr24:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #30 reg = r0x26  key 32, rIdx = 38, size 1
  -- #31 reg = r0x35  key 32, rIdx = 53, size 1
  -- #32 reg = r0x44  key 32, rIdx = 68, size 1
  -- #33 reg = r0x53  key 32, rIdx = 83, size 1
  -- #34 reg = r0x62  key 32, rIdx = 98, size 1
  -- #35 reg = r0x27  key 33, rIdx = 39, size 1
  -- #36 reg = r0x36  key 33, rIdx = 54, size 1
  -- #37 reg = r0x45  key 33, rIdx = 69, size 1
  -- #38 reg = r0x54  key 33, rIdx = 84, size 1
  -- #39 reg = r0x63  key 33, rIdx = 99, size 1
  -- #40 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #41 reg = r0x28  key 34, rIdx = 40, size 1
  -- #42 reg = r0x37  key 34, rIdx = 55, size 1
  -- #43 reg = r0x46  key 34, rIdx = 70, size 1
  -- #44 reg = r0x55  key 34, rIdx = 85, size 1
  -- #45 reg = r0x64  key 34, rIdx = 100, size 1
  -- #46 reg = r0x29  key 35, rIdx = 41, size 1
  -- #47 reg = r0x38  key 35, rIdx = 56, size 1
  -- #48 reg = r0x47  key 35, rIdx = 71, size 1
  -- #49 reg = r0x56  key 35, rIdx = 86, size 1
  -- #50 reg = r0x65  key 35, rIdx = 101, size 1
  -- #51 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #52 reg = r0x39  key 36, rIdx = 57, size 1
  -- #53 reg = r0x48  key 36, rIdx = 72, size 1
  -- #54 reg = r0x57  key 36, rIdx = 87, size 1
  -- #55 reg = r0x66  key 36, rIdx = 102, size 1
  -- #56 reg = r0x49  key 37, rIdx = 73, size 1
  -- #57 reg = r0x58  key 37, rIdx = 88, size 1
  -- #58 reg = r0x67  key 37, rIdx = 103, size 1
  -- #59 reg = r0x59  key 38, rIdx = 89, size 1
  -- #60 reg = r0x68  key 38, rIdx = 104, size 1
  -- #61 reg = r0x69  key 39, rIdx = 105, size 1
  -- #62 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #63 reg = STK00  key 45, rIdx = 127, size 1
  -- #64 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #65 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #66 reg = STK01  key 46, rIdx = 126, size 1
  -- #67 reg = STK10  key 46, rIdx = 117, size 1
  -- #68 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #69 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #70 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #71 reg = STK02  key 47, rIdx = 125, size 1
  -- #72 reg = STK11  key 47, rIdx = 116, size 1
  -- #73 reg = INTCON  key 47, rIdx = 11, size 1
  -- #74 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #75 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #76 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #77 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #78 reg = STK03  key 48, rIdx = 124, size 1
  -- #79 reg = STK12  key 48, rIdx = 115, size 1
  -- #80 reg = PCL  key 48, rIdx = 2, size 1
  -- #81 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #82 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #83 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #84 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #85 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #86 reg = STK04  key 49, rIdx = 123, size 1
  -- #87 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #88 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #89 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #90 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #91 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #92 reg = STK05  key 50, rIdx = 122, size 1
  -- #93 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #94 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #95 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #96 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #97 reg = STK06  key 51, rIdx = 121, size 1
  -- #98 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #99 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #100 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #101 reg = STK07  key 52, rIdx = 120, size 1
  -- #102 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #103 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #104 reg = STK08  key 53, rIdx = 119, size 1
  -- #105 reg = STK09  key 55, rIdx = 118, size 1
  -- #106 reg = INDF  key 56, rIdx = 0, size 1
  -- #107 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
  2697 - iTemp4
  2697 - iTemp5
  2697 - iTemp6
  2697 - iTemp7
  2697 - iTemp8
  2697 - iTemp9
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x6F (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x70 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) (6) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x71 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) (6) (8) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x72 (004F6C52).
  2378 - 
  2394 - 
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 24
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) }

local defines bitVector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

----------------------------------------------------------------
libRGB.c(l182:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l182:s2:k1:d0:s0)		proc _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s3:k2:d0:s0)	iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}[r0x6F ] = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s4:k3:d0:s0)	iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}[r0x70 ] = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s5:k4:d0:s0)	iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}[r0x71 ] = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l182:s6:k5:d0:s0)	iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}[r0x72 ] = recv _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l183:s7:k6:d0:s0)		send 0xb {literal-unsigned-char}{argreg = 1}
libRGB.c(l183:s8:k7:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}[r0x72 ]{argreg = 1}
libRGB.c(l183:s9:k8:d0:s0)		iTemp4 [k11 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l184:s10:k9:d0:s0)		send 0x6 {literal-unsigned-char}{argreg = 1}
libRGB.c(l184:s11:k10:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}[r0x72 ]{argreg = 1}
libRGB.c(l184:s12:k11:d0:s0)		iTemp5 [k12 lr12:12 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l185:s13:k12:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l185:s14:k13:d0:s0)		send iTemp3 [k8 lr6:14 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_velocidad_1_1}[r0x72 ]{argreg = 1}
libRGB.c(l185:s15:k14:d0:s0)		iTemp6 [k13 lr15:15 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l187:s16:k15:d0:s0)		send 0xa {literal-unsigned-char}{argreg = 1}
libRGB.c(l187:s17:k16:d0:s0)		send iTemp2 [k6 lr5:17 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_blue_1_1}[r0x71 ]{argreg = 1}
libRGB.c(l187:s18:k17:d0:s0)		iTemp7 [k14 lr18:18 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l188:s19:k18:d0:s0)		send 0x5 {literal-unsigned-char}{argreg = 1}
libRGB.c(l188:s20:k19:d0:s0)		send iTemp1 [k4 lr4:20 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_green_1_1}[r0x70 ]{argreg = 1}
libRGB.c(l188:s21:k20:d0:s0)		iTemp8 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l189:s22:k21:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l189:s23:k22:d0:s0)		send iTemp0 [k2 lr3:23 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _RGB_red_1_1}[r0x6F ]{argreg = 1}
libRGB.c(l189:s24:k23:d0:s0)		iTemp9 [k16 lr24:24 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l189:s25:k24:d0:s0)	 _return($1) :
libRGB.c(l189:s26:k25:d0:s0)		eproc _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 25 , last iCode = 26
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 26 bSize = 4
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

outDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { (2) (3) (4) (5) (8) (11) (14) (17) (20) (23) }

usesDefs Set bitvector :bitvector Size = 26 bSize = 4
Bits on { }

----------------------------------------------------------------
libRGB.c(l189:s25:k24:d0:s0)	 _return($1) :
libRGB.c(l189:s26:k25:d0:s0)		eproc _RGB [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x71
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x71
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x70
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x6f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l194:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l194:s2:k1:d0:s0)		proc _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l194:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1} = recv _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l194:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1} = recv _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l195:s5:k4:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l195:s6:k5:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l195:s7:k6:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}{argreg = 1}
libRGB.c(l195:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}{argreg = 1}
libRGB.c(l195:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l195:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l195:s11:k10:d0:s0)		eproc _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
packRegisters
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = r0x70  key 31, rIdx = 112, size 1
  -- #30 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #31 reg = r0x26  key 32, rIdx = 38, size 1
  -- #32 reg = r0x35  key 32, rIdx = 53, size 1
  -- #33 reg = r0x44  key 32, rIdx = 68, size 1
  -- #34 reg = r0x53  key 32, rIdx = 83, size 1
  -- #35 reg = r0x62  key 32, rIdx = 98, size 1
  -- #36 reg = r0x71  key 32, rIdx = 113, size 1
  -- #37 reg = r0x27  key 33, rIdx = 39, size 1
  -- #38 reg = r0x36  key 33, rIdx = 54, size 1
  -- #39 reg = r0x45  key 33, rIdx = 69, size 1
  -- #40 reg = r0x54  key 33, rIdx = 84, size 1
  -- #41 reg = r0x63  key 33, rIdx = 99, size 1
  -- #42 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #43 reg = r0x72  key 33, rIdx = 114, size 1
  -- #44 reg = r0x28  key 34, rIdx = 40, size 1
  -- #45 reg = r0x37  key 34, rIdx = 55, size 1
  -- #46 reg = r0x46  key 34, rIdx = 70, size 1
  -- #47 reg = r0x55  key 34, rIdx = 85, size 1
  -- #48 reg = r0x64  key 34, rIdx = 100, size 1
  -- #49 reg = r0x29  key 35, rIdx = 41, size 1
  -- #50 reg = r0x38  key 35, rIdx = 56, size 1
  -- #51 reg = r0x47  key 35, rIdx = 71, size 1
  -- #52 reg = r0x56  key 35, rIdx = 86, size 1
  -- #53 reg = r0x65  key 35, rIdx = 101, size 1
  -- #54 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #55 reg = r0x39  key 36, rIdx = 57, size 1
  -- #56 reg = r0x48  key 36, rIdx = 72, size 1
  -- #57 reg = r0x57  key 36, rIdx = 87, size 1
  -- #58 reg = r0x66  key 36, rIdx = 102, size 1
  -- #59 reg = r0x49  key 37, rIdx = 73, size 1
  -- #60 reg = r0x58  key 37, rIdx = 88, size 1
  -- #61 reg = r0x67  key 37, rIdx = 103, size 1
  -- #62 reg = r0x59  key 38, rIdx = 89, size 1
  -- #63 reg = r0x68  key 38, rIdx = 104, size 1
  -- #64 reg = r0x69  key 39, rIdx = 105, size 1
  -- #65 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #66 reg = STK00  key 45, rIdx = 127, size 1
  -- #67 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #68 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #69 reg = STK01  key 46, rIdx = 126, size 1
  -- #70 reg = STK10  key 46, rIdx = 117, size 1
  -- #71 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #72 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #73 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #74 reg = STK02  key 47, rIdx = 125, size 1
  -- #75 reg = STK11  key 47, rIdx = 116, size 1
  -- #76 reg = INTCON  key 47, rIdx = 11, size 1
  -- #77 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #78 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #79 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #80 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #81 reg = STK03  key 48, rIdx = 124, size 1
  -- #82 reg = STK12  key 48, rIdx = 115, size 1
  -- #83 reg = PCL  key 48, rIdx = 2, size 1
  -- #84 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #85 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #86 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #87 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #88 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #89 reg = STK04  key 49, rIdx = 123, size 1
  -- #90 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #91 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #92 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #93 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #94 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #95 reg = STK05  key 50, rIdx = 122, size 1
  -- #96 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #97 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #98 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #99 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #100 reg = STK06  key 51, rIdx = 121, size 1
  -- #101 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #102 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #103 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #104 reg = STK07  key 52, rIdx = 120, size 1
  -- #105 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #106 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #107 reg = STK08  key 53, rIdx = 119, size 1
  -- #108 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #109 reg = STK09  key 55, rIdx = 118, size 1
  -- #110 reg = INDF  key 56, rIdx = 0, size 1
  -- #111 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x73 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x74 (004F6C52).
  2378 - 
  2394 - 
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
freeReg
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l194:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l194:s2:k1:d0:s0)		proc _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l194:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}[r0x73 ] = recv _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l194:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}[r0x74 ] = recv _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l195:s5:k4:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l195:s6:k5:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l195:s7:k6:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_intensidad_1_1}[r0x73 ]{argreg = 1}
libRGB.c(l195:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Blue_velocidad_1_1}[r0x74 ]{argreg = 1}
libRGB.c(l195:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l195:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l195:s11:k10:d0:s0)		eproc _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l195:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l195:s11:k10:d0:s0)		eproc _Blue [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x73
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l199:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l199:s2:k1:d0:s0)		proc _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l199:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1} = recv _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l199:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1} = recv _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l200:s5:k4:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}{argreg = 1}
libRGB.c(l200:s6:k5:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l200:s7:k6:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l200:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}{argreg = 1}
libRGB.c(l200:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l200:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l200:s11:k10:d0:s0)		eproc _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
packRegisters
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = r0x70  key 31, rIdx = 112, size 1
  -- #30 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #31 reg = r0x26  key 32, rIdx = 38, size 1
  -- #32 reg = r0x35  key 32, rIdx = 53, size 1
  -- #33 reg = r0x44  key 32, rIdx = 68, size 1
  -- #34 reg = r0x53  key 32, rIdx = 83, size 1
  -- #35 reg = r0x62  key 32, rIdx = 98, size 1
  -- #36 reg = r0x71  key 32, rIdx = 113, size 1
  -- #37 reg = r0x27  key 33, rIdx = 39, size 1
  -- #38 reg = r0x36  key 33, rIdx = 54, size 1
  -- #39 reg = r0x45  key 33, rIdx = 69, size 1
  -- #40 reg = r0x54  key 33, rIdx = 84, size 1
  -- #41 reg = r0x63  key 33, rIdx = 99, size 1
  -- #42 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #43 reg = r0x72  key 33, rIdx = 114, size 1
  -- #44 reg = r0x28  key 34, rIdx = 40, size 1
  -- #45 reg = r0x37  key 34, rIdx = 55, size 1
  -- #46 reg = r0x46  key 34, rIdx = 70, size 1
  -- #47 reg = r0x55  key 34, rIdx = 85, size 1
  -- #48 reg = r0x64  key 34, rIdx = 100, size 1
  -- #49 reg = r0x73  key 34, rIdx = 115, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #57 reg = r0x39  key 36, rIdx = 57, size 1
  -- #58 reg = r0x48  key 36, rIdx = 72, size 1
  -- #59 reg = r0x57  key 36, rIdx = 87, size 1
  -- #60 reg = r0x66  key 36, rIdx = 102, size 1
  -- #61 reg = r0x49  key 37, rIdx = 73, size 1
  -- #62 reg = r0x58  key 37, rIdx = 88, size 1
  -- #63 reg = r0x67  key 37, rIdx = 103, size 1
  -- #64 reg = r0x59  key 38, rIdx = 89, size 1
  -- #65 reg = r0x68  key 38, rIdx = 104, size 1
  -- #66 reg = r0x69  key 39, rIdx = 105, size 1
  -- #67 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #68 reg = STK00  key 45, rIdx = 127, size 1
  -- #69 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #70 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #71 reg = STK01  key 46, rIdx = 126, size 1
  -- #72 reg = STK10  key 46, rIdx = 117, size 1
  -- #73 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #74 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #75 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #76 reg = STK02  key 47, rIdx = 125, size 1
  -- #77 reg = STK11  key 47, rIdx = 116, size 1
  -- #78 reg = INTCON  key 47, rIdx = 11, size 1
  -- #79 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #80 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #81 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #82 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #83 reg = STK03  key 48, rIdx = 124, size 1
  -- #84 reg = STK12  key 48, rIdx = 115, size 1
  -- #85 reg = PCL  key 48, rIdx = 2, size 1
  -- #86 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #87 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #88 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #89 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #90 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #91 reg = STK04  key 49, rIdx = 123, size 1
  -- #92 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #93 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #94 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #95 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #96 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #97 reg = STK05  key 50, rIdx = 122, size 1
  -- #98 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #99 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #100 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #101 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #102 reg = STK06  key 51, rIdx = 121, size 1
  -- #103 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #104 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #105 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #106 reg = STK07  key 52, rIdx = 120, size 1
  -- #107 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #108 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #109 reg = STK08  key 53, rIdx = 119, size 1
  -- #110 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #111 reg = STK09  key 55, rIdx = 118, size 1
  -- #112 reg = INDF  key 56, rIdx = 0, size 1
  -- #113 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x75 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x76 (004F6C52).
  2378 - 
  2394 - 
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
freeReg
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l199:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l199:s2:k1:d0:s0)		proc _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l199:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}[r0x75 ] = recv _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l199:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}[r0x76 ] = recv _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l200:s5:k4:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_intensidad_1_1}[r0x75 ]{argreg = 1}
libRGB.c(l200:s6:k5:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l200:s7:k6:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l200:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Red_velocidad_1_1}[r0x76 ]{argreg = 1}
libRGB.c(l200:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l200:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l200:s11:k10:d0:s0)		eproc _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l200:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l200:s11:k10:d0:s0)		eproc _Red [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x75
Found a Dynamic Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l204:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l204:s2:k1:d0:s0)		proc _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l204:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1} = recv _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l204:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1} = recv _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l205:s5:k4:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l205:s6:k5:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}{argreg = 1}
libRGB.c(l205:s7:k6:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l205:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}{argreg = 1}
libRGB.c(l205:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l205:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l205:s11:k10:d0:s0)		eproc _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
packRegisters
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
  right:
    used on left
  3947 - pointer reg req = 0
  left:iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = r0x70  key 31, rIdx = 112, size 1
  -- #30 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #31 reg = r0x26  key 32, rIdx = 38, size 1
  -- #32 reg = r0x35  key 32, rIdx = 53, size 1
  -- #33 reg = r0x44  key 32, rIdx = 68, size 1
  -- #34 reg = r0x53  key 32, rIdx = 83, size 1
  -- #35 reg = r0x62  key 32, rIdx = 98, size 1
  -- #36 reg = r0x71  key 32, rIdx = 113, size 1
  -- #37 reg = r0x27  key 33, rIdx = 39, size 1
  -- #38 reg = r0x36  key 33, rIdx = 54, size 1
  -- #39 reg = r0x45  key 33, rIdx = 69, size 1
  -- #40 reg = r0x54  key 33, rIdx = 84, size 1
  -- #41 reg = r0x63  key 33, rIdx = 99, size 1
  -- #42 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #43 reg = r0x72  key 33, rIdx = 114, size 1
  -- #44 reg = r0x28  key 34, rIdx = 40, size 1
  -- #45 reg = r0x37  key 34, rIdx = 55, size 1
  -- #46 reg = r0x46  key 34, rIdx = 70, size 1
  -- #47 reg = r0x55  key 34, rIdx = 85, size 1
  -- #48 reg = r0x64  key 34, rIdx = 100, size 1
  -- #49 reg = r0x73  key 34, rIdx = 115, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #57 reg = r0x39  key 36, rIdx = 57, size 1
  -- #58 reg = r0x48  key 36, rIdx = 72, size 1
  -- #59 reg = r0x57  key 36, rIdx = 87, size 1
  -- #60 reg = r0x66  key 36, rIdx = 102, size 1
  -- #61 reg = r0x75  key 36, rIdx = 117, size 1
  -- #62 reg = r0x49  key 37, rIdx = 73, size 1
  -- #63 reg = r0x58  key 37, rIdx = 88, size 1
  -- #64 reg = r0x67  key 37, rIdx = 103, size 1
  -- #65 reg = r0x76  key 37, rIdx = 118, size 1
  -- #66 reg = r0x59  key 38, rIdx = 89, size 1
  -- #67 reg = r0x68  key 38, rIdx = 104, size 1
  -- #68 reg = r0x69  key 39, rIdx = 105, size 1
  -- #69 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #70 reg = STK00  key 45, rIdx = 127, size 1
  -- #71 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #72 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #73 reg = STK01  key 46, rIdx = 126, size 1
  -- #74 reg = STK10  key 46, rIdx = 117, size 1
  -- #75 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #76 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #77 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #78 reg = STK02  key 47, rIdx = 125, size 1
  -- #79 reg = STK11  key 47, rIdx = 116, size 1
  -- #80 reg = INTCON  key 47, rIdx = 11, size 1
  -- #81 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #82 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #83 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #84 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #85 reg = STK03  key 48, rIdx = 124, size 1
  -- #86 reg = STK12  key 48, rIdx = 115, size 1
  -- #87 reg = PCL  key 48, rIdx = 2, size 1
  -- #88 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #89 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #90 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #91 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #92 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #93 reg = STK04  key 49, rIdx = 123, size 1
  -- #94 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #95 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #96 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #97 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #98 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #99 reg = STK05  key 50, rIdx = 122, size 1
  -- #100 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #101 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #102 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #103 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #104 reg = STK06  key 51, rIdx = 121, size 1
  -- #105 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #106 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #107 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #108 reg = STK07  key 52, rIdx = 120, size 1
  -- #109 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #110 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #111 reg = STK08  key 53, rIdx = 119, size 1
  -- #112 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #113 reg = STK09  key 55, rIdx = 118, size 1
  -- #114 reg = INDF  key 56, rIdx = 0, size 1
  -- #115 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x77 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 30 bSize = 4
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x78 (004F6C52).
  2378 - 
  2394 - 
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
freeReg
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 9
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) }

local defines bitVector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

----------------------------------------------------------------
libRGB.c(l204:s1:k0:d0:s0)	 _entry($2) :
libRGB.c(l204:s2:k1:d0:s0)		proc _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l204:s3:k2:d0:s0)	iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}[r0x77 ] = recv _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l204:s4:k3:d0:s0)	iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}[r0x78 ] = recv _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l205:s5:k4:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l205:s6:k5:d0:s0)		send iTemp0 [k2 lr3:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_intensidad_1_1}[r0x77 ]{argreg = 1}
libRGB.c(l205:s7:k6:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l205:s8:k7:d0:s0)		send iTemp1 [k4 lr4:8 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Green_velocidad_1_1}[r0x78 ]{argreg = 1}
libRGB.c(l205:s9:k8:d0:s0)		iTemp2 [k7 lr9:9 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k6 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l205:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l205:s11:k10:d0:s0)		eproc _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 10 , last iCode = 11
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 11 bSize = 2
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

outDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { (2) (3) (8) }

usesDefs Set bitvector :bitvector Size = 11 bSize = 2
Bits on { }

----------------------------------------------------------------
libRGB.c(l205:s10:k9:d0:s0)	 _return($1) :
libRGB.c(l205:s11:k10:d0:s0)		eproc _Green [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x77
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
leaving
<><><><><><><><><><><><><><><><><>
<><><><><><><><><><><><><><><><><>
starting	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/src/pic/ralloc.c:pic14_assignRegisters
ebbs before optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

----------------------------------------------------------------
libRGB.c(l213:s1:k0:d0:s0)	 _entry($13) :
libRGB.c(l213:s2:k1:d0:s0)		proc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s3:k2:d0:s0)	iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1} = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s4:k3:d0:s0)	iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1} = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s5:k4:d0:s0)	iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1} = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s6:k5:d0:s0)	iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1} = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l215:s7:k6:d0:s0)		if iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1} != 0 goto _iffalse_6($10)

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 8 , last iCode = 22
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (11) (14) (17) (22) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (11) (14) (17) (22) }

----------------------------------------------------------------
libRGB.c(l216:s8:k9:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s9:k10:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s10:k11:d0:s0)		iTemp4 [k11 lr10:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l217:s11:k12:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s12:k13:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s13:k14:d0:s0)		iTemp5 [k12 lr13:13 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l218:s14:k15:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s15:k16:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s16:k17:d0:s0)		iTemp6 [k13 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l219:s17:k18:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s18:k19:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s19:k20:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s20:k21:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s21:k22:d0:s0)		iTemp7 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l219:s22:k23:d0:s0)		 goto _return($12)

----------------------------------------------------------------
Basic Block _iffalse_6 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 23 , last iCode = 43
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (43) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (27) (30) (33) (36) (39) (42) (43) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (27) (30) (33) (36) (39) (42) (43) }

----------------------------------------------------------------
libRGB.c(l219:s23:k24:d0:s0)	 _iffalse_6($10) :
libRGB.c(l222:s24:k25:d0:s0)		send 0x3 {literal-unsigned-char}{argreg = 1}
libRGB.c(l222:s25:k26:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}{argreg = 1}
libRGB.c(l222:s26:k27:d0:s0)		iTemp8 [k16 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l223:s27:k28:d0:s0)		send 0x4 {literal-unsigned-char}{argreg = 1}
libRGB.c(l223:s28:k29:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}{argreg = 1}
libRGB.c(l223:s29:k30:d0:s0)		iTemp9 [k17 lr29:29 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l224:s30:k31:d0:s0)		send 0x8 {literal-unsigned-char}{argreg = 1}
libRGB.c(l224:s31:k32:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}{argreg = 1}
libRGB.c(l224:s32:k33:d0:s0)		iTemp10 [k18 lr32:32 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l225:s33:k34:d0:s0)		send 0x9 {literal-unsigned-char}{argreg = 1}
libRGB.c(l225:s34:k35:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}{argreg = 1}
libRGB.c(l225:s35:k36:d0:s0)		iTemp11 [k19 lr35:35 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l226:s36:k37:d0:s0)		send 0xd {literal-unsigned-char}{argreg = 1}
libRGB.c(l226:s37:k38:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}{argreg = 1}
libRGB.c(l226:s38:k39:d0:s0)		iTemp12 [k20 lr38:38 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l227:s39:k40:d0:s0)		send 0xe {literal-unsigned-char}{argreg = 1}
libRGB.c(l227:s40:k41:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}{argreg = 1}
libRGB.c(l227:s41:k42:d0:s0)		iTemp13 [k21 lr41:41 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l229:s42:k43:d0:s0)		iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1} == 0x1 {literal-unsigned-char}
libRGB.c(l229:s43:k44:d0:s0)		if iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_5($7)

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 44 , last iCode = 50
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (49) (52) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (49) (52) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (49) (52) }

----------------------------------------------------------------
libRGB.c(l230:s44:k47:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l230:s45:k48:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}{argreg = 1}
libRGB.c(l230:s46:k49:d0:s0)		iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s47:k50:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s48:k51:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s49:k52:d0:s0)		iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s50:k53:d0:s0)		 goto _return($12)

----------------------------------------------------------------
Basic Block _iffalse_5 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 51 , last iCode = 53
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (55) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (55) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (55) }

----------------------------------------------------------------
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1} == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 54 , last iCode = 60
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (61) (64) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (61) (64) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (61) (64) }

----------------------------------------------------------------
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)

----------------------------------------------------------------
Basic Block _iffalse_4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 61 , last iCode = 63
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (67) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (67) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (67) }

----------------------------------------------------------------
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1} == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 64 , last iCode = 69
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (73) (76) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) (73) (76) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (73) (76) }

----------------------------------------------------------------
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 70 , last iCode = 71
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) (27) (30) (33) (36) (39) (42) (43) (49) (52) (55) (61) (64) (67) (73) (76) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) (27) (30) (33) (36) (39) (42) (43) (49) (52) (55) (61) (64) (67) (73) (76) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { }

----------------------------------------------------------------
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
packRegisters
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
    used on left
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
  hey we can remove this unnecessary assign
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
  hey we can remove this unnecessary assign
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}
          Symbol type: unsigned-char
  3947 - pointer reg req = 0
packForReceive
  result:iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
  right:
  hey we can remove this unnecessary assign
  left:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp4 [k11 lr10:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp5 [k12 lr13:13 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp6 [k13 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_RGB [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
  result:iTemp7 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp8 [k16 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp9 [k17 lr29:29 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp10 [k18 lr32:32 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp11 [k19 lr35:35 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp12 [k20 lr38:38 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp13 [k21 lr41:41 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  left:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
        Symbol type: unsigned-char
  result:iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
        Symbol type: unsigned-char
  result:iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}
        Symbol type: unsigned-char
  result:iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
          Symbol type: char
  3947 - pointer reg req = 0
  3964
  left:iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char}
        Symbol type: char
  3947 - pointer reg req = 0
packRegisters
  3947 - pointer reg req = 0
  left:iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}
        Symbol type: unsigned-char
  3947 - pointer reg req = 0
  left:_Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  3947 - pointer reg req = 0
  left:_Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char) 
  result:iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void}
          Symbol type: void
  3947 - pointer reg req = 0
packRegisters
  left:_Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
        Symbol type: void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) 
dir registers allocated so far:
  -- #0 reg = _SSPSTAT  key 4, rIdx = 0, size 1
  -- #1 reg = STATUS  key 9, rIdx = 3, size 1
  -- #2 reg = _TRISC  key 9, rIdx = 135, size 1
  -- #3 reg = _SSPADD  key 9, rIdx = 147, size 1
  -- #4 reg = _SSPCON2  key 23, rIdx = 145, size 1
  -- #5 reg = _PIR1  key 25, rIdx = 12, size 1
  -- #6 reg = r0x20  key 26, rIdx = 32, size 1
  -- #7 reg = r0x21  key 27, rIdx = 33, size 1
  -- #8 reg = r0x30  key 27, rIdx = 48, size 1
  -- #9 reg = r0x22  key 28, rIdx = 34, size 1
  -- #10 reg = r0x31  key 28, rIdx = 49, size 1
  -- #11 reg = r0x40  key 28, rIdx = 64, size 1
  -- #12 reg = PSAVE  key 29, rIdx = 32764, size 1
  -- #13 reg = r0x23  key 29, rIdx = 35, size 1
  -- #14 reg = r0x32  key 29, rIdx = 50, size 1
  -- #15 reg = r0x41  key 29, rIdx = 65, size 1
  -- #16 reg = r0x50  key 29, rIdx = 80, size 1
  -- #17 reg = r0x24  key 30, rIdx = 36, size 1
  -- #18 reg = r0x33  key 30, rIdx = 51, size 1
  -- #19 reg = r0x42  key 30, rIdx = 66, size 1
  -- #20 reg = r0x51  key 30, rIdx = 81, size 1
  -- #21 reg = r0x60  key 30, rIdx = 96, size 1
  -- #22 reg = _SSPBUF  key 30, rIdx = 1, size 1
  -- #23 reg = PCLATH  key 31, rIdx = 10, size 1
  -- #24 reg = r0x25  key 31, rIdx = 37, size 1
  -- #25 reg = r0x34  key 31, rIdx = 52, size 1
  -- #26 reg = r0x43  key 31, rIdx = 67, size 1
  -- #27 reg = r0x52  key 31, rIdx = 82, size 1
  -- #28 reg = r0x61  key 31, rIdx = 97, size 1
  -- #29 reg = r0x70  key 31, rIdx = 112, size 1
  -- #30 reg = SSAVE  key 32, rIdx = 32765, size 1
  -- #31 reg = r0x26  key 32, rIdx = 38, size 1
  -- #32 reg = r0x35  key 32, rIdx = 53, size 1
  -- #33 reg = r0x44  key 32, rIdx = 68, size 1
  -- #34 reg = r0x53  key 32, rIdx = 83, size 1
  -- #35 reg = r0x62  key 32, rIdx = 98, size 1
  -- #36 reg = r0x71  key 32, rIdx = 113, size 1
  -- #37 reg = r0x27  key 33, rIdx = 39, size 1
  -- #38 reg = r0x36  key 33, rIdx = 54, size 1
  -- #39 reg = r0x45  key 33, rIdx = 69, size 1
  -- #40 reg = r0x54  key 33, rIdx = 84, size 1
  -- #41 reg = r0x63  key 33, rIdx = 99, size 1
  -- #42 reg = _SSPCON  key 33, rIdx = 2, size 1
  -- #43 reg = r0x72  key 33, rIdx = 114, size 1
  -- #44 reg = r0x28  key 34, rIdx = 40, size 1
  -- #45 reg = r0x37  key 34, rIdx = 55, size 1
  -- #46 reg = r0x46  key 34, rIdx = 70, size 1
  -- #47 reg = r0x55  key 34, rIdx = 85, size 1
  -- #48 reg = r0x64  key 34, rIdx = 100, size 1
  -- #49 reg = r0x73  key 34, rIdx = 115, size 1
  -- #50 reg = r0x29  key 35, rIdx = 41, size 1
  -- #51 reg = r0x38  key 35, rIdx = 56, size 1
  -- #52 reg = r0x47  key 35, rIdx = 71, size 1
  -- #53 reg = r0x56  key 35, rIdx = 86, size 1
  -- #54 reg = r0x65  key 35, rIdx = 101, size 1
  -- #55 reg = r0x74  key 35, rIdx = 116, size 1
  -- #56 reg = WSAVE  key 36, rIdx = 32766, size 1
  -- #57 reg = r0x39  key 36, rIdx = 57, size 1
  -- #58 reg = r0x48  key 36, rIdx = 72, size 1
  -- #59 reg = r0x57  key 36, rIdx = 87, size 1
  -- #60 reg = r0x66  key 36, rIdx = 102, size 1
  -- #61 reg = r0x75  key 36, rIdx = 117, size 1
  -- #62 reg = r0x49  key 37, rIdx = 73, size 1
  -- #63 reg = r0x58  key 37, rIdx = 88, size 1
  -- #64 reg = r0x67  key 37, rIdx = 103, size 1
  -- #65 reg = r0x76  key 37, rIdx = 118, size 1
  -- #66 reg = r0x59  key 38, rIdx = 89, size 1
  -- #67 reg = r0x68  key 38, rIdx = 104, size 1
  -- #68 reg = r0x77  key 38, rIdx = 119, size 1
  -- #69 reg = r0x69  key 39, rIdx = 105, size 1
  -- #70 reg = r0x78  key 39, rIdx = 120, size 1
  -- #71 reg = r0x2A  key 44, rIdx = 42, size 1
  -- #72 reg = STK00  key 45, rIdx = 127, size 1
  -- #73 reg = r0x2B  key 45, rIdx = 43, size 1
  -- #74 reg = r0x3A  key 45, rIdx = 58, size 1
  -- #75 reg = STK01  key 46, rIdx = 126, size 1
  -- #76 reg = STK10  key 46, rIdx = 117, size 1
  -- #77 reg = r0x2C  key 46, rIdx = 44, size 1
  -- #78 reg = r0x3B  key 46, rIdx = 59, size 1
  -- #79 reg = r0x4A  key 46, rIdx = 74, size 1
  -- #80 reg = STK02  key 47, rIdx = 125, size 1
  -- #81 reg = STK11  key 47, rIdx = 116, size 1
  -- #82 reg = INTCON  key 47, rIdx = 11, size 1
  -- #83 reg = r0x2D  key 47, rIdx = 45, size 1
  -- #84 reg = r0x3C  key 47, rIdx = 60, size 1
  -- #85 reg = r0x4B  key 47, rIdx = 75, size 1
  -- #86 reg = r0x5A  key 47, rIdx = 90, size 1
  -- #87 reg = STK03  key 48, rIdx = 124, size 1
  -- #88 reg = STK12  key 48, rIdx = 115, size 1
  -- #89 reg = PCL  key 48, rIdx = 2, size 1
  -- #90 reg = r0x2E  key 48, rIdx = 46, size 1
  -- #91 reg = r0x3D  key 48, rIdx = 61, size 1
  -- #92 reg = r0x4C  key 48, rIdx = 76, size 1
  -- #93 reg = r0x5B  key 48, rIdx = 91, size 1
  -- #94 reg = r0x6A  key 48, rIdx = 106, size 1
  -- #95 reg = STK04  key 49, rIdx = 123, size 1
  -- #96 reg = r0x2F  key 49, rIdx = 47, size 1
  -- #97 reg = r0x3E  key 49, rIdx = 62, size 1
  -- #98 reg = r0x4D  key 49, rIdx = 77, size 1
  -- #99 reg = r0x5C  key 49, rIdx = 92, size 1
  -- #100 reg = r0x6B  key 49, rIdx = 107, size 1
  -- #101 reg = STK05  key 50, rIdx = 122, size 1
  -- #102 reg = r0x3F  key 50, rIdx = 63, size 1
  -- #103 reg = r0x4E  key 50, rIdx = 78, size 1
  -- #104 reg = r0x5D  key 50, rIdx = 93, size 1
  -- #105 reg = r0x6C  key 50, rIdx = 108, size 1
  -- #106 reg = STK06  key 51, rIdx = 121, size 1
  -- #107 reg = r0x4F  key 51, rIdx = 79, size 1
  -- #108 reg = r0x5E  key 51, rIdx = 94, size 1
  -- #109 reg = r0x6D  key 51, rIdx = 109, size 1
  -- #110 reg = STK07  key 52, rIdx = 120, size 1
  -- #111 reg = r0x5F  key 52, rIdx = 95, size 1
  -- #112 reg = r0x6E  key 52, rIdx = 110, size 1
  -- #113 reg = STK08  key 53, rIdx = 119, size 1
  -- #114 reg = r0x6F  key 53, rIdx = 111, size 1
  -- #115 reg = STK09  key 55, rIdx = 118, size 1
  -- #116 reg = INDF  key 56, rIdx = 0, size 1
  -- #117 reg = FSR  key 60, rIdx = 4, size 1
regTypeNum
  2697 - iTemp0
  2707 - itemp register
  reg name iTemp0,  reg type REG_GPR
  2697 - iTemp1
  2707 - itemp register
  reg name iTemp1,  reg type REG_GPR
  2697 - iTemp2
  2707 - itemp register
  reg name iTemp2,  reg type REG_GPR
  2697 - iTemp3
  2707 - itemp register
  reg name iTemp3,  reg type REG_GPR
  2697 - iTemp4
  2697 - iTemp5
  2697 - iTemp6
  2697 - iTemp7
  2697 - iTemp8
  2697 - iTemp9
  2697 - iTemp10
  2697 - iTemp11
  2697 - iTemp12
  2697 - iTemp13
  2697 - iTemp14
  2707 - itemp register
  2697 - iTemp15
  2697 - iTemp16
  2697 - iTemp17
  2707 - itemp register
  2697 - iTemp18
  2697 - iTemp19
  2697 - iTemp20
  2707 - itemp register
  2697 - iTemp21
  2697 - iTemp22
serialRegAssign
  op: LABEL
deassignLRs
  op: unknown op 9 	
deassignLRs
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 33 bSize = 5
Bits on { (2) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x79 (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 83 bSize = 11
Bits on { (2) (4) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7A (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 83 bSize = 11
Bits on { (2) (4) (6) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7B (004F6C52).
  2378 - 
  2394 - 
  op: RECEIVE
deassignLRs
willCauseSpill
computeSpillable
When I get clever, I'll optimize the receive logic
  2363 - 
bitvector Size = 83 bSize = 11
Bits on { (2) (4) (6) (8) }
getRegGpr
allocReg of type REG_GPR
newReg: Created register r0x7C (004F6C52).
  2378 - 
  2394 - 
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: GOTO
deassignLRs
  op: LABEL
deassignLRs
  op: EQ_OP
deassignLRs
  op: IFX
deassignLRs
freeReg
  op: SEND
deassignLRs
  op: SEND
deassignLRs
freeReg
  op: CALL
deassignLRs
  op: SEND
deassignLRs
  op: SEND
deassignLRs
  op: CALL
deassignLRs
  op: LABEL
deassignLRs
  op: ENDFUNCTION
deassignLRs
createRegMask
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
regsUsedIniCode
rUmaskForOp
rUmaskForOp
ebbs after optimizing:

----------------------------------------------------------------
Basic Block _entry : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 1 : bbnum = 0 1st iCode = 1 , last iCode = 7
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :
outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

----------------------------------------------------------------
libRGB.c(l213:s1:k0:d0:s0)	 _entry($13) :
libRGB.c(l213:s2:k1:d0:s0)		proc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s3:k2:d0:s0)	iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s4:k3:d0:s0)	iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ] = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s5:k4:d0:s0)	iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ] = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l213:s6:k5:d0:s0)	iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ] = recv _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l215:s7:k6:d0:s0)		if iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] != 0 goto _iffalse_6($10)
libRGB.c(l216:s8:k9:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s9:k10:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s10:k11:d0:s0)		iTemp4 [k11 lr10:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l217:s11:k12:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s12:k13:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s13:k14:d0:s0)		iTemp5 [k12 lr13:13 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l218:s14:k15:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s15:k16:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s16:k17:d0:s0)		iTemp6 [k13 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l219:s17:k18:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s18:k19:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s19:k20:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s20:k21:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s21:k22:d0:s0)		iTemp7 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l219:s22:k23:d0:s0)		 goto _return($12)
libRGB.c(l219:s23:k24:d0:s0)	 _iffalse_6($10) :
libRGB.c(l222:s24:k25:d0:s0)		send 0x3 {literal-unsigned-char}{argreg = 1}
libRGB.c(l222:s25:k26:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l222:s26:k27:d0:s0)		iTemp8 [k16 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l223:s27:k28:d0:s0)		send 0x4 {literal-unsigned-char}{argreg = 1}
libRGB.c(l223:s28:k29:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l223:s29:k30:d0:s0)		iTemp9 [k17 lr29:29 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l224:s30:k31:d0:s0)		send 0x8 {literal-unsigned-char}{argreg = 1}
libRGB.c(l224:s31:k32:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l224:s32:k33:d0:s0)		iTemp10 [k18 lr32:32 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l225:s33:k34:d0:s0)		send 0x9 {literal-unsigned-char}{argreg = 1}
libRGB.c(l225:s34:k35:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l225:s35:k36:d0:s0)		iTemp11 [k19 lr35:35 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l226:s36:k37:d0:s0)		send 0xd {literal-unsigned-char}{argreg = 1}
libRGB.c(l226:s37:k38:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l226:s38:k39:d0:s0)		iTemp12 [k20 lr38:38 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l227:s39:k40:d0:s0)		send 0xe {literal-unsigned-char}{argreg = 1}
libRGB.c(l227:s40:k41:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l227:s41:k42:d0:s0)		iTemp13 [k21 lr41:41 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l229:s42:k43:d0:s0)		iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x1 {literal-unsigned-char}
libRGB.c(l229:s43:k44:d0:s0)		if iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_5($7)
libRGB.c(l230:s44:k47:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l230:s45:k48:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l230:s46:k49:d0:s0)		iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s47:k50:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s48:k51:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s49:k52:d0:s0)		iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s50:k53:d0:s0)		 goto _return($12)
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock0 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 2 : bbnum = 1 1st iCode = 8 , last iCode = 22
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (11) (14) (17) (22) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (11) (14) (17) (22) }

----------------------------------------------------------------
libRGB.c(l216:s8:k9:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s9:k10:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l216:s10:k11:d0:s0)		iTemp4 [k11 lr10:10 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l217:s11:k12:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s12:k13:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l217:s13:k14:d0:s0)		iTemp5 [k12 lr13:13 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l218:s14:k15:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s15:k16:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l218:s16:k17:d0:s0)		iTemp6 [k13 lr16:16 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l219:s17:k18:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s18:k19:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s19:k20:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s20:k21:d0:s0)		send 0x0 {literal-unsigned-char}{argreg = 1}
libRGB.c(l219:s21:k22:d0:s0)		iTemp7 [k15 lr21:21 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _RGB [k14 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
libRGB.c(l219:s22:k23:d0:s0)		 goto _return($12)
libRGB.c(l219:s23:k24:d0:s0)	 _iffalse_6($10) :
libRGB.c(l222:s24:k25:d0:s0)		send 0x3 {literal-unsigned-char}{argreg = 1}
libRGB.c(l222:s25:k26:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l222:s26:k27:d0:s0)		iTemp8 [k16 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l223:s27:k28:d0:s0)		send 0x4 {literal-unsigned-char}{argreg = 1}
libRGB.c(l223:s28:k29:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l223:s29:k30:d0:s0)		iTemp9 [k17 lr29:29 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l224:s30:k31:d0:s0)		send 0x8 {literal-unsigned-char}{argreg = 1}
libRGB.c(l224:s31:k32:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l224:s32:k33:d0:s0)		iTemp10 [k18 lr32:32 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l225:s33:k34:d0:s0)		send 0x9 {literal-unsigned-char}{argreg = 1}
libRGB.c(l225:s34:k35:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l225:s35:k36:d0:s0)		iTemp11 [k19 lr35:35 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l226:s36:k37:d0:s0)		send 0xd {literal-unsigned-char}{argreg = 1}
libRGB.c(l226:s37:k38:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l226:s38:k39:d0:s0)		iTemp12 [k20 lr38:38 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l227:s39:k40:d0:s0)		send 0xe {literal-unsigned-char}{argreg = 1}
libRGB.c(l227:s40:k41:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l227:s41:k42:d0:s0)		iTemp13 [k21 lr41:41 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l229:s42:k43:d0:s0)		iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x1 {literal-unsigned-char}
libRGB.c(l229:s43:k44:d0:s0)		if iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_5($7)
libRGB.c(l230:s44:k47:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l230:s45:k48:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l230:s46:k49:d0:s0)		iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s47:k50:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s48:k51:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s49:k52:d0:s0)		iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s50:k53:d0:s0)		 goto _return($12)
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _iffalse_6 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 3 : bbnum = 2 1st iCode = 23 , last iCode = 43
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (43) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (27) (30) (33) (36) (39) (42) (43) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (27) (30) (33) (36) (39) (42) (43) }

----------------------------------------------------------------
libRGB.c(l219:s23:k24:d0:s0)	 _iffalse_6($10) :
libRGB.c(l222:s24:k25:d0:s0)		send 0x3 {literal-unsigned-char}{argreg = 1}
libRGB.c(l222:s25:k26:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l222:s26:k27:d0:s0)		iTemp8 [k16 lr26:26 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l223:s27:k28:d0:s0)		send 0x4 {literal-unsigned-char}{argreg = 1}
libRGB.c(l223:s28:k29:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l223:s29:k30:d0:s0)		iTemp9 [k17 lr29:29 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l224:s30:k31:d0:s0)		send 0x8 {literal-unsigned-char}{argreg = 1}
libRGB.c(l224:s31:k32:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l224:s32:k33:d0:s0)		iTemp10 [k18 lr32:32 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l225:s33:k34:d0:s0)		send 0x9 {literal-unsigned-char}{argreg = 1}
libRGB.c(l225:s34:k35:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l225:s35:k36:d0:s0)		iTemp11 [k19 lr35:35 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l226:s36:k37:d0:s0)		send 0xd {literal-unsigned-char}{argreg = 1}
libRGB.c(l226:s37:k38:d0:s0)		send iTemp2 [k6 lr5:37 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_max_1_1}[r0x7B ]{argreg = 1}
libRGB.c(l226:s38:k39:d0:s0)		iTemp12 [k20 lr38:38 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l227:s39:k40:d0:s0)		send 0xe {literal-unsigned-char}{argreg = 1}
libRGB.c(l227:s40:k41:d0:s0)		send iTemp1 [k4 lr4:40 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_min_1_1}[r0x7A ]{argreg = 1}
libRGB.c(l227:s41:k42:d0:s0)		iTemp13 [k21 lr41:41 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l229:s42:k43:d0:s0)		iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x1 {literal-unsigned-char}
libRGB.c(l229:s43:k44:d0:s0)		if iTemp14 [k22 lr42:43 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_5($7)
libRGB.c(l230:s44:k47:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l230:s45:k48:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l230:s46:k49:d0:s0)		iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s47:k50:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s48:k51:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s49:k52:d0:s0)		iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s50:k53:d0:s0)		 goto _return($12)
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock1 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 4 : bbnum = 3 1st iCode = 44 , last iCode = 50
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (49) (52) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (49) (52) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (49) (52) }

----------------------------------------------------------------
libRGB.c(l230:s44:k47:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l230:s45:k48:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l230:s46:k49:d0:s0)		iTemp15 [k24 lr46:46 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Red [k23 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s47:k50:d0:s0)		send 0x2 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s48:k51:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l231:s49:k52:d0:s0)		iTemp16 [k25 lr49:49 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l231:s50:k53:d0:s0)		 goto _return($12)
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _iffalse_5 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 5 : bbnum = 4 1st iCode = 51 , last iCode = 53
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (55) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (55) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (55) }

----------------------------------------------------------------
libRGB.c(l231:s51:k54:d0:s0)	 _iffalse_5($7) :
libRGB.c(l234:s52:k55:d0:s0)		iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x2 {literal-unsigned-char}
libRGB.c(l234:s53:k56:d0:s0)		if iTemp17 [k26 lr52:53 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _iffalse_4($4)
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock2 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 6 : bbnum = 5 1st iCode = 54 , last iCode = 60
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (61) (64) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (61) (64) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (61) (64) }

----------------------------------------------------------------
libRGB.c(l235:s54:k59:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l235:s55:k60:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l235:s56:k61:d0:s0)		iTemp18 [k28 lr56:56 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Green [k27 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s57:k62:d0:s0)		send 0x7 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s58:k63:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l236:s59:k64:d0:s0)		iTemp19 [k29 lr59:59 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l236:s60:k65:d0:s0)		 goto _return($12)
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _iffalse_4 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 7 : bbnum = 6 1st iCode = 61 , last iCode = 63
visited 0 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (67) }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (67) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (67) }

----------------------------------------------------------------
libRGB.c(l236:s61:k66:d0:s0)	 _iffalse_4($4) :
libRGB.c(l239:s62:k67:d0:s0)		iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} = iTemp0 [k2 lr3:62 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_tipo_1_1}[r0x79 ] == 0x3 {literal-unsigned-char}
libRGB.c(l239:s63:k68:d0:s0)		if iTemp20 [k30 lr62:63 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{char} == 0 goto _return($12)
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _eBBlock3 : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 8 : bbnum = 7 1st iCode = 64 , last iCode = 69
visited 0 : hasFcall = 1

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :bitvector Size = 83 bSize = 11
Bits on { (73) (76) }

pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (27) (30) (33) (36) (39) (42) (43) (55) (67) (73) (76) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (5) (73) (76) }

----------------------------------------------------------------
libRGB.c(l240:s64:k71:d0:s0)		send 0xfa {literal-unsigned-char}{argreg = 1}
libRGB.c(l240:s65:k72:d0:s0)		send iTemp3 [k8 lr6:65 so:0]{ ia0 a2p0 re1 rm0 nos0 ru0 dp0}{unsigned-char}{ sir@ _Latido_velocidad_1_1}[r0x7C ]{argreg = 1}
libRGB.c(l240:s66:k73:d0:s0)		iTemp21 [k32 lr66:66 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Blue [k31 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s67:k74:d0:s0)		send 0xc {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s68:k75:d0:s0)		send 0x1 {literal-unsigned-char}{argreg = 1}
libRGB.c(l241:s69:k76:d0:s0)		iTemp22 [k33 lr69:69 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void} = call _Write_RGB [k10 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char) }
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }

----------------------------------------------------------------
Basic Block _return : loop Depth = 0 noPath = 0 , lastinLoop = 0
depth 1st num 9 : bbnum = 8 1st iCode = 70 , last iCode = 71
visited 1 : hasFcall = 0

defines bitVector :bitvector Size = 83 bSize = 11
Bits on { }

local defines bitVector :
pointers Set bitvector :
in pointers Set bitvector :
inDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) (27) (30) (33) (36) (39) (42) (43) (49) (52) (55) (61) (64) (67) (73) (76) }

outDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { (2) (3) (4) (5) (11) (14) (17) (22) (27) (30) (33) (36) (39) (42) (43) (49) (52) (55) (61) (64) (67) (73) (76) }

usesDefs Set bitvector :bitvector Size = 83 bSize = 11
Bits on { }

----------------------------------------------------------------
libRGB.c(l241:s70:k81:d0:s0)	 _return($12) :
libRGB.c(l241:s71:k82:d0:s0)		eproc _Latido [k1 lr0:0 so:0]{ ia0 a2p0 re0 rm0 nos0 ru0 dp0}{void function    ( unsigned-char, unsigned-char, unsigned-char, unsigned-char) }
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
leaving
<><><><><><><><><><><><><><><><><>
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x78
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x76
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x74
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x72
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x79
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x6a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x2e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x2f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x2e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x38
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x38
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x43
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x54
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x55
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x54
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x55
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x59
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x59
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x43
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x39
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x2f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
Found a Processor Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x22
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x21
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x20
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x23
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x2e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x2e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x38
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x38
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x42
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7e
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7d
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4f
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4e
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4d
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x4c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x54
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x7f
Found a Stack Register!
typeRegWithIdx - requesting index = 0x55
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x54
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x55
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x58
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5a
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5b
Found a Dynamic Register!
typeRegWithIdx - requesting index = 0x5c
Found a Dynamic Register!
