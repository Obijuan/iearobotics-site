;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Thu Oct 30 09:38:38 2008
;--------------------------------------------------------
; PIC port for the 14-bit core
;--------------------------------------------------------
;	.module delay0
	list	p=16f876a
	radix dec
	include "p16f876a.inc"
;--------------------------------------------------------
; publics variables in this module
;--------------------------------------------------------
	global _timer0_configurar
	global _delay0
;--------------------------------------------------------
; extern variables in this module
;--------------------------------------------------------
	extern _EECON2
	extern _EECON1
	extern _EEADRH
	extern _EEDATH
	extern _EEADR
	extern _EEDATA
	extern _ADCON1
	extern _ADRESL
	extern _CVRCON
	extern _CMCON
	extern _SPBRG
	extern _TXSTA
	extern _SSPSTAT
	extern _SSPADD
	extern _PR2
	extern _SSPCON2
	extern _PCON
	extern _PIE2
	extern _PIE1
	extern _TRISC
	extern _TRISB
	extern _TRISA
	extern _OPTION_REG
	extern _ADCON0
	extern _ADRESH
	extern _CCP2CON
	extern _CCPR2H
	extern _CCPR2L
	extern _RCREG
	extern _TXREG
	extern _RCSTA
	extern _CCP1CON
	extern _CCPR1H
	extern _CCPR1L
	extern _SSPCON
	extern _SSPBUF
	extern _T2CON
	extern _TMR2
	extern _T1CON
	extern _TMR1H
	extern _TMR1L
	extern _PIR2
	extern _PIR1
	extern _INTCON
	extern _PCLATH
	extern _PORTC
	extern _PORTB
	extern _PORTA
	extern _FSR
	extern _STATUS
	extern _TMR0
	extern _TXSTA_bits
	extern _T2CON_bits
	extern _T1CON_bits
	extern _STATUS_bits
	extern _SSPSTAT_bits
	extern _SSPCON2_bits
	extern _SSPCON_bits
	extern _RCSTA_bits
	extern _PIR2_bits
	extern _PIR1_bits
	extern _PIE2_bits
	extern _PIE1_bits
	extern _PCON_bits
	extern _OPTION_REG_bits
	extern _INTCON_bits
	extern _EECON1_bits
	extern _CVRCON_bits
	extern _CMCON_bits
	extern _CCP2CON_bits
	extern _CCP1CON_bits
	extern _ADCON1_bits
	extern _ADCON0_bits
	extern _PCL
	extern _INDF
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; absolute symbol definitions
;--------------------------------------------------------

	extern PSAVE
	extern SSAVE
	extern WSAVE
	extern STK12
	extern STK11
	extern STK10
	extern STK09
	extern STK08
	extern STK07
	extern STK06
	extern STK05
	extern STK04
	extern STK03
	extern STK02
	extern STK01
	extern STK00
;	.area	RSEG    (DATA)
;--------------------------------------------------------
; udata
;--------------------------------------------------------
data_delay0	udata
;	.area	DSEG    (DATA)
udata_delay0_0	udata
r0x20	res	1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
;	udata_ovr
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
;	.area	BSEG    (BIT)
;--------------------------------------------------------
; code
;--------------------------------------------------------
code_delay0	code
;***
;  pBlock Stats: dbName = C
;***
;entry:  _delay0	;Function start
; 2 exit points
;has an exit
;1 compiler assigned register :
;   r0x20
;; Starting pCode block
_delay0	;Function start
; 2 exit points
;	.line	39; "delay0.c"	void delay0(unsigned char pausa)
	BANKSEL	r0x20
	MOVWF	r0x20
_00112_DS_
;	.line	43; "delay0.c"	while(pausa>0) {
	MOVLW	0x00
	IORWF	r0x20,W
	BTFSC	STATUS,2
	GOTO	_00115_DS_
;	.line	44; "delay0.c"	TMR0=TICKS10;   // Inicializar contador
	MOVLW	0x3d
	BCF	STATUS,5
	BCF	STATUS,6
	MOVWF	_TMR0
;	.line	45; "delay0.c"	T0IF=0;         // Quitar flag overflow
	BCF	_INTCON_bits,2
_00109_DS_
;	.line	48; "delay0.c"	while (!T0IF);
	BTFSS	_INTCON_bits,2
	GOTO	_00109_DS_
;	.line	51; "delay0.c"	pausa--;
	BANKSEL	r0x20
	DECF	r0x20,F
	GOTO	_00112_DS_
_00115_DS_
	RETURN	
; exit point of _delay0

;***
;  pBlock Stats: dbName = C
;***
;entry:  _timer0_configurar	;Function start
; 2 exit points
;has an exit
;; Starting pCode block
_timer0_configurar	;Function start
; 2 exit points
;	.line	31; "delay0.c"	OPTION_REG=0x87;
	MOVLW	0x87
	BSF	STATUS,5
	BCF	STATUS,6
	MOVWF	_OPTION_REG
	RETURN	
; exit point of _timer0_configurar


;	code size estimation:
;	   20+    2 =    22 instructions (   48 byte)

	end
