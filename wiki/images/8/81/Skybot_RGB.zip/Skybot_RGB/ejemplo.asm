;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Thu Oct 30 09:38:38 2008
;--------------------------------------------------------
; PIC port for the 14-bit core
;--------------------------------------------------------
;	.module ejemplo
	list	p=16f876a
	radix dec
	include "p16f876a.inc"
;--------------------------------------------------------
; publics variables in this module
;--------------------------------------------------------
	global _main
;--------------------------------------------------------
; extern variables in this module
;--------------------------------------------------------
	extern _Latido
	extern _Green
	extern _Red
	extern _Blue
	extern _RGB
	extern _RGB_init
	extern _i2c_configure
	extern _LeerLDR
	extern _Pulsador_no_esta_pulsado
	extern _Pulsador_esta_pulsado
	extern _LeerPulsador
	extern _CambiarLed
	extern _EstadoLed
	extern _Led_esta_apagado
	extern _Led_esta_encendido
	extern _ApagarLed
	extern _EncenderLed
	extern _LeerPuertoALinea4
	extern _LeerPuertoALinea3
	extern _LeerPuertoALinea2
	extern _LeerPuertoALinea1
	extern _LeerBumperDerecho
	extern _LeerBumperIzquierdo
	extern _Bumper_Der_esta_apretado
	extern _Bumper_Izq_esta_apretado
	extern _LeerSensor4
	extern _LeerSensor3
	extern _LeerSensor2
	extern _LeerSensor1
	extern _LeerInfrarrojos
	extern _SensorIR_Der_Lee_Blanco
	extern _SensorIR_Izq_Lee_Blanco
	extern _SensorIR_Der_Lee_Negro
	extern _SensorIR_Izq_Lee_Negro
	extern _Parar
	extern _Retroceder
	extern _GirarDer
	extern _GirarIzq
	extern _Avanzar
	extern _PausaTiempo
	extern _ConfigurarSkybot
	extern _delay0
	extern _timer0_configurar
	extern _EECON2
	extern _EECON1
	extern _EEADRH
	extern _EEDATH
	extern _EEADR
	extern _EEDATA
	extern _ADCON1
	extern _ADRESL
	extern _CVRCON
	extern _CMCON
	extern _SPBRG
	extern _TXSTA
	extern _SSPSTAT
	extern _SSPADD
	extern _PR2
	extern _SSPCON2
	extern _PCON
	extern _PIE2
	extern _PIE1
	extern _TRISC
	extern _TRISB
	extern _TRISA
	extern _OPTION_REG
	extern _ADCON0
	extern _ADRESH
	extern _CCP2CON
	extern _CCPR2H
	extern _CCPR2L
	extern _RCREG
	extern _TXREG
	extern _RCSTA
	extern _CCP1CON
	extern _CCPR1H
	extern _CCPR1L
	extern _SSPCON
	extern _SSPBUF
	extern _T2CON
	extern _TMR2
	extern _T1CON
	extern _TMR1H
	extern _TMR1L
	extern _PIR2
	extern _PIR1
	extern _INTCON
	extern _PCLATH
	extern _PORTC
	extern _PORTB
	extern _PORTA
	extern _FSR
	extern _STATUS
	extern _TMR0
	extern _TXSTA_bits
	extern _T2CON_bits
	extern _T1CON_bits
	extern _STATUS_bits
	extern _SSPSTAT_bits
	extern _SSPCON2_bits
	extern _SSPCON_bits
	extern _RCSTA_bits
	extern _PIR2_bits
	extern _PIR1_bits
	extern _PIE2_bits
	extern _PIE1_bits
	extern _PCON_bits
	extern _OPTION_REG_bits
	extern _INTCON_bits
	extern _EECON1_bits
	extern _CVRCON_bits
	extern _CMCON_bits
	extern _CCP2CON_bits
	extern _CCP1CON_bits
	extern _ADCON1_bits
	extern _ADCON0_bits
	extern _PCL
	extern _INDF
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; absolute symbol definitions
;--------------------------------------------------------

	global PSAVE
	global SSAVE
	global WSAVE
	global STK12
	global STK11
	global STK10
	global STK09
	global STK08
	global STK07
	global STK06
	global STK05
	global STK04
	global STK03
	global STK02
	global STK01
	global STK00
sharebank udata_ovr 0x0070
PSAVE	res 1
SSAVE	res 1
WSAVE	res 1
STK12	res 1
STK11	res 1
STK10	res 1
STK09	res 1
STK08	res 1
STK07	res 1
STK06	res 1
STK05	res 1
STK04	res 1
STK03	res 1
STK02	res 1
STK01	res 1
STK00	res 1
;	.area	RSEG    (DATA)
;--------------------------------------------------------
; udata
;--------------------------------------------------------
data_ejemplo	udata
;	.area	DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
;	udata_ovr
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
;	.area	BSEG    (BIT)
;--------------------------------------------------------
; reset vector 
;--------------------------------------------------------
STARTUP	code
	nop
	pagesel __sdcc_gsinit_startup
	goto	__sdcc_gsinit_startup
code_init	code
__sdcc_gsinit_startup
	pagesel _main
	goto _main
;--------------------------------------------------------
; code
;--------------------------------------------------------
code_ejemplo	code
;***
;  pBlock Stats: dbName = M
;***
;entry:  _main	;Function start
; 2 exit points
;has an exit
;functions called:
;   _RGB_init
;   _ConfigurarSkybot
;   _Avanzar
;   _Latido
;   _RGB_init
;   _ConfigurarSkybot
;   _Avanzar
;   _Latido
;3 compiler assigned registers:
;   STK02
;   STK01
;   STK00
;; Starting pCode block
_main	;Function start
; 2 exit points
;	.line	6; "ejemplo.c"	RGB_init();          // arranco la placa RGB
	PAGESEL	_RGB_init
	CALL	_RGB_init
	PAGESEL	$
;	.line	7; "ejemplo.c"	ConfigurarSkybot();  // configuro el SkyBot
	PAGESEL	_ConfigurarSkybot
	CALL	_ConfigurarSkybot
	PAGESEL	$
;	.line	9; "ejemplo.c"	Avanzar();           // Avanza
	PAGESEL	_Avanzar
	CALL	_Avanzar
	PAGESEL	$
;	.line	10; "ejemplo.c"	Latido(1,66,255,1);  // Late en Rojo 
	MOVLW	0x01
	MOVWF	STK02
	MOVLW	0xff
	MOVWF	STK01
	MOVLW	0x42
	MOVWF	STK00
	MOVLW	0x01
	PAGESEL	_Latido
	CALL	_Latido
	PAGESEL	$
_00106_DS_
	GOTO	_00106_DS_
	RETURN	
; exit point of _main


;	code size estimation:
;	   13+    8 =    21 instructions (   58 byte)

	end
