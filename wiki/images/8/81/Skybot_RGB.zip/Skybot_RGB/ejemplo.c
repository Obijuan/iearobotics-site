#include "libreria_skybot.h"
#include "libRGB.h"

void main() {
	
	RGB_init();          // arranco la placa RGB
	ConfigurarSkybot();  // configuro el SkyBot
	
	Avanzar();           // Avanza
	Latido(1,66,255,1);  // Late en Rojo 
	
	for (;;);
}

