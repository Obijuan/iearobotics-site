#include "libreria_skybot.h"
#include "libRGB.h"

void main() {
	
	RGB_init();          // arranco la placa RGB
	ConfigurarSkybot();  // configuro el SkyBot
	
	// Programa principal
	
	while (1) {
		if (SensorIR_Der_Lee_Negro() && SensorIR_Izq_Lee_Negro()) {
			Avanzar();
			Green(255,0);
		}
		else if (!SensorIR_Der_Lee_Negro() && !SensorIR_Izq_Lee_Negro()) {
			GirarDer();
			RGB(0,0,0,0);
		}	
		else if (!SensorIR_Der_Lee_Negro()) {
			GirarDer();
			Red(255,0);
		} else {
			GirarIzq();
			Blue(255,0);
		}
	}
}

