#!/usr/bin/env python
#-*- coding: iso-8859-15 -*-

from distutils.core import setup


files = ["pixmaps/*"]

setup(name         = 'skybot-test',
      version      = '1.0',
      description  = 'Control del robot Skybot y lectura de sus sensores',
      author       = 'Juan Gonzalez',
      author_email = 'juan@iearobotics.com',
      url          = 'http://www.iearobotics.com/wiki/index.php?title=Skybot-test',
      license      = 'GPL v3 or later',
      packages = ['skybot_test'],
      package_data = {'skybot_test' : files },
      scripts      = ['skybot-test.py',],
      )
