#include <MC68HC908GP32.h>

#define PORTD PTD

void main(void) {

  for(;;) {
    DDRD   = 0xFF;   //-- Configurar Puerto B para salida  
	PORTD  = 0x01;  //-- Enviar un dato
  } /* loop forever */
  /* please make sure that you never leave this function */
}
