/*************************************************************************** */
/* Andres Prieto-Moreno                                                      */
/* Juan gonzalez                                                             */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

#ifndef SERVOS_H
#define SERVOS_H

//-- Constantes para habilitar los servos
#define SERVO0 0x01
#define SERVO1 0x02
#define SERVO2 0x04
#define SERVO3 0x08
#define SERVO4 0x10
#define SERVO5 0x20
#define SERVO6 0x40
#define SERVO7 0x80
#define SERVOS_ALL  0xFF
#define SERVOS_NONE 0x00

void servos_init(void);void servos_set(int servo, int grados);
void servos_enable(unsigned char mascara);

#endif

