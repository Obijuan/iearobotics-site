from pyrobot.brain import Brain
from pywii.pywii import Wiimote
from pywii.wiicon import WiiconError
import sys

class WiiBrain (Brain):

	def __init__ (self, name, engine, address):
		Brain.__init__ (self, name, engine)
		self.__wiimote = Wiimote ()

		try:
			self.__wiimote.start (address)
		except WiiconError:
			print 'Error al iniciar servicio Bluetooth'
			sys.exit (-1)

	def step (self):
		events = [ev.data for ev in self.__wiimote.getEvents () if ev.type == 'Motion']
		if events:
			motion = events [-1]
			self.robot.move (motion.y, -motion.x)
	
def INIT (engine):
	wiiBrain = WiiBrain ('WiiBrain', engine, '00:19:1D:9D:E9:33')
	return wiiBrain
