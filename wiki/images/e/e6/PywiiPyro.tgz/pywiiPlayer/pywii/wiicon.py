#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: wiicon is a module to low-level comunication
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

from bluetooth import BluetoothSocket, BluetoothError, L2CAP

class WiiconError (Exception):
	pass

class Wiicon:

	def __init__ (self):
		self.__address = None
		self.__fdin = None
		self.__fdout = None
	
	def start (self, address):
		self.__address = address
		
		# Try to connect to Wiimote
		print 'Conectando a %s, presiona 1 y 2.' % self.__address
		self.__fdin = BluetoothSocket (L2CAP)
		self.__fdout = BluetoothSocket (L2CAP)
		try:
			self.__fdin.connect ((self.__address, 0x13))
			self.__fdout.connect ((self.__address, 0x11))
		except BluetoothError:
			raise WiiconError, 'Error: Unable to load bluetooth.'
		print 'Conectado a %s.' % self.__address
	
	def send (self, msg):
		self.__fdout.send (msg)
	
	def recv (self, len):
		return self.__fdin.recv (len)

	def stop (self):
		self.__fdin.close ()
		self.__fdout.close ()
