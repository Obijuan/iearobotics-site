#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: wiievent is a module for event passing
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

class Event:

	def __init__ (self, type, data):
		self.type = type
		self.data = data

class EventQueue:

	def __init__ (self):
		self.__queue = []
	
	def enqueue (self, element):
		self.__queue.append (element)
	
	def first (self):
		return self.__queue [0]

	def dequeue (self):
		if len (self.__queue) > 0:
			return self.__queue.pop (0)
		else:
			return None
	
	def dequeueAll (self):
		ret = self.__queue
		self.__queue = []
		return ret
	
	def clear (self):
		del self.__queue
		self.__queue = []
