#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: wiiutils is a miscelaneous module
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import math

class Vector:

	def __init__ (self, x, y, z):
		self.x = x
		self.y = y
		self.z = z
	
	def module (self):
		return math.sqrt (self.x * self.x + self.y * self.y + self.z * self.z)

	def __add__ (self, v):
		return Vector (self.x + v.x, self.y + v.y, self.z + v.z)

	def __sub__ (self, v):
		return Vector (self.x - v.x, self.y - v.y, self.z - v.z)

	def __div__ (self, v):
		return Vector (float (self.x) / v.x, float (self.y) / v.y, float (self.z) / v.z)

	def __str__ (self):
		return 'x: %.3f; y: %.3f; z: %.3f;' % (self.x, self.y, self.z)
