#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: wiimovsys is a module to generate movement events from low-level motion events
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# TODO: All!!!

import thread, time
from wiievent import Event, EventQueue

class MoveSystem:

	def __init__ (self):
		self.__state = 0
		self.__queue = None
		self.__events = EventQueue ()

	def __listener (self):
		print 'Servidor de movimientos listo y a la escucha.'
		while self.__state:
			events = self.__events.dequeueAll ()
			for ev in events:
				self.__queue.enqueue (ev)
			time.sleep (0.01)
		
		print 'Servidor de movimientos muriendo...'
		self.__state = -1

	def __initMoveServer (self):
		thread.start_new_thread (self.__listener, ())
	
	def getState (self):
		return self.__state
	
	def start (self, queue):
		self.__state = 1
		self.__queue = queue
		self.__initMoveServer ()

	def notify (self, ev):
		self.__events.enqueue (Event ('Move', ev.data))
	
	def stop (self):
		self.__state = 0
		while not self.__state:
			time.sleep (0.01)
		self.__events.clear ()
