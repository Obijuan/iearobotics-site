-------------------------------------------------------------------------------
-- Juan Gonzalez. Febrero 2009. 
-- Ejemplo "Hola mundo" en VHDL. Registro de 8 bits
-- Licencia GPL
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;

entity REG is
  
  port (
    D      : in  std_logic_vector(7 downto 0);   -- Entrada
    CLK    : in  std_logic;                      -- Reloj
    nRESET : in  std_logic;                      -- Reset
    Q      : out std_logic_vector(7 downto 0));  -- Salida

end REG;

architecture test of REG is

begin  
 
  -- Registro de 8 bits
  -- Reset asincrono, activo a nivel bajo
  process (CLK, nRESET)
  begin

    if nRESET = '0' then
      Q<="00000000";
    elsif rising_edge(CLK) then  
      Q<=D;
    end if;
  end process;

  
end test;


