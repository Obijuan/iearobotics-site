-------------------------------------------------------------------------------
-- Juan Gonzalez. Febrero 2009. 
-- Ejemplo "Hola mundo" en VHDL. Banco de pruebas del registro.
-- Se cargan todos los valores
-- Licencia GPL
-------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.all;
use ieee.numeric_std.all;	

entity reg_tb is
end reg_tb;

architecture test of reg_tb is

  -- Declaracion del componente que se va a utilizar en las
  -- pruebas
  component REG
    port (
    D      : in  std_logic_vector(7 downto 0);   -- Entrada
    CLK    : in  std_logic;                      -- Reloj
    nRESET : in  std_logic;                      -- Reset
    Q      : out std_logic_vector(7 downto 0));  -- Salida
  end component;

  --Senales para usar en las pruebas del registro
  signal CLK, nRESET : std_logic := '0';
  signal D, Q : std_logic_vector(7 downto 0) := "00000000";
	
  -- Senal para indicar el fin de la simulacion
  signal end_sim : boolean := false;
	
  -- CONSTANTES
  constant tdelay : time := 10 ns;
  constant tper   : time := 50 ns;      -- Periodo de reloj 

 ------------------------------------------------------------------------------
 -- DESCRIPCION DE LA PRUEBA:
 -- 1) Se coloca (instancia) el registro disenado
 -- 2) Se crea un proceso que activa las senales de entrada y comprueba las
 --    salida para ver si son correctas
 -- 3) Se crea un proceso de RELOJ que genera una onda cuadrada. Es el reloj
 --    de nuestro diseno digital.
 --
 -- Estos tres elementos: registro, reloj y pruebas son tres procesos
 -- independientes que se ejecutan EN PARALELO. 
 ------------------------------------------------------------------------------
  
begin

  -- Instanciar (colocar) el registro a probar
  uut : REG port map(CLK=>CLK, nRESET=>nRESET, D=>D, Q=>Q);
	
  -- proceso generador de reloj
  process
  begin
    while not end_sim loop
      clk <= '0';
      wait for tper/2;
      clk <= '1';
      wait for tper/2;
    end loop;
    wait;
  end process;


 ------------------------------------------------------------------------------
 -- PROCESO PRINCIPAL DE PRUEBAS
 ------------------------------------------------------------------------------
  process	 
  begin
    -- prueba del reset
    nRESET <= '0';
    wait for tdelay;
    assert Q=x"00" report "reset inicial falla" severity failure;

    -- Pruebas sistematicas. Se cargan todos los valores
    nRESET <= '1';
    for i in 0 to 255 loop

      D <= std_logic_vector(to_unsigned(i,8));
      wait until rising_edge(CLK); wait for tdelay;

      assert Q=D 
        report "El registro falla para D:" & 
          integer'image(to_integer(unsigned(D))) &
          "Deberia ser:" & integer'image(to_integer(unsigned(Q)))
          severity failure;

      -- Comprobar que el reset es asincrono
      nRESET <= '0';
      wait for tdelay;
	assert Q=x"00" 
           report "El registro falla el reset con D:" & 
              integer'image(to_integer(unsigned(D)))  
           severity failure;

      nRESET <= '1';
      wait until rising_edge(CLK); wait for tdelay;
     end loop; 
		
    ---------------------------------------------------------------------------
    -- Fin de la simulacion.
    ---------------------------------------------------------------------------
     report "Simulacion correcta" severity note;
     end_sim <= true;
     wait;	
   end process;

end test;
