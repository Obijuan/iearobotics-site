EESchema Schematic File Version 1
LIBS:power,chronopic_30
EELAYER 23  0
EELAYER END
$Descr A4 11700 8267
Sheet 1 1
Title "Chronopic"
Date "20 jan 2008"
Rev "3.0"
Comp "Project web: www.gnome.org/projects/chronojump"
Comment1 "Creative Commons Attribution-ShareAlike 2.5 Spain License"
Comment2 "Based on the SkyPic & SkyLamp boards"
Comment3 "email: ricardo@eagleman.org    web: www.iearobotics.com"
Comment4 "Ricardo Gomez Gonzalez "
$EndDescr
$Comp
L SW_PUSH SW2
U 1 1 478A8122
P 8900 3275
F 0 "SW2" H 9050 3385 50  0000 C C
F 1 "TEST" H 8900 3195 50  0000 C C
	1    8900 3275
	1    0    0    -1  
$EndComp
$Comp
L SW_PUSH SW1
U 1 1 478A810A
P 4450 3600
F 0 "SW1" H 4600 3710 50  0000 C C
F 1 "RESET" H 4450 3520 50  0000 C C
	1    4450 3600
	1    0    0    -1  
$EndComp
Connection ~ 8225 4850
Wire Wire Line
	8225 4850 8225 6100
Connection ~ 9425 2075
Wire Wire Line
	9650 2000 9650 2075
Connection ~ 9325 2500
Wire Wire Line
	9325 2500 9325 1900
Wire Wire Line
	9325 1900 9750 1900
Connection ~ 8000 5975
Wire Wire Line
	8000 5975 5025 5975
Wire Wire Line
	7900 4850 7900 3950
Wire Wire Line
	1225 4200 1075 4200
Wire Wire Line
	1075 4200 1075 4375
Wire Wire Line
	1200 2075 1200 1700
Wire Wire Line
	1200 1700 1075 1700
Wire Wire Line
	3850 1150 7475 1150
Wire Wire Line
	7475 1150 7475 4800
Wire Wire Line
	7475 4800 7225 4800
Connection ~ 5625 1950
Wire Wire Line
	5400 1950 5625 1950
Wire Wire Line
	4825 1750 5000 1750
Wire Wire Line
	4325 1750 4150 1750
Wire Wire Line
	4150 1750 4150 1550
Wire Wire Line
	4150 1550 3850 1550
Connection ~ 8075 6300
Wire Wire Line
	8400 5250 8075 5250
Wire Wire Line
	8075 5250 8075 6675
Connection ~ 8150 5150
Wire Wire Line
	8400 6400 8150 6400
Wire Wire Line
	8150 6400 8150 4675
Wire Wire Line
	8225 6100 8400 6100
Wire Wire Line
	7900 4850 8400 4850
Wire Wire Line
	8400 5050 8000 5050
Wire Wire Line
	7225 4250 7800 4250
Wire Wire Line
	7900 3950 7225 3950
Wire Wire Line
	7225 4450 8675 4450
Wire Wire Line
	9175 4450 9350 4450
Wire Wire Line
	10125 3400 10125 3275
Wire Wire Line
	10125 3275 9950 3275
Wire Wire Line
	7225 4150 8450 4150
Wire Wire Line
	9325 3275 9325 2700
Connection ~ 9325 3275
Wire Wire Line
	9325 2700 9500 2700
Wire Wire Line
	9450 3275 9200 3275
Connection ~ 6275 2950
Wire Wire Line
	6375 2950 6275 2950
Connection ~ 6275 5700
Wire Wire Line
	6275 5775 6275 5700
Connection ~ 3675 4800
Wire Wire Line
	3675 4975 3675 4550
Wire Wire Line
	3675 4550 5225 4550
Wire Wire Line
	3675 5375 3675 5525
Wire Wire Line
	4400 4800 4500 4800
Wire Wire Line
	5225 3600 4750 3600
Wire Wire Line
	4150 3600 4000 3600
Wire Wire Line
	4000 3600 4000 3750
Connection ~ 2100 1150
Wire Wire Line
	3850 1950 4325 1950
Wire Wire Line
	4825 1950 5000 1950
Connection ~ 3050 2650
Connection ~ 2950 2650
Wire Wire Line
	2950 2550 2950 2650
Wire Wire Line
	2100 2825 2100 2950
Wire Wire Line
	2250 2350 2100 2350
Wire Wire Line
	2100 2350 2100 2425
Wire Wire Line
	2250 1450 1275 1450
Wire Wire Line
	1275 1450 1275 1500
Wire Wire Line
	1275 1500 1075 1500
Wire Wire Line
	2250 1150 1925 1150
Wire Wire Line
	1075 1400 1225 1400
Wire Wire Line
	1225 1400 1225 1150
Wire Wire Line
	1225 1150 1425 1150
Wire Wire Line
	2250 1550 1325 1550
Wire Wire Line
	1325 1550 1325 1600
Wire Wire Line
	1325 1600 1075 1600
Wire Wire Line
	2850 2550 2850 2650
Wire Wire Line
	2850 2650 3250 2650
Wire Wire Line
	3250 2650 3250 2550
Wire Wire Line
	3150 2550 3150 2650
Connection ~ 3150 2650
Wire Wire Line
	3050 2925 3050 2550
Wire Wire Line
	4825 2125 5000 2125
Wire Wire Line
	3850 2050 4150 2050
Wire Wire Line
	4150 2050 4150 2125
Wire Wire Line
	4150 2125 4325 2125
Wire Wire Line
	2100 925  2100 1250
Wire Wire Line
	2100 1250 2250 1250
Connection ~ 5025 3600
Wire Wire Line
	5025 2825 5025 2950
Wire Wire Line
	3800 4800 3675 4800
Wire Wire Line
	4500 5375 4500 5525
Wire Wire Line
	5225 4650 4500 4650
Wire Wire Line
	4500 4650 4500 4975
Connection ~ 4500 4800
Wire Wire Line
	6175 5650 6175 5700
Wire Wire Line
	6175 5700 6375 5700
Wire Wire Line
	6375 5700 6375 5650
Wire Wire Line
	6275 2775 6275 3100
Wire Wire Line
	6775 2950 6875 2950
Wire Wire Line
	6875 2950 6875 3075
Wire Wire Line
	8600 3275 8350 3275
Wire Wire Line
	8450 2500 9500 2500
Connection ~ 8450 3275
Connection ~ 8450 2500
Wire Wire Line
	3850 1450 8450 1450
Wire Wire Line
	8450 1450 8450 4150
Wire Wire Line
	7825 3475 7825 3275
Wire Wire Line
	7825 3275 7950 3275
Wire Wire Line
	9750 4450 9900 4450
Wire Wire Line
	9900 4450 9900 4575
Wire Wire Line
	7225 3850 8000 3850
Wire Wire Line
	5025 5975 5025 3450
Wire Wire Line
	8400 5450 8000 5450
Wire Wire Line
	8300 5050 8300 6200
Wire Wire Line
	8300 6200 8400 6200
Connection ~ 8300 5050
Wire Wire Line
	8400 5150 8150 5150
Wire Wire Line
	8400 6300 8075 6300
Wire Wire Line
	8400 6500 8000 6500
Wire Wire Line
	8000 6500 8000 5450
Wire Wire Line
	5625 925  5625 2125
Wire Wire Line
	5625 2125 5400 2125
Wire Wire Line
	5400 1750 5500 1750
Wire Wire Line
	5500 1750 5500 2325
Wire Wire Line
	7225 4900 7425 4900
Wire Wire Line
	7425 4900 7425 1250
Wire Wire Line
	7425 1250 3850 1250
Wire Wire Line
	1075 3775 1075 3875
Wire Wire Line
	1075 3875 1225 3875
Wire Wire Line
	8000 3850 8000 5050
Wire Wire Line
	7800 4250 7800 4950
Wire Wire Line
	7800 4950 8400 4950
Wire Wire Line
	9425 2700 9425 2000
Wire Wire Line
	9425 2000 9550 2000
Connection ~ 9425 2700
Wire Wire Line
	9750 2000 9750 2075
Wire Wire Line
	9750 2075 9425 2075
Connection ~ 9650 2075
$Comp
L RCA RCA1
U 1 1 4789F649
P 9850 1900
F 0 "RCA1" H 9900 1625 60  0000 C C
F 1 "Platform 2" H 9900 2025 60  0000 C C
	1    9850 1900
	-1   0    0    -1  
$EndComp
$Comp
L FT232RL IC2
U 1 1 47810744
P 3050 1750
F 0 "IC2" H 2350 2470 50  0000 L B
F 1 "FT232RL" H 2350 950 50  0000 L B
	1    3050 1750
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR01
U 1 1 477F6CD9
P 1075 4375
F 0 "#PWR01" H 1075 4375 30  0001 C C
F 1 "GND" H 1075 4305 30  0001 C C
	1    1075 4375
	1    0    0    -1  
$EndComp
$Comp
L PWR_FLAG #FLG02
U 1 1 477F6CC4
P 1225 4200
F 0 "#FLG02" H 1225 4470 30  0001 C C
F 1 "PWR_FLAG" H 1225 4430 30  0000 C C
	1    1225 4200
	0    1    1    0   
$EndComp
$Comp
L PWR_FLAG #FLG03
U 1 1 477F6C46
P 1225 3875
F 0 "#FLG03" H 1225 4145 30  0001 C C
F 1 "PWR_FLAG" H 1225 4105 30  0000 C C
	1    1225 3875
	0    1    1    0   
$EndComp
$Comp
L VCC #PWR04
U 1 1 477F6C43
P 1075 3775
F 0 "#PWR04" H 1075 3875 30  0001 C C
F 1 "VCC" H 1075 3875 30  0000 C C
	1    1075 3775
	1    0    0    -1  
$EndComp
NoConn ~ 7225 5000
$Comp
L GND #PWR05
U 1 1 477F699A
P 5500 2325
F 0 "#PWR05" H 5500 2325 30  0001 C C
F 1 "GND" H 5500 2255 30  0001 C C
	1    5500 2325
	1    0    0    -1  
$EndComp
$Comp
L VCC #PWR06
U 1 1 477F6912
P 5625 925
F 0 "#PWR06" H 5625 1025 30  0001 C C
F 1 "VCC" H 5625 1025 30  0000 C C
	1    5625 925 
	1    0    0    -1  
$EndComp
NoConn ~ 8400 4750
NoConn ~ 8400 5650
NoConn ~ 8400 5550
NoConn ~ 8400 5350
$Comp
L GND #PWR07
U 1 1 477F66F3
P 8075 6675
F 0 "#PWR07" H 8075 6675 30  0001 C C
F 1 "GND" H 8075 6605 30  0001 C C
	1    8075 6675
	1    0    0    -1  
$EndComp
$Comp
L VCC #PWR08
U 1 1 477F66CF
P 8150 4675
F 0 "#PWR08" H 8150 4775 30  0001 C C
F 1 "VCC" H 8150 4775 30  0000 C C
	1    8150 4675
	1    0    0    -1  
$EndComp
NoConn ~ 7225 4350
$Comp
L GND #PWR09
U 1 1 477F6656
P 9900 4575
F 0 "#PWR09" H 9900 4575 30  0001 C C
F 1 "GND" H 9900 4505 30  0001 C C
	1    9900 4575
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR010
U 1 1 477F6613
P 10125 3400
F 0 "#PWR010" H 10125 3400 30  0001 C C
F 1 "GND" H 10125 3330 30  0001 C C
	1    10125 3400
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR011
U 1 1 477F6580
P 7825 3475
F 0 "#PWR011" H 7825 3475 30  0001 C C
F 1 "GND" H 7825 3405 30  0001 C C
	1    7825 3475
	1    0    0    -1  
$EndComp
NoConn ~ 7225 4550
NoConn ~ 7225 4050
NoConn ~ 7225 5100
NoConn ~ 5225 5100
NoConn ~ 5225 5000
NoConn ~ 5225 4900
NoConn ~ 5225 4800
NoConn ~ 5225 4350
NoConn ~ 5225 4250
NoConn ~ 5225 4150
NoConn ~ 5225 4050
NoConn ~ 5225 3950
NoConn ~ 5225 3850
$Comp
L GND #PWR012
U 1 1 477F637B
P 6875 3075
F 0 "#PWR012" H 6875 3075 30  0001 C C
F 1 "GND" H 6875 3005 30  0001 C C
	1    6875 3075
	1    0    0    -1  
$EndComp
$Comp
L VCC #PWR013
U 1 1 477F636E
P 6275 2775
F 0 "#PWR013" H 6275 2875 30  0001 C C
F 1 "VCC" H 6275 2875 30  0000 C C
	1    6275 2775
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR014
U 1 1 477F6354
P 6275 5775
F 0 "#PWR014" H 6275 5775 30  0001 C C
F 1 "GND" H 6275 5705 30  0001 C C
	1    6275 5775
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR015
U 1 1 477F6303
P 3675 5525
F 0 "#PWR015" H 3675 5525 30  0001 C C
F 1 "GND" H 3675 5455 30  0001 C C
	1    3675 5525
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR016
U 1 1 477F6300
P 4500 5525
F 0 "#PWR016" H 4500 5525 30  0001 C C
F 1 "GND" H 4500 5455 30  0001 C C
	1    4500 5525
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR017
U 1 1 477F626B
P 4000 3750
F 0 "#PWR017" H 4000 3750 30  0001 C C
F 1 "GND" H 4000 3680 30  0001 C C
	1    4000 3750
	1    0    0    -1  
$EndComp
$Comp
L VCC #PWR018
U 1 1 477F6264
P 5025 2825
F 0 "#PWR018" H 5025 2925 30  0001 C C
F 1 "VCC" H 5025 2925 30  0000 C C
	1    5025 2825
	1    0    0    -1  
$EndComp
$Comp
L VCC #PWR019
U 1 1 477F61FC
P 2100 925
F 0 "#PWR019" H 2100 1025 30  0001 C C
F 1 "VCC" H 2100 1025 30  0000 C C
	1    2100 925 
	1    0    0    -1  
$EndComp
NoConn ~ 3850 2350
NoConn ~ 3850 2250
NoConn ~ 3850 2150
NoConn ~ 3850 1850
NoConn ~ 3850 1750
NoConn ~ 3850 1650
NoConn ~ 3850 1350
$Comp
L GND #PWR020
U 1 1 477F6176
P 3050 2925
F 0 "#PWR020" H 3050 2925 30  0001 C C
F 1 "GND" H 3050 2855 30  0001 C C
	1    3050 2925
	1    0    0    -1  
$EndComp
NoConn ~ 2250 2150
NoConn ~ 2250 2050
NoConn ~ 2250 1950
NoConn ~ 2250 1850
NoConn ~ 2250 1750
$Comp
L C C5
U 1 1 477F5B7B
P 2100 2625
F 0 "C5" H 2150 2725 50  0000 L C
F 1 "100nF" H 2150 2525 50  0000 L C
	1    2100 2625
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR021
U 1 1 477F6146
P 2100 2950
F 0 "#PWR021" H 2100 2950 30  0001 C C
F 1 "GND" H 2100 2880 30  0001 C C
	1    2100 2950
	1    0    0    -1  
$EndComp
$Comp
L GND #PWR022
U 1 1 477F6113
P 1200 2075
F 0 "#PWR022" H 1200 2075 30  0001 C C
F 1 "GND" H 1200 2005 30  0001 C C
	1    1200 2075
	1    0    0    -1  
$EndComp
$Comp
L R CH1
U 1 1 477F6091
P 1675 1150
F 0 "CH1" V 1575 1150 50  0000 C C
F 1 "R" V 1775 1150 50  0001 C C
	1    1675 1150
	0    1    1    0   
$EndComp
$Comp
L C C3
U 1 1 477F5C4A
P 6575 2950
F 0 "C3" V 6475 2800 50  0000 L C
F 1 "100nF" V 6475 3175 50  0000 L C
	1    6575 2950
	0    1    1    0   
$EndComp
$Comp
L MOLEX-5 CP1
U 1 1 477F5C32
P 8775 6300
F 0 "CP1" H 8700 5900 60  0000 C C
F 1 "ICD2" H 8775 6725 60  0000 C C
	1    8775 6300
	1    0    0    -1  
$EndComp
$Comp
L CT CT1
U 1 1 477F5C28
P 8750 5200
F 0 "CT1" V 8700 5200 60  0000 C C
F 1 "PROG" V 8800 5200 60  0000 C C
	1    8750 5200
	1    0    0    -1  
$EndComp
$Comp
L CLEMA2P CL1
U 1 1 477F5C12
P 9700 2600
F 0 "CL1" H 9650 2850 60  0000 C C
F 1 "Platform 1" H 9700 2350 60  0000 C C
	1    9700 2600
	1    0    0    -1  
$EndComp
$Comp
L R R3
U 1 1 477F5C08
P 9700 3275
F 0 "R3" V 9600 3275 50  0000 C C
F 1 "147R" V 9800 3275 50  0000 C C
	1    9700 3275
	0    1    1    0   
$EndComp
$Comp
L CAPAPOL C4
U 1 1 477F5C00
P 8150 3275
F 0 "C4" V 8050 3425 50  0000 L C
F 1 "1uF" V 8050 3100 50  0000 L C
	1    8150 3275
	0    1    1    0   
$EndComp
$Comp
L DIODO_LED D1
U 1 1 477F5BF1
P 9550 4450
F 0 "D1" H 9550 4550 50  0000 C C
F 1 "DIODO_LED" H 9550 4350 50  0001 C C
	1    9550 4450
	1    0    0    -1  
$EndComp
$Comp
L R R2
U 1 1 477F5BE8
P 8925 4450
F 0 "R2" V 8825 4450 50  0000 C C
F 1 "330R" V 9025 4450 50  0000 C C
	1    8925 4450
	0    1    1    0   
$EndComp
$Comp
L CRYSTAL X1
U 1 1 477F5BE1
P 4100 4800
F 0 "X1" H 4100 4950 60  0000 C C
F 1 "4MHz" H 4100 4650 60  0000 C C
	1    4100 4800
	1    0    0    -1  
$EndComp
$Comp
L C C2
U 1 1 477F5BD8
P 4500 5175
F 0 "C2" H 4550 5275 50  0000 L C
F 1 "22pF" H 4550 5075 50  0000 L C
	1    4500 5175
	1    0    0    -1  
$EndComp
$Comp
L C C1
U 1 1 477F5BD1
P 3675 5175
F 0 "C1" H 3725 5275 50  0000 L C
F 1 "22pF" H 3725 5075 50  0000 L C
	1    3675 5175
	1    0    0    -1  
$EndComp
$Comp
L R R1
U 1 1 477F5BBE
P 5025 3200
F 0 "R1" V 4925 3200 50  0000 C C
F 1 "10K" V 5125 3200 50  0000 C C
	1    5025 3200
	1    0    0    -1  
$EndComp
$Comp
L PIC16F876A IC1
U 1 1 477F5BB8
P 6275 4500
F 0 "IC1" H 6475 3600 60  0000 C C
F 1 "PIC16F876A" H 6625 5700 60  0000 C C
	1    6275 4500
	-1   0    0    -1  
$EndComp
$Comp
L DIODO_LED D2
U 1 1 477F5BAE
P 5200 2125
F 0 "D2" H 5075 2175 50  0000 C C
F 1 "RX" H 5325 2175 50  0000 C C
	1    5200 2125
	-1   0    0    -1  
$EndComp
$Comp
L DIODO_LED D3
U 1 1 477F5BAB
P 5200 1950
F 0 "D3" H 5075 2000 50  0000 C C
F 1 "TX" H 5325 2000 50  0000 C C
	1    5200 1950
	-1   0    0    -1  
$EndComp
$Comp
L DIODO_LED D4
U 1 1 477F5BA6
P 5200 1750
F 0 "D4" H 5075 1825 50  0000 C C
F 1 "TEST" H 5375 1825 50  0000 C C
	1    5200 1750
	1    0    0    -1  
$EndComp
$Comp
L R R6
U 1 1 477F5B9B
P 4575 1750
F 0 "R6" V 4500 1600 50  0000 C C
F 1 "330R" V 4500 1875 50  0000 C C
	1    4575 1750
	0    1    1    0   
$EndComp
$Comp
L R R4
U 1 1 477F5B93
P 4575 2125
F 0 "R4" V 4500 1975 50  0000 C C
F 1 "330R" V 4500 2250 50  0000 C C
	1    4575 2125
	0    1    1    0   
$EndComp
$Comp
L R R5
U 1 1 477F5B8B
P 4575 1950
F 0 "R5" V 4500 1800 50  0000 C C
F 1 "330R" V 4500 2075 50  0000 C C
	1    4575 1950
	0    1    1    0   
$EndComp
$Comp
L USB-B CON1
U 1 1 477F5B61
P 1000 1550
F 0 "CON1" H 950 1800 60  0000 C C
F 1 "USB-B" H 950 1300 60  0000 C C
	1    1000 1550
	1    0    0    -1  
$EndComp
$EndSCHEMATC
