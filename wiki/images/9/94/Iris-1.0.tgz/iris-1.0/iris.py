# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'iris.ui'
#
# Created: Wed May 16 00:01:56 2007
#      by: PyQt4 UI code generator 4.0.1
#
# WARNING! All changes made in this file will be lost!

import sys
from PyQt4 import QtCore, QtGui
import libIris

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.setWindowModality(QtCore.Qt.NonModal)
        MainWindow.setEnabled(True)
        MainWindow.resize(QtCore.QSize(QtCore.QRect(0,0,184,350).size()).expandedTo(MainWindow.minimumSizeHint()))

        self.centralwidget = QtGui.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")

        self.vboxlayout = QtGui.QVBoxLayout(self.centralwidget)
        self.vboxlayout.setMargin(9)
        self.vboxlayout.setSpacing(6)
        self.vboxlayout.setObjectName("vboxlayout")

        self.groupBox = QtGui.QGroupBox(self.centralwidget)
        self.groupBox.setObjectName("groupBox")

        self.vboxlayout1 = QtGui.QVBoxLayout(self.groupBox)
        self.vboxlayout1.setMargin(9)
        self.vboxlayout1.setSpacing(6)
        self.vboxlayout1.setObjectName("vboxlayout1")

        self.hboxlayout = QtGui.QHBoxLayout()
        self.hboxlayout.setMargin(0)
        self.hboxlayout.setSpacing(6)
        self.hboxlayout.setObjectName("hboxlayout")

        self.vboxlayout2 = QtGui.QVBoxLayout()
        self.vboxlayout2.setMargin(0)
        self.vboxlayout2.setSpacing(6)
        self.vboxlayout2.setObjectName("vboxlayout2")

        self.label = QtGui.QLabel(self.groupBox)
        self.label.setObjectName("label")
        self.vboxlayout2.addWidget(self.label)

        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setObjectName("label_2")
        self.vboxlayout2.addWidget(self.label_2)
        self.hboxlayout.addLayout(self.vboxlayout2)

        self.vboxlayout3 = QtGui.QVBoxLayout()
        self.vboxlayout3.setMargin(0)
        self.vboxlayout3.setSpacing(6)
        self.vboxlayout3.setObjectName("vboxlayout3")

        self.fileEdit = QtGui.QLineEdit(self.groupBox)
        self.fileEdit.setObjectName("fileEdit")
        self.vboxlayout3.addWidget(self.fileEdit)

        self.portEdit = QtGui.QLineEdit(self.groupBox)
        self.portEdit.setObjectName("portEdit")
        self.vboxlayout3.addWidget(self.portEdit)
        self.hboxlayout.addLayout(self.vboxlayout3)
        self.vboxlayout1.addLayout(self.hboxlayout)

        self.slaveCheck = QtGui.QCheckBox(self.groupBox)
        self.slaveCheck.setObjectName("slaveCheck")
        self.vboxlayout1.addWidget(self.slaveCheck)
        self.vboxlayout.addWidget(self.groupBox)

        self.groupBox_2 = QtGui.QGroupBox(self.centralwidget)
        self.groupBox_2.setObjectName("groupBox_2")

        self.vboxlayout4 = QtGui.QVBoxLayout(self.groupBox_2)
        self.vboxlayout4.setMargin(9)
        self.vboxlayout4.setSpacing(6)
        self.vboxlayout4.setObjectName("vboxlayout4")

        self.vboxlayout5 = QtGui.QVBoxLayout()
        self.vboxlayout5.setMargin(0)
        self.vboxlayout5.setSpacing(6)
        self.vboxlayout5.setObjectName("vboxlayout5")

        self.info = QtGui.QTextEdit(self.groupBox_2)
        self.info.setEnabled(False)
        self.info.setObjectName("info")
        self.vboxlayout5.addWidget(self.info)
        self.vboxlayout4.addLayout(self.vboxlayout5)
        self.vboxlayout.addWidget(self.groupBox_2)

        self.groupBox_3 = QtGui.QGroupBox(self.centralwidget)
        self.groupBox_3.setObjectName("groupBox_3")

        self.hboxlayout1 = QtGui.QHBoxLayout(self.groupBox_3)
        self.hboxlayout1.setMargin(9)
        self.hboxlayout1.setSpacing(6)
        self.hboxlayout1.setObjectName("hboxlayout1")

        spacerItem = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout1.addItem(spacerItem)

        self.writeButton = QtGui.QPushButton(self.groupBox_3)
        self.writeButton.setObjectName("writeButton")
        self.hboxlayout1.addWidget(self.writeButton)

        spacerItem1 = QtGui.QSpacerItem(40,20,QtGui.QSizePolicy.Expanding,QtGui.QSizePolicy.Minimum)
        self.hboxlayout1.addItem(spacerItem1)
        self.vboxlayout.addWidget(self.groupBox_3)

        self.line = QtGui.QFrame(self.centralwidget)
        self.line.setFrameShape(QtGui.QFrame.HLine)
        self.line.setFrameShadow(QtGui.QFrame.Sunken)
        self.line.setObjectName("line")
        self.vboxlayout.addWidget(self.line)

        self.label_3 = QtGui.QLabel(self.centralwidget)
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.vboxlayout.addWidget(self.label_3)
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QObject.connect(self.writeButton,QtCore.SIGNAL("clicked()"),self.__write)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QtGui.QApplication.translate("MainWindow", "Skypic downldr", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox.setTitle(QtGui.QApplication.translate("MainWindow", "Data", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("MainWindow", "File:", None, QtGui.QApplication.UnicodeUTF8))
        self.label_2.setText(QtGui.QApplication.translate("MainWindow", "Port:", None, QtGui.QApplication.UnicodeUTF8))
        self.slaveCheck.setText(QtGui.QApplication.translate("MainWindow", "Program slave Skypic", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_2.setTitle(QtGui.QApplication.translate("MainWindow", "Info", None, QtGui.QApplication.UnicodeUTF8))
        self.groupBox_3.setTitle(QtGui.QApplication.translate("MainWindow", "Actions", None, QtGui.QApplication.UnicodeUTF8))
        self.writeButton.setText(QtGui.QApplication.translate("MainWindow", "Write!", None, QtGui.QApplication.UnicodeUTF8))
        self.label_3.setText(QtGui.QApplication.translate("MainWindow", "(C) 2007 Rafael Treviño Menéndez", None, QtGui.QApplication.UnicodeUTF8))

    def __write (self):
		self.fileEdit.setEnabled(False)
		self.portEdit.setEnabled(False)
		self.slaveCheck.setEnabled(False)

		# Main thing
		file = str (self.fileEdit.text ())
		port = str (self.portEdit.text ())

		# TODO: slaveCheck support (remember enable it!)

		self.info.clear ()

		if file and port:
			iris = libIris.Iris (port)
			try:
				iris.download (file)
			except qlibIris.IrisError, e:
				self.info.append ('Download: FAIL: %s' % str (e))
			else:
				self.info.append ('Download: OK')
		else:
			self.info.append ('You must enter file and port')
		
		self.fileEdit.setEnabled(True)
		self.portEdit.setEnabled(True)
		self.slaveCheck.setEnabled(True)

if __name__ == "__main__":
    app = QtGui.QApplication(sys.argv)
    MainWindow = QtGui.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
