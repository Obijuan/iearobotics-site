
#ifndef __SERIAL_H
#define __SERIAL_H

#define DTR_ON  1
#define DTR_OFF 0

int sg_serial_open(char *disp);
int read_car(int fd, unsigned char *car, unsigned int tout);
void sc_signal_dtr_set(int fd, int estado);
void sg_serial_enviar(int serial_fd, char *trama, int tam);

#endif
