/*************************************************************************** */
/* Juan gonzalez                                                             */
/*---------------------------------------------------------------------------*/
/*  LICENCIA GPL                                                             */
/*****************************************************************************/

//-- Especificar el pic a emplear
#include <pic16f876a.h>
#include <float.h>
#include <math.h>

//-- Definiciones
#define LED       RB1     // Pin del led de la Skypic
#define ON        1

//----------------------------
//- Comienzo del programa  
//----------------------------

__code static float tabla[]={
0.0,
0.017452, 0.034899, 0.052336, 0.069756, 0.087156, 0.10453, 0.12187, 0.13917, 0.15643, 0.17365, //- 01 - 10
0.19081,  0.20791,  0.22495,  0.24192,  0.25882,  0.27564, 0.29237, 0.30902, 0.32557, 0.34202, //- 11 - 20
0.35837,  0.37461,  0.39073,  0.40674,  0.42262,  0.43837, 0.45399, 0.46947, 0.48481, 0.50000, //- 21 - 30
0.51504,  0.52992,  0.54464,  0.55919,  0.57358,  0.58779, 0.60182, 0.61566, 0.62932, 0.64279, //- 31 - 40
0.65606,  0.66913,  0.68200,  0.69466,  0.70711,  0.71934, 0.73135, 0.74314, 0.75471, 0.76604, //- 41 - 50
0.77715,  0.78801,  0.79864,  0.80902,  0.81915,  0.82904, 0.83867, 0.84805, 0.85717, 0.86603, //- 51 - 60
0.87462,  0.88295,  0.89101,  0.89879,  0.90631,  0.91355, 0.92050, 0.92718, 0.93358, 0.93969, //- 61 - 70
0.94552,  0.95106,  0.95630,  0.96126,  0.96593,  0.97030, 0.97437, 0.97815, 0.98163, 0.98481, //- 71 - 80
0.98769,  0.99027,  0.99255,  0.99452,  0.99619,  0.99756, 0.99863, 0.99939, 0.99985, 1.00000, //- 81 - 90
};

//------------- RELACIONADAS CON LOS SERVOS -----------------
#define DELAY_0_3ms 0xEA	  // Tiempo 0'3ms, con prescaler a =64
#define DELAY_1_0ms 0xB0	  // Posicion central: 1ms, pres a = 64
#define DELAY_2_2ms 0x52    // Tiempo 2,2ms, con prescaler a =64

#define CENTRO	    DELAY_1_0ms
#define EXTREMO1    0xE0
#define EXTREMO2    0x90

// --Posicion de los servos
volatile unsigned char pos_servos[8];  // Posicion servo
unsigned char indice;        // indice de servo
unsigned char servo_actual;  // Servo actual

unsigned char salidas;	    // Máscara que indica qué salidas están activas
unsigned char estado;	
	
unsigned char car;   // Caracter recibido por el SCI
unsigned char pos;   // Calculos intermedios

#define RETRASO 0xFFFF

//-- Realizar una pausa mediante espera activa
void pausa(unsigned int retraso)
{
  while (retraso>0) {
    retraso--;
  }  
}

void pausa2(unsigned char ticks)
{
  for (;ticks>0; ticks--)
    pausa(RETRASO);
}

/******************************************
	Rutina de atención a la interrupción
*******************************************/

void intr(void) interrupt 0 {
	
  // Borra flag de interrupcion TIMER0 TOIF
  INTCON=INTCON&0xFB;   // TOIF=0  borra flag interrupcion del timer

  if (estado==0) {
    PORTB=salidas & servo_actual;  // servo activo con mascara de las salidas
    //-- Lanzar temporizador para calcular anchura fija de 0.3ms
    TMR0=DELAY_0_3ms;
    estado=1;
  }
  else if (estado==1) {
    //-- Anchura para situar el servo
    TMR0=pos_servos[indice];
    estado=2;
  }
  else if (estado==2) {
    PORTB=0;
    TMR0=DELAY_2_2ms-pos_servos[indice];   
    estado=0;
		
    //-- Pasar al siguiente servo
    servo_actual=servo_actual<<1;
    indice++;
    if (servo_actual==0x00) { 
      servo_actual=1;
      indice=0;
     }	
  }	 
  else {
    // si llega aquí es por error -> vuelvo a estado inicial
    estado=0;
  }	
}

/***************************************
   Configuracion del Timer 0
****************************************/

void timer0_configure() {
  // TOCS=Modo timer bit5=0
  // PS2:PS9 prescaler a 32
  // PSA=0 para asignar el prescaler al timer0
  OPTION_REG=0x05;   
	
  // Borra flag de interrupcion TIMER0 TOIF
  INTCON=INTCON&0xFB;   // TOIF=0  borra flag interrupcion del timer
  INTCON=INTCON|0x20;   // TOIE=1  activa interrupciones del timer
  INTCON=INTCON|0x80;   // GIE=1   activa interrupciones globales
  TMR0=0;               // Inicializa el registro del timer
}


int sin(int A, int x)
{
  volatile int result;
  int signo1=1;

//-- Por hacer: Falta cambiar signo segun el signo de x
//-- Por ahora supondremos que x>=0

/*  if (x>=0) signo=1;
  else {
    signo=-1;
    x=-x;
  }*/

  //-- Dejar la fase en el rango 0-360
  x = x % 360; 

  //-- Segundo cuadrante
  if (x>90 && x<=180) {
    x = 180-x;
  }

  //-- Tercer cuadrante
  if (x>180 && x<=270) {
    x = x - 180;
    signo1=-1;
  }

  //-- Cuarto cuadrante
  if (x>270 && x<=360) {
    x = 360 -x;
    signo1=-1;
  }

  result = (int) (A*tabla[x]);

  return signo1*result;
}

int grados_futaba(int grados)
{
  int result;
  volatile int g;
  volatile float temp;
  volatile int t2;

  if (grados>=0)
    result = (int) (grados*0.8 + 72);
  else {
    //-- Debido al bug del SDCC de los numeros flotantes negativos, primero
    //-- calculamos el valor pos_grados*0.8 como un numero entero positivo
    g = -grados;
    temp = g*0.8;
    t2 = (int)temp;
    result = 72 - t2;
   }

  return result;
}

volatile int temp;
volatile int temp2;

//-- Codigo validado. 
//-- OSCILACION DE UN SERVO!!!!!!!!! Ya tengo un módulo Y1 oscilando
//-- de manera autonoma, y con la posibilidad de cambiar en el codigo
//-- la amplitud y frecuencia. IMPRESIONANTE!!


/************************************************************************/
/* Posicionar el servo indicado, usando una amplitud y una fase         */
/* Entradas:                                                            */
/*   -servo: 0-7                                                        */
/*   -A: 0 - 90 grados                                                  */
/*   -fase: 0 - 360 grados                                              */
/************************************************************************/
void actualizar_servo(int servo, int A, int fase)
{
	temp=sin(A,fase);
  temp2 = grados_futaba(temp);
  pos_servos[servo]=0xFF-temp2;  
}

void main(void)
{
  unsigned char i;
  int fase;

  //-- Configurar pin del led como salida
  TRISB=0x00;

  //--inicializacion de variables
  for (i=0; i<8; i++) {
    pos_servos[i]=CENTRO;  // Motores en el centro como inicio
  }
  salidas=0xff;
  indice=0;
  estado=0;
  servo_actual=1; 
	
  //-- Configurar el Timer0 para controlar los servos
  //-- y activar su interrupcion
  timer0_configure();

  //-- Servos a posiciones iniciales
  actualizar_servo(0,0,0);
  actualizar_servo(1,0,0);
  pausa2(6);

  //-- Empezar!
  while(1) {
    for (fase=0; fase<360; fase+=5) {
			actualizar_servo(0,45,fase);
      actualizar_servo(1,45,fase+90);

      pausa(0x1000);
    }
  }
  //while(1);
}

