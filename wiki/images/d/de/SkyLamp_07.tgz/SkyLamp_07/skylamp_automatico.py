#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# serial.py, SkyLamp_automatico
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys, urllib2, skylamp

# Syntax: skylamp_automatico <Puerto> [DTR | RTS]
if __name__ == '__main__':

	try:
		port = sys.argv [1] # Check the port name
	except IndexError:
		print 'Uso: %s <Puerto> [DTR | RTS]' % sys.argv [0]
		sys.exit (-1)
	
	try:
		signal = sys.argv [2]
	except IndexError:
		SL = skylamp.SkyLamp (port)
		'Info: Usando DTR'
	else:
		SL = skylamp.SkyLamp (port, signal)
	
	lastState = 0
	
	while (True):
	
		data = urllib2.urlopen ('http://www.webdearde.com/lampara.txt')
		state = int (data.readline ())
		data.close ()

		if state != lastState:
			if state == 0:
				SL.off ()
			if state == 1:
				SL.on ()

		elif state != 0 and state != 1:
			SL.blink ()

		else:
			SL.idle ()

		lastState = state
