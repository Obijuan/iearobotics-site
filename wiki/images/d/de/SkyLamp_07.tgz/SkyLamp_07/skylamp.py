#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# serial.py, SkyLamp Module
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import serial, time

class SkyLamp:

	def __init__ (self, port, signal = 'DTR'):
		self.port = port

		try:
			self.s = serial.Serial (port, 9600)
			self.s.timeout = 1
		except serial.SerialException:
			print >> sys.stderr, 'Error: No se puede abrir el puerto "%s"' % port
		else:
			print 'Usando puerto "%s"' % port

		if signal == 'DTR':
			self.fsignal = self.s.setDTR
		elif signal == 'RTS':
			self.fsignal = self.s.setRTS
		else:
			self.fsignal = self.s.setDTR
			print >> sys.stderr, 'Aviso: Token "%s" no reconocido, usando DTR' % signal
	
	def on (self): # Time: 1 second
		self.fsignal (1)
		time.sleep (1)
	
	def off (self): # Time: 1 second
		self.fsignal (0)
		time.sleep (1)
	
	def blink (self): # Time: 1 second
		for i in xrange (10):
			if i % 2:
				self.off ()
			else:
				self.on ()
			time.sleep (.1)
	
	def idle (self): # Time: 1 second
		time.sleep (1)
	
	def __del__ (self):
		self.s.close ()
