#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# serial.py, SkyLamp_teclas
# Copyright (C) 2006 por Rafael Treviño Menéndez
# Autor: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys, urllib2, consola_io, skylamp

#-- Caracter empleado para salir del terminarl
EXITCHARACTER = '\x04'   # Ctrl + D

# Syntax: skylamp_teclas <Puerto> [DTR | RTS]
if __name__ == '__main__':

	try:
		port = sys.argv [1] # Check the port name
	except IndexError:
		print 'Uso: %s <Puerto> [DTR | RTS]' % sys.argv [0]
		sys.exit (-1)
	
	try:
		signal = sys.argv [2]
	except IndexError:
		SL = skylamp.SkyLamp (port)
		'Info: Usando DTR'
	else:
		SL = skylamp.SkyLamp (port, signal)
	
	# Mensaje inicial
	print 'SkyLamp por consola en Python'
	print '0 para apagar'
	print '1 para encender'
	print '2 para parpadeo'
	print
	print 'CTRL-D para salir'
	
	lastState = 0
	
	while (True):

		try:
			token = consola_io.getkey ()
		except KeyboardInterrupt:
			print 'Abortando...'
			sys.exit (0)

		if token == EXITCHARACTER:
			sys.exit (0)

		try:
			state = int (token)
		except ValueError:
			print >> sys.stderr, 'Token "%s" no reconocido' % token

		if state != lastState and state != 2:
			if state == 0:
				SL.off ()
			if state == 1:
				SL.on ()

		elif state != 0 and state != 1:
			SL.blink ()

		lastState = state
