#include <MC68HC908GP32.h>


void main(void) {

  //-- Configurar pines PTC1, PTC2, PTC3 y PTC4 para salida
	DDRC=0x1E;  		

	//-- Activar el motor 1 y 2  
	PTC=0x14;	


  for(;;); /* loop forever */
  /* please make sure that you never leave this function */
}
