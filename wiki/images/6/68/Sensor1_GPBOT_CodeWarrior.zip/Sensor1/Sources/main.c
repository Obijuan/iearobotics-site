/* Sensor IR1: Pin PTC5               */
/* Valores devueltos por el sensor:   */
/* Negro -->  1                       */
/* Blanco --> 0                       */

#include <mc68hc908gp32.h>

unsigned char sensor;

void main(void){	
	CONFIG1|=0x01;  //-- Deshabilitar el COP

	//-- Configurar puerto B para salida	
	DDRB=0xFF;
	  
	//-- Configuraci�n para utilizar el sensor en modo digital
	//-- Configurar puerto C para entrada	
	DDRC=0x00;	
  
  //-- Configurar pull-up	
	PTCPUE=0x20;
	
	for(;;) {
		//-- Leer sensor IR1
		sensor=(PTC & 0x20)<<1;
		//-- Enviar el valor al puerto B para visualizarlo
		PTB=sensor;
	
	}
}
 

