
- Para crear la pagina man ejecutar:

  $ ./make_man

  Esto crea la pagina de manual a partir de la version en xml

- Para visulizar la pagina ejecutar:

  $ ./make_man view
