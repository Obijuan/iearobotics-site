#!/usr/bin/env python
#-*- coding: iso-8859-15 -*-

from distutils.core import setup

setup(name         = 'pydownloader',
      version      = '1.0',
      description  = 'Libreria para descarga de Firmware en la skypic',
      author       = 'Juan Gonzalez, Rafael Treviño',
      author_email = 'juan@iearobotics.com',
      url          = 'http://www.iearobotics.com/wiki/index.php?title=Pydownloader',
      license      = 'GPL v2 or later',
      data_files   = [('share/man/man1',['man/pydownloader.1'])],
      scripts      = ['pydownloader.py',],
      )
