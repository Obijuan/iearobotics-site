#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: pywii is a class to control wiimote
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import thread, time, sys, wiicon
from wiievent import Event, EventQueue
from wiicon import WiiconError
from wiiutils import Vector
from wiimovsys import MoveSystem

import traceback

buttonActionType = {0: 'ButtonPress', 1: 'ButtonRelease'}
buttonType = {
		0:  'Two',
		1:  'One',
		2:  'B',
		3:  'A',
		4:  'Minus',
		7:  'Home',
		8:  'Left',
		9:  'Right',
		10: 'Down',
		11: 'Up',
		12: 'Plus'}
	
class Wiimote:

	__gid = [0, 0, 0, 0]
	
	def __init__ (self):
		self.__state = 0
		self.__events = EventQueue ()
		self.__control = EventQueue ()
		self.__con = None
		self.__id = 0
		self.__rumble = 0
		self.__motionZero = Vector (132, 132, 131)
		self.__motionOne = Vector (26, 26, 26)
		self.__buttonState = 0
		self.__moveSystem = MoveSystem ()
		self.__moveEnabled = False
		self.__motionMean = [Vector (0, 0, 0), Vector (0, 0, 0)]
	
	def __listener (self):
		print 'Servidor de eventos listo y a la escucha.'
		while self.__state:
			try:
				msg = self.__con.recv (23)
			except BluetoothError:
				time.sleep (0.01)
				continue

			msg = [ord (b) for b in msg]
				
			type = msg [1]
			#print "Type: %x" % type
				
			if type == 0x21:
				self.__control.enqueue (Event ('Read', msg [2:]))
				continue

			buttonState = ((msg [2] & 0x9F) << 8) + (msg [3] & 0x9F)
			
			# Modes 0x30 (default), 0x31 (after start () call) and 0x32 (expansion)
			if self.__buttonState != buttonState:
				oldState = self.__buttonState
				newState = buttonState
				for i in xrange (16):
					oldb = oldState & 1
					if newState & 1 != oldb:
						self.__events.enqueue (Event (buttonActionType [oldb], buttonType [i]))
					newState = newState >> 1
					oldState = oldState >> 1
			
				self.__buttonState = buttonState
	
			# Motion report
			if type == 0x31 or type==0x32:
				

				#-- Wii-board
				if type==0x32:
					v=Vector(0,0,0)
					v.y=msg[4]-msg[6]-4;
					#v.y=msg[8]-msg[10]-49;
					try:
 				  		v.x=msg[4]-msg[8]-6;
					except:
				  		print "Error"
   					v.z=0;
				else:
					rawv = Vector (*[d for d in msg [4: 7]])
					self.__motionMean.append (rawv)
					v = self.__motionMean [0] + self.__motionMean [1] + self.__motionMean [2]
					v.x /= 3
					v.y /= 3
					v.z /= 3

					del self.__motionMean [0]
				
					v = self.__normalizeVector (v)
				
				ev = Event ('Motion', v)
				
				if self.__moveEnabled:
					self.__moveSystem.notify (ev)
				else:
					self.__events.enqueue (ev)

			# Expansion attached (or detached)
			elif type == 0x20:
				if msg [4] & 0x02:
					# Set channel 32 active (with expansion)
					self.__con.send ("\x52\x12\x00\x32")
				else:
					# Set channel 31 active (without expansion)
					self.__con.send ("\x52\x12\x00\x32")

	
		print 'Servidor de eventos muriendo...'
		self.__state = -1

	def __initEventServer (self):
		thread.start_new_thread (self.__listener, ())
	
	def __readMem (self, offset, len):
		address = '%c%c' % (offset >> 8, offset % 256)
		size = '%c%c' % (len >> 8, len % 256)
		self.__con.send ("\x52\x17\x00\x00%s%s" % (address, size))

		# Wait answer
		while 1:
			ev = self.__control.dequeue ()
			if ev:
				break
			time.sleep (0.01)
		# print ev.type, ev.data

		return ev.data [5:]
	
	def __readZeroes (self):
		data = self.__readMem (0x16, 0x8)
		
		# Set motion origins
		self.__motionZero = Vector (*[d for d in data [:3]])
		self.__motionOne = Vector (*[d for d in data [4: 7]])
		
		self.__motionOne -= self.__motionZero

	def __initialMessages (self):
		# Set channel 31 active
		self.__con.send ("\x52\x12\x00\x31")

		# Set Player led
		available = [i for i, v in enumerate (self.__gid) if v == 0]
		try:
			self.__id = available [0]
		except IndexError:
			print "No quedan id's libres."
		else:
			byte = 1 << (self.__id + 4)
			self.__con.send ("\x52\x11%c" % chr (byte))

			print 'Establecido wiimote con id %s' % ((self.__id + 1) * '·')

	def start (self, address):
		self.__state = 1
		self.__con = wiicon.Wiicon ()
		self.__con.start (address)
		self.__initialMessages ()
		self.__initEventServer ()
		self.__readZeroes ()
	
	def stop (self):
		self.__state = 0
		while not self.__state:
			time.sleep (0.01)
		self.__events.clear ()
		self.__con.stop ()
		self.__gid [self.__id] = 0
		self.disableMoveSystem ()
		self.__rumble = 0
	
	def getEvents (self):
		return self.__events.dequeueAll ()

	def enableMoveSystem (self):
		if not self.__moveEnabled:
			self.__moveSystem.start (self.__events)
			self.__moveEnabled = True
	
	def disableMoveSystem (self):
		if self.__moveEnabled:
			self.__moveSystem.stop ()
			self.__moveEnabled = False
	
	def enableRumble (self):
		self.__rumble = 1
	
	def disableRumble (self):
		self.__rumble = 0

	def __normalizeVector (self, v):
		return (v - self.__motionZero) / self.__motionOne

if __name__ == '__main__':
	
	wii = Wiimote ()

	try:
		wii.start (sys.argv [1])
	except IndexError:
		print 'Uso: %s <address>' % sys.argv [0]
		sys.exit (-1)
	except WiiconError:
		print 'Error al iniciar servicio Bluetooth'
		sys.exit (-1)
	
	print 'Pulsa "Home" para salir'
	
	# Replace motion events (low-level)
	# for move events (high-level)
	# (not yet implemented)
	# wii.enableMoveSystem ()

	keep = True
	while keep:
		events = wii.getEvents ()
		for ev in events:
			if ev.type == 'Motion':
				# print 'Motion event', ev.data
				# print 'Modulo: %.3f' % ev.data.module ()
				pass
			elif ev.type == 'ButtonPress':
				print 'Button press event', ev.data
				if ev.data == 'Home':
					keep = False
					break
			elif ev.type == 'ButtonRelease':
				print 'Button release event', ev.data
			elif ev.type == 'Move':
				print 'Move event', ev.data
				print 'Modulo: %.3f' % ev.data.module ()
				pass
		time.sleep (0.01)

	wii.stop ()
