#! /usr/bin/python
#---------------------------------------------------------------------------
#--  (C)2007 Juan Gonzalez
#--
#--  Modulo Stargate para la comunicacion con lo servidores "stargates"
#--
#--  LICENCIA GPL
#---------------------------------------------------------------------------

import os, sys, time, pygame
sys.path = ['./pywii'] + sys.path
import pywii
import sys
import time
from bluetooth import BluetoothError
import stargate
from pic16f876 import * 

dirhw =  "00:1E:35:C1:5E:E4"

#-- Caracter de escape
ESC = '\x1B'

ADELANTE = 0x1C
ATRAS = 0x16
STOP = 0x00
DERECHA = 0x14
IZQUIERDA = 0x1E

#---------------------
#- Comienzo programa
#---------------------

try:
  wii = pywii.Wiimote ()
except BluetoothError:
  print 'Error al conectar'

try:
  wii.start (dirhw)
except BluetoothError:
  print 'Error al iniciar servicio'
  sys.exit (-1)
except IndexError:
  print 'Uso: %s <address>' % sys.argv [0]
  print 'tomando dir: %s' % dirhw
  wii.start (dirhw)
  
#-- Establecer conexion con stargate
g = stargate.start_typical_session("GENERIC")
  
  
#-- Configurar puertos
g[TRISB]=0xE1;
g[TRISA]=0xFF;
  
#-- Configurar el puerto A para trabajar con los bumpers
g[ADCON1]=0x0E;     

oldpitch=0

estado = STOP
oldestado = STOP


while 1:
  events = wii.getEvents ()
  for ev in events:
    if ev.type == 'Motion':
      x=ev.data.x; y=ev.data.y; z=ev.data.z;
      #print 'x: %0.3f; y: %.3f; z: %.3f' %  (x,y,z)
      print 'x: %3d; y: %3d; z: %3d' %  (x,y,z)
      
      if x>=5:
        estado=IZQUIERDA
      elif x<=-6:
        estado=DERECHA
      elif y<=-5:
        estado=ADELANTE
      elif y>=8:
        estado=ATRAS
      else:
        estado=STOP
      
      if estado!=oldestado:  
        if estado==ADELANTE:
          g[TRISB]=0xE1;
          g[PORTB]=ADELANTE
          print "adelante"
          
        elif estado==ATRAS:
          g[TRISB]=0xE1;
          g[PORTB]=ATRAS        
          print "Atras"
        
        elif estado==IZQUIERDA:
          g[TRISB]=0xE1;
          g[PORTB]=IZQUIERDA
          print "izquierda"
          
        elif estado==DERECHA:
          g[TRISB]=0xE1;
          g[PORTB]=DERECHA
          print "derecha"          
          
        elif estado==STOP:
          g[TRISB]=0xE1;
          g[PORTB]=STOP
          print "Stop"
          
      oldestado=estado    

  time.sleep (0.01)

g[PORTB]=STOP    
wii.stop ()
print 'Fin'
