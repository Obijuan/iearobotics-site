VERSION DE PRUEBAS
------------------



-La dirección de la Wii-board está puesta al comienzo del fichero wii-fit.py

-- Ejecutar con:
-- (Sustituir /dev/ttyUSB0 por el puerto serie donde este conectado el Skybot)

./wii-fit.py -p/dev/ttyUSB0

Aparecerá:
Conectando a 00:1E:35:C1:5E:E4, presiona 1 y 2.

En ese momento hay que pulsar el botón de "Sync" de la wii-board, que se
encuentra situado donde están las pilas (De momento no sé cómo sincronizarlo
de otra manera...)

El funcionamiento está calibrado para mi peso :-)

Más información: 
http://www.iearobotics.com/wiki/index.php?title=Wii_Board
