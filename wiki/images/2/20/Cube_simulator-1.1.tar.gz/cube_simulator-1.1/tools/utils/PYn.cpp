/*---------------------------------------------------------------------------*/
/**  \file PYn.cpp
  *  \brief Create the genotype string for PYn configurations
  *             
  *
  *  The genotype is created from the number of modules, Ah,Av,T,Ov,Oh,DFv,
  *  DFh, DFhv
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date January 2007
*/
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

/****************************/
/* VARIABLES                */
/****************************/

//-- Numero maximo de modulos permitidos
#define MAX_MOD 200

int Av,Ah;
int T;
int DFv,DFh,DFvh;
int Ov,Oh;
int num_mod;     //-- Numero de modulos de la configuracion


static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  PYn N T Av Ah Ov Oh DFv DFh DFhv\n");
  printf ("donde,\n");
  printf ("  -N es el numero de modulos (1-20)\n");
  printf ("  -T es el periodo \n");
  printf ("  -Av es la amplitud en grados (0-90) de los modulos Pitch\n");
  printf ("  -Ah es la amplitud en grados (0-90) de los modulos yaw\n");
  printf ("  -Ov es el offset de los modulos pitch \n");
  printf ("  -Oh es el offset de los modulos yaw\n");
  printf ("  -DFv es la diferencia de fase entre modulos pitch consecutivos \n");
  printf ("  -DFh es la diferencia de fase entre modulos yaw consecutivos\n");
  printf ("  -DFvh es la diferencia de fase entre modulos pitch y yaw\n");
  
  printf ("Ejemplo:\n");
  printf ("  PYn 3 10 45 45 0 0 0 0 90\n");
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{

  if (argc!=10) {
    help();
    exit(1);
  }
  
  //-- Leer numero de modulos y comprobar que es correcto
  num_mod=atoi(argv[1]);
  
  if (num_mod<=0) {
    printf ("ERROR. Numero de modulos incorrecto\n");
    return 0;
  }
  
  if (num_mod>MAX_MOD) {
    printf ("ERROR. Numero maximo de modulos permitidos: %d\n",MAX_MOD);
    return 0;
  }
  
  //-- Leer periodo
  T=atoi(argv[2]);
  
  //-- El periodo no puede ser 0. Si es asi se pone a 2
  if (T==0) T=2;
  
  Av=atoi(argv[3]);
  Ah=atoi(argv[4]);
  Ov=atoi(argv[5]);
  Oh=atoi(argv[6]);
  DFv=atoi(argv[7]);
  DFh=atoi(argv[8]);
  DFvh=atoi(argv[9]);
  
  
  //-- Generar la salida
  printf ("%d ",num_mod);
  
  for (int i=0; i<num_mod; i++) {
    
    //-- Los modulos pares son los pitch
    if (i%2==0) {
       printf("%d %d %d %d  ",Av,T,-i*DFv/2,Ov);
    }
    else //-- Los impares son los yaw
       printf("%d %d %d %d  ",Ah,T,DFvh-(i-1)*DFh/2+180,Oh);
  }
  
  //-- Sacar la estructura del robot
  for (int i=0; i<num_mod; i++) {
    if (i%2==0)
      printf ("P ");
    else
      printf ("Y ");
  }
  
  printf ("\n");
  
}
