/*---------------------------------------------------------------------------*/
/**  \file Pn.cpp
  *  \brief Create the genotype string for Pn configurations
  *             
  *
  *  The genotype is created from the number of modules, A, T, O and DF.
  *  That is, from the homogeneous+O group
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date January 2007
*/
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

/****************************/
/* VARIABLES                */
/****************************/

//-- Numero maximo de modulos permitidos
#define MAX_MOD 200

int A;
int T;
int F;
int O;
int num_mod;     //-- Numero de modulos de la configuracion


static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Pn N A T F O\n");
  printf ("donde,\n");
  printf ("  -N es el numero de modulos (1-20)\n");
  printf ("  -A es la amplitud en grados (0-90)\n");
  printf ("  -T es el periodo \n");
  printf ("  -F es la diferencia de fasee  \n");
  printf ("  -O es el offset  \n");
  printf ("Ejemplo:\n");
  printf ("  Pn 2 40 10 120 0\n");
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{

  if (argc!=6) {
    help();
    exit(1);
  }
  
  //-- Leer parametros
  num_mod=atoi(argv[1]);
 
  A=atoi(argv[2]);
  
  T=atoi(argv[3]);
  
  //-- El periodo no puede ser 0. Si es asi se pone a 2
  if (T==0) T=2;
  
  F=atoi(argv[4]);
  O=atoi(argv[5]);
 
  //-- Generar la salida
  
  //-- Numero de modulos
  printf ("%d ",num_mod);
  
  //-- Sacar los parametros de cada generador
  for (int i=0; i<num_mod; i++) {
    printf("%d %d %d %d  ",A,T,-i*F,O);
  }
  
  //-- Sacar la estructura del robot
  for (int i=0; i<num_mod; i++) {
    printf ("P ");
  }
  
  printf ("\n");
  
}
