/*---------------------------------------------------------------------------*/
/**  \file sin2file.cpp
  *  \brief Generate a .mvm file from sinusoidal generators   
  *
  *  Utility for generating .mvm files from sinusoidal generators. 
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include "T1D.h"
#include "Rtk-3D.h"

/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

//-- Cadena para el fichero de salida, con la sequencia
char fich[255];


static void help()
{
  printf ("Forma de uso: \n");
  printf ("  sin2file [fich] Num_mod [A T F O,...] [P | Y | X, ...] ...\n");
  printf ("donde,\n");
  printf ("  -Num_mod: Numero de modulos\n");
  printf ("  -A es la amplitud en grados (0-90)\n");
  printf ("  -T es el periodo \n");
  printf ("  -F es la fase    \n");
  printf ("  -O es el offset  \n");
  printf ("  -'P'-> Modulo Pitch\n");
  printf ("  -'Y'-> Modulo Yaw\n");
  printf ("  -'X'-> Modulo no usado\n");
 
  printf ("Ejemplo:\n");
  printf ("  sin2file 3  45 10 0 0  45 10 60 0  45 10 120 0  P P P\n");
  printf ("  sin2file `./Pn 2 40 100 120 0`\n");
  printf (" sin2file hola.mvm `./PYn 3 10 45 45 0 0 0 0 90`\n");
}

/*****************************************************************************/
/* Generar el nombre del fichero en base a los parameros de los generadores  */
/*****************************************************************************/
void generar_nombre(char *filename)
{
  char aux[255];
  
  //-- Crear nombre del fichero
  sprintf (filename,"M%d_",worm.nm);
  
  for (int i=0; i<worm.nm; i++) {
    if (worm.estructura[i]==T1D_YAW) {
      strcat(filename,"Y");
    }  
    else {
      strcat (filename,"P");
    }
  }
  
  for (int i=0; i<worm.nm; i++) {
    sprintf(aux,"_A%dT%dF%dO%d",worm.cpg_A[i],worm.cpg_T[i],
                                worm.cpg_F[i],worm.cpg_O[i]);
    strcat(filename,aux);
  }
  strcat(filename,".mvm");
}


/******************************************/
/* Generar el fichero .mvm                */
/******************************************/
void generar_fichero_mvm(char *filename)
{
  FILE *fd;

  
  //-- Por hacer: control de errores...
  fd = fopen(filename,"w");
 
  //-- Crear fichero
  for (int i=0; i<worm.nm; i++) {
    Rtk_Sampled_Function_output_mrs(fd, &(worm.sf[i]));
  } 
  
  fclose(fd);
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  int n=0;
  bool fichero_salida=false;
  
  
  //-- Analizar parametros pasados por el usuario
  if (argc<2) {
    help();
    exit(1);
  }
  
  //-- El primer parametro es opcional y es el nombre del fichero de salida
  //-- Si el primer argumento NO es un numero, se toma como el nombre del 
  //-- fichero
  
  if (atoi(argv[1])==0)  {  //-- Fichero especificado
    strcpy(fich,argv[1]);
    n=1;
    fichero_salida=true;
  }  
    
  //-- Analizar los parametros de los generadores
  ok=T1D_get_args(&worm,argc-1,&argv[n],true);
  
  if (!ok) {
    help();
    exit(1);
  }
    
  //-- Construir configuracion
  T1D_new_robot(&worm,true,false);
  
  //-- Si nombre del fichero no esta especificado se genera uno
  if (fichero_salida==false)
    generar_nombre(fich);
  
  //-- Generar fichero en formato .mvm
  generar_fichero_mvm(fich);
  
  printf ("Fichero creado: %s\n",fich);
  
}
