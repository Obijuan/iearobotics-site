/*---------------------------------------------------------------------------*/
/**  \file Range_PYn.cpp
  *  \brief Calculate the kinematics when somme parameters change 
  *
  *  Different octave files are generated with the results of the experiment
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date February 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include <ctype.h>

#include "T1D.h"
#include "Rtk.h"

/****************************/
/* CONSTANTES               */
/****************************/
#define PARAM_T    1
#define PARAM_A    2
#define PARAM_O    3
#define PARAM_DF   4
#define PARAM_F    5   //-- Fase inicial

//-- 0.001 alta resolucion
//-- 0.01  resolucion normal
#define STEP 0.1

//-- coeficiente normal: 0.2
//-- coeficiente bajo 0.01
#define MU 0.4


#define MAX_RANGE 361
/****************************/
/* VARIABLES                */
/****************************/
static T1D_Robot worm;
static int ciclos_ini;
static int ciclos;

//-- Valor de DF inicial
static int DF_ini = 0;

//-- Parametro a variar
static int param;

//-- Rango del parametro
static int param_lower;
static int param_upper;

static dReal func_period[MAX_RANGE];
static dReal func_DX[MAX_RANGE];
static dReal func_DY[MAX_RANGE];
static dReal func_DL[MAX_RANGE];
static dReal func_VX[MAX_RANGE];
static dReal func_VY[MAX_RANGE];
static dReal func_YAW[MAX_RANGE];
static dReal func_ROLL[MAX_RANGE];
static dReal func_WYAW[MAX_RANGE];
static dReal func_WROLL[MAX_RANGE];

//-- Amplitud global normalizada
static dReal func_AGN[MAX_RANGE];

//-- Distancia Y normalizada
static dReal func_DYN[MAX_RANGE];

//-- Cadenas asociadas a los paramtros
static char param_str[][6]={
  "","N","A","O","DF","F"
};

//-- Etiquetas para el eje X
static char xlabel[][255]={
  "",
  "Numero de muestras (N)",
  "Amplitud A (grados)",
  "Offset O (grados)",
  "Diferencia de fase DF (grados)",
  "Fase inicial (grados)",
};


/***************************************************/
/* Simulacion de un paso                           */
/* Devuelve false cuando se ha terminado           */
/***************************************************/
static bool simLoop (void)
{
  
  //-- Realizar un paso de simulacion
  T1D_step(&worm);
    
  //-- Comprobar timeout
  if (worm.timeout) {
    printf ("Timeout!!\n");
    return false;
  }  
  
  //-- Al terminar un intervalo finaliza la simulacion
  if (worm.intervalo_transicion && worm.intervalo_numero==2) {
    return false;
  }  
    
  return true;
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Range_PYn c_ini c param ini fin Num_mod [A N F O,...] [P | Y | X]\n");
  printf ("donde,\n");
  printf ("  -\n");
  printf ("Ejemplo:\n");
  printf ("  Range_Pn 1 2 A 0 90 `./Pn 2 0 10 0 0`\n");
}


/*************************************/
/* Pasar una cadena a mayusculas     */
/*************************************/
static void upcase(char *cad)
{
  for (unsigned int i=0; i<strlen(cad); i++) {
    cad[i]=toupper(cad[i]);
  }  
}

/************************************************/
/* Devolver el tipo de parametro                */
/************************************************/
int get_range_param(char *param, int *param_type)
{
   upcase(param);
  
  if (strcmp(param,"N")==0) {
    *param_type=PARAM_T;
    return 1;
  }else if (strcmp(param,"A")==0) {
    *param_type=PARAM_A;
    return 1;
  }else if (strcmp(param,"O")==0) {
    *param_type=PARAM_O;
    return 1;
  }else if (strcmp(param,"DF")==0) {
    *param_type=PARAM_DF;
    return 1;
  }else if (strcmp(param,"F")==0) {
    *param_type=PARAM_F;
    return 1;
  }else {
    return 0;
  }   
  
  return 1;
}

void print_param_type(int param_type)
{
  printf ("%s",param_str[param_type]);
}


/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static void analizar_parametros(int argc, char* argv[])
{
  int ok;

  //-- Comprobar que estan todos los parametros
  if (argc<12) {
    help();
    exit(1);
  }
  
  //-- Leer ciclo inicial y numero de ciclos
  ciclos_ini=atoi(argv[1]);
  ciclos=atoi(argv[2]);
  
  //-- Leer el parametro a variar
  ok=get_range_param(argv[3],&param);
  if (!ok) {
    printf ("Parametro %s incorrecto\n",argv[4]);
    help();
    exit(1);
  }
  
  //-- Leer el rango del parametro
  param_lower = atoi(argv[4]);
  param_upper = atoi(argv[5]);

  //-- Analizar resto de parametros
  ok=T1D_get_args(&worm,argc-5,&argv[5],true);
  
  if (!ok) {
    printf ("Error aqui!!\n");
    help();
    exit(1);
  } 
}


void tomar_medidas()
{
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,true,false);
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  worm.sim.step=STEP;
  worm.sim.mu=MU;
  
  //-- DEBUG!!! Imprimir los valores de los cpgs
  /*for (int i=0; i<worm.nm; i++) {
    printf ("   [%d] A: %d, T: %d, O: %d, F: %d\n",
           i,
           worm.cpg_A[i],
           worm.cpg_T[i],
           worm.cpg_O[i],
           worm.cpg_F[i]);
  }*/
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  
  do {
  } while (simLoop());
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
}


/***********************************************/
/* Asignar un valor al parametro especificado  */
/***********************************************/
void asignar_param(int param, int value)
{
  for (int i=0; i<worm.nm; i++) {
    
    switch(param) {
      case PARAM_T:
        worm.cpg_T[i]=value;
        break;
      
      case PARAM_A:
         worm.cpg_A[i]=value;  
         break;
        
      case PARAM_O: 
        worm.cpg_O[i]=value;
        break;

      case PARAM_DF: 
        worm.cpg_F[i]=i*value;
        break;
      
      case PARAM_F:
        worm.cpg_F[0]=value;
        break;
      
      default:
        printf ("Warning!!!!\n");        
    } 
  }
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  double L;
  double L_k;
  double k;
  double offset_z;
  
  //-- Analizar parametros pasados por el usuario
  analizar_parametros(argc,argv);
  
  //-- Obtener el valor de DF inicial
  //-- Si solo hay un modulo la diferencia de fase se pone a 0
  if (worm.nm>1) {
    DF_ini = worm.cpg_F[1] - worm.cpg_F[0];
  }
  else {
    DF_ini = 0;  
  }  
  
  //-- Calcular distancia del robot en cm
  L=worm.nm*LONG_mm*0.1;
  
  //-- Calcular parametro k
  k = abs((DF_ini * worm.nm)/(360));
  
  //-- Calcular parametro L_k
  L_k = L/k;
  
  offset_z=(ALTURA_mm*0.1/2);
  
  printf ("Ciclo inicial         : %d\n",ciclos_ini);
  printf ("Numero de ciclos      : %d\n",ciclos);
  printf ("Parametro             : ");
  print_param_type(param);
  printf ("\n");
  printf ("Valor inferior        : %d\n",param_lower);
  printf ("Valor superior        : %d\n",param_upper);
  printf ("Numero de modulos     : %d\n",worm.nm);
  printf ("DF                    : %d\n",DF_ini);
  printf ("Paso de simulacion    : %f\n",STEP);
  printf ("Coef. Rozamiento      : %f\n",MU);
  printf ("k                     : %f\n",k);
  printf ("\n");

  
  
  
  for (int i=param_lower; i<=param_upper; i++) {
    //-- Asignar siguiente valor al parametro
    asignar_param(param,i);
    
    //-- Realizar la simulacion
    tomar_medidas();
    
    //-- Almacenar resultado de la simulacion
    func_period[i]=worm.intervalo_duracion/worm.intervalo_ciclos;
    func_DX[i]=worm.xinc_int/worm.intervalo_ciclos;
    func_DY[i]=worm.yinc_int/worm.intervalo_ciclos;
    func_VX[i]=worm.vx_int;
    func_VY[i]=worm.vy_int;
    func_YAW[i]=RTK_TO_GRADOS(worm.yawinc_int/worm.intervalo_ciclos);
    func_ROLL[i]=RTK_TO_GRADOS(worm.rollinc_int/worm.intervalo_ciclos);
    func_WYAW[i]=RTK_TO_GRADOS(worm.wyaw_int);
    func_WROLL[i]=RTK_TO_GRADOS(worm.wroll_int);
    
    //-- Calcular la altura global normalizada
    func_AGN[i]=(worm.zmax_ciclo-offset_z)/L_k;
    
    //-- Calcular la distancia Y normalizada
    func_DYN[i]=func_DY[i]/L_k;
    
    //-- Almacenar Distancia total
    func_DL[i]=sqrt(func_DX[i]*func_DX[i] + func_DY[i]*func_DY[i]);
    
    //-- Imprimir
    printf ("%s: %d, T=%.2f, DX=%.2f, DY=%.2f, VX=%.2f, VY=%.2f, YAW: %.2f, ROLL: %.2f\n",
            param_str[param],i,
            func_period[i],
            func_DX[i],func_DY[i],
            func_VX[i],func_VY[i],
            func_YAW[i],func_ROLL[i]);
  } 
  
  //------------ Generar las graficas --------------
  
  //-- Grafica del periodo
  char file[255];
  char title[255];
  sprintf (file,"Range_Pn_%s_period.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data(param_lower, param_upper,file,
                        func_period,"Periodo",
                        title,
                        xlabel[param],
                        "Periodo (ticks de 0.01 seg)");
  
  //-- Grafica con DX y DY
  sprintf (file,"Range_Pn_%s_rcm.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_DX,"DX",func_DY,"DY",
                        title,
                        xlabel[param],
                        "Distancia (cm)");
  
  //-- Grafica con Vx, Vy
  sprintf (file,"Range_Pn_%s_vcm.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_VX,"VX",func_VY,"VY",
                        title,
                        xlabel[param],
                        "Velocidad (cm/s)");                      
  
  //-- Grafica con Yaw, Roll
  sprintf (file,"Range_Pn_%s_rot.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_YAW,"YAW",func_ROLL,"ROLL",
                        title,
                        xlabel[param],
                        "Angulo rotado (grados)");
  
  //-- Grafica con WYaw, WRoll
  sprintf (file,"Range_Pn_%s_wrot.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_WYAW,"WYAW",func_WROLL,"WROLL",
                        title,
                        xlabel[param],
                        "Velocidad angular (grados/seg)");
                        
  //-- Grafica con Amplitud global normalizada
  sprintf (file,"Range_Pn_%s_Agn.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data(param_lower, param_upper,file,
                        func_AGN,"AG vs A",
                        title,
                        xlabel[param],
                        "Amplitud Global Normalizada");
                        
  //-- Grafica con DY Normalizada
  sprintf (file,"Range_Pn_%s_DYN.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data(param_lower, param_upper,file,
                        func_DYN,"DY Normalizada",
                        title,
                        xlabel[param],
                        "DY Normalizada");
                        
  //-- Grafica con la distancia total (DL) desplazada
  sprintf (file,"Range_Pn_%s_DL.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);

  T1D_file_octave_data(param_lower, param_upper,file,
                       func_DL,"DL",
                       title,
                       xlabel[param],
                       "Distancia DL");
  
 
  
 
}
