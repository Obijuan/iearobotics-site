/*---------------------------------------------------------------------------*/
/**  \file Range_PYn.cpp
  *  \brief Calculate the kinematics when somme parameters change 
  *
  *  Different octave files are generated with the results of the experiment
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date February 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include <ctype.h>

#include "T1D.h"
#include "Rtk-3D.h"

/****************************/
/* CONSTANTES               */
/****************************/
#define PARAM_T    1
#define PARAM_Av   2
#define PARAM_Ah   3
#define PARAM_Oh   4
#define PARAM_Ov   5
#define PARAM_DFv  6
#define PARAM_DFh  7
#define PARAM_DFvh 8


#define MAX_RANGE 361
/****************************/
/* VARIABLES                */
/****************************/
static T1D_Robot worm;
static int ciclos_ini;
static int ciclos;

//-- Valor de DFvh inicial
static int DFvh_ini=0;

//-- Valor de DFh inicial
static int DFh_ini=0;

//-- Parametro a variar
static int param;

//-- Rango del parametro
static int param_lower;
static int param_upper;

static dReal func_period[MAX_RANGE];
static dReal func_DX[MAX_RANGE];
static dReal func_DY[MAX_RANGE];
static dReal func_VX[MAX_RANGE];
static dReal func_VY[MAX_RANGE];
static dReal func_YAW[MAX_RANGE];
static dReal func_ROLL[MAX_RANGE];
static dReal func_WYAW[MAX_RANGE];
static dReal func_WROLL[MAX_RANGE];
static dReal func_DL[MAX_RANGE];

//-- Cadenas asociadas a los paramtros
static char param_str[][5]={
  "","T","Av","Ah","Oh","Ov","DFv","DFh","DFvh"
};

//-- Etiquetas para el eje X
static char xlabel[][255]={
  "",
  "Numero de muestras (T)",
  "Amplitud Av (grados)",
  "Amplitud Ah (grados)",
  "Offset Ov (grados)",
  "Offset Oh (grados)",
  "Diferencia de fase DFv (grados)",
  "Diferencia de fase DFh (grados)",
  "Diferencia de fase DFvh (grados)",
};


/***************************************************/
/* Simulacion de un paso                           */
/* Devuelve false cuando se ha terminado           */
/***************************************************/
static bool simLoop (void)
{
  
  //-- Realizar un paso de simulacion
  T1D_step(&worm);
    
  //-- Comprobar timeout
  if (worm.timeout) {
    printf ("Timeout!!\n");
    return false;
  }  
  
  //-- Al terminar un intervalo finaliza la simulacion
  if (worm.intervalo_transicion && worm.intervalo_numero==2) {
    return false;
  }  
    
  return true;
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Range_PYn c_ini c param ini fin Num_mod [A T F O,...] [P | Y | X]\n");
  printf ("donde,\n");
  printf ("  -Ai es la amplitud en grados (0-90)\n");
  printf ("  -Ti es el periodo \n");
  printf ("  -Fi es la fase    \n");
  printf ("  -Oi es el offset  \n");
  printf ("Ejemplo:\n");
  printf ("  Range_PYn 1 2 Av 0 90 `./PYn 3 10 45 45 0 0 0 0 60`\n");
}


/*************************************/
/* Pasar una cadena a mayusculas     */
/*************************************/
static void upcase(char *cad)
{
  for (unsigned int i=0; i<strlen(cad); i++) {
    cad[i]=toupper(cad[i]);
  }  
}

/************************************************/
/* Devolver el tipo de parametro                */
/************************************************/
int get_range_param(char *param, int *param_type)
{
   upcase(param);
  
  if (strcmp(param,"T")==0) {
    *param_type=PARAM_T;
    return 1;
  }else if (strcmp(param,"AV")==0) {
    *param_type=PARAM_Av;
    return 1;
  }else if (strcmp(param,"AH")==0) {
    *param_type=PARAM_Ah;
    return 1;
  }else if (strcmp(param,"OV")==0) {
    *param_type=PARAM_Ov;
    return 1;
  }else if (strcmp(param,"OH")==0) {
    *param_type=PARAM_Oh;
    return 1;
  }else if (strcmp(param,"DFV")==0) {
    *param_type=PARAM_DFv;
    return 1;
  }else if (strcmp(param,"DFH")==0) {
    *param_type=PARAM_DFh;
    return 1;
  }else if (strcmp(param,"DFVH")==0) {
    *param_type=PARAM_DFvh;
    return 1;
  }else {
    return 0;
  }   
  
  return 1;
}

void print_param_type(int param_type)
{
  printf ("%s",param_str[param_type]);
}


/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static void analizar_parametros(int argc, char* argv[])
{
  int ok;

  //-- Comprobar que estan todos los parametros
  if (argc<12) {
    help();
    exit(1);
  }
  
  //-- Leer ciclo inicial y numero de ciclos
  ciclos_ini=atoi(argv[1]);
  ciclos=atoi(argv[2]);
  
  //-- Leer el parametro a variar
  ok=get_range_param(argv[3],&param);
  if (!ok) {
    printf ("Parametro %s incorrecto\n",argv[4]);
    help();
    exit(1);
  }
  
  //-- Leer el rango del parametro
  param_lower = atoi(argv[4]);
  param_upper = atoi(argv[5]);

  //-- Analizar resto de parametros
  ok=T1D_get_args(&worm,argc-5,&argv[5],true);
  
  if (!ok) {
    printf ("Error aqui!!\n");
    help();
    exit(1);
  } 
}


void tomar_medidas()
{
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,true,false);
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  //-- DEBUG!!! Imprimir los valores de los cpgs
  /*for (int i=0; i<worm.nm; i++) {
    printf ("   [%d] A: %d, T: %d, O: %d, F: %d\n",
           i,
           worm.cpg_A[i],
           worm.cpg_T[i],
           worm.cpg_O[i],
           worm.cpg_F[i]);
  }*/
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  
  do {
  } while (simLoop());
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
}


/***********************************************/
/* Asignar un valor al parametro especificado  */
/***********************************************/
void asignar_param(int param, int value)
{
  for (int i=0; i<worm.nm; i++) {
    
    switch(param) {
      case PARAM_T:
        worm.cpg_T[i]=value;
        break;
      
      case PARAM_Av:
         //-- Solo para los modulos Pitch
         if (i%2==0) {
           worm.cpg_A[i]=value;
         }  
         break;
         
      case PARAM_Ah:
        //-- Solo para los modulos Yaw
        if (i%2!=0) {
          worm.cpg_A[i]=value;
        }
        break;
        
      case PARAM_Ov: 
        //-- Solo para los modulos Pitch
        if (i%2==0) {
          worm.cpg_O[i]=value;
        }  
        break;

      case PARAM_Oh:
        //-- Solo para los modulos Yaw
        if (i%2!=0) {
          worm.cpg_O[i]=value;
        }
        break;

      case PARAM_DFv: 
        //-- Solo para los modulos Pitch
        if (i%2==0) {
          worm.cpg_F[i]=i*value/2;
        }  
        break;

      case PARAM_DFh: 
        //-- Solo para los modulos Yaw
        if (i%2!=0) {
          worm.cpg_F[i]=DFvh_ini+(i-1)*value/2;
        }  
        break;     

      case PARAM_DFvh: 
        //-- Solo para los modulos Yaw
        if (i%2!=0) {
           worm.cpg_F[i]=value + (i-1)*DFh_ini/2;
        }  
        break;           
      
      default:
        printf ("Warning!!!!\n");        
    } 
  }
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  //-- Analizar parametros pasados por el usuario
  analizar_parametros(argc,argv);
  
  //-- Obtener el valor de DFvh inicial
  DFvh_ini = worm.cpg_F[1] - worm.cpg_F[0];
  
  //-- Obtener el valor de DFh inicial
  DFh_ini = worm.cpg_F[3]-worm.cpg_F[1];
  
  printf ("Ciclo inicial         : %d\n",ciclos_ini);
  printf ("Numero de ciclos      : %d\n",ciclos);
  printf ("Parametro             : ");
  print_param_type(param);
  printf ("\n");
  printf ("Valor inferior        : %d\n",param_lower);
  printf ("Valor superior        : %d\n",param_upper);
  printf ("Numero de modulos     : %d\n",worm.nm);
  printf ("DFvh                  : %d\n",DFvh_ini);
  printf ("DFh                   : %d\n",DFh_ini);
  printf ("\n");

  
  for (int i=param_lower; i<=param_upper; i++) {
    //-- Asignar siguiente valor al parametro
    asignar_param(param,i);
    
    //-- Realizar la simulacion
    tomar_medidas();
    
    //-- Almacenar resultado de la simulacion
    func_period[i]=worm.intervalo_duracion/worm.intervalo_ciclos;
    func_DX[i]=worm.xinc_int/worm.intervalo_ciclos;
    func_DY[i]=worm.yinc_int/worm.intervalo_ciclos;
    func_VX[i]=worm.vx_int;
    func_VY[i]=worm.vy_int;
    func_YAW[i]=RTK_TO_GRADOS(worm.yawinc_int/worm.intervalo_ciclos);
    func_ROLL[i]=RTK_TO_GRADOS(worm.rollinc_int/worm.intervalo_ciclos);
    func_WYAW[i]=RTK_TO_GRADOS(worm.wyaw_int);
    func_WROLL[i]=RTK_TO_GRADOS(worm.wroll_int);
    
    //-- Almacenar Distancia total
    func_DL[i]=sqrt(func_DX[i]*func_DX[i] + func_DY[i]*func_DY[i]);
    
    //-- Imprimir
    printf ("%s: %d, DX=%.2f, DY=%.2f, VX=%.2f, VY=%.2f, YAW: %.2f, ROLL: %.2f\n",
            param_str[param],i,
            func_DX[i],func_DY[i],
            func_VX[i],func_VY[i],
            func_YAW[i],func_ROLL[i]);
  } 
  
  //------------ Generar las graficas --------------
  
  //-- Grafica del periodo
  char file[255];
  char title[255];
  sprintf (file,"Range_PYn_%s_period.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data(param_lower, param_upper,file,
                        func_period,"Periodo",
                        title,
                        xlabel[param],
                        "Periodo (ticks de 0.01 seg)");
  
  //-- Grafica con DX y DY
  sprintf (file,"Range_PYn_%s_rcm.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_DX,"DX",func_DY,"DY",
                        title,
                        xlabel[param],
                        "Distancia (cm)");
  
  //-- Grafica con Vx, Vy
  sprintf (file,"Range_PYn_%s_vcm.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_VX,"VX",func_VY,"VY",
                        title,
                        xlabel[param],
                        "Velocidad (cm/s)");
  
  //-- Grafica con Yaw, Roll
  sprintf (file,"Range_PYn_%s_rot.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_YAW,"YAW",func_ROLL,"ROLL",
                        title,
                        xlabel[param],
                        "Angulo rotado (grados)");
  
  //-- Grafica con WYaw, WRoll
  sprintf (file,"Range_PYn_%s_wrot.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);
  
  T1D_file_octave_data2(param_lower, param_upper,file,
                        func_WYAW,"WYAW",func_WROLL,"WROLL",
                        title,
                        xlabel[param],
                        "Velocidad angular (grados/seg)");
  
  //-- Grafica con la distancia total (DL) desplazada
  sprintf (file,"Range_PYn_%s_DL.m",param_str[param]);
  sprintf (title,"Espectro %s",param_str[param]);

  T1D_file_octave_data(param_lower, param_upper,file,
                       func_DL,"DL",
                       title,
                       xlabel[param],
                       "Distancia DL");
 
}
