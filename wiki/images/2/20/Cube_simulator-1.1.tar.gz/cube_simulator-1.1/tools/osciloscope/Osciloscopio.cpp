/*---------------------------------------------------------------------------*/
/**  \file Osciloscopio.cpp
  *  \brief Data aquisition for Pn and PYn configurations
  *
  *  Only one robot is used to collect the data
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include <ctype.h>
#include "T1D.h"
#include "Rtk-3D.h"

#define MAX_TICKS 50000

//-- 0.001 alta resolucion
//-- 0.01  resolucion normal
#define STEP 0.01
#define MU 0.2


/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

//-- Almacenamiento de la cinematica global del robot
static dReal pitch[MAX_TICKS];
static dReal yaw[MAX_TICKS];
static dReal roll[MAX_TICKS];

static dReal wpitch[MAX_TICKS];
static dReal wyaw[MAX_TICKS];
static dReal wroll[MAX_TICKS];

static dReal x[MAX_TICKS];
static dReal y[MAX_TICKS];
static dReal z[MAX_TICKS];

static dReal vx[MAX_TICKS];
static dReal vy[MAX_TICKS];
static dReal vz[MAX_TICKS];

//-- Almacenamiento de la informacion local de cada modulo
static dReal phi[RTK_MAX_MOD][MAX_TICKS];
static dReal w[RTK_MAX_MOD][MAX_TICKS];

//-- Almacenar el tiempo en el que se alcanzan las posiciones de referencia 
static int pos_ref_time[256*20];
static int n=0;

//-- Almacenar el instante en el que acaba el intervalo
static int fin_intervalo=0;

//-- Almacenar los parametros leidos
int ciclo_ini;   //-- ciclo inicial
int ciclos;      //-- Numero de ciclos
int param_estructura;  //-- Tipo de estructura PYn o Pn


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='1') {
    
  }
  else if (cmd=='q') {
    dsStop();
  }
	
}

/**************************************************************/
/* Generar un fichero con la velocidad angular de los servos  */
/**************************************************************/
static void generar_Pn_w(char fich[])
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  
  //-- Generar la declaracion de las matrices de octave
  for (int m=0; m<worm.nm; m++) {
    fprintf (fd,"w%d=[",m);
    for (int i=0; i<worm.intervalo_ticks; i++)
      fprintf (fd,"%f,",w[m][i]);
    fprintf (fd,"];\n");
  }
  
  fprintf (fd,"t=[0:1:%d];\n",(worm.intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Velocidad del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",worm.sim.step);
  fprintf (fd,"ylabel('Velocidad (Grad/Seg)')\n");
  fprintf (fd,"axis([0,%d,-300, 300])\n",worm.intervalo_ticks);
 
  fprintf (fd,"plot(");
  for (int m=0; m<worm.nm; m++) {
    if (m>0) fprintf (fd,",");
    fprintf (fd,"t,w%d,';Servo %d;'",m,m+1);
  }
  fprintf (fd,");\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  printf ("----> Fichero %s creado!!!\n",fich);
 
}

/********************************************************************/
/* Generar el fichero con la posicion de los servos (phi) y las     */
/* Posiciones de referencia p                                       */
/********************************************************************/
static void generar_Pn_Phi_ts(char fich[])
{
  FILE *fd;
  
  
 for (int i=0; i<=n; i++) {
   printf ("ts%d=%d\n",i,pos_ref_time[i]);
 }
  
  
  
  fd = fopen(fich,"w");
  
  //-- Generar la declaracion de las matrices de octave
  for (int m=0; m<worm.nm; m++) {
    fprintf (fd,"phi%d=[",m);
    for (int i=0; i<worm.intervalo_ticks; i++)
      fprintf (fd,"%f,",phi[m][i]);
    fprintf (fd,"];\n");
  }
  
  int im=0;
  
  //-- Posiciones de referencia
  for (int m=0; m<worm.nm; m++) {
    fprintf (fd,"F%d=[",im);
    
    for (int i=1; i<n; i++) {
      im = i % worm.sf[m].N;
      
      fprintf (fd,"%f,",worm.sf[m].f[im]);
    }
    
    //fprintf (fd,"];\n");
    
    fprintf (fd,"%f,%f];\n",worm.sf[m].f[0],worm.sf[m].f[0]);
  }
  
  //-- Tiempos de las posiciones de referencia
  fprintf (fd,"n=[");
  for (int i=0; i<=n; i++)
    fprintf (fd,"%d,",pos_ref_time[i]);
  fprintf (fd,"];\n");
  
 // fprintf (fd,"n=[0:1:%d];\n",worm.sf[0].N);
  
  fprintf (fd,"t=[0:1:%d];\n",(worm.intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion de los servos y sus referencias')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",worm.sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"axis([0,%d,-95, 95])\n",worm.intervalo_ticks);
  
  fprintf (fd,"plot(");
  for (int m=0; m<worm.nm; m++) {   // m<worm.nm
    if (m>0) fprintf (fd,",");
    fprintf (fd,"t,phi%d,';Servo %d;',n,F%d,'L; Ref %d;'",m,m+1,m,m+1);
  }
  
  fprintf (fd,");\n");
   
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("----> Fichero %s creado!!!\n",fich);
}


/********************************************************************/
/* Generar el fichero con la posicion de los servos (phi)           */
/********************************************************************/
static void generar_Pn_phi(char fich[])
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  
  //-- Generar la declaracion de las matrices de octave
  for (int m=0; m<worm.nm; m++) {
    fprintf (fd,"phi%d=[",m);
    for (int i=0; i<worm.intervalo_ticks; i++)
      fprintf (fd,"%f,",phi[m][i]);
    fprintf (fd,"];\n");
  }
  
  fprintf (fd,"t=[0:1:%d];\n",(worm.intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion de los servos')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",worm.sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"axis([0,%d,-90, 90])\n",worm.intervalo_ticks);
  
  fprintf (fd,"plot(");
  for (int m=0; m<worm.nm; m++) {   // m<worm.nm
    if (m>0) fprintf (fd,",");
    fprintf (fd,"t,phi%d,';Servo %d;'",m,m+1);
  }
  fprintf (fd,");\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("----> Fichero %s creado!!!\n",fich);
}

/***************************************************************************/
/* Generar fichero octave con las posiciones de referencia (F) del robot   */
/* ENTRADAS:                                                               */
/*   -fich: Nombre del fichero                                             */
/***************************************************************************/
static void generar_Pn_F(char fich[])
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  
  //-- Generar la declaracion de las matrices de octave
  for (int m=0; m<worm.nm; m++) {
    fprintf (fd,"F%d=[",m);
    for (int i=0; i<worm.sf[m].N; i++)
      fprintf (fd,"%f,",worm.sf[m].f[i]);
    fprintf (fd,"%f];\n",worm.sf[m].f[0]);
  }
  
  fprintf (fd,"t=[0:1:%d];\n",worm.sf[0].N);
  fprintf (fd,"title('Posiciones de referencia de los servos')\n");
  fprintf (fd,"xlabel('Tiempo discreto')\n");
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"grid on;\n");
  
  fprintf (fd,"plot(");
  for (int m=0; m<worm.nm; m++) {
    if (m>0) fprintf (fd,",");
    fprintf (fd,"t,F%d,'-*;Servo %d;'",m,m+1);
  }
  fprintf (fd,");\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("----> Fichero %s creado!!!\n",fich);
  
}



/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    
    //-- Comprobar timeout
    if (worm.timeout)
      //printf ("Timeout!!\n");
    
    //-- Se ejecuta al comienzo de cada nuevo periodo
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
      
      //-- Imprimir duracion del ciclo
      printf ("  Periodo  : %.2f seg\n", worm.period);
      printf ("  Paso ang : Yaw: %.2f grad, Roll: %.2f, Pitch: %.2f\n",
                RTK_TO_GRADOS(worm.yawinc_ciclo),
                RTK_TO_GRADOS(worm.rollinc_ciclo),
                RTK_TO_GRADOS(worm.pitchinc_ciclo));
      printf ("  Vel ang  : WYaw: %.2f, WRoll: %.2f, WPitch: %.2f (grad/seg)\n",
              RTK_TO_GRADOS(worm.wyaw_ciclo),
              RTK_TO_GRADOS(worm.wroll_ciclo),
              RTK_TO_GRADOS(worm.wpitch_ciclo));
      
      printf ("  Paso     : X=%.2f cm,     Y=%.3f cm,     Z=%.2f\n",
           worm.xinc_ciclo,
           worm.yinc_ciclo,
           worm.zinc_ciclo);
      printf ("  Velocidad: X=%.2f cm/seg, Y=%.3f cm/seg, Z=%.2f cm/seg,\n",
           worm.vx_ciclo,
           worm.vy_ciclo,
           worm.vz_ciclo); 
    }  
    
    //-- Se ejecuta al comienzo de un intervalo nuevo
    if (worm.intervalo_transicion) {
      
      //-- Almacenar el instante en el que acaba
      fin_intervalo=(int)(worm.intervalo_duracion/worm.sim.step);
      
      printf ("\n");
      printf ("************************* FIN INTERVALO %d *******************\n",
               worm.intervalo_numero-1);
      printf ("  Duracion intervalo: %.2f\n",worm.intervalo_duracion);
      printf ("  Paso ang : Yaw: %.2f grad, Roll: %.2f, Pitch: %.2f\n",
               RTK_TO_GRADOS(worm.yawinc_int),
               RTK_TO_GRADOS(worm.rollinc_int),
               RTK_TO_GRADOS(worm.pitchinc_int));
      printf ("  Vel ang  : WYaw: %.2f, WRoll: %.2f, WPitch: %.2f (grad/seg)\n",
             RTK_TO_GRADOS(worm.wyaw_int),
             RTK_TO_GRADOS(worm.wroll_int),
             RTK_TO_GRADOS(worm.wpitch_int)); 
      printf ("  Paso     : X=%.2f cm,     Y=%.3f cm,     Z=%.2f\n",
          worm.xinc_int,
          worm.yinc_int,
          worm.zinc_int);
      printf ("  Velocidad: X=%.2f cm/seg, Y=%.3f cm/seg, Z=%.2f cm/seg,\n",
          worm.vx_int,
          worm.vy_int,
          worm.vz_int); 
      printf ("  Zmax: %.2f cm, Ag: %.2f cm, Agn: %.3f\n",
          worm.zmax_ciclo,
          (worm.zmax_ciclo-(ALTURA_mm*0.1/2))/2,
          (worm.zmax_ciclo-(ALTURA_mm*0.1/2))/(2*worm.nm*LONG_mm*0.1));
    }
     
     
    //-- Durante intervalo 1 se capturan los datos
    if (worm.intervalo_numero==1) {
      
      //-- Posicion angular modulo referencia
      yaw[worm.t_int]=RTK_TO_GRADOS(worm.yawinc_acum_int);
      roll[worm.t_int]=RTK_TO_GRADOS(worm.rollinc_acum_int);
      pitch[worm.t_int]=RTK_TO_GRADOS(worm.pitchinc_acum_int);
      
      //-- Velocidad angular modulo de referencia
      wyaw[worm.t_int]=RTK_TO_GRADOS(worm.wyaw);
      wroll[worm.t_int]=RTK_TO_GRADOS(worm.wroll);
      wpitch[worm.t_int]=RTK_TO_GRADOS(worm.wpitch);
      
      //-- Posicion modulo referencia
      z[worm.t_int]=worm.z;
      x[worm.t_int]=worm.x;
      y[worm.t_int]=worm.y;
      
      //-- Velocidad modulo referencia
      vz[worm.t_int]=worm.zinc/worm.sim.step;
      vx[worm.t_int]=worm.xinc/worm.sim.step;
      vy[worm.t_int]=worm.yinc/worm.sim.step;
      
      //-- Leer posicion angular de los modulos
      for (int m=0; m<worm.nm; m++) {
        phi[m][worm.t_int]=Rtk_Y1Module_get_pos_grad(&(worm.mod[m]));
        w[m][worm.t_int]=Rtk_Y1Module_get_vel (&(worm.mod[m]));
      }  
      
      //-- Almacenar los tiempos en los que se alcanzan las posiciones
      //-- solicitadas (tiempo de setup?)
      if (Rtk_Chain_stable(&worm.cadena)) {
        pos_ref_time[n]=worm.t_int;
        n++;
      }  
      
    }
    
    //-- Al terminar intervalo 1 se vuelcan los datos a un fichero
    if (worm.intervalo_transicion && worm.intervalo_numero==2) {
      printf ("\n");
      printf ("------------------------------------------------------------\n");
      
      //-- Almacenar el tiempo final
      pos_ref_time[n]=fin_intervalo;
      
      //-- Generar fichero con las posiciones angulares
      T1D_file_octave_data3(&worm,"OSC_data_rot.m",
                            yaw,"Yaw",pitch,"Pitch",roll,"roll",
                            "Posiciones angulares",
                            "Tiempo (Tics de 0.01 seg)",
                            "Angulo (grados)");
      
      //-- Generar fichero con las posiciones angulares
      T1D_file_octave_data3(&worm,"OSC_data_wrot.m",
                            wyaw,"wYaw",wpitch,"wPitch",wroll,"wroll",
                            "Velocidades angulares",
                            "Tiempo (Tics de 0.01 seg)",
                            "Velocidad angular (grados/seg)");
      
      //-- Generar fichero con las posiciones del modulo de ref.
      T1D_file_octave_data3(&worm,"OSC_data_rcm.m",
                            x,"x",y,"y",z,"z",
                            "Posicion del centro de masas",
                            "Tiempo (Tics de 0.01 seg)",
                            "Distancia (cm)");
      
      //-- Generar fichero con las posiciones del modulo de ref.
      T1D_file_octave_data3(&worm,"OSC_data_vcm.m",
                            vx,"vx",vy,"vy",vz,"vz",
                            "Velocidad del centro de masas",
                            "Tiempo (Tics de 0.01 seg)",
                            "Velocidad (cm/seg)");
                            
    
      //-- Generar los ficheros con los datos de los modulos
      generar_Pn_Phi_ts("OSC_data_phi_ts.m");
      generar_Pn_phi("OSC_data_phi.m");
      generar_Pn_w("OSC_data_w.m");
      generar_Pn_F("OSC_data_F.m");
    
      printf ("------------------------------------------------------------\n");
      
    }
    
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  //usleep(int (sim.step*1000000));	
  //usleep(10);
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Osciloscopio-file ciclo-ini ciclos Estructura Fichero.mvm  \n");
  printf ("donde,\n");
  printf ("  -ciclo-ini: Ciclo inicial a partir del cual comenzar los calculos\n");
  printf ("  -ciclos: Numero de ciclos sobre los que calcular la cinematica\n");
  printf ("  -Estructura: PYn o Pn. Indica el tipo de robot\n");
  printf ("  -Fichero.mvm es un fichero de movimiento en formato .mvm\n");
  printf ("Ejemplo:\n");
  printf ("  Osciloscopio-file 1 2 PYn T1.mvm \n");
}


/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static int analizar_parametros(T1D_Robot *worm,int argc, char* argv[])
{
  int ok;
  
  //-- Si argumentos incorrectos
  if (argc<5) {
    help();
    return 0;
  }
  
  //-- Leer el ciclo inicial
  ciclo_ini=atoi(argv[1]);
  
  //-- Leer la longitud del intervalo
  ciclos=atoi(argv[2]);
  
  if (ciclos<=0) {
    printf ("ERROR. Numero de ciclos incorrectos\n");
    return 0;
  }
  
  //-- Leer la funcion de fitness
  //ok=T1D_get_fitness_type(argv[3],&fitness_type);
  //if (!ok) {
  //  help();
  //  exit(1);
  //}
  
  //-- Analizar parametros pasados por el usuario
  ok=T1D_get_args(worm,argc-2,&argv[2],true);
  
  if (!ok) {
    help();
    exit(1);
  }
   
  return 1;
}



/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  
  //-- Analizar parametros y terminar si hay algun error
  ok=analizar_parametros(&worm,argc,argv);
  if (!ok) return 0;
   
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,true,false);
  
  worm.intervalo_ciclo_ini=ciclo_ini;
  worm.intervalo_ciclos=ciclos;
  
  //-- DEBUG: Usar otra resolucion temporal
  //0.001
  worm.sim.step=STEP;
  worm.sim.mu=MU;
  
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
  
}
