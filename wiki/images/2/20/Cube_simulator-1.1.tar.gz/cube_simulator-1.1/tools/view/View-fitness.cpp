/*---------------------------------------------------------------------------*/
/**  \file View-fitness.cpp
  *  \brief Visualize the movement of Pn configuration when controlled by
  *         sinusoidal CPGs      
  *
  *  Only one configuration is moved.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include "T1D.h"
#include <unistd.h>
#include "Rtk-3D.h"
#include <ctype.h>

#define MAX_TICKS 50000

#define FILENAME "test.m"

//-- 0.001 alta resolucion
//-- 0.01  resolucion normal
#define STEP 0.01
//#define MU 0.02
#define MU 0.4
//#define MU 1.0
//#define MU 0.2

/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;
static int ciclos, ciclos_ini;

static int fitness_type;


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='1') {
    printf ("TIEMPO DE CICLO: %d\n",worm.t);
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
	if (!pause) {
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    
    //-- Comprobar timeout
    if (worm.timeout)
      printf ("Timeout!!\n");    
    
    //-- Se ejecuta al comienzo de cada nuevo periodo
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
      
      //-- Imprimir duracion del ciclo
      printf ("  Periodo  : %.2f seg\n", worm.period);
      printf ("  Paso ang : Yaw: %.2f grad, Roll: %.2f, Pitch: %.2f\n",
                RTK_TO_GRADOS(worm.yawinc_ciclo),
                RTK_TO_GRADOS(worm.rollinc_ciclo),
                RTK_TO_GRADOS(worm.pitchinc_ciclo));
      printf ("  Vel ang  : WYaw: %.2f, WRoll: %.2f, WPitch: %.2f (grad/seg)\n",
              RTK_TO_GRADOS(worm.wyaw_ciclo),
              RTK_TO_GRADOS(worm.wroll_ciclo),
              RTK_TO_GRADOS(worm.wpitch_ciclo));
      
      printf ("  Paso     : DX=%.2f cm,     DY=%.3f cm,     DZ=%.2f\n",
           worm.xinc_ciclo,
           worm.yinc_ciclo,
           worm.zinc_ciclo);
      printf ("  Velocidad: VX=%.2f cm/seg, VY=%.3f cm/seg, VZ=%.2f cm/seg,\n",
           worm.vx_ciclo,
           worm.vy_ciclo,
           worm.vz_ciclo); 
           
      if (worm.volcado_ciclo)
        printf ("  VOLCADO!\n");
    }    
    
    if (worm.intervalo_transicion) {
      printf ("******** FIN INTERVALO %d ************************************\n",
               worm.intervalo_numero-1);
      dReal fitness_value;
      
      printf ("  Duracion intervalo: %.2f\n",worm.intervalo_duracion);
      
      printf ("  >>>>>>>> ");
      fitness_value = T1D_get_fitness(&worm,fitness_type);
      T1D_print_fitness_type(fitness_type);
      printf (": %.3f\n",fitness_value);
      printf ("\n");
      
    }
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  //usleep(10);
}

static void help()
{
  printf ("Forma de uso: \n");
  printf ("  View-fitness c_ini c fit Num_mod [A T F O,...] [P | Y | X,...] ..\n");
  printf ("donde,\n");
  printf ("  -c_ini: ciclo inicial desde el que empezar a 'medir'\n");
  printf ("  -ciclos: Numero de ciclos del intervalo a medir\n");
  printf ("  -fit: Tipo de fitness a medir: Dx,Dy,Vx,Vy,Yaw,Roll, W-Yaw, W-Roll\n");
  printf ("  -Num_mod: Numero de modulos\n");
  printf ("  -A es la amplitud en grados (0-90)\n");
  printf ("  -T es el periodo \n");
  printf ("  -F es la fase    \n");
  printf ("  -O es el offset  \n");
  printf ("  -'P'-> Modulo Pitch\n");
  printf ("  -'Y'-> Modulo Yaw\n");
  printf ("  -'X'-> Modulo no usado\n");
 
  printf ("Ejemplo:\n");
  printf ("  View-fitness 1 2 DY 3  45 10 0 0  45 10 60 0  45 10 120 0  P P P\n");
}


void upcase(char *cad)
{
  for (unsigned int i=0; i<strlen(cad); i++) {
    cad[i]=toupper(cad[i]);
  }  
}


void analizar_parametros(int argc, char* argv[])
{
  int ok;

  if (argc<6) {
    help();
    exit(1);
  }
  
  ciclos_ini=atoi(argv[1]);
  ciclos=atoi(argv[2]);
  
  //-- Leer la funcion de fitness
  ok=T1D_get_fitness_type(argv[3],&fitness_type);
  if (!ok) {
    help();
    exit(1);
  }
  
  //-- Analizar parametros pasados por el usuario
  ok=T1D_get_args(&worm,argc-3,&argv[3],true);
  
  if (!ok) {
    help();
    exit(1);
  }
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
 
  //-- Analizar parametros
  analizar_parametros(argc,argv); 
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,true,false);
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  worm.sim.step=STEP;
  worm.sim.mu=MU;
  
  printf ("Paso de simulacion    : %f\n",STEP);
  printf ("Coef. Rozamiento      : %f\n",MU);
  
  printf ("FUNCION DE FITNESS: ");
  T1D_print_fitness_type(fitness_type);
  printf ("\n");
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
  
}
