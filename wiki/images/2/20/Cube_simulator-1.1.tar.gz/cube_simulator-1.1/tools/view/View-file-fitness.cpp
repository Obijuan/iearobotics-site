/*---------------------------------------------------------------------------*/
/**  \file View-file-fitness.cpp
  *  \brief Visualize the movement of the robot and get the data
  *
  *  Only one configuration is moved. The generators are create from a file
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include "T1D.h"
#include <unistd.h>
#include "Rtk-3D.h"
#include <ctype.h>

#define MAX_TICKS 50000

#define FILENAME "test.m"


/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;
static int ciclos, ciclos_ini;

static int fitness_type;
int param_estructura;  //-- Tipo de estructura PYn o Pn

/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='1') {
    
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    
    //-- Comprobar timeout
    if (worm.timeout)
      printf ("Timeout!!\n");    
    
    //-- Se ejecuta al comienzo de cada nuevo periodo
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
      
      //-- Imprimir duracion del ciclo
      printf ("  Periodo  : %.2f seg\n", worm.period);
      printf ("  Paso ang : Yaw: %.2f grad, Roll: %.2f, Pitch: %.2f\n",
                RTK_TO_GRADOS(worm.yawinc_ciclo),
                RTK_TO_GRADOS(worm.rollinc_ciclo),
                RTK_TO_GRADOS(worm.pitchinc_ciclo));
      printf ("  Vel ang  : WYaw: %.2f, WRoll: %.2f, WPitch: %.2f (grad/seg)\n",
              RTK_TO_GRADOS(worm.wyaw_ciclo),
              RTK_TO_GRADOS(worm.wroll_ciclo),
              RTK_TO_GRADOS(worm.wpitch_ciclo));
      
      printf ("  Paso     : DX=%.2f cm,     DY=%.3f cm,     DZ=%.2f\n",
           worm.xinc_ciclo,
           worm.yinc_ciclo,
           worm.zinc_ciclo);
      printf ("  Velocidad: VX=%.2f cm/seg, VY=%.3f cm/seg, VZ=%.2f cm/seg,\n",
           worm.vx_ciclo,
           worm.vy_ciclo,
           worm.vz_ciclo); 
           
      if (worm.volcado_ciclo)
        printf ("  VOLCADO!\n");
    }    
    
    if (worm.intervalo_transicion) {
      printf ("******** FIN INTERVALO %d ************************************\n",
               worm.intervalo_numero-1);
      dReal fitness_value;
      
      printf ("  Duracion intervalo: %.2f\n",worm.intervalo_duracion);
      
      printf ("  >>>>>>>> ");
      fitness_value = T1D_get_fitness(&worm,fitness_type);
      T1D_print_fitness_type(fitness_type);
      printf (": %.2f\n",fitness_value);
      printf ("\n");
      
    }
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  usleep(10);
}

static void help()
{
  printf ("Forma de uso: \n");
  printf ("  View-file-fitness c_ini c Estructura Fichero.mvm fit\n");
  printf ("donde,\n");
  printf ("  -c_ini: ciclo inicial desde el que empezar a 'medir'\n");
  printf ("  -ciclos: Numero de ciclos del intervalo a medir\n");
  printf ("  -Estructura: PYn o Pn. Indica el tipo de robot\n");
  printf ("  -Fichero.mvm es un fichero de movimiento en formato .mvm\n");
  printf ("  -fit: Tipo de fitness a medir: Dx,Dy,Vx,Vy,Yaw,Roll, W-Yaw, W-Roll\n");
 
  printf ("Ejemplo:\n");
  printf ("  ./View-file-fitness 1 2 Pn test.mvm DX\n");
}


void upcase(char *cad)
{
  for (unsigned int i=0; i<strlen(cad); i++) {
    cad[i]=toupper(cad[i]);
  }  
}


static int analizar_parametros(T1D_Robot *worm, int argc, char* argv[])
{
  int ok;
  
  //-- Si argumentos incorrectos
  if (argc<6) {
    help();
    return 0;
  }
  
  //-- Leer el ciclo inicial
  ciclos_ini=atoi(argv[1]);
  
  //-- Leer la longitud del intervalo
  ciclos=atoi(argv[2]);
  
  if (ciclos<=0) {
    printf ("ERROR. Numero de ciclos incorrectos\n");
    return 0;
  }
  
  //-- Leer la estructura del robot
  ok = T1D_get_structure_type(argv[3], &param_estructura);
  if (!ok) {
    printf ("Parametro incorrecto: %s\n",argv[3]);
    help();
    return 0;
  }  
  
  //-- Leer todas las funciones del fichero .mvm
  int m=0;
  do {
    ok = Rtk_Sampled_Function_new_from_mvm_file(&(worm->sf[m]), argv[4],m+1);
       
    printf ("Modulo: %d, ok: %d\n",m,ok);
    if (ok==1) m++;
  } while (ok==1);
    
  //-- Almacenar numero de modulos
  worm->nm=m;
  
  //-- Especificar la estructura del robot segun lo que se haya indicado
  //-- en los parametros
  
  if (param_estructura==T1D_PYn) {  //-- Estructura PYn
  
    for (int i=0; i<worm->nm; i++) {
      if (i%2==0)
        worm->estructura[i]=T1D_PITCH;
      else
        worm->estructura[i]=T1D_YAW;
    }
  }
  else {   //-- Estructura Pn
    for (int i=0; i<worm->nm; i++) {
        worm->estructura[i]=T1D_PITCH;
    }
    
  }  
    
  //-- Leer la funcion de fitness
  ok=T1D_get_fitness_type(argv[5],&fitness_type);
  if (!ok) {
    help();
    exit(1);
  }
  
   return 1;
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  
  //-- Analizar parametros
  ok=analizar_parametros(&worm,argc,argv); 
  if (!ok) return 0;
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,false,false);
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  printf ("FUNCION DE FITNESS: ");
  T1D_print_fitness_type(fitness_type);
  printf ("\n");
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
  
}
