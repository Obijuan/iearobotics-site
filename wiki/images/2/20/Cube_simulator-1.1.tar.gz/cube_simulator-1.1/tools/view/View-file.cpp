/*---------------------------------------------------------------------------*/
/**  \file View-file.cpp
  *  \brief Visualization of the movement of Pn and PYn structures
  *
  *  The virtual robots are created and moved according to the .mvm files
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include "T1D.h"
#include "Rtk-3D.h"

#define VIEW_MAX_ROBOTS 10

//-- Separacion entre robots, en cm
#define SEPARACION_cm  10.0

/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm[VIEW_MAX_ROBOTS];

//-- Almacenar los parametros leidos
int param_estructura;  //-- Tipo de estructura PYn o Pn

//-- Numero de robots
int robot_num=0;

//-- Separacion entre robots, en cm
dReal separacion_cm=SEPARACION_cm;

//-- Robogets de la simulacion
RtkSimulationEngine sim;
RtkRobotGroup       group;


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='1') {
    
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim); 
  }
	
  //-- Renderizar
  Rtk_3D_render(&sim);
  usleep(10);
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  View-file  Est Fich.mvm  [Est Fich.mvm] [separacion]\n");
  printf ("donde,\n");
  printf ("  -Est: Estructura del robot: PYn o Pn.\n");
  printf ("  -Fich.mvm es un fichero de movimiento en formato .mvm\n");
  printf ("  -separacion: separacion entre robots en cm\n");
  printf ("Ejemplos:\n");
  printf ("  View-file PYn T1.mvm \n");
  printf ("  View-file Pn t1.mvm PYn t2.mvm 20\n");
  printf ("Se pueden especificar tantos pares estructura-fichero como se quieran\n");
}

/*************************************************/
/* Construir un nuevo robot segun su estructura  */
/*************************************************/
static void New_robot(T1D_Robot *worm)
{
  //-- Calcular el modulo de referencia: modulo central.
  if (worm->nm%2==0) 
     worm->mod_ref=(worm->nm/2)-1;   //-- Si numero par de modulos
  else 
     worm->mod_ref=(worm->nm-1)/2;   //-- Si numero impar
  
  //-- Crear la cadena
  Rtk_Chain_new(&(worm->cadena));
  
  for (int i=0; i<worm->nm; i++) {
    
    //-- Modulo Y1
    Rtk_Y1Module_new(&(worm->mod[i]));
    
    //-- Asignar servo fisico
    worm->mod[i].servo_real=worm->conexion[i+1];
    
    //-- Puede ser de tipo Pitch o Yaw
    if (worm->estructura[i]==T1D_YAW) {
      worm->mod[i].pitch=0;
      
      //-- Las de tipo Yaw se pintan en rojo
      worm->mod[i].red=1;
      worm->mod[i].green=0;
      worm->mod[i].blue=0;
    }  
    else if (worm->estructura[i]==T1D_PITCH){
      //-- Para las de tipo pitch se usan los colores por defecto
      worm->mod[i].pitch=1;
    }
    else {
      //-- Los deshabilitados se dibujan en blanco
      worm->mod[i].pitch=1;
      worm->mod[i].red=1;
      worm->mod[i].green=1;
      worm->mod[i].blue=1;
    }
    
    //-- Generador
    Rtk_Generator_new(&(worm->gen[i]));
    
    //-- Anadir generador al modulo Y1
    Rtk_Y1Module_generator_add(&(worm->mod[i]),&(worm->gen[i]));
         
    //-- Asignar la funcion al generador
    Rtk_Generator_set_func(&(worm->gen[i]),&(worm->sf[i]));
    
    //-- Anadir modulo a la cadena
    Rtk_Chain_add(&(worm->cadena), &(worm->mod[i]));
  }
  
  //-- Robot 
  Rtk_Robot_new(&(worm->robot));
  Rtk_Robot_add(&(worm->robot),&(worm->cadena),worm->cadena.type);
}

/**************************************************************************/
/* Obtener los parametos estructura y fichero.mvm. Cargar los datos en el */
/* robot especificado                                                     */
/**************************************************************************/
int get_structure(T1D_Robot *worm, char *argv[])
{
  int ok;
  
  //-- Leer la estructura del robot
  ok = T1D_get_structure_type(argv[0], &param_estructura);
  if (!ok) {
    printf ("Parametro incorrecto: %s\n",argv[0]);
    help();
    return 0;
  }  
  
  //-- Leer todas las funciones del fichero .mvm
  int m=0;
  do {
    ok = Rtk_Sampled_Function_new_from_mvm_file(&(worm->sf[m]), argv[1],m+1);
       
    //printf ("Modulo: %d, ok: %d\n",m,ok);
    if (ok==1) m++;
  } while (ok==1);
    
  //-- Almacenar numero de modulos
  worm->nm=m;
  
  //-- Especificar la estructura del robot segun lo que se haya indicado
  //-- en los parametros
  T1D_set_structure(worm,param_estructura);
   
  return 1;
  
}

/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static int analizar_parametros(T1D_Robot *worm,int argc, char* argv[])
{
  int ok;
  int i;
  
  //-- Si argumentos incorrectos
  if (argc<3) {
    help();
    return 0;
  }
  
  //-- Procesar los argumentos por pares: estructura + fichero
  for (i=0; i<(argc-1)/2; i++) {
    
    //-- Leer parametros
    ok=get_structure(&worm[i],&argv[2*i+1]);
    
    //-- Si hay error terminar
    if (!ok) return 0;
  }
  
  robot_num = i;
  
  //-- Obtener la separacion entre robots, en cm
  //-- Si el numero de argumentos es par (sin contar el nombre del programa)
  //-- entonces no se ha especificado sepacion.
  if ( ((argc-1) % 2) == 0) {
    separacion_cm=SEPARACION_cm;
  }  
  else {
    separacion_cm = atoi(argv[argc-1]);
    if (separacion_cm==0) {
      printf ("Error en la separacion entre robots: %s\n",argv[argc-1]);
      help();
      return 0;
    }
  }
    
  return ok;
 
}



/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  
  //-- Analizar parametros y terminar si hay algun error
  ok=analizar_parametros(&worm[0],argc,argv);
  if (!ok) return 0;
    
  printf ("Numero de robots: %d\n",robot_num);
  
  //-- Crear el grupo de robots
  Rtk_Robot_Group_new(&group);
  
  //-- Construir las ocnfiguraciones e incluirlas en el grupo de robots
  for (int r=0; r<robot_num; r++) {
    
    //-- Crear robot
    New_robot(&worm[r]);
    
    //-- Establecer posicion inicial
    Rtk_Chain_set_initial_pos(&(worm[r].cadena), 
                               r*(separacion_cm/100.0), 0.0, 0.0);
    
    //-- Anadir robot al grupo
    Rtk_Robot_Group_add(&group, &(worm[r].robot));
  }  
  
  /*----------------------------*/
  /* CREAR LA SIMULACION        */
  /*----------------------------*/
  Rtk_Simulation_Engine_new(&sim);
  
  //-- Anadir los robots a la simulacion
  Rtk_Simulation_Engine_Add(&sim,&group,group.type);
 
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&sim);
  
}
