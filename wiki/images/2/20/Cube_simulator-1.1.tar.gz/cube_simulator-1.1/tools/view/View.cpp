/*---------------------------------------------------------------------------*/
/**  \file View.cpp
  *  \brief Visualize the movement of Pn configuration when controlled by
  *         sinusoidal CPGs      
  *
  *  Only one configuration is moved.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include "T1D.h"
#include <unistd.h>
#include "Rtk-3D.h"


/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
	if (cmd=='1') {
    
  }
  else if (cmd=='2') {
    printf ("TIEMPO DE CICLO--: %d\n",worm.t);
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    
   
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
      
      //-- Imprimir duracion del ciclo
      printf ("  Periodo  : %.2f seg\n", worm.period);
    }
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  usleep(10);
}

static void help()
{
  printf ("Forma de uso: \n");
  printf ("  View Num_mod [A T F O,...] [P | Y | X, ...] ...\n");
  printf ("donde,\n");
  printf ("  -Num_mod: Numero de modulos\n");
  printf ("  -A es la amplitud en grados (0-90)\n");
  printf ("  -T es el periodo \n");
  printf ("  -F es la fase    \n");
  printf ("  -O es el offset  \n");
  printf ("  -'P'-> Modulo Pitch\n");
  printf ("  -'Y'-> Modulo Yaw\n");
  printf ("  -'X'-> Modulo no usado\n");
 
  printf ("Ejemplo:\n");
  printf ("  View 3  45 10 0 0  45 10 60 0  45 10 120 0  P P P\n");
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  
  //-- Analizar parametros pasados por el usuario
  ok=T1D_get_args(&worm,argc,argv,true);
  
  if (!ok) {
    help();
    exit(1);
  }
   
  //-- CONSTRUIR CONFIGURACION 
  T1D_new_robot(&worm,true,false);
  
  worm.sim.mu=0.2;
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
  
}
