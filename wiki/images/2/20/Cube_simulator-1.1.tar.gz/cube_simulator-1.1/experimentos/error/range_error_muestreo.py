#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

import sys;
import math;
from math import sin;

try: 
  Nmax=int(sys.argv[1])
except:
  print "Tomando Nmax=20"
  Nmax=20

Emax=[]

for N in range(2,Nmax+1): 
  Error=[]
  for fase_ini in range(-180,180+1):
    senal=[]
    for i in range(N):
      senal.append(round(90*sin(2*math.pi*i/N + fase_ini*math.pi/180)))
    Aref = max(senal)
    Error.append(90 - Aref)
  #-- Calcular el error maximo
  Emax.append(max(Error))
  print "N: %d. Error max: %d" % (N,Emax[N-2])

salida= """

   F= %s;
   t=[2:1:%d];
   grid on;
   title('Error de muestreo')
   xlabel('Phase (en grados)')
   ylabel('Error (en grados)')
   axis([2,%d,0, 90])

   plot(t,F,';Error maximo;');
   pause;
   
""" % (str(Emax),Nmax,Nmax)

#-- Escribir en un fichero
fich="range_error_muestreo.m"

f=open(fich,'w')
f.write(salida)
f.close()

print "Fichero: " + fich
print ""
