#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

import sys;
import math;
from math import sin;

try: 
  N=int(sys.argv[1])
except:
  print "Error en parametro. Tomando N=2"
  N=2

fase_ini = 0;
senal=[];
rango=180
Error=[]

for fase_ini in range(-rango,rango+1):
  senal=[]
  for i in range(N):
    senal.append(round(90*sin(2*math.pi*i/N + fase_ini*math.pi/180)))
  Aref = max(senal)
  Error.append(90 - Aref)

#print "N: %d. Error min: %d, Error max: %d" % (N,min(Error),max(Error))

salida= """

   F= %s;
   t=[0:1:360];
   grid on;
   title('Error de muestreo')
   xlabel('Phase (en grados)')
   ylabel('Error (en grados)')
   axis([0,360,0, 90])

   plot(t,F,';N=%d;');
   pause;
   
""" % (str(Error),N)

#-- Escribir en un fichero
fich="error_muestreo_N%d.m" % (N)

f=open(fich,'w')
f.write(salida)
f.close()

print "Fichero: " + fich
print ""
