#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

#-- Calculo del error de muestra cuando la fase esta fijada, y lo que
#-- varia es N

import sys;
import math;
from math import sin;

#-- X es la fase
XMIN=0
XSTEP=5
XMAX=360


#-- Y es el numero de muestras N
YMIN=2
YMAX=20


Z="["
for y in range(YMIN,YMAX+1):
  for x in range(XMIN,XMAX+1,XSTEP):
    senal=[]
    #-- Calcular las muestras de la senal
    for i in range(y):
      senal.append(round(90*sin(2*math.pi*i/y + x*math.pi/180)))
      
    #-- Calcular error muestre de esa senal
    Error = 90 - max(senal) 
    Z=Z+ " %d" % (Error)
  Z=Z+";"

Z=Z+"];"


#~ for N in range(2,Nmax+1):
  #~ senal=[]
  #~ for i in range(N):
    #~ senal.append(round(90*sin(2*math.pi*i/N + fase_ini*math.pi/180)))
  #~ Aref = (max(senal) - min(senal))/2
  #~ Error.append(90 - Aref)


salida= """
x=[%d:%d:%d];
y=[%d:%d];
[X,Y]=meshgrid(x,y);
Z=%s
xlabel('Fase');
ylabel('Muestras (N)');
title('Error de muestreo');
grid on;
mesh(X,Y,Z);
view(130,40)
pause;
   
""" % (XMIN,XSTEP,XMAX,YMIN,YMAX,Z)

#-- Escribir en un fichero
fich="error_muestreo_FASE_N.m"

f=open(fich,'w')
f.write(salida)
f.close()

print "Fichero: " + fich
print ""
