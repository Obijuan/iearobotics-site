/*---------------------------------------------------------------------------*/
/**  \file Espectro_N_modulo.cpp
  *  \brief Calculate the relationship between N (samples) and T (period)
  *
  *  Calculate the relantionship between N and T
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date April 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include <ctype.h>

#include "T1D.h"
#include "Rtk-3D.h"

/****************************/
/* CONSTANTES               */
/****************************/
#define PARAM_T    1
#define PARAM_A    2
#define PARAM_O    3
#define PARAM_DF   4


#define MAX_RANGE 361
/****************************/
/* VARIABLES                */
/****************************/
static T1D_Robot worm;
static int ciclos_ini;
static int ciclos;

//-- Posiciones de referencia inicial y final
static int p0,p1;

//-- Rango del parametro
static int param_lower;
static int param_upper;

static dReal func_period[MAX_RANGE];


/***************************************************/
/* Simulacion de un paso                           */
/* Devuelve false cuando se ha terminado           */
/***************************************************/
static bool simLoop (void)
{
  
  //-- Realizar un paso de simulacion
  T1D_step(&worm);
    
  //-- Comprobar timeout
  if (worm.timeout) {
    //printf ("Timeout!!\n");
    //return false;
  }  
  
  //-- Al terminar un intervalo finaliza la simulacion
  if (worm.intervalo_transicion && worm.intervalo_numero==2) {
    return false;
  }  
    
  return true;
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Espectro_N_modulo c_ini c ini fin pos_ref_ini pos_ref_fin\n");
  printf ("donde,\n");
  printf ("  -c_ini: periodo inicial\n");
  printf ("  -c: Numero de ciclos\n");
  printf ("  -ini: Valor inicial de N\n");
  printf ("  -fin: Valor final de N\n");
  printf ("  -pos_ref_ini: Posicion de referencia inicial\n");
  printf ("  -pos_ref_fin: Posicion de referencia final\n");
  printf ("Ejemplo:\n");
  printf ("  ./Espectro_N_modulo 2 1 2 255 0 90\n");
}


/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static void analizar_parametros(int argc, char* argv[])
{
  int ok;
  
  //-- Esta cadena se usa para poder utilizar la funcion
  //-- T1D_get_args. Es como si se hubiesen utilizado estos
  //-- parametros en la liena de comandos, pero no se usan
  char *cads[]={"X","1","90","2","90","0","P"};

  //-- Comprobar que estan todos los parametros
  if (argc<7) {
    help();
    exit(1);
  }
  
  //-- Leer ciclo inicial y numero de ciclos
  ciclos_ini=atoi(argv[1]);
  ciclos=atoi(argv[2]);
  
  //-- Leer el rango del parametro
  param_lower = atoi(argv[3]);
  param_upper = atoi(argv[4]);
  
  //-- Leer Posicion de referencia 1
  p0 = atoi(argv[5]);
  
  //-- Leer Posicion de referencia 2
  p1 = atoi(argv[6]);
  
  //-- Analizar resto de parametros. No hay mas parametros. Pero se simula
  //-- que si los hay (como si estuviesen en cads) para llamar a la
  //-- funcion T1D_get_args y que se inicialice todo lo necesario
  //-- Es una chapucilla para no tener que reescribir mucho codigo
  ok=T1D_get_args(&worm,7,cads,true);
  
  if (!ok) {
    printf ("Error aqui!!\n");
    help();
    exit(1);
  } 
}


void tomar_medidas()
{
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,false,false);
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  
  //-- Usar esto para cambiar la resolucion de la simulacion
  //-- Alta: 0.001
  //-- Normal: 0.01
  worm.sim.step=0.001;
  
  //-- DEBUG!!! Imprimir los valores de los cpgs
  /*for (int i=0; i<worm.nm; i++) {
    printf ("   [%d] A: %d, T: %d, O: %d, F: %d\n",
           i,
           worm.cpg_A[i],
           worm.cpg_T[i],
           worm.cpg_O[i],
           worm.cpg_F[i]);
  }*/
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  
  do {
  } while (simLoop());
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
}


/***********************************************/
/* Asignar un valor al parametro especificado  */
/***********************************************/
void asignar_param(int value)
{
  //-- Establecer el numero de muestras
  worm.sf[0].N = value;
  
  //printf ("N=%d\n",value);
  //-- Crear la secuencia
  for (int i=0; i<=value-1; i++) {
    worm.sf[0].f[i]=(i*p1)/(value-1);
    //printf ("%.0f ",worm.sf[0].f[i]);
  }
  //printf ("\n");
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  //-- Analizar parametros pasados por el usuario
  analizar_parametros(argc,argv);
  
  printf ("Ciclo inicial         : %d\n",ciclos_ini);
  printf ("Numero de ciclos      : %d\n",ciclos);
  printf ("Parametro             : N\n");
  printf ("Valor inferior        : %d\n",param_lower);
  printf ("Valor superior        : %d\n",param_upper);
  printf ("Pos ref ini           : %d\n",p0);
  printf ("Pos ref final         : %d\n",p1);
  printf ("Numero de modulos     : %d\n",worm.nm);
  printf ("\n");

  
  for (int i=param_lower; i<=param_upper; i++) {
    //-- Asignar siguiente valor al parametro
    asignar_param(i);
    
    //-- Realizar la simulacion
    tomar_medidas();
    
    //-- Almacenar resultado de la simulacion
    func_period[i]=(worm.intervalo_duracion-0.43)/
                   (worm.intervalo_ciclos*worm.sim.step);
    
    //-- Imprimir
    printf ("N: %d, T=%.2f\n", i, func_period[i]);
  } 
  
  //------------ Generar las graficas --------------
  
  //-- Grafica del periodo
  char file[255];
  char title[255];
  sprintf (file,"Espectro_N_modulo.m");
  sprintf (title,"Espectro N");
  
  T1D_file_octave_data(param_lower, param_upper,file,
                        func_period,"Periodo",
                        title,
                        "Numero de muestras (N)",
                        "Tiempo de simulacion (ticks de 0.01 segundos)");
    
 
}
