/*---------------------------------------------------------------------------*/
/**  \file Osciloscopio-Y1.cpp
  *  \brief Medir la respuesta del servo ante una secuencia cualquiera
  *
  *  Se obtienen las graficas en octave tanto de las posiciones de salida 
  *  como de la velocidad. Solo se obtienen los datos correspondientes al
  *  primer periodo de la senal  \n
  *  Hay renderizado en 3D
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Septiembre 2006                                                   */
/*---------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <ode/ode.h>

#include "Rtk-3D.h"

/*********************************************/
/* Algunas constantes usadas en el programa  */
/*********************************************/
#define TICKS 400              // Numero de ticks a simular
#define MAX_TICKS   10000      // Numero maximo de ticks
#define DEFAULT_SAMPLES 12     // Muestras de la senal usada por defecto

//*******************************************
// VARIABLES GLOBALES DEL PROGRAMA
//*******************************************
//-- RoboGets 
static RtkSimulationEngine sim;
static RtkRobot            robot;
static RtkY1Module         mod;
static RtkGenerator        gen;
static RtkSampledFunction  sf;

//-- Contador de tiempo
static int t=0;

//-- Indice de tiempo para las posiciones de referencia
static int n=0;

//-- Almacenar las muestras de la posicion del servo
static dReal servo_pos[MAX_TICKS];
static dReal servo_vel[MAX_TICKS];
static int pos_ref_time[1000];


//-- FUNCIONES PRIVADAS
static void generar_fichero_servo_data_pos(int ticks);
static void generar_fichero_servo_data_vel(int ticks);
static void generar_fichero_pos_deseada();
static void generar_fichero_servo_data_pos_ref(int ticks);


/***************************************************************************/
/* FUNCIONES DE RETROLLAMADA                                               */
/***************************************************************************/


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='q') {
    dsStop();
  }
}

/***********************************************************************/
/* SIMULACION!!                                                        */
/***********************************************************************/

/***************************************************/
/* Simulacion de un paso                           */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
		
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim);
    
    //-- Check if the first period has been finished
    if (gen.period_transition==1 && gen.period_counter==2) {
      
      printf ("Number of ticks: %d\n",t);
      pos_ref_time[n]=t;
      
      //-- Generar fichero con las posiciones de referencia
      generar_fichero_pos_deseada();
      
      //-- Generar el fichero con las posiciones y velocidad del servo
      generar_fichero_servo_data_pos(t);
      generar_fichero_servo_data_vel(t);
      generar_fichero_servo_data_pos_ref(t);
    }
    
    //-- Check if we are in the first period
    if (gen.period_counter==1) {
      
      //-- obtener posicion del servo en grados y almacenarla
      //-- obtener posicion del servo en grados y almacenarla
      dReal pos=Rtk_Y1Module_get_pos_grad (&mod);
      servo_pos[t]=pos;
      
      //-- Obtener velocidad y almacenarla
      dReal vel=Rtk_Y1Module_get_vel (&mod);
      servo_vel[t]=vel;
      
      //-- Almacenar los tiempos de las posiciones de referencia
      if (Rtk_Y1Module_stable(&mod)) {
        pos_ref_time[n]=t+1;
        n++;
      }  
      
      //-- Incrementar el tiempo
      t++;
    }
  }
  
	//-- Renderizar
  Rtk_3D_render(&sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(int (sim.step*1000000));
}





/**********************************************************************/
/* Generar fichero octave con las posiciones deseadas para el servo   */
/**********************************************************************/
static void generar_fichero_pos_deseada()
{
  FILE *fd;
  
  fd = fopen("servo_data_ref.m","w");
  
  fprintf (fd,"ref=[");
  for (int i=0; i<sf.N; i++)
    fprintf (fd,"%f,",sf.f[i]);
  fprintf (fd,"%f];\n",sf.f[0]);
  
  fprintf (fd,"t=[0:1:%d];\n",sf.N);
  fprintf (fd,"title('Posiciones de referencia de los servos')\n");
  fprintf (fd,"xlabel('Tiempo discreto')\n");
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"grid on;\n");
  fprintf (fd,"plot(t,ref,'-*;Servo 1;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  printf ("Fichero: servo_data_ref.m\n");
}



/**************************************************************/
/* Generar un fichero con la velocidad angular del servo      */
/**************************************************************/
static void generar_fichero_servo_data_vel(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_vel.m","w");
  
  //-- Generar parte inicial
  fprintf (fd,"vel=[");
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_vel[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Velocidad del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Velocidad (Grad/Seg)')\n");
  fprintf (fd,"axis([0,%d,-300, 300])\n",ticks);
  fprintf (fd,"plot(t,vel,';Velocidad;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);

  printf ("Fichero: servo_data_vel.m\n");
}

/********************************************************************/
/* Generar el fichero con la posicion de referencia y real a los    */
/* largo del tiempo                                                 */
/********************************************************************/
static void generar_fichero_servo_data_pos_ref(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_pos_ref.m","w");
  
  //-- Datos de la posicion de referencia
  fprintf (fd,"pos_ref=[");
  for (int i=1; i<sf.N; i++)
    fprintf (fd,"%f,",sf.f[i]);
  fprintf (fd,"%f,%f];\n",sf.f[0],sf.f[0]);
  
  //-- Tiempo de la posicion de referencia
  fprintf (fd,"tf=[");
  for (int i=0; i<sf.N+1; i++)
    fprintf (fd,"%d,",pos_ref_time[i]);
  fprintf (fd,"];\n");
  
  
  //-- Datos de la posicion real
  fprintf (fd,"pos=[");
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_pos[i]);
  fprintf (fd,"];\n");
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  
  //-- Dibujar la grafica
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"axis([0,%d,-90, 90])\n",ticks);
  fprintf (fd,"plot(tf,pos_ref,'L;Posicion ref;',t,pos,';Posicion;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("Fichero: servo_data_pos_ref.m\n");
}

/********************************************************************/
/* Generar el fichero con la posicion del servo a lo                */
/* largo de la simulacion                                           */
/********************************************************************/
static void generar_fichero_servo_data_pos(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_pos.m","w");
  
  //-- Generar parte in$ ./modulo-y1-3D-medidas servo_test.mvmicial
  fprintf (fd,"pos=[");
  
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_pos[i]);
  fprintf (fd,"];\n");
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"plot(t,pos,';Posicion;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("Fichero: servo_data_pos.m\n");
}


static void help()
{
  printf ("Uso: ./Osciloscopio-y1 [fichero.mvm]\n");
  printf ("      donde fichero.mvm es un fichero en formato MRS\n");
  printf ("      Si no se especifica se utiliza una secuencia establecida\n");
}

/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static void analizar_parametros(int argc, char* argv[])
{
  
   //-- Si fichero de secuencias especificado
   if (argc>1) {
     
     //-- Leer la secuencia del fichero 
     Rtk_Sampled_Function_new_from_mvm_file(&sf, argv[1],1);   
   }
   else {
     //-- Tomar secuencia por defecto
     Rtk_Sampled_Function_new_from_sine_func(&sf,40,0,0,DEFAULT_SAMPLES);
     printf ("Tomando secuencia por defecto\n");
   }
}



/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  //-- Analizar los argumentos de entrada
  analizar_parametros(argc,argv);
   
  /********************************/
  /* Definir el modulo           */
  /********************************/  
   
  //-- Crear modulo Y1 con sus propiedades
  Rtk_Y1Module_new(&mod);
    mod.pitch=1;
    mod.error_min=RTK_TO_RADIANES(5);
    mod.red=0;
    mod.green=0;
    mod.blue=1;
   
  //-- generadores
  Rtk_Generator_new(&gen);
  Rtk_Y1Module_generator_add(&mod,&gen);
  
  //-- Asignar la secuencia al generador
  Rtk_Generator_set_func(&gen,&sf);   
 
  //-- Create the robot and add the Y1 module to it
  Rtk_Robot_new(&robot);                  
  Rtk_Robot_add(&robot,&mod,mod.type);
  
  //-- Crear la simulacion y anadir el robot
  Rtk_Simulation_Engine_new(&sim);
  
  //-- Anadir el robot a la simulacion
  Rtk_Simulation_Engine_Add(&sim,&robot,robot.type);
  
  printf ("Hola..\n");
  
  //-- Que comience la simulacion...
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  //-- Fin de la simulacion
  Rtk_Simulation_Engine_end(&sim);


  return 0;
}
