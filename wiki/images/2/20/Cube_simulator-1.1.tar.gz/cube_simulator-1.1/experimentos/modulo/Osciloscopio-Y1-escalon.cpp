/*---------------------------------------------------------------------------*/
/**  \file Osciloscopio-Y1-escalon.cpp
  *  \brief Medir la respuesta del servo ante un estimulo de tipo escalon
  *
  *  Se obtienen las graficas en octave tanto de las posiciones de salida 
  *  como de la velocidad. \n
  *  Hay renderizado en 3D
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Agosto 2006
*/
/*---------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <ode/ode.h>

#include "Rtk-3D.h"

/*********************************************/
/* Algunas constantes usadas en el programa  */
/*********************************************/
#define TICKS 400              // Numero de ticks a simular
#define MAX_TICKS   10000      // Numero maximo de ticks

//*******************************************
// VARIABLES GLOBALES DEL PROGRAMA
//*******************************************
//-- RoboGets 
static RtkSimulationEngine sim;
static RtkRobot            robot;
static RtkY1Module         mod;

//-- Contador de tiempo
static int t=0;

//-- Tiempo de establecimiento
static int ts=0;

//-- Amplitud del escalon
static int amplitud;

//-- Almacenar las muestras de la posicion del servo
static dReal servo_pos[MAX_TICKS];
static dReal servo_vel[MAX_TICKS];


//-- FUNCIONES PRIVADAS
static void generar_fichero_servo_data_pos(int ticks);
static void generar_fichero_servo_data_vel(int ticks);
static void generar_fichero_servo_data_pos_ref(int ticks);

/***************************************************************************/
/* FUNCIONES DE RETROLLAMADA                                               */
/***************************************************************************/


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	if (cmd=='q') {
    dsStop();
  }
}

/***********************************************************************/
/* SIMULACION!!                                                        */
/***********************************************************************/

/***************************************************/
/* Simulacion de un paso                           */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
		
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim);
    
    //-- Introducir el escalon
    if (t==TICKS/2) {
      Rtk_Y1Module_set_pos_ref_grados(&mod, amplitud);
    }
    
    
    //-- Parar la simulacion
    if (t>=TICKS) {
      //-- Generar el fichero con las posiciones y velocidad del servo
      generar_fichero_servo_data_pos(t);
      generar_fichero_servo_data_vel(t);
      generar_fichero_servo_data_pos_ref(t);
      
      printf ("FIN!\n");
      
      dsStop();
    }
    
    //-- Obtener el tiempo de establecimiento ts, si no estaba
    //-- ya calculado
    if (t>TICKS/2 && ts==0) {
      if (Rtk_Y1Module_stable(&mod)) {
        ts=t-TICKS/2;
        printf ("ts: %d\n",ts);
      }  
    }
    
    //-- obtener posicion del servo en grados y almacenarla
    dReal pos=Rtk_Y1Module_get_pos_grad (&mod);
    servo_pos[t]=pos;
       
    //-- Obtener velocidad y almacenarla
    dReal vel=Rtk_Y1Module_get_vel (&mod);
    servo_vel[t]=vel;
    
    //-- Incrementar el tiempo
    t++;
  }
  
	//-- Renderizar
  Rtk_3D_render(&sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(int (sim.step*1000000));
}


/**************************************************************/
/* Generar un fichero con la velocidad angular del servo      */
/**************************************************************/
static void generar_fichero_servo_data_vel(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_vel.m","w");
  
  //-- Generar parte inicial
  fprintf (fd,"vel=[");
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_vel[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Velocidad del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Grad/Seg')\n");
  fprintf (fd,"plot(t,vel,';Velocidad;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);

  printf ("Fichero: servo_data_vel.m\n");
}

/********************************************************************/
/* Generar el fichero con la posicion y velocidad del servo a lo    */
/* largo de la simulacion                                           */
/********************************************************************/
static void generar_fichero_servo_data_pos(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_pos.m","w");
  
  //-- Generar parte inicial
  fprintf (fd,"pos=[");
  
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_pos[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"axis([0,%d,-10, 110])\n",TICKS);
  fprintf (fd,"plot(t,pos,';Posicion real;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("Fichero: servo_data_pos.m\n");
}

/********************************************************************/
/* Generar una grafica conjunta de la posicion de referencia y la   */
/* real.                                                            */
/********************************************************************/
static void generar_fichero_servo_data_pos_ref(int ticks)
{
  FILE *fd;
  
  fd = fopen("servo_data_pos_ref.m","w");
  
  //-- Generar parte inicial
  fprintf (fd,"pos=[");
  
  for (int i=0; i<ticks; i++)
     fprintf (fd,"%f,",servo_pos[i]);
  fprintf (fd,"];\n");
  fprintf (fd,"t=[0:1:%d];\n",(ticks-1));
  
  fprintf (fd,"esc=[0.5,%f,%f];\n",amplitud+0.5,amplitud+0.5);
  fprintf (fd,"tesc=[0,%d,%d];\n",ticks/2,ticks);
  
  //-- Generar parte final
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('Posicion del servo')\n");
  fprintf (fd,"xlabel('Tiempo (Tics de %.2f seg)')\n",sim.step);
  fprintf (fd,"ylabel('Angulo (Grados)')\n");
  fprintf (fd,"axis([0,%d,-10, 110])\n",TICKS);
  fprintf (fd,"plot(tesc,esc,'L;Posicion ref;',t,pos,';Posicion real;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  
  printf ("Fichero: servo_data_pos_ref.m\n");
}

static void help()
{
  printf ("Uso: ./modulo-y1-3D-escalon [amplitud]\n");
  printf ("      donde amplitud del escalon entre 0 y 90\n");
  printf ("      Si no se especifica se utilizan 90 grados\n");
}


/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static void analizar_parametros(int argc, char* argv[])
{
  
   //-- Si fichero de secuencias especificado
   if (argc>1) {
     
     amplitud=atoi(argv[1]);
     printf ("Amplitud: %d\n",amplitud);
     
   }
   else {
     amplitud=90;
     printf ("Tomando amplitud por defecto: %d\n",amplitud);
   }
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  //-- Analizar los argumentos de entrada
  analizar_parametros(argc,argv);
   
  /********************************/
  /* Definir el modulo           */
  /********************************/  
   
  //-- Crear modulo Y1 con sus propiedades
  Rtk_Y1Module_new(&mod);
    mod.pitch=1;
    mod.error_min=RTK_TO_RADIANES(5);
    mod.red=1;
    mod.green=0;
    mod.blue=0;
  
  //-- Create the robot and add the Y1 module to it
  Rtk_Robot_new(&robot);                  
  Rtk_Robot_add(&robot,&mod,mod.type);
  
  //-- Crear la simulacion y anadir el robot
  Rtk_Simulation_Engine_new(&sim);
  
  //-- Anadir el robot a la simulacion
  Rtk_Simulation_Engine_Add(&sim,&robot,robot.type);
  
  //-- Que comience la simulacion...
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  //-- Fin de la simulacion
  Rtk_Simulation_Engine_end(&sim);


  return 0;
}
