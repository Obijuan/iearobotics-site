#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

import sys;

try: 
  N=int(sys.argv[1])
except:
  print "Error en parametro. Tomando N=2"
  N=2

for i in range(N):
  sample = i*90/(N-1)
  sys.stdout.write("%d " % sample)
  sys.stdout.flush()
  
print ""
