/*---------------------------------------------------------------------------*/
/**  \file Rtk-3D.cpp
  *  \brief Renderizacion 3D para RTK
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño
  *  \date Agosto 2006. Licencia GPL
*/
/*---------------------------------------------------------------------------*/
 #include <unistd.h>
#include "Rtk-3D.h"

/*-------------------------*/
/* VARIABLES PRIVADAS      */
/*-------------------------*/
//-- Robot a evaluar. Usado en funcion de fitness
static RtkRobot *robot;

//-- Simulacion
static RtkSimulationEngine *sim;



/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/
static void command (int cmd)
{
  if (cmd=='q')
    dsStop();
}

/************************************************/
/* Bucle de simulacion para funcion de Fitness  */
/************************************************/
static void simLoop (int pause)
{
  int fin;
  
  if (!pause) {
    //-- Paso de simulacion
 
    fin=Rtk_Fitness_distance_step();
  
    if (fin) dsStop();
  }    
  
  //-- Renderizar
  Rtk_3D_render(robot->sim);
}  

/************************************************/
/* Bucle de simulacion para simulacion sencilla  */
/************************************************/
static void step (int pause)
{
  
  if (!pause) {
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(sim);
  }    
  
   //-- Renderizar
  Rtk_3D_render(sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(100);
  //usleep(int (sim->step*1000000));
}  


/*************************/
/* Dibujar una geometria */
/*************************/
static void drawGeom (RtkSimulationEngine *sim,dGeomID g)
{
	const dReal *pos;
	const dReal *R;
  dReal pos2[4];	
	
	//-- Leer la posicion y orintacion de la geometria
  pos = dGeomGetPosition (g);
  R = dGeomGetRotation (g);

	//-- Leer el tipo de geometria
	//-- En este ejemplo solo puede ser una "caja"
  int type = dGeomGetClass (g);
	
	//-- Si es una caja...
  if (type == dBoxClass) {
    dVector3 sides;
    dGeomBoxGetLengths (g,sides);
		
		//-- Antes de dibujar, escalamos todos los vectores
    //-- segun un factor. Asi se puede modificar el tamano de lo
    //-- que se visualiza sin que afecte a la simulacion
    //-- Escalar el vector de posicion
    pos2[0]=pos[0]*sim->Factor_visualizacion;
    pos2[1]=pos[1]*sim->Factor_visualizacion;
    pos2[2]=pos[2]*sim->Factor_visualizacion;
    
    //-- Escalar dimensiones de la caja
    sides[0]*=sim->Factor_visualizacion;
    sides[1]*=sim->Factor_visualizacion;
    sides[2]*=sim->Factor_visualizacion;
    
    //-- Dibujar la caja
    dsDrawBox (pos2,R,sides);
  }
}

//**************************************************************
//-- Funcion de retrollamada de comienzo de la simulacion
//-- Se utiliza principalmente para establecer el punto de vista
//-- inicial (posicion de la camara en el universo)
//**************************************************************
static void start()
{
	//-- Esta es la posicion de la camara. Se pasan las coordenadas x,y,z
	static float xyz[3] = {-2.65f, -1.0f, 1.93f};

  //-- 	Esta es la orientacion de la camara.
	//-- Las componentes son Pan, Tilt (inclinacion) y Roll
	//-- El valor (0,0,0) indica que la camara esta apuntando en 
	//-- direccion positiva de las X, paralelamente al suelo.
	static float hpr[3] = {0.0f,-26.5f,0.0f};
	
  
  //-- Pruebas:
  
  //Viewpoint = (4.8310,-3.3127,1.3100,-180.0000,-10.5000,0.0000)
  //static float xyz[3] = {4.8310f, -3.312f, 1.31f};
  //static float hpr[3] = {-180.0f,-10.5f,0.0f};
  
  
	//-- Establecer la posicion de la camara
  dsSetViewpoint (xyz,hpr);
  
}


/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/


/**********************************/
/* Bucle principal de simulacion  */
/**********************************/
void Rtk_3D_Simulation_Loop(int  argc, char **argv,
                            void (*step) (int pause),
                            void (*command) (int cmd))
{
  dsFunctions fn;
  
	//-- Retrollamada de comienzo de la simulacion
	fn.start = &start;
	
	//-- Retrollamada de un paso en la simulacion
	fn.step = step;
	
	//-- Retrollamada para tecla pulsada
	fn.command = command;
	
	//-- Otros
  fn.version = DS_VERSION;
  fn.stop = 0;
  fn.path_to_textures = "./textures";
  
  dsSimulationLoop (argc,argv,400,300,&fn);
}


/***************************************/
/* Bucle principal de simulacion       */
/* Esta es la version mas simplificada */
/***************************************/
void Rtk_3D_Simulation_Loop(int  argc, char **argv, RtkSimulationEngine *s)
{
  dsFunctions fn;
	
	//-- Retrollamada de comienzo de la simulacion
	fn.start = &start;
	
	//-- Retrollamada de un paso en la simulacion
	fn.step = step;
	
	//-- Retrollamada para tecla pulsada
	fn.command = command;
	
	//-- Otros
  fn.version = DS_VERSION;
  fn.stop = 0;
  fn.path_to_textures = "./textures";
  
  sim=s;
  
  dsSimulationLoop (argc,argv,400,300,&fn);
}




/**************************************/
/* Dibujar el modulo Y1               */
/**************************************/
void Rtk_3D_Y1Module_render(RtkY1Module *mod)
{
  //-- Establecer color
	dsSetColor(mod->red,mod->green,mod->blue);
  
  //-- Textura
  dsSetTexture (DS_WOOD);
			
	//-- Segmento izquierdo
	drawGeom(mod->sim,mod->seg[0].geom[0]);
		
	//-- Segmento derecho
	drawGeom(mod->sim,mod->seg[1].geom[0]);
}


/************************************/
/* Renderizar una configuracion PP  */
/************************************/
void Rtk_3D_PP_render(RtkPP *pp)
{
  Rtk_3D_Y1Module_render(pp->lm);
  Rtk_3D_Y1Module_render(pp->rm);
}

/**************************************/
/* Renderizar un robot                */
/**************************************/
void Rtk_3D_Robot_render(RtkRobot *robot)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      mod=(RtkY1Module *)robot->roboget;
      Rtk_3D_Y1Module_render(mod);
      break;
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_3D_PP_render(pp);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_3D_Chain_render(chain);
      break;
  }
}  


/***************************************/
/* Renderizar grupo de robots          */
/***************************************/
void Rtk_3D_Robot_Group_render(RtkRobotGroup *group)
{
  //-- Renderizar cada uno de los robots
  for (int i=0; i<group->size; i++)
    Rtk_3D_Robot_render(group->roboget[i]);
}

/**********************************/
/* Renderizar cadena de modulos   */
/**********************************/
void Rtk_3D_Chain_render(RtkChain *chain)
{
  RtkY1Module *mod;
  RtkY1Module *mods;
  int Mod;
  
  mod=(RtkY1Module *)chain->module[0];
  
  //-- Textura
  //dsSetTexture (DS_WOOD);
  
  if (chain->size==1) {
	  dsSetColor(mod->red,mod->green,mod->blue);
    drawGeom(mod->sim,mod->seg[0].geom[0]);
    drawGeom(chain->module[0]->sim, chain->module[0]->seg[1].geom[0]);
    return;
  }  
  
  //-- Dibujar brazo izquierdo
  dsSetColor(mod->red,mod->green,mod->blue);
  drawGeom(mod->sim,mod->seg[0].geom[0]);
  
  for (int i=0; i<=chain->size-2; i++) {
    dsSetColor(chain->module[i]->red,
               chain->module[i]->green,
               chain->module[i]->blue);
    drawGeom(chain->module[i]->sim,
             chain->module[i]->seg[1].geom[0]);
    
    dsSetColor(chain->module[i+1]->red,
               chain->module[i+1]->green,
               chain->module[i+1]->blue);
    drawGeom(chain->module[i]->sim,
             chain->module[i]->seg[1].geom[1]);
  }
  
  //-- Brazo derecho
  Mod=chain->size-1;
  dsSetColor(chain->module[Mod]->red,
               chain->module[Mod]->green,
               chain->module[Mod]->blue);
  
  drawGeom(chain->module[Mod]->sim,
           chain->module[Mod]->seg[1].geom[0]);

}


/**************************************/
/* Renderizar la simulacion completa  */
/**************************************/
void Rtk_3D_render(RtkSimulationEngine *sim)
{
  RtkRobot      *robot;
  RtkRobotGroup *group;
  
  //-- Navegar por la simulacion
  switch(sim->roboget_type) {
    
    case RTK_TYPE_ROBOT:
      robot=(RtkRobot *)sim->roboget;
    
      //-- Renderizar el robot
      Rtk_3D_Robot_render(robot);
      break;
    
    case RTK_TYPE_ROBOT_GROUP:
      group=(RtkRobotGroup *)sim->roboget;
    
      //-- Renderizar grupo de robots
      Rtk_3D_Robot_Group_render(group);
      break;
  }
}

/************************************************************************/
/* MAIN LOOP para la evaluacion de robots                               */
/************************************************************************/




/***************************************************************/
/* Funcion de evaluacion de la distancia que recorre un robot  */
/***************************************************************/
void Rtk_3D_Fitness_distance(int argc, char **argv, 
                             RtkRobot *r, 
                             int tics_simu,
                             dVector3 desp)
{
  //-- Realizar un reset de la simulacion
  Rtk_Simulation_Engine_reset(r->sim);
  
  //-- Almacenar un puntero al robot a evaluar
  robot=r;
  
  //-- Inicializar todas las variables
  Rtk_Fitness_distance_init(robot, tics_simu);
  
  //-- Bucle de simulacion
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
   //-- Devolver la distancia
  Rtk_Fitness_distance_get_value(desp);
  
}
