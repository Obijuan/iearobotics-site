/*-------------------------------------------------------------------------*/
/**  \file Rtk-Generator.cpp
  *  \brief Generador de onda para movimiento de servos
  *
  *  Generador para la obtencion de posiciones de refencia para los servos
  *  De momento esta limitado a secuencias de 10 muestras
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño
  *  \date Agosto 2006. Licencia GPL                                        */
/*--------------------------------------------------------------------------*/
#include "Rtk.h"


/*------------------------------*/
/* Algunas secuencias de prueba */
/*------------------------------*/
static dReal func_sin_A40_P120_T10[]={0,23,38,38,23,0,-23,-38,-38,-23,};

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/



/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/***************************************/
/* Inicializar un nuevo generador      */
/***************************************/
void Rtk_Generator_new(RtkGenerator *gen)
{
  
  /*-------------------------------------------------*/
  /* INICIALIZAR LOS CAMPOS COMUNES                  */
  /*-------------------------------------------------*/
  gen->type=RTK_TYPE_GENERATOR;
  gen->Parent=NULL;
  gen->Parent_type=RTK_TYPE_UNKNOW;
  gen->sim=NULL;
  
  /*----------------------------------------------------------*/
  /* INICIALIZAR LOS ATRIBUTOS PARTICULACIONES                */
  /*----------------------------------------------------------*/
  
  //-- Inicializar funcion del generador
  gen->f=&(func_sin_A40_P120_T10[0]);
  
  //!-- Numero de muestras (Modulo)
  gen->N=10;
  
  //!-- Indice a la muestra actual
  gen->n=0;
  
  //!-- Indice de periodos
  gen->period_counter=0;
  
  //!-- Valor anterior
  gen->period_counter_old=0;
  
  //!-- Inicialmente no ha habido transiciones
  gen->period_transition=0;
  
  //!-- Por defecto el generador reproduce
  gen->Play=1;
  
}

/**********************************/
/* Crear generador                */
/**********************************/
void Rtk_Generator_create(RtkSimulationEngine *sim,
                          RtkGenerator *gen)
{
  RtkY1Module *mod;
  
  //-- Enlazar con el motor de simulacion
  gen->sim=sim;
  
  //-- Establecer la primera posicion de referencia del modulo
  mod=(RtkY1Module *)gen->Parent;
  Rtk_Y1Module_set_pos_ref_grados(mod, gen->f[0]);
}


/******************************************************************/
/* Indicar si el controlador se ha disparado y el generador debe  */
/* enviar la siguiente posicion de referencia                     */
/* Devuelve:                                                      */
/*  0: No se ha disparado                                         */
/*  1: Se ha disparado                                            */
/******************************************************************/
int Rtk_Generator_trigger(RtkGenerator *gen)
{
 return 0;
}

/************************************************************************/
/* Forzar al generador a que envie la siguiente posicion de referencia  */
/************************************************************************/
void Rtk_Generator_next_sample(RtkGenerator *gen)
{
  RtkY1Module *mod;
  
  //-- Asegurarse que existe generador. No se informa de un warning
  //-- Porque los generadores son opcionales.
  if (gen==NULL) return;
  
  if (gen->Play==1) {
  
    //-- Obtener el modulo asociado
    mod=(RtkY1Module *)gen->Parent;
    
    
    //-- Si el indice llega al comienzo, se incrementa el contador de periodos
    if (gen->n==0) {
          
      //-- Actualizar contador de periodos
      gen->period_counter++;
      gen->period_transition=1;
    }
        
    //-- Actualizar el indice de muestras
    gen->n=(gen->n+1) % gen->N;
        
    //-- Establecer la nueva posicion de referencia
    Rtk_Y1Module_set_pos_ref_grados(mod, gen->f[gen->n]);
  }  
  
}

/***********************************/
/* Simular el generador            */
/***********************************/
void Rtk_Generator_simulate(RtkGenerator *gen)
{
  RtkY1Module *mod;
  
  //-- Obtener el modulo asociado
  mod=(RtkY1Module *)gen->Parent;
    
  //-- Poner a cero flag de transicion de periodo
  if (gen->period_transition==1) gen->period_transition=0;
  
  //-- Guardar valor del contador de periodos
  gen->period_counter_old = gen->period_counter;
  
}

/************************************/
/* Imprimir el generador            */
/************************************/
void Rtk_Generator_print(RtkGenerator *gen, int depth)
{
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Generator\n");
}



/*******************************************/
/* Asignar una funcion para el generador   */
/*******************************************/
void Rtk_Generator_set_func(RtkGenerator *gen, RtkSampledFunction *sf)
{
  gen->f=sf->f;
  gen->N=sf->N;
}

/***************************************************/
/* Asignar una funcion desde un fichero MVM        */
/* La secuencia tiene que ser de 10 muestras       */
/***************************************************/


/***************************************************/
/* Establecer el numero de muestras de la funcion  */
/***************************************************/
void Rtk_Generator_set_N(RtkGenerator *gen, int N)
{
  gen->N=N;
}

/*********************************************/
/* Establecer si el generador reproduce o no */
/*********************************************/
void Rtk_Generator_set_play(RtkGenerator *gen, int play)
{
  gen->Play=play;
}

/********************************/
/* Inicializar el generador     */
/********************************/
void Rtk_Generator_reset(RtkGenerator *gen)
{
  RtkY1Module *mod;
  
  //!-- Indice a la muestra actual
  gen->n=0;
  
  //!-- Indice de periodos
  gen->period_counter=0;
  
  //!-- Valor anterior
  gen->period_counter_old=0;
  
  //!-- Inicialmente no ha habido transiciones
  gen->period_transition=0;
  
  //!-- Por defecto el generador reproduce
  gen->Play=1;
  
  //-- Establecer la primera posicion de referencia del modulo
  mod=(RtkY1Module *)gen->Parent;
  Rtk_Y1Module_set_pos_ref_grados(mod, gen->f[0]);
}
