/**  \file Rtk-Simulation-Engine.cpp
  *  \brief Motor de simulacion de RTK
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño.
  *  \date Agosto 2006. Licencia GPL
*/

#include "Rtk.h"

/*********************************************/
/* Algunas constantes usadas en el programa  */
/*********************************************/
//! Numero maximo de puntos de contacto (parametro para ODE)
#define MAX_CONTACTS 4

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/
/****************************************************************/
/* Funcion de retrollamada invocada por dSpaceCollide cuando    */
/* dos objetos del espacio estan a punto de colisionar          */
/****************************************************************/
static void nearCallback (void *data, dGeomID o1, dGeomID o2)   
{
  int i;
	
  //-- Obtener el contexto de simulacion
  RtkSimulationEngine *sim = (RtkSimulationEngine *)data;
   
  //-- Obtener los cuerpos asociados
	dBodyID b1 = dGeomGetBody(o1);
  dBodyID b2 = dGeomGetBody(o2);
  
	//-- Si ya estan conectados por una articulacion, terminar
	if (b1 && b2 && dAreConnectedExcluding (b1,b2,dJointTypeContact)) {
		return;
	}	
 
  //-- Crear contactos
  dContact contact[MAX_CONTACTS]; 
  for (i=0; i<MAX_CONTACTS; i++) {
    contact[i].surface.mode = dContactBounce | dContactSoftCFM;
    contact[i].surface.mu = sim->mu;
    contact[i].surface.mu2 = 0;
    contact[i].surface.bounce = 0.1;
    contact[i].surface.bounce_vel = 0.1;
    contact[i].surface.soft_cfm = 0.01;
    
  }
	
	//-- Obtener los puntos de contacto
	int numc = dCollide (o1,o2,MAX_CONTACTS,&contact[0].geom, sizeof(dContact));
	
  
	//-- Si hay al menos algun punto de contacto...
  if (numc!=0) {
    
		//-- Para cada punto de contacto crear una articulacion
    for (i=0; i<numc; i++) {
			
			//-- Crear articulacion y meterla en el grupo contactgroup
      dJointID c = dJointCreateContact (sim->world,sim->contactgroup,
                                        &contact[i]);
      
			//-- Establecer la artiulacion entre los dos cuerpos
      dJointAttach (c,b1,b2);
    }
  }
  
   
}



/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/**********************************************/
/* Crear un nuevo objeto del tipo simulacion  */
/**********************************************/
void Rtk_Simulation_Engine_new(RtkSimulationEngine *sim)
{
  
  //-- Indica el tipo de roboget
  sim->type=RTK_TYPE_SIMULATION_ENGINE;
  
  //-- Roboget padre
  sim->Parent=NULL;
  
  //-- Tipo del roboget padre
  sim->Parent_type=RTK_TYPE_UNKNOW;
  
  //-- Enlace al simulador
  sim->sim=sim;
 
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  sim->roboget=NULL;
  sim->roboget_type=RTK_TYPE_UNKNOW;
  
  /******************************************************/
  /* Inicializar los campos del contexto de simulacion  */
  /* a sus valores por defecto                          */
  /******************************************************/
  
  //-- Inicializar el automata
  sim->automata=AUT_TRANSITORIO;
  
  //-- Inicializar parametros para el ODE
  sim->gravedad=-9.81;
  sim->cfm=1e-5;
  sim->erp=0.2;
  sim->MaxCorrectingVel=0.1;
  sim->SurfaceLayer=0.0001;
  sim->mu=0.2;
  sim->step=0.02;
  
 
  /********************************************************************/
  /* Crear el mundo. Es un contenedor de todos los objetos a simular  */
	/* El mundo no sabe nada de como se dibujan los objetos             */
	/* En este ejemplo el mundo solo tiene un suelo y una "caja"        */
	/********************************************************************/
  //-- Crear mundo
  sim->world = dWorldCreate();
  
  //-- Establecer los parametros por defecto para la simulaion con ODE
  //-- Establecer la gravedad
	dWorldSetGravity (sim->world,0,0,sim->gravedad);
  
  //-- Establecer parametro CFM
	dWorldSetCFM (sim->world,sim->cfm);
  
  //-- Establecer parametro ERP
  dWorldSetERP(sim->world,sim->erp);
  
  //-- Otros parametros... (consular documentacion)
	dWorldSetContactMaxCorrectingVel (sim->world,sim->MaxCorrectingVel);
  dWorldSetContactSurfaceLayer (sim->world,sim->SurfaceLayer);
	
	//-- Establecer el modo auto-disabled por defecto
	//-- Cualquier objeto que se encuentre en reposo se deshabilitara
	//-- y no consumira recursos en la simulacion
	dWorldSetAutoDisableFlag (sim->world,1);
  
  //-- Crear un espacio. Los espacios contienen los elementos geometricos
	//-- sobre las que se quiere comprobar si hay colision o no
	//-- Se utilizan espacios para que la simulacion sea mas rapida 
  sim->space = dHashSpaceCreate (0);
  
	//-- Crear un grupo de articulaciones
	//-- Se utiliza para almacenar los puntos de contacto en una colision
  sim->contactgroup = dJointGroupCreate (0);
  
	//-- Crear un plano infinito y meterlo en el espacio
	//-- El plano se determina por su ecuacion del tipo:
	//-- a*x + b*y + c*z = d, donde (a,b,c) es un vector unitario
	//-- normal a su superficie
	//-- En este ejemplo se crea el plano con vector (0,0,1), es
	//-- decir, el plano: z=0
	//-- Este plano sera para nosotros el "suelo"
  dCreatePlane (sim->space,0,0,1,0);
  
  //-- Factor de visualizacion
  sim->Factor_visualizacion=FACTOR_VISUALIZACION;
  
  //-- Puerto serie
  sim->serial_fd=0;
}

/***************************************/
/* Anadir un robot al simulador        */
/***************************************/
void Rtk_Simulation_Engine_Add(RtkSimulationEngine *sim,
                               void *roboget, int roboget_type)
{
  RtkRobot      *robot;
  RtkRobotGroup *group;
  
  
  //-- Comprobar errores
  if (sim==NULL) {
    printf ("Warning: Puntero a simulacion NULO!\n");
    return;
  }
  if (roboget==NULL) {
    printf ("Warning: Puntero a roboget NULO\n");
    return;
  }
  
  //-- Establecer el Roboget "hijo"
  switch(roboget_type) {
    
    case RTK_TYPE_ROBOT:
      robot=(RtkRobot *)roboget;
    
      //-- Enlazar al robot "hijo"
      sim->roboget=robot;
      sim->roboget_type=robot->type;
    
      //-- Enlazar del robot a la simulacion
      robot->Parent=(RtkSimulationEngine *)sim;
      robot->Parent_type=sim->type;
  
      //-- Crear el robot:
      Rtk_Robot_create(sim,robot);
      break;
    
    case RTK_TYPE_ROBOT_GROUP:
      group=(RtkRobotGroup *)roboget;
    
      //-- Enlazar al roboget "hijo"
      sim->roboget=(RtkRobotGroup *)group;
      sim->roboget_type=group->type;
    
      //-- Enlazar el grupo a la simulacion
      group->Parent=(RtkSimulationEngine *)sim;
      group->Parent_type=sim->type;
  
      //-- Crear el grupo:
      Rtk_Robot_Group_create(sim,group);
      break;
    
    default:
      printf ("Warning: Se intenta anadir un tipo Incorrecto\n");
      return;
  }
  
  
  
}
 

/***************************************************************/
/* Finalizar la simulacion                                     */
/***************************************************************/
void Rtk_Simulation_Engine_end(RtkSimulationEngine *sim)
{
  //-- Destruir el grupo de articulaciones
  dJointGroupDestroy (sim->contactgroup);
	
	//-- Destruir el espacio de colisiones
  dSpaceDestroy (sim->space);
  
  //-- Destruir el mundo con todos sus objetos
  dWorldDestroy (sim->world);
}


/**************************************************/
/* Simular                                        */
/**************************************************/
static void Rtk_Simulation_Engine_simulate(RtkSimulationEngine *sim)
{
  RtkRobot      *robot;
  RtkRobotGroup *group;
  
  if (sim==NULL) {
    printf ("Warning: Rtk_Simulation_Engine_simulate. sim==NULL\n");
    return;
  }
  
  //-- Navegar por las articulaciones para simular los servos
  switch(sim->roboget_type) {
    
    case RTK_TYPE_ROBOT:
      robot=(RtkRobot *)sim->roboget;
      Rtk_Robot_simulate(robot);
      break;
    
    case RTK_TYPE_ROBOT_GROUP:
      group=(RtkRobotGroup *)sim->roboget;
      Rtk_Robot_Group_simulate(group);
      break;
  }
}

/*************************************************/
/* Imprimir el arbol de simulacion               */
/*************************************************/
void Rtk_Simulation_Engine_print(RtkSimulationEngine *sim)
{
  RtkRobot      *robot;
  RtkRobotGroup *group;
  
  if (sim==NULL) {
    printf ("Warning: Rtk_Simulation_Engine_simulate. sim==NULL\n");
    return;
  }
 
  printf ("* Simulation Engine\n");
  
  //-- Navegar por las articulaciones para simular los servos
  switch(sim->roboget_type) {
    
    case RTK_TYPE_ROBOT:
      robot=(RtkRobot *)sim->roboget;
      Rtk_Robot_print(robot,2);
      break;
    
    case RTK_TYPE_ROBOT_GROUP:
      group=(RtkRobotGroup *)sim->roboget;
      Rtk_Robot_Group_print(group,2);
      break;
  }
}


/***************************************/
/* Realizar un paso de simulacion      */
/***************************************/
void Rtk_Simulation_Engine_step(RtkSimulationEngine *sim)
{
  //-- Deteccion de colisiones. Determinar que pares de elementos geometricos
  //-- estan a punto de colisionar. Se llama a la funcion de retrollamada
  //-- nearCallback, pasando como argumento el contexto de simulacion.
  dSpaceCollide (sim->space,sim,&nearCallback);
   
  //-- Realizar un paso de simulacion
  dWorldStep(sim->world,sim->step);
  
  //-- Navegar por las articulaciones para simular los servos
  Rtk_Simulation_Engine_simulate(sim);

  // Eliminar todos los puntos de contacto
  dJointGroupEmpty (sim->contactgroup);
}


/***************************************************************/
/* Hacer un reset del motor de simulacion y todos sus "hijos"  */
/***************************************************************/
void Rtk_Simulation_Engine_reset(RtkSimulationEngine *sim)
{
  RtkRobot      *robot;
  RtkRobotGroup *group;
  
  if (sim==NULL) {
    printf ("Warning: Rtk_Simulation_Engine_reset. sim==NULL\n");
    return;
  }
  
  //-- Navegar por los hijos para hacer reset de todos ellos
  switch(sim->roboget_type) {
    
    case RTK_TYPE_ROBOT:
      robot=(RtkRobot *)sim->roboget;
      Rtk_Robot_reset(robot);
      break;
    
    case RTK_TYPE_ROBOT_GROUP:
      group=(RtkRobotGroup *)sim->roboget;
      Rtk_Robot_Group_reset(group);
      break;
  }
}

/**********************************************************/
/* Establecer el puerto serie empleado en la simulacion   */
/**********************************************************/
void Rtk_Simulation_Engine_set_serialfd(RtkSimulationEngine *sim, int fd)
{
  sim->serial_fd=fd;
}
