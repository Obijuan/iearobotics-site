/*-------------------------------------------------------------------------*/
/**  \file Rtk-fitness.cpp
  *  \brief Funciones de evaluacion de los robots
  *
  *  Funciones de evaluacion para su utilizacion con algoritmos geneticos
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño
  *  \date Septiembre 2006. Licencia GPL                                    */
/*--------------------------------------------------------------------------*/


#include <ode/ode.h>

#include "Rtk.h"

//-- RoboGets 
static RtkRobot *robot;
static int tics=0;  //-- Numero de tics a simular
static int t=0;     //-- Tiempo

//-- Vectores de posicion inicial y final
static dVector3 pos_ini;
static dVector3 pos_fin;

//-- Desplazamiento final
static dVector3 desp;


/*********************************************/
/* FUNCIONES PRIVADAS                        */
/*********************************************/

/******************************************/
/* Restar dos vectores del tipo dVector3  */
/* result = a - b                         */
/******************************************/
static void dvector3_restar(dVector3 result, dVector3 a, dVector3 b)
{
  result[X]=a[X]-b[X];
  result[Y]=a[Y]-b[Y];
  result[Z]=a[Z]-b[Z];
}


/***************************************************/
/* FUNCIONES DE INTERFAZ                           */
/***************************************************/

/**************************************/
/* Inicializar las variables          */
/**************************************/
void Rtk_Fitness_distance_init(RtkRobot *r, int tics_simu)
{
  robot=r;
  tics=tics_simu;
  t=0;
}

/************************************/
/* Realizar un paso de simulacion   */
/************************************/
int Rtk_Fitness_distance_step(void)
{
  RtkGenerator *geni;
  
  geni=Rtk_Robot_get_generator(robot);
  
  //-- Realizar un paso de simulacion
  Rtk_Simulation_Engine_step(robot->sim);
  
  //-- Comienzo del primer periodo
  if (geni->period_transition==1 && geni->period_counter==1) {
    Rtk_Robot_get_center(robot, pos_ini);
  }
  
  if (t>=tics) {
    Rtk_Robot_get_center(robot, pos_fin);
    dvector3_restar(desp,pos_fin,pos_ini);
      
    return 1;
  }
    
  //-- Incrementar el contador de ticks
  t++;
  
  return 0;
}



/********************************************/
/* Calcular la distancia                    */
/********************************************/
void Rtk_Fitness_distance_get_value(dVector3 desp)
{
  //-- Calcular el vector desplazamiento
  dvector3_restar(desp,pos_fin,pos_ini);
}


/*************************************************************/
/* FUNCION DE EVALUACION DE LA DISTANCIA                     */
/*************************************************************/
void Rtk_Fitness_distance(RtkRobot *r, int tics_simu, dVector3 desp)
{
  int fin;
  
  //-- Realizar un reset de la simulacion
  Rtk_Simulation_Engine_reset(r->sim);
  
  //-- Inicializar todas las variables
  Rtk_Fitness_distance_init(r, tics_simu);
  
  //-- Realizar la simulacion
  do {
    fin = Rtk_Fitness_distance_step();
  } while (!fin);
  
  //-- Devolver la distancia recorrida
  Rtk_Fitness_distance_get_value(desp);
  
}
