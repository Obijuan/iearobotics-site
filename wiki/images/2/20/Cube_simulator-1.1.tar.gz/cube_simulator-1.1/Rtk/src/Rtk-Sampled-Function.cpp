/*-------------------------------------------------------------------------*/
/**  \file Rtk-Sampled-Function.cpp
  *  \brief Funcion muestreada
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño.
  *  \date Septiembre 2006. Licencia GPL                                    */
/*--------------------------------------------------------------------------*/
#include "Rtk.h"


/*------------------------------*/
/* Algunas secuencias de prueba */
/*------------------------------*/
static dReal func_sin_A40_P120_T10[]={0,23,38,38,23,0,-23,-38,-38,-23,};

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/



/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/*************************************************/
/* Crear un objeto del tipo Rtk-sampled-fucntion */
/*************************************************/
void Rtk_Sampled_Function_new(RtkSampledFunction *sf)
{
  //-- Poner a cero el objeto
  memset(sf, 0, sizeof(RtkSampledFunction));
  
  //-- Valores por defecto
  sf->f[0]=0;
  sf->N=1;
}

/**************************************************************/
/* Crear el objeto Rtk_Sampled-function a partir de un array  */
/**************************************************************/
void Rtk_Sampled_Function_new_from_array(RtkSampledFunction *sf, 
                                        dReal *f,
                                        int N)
{
  sf->N=N;
  
  for (int i=0; i<N; i++) {
    sf->f[i]=f[i];
  }
}


/**************************************************************/
/* Crear un objeto del tipo Rtk-Sampled-function a partir de  */
/* una onda sinusoidal                                        */
/**************************************************************/
void Rtk_Sampled_Function_new_from_sine_func(
   RtkSampledFunction *sf,
   dReal a,
   dReal df,
   dReal offset,
   int N)
   
{
  for (int i=0; i<N; i++) {
    
    //-- Muestrear con redondeo
    //sf->f[i]=round(a*sin(2*M_PI*i/N + RTK_TO_RADIANES(df))+offset);
    
    //-- Sin redondeo
    sf->f[i]=a*sin(2*M_PI*i/N + RTK_TO_RADIANES(df))+offset;
  }
  
  sf->N=N;
  
}

/**************************************************************/
/* Crear un objeto del tipo Rtk-Sampled-function a partir de  */
/* unos armonicos                                             */
/**************************************************************/
void Rtk_Sampled_Function_new_from_harmonics(
   RtkSampledFunction *sf,
   dReal offset, dReal a0, dReal phase0, int N0,
   dReal a1, dReal phase1, int N1,
   dReal a2, dReal phase2, int N2,
   dReal a3, dReal phase3, int N3,
   dReal a4, dReal phase4, int N4)
   
{
  dReal s0;
  dReal s1;
  dReal s2;
  dReal s3;
  dReal s4;
  
  for (int i=0; i<N0; i++) {
    
    //-- Tono fundamental con el offset
    s0 = a0 * sin (2*M_PI*i/N0 + RTK_TO_RADIANES(phase0))+offset;
    
    //-- Tono 1
    s1 = a1 * sin (2*M_PI*i/N1 + RTK_TO_RADIANES(phase1));
    
    //-- Tono 2
    s2 = a2 * sin (2*M_PI*i/N2 + RTK_TO_RADIANES(phase2));
    
    //-- Tono 3
    s3 = a3 * sin (2*M_PI*i/N3 + RTK_TO_RADIANES(phase3));
    
    //-- Tono 4
    s4 = a4 * sin (2*M_PI*i/N4 + RTK_TO_RADIANES(phase4));
    
    sf->f[i]=trunc(s0+s1+s2+s3+s4);
  }
  
  sf->N=N0;
}

/************************************************************/
/* Rotar a la izquierda la funcion el numero de muestras n  */
/************************************************************/
void Rtk_Sampled_Function_roll_left(RtkSampledFunction *sf, int n)
{
  RtkSampledFunction sf_temp;
  
  
  //-- No se puede rotar mas del numero de muestras de la funcion
  n = (n % sf->N);
  
  //-- Si n es cero no hay nada que rotar
  if (n==0) return;
  
  //-- Rotar desde el elemento n al final
  for (int i=n; i<sf->N; i++) {
    sf_temp.f[i-n]=sf->f[i];
  }
  
  //-- Llevar desde el elemento 0-n hasta la parte trasera
  for (int i=0; i<n; i++) {
    sf_temp.f[sf->N - n +i]=sf->f[i];
  }
  
  //-- Copiar los datos en la funcion original
  for (int i=0; i<sf->N; i++)
    sf->f[i]=sf_temp.f[i];
  
}


/**************************************/
/* Leer una linea de un fichero       */
/**************************************/
static int Leer_linea(FILE *fd, char *cad)
{
  char c=0;
  int j=0;
  int n;
  
  do {
    n=fread(&c, sizeof(char), 1, fd);
    if (n==1) {
      cad[j]=c;
      j++;
    }  
  } while (n==1 && c!='\n');
  cad[j]='\0';
  
  //-- Si es distinto de 1 ya no hay mas linea
  if (n!=1) return 0;
    
  return 1;
}


/********************************************************************/
/* Crear un objeto nuevo del tipo Rtk-sampled-funcion desde         */
/* el descriptor de un fichero                                      */
/* Puede leer ficheros .MVM de cualquier numero de muestras         */
/* ENTRADAS:                                                        */
/*   -nf: Numero de funcion a leer (entre 1 y ...)                  */
/* Devuelve 1 si todo OK. 0 si el numero de funcion no se encuentra */
/********************************************************************/
int Rtk_Sampled_Function_new_from_mvm_file_fd(RtkSampledFunction *sf,
                                            FILE *fd, int nf)
{
  char linea[2000];
  
  int num;
  int n=1;
  char numstr[10];
  char *l;
  int count;
  int N=0;
  int ok;
  
  //-- Inicializar objeto
  Rtk_Sampled_Function_new(sf);
  
  //-- Leer la funcion de la linea solicitada
  for (int i=0; i<nf; i++) {
    ok=Leer_linea(fd,linea);
    if (!ok) return 0;  //-- Funcion solicitada no esta. Fin de fichero
  }  
  
  //-- l es un puntero a la linea leida
  l=linea;
  count=0;
  
  //-- Leer cada uno de las muestras y almacenarlas en la funcion
  do {
    
    //-- Tambien quitamos los espacions en blanco que haya al comienzo de
    //-- la linea
    while(l[0]==' ') l=&l[1];
    
    //-- Leer una muestra
    n = sscanf(l,"%d",&num);
    
    //-- Si es correcto...
    if (n==1) {
      
      //-- CASO ESPECIAL: Si es un -0, quitar el -
      //-- Si no se hace asi, el caso -0 lo toma como dos ceros,
      //-- incrementandose el periodo (BUGFIXED).
      if (num==0 && l[0]=='-')
        l=&l[1];
      
      
      //--Obtener el numero de caracteres que ocupaba el numero 
      sprintf(numstr,"%d",num);
      
      //-- y se los restamos a la linea
      l=&l[strlen(numstr)];
      
      //-- Tambien quitamos los espacions en blanco que haya
      while(l[0]==' ') l=&l[1];
        
      //-- Almacenar la muestra
      sf->f[N]=(dReal)num;
      
      //-- Incrementar contador de muestras
      N++;
    }
  } while (n==1);

  //-- Guardar tamano de la funcion
  sf->N=N;
  
  return 1;
  
}


/*******************************************************************/
/* Crear un objeto nuevo del tipo Rtk-sampled-funcion desde        */
/* el descriptor de un fichero                                     */
/* FUNCION OBSOLETA. Solo puede leer fichero .mvm de 10 muestras   */
/*******************************************************************/
void Rtk_Sampled_Function_new_from_mvm_file_fd2(RtkSampledFunction *sf,
                                            FILE *fd, int nf)
{
  int n;
  int a,b,c,d,e,f,g,h,i,j;
  
  //-- Inicializar objeto
  Rtk_Sampled_Function_new(sf);
  
  //-- Leer la funcion que toca
  for (int count=0; count<nf; count++) {
    
    n=fscanf(fd,"%d %d %d %d %d %d %d %d %d %d \n",
             &a,&b,&c,&d,&e,&f,&g,&h,&i,&j);
    
    sf->f[0]=(dReal)a;
    sf->f[1]=(dReal)b;
    sf->f[2]=(dReal)c;
    sf->f[3]=(dReal)d;
    sf->f[4]=(dReal)e;
    sf->f[5]=(dReal)f;
    sf->f[6]=(dReal)g;
    sf->f[7]=(dReal)h;
    sf->f[8]=(dReal)i;
    sf->f[9]=(dReal)j;
    
    if (n!=10) {
      printf ("ERROR al leer fichero\n");
      exit(1);
    }
  }
  
  sf->N=10;
  
}


/************************************************************************/
/* Crear un objeto nuevo del tipo Rtk-sampled-funcion desde un fichero  */
/* DEVUELVE:                                                            */
/*   1: Todo ok                                                         */
/*   0: La funcion solicitada no esta (fin de fichero)                  */
/************************************************************************/
int Rtk_Sampled_Function_new_from_mvm_file(RtkSampledFunction *sf,
                                            const char *fich, int nf)
{
  FILE *fd;
  int ok;
  
  //-- Inicializar objeto
  Rtk_Sampled_Function_new(sf);
  
  //-- Leer secuencia a partir del fichero
  fd=fopen(fich,"r");
  ok=Rtk_Sampled_Function_new_from_mvm_file_fd(sf,fd,nf);
  
  //-- Cerrar fichero
  fclose(fd);
  
  return ok;
}

/***********************************/
/* Imprimir una funcion            */
/***********************************/
void Rtk_Sampled_Function_print(RtkSampledFunction *sf)
{
  printf ("[");
  for (int i=0; i<sf->N; i++)
    printf ("%.0f, ",sf->f[i]);
  printf ("];\n");
}

/**************************************************/
/* Sacar la funcion a un fichero en formato .mvm  */
/**************************************************/
void Rtk_Sampled_Function_output_mrs(FILE *fd, RtkSampledFunction *sf)
{
  for (int i=0; i<sf->N; i++)
    fprintf (fd,"%.0f ",sf->f[i]);
  
  fprintf (fd,"\n");
  
}

/************************************************************/
/* Sacar la funcion por la salida estandar en formato .mvm  */
/************************************************************/
void Rtk_Sampled_Function_output_mrs(RtkSampledFunction *sf)
{
  Rtk_Sampled_Function_output_mrs(stdout,sf);
}


/***************************************************/
/* Sacara la funcion a un fichero en formato c     */
/***************************************************/
void Rtk_Sampled_Function_output_c(FILE *fd, RtkSampledFunction *sf)
{
   fprintf (fd,"static RtkSampledFunction func = {\n");
    fprintf (fd,"  {");
    for (int i=0; i<sf->N; i++)
      fprintf (fd,"%.0f,",sf->f[i]);
    fprintf (fd,"},\n");
    fprintf (fd,"  %d,\n",sf->N);
  fprintf (fd,"};\n");
}


/*********************************************************/
/* Sacar la funcion por la salida estandar en formato c  */
/*********************************************************/
void Rtk_Sampled_Function_output_c(RtkSampledFunction *sf)
{
 
  Rtk_Sampled_Function_output_c(stdout,sf);    
}

/**********************************************************/
/* Generar la salida en formato Octave/matlab             */
/* Se saca por el stream pasado                           */
/**********************************************************/
void Rtk_Sampled_Function_output_octave(FILE *fd, RtkSampledFunction *sf)
{
  fprintf (fd,"f1=[");
  for (int i=0; i<sf->N; i++)
    fprintf (fd,"%.0f,",sf->f[i]);
  fprintf (fd,"%f];\n",sf->f[0]);
  
  fprintf (fd,"t=[0:1:%d];\n",(sf->N));
  fprintf (fd,"title('Posiciones de referencia de los servos')\n");
  fprintf (fd,"xlabel('Tiempo')\n");
  fprintf (fd,"ylabel('Grados')\n");
  fprintf (fd,"grid on;\n");
  fprintf (fd,"plot(t,f1,';Servo 1;');\n");
  fprintf (fd,"pause;\n");
}
