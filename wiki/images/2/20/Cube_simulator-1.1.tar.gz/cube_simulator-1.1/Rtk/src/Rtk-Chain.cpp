/**  \file Rtk-Chain.cpp
  *  \brief Cadena de modulos
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Trevino
  *  \date Septiembre 2006. Licencia GPL
*/

#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/
/***************************************************************/
/* Unir los modulos izquierdo y derecho mediante una fijacion  */
/***************************************************************/
static void Crear_fijacion(RtkChain *chain, int fij, int mi, int md)
{
  RtkY1Module *modi, *modd;
  
  //-- Punteros a los modulos a unir
  modi= chain->module[mi];
  modd= chain->module[md];
  
	//-- Crear la fijacion
	chain->fixation[fij]=dJointCreateHinge (chain->sim->world, 0);
	
	//-- Unir los dos modulos. Segmento derecho del modulo Izquierdo, con
  //-- el segmento izquierdo del modulo derecho
	dJointAttach (chain->fixation[fij], modi->seg[1].body, modd->seg[0].body);
	
	//-- Definir el eje de rotacion. En realidad nunca habra rotacion, pero
  //-- para "unir" dos objetos hay que usar una articulacion 
	dJointSetHingeAxis (chain->fixation[fij], 1,0,0);
  
  //-- Anclar el eje. Estara situado en el punto medio entre los dos
  //-- modulos. Para su calculo se puede obtener la posicion del 
  //-- segmento derecho del modulo izquierdo y restarle LONG/4 a la 
  //-- coordenada y
    const dReal *pos;
    pos=dBodyGetPosition(modi->seg[1].body);
  
    //-- Establecer punto de anclaje
	  dJointSetHingeAnchor (chain->fixation[fij], pos[0], 
                          (pos[1]-modi->Ld/2.0), modd->altura/2.0);
	
	//-- Establecer otros parametros del servo
	dJointSetHingeParam(chain->fixation[fij], dParamFMax, 1000);
  dJointSetHingeParam(chain->fixation[fij], dParamVel, 0.0);
  
  //-- Es posible establecer una posicion "inicial" de esta articulacion
  //-- lo que permitiria conectar los dos modulos Y1 con otra orientacion
  
  /********************************************************/
  /* Almacenar el estado inicial, para poder hacer reset  */
  /********************************************************/
  //-- Leer punto de anclaje de la articulacion 
  dJointGetHingeAnchor (chain->fixation[fij], chain->fixation_ini[fij]);
}


/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/***********************************/
/* Crear una nueva cadena          */
/***********************************/
void Rtk_Chain_new(RtkChain *chain)
{
  //-- Poner a cero el objeto
  memset(chain, 0, sizeof(RtkChain));
  
  
  //-- Iniciar los valores por defecto
  
  //-- Indica el tipo de roboget
  chain->type=RTK_TYPE_CHAIN;
  
  //-- Roboget padre
  chain->Parent=NULL;
  
  //-- Tipo del roboget padre
  chain->Parent_type=RTK_TYPE_UNKNOW;
  
  //-- Enlace al simulador
  chain->sim=NULL;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  
  //! Modulos dentro de la cadena
  for (int i=0; i<RTK_MAX_MOD; i++)
    chain->module[i]=NULL;
  
  //-- Numero de modulos en el grupo
  chain->size=0;
  
  //-- Tipo de control
  chain->centralized_controller=1;
  
  //-- Posiciones iniciales de la configuracion
  chain->xini=0;
  chain->yini=0;
  chain->zini=0;
}

/*********************************/
/* Anadir un modulo a la cadena  */
/*********************************/
void  Rtk_Chain_add(RtkChain *chain, RtkY1Module *mod)
{
  //-- Enlace de la cadena al modulo
  chain->module[chain->size] = mod;
  chain->size++;
  
  //-- Enlace del modulo a la cadena
  mod->Parent=chain;
  mod->Parent_type=chain->type;
  
}


/********************************/
/* Crear la cadena              */
/********************************/
void Rtk_Chain_create(RtkSimulationEngine *sim, RtkChain *chain)
{
  RtkY1Module *mod;
  RtkGenerator *gen;
  dReal L;  //-- Longitud del segmento
  dReal M;  //-- Masa del segmento
  dMass m;
  int Mod;  //-- Numero de modulos de la cadena
  dReal x0,y0,z0;
  
 
  
  //---------------------------------------
  //-- 1) Brazo izquierdo
  //---------------------------------------
  mod=(RtkY1Module *)chain->module[0];
  mod->sim=sim;
  L=mod->L;
  M=mod->M;
  Mod = chain->size;
  x0=mod->xini;
  y0=mod->yini;
  z0=mod->zini;
  
  //-- Si hay un generador asociado, crearlo
  if (mod->gen!=NULL) {
    gen=mod->gen;
    Rtk_Generator_create(sim,gen);
  }  
  
  //-- Crear cuerpo y establecer su posiion
	mod->seg[0].body = dBodyCreate(mod->sim->world);
  dBodySetPosition(mod->seg[0].body, x0, y0-L/4, 
                   mod->altura/2.0 + z0);
  //-- Establecer su masa
	dMassSetBoxTotal (&m, M/2, mod->grosor,L/2,mod->altura);
	dBodySetMass (mod->seg[0].body,&m);
  
  //-- Crear la geometria y asociarla al cuerpo
	mod->seg[0].geom[0] = dCreateBox (mod->sim->space,mod->grosor,L/2, 
                                  mod->altura);
	dGeomSetBody (mod->seg[0].geom[0],mod->seg[0].body);
  
  
  //-------------------------------
  //-- Caso general
  //-------------------------------
  for (int i=0; i<=Mod-2; i++) {
    mod=(RtkY1Module *)chain->module[i];
    mod->sim=sim;
    //-- Si hay un generador asociado, crearlo
    if (mod->gen!=NULL) {
      gen=mod->gen;
      Rtk_Generator_create(sim,gen);
    } 
    
    //-- Crear cuerpo y establecer su posicion
	  mod->seg[1].body = dBodyCreate(mod->sim->world);
    dBodySetPosition(mod->seg[1].body, x0, y0-L*(i+1), 
                     mod->altura/2.0 + z0);
    //-- Establecer su masa
	  dMassSetBoxTotal (&m, M, mod->grosor,L,mod->altura);
	  dBodySetMass (mod->seg[1].body,&m);
    
    //-- Crear las geometrias y asociarlas al cuerpo
    mod->seg[1].geom[0] = dCreateBox (mod->sim->space,mod->grosor,L/2, 
                                      mod->altura);
    mod->seg[1].geom[1] = dCreateBox (mod->sim->space,mod->grosor,L/2, 
                                      mod->altura);
    dGeomSetBody (mod->seg[1].geom[0],mod->seg[1].body);
    dGeomSetBody (mod->seg[1].geom[1],mod->seg[1].body);
    
    //-- Establecer los offsets
    dGeomSetOffsetPosition (mod->seg[1].geom[0], 0.0, L/4, 0.0);
    dGeomSetOffsetPosition (mod->seg[1].geom[1], 0.0, -L/4, 0.0);
  }
  
  //-- Articulaciones centrales
  for (int i=1; i<=chain->size-2; i++) {
    mod=(RtkY1Module *)chain->module[i];
    mod->servo=dJointCreateHinge (mod->sim->world, 0);
    
    dJointAttach (mod->servo,
                  chain->module[i-1]->seg[1].body,
                  chain->module[i]->seg[1].body);
    //-- Definir eje rotacion, punto anclaje y parametros del servo
    if (mod->pitch==1) 
      dJointSetHingeAxis (mod->servo, 1,0,0);
    else
      dJointSetHingeAxis (mod->servo, 0,0,1);
    
	  dJointSetHingeAnchor (mod->servo, x0, 
                         y0-i*L-L/2,mod->altura/2.0 + z0);
	  dJointSetHingeParam(mod->servo, dParamFMax, mod->par);
    dJointSetHingeParam(mod->servo, dParamVel, 0.0);
  }
  
  //---------------------------------------
  //-- 1) Brazo derecho
  //---------------------------------------
  mod=(RtkY1Module *)chain->module[Mod-1];
  
  //-- Crear cuerpo y establecer su posiion
	mod->seg[1].body = dBodyCreate(sim->world);
  dBodySetPosition(mod->seg[1].body, x0, y0-Mod*L+L/4, 
                   mod->altura/2.0 + z0);
  
  //-- Establecer su masa
	dMassSetBoxTotal (&m, M/2, mod->grosor,L/2,mod->altura);
	dBodySetMass (mod->seg[1].body,&m);
  
  //-- Crear la geometria y asociarla al cuerpo
	mod->seg[1].geom[0] = dCreateBox (sim->space,mod->grosor,L/2, 
                                  mod->altura);
	dGeomSetBody (mod->seg[1].geom[0],mod->seg[1].body);
  
  //-----------------------------
  //-- Articulaciones
  //-----------------------------
  mod=(RtkY1Module *)chain->module[0];
  
  //-- Crear articulacion izquierda que una los cuerpos izquierdo y derecho
  //-- del modulo 0
  mod->servo=dJointCreateHinge (mod->sim->world, 0);
  dJointAttach (chain->module[0]->servo,
                chain->module[0]->seg[0].body,
                chain->module[0]->seg[1].body);
  
	//-- Definir eje rotacion, punto anclaje y parametros del servo
  if (mod->pitch==1) 
    dJointSetHingeAxis (mod->servo, 1,0,0);
  else
    dJointSetHingeAxis (mod->servo, 0,0,1);
	dJointSetHingeAnchor (mod->servo, x0, 
                        y0-L/2,mod->altura/2.0 + z0);
	dJointSetHingeParam(mod->servo, dParamFMax, mod->par);
  dJointSetHingeParam(mod->servo, dParamVel, 0.0);
  
  //-- Crear la articulacion derecha, solo si hay mas de 1 modulo
  if (chain->size>1) {
    mod=(RtkY1Module *)chain->module[Mod-1];
    mod->sim=sim;
    //-- Si hay un generador asociado, crearlo
    if (mod->gen!=NULL) {
      gen=mod->gen;
      Rtk_Generator_create(sim,gen);
    } 
    
    mod->servo=dJointCreateHinge (mod->sim->world, 0);
    dJointAttach (mod->servo,
                  chain->module[Mod-2]->seg[1].body,
                  chain->module[Mod-1]->seg[1].body);
    //-- Definir eje rotacion, punto anclaje y parametros del servo
    if (mod->pitch==1) 
      dJointSetHingeAxis (mod->servo, 1,0,0);
    else
      dJointSetHingeAxis (mod->servo, 0,0,1);
    
	  dJointSetHingeAnchor (mod->servo, x0, 
                         y0-Mod*L+L/2,mod->altura/2.0 + z0);
	  dJointSetHingeParam(mod->servo, dParamFMax, mod->par);
    dJointSetHingeParam(mod->servo, dParamVel, 0.0);
  }
}


/*************************************************************/
/* Comprobar si todos los modulos de la cadena son estables  */
/*************************************************************/
int Rtk_Chain_stable(RtkChain *chain)
{
  
  //-- Simular cada uno de los modulos
  for (int i=0; i<chain->size; i++) {
    if (!Rtk_Y1Module_stable(chain->module[i]))
      return 0;
  }  
  
  //-- Si llega aqui es que todos son estables
  return 1;
}


/************************************/
/* Simular la cadena                */
/************************************/
void Rtk_Chain_simulate(RtkChain *chain)
{
  RtkGenerator *gen;
  RtkY1Module  *mod;
  int stable;
  
  if (chain==NULL) {
    printf ("Warning: Rtk_Chain_simulate. chain==NULL\n");
    return;
  }
  
  //-- Si el cocntrol esta realizado por la cadena
  if (chain->centralized_controller) {
    
    //-- Simular modulos
    for (int i=0; i<chain->size; i++)
      Rtk_Y1module_simulate(chain->module[i],0);
    
    //-- Condicion de disparo
    if (Rtk_Chain_stable(chain)) {
      for (int i=0; i<chain->size; i++) {
        //-- POR HACER: CONTROL DE NULL!!!!
        mod = (RtkY1Module *)chain->module[i];
        gen = (RtkGenerator *)mod->gen;
        Rtk_Generator_next_sample(gen);
      }  
    }
    
  }
  else {
    //-- Control no centralizado
    //-- Simular cada uno de los modulos de forma independiente
    for (int i=0; i<chain->size; i++) {
      Rtk_Y1module_simulate(chain->module[i],1);
    }
  }
  
  
}


/***********************************************/
/* Imprimir La cadena de modulos               */
/***********************************************/
void Rtk_Chain_print(RtkChain *chain, int depth)
{
  if (chain==NULL) {
    printf ("Warning: Rtk_Chain_print. chain==NULL\n");
    return;
  }
  
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Chain\n");
  
  //-- Imprimir cada uno de los modulos
  for (int i=0; i<chain->size; i++)
    Rtk_Y1Module_print(chain->module[i],depth+2);
}

/*************************************/
/* Hacer un reset de la cadena       */
/*************************************/
void Rtk_Chain_reset(RtkChain *chain)
{
   if (chain==NULL) {
    printf ("Warning: Rtk_Chain_reset. chain==NULL\n");
    return;
  }
  
  //-- Hacer reset de cada uno de los modulos
  for (int i=0; i<chain->size; i++)
    Rtk_Y1Module_reset(chain->module[i]);
  
  //-- Llevar las fijaciones a su estado inicial
  for (int i=0; i<chain->size-1; i++) {
    dJointSetHingeAnchor (chain->fixation[i], chain->fixation_ini[i][X], 
                          chain->fixation_ini[i][Y],
                          chain->fixation_ini[i][Z]);
  
    //-- Velocidad  a 0
    dJointSetHingeParam(chain->fixation[i], dParamVel, 0.0);
  }  
}

/****************************************************/
/* Leeer la posicion del primer modulo de la cadena */
/****************************************************/
void Rtk_Chain_get_center(RtkChain *chain, dVector3 pos)
{
  
  RtkY1Module *mod;
  
  mod=(RtkY1Module *)chain->module[0];
  Rtk_Y1Module_get_center(mod,pos);
}
 
/***************************************/
/* Devolver un generador de la cadena  */
/***************************************/
RtkGenerator *Rtk_Chain_get_generator(RtkChain *chain)
{
  RtkY1Module *mod;
  
  mod=(RtkY1Module *)chain->module[0];
  return Rtk_Y1Module_get_generator(mod);
}

void Rtk_Chain_set_initial_pos(RtkChain *chain, dReal x, dReal y, dReal z)
{
  //-- Establecer la posicion del modulo de la izquierda
  chain->module[0]->xini=x;
  chain->module[0]->yini=y;
  chain->module[0]->zini=z;
}
