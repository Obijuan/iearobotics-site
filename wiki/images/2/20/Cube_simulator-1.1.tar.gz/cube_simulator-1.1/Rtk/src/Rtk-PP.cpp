/*-------------------------------------------------------------------------*/
/**  \file Rtk-PP.cpp
  *  \brief Configuracion Pitch-pitch
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño
  *  \date Agosto 2006. Licencia GPL                                        */
/*--------------------------------------------------------------------------*/
#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/

/***************************************************************/
/* Unir los modulos izquierdo y derecho mediante una fijacion  */
/***************************************************************/
static void Crear_fijacion(RtkPP *pp)
{
	//-- Crear la fijacion
	pp->fixation=dJointCreateHinge (pp->sim->world, 0);
	
	//-- Unir los dos modulos. Segmento derecho del modulo Izquierdo, con
  //-- el segmento izquierdo del modulo derecho
	dJointAttach (pp->fixation, pp->lm->seg[1].body, pp->rm->seg[0].body);
	
	//-- Definir el eje de rotacion. En realidad nunca habra rotacion, pero
  //-- para "unir" dos objetos hay que usar una articulacion 
	dJointSetHingeAxis (pp->fixation, 1,0,0);
  
  //-- Anclar el eje. Estara situado en el punto medio entre los dos
  //-- modulos. Para su calculo se puede obtener la posicion del 
  //-- segmento derecho del modulo izquierdo y restarle LONG/4 a la 
  //-- coordenada y
    const dReal *pos;
    pos=dBodyGetPosition(pp->lm->seg[1].body);
  
    //-- Establecer punto de anclaje
	  dJointSetHingeAnchor (pp->fixation, pos[0], 
                          (pos[1]-pp->lm->Ld/2.0), pp->lm->altura/2.0);
	
	//-- Establecer otros parametros del servo
	dJointSetHingeParam(pp->fixation, dParamFMax, 1000);
  dJointSetHingeParam(pp->fixation, dParamVel, 0.0);
  
  //-- Es posible establecer una posicion "inicial" de esta articulacion
  //-- lo que permitiria conectar los dos modulos Y1 con otra orientacion
  
  /********************************************************/
  /* Almacenar el estado inicial, para poder hacer reset  */
  /********************************************************/
  //-- Leer punto de anclaje de la articulacion
  dJointGetHingeAnchor (pp->fixation, pp->fixation_ini);
  
}

/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/*******************************/
/* Crear una configuracion PP  */
/*******************************/
void Rtk_PP_new(RtkPP *pp)
{
  //-- Poner a cero el objeto
  memset(pp, 0, sizeof(RtkPP));
  
  /*-------------------------------------------------*/
  /* INICIALIZAR LOS CAMPOS COMUNES                  */
  /*-------------------------------------------------*/
  pp->type=RTK_TYPE_PP;
  pp->Parent=NULL;
  pp->Parent_type=RTK_TYPE_UNKNOW;
  pp->sim=NULL;
  
  /*----------------------------------------------------------*/
  /* INICIALIZAR LOS ATRIBUTOS PARTICULACIONES                */
  /* Se establecen los valores por defecto                    */
  /*----------------------------------------------------------*/
  pp->lm=NULL;   //-- Modulo izquierdo
  pp->rm=NULL;   //-- Modulo derecho
  
  //-- Por defecto control centralizado por la configuracion PP
  pp->centralized_controller=1;
  
  //-- Por defecto se mueven los modulos
  pp->Play=1;
  
  //-- Posiciones iniciales de la configuracion PP
  pp->xini=0;
  pp->yini=0;
  pp->zini=0;
  
}

/*****************************************************************/
/* Anadir los modulos izquierdo y derecho a la configuracion PP  */
/*****************************************************************/
void Rtk_PP_add(RtkPP *pp, RtkY1Module *mi, RtkY1Module *md)
{
  
  //-- Establecer los enlaces desde PP a los modulos
  pp->lm=mi;
  pp->rm=md;
  
  //-- Establecer enlaces desde modulo izquierdo a PP
  mi->Parent=pp;
  mi->Parent_type=pp->type;
  
  //-- Establecer enlaces desde modulo derecho a PP
  md->Parent=pp;
  md->Parent_type=pp->type;
}

/*********************************************************************/
/* Establecer posicion inicial de la configuracion PP. Se especifica */
/* la posicion del modulo izquierdo                                  */
/*********************************************************************/
void Rtk_PP_set_initial_pos(RtkPP *pp, dReal x, dReal y, dReal z)
{
  pp->lm->xini=x;
  pp->lm->yini=y;
  pp->lm->zini=z;
}


/******************************************************/
/* Crear el modulo PP                                 */
/******************************************************/
void Rtk_PP_create(RtkSimulationEngine *sim, RtkPP *pp)
{
  
  //-- Poner el puntero a la simulacion
  pp->sim=sim;
  
  //-- Crear modulo Y1 izquierdo
  Rtk_Y1module_create(sim,pp->lm);
  
  //-- Situar el modulo derecho pegado al izquierdo
  pp->rm->yini = pp->lm->yini - pp->lm->L;
  
  //-- La coordenada x y la z son las misma para los dos modulos
  pp->rm->xini = pp->lm->xini;
  pp->rm->zini = pp->lm->zini;
  
  
  //-- Crear modulo derecho
  Rtk_Y1module_create(sim,pp->rm);
  
  //-- Crear la fijacion entre los dos modulos
  Crear_fijacion(pp);
  
}

/*************************************/
/* Simular configuracion PP          */
/*************************************/
void Rtk_PP_simulate(RtkPP *pp)
{
  RtkY1Module *mi;
  RtkY1Module *md;
  RtkGenerator *gen1;
  RtkGenerator *gen2;
  
  if (pp==NULL) {
    printf ("Warning: Rtk_PP_simulate. pp==NULL\n");
    return;
  }
  
  //-- Obtener los modulos izquierdo y derecho
  mi=pp->lm;
  md=pp->rm;
    
  if (mi==NULL) {
    printf ("Warning. Rtk_PP_simulate. mi==NULL\n");
    return;
  }
  
  if (md==NULL) {
    printf ("Warning. Rtk_PP_simulate. mi==NULL\n");
    return;
  }
    
  //-- Obtener generadores
  gen1=pp->lm->gen;
  gen2=pp->rm->gen;
  
  //-- El flag de play de PP se asigna tambien a los generadores
  if (gen1!=NULL) gen1->Play=pp->Play;
  if (gen2!=NULL) gen2->Play=pp->Play;
  
  //-- Control realizado por PP
  if (pp->centralized_controller) {
    
    //-- Simular modulo izquierdo
    Rtk_Y1module_simulate(mi,0);
    
    //-- Simular modulo derecho
    Rtk_Y1module_simulate(md,0);
    
    //-- Si mi y md estables, actualizar generadores
    if (Rtk_Y1Module_trigger(mi) && Rtk_Y1Module_trigger(md)) {
      Rtk_Generator_next_sample(gen1);
      Rtk_Generator_next_sample(gen2);
    }
    
  }  
  //-- Control realizado por los propios Modulos Y1
  else {
    //-- Simular modulo izquierdo
    Rtk_Y1module_simulate(mi,1);
    
    //-- Simular modulo derecho
    Rtk_Y1module_simulate(md,1); 
    }
}

/*********************************/
/* Imprimir la configuracion PP  */
/*********************************/
void Rtk_PP_print(RtkPP *pp, int depth)
{
  if (pp==NULL) {
    printf ("Warning. Rtk_PP_print. pp==NULL\n");
    return;
  }
  
  for (int i=0; i<depth; i++)
    printf (" ");
    
  printf ("* Conf.PP\n");
  
  Rtk_Y1Module_print(pp->lm,depth+2);
  Rtk_Y1Module_print(pp->rm,depth+2);
}


/***********************************************/
/* Condicion de disparo de la configuracion PP */
/***********************************************/
int Rtk_PP_trigger(RtkPP *pp)
{
  if (Rtk_Y1Module_trigger(pp->lm) && Rtk_Y1Module_trigger(pp->rm))
    return 1;
  else 
    return 0;
}

/******************************************************************/
/* Obtener las coordenas del punto medio de la configuracion PP.  */
/* Coincide con la fijacion entre los dos modulos                 */
/* ENTRADAS:                                                      */
/*   -pp: Puntero a la configuracion PP                           */
/* SALIDAS:                                                       */
/*   -pos: Vector de posicion del punto medio                     */
/******************************************************************/
void Rtk_PP_get_center(RtkPP *pp, dVector3 pos)
{
  
  //-- Leer posicion de la fijacion
  dJointGetHingeAnchor(pp->fixation,pos);  
}

/****************************************/
/* Hacer reset de la configuracion PP   */
/****************************************/
void Rtk_PP_reset(RtkPP *pp)
{
  Rtk_Y1Module_reset(pp->lm);
  Rtk_Y1Module_reset(pp->rm);
  
  //-- Establecer punto de anclaje inicial de la fijacion
  dJointSetHingeAnchor (pp->fixation, pp->fixation_ini[X], 
                        pp->fixation_ini[Y],
                        pp->fixation_ini[Z]);
  
  //-- Velocidad del servo a 0
  dJointSetHingeParam(pp->fixation, dParamVel, 0.0);
}

/*******************************************************/
/* Devolver uno de los generadores asociados al robot  */
/*******************************************************/
RtkGenerator *Rtk_PP_get_generator(RtkPP *pp)
{
  RtkY1Module *mod;
  
  mod = pp->lm;
  
  return Rtk_Y1Module_get_generator(mod);
}
