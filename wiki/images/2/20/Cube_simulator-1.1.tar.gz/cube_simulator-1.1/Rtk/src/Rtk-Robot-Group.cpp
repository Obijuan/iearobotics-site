/**  \file Rtk-Robot-Group.cpp
  *  \brief Roboget del tipo grupo de robots
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño.
  *  \date Agosto 2006. Licencia GPL
*/

#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/***********************************/
/* Crear un nuevo grupo de robots  */
/***********************************/
void Rtk_Robot_Group_new(RtkRobotGroup *group)
{
  //-- Poner a cero el objeto
  memset(group, 0, sizeof(RtkRobotGroup));
  
  
  //-- Iniciar los valores por defecto
  
  //-- Indica el tipo de roboget
  group->type=RTK_TYPE_ROBOT_GROUP;
  
  //-- Roboget padre
  group->Parent=NULL;
  
  //-- Tipo del roboget padre
  group->Parent_type=RTK_TYPE_UNKNOW;
  
  //-- Enlace al simulador
  group->sim=NULL;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  
  //! Robots dentro del grupo
  for (int i=0; i<MAX_ROBOTS; i++)
    group->roboget[i]=NULL;
  
  //-- Numero de robots en el grupo
  group->size=0;
}


/***********************************/
/* Anadir un robot al grupo        */
/***********************************/
void Rtk_Robot_Group_add(RtkRobotGroup *group, RtkRobot *robot)
{
  //-- Enlace del grupo al robot
  group->roboget[group->size] = robot;
  group->size++;
  
  //-- Enlace del robot al grupo
  robot->Parent=group;
  robot->Parent_type=group->type;
}

/********************************/
/* Crear el grupo de robots     */
/********************************/
void Rtk_Robot_Group_create(RtkSimulationEngine *sim, RtkRobotGroup *group)
{
  
  //-- Enlazar con la simulacion
  group->sim=sim;
  
  //-- Crear los robots del grupo
  for (int i=0; i<group->size; i++)
    Rtk_Robot_create(sim,group->roboget[i]);
}

/************************************/
/* Simular el grupo de robots       */
/************************************/
void Rtk_Robot_Group_simulate(RtkRobotGroup *group)
{
  if (group==NULL) {
    printf ("Warning: Rtk_Robot_Group_simulate. group==NULL\n");
    return;
  }
  
  //-- Simular cada uno de los robots
  for (int i=0; i<group->size; i++)
    Rtk_Robot_simulate(group->roboget[i]);
}

/***********************************************/
/* Imprimir la estructrua del grupo de robots  */
/***********************************************/
void Rtk_Robot_Group_print(RtkRobotGroup *group, int depth)
{
  if (group==NULL) {
    printf ("Warning: Rtk_Robot_Group_print. group==NULL\n");
    return;
  }
  
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Robot Group\n");
  
  //-- Simular cada uno de los robots
  for (int i=0; i<group->size; i++)
    Rtk_Robot_print(group->roboget[i],depth+2);
}

/**********************************************/
/* Hacer reset de un grupo de robots          */
/**********************************************/
void Rtk_Robot_Group_reset(RtkRobotGroup *group)
{
  if (group==NULL) {
    printf ("Warning: Rtk_Robot_Group_reset. group==NULL\n");
    return;
  }
  
  //-- Hacer reset de cada uno de los robots
  for (int i=0; i<group->size; i++)
    Rtk_Robot_reset(group->roboget[i]);
}
