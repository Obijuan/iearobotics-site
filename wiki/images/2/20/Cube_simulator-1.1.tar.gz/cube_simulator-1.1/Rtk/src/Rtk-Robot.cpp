/**  \file Rtk-Robot.cpp
  *  \brief Roboget del tipo Robot
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño.
  *  \date Agosto 2006. Licencia GPL
*/

#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/

/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/*****************************************/
/* Crear un nuevo objeto del tipo robot  */
/*****************************************/
void Rtk_Robot_new(RtkRobot *robot)
{
  
  //-- Poner a cero el objeto
  memset(robot, 0, sizeof(RtkRobot));
  
  //-- Indicar el tipo de Roboget
  robot->type=RTK_TYPE_ROBOT;
  
  //-- Todavia no tiene padre
  robot->Parent=NULL;
  robot->Parent_type=RTK_TYPE_UNKNOW;
  
  //-- Todavia no tiene un simulador asociado
  robot->sim=NULL;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL ROBOT  */
  /**********************************/
  
  //-- Todavia no tienen ningun roboget asociado
  robot->roboget=NULL;
  robot->roboget_type=RTK_TYPE_UNKNOW;
  
  
}

/********************************************/
/* Asociar un roboget al robot              */
/********************************************/
void Rtk_Robot_add(RtkRobot *robot, void *roboget, int type)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
 
  //-- Control de errores
  if (robot==NULL) {
    printf ("Warning: Puntero a robot NULO!!\n");
    return;
  }
  
  if (roboget==NULL) {
    printf ("Warning: Puntero a Roboget NULO!!\n");
    return;
  }  
    
  
  //-- Establecer el Roboget "hijo"
  
  switch(type) {
    
    case RTK_TYPE_ROBOT:
      printf ("Warning: No se puede asociar un robot a otro robot\n");
      return;
      break;
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Enlazar al modulo "hijo"
      mod=(RtkY1Module *)roboget;
      robot->roboget = mod;
      robot->roboget_type = type;
    
      //-- Enlazar del hijo al padre
      mod->Parent=(RtkRobot *)robot;
      mod->Parent_type=robot->type;
      break;
    
    case RTK_TYPE_PP:
      //-- Enlazar a la configuracion PP hija
      pp=(RtkPP *)roboget;
      robot->roboget = pp;
      robot->roboget_type = type;
    
      //-- Enlazar del hijo al padre
      pp->Parent=(RtkRobot *)robot;
      pp->Parent_type=robot->type;
      break;
    
    case RTK_TYPE_CHAIN:
      //-- Enlazar a la cadena
      chain=(RtkChain *)roboget;
      robot->roboget = chain;
      robot->roboget_type=type;
    
      //-- Enlazar del hijo al padre
      chain->Parent=(RtkRobot *)robot;
      chain->Parent_type=robot->type;
      break;
    
    default:
      printf ("Warning: Tipo desconocido\n");
      return;
  }
  
}


/********************************************************/
/* Crear un robot completo y asociarlo a la simulacion  */
/********************************************************/
void Rtk_Robot_create(RtkSimulationEngine *sim, RtkRobot *robot)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  
  //-- Control de errores
  if (sim==NULL) {
    printf ("Warning: Puntero a simulacion NULO!!\n");
    return;
  }
  
  if (robot==NULL) {
    printf ("Warning: Puntero a robot NULO!!\n");
    return;
  }
  
  //-- Enlazar con la simulacion
  robot->sim=sim;
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_ROBOT:
      printf ("Warning: Un robot no puede contener a otro robot\n");
      return;
      break;
    
    case RTK_TYPE_Y1MODULE:
      //-- Crear el modulo
      mod=(RtkY1Module *)robot->roboget;
      Rtk_Y1module_create(sim,mod);
      break;
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_PP_create(sim,pp);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_Chain_create(sim,chain);
      break;
    
    default:
      printf ("Warning: Tipo desconocido!!!\n");
      return;
  }
}

/****************************************/
/* Simular un robot                     */
/****************************************/
void Rtk_Robot_simulate(RtkRobot *robot)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  if (robot==NULL) {
    printf ("Warning. Rtk_Robot_simulate. robot==NULL\n");
  }
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Por defecto se simula junto con su generador
      mod=(RtkY1Module *)robot->roboget;
      Rtk_Y1module_simulate(mod,1);
      break; 
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_PP_simulate(pp);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_Chain_simulate(chain);
      break;
  }
}


/****************************************/
/* Simular un robot                     */
/****************************************/
void Rtk_Robot_print(RtkRobot *robot, int depth)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  if (robot==NULL) {
    printf ("Warning. Rtk_Robot_print. robot==NULL\n");
  }
  
  //-- Imprimir indentado
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Robot.\n");
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Por defecto se simula junto con su generador
      mod=(RtkY1Module *)robot->roboget;
      Rtk_Y1Module_print(mod,depth+2);
      break; 
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_PP_print(pp, depth+2);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_Chain_print(chain,depth+2);
      break;
  }
}

/**************************************/
/* Hacer un reset del robot           */
/**************************************/
void Rtk_Robot_reset(RtkRobot *robot)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  if (robot==NULL) {
    printf ("Warning. Rtk_Robot_reset. robot==NULL\n");
  }
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Hacer reset del modulo
      mod=(RtkY1Module *)robot->roboget;
      Rtk_Y1Module_reset(mod);
      break; 
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_PP_reset(pp);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_Chain_reset(chain);
      break;
  }
}

/*****************************************/
/* Obtener la posicion del robot         */
/*****************************************/
void Rtk_Robot_get_center(RtkRobot *robot, dVector3 pos)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  if (robot==NULL) {
    printf ("Warning. Rtk_Robot_get_center. robot==NULL\n");
  }
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Obtener la posicion del modulo
      mod=(RtkY1Module *)robot->roboget;
      Rtk_Y1Module_get_center(mod, pos);
      break; 
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      Rtk_PP_get_center(pp, pos);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      Rtk_Chain_get_center(chain,pos);
      break;
  }
}


/*****************************************************/
/* Devolver un generador del robot                   */
/* En el caso de una cadena o configuracion PP se    */
/* devuelve el modulo de la izquierda                */
/*****************************************************/
RtkGenerator *Rtk_Robot_get_generator(RtkRobot *robot)
{
  RtkY1Module *mod;
  RtkPP       *pp;
  RtkChain    *chain;
  
  if (robot==NULL) {
    printf ("Warning. Rtk_Robot_get_generator. robot==NULL\n");
  }
  
  //-- Segun el tipo del roboget "hijo"
  switch(robot->roboget_type) {
    
    case RTK_TYPE_Y1MODULE:
      
      //-- Obtener la posicion del modulo
      mod=(RtkY1Module *)robot->roboget;
      return Rtk_Y1Module_get_generator(mod);
      break; 
    
    case RTK_TYPE_PP:
      pp=(RtkPP *)robot->roboget;
      return Rtk_PP_get_generator(pp);
      break;
    
    case RTK_TYPE_CHAIN:
      chain=(RtkChain *)robot->roboget;
      return Rtk_Chain_get_generator(chain);
      break;
  }
  
  return NULL;
}
