/*---------------------------------------------------------------------------*/
/**  \file test-robots.cpp
  *  \brief Ejemplo de prueba de las RTK
  *
  *  Ejemplo de pruebas de diferentes configuraciones.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Agosto 2006
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include "T1D.h"
#include "Rtk-3D.h"

/****************************/
/* VARIABLES                */
/****************************/
//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
	if (cmd=='1') {
    
  }
  else if (cmd=='2') {
    printf ("TIEMPO DE CICLO--: %d\n",worm.t);
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    
   
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
      
      //-- Imprimir duracion del ciclo
      printf ("  Periodo  : %.2f seg\n", worm.period);
    }
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  usleep(10);
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  
  //-- Analizar parametros pasados por el usuario
  ok=T1D_get_args(&worm,argc,argv,true);
  
  if (!ok) {
    printf ("Argumentos incorrectos\n");
    exit(1);
  }
   
  //-- CONSTRUIR CONFIGURACION 
  T1D_new_robot(&worm,true,false);
  
  worm.sim.mu=0.2;
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));  
 
  
}
