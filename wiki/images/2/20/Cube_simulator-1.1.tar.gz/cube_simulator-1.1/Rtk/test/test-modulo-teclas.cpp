/*---------------------------------------------------------------------------*/
/**  \file test-modulo-teclas.cpp
  *  \brief Ejemplo de prueba de las RTK. Movimiento de un modulo con teclas
  *
  *  Ejemplo de pruebas para un modulo Y1. Utilizando las teclas se pueden
  *  establecer diferentes posiciones de referencia para el servo
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Agosto 2006
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>

#include "Rtk-3D.h"

/****************************/
/* VARIABLES                */
/****************************/

//-- RoboGets 
static RtkRobot            robot;
static RtkY1Module         mod;
static RtkSimulationEngine sim;


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
  
	if (cmd=='1') {
    Rtk_Y1Module_set_pos_ref_grados(&mod,-60);
  }
  else if (cmd=='2') {
    Rtk_Y1Module_set_pos_ref_grados(&mod,0);
  }
  else if (cmd=='3') {
    Rtk_Y1Module_set_pos_ref_grados(&mod,60);
  }
  else if (cmd=='q') {
    dsStop();
  }
  
  
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
	
  if (!pause) {
		
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim);
   
  }
	
  //-- Renderizar
  Rtk_3D_render(&sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(int (sim.step*1000000));
  
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  /*--------------------------------*/
  /* CONSTRUIR EL ROBOT             */
  /*--------------------------------*/
  
  //-- Crear modulo con sus propiedades
  Rtk_Y1Module_new(&mod);
    mod.pitch=0;
    
    //-- Color
    mod.red=1;
    mod.green=0;
    mod.blue=0;
  
    //-- Con esto se establecen la longitud de los brazos izquierdo y derecho
    mod.Li=RTK_MM_TO_METROS(100);
    mod.Ld=RTK_MM_TO_METROS(50);
  
    //-- Establecer las propiedades
    Rtk_Y1Module_set_data(&mod);

  //-- Crear robot y asociarle el modulo
  Rtk_Robot_new(&robot);                   
  Rtk_Robot_add(&robot,&mod,mod.type);
  
  
  //-- Crear la simulacion
  Rtk_Simulation_Engine_new(&sim);
  
  //-- Anadir el robot a la simulacion
  Rtk_Simulation_Engine_Add(&sim, &robot, robot.type);
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&sim);
  
}
