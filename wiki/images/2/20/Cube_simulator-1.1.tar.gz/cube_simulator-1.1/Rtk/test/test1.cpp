/*---------------------------------------------------------------------------*/
/**  \file test-robots.cpp
  *  \brief Ejemplo de prueba de las RTK
  *
  *  Ejemplo de pruebas de diferentes configuraciones.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Agosto 2006
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>

#include "Rtk-3D.h"

/****************************/
/* VARIABLES                */
/****************************/

//-- RoboGets 
static RtkY1Module         mod1;
static RtkSimulationEngine sim;
static RtkGenerator        gen1,gen3;
static RtkRobotGroup       group;
static RtkPP               pp;
static RtkSampledFunction  test1,test2;

/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
	if (cmd=='1') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,-30);
  }
  else if (cmd=='2') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,0);
  }
  else if (cmd=='3') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,30);
  }
  else if (cmd=='4') {
    Rtk_Generator_set_func(&gen1,&test1);
  }
  else if (cmd=='5') {
    Rtk_Generator_set_func(&gen1,&test2);
  }
  else if (cmd=='r') {
    Rtk_Simulation_Engine_reset(&sim);
  }
  else if (cmd=='s') {
    Rtk_Generator_set_play(&gen3,0);
  }
  else if (cmd=='p') {
    Rtk_Generator_set_play(&gen3,1);
  }
  else if (cmd=='z')
    pp.Play=0;
  else if (cmd=='x')
    pp.Play=1;
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
   
    //Rtk_Simulation_Engine_print(&sim);
    //dsStop();
    
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim);
    
    if (gen3.period_transition==1)
      printf ("Nuevo periodo: %d\n",gen3.period_counter);
  }
  
  //-- Renderizar
  Rtk_3D_render(&sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(int (sim.step*1000000));
	
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  /*-----------------------*/
  /* ROBOT 5               */
  /*-----------------------*/
  #define MOD 3
  RtkY1Module mod[MOD];
  RtkGenerator gen[MOD];
  RtkRobot    robot5;
  RtkChain    chain;
  RtkSampledFunction r5_sf;
  
  printf ("Ini...\n");
  
  //-- Crear una cadena
  Rtk_Chain_new(&chain);
  
  Rtk_Sampled_Function_new_from_sine_func(&r5_sf,20,0,0,10);
  
  for (int i=0; i<MOD; i++) {
    Rtk_Y1Module_new(&mod[i]);
    
    //mod[i].pitch=0;
   if (i % 2 == 0) {
      mod[i].pitch=0;
      mod[i].red=0;
   }  
    
    Rtk_Generator_new(&gen[i]);
    Rtk_Generator_set_func(&gen[i],&r5_sf);
    Rtk_Y1Module_generator_add(&mod[i],&gen[i]);
    Rtk_Chain_add(&chain, &mod[i]);
  }
  
  Rtk_Chain_set_initial_pos(&chain,
                            0.0,
                            0.0,
                            RTK_MM_TO_METROS(50));
  
  //chain.centralized_controller=1;
  
  //-- Robot
  Rtk_Robot_new(&robot5);
  Rtk_Robot_add(&robot5,&chain,chain.type);
  
  
  /*-----------------------------*/
  /* CREAR EL GRUPO DE ROBOTS    */
  /*-----------------------------*/
  Rtk_Robot_Group_new(&group);
  Rtk_Robot_Group_add(&group, &robot5);
  
  /*----------------------------*/
  /* CREAR LA SIMULACION        */
  /*----------------------------*/
  Rtk_Simulation_Engine_new(&sim);
  
  //-- Anadir el robot a la simulacion
  Rtk_Simulation_Engine_Add(&sim,&group,group.type);
  
  printf ("Hola!!!!\n");
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&sim);
  
}
