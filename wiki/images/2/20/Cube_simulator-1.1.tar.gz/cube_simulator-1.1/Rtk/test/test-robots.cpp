/*---------------------------------------------------------------------------*/
/**  \file test-robots.cpp
  *  \brief Ejemplo de prueba de las RTK
  *
  *  Ejemplo de pruebas de diferentes configuraciones.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date Agosto 2006
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>

#include "Rtk-3D.h"

/****************************/
/* VARIABLES                */
/****************************/

//-- RoboGets 
static RtkRobot            robot1,robot2,robot3,robot4;
static RtkY1Module         mod1,mod2,mi,md;
static RtkSimulationEngine sim;
static RtkGenerator        gen1,gen2,gen3,gen4;
static RtkRobotGroup       group;
static RtkPP               pp;
static RtkSampledFunction  sf1,sf2;
static RtkSampledFunction  test1,test2;


static dReal func1[]={90, -90};
static dReal func2[]={45, -45};
static dReal func3[]={10,10};
static dReal func_A40_T10_FI0[]  ={0,23,38,38,23,0,-23,-38,-38,-23,};
static dReal func_A40_T10_FI120[]={34,16,-8,-29,-39,-34,-16,8,29,39,};

static dReal s1[]={0,23,38,38,23,0,-23,-38,-38,-23,};
static dReal s2[]={34,16,-8,-29,-39,-34,-16,8,29,39,};

static dReal t1[]={80,0,-80,0};
static dReal t2[]={0,-80,0,80};

static RtkSampledFunction func = {
  {0,23,38,38,23,0,-23,-38,-38,-23,},
  10,
};


/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
	if (cmd=='1') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,-30);
  }
  else if (cmd=='2') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,0);
  }
  else if (cmd=='3') {
    Rtk_Y1Module_set_pos_ref_grados(&mod1,30);
  }
  else if (cmd=='4') {
    Rtk_Generator_set_func(&gen1,&test1);
  }
  else if (cmd=='5') {
    Rtk_Generator_set_func(&gen1,&test2);
  }
  else if (cmd=='r') {
    Rtk_Simulation_Engine_reset(&sim);
  }
  else if (cmd=='s') {
    Rtk_Generator_set_play(&gen3,0);
  }
  else if (cmd=='p') {
    Rtk_Generator_set_play(&gen3,1);
  }
  else if (cmd=='z')
    pp.Play=0;
  else if (cmd=='x')
    pp.Play=1;
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
	if (!pause) {
   
    //Rtk_Simulation_Engine_print(&sim);
    //dsStop();
    
    //-- Realizar un paso de simulacion
    Rtk_Simulation_Engine_step(&sim);
    
    if (gen3.period_transition==1)
      printf ("Nuevo periodo: %d\n",gen3.period_counter);
  }
	
  //-- Renderizar
  Rtk_3D_render(&sim);
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  usleep(int (sim.step*1000000));
	
}

/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  
  //-- Crear algunas funciones de prueba
  Rtk_Sampled_Function_new_from_array(&test1,func1,RTK_FUNC_SIZE(func1));
  Rtk_Sampled_Function_new_from_array(&test2,func2,RTK_FUNC_SIZE(func2));
  
  /*--------------------------------*/
  /* CONSTRUIR EL ROBOT 1           */
  /*--------------------------------*/
  
  //-- Crear modulo Y1 con sus propiedades
  Rtk_Y1Module_new(&mod1);
    mod1.pitch=0;
    mod1.Li=RTK_MM_TO_METROS(100);
    mod1.red=1;
    mod1.green=0;
    mod1.blue=0;
    mod1.xini=RTK_MM_TO_METROS(150);
    //mod1.altura=0.001;
    Rtk_Y1Module_set_data(&mod1);
  
  //-- Anadir un generador
  Rtk_Generator_new(&gen1);
  Rtk_Y1Module_generator_add(&mod1,&gen1);
  

  Rtk_Robot_new(&robot1);                  
  Rtk_Robot_add(&robot1,&mod1,mod1.type);
  
  printf ("The first robot has been created!\n");
  
  
  /*-----------------------------------*/
  /* CONSTRUIR EL ROBOT 2              */
  /*-----------------------------------*/
  //-- Crear modulo Y1 con sus propiedades
  Rtk_Y1Module_new(&mod2);
    mod2.pitch=1;
    mod2.Li=RTK_MM_TO_METROS(50);
    mod2.red=0;
    mod2.green=1;
    mod2.blue=0;
    mod2.xini=RTK_MM_TO_METROS(80);
    Rtk_Y1Module_set_data(&mod2);
  
  //-- Anadir un generador
  Rtk_Generator_new(&gen2);
  Rtk_Y1Module_generator_add(&mod2,&gen2);
  
  Rtk_Robot_new(&robot2);                  
  Rtk_Robot_add(&robot2,&mod2,mod2.type);
  
  printf ("The second robot has been created!\n");
  
  /*-----------------------------*/
  /* CONSTRUIR ROBOT 3           */
  /*-----------------------------*/
  Rtk_Y1Module_new(&mi);
  Rtk_Y1Module_new(&md);
  
  printf ("Check1\n");
  
  Rtk_PP_new(&pp);
  Rtk_PP_add(&pp,&mi,&md);
  Rtk_PP_set_initial_pos(&pp,
                         RTK_MM_TO_METROS(0),
                         RTK_MM_TO_METROS(300),
                         RTK_MM_TO_METROS(0));
  
  
  //-- generadores
  Rtk_Generator_new(&gen3);
  Rtk_Y1Module_generator_add(&mi,&gen3);
  
  Rtk_Generator_new(&gen4);
  Rtk_Y1Module_generator_add(&md,&gen4);
  
  Rtk_Sampled_Function_new_from_mvm_file(&sf1, "genetico.mvm",1);
  Rtk_Sampled_Function_print(&sf1);
  Rtk_Generator_set_func(&gen3,&sf1);
  
  Rtk_Sampled_Function_new_from_mvm_file(&sf2, "genetico.mvm",2);
  Rtk_Sampled_Function_print(&sf2);
  Rtk_Generator_set_func(&gen4,&sf2);
  
  //-- Robot 
  Rtk_Robot_new(&robot3);
  Rtk_Robot_add(&robot3,&pp,pp.type);
  
  printf ("The third robot has been created!\n");
  
  
  /*-------------------------------*/
  /* CONSTRUIR ROBOT 4             */
  /*-------------------------------*/
  RtkY1Module mi2,md2;
  RtkPP pp2;
  RtkGenerator gen5,gen6;
  RtkSampledFunction sf3,sf4;
  
  Rtk_Y1Module_new(&mi2);
    mi2.red=1;
    mi2.green=1;
    mi2.blue=1;
    Rtk_Y1Module_set_data(&mi2);
  
  Rtk_Y1Module_new(&md2);
    md2.red=1;
    md2.green=1;
    md2.blue=1;
    Rtk_Y1Module_set_data(&md2);
  
  Rtk_PP_new(&pp2);
  Rtk_PP_add(&pp2,&mi2,&md2);
  Rtk_PP_set_initial_pos(&pp2,
                         RTK_MM_TO_METROS(-60),
                         RTK_MM_TO_METROS(50),
                         RTK_MM_TO_METROS(50));
  
  //-- generadores
  Rtk_Generator_new(&gen5);
  Rtk_Y1Module_generator_add(&mi2,&gen5);
  
  Rtk_Generator_new(&gen6);
  Rtk_Y1Module_generator_add(&md2,&gen6);
  
  Rtk_Sampled_Function_new_from_sine_func(&sf3,40,0,0,10);
  //Rtk_Sampled_function_new_from_mvm_file(&sf3, "pp80-120.mvm",1);
  Rtk_Sampled_Function_output_mrs(&sf3);
  Rtk_Sampled_Function_output_c(&sf3);
  Rtk_Sampled_Function_output_octave(stdout,&sf3);
  Rtk_Sampled_Function_print(&sf3);
  Rtk_Generator_set_func(&gen5,&sf3);
  //Rtk_Generator_set_func(&gen5,t1,RTK_FUNC_SIZE(t1));
  
  Rtk_Sampled_Function_new_from_sine_func(&sf4,40,120,0,10);
  //Rtk_Sampled_function_new_from_mvm_file(&sf4, "pp80-120.mvm",2);
  Rtk_Sampled_Function_print(&sf4);
  Rtk_Generator_set_func(&gen6,&sf4);
  //Rtk_Generator_set_func(&gen6,t2,RTK_FUNC_SIZE(t2));
  
  //-- Robot 
  Rtk_Robot_new(&robot4);
  Rtk_Robot_add(&robot4,&pp2,pp2.type);
  
  /*-----------------------*/
  /* ROBOT 5               */
  /*-----------------------*/
  #define MOD 10
  RtkY1Module mod[MOD];
  RtkY1Module mod2[MOD];
  RtkGenerator gen[MOD];
  RtkRobot    robot5;
  RtkChain    chain;
  RtkSampledFunction r5_sf;
  
  //-- Crear una cadena
  Rtk_Chain_new(&chain);
  
  Rtk_Sampled_Function_new_from_sine_func(&r5_sf,20,0,0,10);
  
  for (int i=0; i<MOD; i++) {
    Rtk_Y1Module_new(&mod[i]);
    
    if (i % 2 == 0) {
      mod[i].pitch=0;
      mod[i].red=0;
    }  
    
    Rtk_Generator_new(&gen[i]);
    Rtk_Generator_set_func(&gen[i],&r5_sf);
    Rtk_Y1Module_generator_add(&mod[i],&gen[i]);
    Rtk_Chain_add(&chain, &mod[i]);
  }
  
  Rtk_Chain_set_initial_pos(&chain,
                            RTK_MM_TO_METROS(400),
                            0.0,
                            RTK_MM_TO_METROS(50));
  
  //chain.centralized_controller=1;
  
  //-- Robot
  Rtk_Robot_new(&robot5);
  Rtk_Robot_add(&robot5,&chain,chain.type);
  
  
  printf ("Hello?\n");
  
  /*-----------------------------*/
  /* CREAR EL GRUPO DE ROBOTS    */
  /*-----------------------------*/
  Rtk_Robot_Group_new(&group);
  Rtk_Robot_Group_add(&group, &robot1);
  Rtk_Robot_Group_add(&group, &robot2);
  Rtk_Robot_Group_add(&group, &robot3);
  Rtk_Robot_Group_add(&group, &robot4);
  Rtk_Robot_Group_add(&group, &robot5);
  
  /*----------------------------*/
  /* CREAR LA SIMULACION        */
  /*----------------------------*/
  Rtk_Simulation_Engine_new(&sim);
  
    //ctx.SurfaceLayer=0;
    //ctx.mu=0;
    
  printf ("Hello?\n");
    
  
  //-- Anadir el robot a la simulacion
  //Rtk_Simulation_Engine_Add(&sim,&robot2,robot2.type);
  Rtk_Simulation_Engine_Add(&sim,&group,group.type);
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&sim);
  
}
