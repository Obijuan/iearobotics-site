/*---------------------------------------------------------------------------*/
/**  \file Rtk_Y1Module.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_Y1MODULE
  *
  *  Structuras de datos, definiciones y prototipos de RTK_Y1MODULE          */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_Y1MODULE_H
#define _RTK_Y1MODULE_H

#include <ode/ode.h>
#include "Rtk-Generator.h"

/*-----------------------------*/
/* CONSTANTES DEL MODULO Y1    */
/*-----------------------------*/
// -- Se utilizan para establecer los valores por defecto del modulo Y1

//! Longitud del Modulo Y1 en milimetros
#define LONG_mm    72

//! Grosor del modulo Y1 en milimetros
#define GROSOR_mm  52


// Para pruebas
//#define GROSOR_mm 10

//! Altura del modulo Y1
#define ALTURA_mm  GROSOR_mm

//#define ALTURA_mm 1

//! Masa del modulo en gramos
#define MASA_gr 50
//#define MASA_gr 10

//! Par del servo en N.m. Valor futaba: 0.314
//valor para pruebas: infinito
#define SERVO_PAR_Nm 20 //0.314 //En Kg.m el par es: 0.032

//! Ganancia del controlador P del servo
#define KP 2.0*4.3

//! Ganancia del controlador I del servo
#define KI 0.0

#define KD 0

//! Velocidad maxima en Rad/seg
#define WMAX 13.0*M_PI/9.0

//-- Error minimo en grados
//-- Normal: 5
#define ERROR_MIN 5

//-- Numero maximo de geometrias para un objeto
#define MAX_GEOM 2

/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura para describir un objeto en ODE
    *
    * Los objetos del universo ODE estan formados por dos partes: 
    * un cuerpo y una geometria: \n
    * -Cuerpo (body): Tiene la informacion sobre posicion, orientacion,
         velocidades lineales y angulares.
    * -Geometrias: Determinan la forma y se usan para las colisiones.
*/
struct OdeObject {
  //! Cuerpo del objeto
  dBodyID body;
  
  //! Numero de geometrias que forman el cuerpo
  int ng;
  
  //! Geometrias del objeto
  dGeomID geom[MAX_GEOM];
  
  //! Posicion inicial
  dVector3 pos_ini;
  
  //! Rotacion inicial
  dMatrix3 Rot_ini;

};


/** \brief Estructura de datos para los modulos Y1
    *
    * El modulo esta compuesto fisicamente por una articulacion y 
        y dos segmentos. En la estrcutura se incluyen tambien las variables
        que define sus estado, como la posicion deseada (de referencia) y 
        el error actual.
*/
struct RtkY1Module {
  
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  
  /************************************/
  /* CAMPOS PARTICULARES DEL ROBOTGET */
  /************************************/
  //! Puntero al generador
  RtkGenerator *gen;
  
  //! Tipo del generador
  int generator_type;
  
  //-- Atributos relacionados con la estrucutra ------------------------
  
  //! Segmentos del servo. 0 izquierdo. 1 derecho
  OdeObject seg[2];

  //! Articulacion que conecta los dos segmentos  
  dJointID servo; 
  
  //! Punto de anclaje inicial. Usado para restablecer su valor al hacer reset
  dVector3 anclaje_ini;
  
  //! Orientacion del modulo. Si se mueve segun eje pitch (1) o yaw(0)
  int pitch;

  //! Posicion inicial del modulo. Coordenada x
  dReal xini;
  
  //! Posicion inicial del modulo. Coordenada y
  dReal yini;
  
  //! Posicion inicial del modulo. Coordenada z
  dReal zini;
  
  //! Longitud del brazo izquierdo (en metros)
  dReal Li;
  
  //! Longitud total del brazo derecho (en metros)
  dReal Ld;
  
  //! Longitud total del modulo (en metros) (suma de Li + Ld) 
  dReal L;
  
  //! Grosor del modulo (en metros)
  dReal grosor;
  
  //! Altura del modulo (en metros)
  dReal altura;
  
  //! Masa (en kilos)
  dReal M;
  
  //! Masa del segmento izquierdo (en Kilos)
  dReal Mi;
  
  //! Masa del segmento derecho (en Kilos)
  dReal Md;
  
  //! Par maximo del servo (en Nm)
  dReal par;
  
  //! Velocidad maxima
  dReal wmax;
  
  //! Ganancia del controlador P del servo
  dReal Kp;
  
  //! Ganancia del controlador Integral
  dReal Ki;
  
  //! Ganancia del controlador diferencial
  dReal Kd;
  
  //! Estado controlador Integral: error acumulado
  dReal estado_integral;
  
  //! Estado integral: posicion anterior
  dReal estado_dif;
   
  //--- Atributos relacionados con el estado del servo -----------------
  //! Posicion de refencia del servo en radianes
  dReal pos_ref;
  
  //! Error actual en Radianes.
  dReal error;

  //! Error minimo en Radianes. 
  dReal error_min; 
  
  //-- Atributos relacionados con el renderizado
  //! Color. Grado de Rojo
  float red;
  
  //! Color. Grado de verde
  float green;
  
  //! Color. Grado de azul
  float blue;
  
  //! Numero del servo real al que esta conectado
  int servo_real;
  
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/

/*----------------------------------------------------------------------------*/
/** \brief Crear un nuevo modulo. Se inicializa con los valores por defecto  
 *
 *   \param mod : SALIDA. Modulo con los parametros por defecto               */
/*----------------------------------------------------------------------------*/
void  Rtk_Y1Module_new(RtkY1Module *mod);


void Rtk_Y1module_create(RtkSimulationEngine *sim, RtkY1Module *mod);
void Rtk_Y1module_simulate(RtkY1Module *mod, int simulate_generator);
void Rtk_Y1Module_set_pos_ref(RtkY1Module *mod, dReal pos);
void Rtk_Y1Module_set_pos_ref_grados(RtkY1Module *mod, dReal pos);
void Rtk_Y1Module_set_data(RtkY1Module *mod);
int Rtk_Y1Module_stable(RtkY1Module *mod);
dReal Rtk_Y1Module_get_pos(RtkY1Module *mod);
dReal Rtk_Y1Module_get_pos_grad(RtkY1Module *mod);
dReal Rtk_Y1Module_get_vel(RtkY1Module *mod);
void Rtk_Y1Module_generator_add(RtkY1Module *mod, RtkGenerator *gen);
int Rtk_Y1Module_trigger(RtkY1Module *mod);
void Rtk_Y1Module_print(RtkY1Module *mod, int depth);
void Rtk_Y1Module_get_center(RtkY1Module *mod, dVector3 pos);
void Rtk_Y1Module_reset(RtkY1Module *mod);
RtkGenerator *Rtk_Y1Module_get_generator(RtkY1Module *mod);


#endif  // _RTK_Y1MODULE_H
