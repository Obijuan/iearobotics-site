/*---------------------------------------------------------------------------*/
/**  \file Rtk_Sampled_function.h
  *  \brief Definiciones, estructuras de datos y prototipos 
  *         de RTK_SAMPLED_FUNCTION
  *  Structuras de datos, definiciones y prototipos de RTK_SAMPLED_FUNCTION  */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_SAMPLED_FUNCTION_H
#define _RTK_SAMPLED_FUNCTION_H

/*-----------*/
/* MACROS    */
/*-----------*/
#define RTK_FUNC_SIZE(x) sizeof(x)/sizeof(dReal)

#define MAX_SAMPLES 2100

/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura de datos para los generadores
    *
*/
struct RtkSampledFunction {
  
 //!-- Muestras de la funcion
 dReal f[MAX_SAMPLES];
  
 //!-- Numero de muestras
 int N;
    
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_Sampled_Function_new(RtkSampledFunction *sf);
int Rtk_Sampled_Function_new_from_mvm_file(RtkSampledFunction *sf,
                                            const char *fich, int nf);
int Rtk_Sampled_Function_new_from_mvm_file_fd(RtkSampledFunction *sf,
                                            FILE *fd, int nf);
void Rtk_Sampled_Function_print(RtkSampledFunction *sf);
void Rtk_Sampled_Function_new_from_sine_func(
   RtkSampledFunction *sf,
   dReal a,
   dReal df,
   dReal offset,
   int N);

void Rtk_Sampled_Function_new_from_array(RtkSampledFunction *sf, 
                                        dReal *f,
                                        int N);
                                        
void Rtk_Sampled_Function_output_mrs(FILE *fd, RtkSampledFunction *sf);
void Rtk_Sampled_Function_output_mrs(RtkSampledFunction *sf);
void Rtk_Sampled_Function_output_c(FILE *fd, RtkSampledFunction *sf);
void Rtk_Sampled_Function_output_c(RtkSampledFunction *sf);
void Rtk_Sampled_Function_output_octave(FILE *fd, RtkSampledFunction *sf);

void Rtk_Sampled_Function_new_from_harmonics(
   RtkSampledFunction *sf,
   dReal offset,
   dReal a0, dReal phase0, int N0,
   dReal a1, dReal phase1, int N1,
   dReal a2, dReal phase2, int N2,
   dReal a3, dReal phase3, int N3,
   dReal a4, dReal phase4, int N4);
   
void Rtk_Sampled_Function_roll_left(RtkSampledFunction *sf, int n);   


#endif  // _RTK_SAMPLED_FUNCTION_H
