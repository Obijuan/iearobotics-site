/*---------------------------------------------------------------------------*/
/**  \file Rtk_Generator.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_GENERATOR
  *
  *  Structuras de datos, definiciones y prototipos de RTK_GENERATOR         */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_GENERATOR_H
#define _RTK_GENERATOR_H

/*-----------*/
/* MACROS    */
/*-----------*/

#include "Rtk-Sampled-Function.h"
struct RtkSimulationEngine;
  
/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura de datos para los generadores
    *
*/
struct RtkGenerator {
  
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  /************************************/
  /* CAMPOS PARTICULARES DEL ROBOTGET */
  /************************************/
  //!-- Puntero a la las muestras de la funcion del generador
  dReal *f;
  
  //!-- Numero de muestras (Modulo)
  int N;
  
  //!-- Indice a la muestra actual
  int n;
  
  //!-- Indicador de periodos. En que periodo se esta. 0 significa transitorio
  int period_counter;
  
  //!-- Valor anterio del contador de periodos. 
  int period_counter_old;
  
  //!-- Transision. Se pone a 1 si se acaba de entrar en un nuevo periodo.
  int period_transition;
  
  //!-- Indicador de si el generador esta reproduciendo o no
  int Play;
    
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_Generator_new(RtkGenerator *gen);
void Rtk_Generator_create(RtkSimulationEngine *sim,
                          RtkGenerator *gen);
void Rtk_Generator_simulate(RtkGenerator *gen);
//void Rtk_Generator_set_func(RtkGenerator *gen, dReal *f, int size);
void Rtk_Generator_set_func(RtkGenerator *gen, RtkSampledFunction *sf);
void Rtk_Generator_set_N(RtkGenerator *gen, int N);
void Rtk_Generator_set_play(RtkGenerator *gen, int Play);
int Rtk_Generator_trigger(RtkGenerator *gen);
void Rtk_Generator_next_sample(RtkGenerator *gen);
void Rtk_Generator_print(RtkGenerator *gen, int depth);
void Rtk_Generator_reset(RtkGenerator *gen);



#endif  // _RTK_GENERATOR_H
