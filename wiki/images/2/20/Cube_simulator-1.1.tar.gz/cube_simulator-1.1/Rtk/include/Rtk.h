/*----------------------------------------------------------------------*/
/**  \file Rtk.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK
  *
  *  Structuras de datos, definiciones y prototipos de RTK              */
/*----------------------------------------------------------------------*/

#ifndef _RTK_H
#define _RTK_H

#include <ode/ode.h>

/*-------------------------*/
/* MACROS                  */
/*-------------------------*/

#ifndef RTK_TO_RADIANES
  //! Pasar de grados a radianes
  #define RTK_TO_RADIANES(x) x*M_PI/180.0
#endif

#ifndef RTK_TO_GRADOS
  //! Pasar de radianes a grados
  #define RTK_TO_GRADOS(x) 180*x/M_PI
#endif

#ifndef RTK_MM_TO_METROS
  //! Pasar de milimetros a metros
  #define RTK_MM_TO_METROS(x) x/1000.0
#endif

#ifndef RTK_GR_TO_KILOS
  //! Pasar de gramos a Kilos
  #define RTK_GR_TO_KILOS(x) x/1000.0
#endif

//! Valor por defecto del factor de visualizacion
#define FACTOR_VISUALIZACION 10

/************************************/
/* TIPOS PARA LOS ROBOGETS          */
/************************************/ 
#define RTK_TYPE_UNKNOW             0
#define RTK_TYPE_ROBOT              1
#define RTK_TYPE_Y1MODULE           2
#define RTK_TYPE_GENERATOR          3
#define RTK_TYPE_ROBOT_GROUP        4
#define RTK_TYPE_SIMULATION_ENGINE  5
#define RTK_TYPE_PP                 6
#define RTK_TYPE_CHAIN              7

#include "Rtk-Simulation-Engine.h"
#include "Rtk-Y1Module.h"
#include "Rtk-Robot.h"
#include "Rtk-Generator.h"
#include "Rtk-Robot-Group.h"
#include "Rtk-PP.h"
#include "Rtk-Sampled-Function.h"
#include "Rtk-Chain.h"
#include "Rtk-Fitness.h"



#endif  // _RTK_H
