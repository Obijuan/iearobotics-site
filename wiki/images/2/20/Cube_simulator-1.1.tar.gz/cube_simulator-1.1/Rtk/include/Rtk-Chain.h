/*---------------------------------------------------------------------------*/
/**  \file Rtk-Chain.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_CHAIN
  *
  *  Structuras de datos, definiciones y prototipos de RTK_CHAIN             */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_CHAIN_H
#define _RTK_CHAIN_H

#include <ode/ode.h>
  
  
#define RTK_MAX_MOD 50  
  
/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura para describir una cadena
    *
*/
struct RtkChain {
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  /*************************************/
  /* CAMPOS PARTICULARES DE LA CADENA  */
  /*************************************/
  
  //! Modulos dentro de la cadena
  RtkY1Module *module[RTK_MAX_MOD];
  
  //!-- Union entre los modulos. La primera fij. une modulos 0 y 1
  dJointID fixation[RTK_MAX_MOD-1];
  
  //!-- Valor inicial de las fijaciones
  dVector3 fixation_ini[RTK_MAX_MOD-1];
  
  //! Posicion inicial de la configuracion. Coordenada x
  dReal xini;
  
  //! Posicion inicial de la configuracion. Coordenada y
  dReal yini;
  
  //! Posicion inicial de la configuracion. Coordenada z
  dReal zini;
  
  //!-- Numero de modulos en la cadena
  int size;
  
  //!-- Flag que indica si el control lo hace la cadena o es independinete
  int centralized_controller;
  
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_Chain_new(RtkChain *chain);
void Rtk_Chain_add(RtkChain *chain, RtkY1Module *mod);
void Rtk_Chain_create(RtkSimulationEngine *sim, RtkChain *chain);
void Rtk_Chain_print(RtkChain *chain, int depth);
void Rtk_Chain_simulate(RtkChain *chain);
void Rtk_Chain_reset(RtkChain *chain);
void Rtk_Chain_get_center(RtkChain *chain, dVector3 pos);
void Rtk_Chain_set_initial_pos(RtkChain *chain, dReal x, dReal y, dReal z);
RtkGenerator *Rtk_Chain_get_generator(RtkChain *chain);
int Rtk_Chain_stable(RtkChain *chain);

#endif  // _RTK_CHAIN_H
