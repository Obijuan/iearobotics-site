/*---------------------------------------------------------------------------*/
/**  \file Rtk_PP.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_PP
  *
  *  Structuras de datos, definiciones y prototipos de RTK_PP                */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_PP_H
#define _RTK_PP_H

#include <ode/ode.h>

/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura de datos para la configuracion PP
    *
    * La configuracion esta compuesta por dos modulos que se mueven en el 
    * eje pitch.
*/
struct RtkPP {
  
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //!-- Indica el tipo de roboget
  int type;
  
  //!-- Roboget padre
  void *Parent;
  
  //!-- Tipo del roboget padre
  int Parent_type;
  
  //!-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  
  /************************************/
  /* CAMPOS PARTICULARES DEL ROBOTGET */
  /************************************/
  //!-- Modulo Izquierdo
  RtkY1Module *lm;
  
  //!-- Modulo derecho
  RtkY1Module *rm;
 
  //!-- Union entre los dos modulos
  dJointID fixation;
  
  //! Punto de anclaje inicial. Usado para restablecer su valor al hacer reset
  dVector3 fixation_ini;
  
  //! Posicion inicial de la configuracion. Coordenada x
  dReal xini;
  
  //! Posicion inicial de la configuracion. Coordenada y
  dReal yini;
  
  //! Posicion inicial de la configuracion. Coordenada z
  dReal zini;
  
  //!-- Flag que indica si el control lo hace PP o es independinete
  int centralized_controller;
  
  //!-- Flag para indicar si la conf. PP completa se mueve o no
  int Play;
  

};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_PP_new(RtkPP *pp);
void Rtk_PP_add(RtkPP *pp, RtkY1Module *mi, RtkY1Module *md);
void Rtk_PP_create(RtkSimulationEngine *sim, RtkPP *pp);
void Rtk_PP_simulate(RtkPP *pp);
int Rtk_PP_trigger(RtkPP *pp);
void Rtk_PP_print(RtkPP *pp, int depth);
void Rtk_PP_set_initial_pos(RtkPP *pp, dReal x, dReal y, dReal z);
void Rtk_PP_get_center(RtkPP *pp, dVector3 pos);
void Rtk_PP_reset(RtkPP *pp);
RtkGenerator *Rtk_PP_get_generator(RtkPP *pp);

#endif  // _RTK_PP_H
