/*---------------------------------------------------------------------------*/
/**  \file Rtk-Robot.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_ROBOT
  *
  *  Structuras de datos, definiciones y prototipos de RTK_ROBOT             */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_ROBOT_H
#define _RTK_ROBOT_H

#include <ode/ode.h>
#include "Rtk-Generator.h"

struct RtkSimulationEngine;
  
/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura para describir un Robot
    *
*/
struct RtkRobot {
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL ROBOT  */
  /**********************************/
  
  //! Roboget que contiene la estructura del robot
  void *roboget;
  
  //! El tipo del roboget "hijo"
  int roboget_type;
  
  
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/

/*----------------------------------------------------------------------------*/
/** \brief Crear un nuevo objeto robot        
 *
 *   \param mod : SALIDA. Robot con los parametros por defecto                */
/*----------------------------------------------------------------------------*/
void Rtk_Robot_new(RtkRobot *robot);


void Rtk_Robot_add(RtkRobot *robot, void *roboget, int type);
void Rtk_Robot_create(RtkSimulationEngine *sim, RtkRobot *robot);
void Rtk_Robot_simulate(RtkRobot *robot);
void Rtk_Robot_print(RtkRobot *robot, int depth);
void Rtk_Robot_reset(RtkRobot *robot);
void Rtk_Robot_get_center(RtkRobot *robot, dVector3 pos);
RtkGenerator *Rtk_Robot_get_generator(RtkRobot *robot);


#endif  // _RTK_ROBOT_H
