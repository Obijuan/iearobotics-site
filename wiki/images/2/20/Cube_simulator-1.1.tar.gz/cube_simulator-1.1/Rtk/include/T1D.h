/*---------------------------------------------------------------------------*/
/**  \file T1D.h
  *  \brief Definiciones, estructuras de datos y prototipos de T1D           *
  *  Structuras de datos, definiciones y prototipos de T1D                   */
/*---------------------------------------------------------------------------*/

#ifndef _T1D_H
#define _T1D_H

#include "Rtk.h"

/*----------------------------*/
/* CONSTANTES                 */
/*-----------------------------*/

//-- Tipos de estructuras
#define T1D_Pn    1
#define T1D_PYn   2
#define T1D_Yn    3

//-- Tipos de modulos
#define T1D_PITCH 1
#define T1D_YAW   2
#define T1D_X     0

//-- Numero maximo de modulos para considerar que ha habido un timeout
#define T1D_T_TIMEOUT_SEG 17
#define T1D_TICKS_TIMEOUT 1700

//-- Tipos de funciones de fitness
#define T1D_FITNESS_DX 1
#define T1D_FITNESS_DY 2
#define T1D_FITNESS_VX 3
#define T1D_FITNESS_VY 4
#define T1D_FITNESS_YAW 5
#define T1D_FITNESS_ROLL 6
#define T1D_FITNESS_WYAW 7
#define T1D_FITNESS_WROLL 8
#define T1D_FITNESS_DL 9


//-- Tipos de Cromosomas
#define T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh 1
#define T1D_CHROMO_T_DF_A               2
#define T1D_CHROMO_RAW                  3
#define T1D_CHROMO_Ti_Ai_Oi_Fi          4


/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

struct T1D_Robot {
  int nm;      //-- Numero de modulos de la configuracion
  int mod_ref; //-- Modulo de referencia para la locomocion
  
  //-- Parametros de los CPGs
  int cpg_A[RTK_MAX_MOD];
  int cpg_T[RTK_MAX_MOD];
  int cpg_F[RTK_MAX_MOD];
  int cpg_O[RTK_MAX_MOD];
  
  //-- Estructura de la topologia. Cada modulo puede ser:
  //-- PITCH, YAW, X
  int estructura[RTK_MAX_MOD];
  
  //-- Robogets
  RtkChain            cadena;
  RtkY1Module         mod[RTK_MAX_MOD];
  RtkGenerator        gen[RTK_MAX_MOD];
  RtkSampledFunction  sf[RTK_MAX_MOD];
  RtkRobot            robot;
  
  //-- Robogets de la simulacion
  RtkSimulationEngine sim;
  RtkRobotGroup       group;
  
  //------------------------------------------------
  //-- Conexionado para controlar el robot fisico  
  //------------------------------------------------
  int conexion[255];
  
  //---------------------------------------------
  //-- Variables internas de la simulacion
  //---------------------------------------------
  int timeout;   //-- Indica si se ha sobrepasadod el tiempo de ciclo maximo
  bool period_transition;
  int period_counter;     
  
  //-------------------- ESTADO EN CADA TICK -----------------------------
  int t;  //-- Contador de ticks en un ciclo
  
  //-- Posiciones x,y,z instantaneas (en cm)
  dReal x,y,z; 
  
  //-- Posicion maxima de z en el instante actual
  dReal zmax;
  
  //-- Posiciones x,y,z en el instante anterior
  dReal xold, yold, zold;
  
  //-- Incremento de posicion r(t) - r(t-1)
  dReal xinc, yinc, zinc;
  
  //-- Incremento acumulado en el instante t, dentro del ciclo actual
  dReal xinc_acum, yinc_acum, zinc_acum;
  
  //-- Posiciones angulares instantaneas (en radianes)
  dReal yaw, pitch, roll;
  
  //-- Posiciones angulares en el instante anterior
  dReal yawold, pitchold, rollold;
  
  //-- Incremento angular ang(t) - ang(t-1) instantaneo
  dReal yawinc, pitchinc, rollinc;
  
  //-- Incrementos angulares acumulados
  dReal yawinc_acum, pitchinc_acum, rollinc_acum;
  
  //-- Velocidad angular instantanea
  dReal wyaw, wpitch, wroll;
  
  //-- Angulos al comienzo del periodo
  dReal yawini, pitchini, rollini;
  
  //-------------------- ESTADO PARA CADA CICLO ---------------------------
  dReal period;  //-- Periodo del ultimo ciclo completado
  
  dReal zmax_ciclo;    //-- Altura (cm) maxixma alcanzada por el 
                       //-- modulo de referencia en el ciclo anterior
  
  //-- Posiciones x,y,z al comienzo del ciclo
  dReal xini, yini, zini;
  
  //-- Distancia media en un ciclo
  dReal xinc_ciclo, yinc_ciclo, zinc_ciclo;
  
  //-- Velocidades lineales medias por ciclo
  dReal vx_ciclo, vy_ciclo, vz_ciclo;
  
  //-- Distancia media angular en un ciclo
  dReal yawinc_ciclo, pitchinc_ciclo, rollinc_ciclo;
  
  //-- Velocidades angulares medias por ciclo
  dReal wyaw_ciclo, wpitch_ciclo, wroll_ciclo;
  
  //-- Flag para indicar si en el ciclo actual o anterior el robot ha
  //-- "volcado". Esto significa que ha habido un roll grande en algun
  //-- momento del ciclo.
  bool volcado;
  bool volcado_ciclo;
  
  
  //-------------------- ESTADO PARA CADA INTERVALO ----------------------
  int t_int; //-- Numero de ticks en el intervalo actual
  int intervalo_ticks;        //-- Duracion del intervalo en ticks
  dReal intervalo_duracion;   //-- Duracion del ultimo intervalo (en seg)
  dReal intervalo_tiempo_acum;//-- Contador acumulado en el intervalo actual
  int   intervalo_ciclos;     //-- Numero de ciclos del intervalo
  int   intervalo_numero;     //-- Numero del intervalo actual
  bool intervalo_transicion;  //-- Flag de transicion entre intervalos
  int contador_ciclos;        //-- Contador de ciclos
  int intervalo_ciclo_ini;    //-- Ciclo en el que se comienza el intervalo
  
  //-- Posiciones x,y,z al comenzar el intervalo
  dReal xini_int, yini_int, zini_int;
 
  //-- Distancia media de un intervalo
  dReal xinc_int, yinc_int, zinc_int;
  
  //-- Velocidad media en un intervalo;
  dReal vx_int, vy_int, vz_int;
  
  //-- Posiciones angulares al comenzar el intervalo
  dReal yawini_int, pitchini_int, rollini_int;
  
  //-- Distancia angular media en un intervalo
  dReal yawinc_int, pitchinc_int, rollinc_int;
  
  //-- Distancia angular acumulada en un intervalo
  dReal yawinc_acum_int, pitchinc_acum_int, rollinc_acum_int;
  
  //-- Velocidad angular media en un intervalo
  dReal wyaw_int, wpitch_int, wroll_int;

};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
int T1D_get_args(T1D_Robot *t1d_robot, int argc, char* argv[],bool verbose);
void T1D_new_robot(T1D_Robot *worm, bool cpgs, bool robot_real);
void T1D_step(T1D_Robot *worm);
void T1D_file_octave_data(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel);  //-- Etiqueta eje Y

void T1D_file_octave_data2(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel);  //-- Etiqueta eje Y
                          
void T1D_file_octave_data2(int ini,       //-- Indice inicial
                           int fin,       //-- Indice final
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel);   //-- Etiqueta eje Y                          

void T1D_file_octave_data3(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          dReal buf3[],   //-- Buffer de datos 3
                          char *name3,    //-- Nombre de los datos 3
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel);  //-- Etiqueta eje Y
                          
void T1D_file_octave_data(int ini,       //-- Indice inicial
                          int fin,       //-- Indice final
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel);   //-- Etiqueta eje Y
                          
                          
int T1D_get_fitness_type(char *fit, int *fit_type);
void T1D_print_fitness_type(int fitness_type);
dReal T1D_get_fitness(T1D_Robot *worm, int fitness_type);
int T1D_get_structure_type(char *structure, int *structure_type);
void T1D_print_structure_type(int estructura);
void T1D_set_structure(T1D_Robot *worm, int estructura);
int T1D_get_chromosome_type(char *chromo, int *chromo_type);
void T1D_print_chromosome(int chromo_type);


#endif  // _T1D_H
