/*---------------------------------------------------------------------------*/
/**  \file Rtk-Simulation-Engine.h
  *  \brief Definiciones, estructuras de datos y prototipos de 
  *         RTK_SIMULATION_ENGINE
  *
  *  Structuras de datos, definiciones y prototipos de RTK_SIMULATION_ENGINE  */
/*----------------------------------------------------------------------------*/

#ifndef _RTK_SIMULATION_ENGINE_H
#define _RTK_SIMULATION_ENGINE_H

#include <ode/ode.h>
#include "Rtk-Robot.h"

/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura para describir el motor de simulacion
    *
*/
struct RtkSimulationEngine {
  
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  
  //! -- Roboget a simular
  void *roboget;
  
  //!-- Tipo del roboget a simular
  int roboget_type;
  
  //!-- Estado del automata de reproduccion: TRANSITORIO, PERIODO1, OTRO
  int automata;
  
  //!-- Identificador para el mundo
  dWorldID world;
  
  //!-- Identificador del espacio (para colisiones)
  dSpaceID space;
  
  //!-- Identificador del grupo de articulaciones
  dJointGroupID contactgroup;
  
  //------------------ Parametros para ODE ----------------------------
  //-- El usuario los puede modificar
  //-------------------------------------------------------------------
  //!-- Gravedad en la simulacion
  dReal gravedad;
  
  //!-- Parametro CFM: Constrait Force Mixing. 
  // Establece cuanto de rigidas o blandas son las articulaciones
  dReal cfm;
  
  //!-- Parametro ERP: Error reducction parameter
  //-- Reducir el error acumulado en cada paso de simulacion
  dReal erp;
  
  //!-- Parametro MaxCorrectingVel
	dReal MaxCorrectingVel;
  
  //!-- Parametro SurfaceLayer
  dReal SurfaceLayer;
  
  //!-- Parametro mu: Coeficiente de rozamiento
  dReal mu;
  
  //!-- Paso de simulacion
  dReal step;
  
  
  //------------------ Parametros para el renderizado 3D -------------------
  //! Factor de escalado para la visualizacion
  dReal Factor_visualizacion;
  
  //------------------------------------------- Otros parametros
  //!-- Descriptor del puerto serie para el robot real
  int serial_fd;
  
};

/*-----------------------------*/
/* CONSTANTES                  */
/*-----------------------------*/
//-- Definiciones para el automata de reproduccion
//! Estado transitorio. Servo moviendose a posicion inicial
#define AUT_TRANSITORIO  0

//! Servo reproduciendo el primer periodo
#define AUT_PERIODO1     1 

//! Servo reproduciendo cualquier otro periodo
#define AUT_FIN_PERIODO1 2 


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/

void Rtk_Simulation_Engine_new(RtkSimulationEngine *sim);
void Rtk_Simulation_Engine_Add(RtkSimulationEngine *sim,
                               void *robot, int roboget_type);                               
void Rtk_Simulation_Engine_end(RtkSimulationEngine *sim);    
void Rtk_Simulation_Engine_step(RtkSimulationEngine *sim);
void Rtk_Simulation_Engine_print(RtkSimulationEngine *sim);
void Rtk_Simulation_Engine_reset(RtkSimulationEngine *sim);
void Rtk_Simulation_Engine_set_serialfd(RtkSimulationEngine *sim, int fd);



#endif  // _RTK_SIMULATION_ENGINE_H
