/*---------------------------------------------------------------------------*/
/**  \file Rtk-Robot-Group.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_ROBOT_GROUP
  *
  *  Structuras de datos, definiciones y prototipos de RTK_ROBOT_GROUP       */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_ROBOT_GROUP_H
#define _RTK_ROBOT_GROUP_H

#include <ode/ode.h>
  
  
#define MAX_ROBOTS 100  
  
/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

/** \brief Estructura para describir un Robot
    *
*/
struct RtkRobotGroup {
  /************************************/
  /* CAMPOS COMUNES A LOS ROBOGETS    */
  /************************************/
  //-- Indica el tipo de roboget
  int type;
  
  //-- Roboget padre
  void *Parent;
  
  //-- Tipo del roboget padre
  int Parent_type;
  
  //-- Enlace al simulador
  RtkSimulationEngine *sim;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  
  //! Robots dentro del grupo
  RtkRobot *roboget[MAX_ROBOTS];
  
  //!-- Numero de robots en el grupo
  int size;
  
};


/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_Robot_Group_new(RtkRobotGroup *group);
void Rtk_Robot_Group_add(RtkRobotGroup *group, RtkRobot *robot);
void Rtk_Robot_Group_create(RtkSimulationEngine *sim, RtkRobotGroup *group);
void Rtk_Robot_Group_simulate(RtkRobotGroup *group);
void Rtk_Robot_Group_print(RtkRobotGroup *group, int depth);
void Rtk_Robot_Group_reset(RtkRobotGroup *group);

#endif  // _RTK_ROBOT_H
