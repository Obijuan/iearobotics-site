/*---------------------------------------------------------------------------*/
/**  \file Rtk_Fitness.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK_FITNESS
  *
  *  Structuras de datos, definiciones y prototipos de RTK_FITNESS           */
/*---------------------------------------------------------------------------*/

#ifndef _RTK_FITNESS_H
#define _RTK_FITNESS_H

#include "Rtk.h"

/*-----------------------------*/
/* CONSTANTES                  */
/*-----------------------------*/
//-- Utilizado para acceder a las componentes X,Y,Z de los
//-- datos de tivpo dvector3.
//-- Ejemplo:  dvector3 pos;
//--   pos[X], pos[Y], pos[Z] son las componentes (x,y,z) del
//--   vector pos.
#define X 0
#define Y 1
#define Z 2

/*******************************************/
/* FUNCIONES DE INTERFAZ                   */
/*******************************************/
void Rtk_Fitness_distance(RtkRobot *r, int tics_simu, dVector3 desp);
void Rtk_Fitness_distance_get_value(dVector3 desp);
int Rtk_Fitness_distance_step(void);
void Rtk_Fitness_distance_init(RtkRobot *r, int tics_simu);


#endif  // _FITNESS_PP_H
