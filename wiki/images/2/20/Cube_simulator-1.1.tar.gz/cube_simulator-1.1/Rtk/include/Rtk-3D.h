/*----------------------------------------------------------------------*/
/**  \file Rtk-3D.h
  *  \brief Definiciones, estructuras de datos y prototipos de RTK-3D
  *
  *  Structuras de datos, definiciones y prototipos de RTK-3D           */
/*----------------------------------------------------------------------*/

#ifndef _RTK_3D_H
#define _RTK_3D_H

#include "drawstuff.h"
#include "Rtk.h"

/*************************************/
/* FUNCIONES DE INTERFAZ             */
/*************************************/
void Rtk_3D_Y1Module_render(RtkY1Module *mod);
void Rtk_3D_Robot_robot(RtkRobot *robot);
void Rtk_3D_Robot_Group_render(RtkRobotGroup *group);
void Rtk_3D_render(RtkSimulationEngine *sim);
void Rtk_3D_Simulation_Loop(int argc, char **argv, 
                            void (*step) (int pause),
                            void (*command) (int cmd));
void Rtk_3D_Simulation_Loop(int  argc, char **argv, RtkSimulationEngine *s);
void Rtk_3D_PP_render(RtkPP *pp);
void Rtk_3D_Chain_render(RtkChain *chain);






void Rtk_fitness_pp_3D_space(RtkSampledFunction *f1, RtkSampledFunction *f2,
                         int ticks_simu,
                         dVector3 desp);
                         
void Rtk_fitness_pp_3D_space(int argc, char **argv,
                         RtkSampledFunction *f1, RtkSampledFunction *f2,
                         int ticks_simu, dVector3 desp);

void Rtk_3D_Fitness_distance(int argc, char **argv, 
                             RtkRobot *robot, 
                             int tics_simu,
                             dVector3 desp);


#endif  // _RTK_3D_H
