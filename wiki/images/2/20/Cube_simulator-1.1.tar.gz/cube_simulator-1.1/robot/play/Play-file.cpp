/*---------------------------------------------------------------------------*/
/**  \file Play-file.cpp
  *  \brief Reproduction of .mvm files
  *
  *  The .mvm file is opened and sent to the real robot
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/

#include <unistd.h>
#include <string.h>
#include "sg-serial.h"
#include "sg-tramas.h"
#include "T1D.h"
#include "consola_io.h"
#include "sg-tramas-servos8.h"

#define ABS(a)	   (((a) < 0) ? -(a) : (a))

#define NORMAL 0
#define PASO   1
#define PAUSA  2
#define STEP   3

#define DIR_ADELANTE 1
#define DIR_ATRAS    2


/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

//-- Vector de posicion actual
static int v_ini[RTK_MAX_MOD];

//-- Vector de posicion
static int v[RTK_MAX_MOD];

//-- Constante de tiempo en useg
unsigned long ct=3800;

//-- Cadena con el dispositivo serie
static char disp_serie[255];

//-- Matriz de conexionado
//-- Indica hacia que servo fisico se envia la funcion indicada por el 
//-- indice. Ejemplo:
//-- conexion[1] contiene el numero de servo al que enviar la funcion 1
static int conexion[]={0,1,2,3,4,5,6,7,8};


/************************/
/* Mostrar la ayuda     */
/************************/
static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Play-file Fichero.mvm  Dispositivo-Serie [S1] [S2] ...\n");
  printf ("donde,\n");
  printf ("  -Fichero.mvm es un fichero de movimiento en formato .mvm\n");
  printf ("  -Dispositivo-Serie: Nombre del puerto serie usado\n");
  printf ("  -Sx: Numero de servo asociado a la funcion 1, 2, 3...\n");
  printf ("Ejemplo:\n");
  printf ("  Play test.mvm /dev/ttyUSB0\n");
  printf ("  Play PPP.mvm /dev/ttyS0 S5 S7 S3\n");
}




/********************************/
/* Obtener la posicion inicial  */
/********************************/
int gen_get_ini_pos(RtkGenerator *gen)
{
  int pos;
  
  pos = (int) round(gen->f[0]);
  return pos;
}

/*************************************/
/* Obtener la posicion anterior      */
/*************************************/
int gen_get_pos_ant(RtkGenerator *gen)
{
  int pos;
   
  //-- Limpiar flag de transicion
  gen->period_transition=0;
  
  //-- Actualizar el indice de muestras
  if (gen->n==0) gen->n=gen->N-1;
  else gen->n = gen->n-1 ;
  
  //-- Si el indice llega al comienzo, se incrementa el contador de periodos
  if (gen->n==gen->N-1) {
          
    //-- Actualizar contador de periodos
    gen->period_counter++;
    gen->period_transition=1;
  }
              
  //-- Establecer la nueva posicion de referencia
  pos = (int) round(gen->f[gen->n]);
  return pos;
}

/*************************************/
/* Obtener la siguiente posicion     */
/*************************************/
int gen_get_pos(RtkGenerator *gen)
{
  int pos;
  
  //-- Limpiar flag de transicion
  gen->period_transition=0;
  
  //-- Actualizar el indice de muestras
  gen->n=(gen->n+1) % gen->N;
  
  //-- Si el indice llega al comienzo, se incrementa el contador de periodos
  if (gen->n==0) {
          
    //-- Actualizar contador de periodos
    gen->period_counter++;
    gen->period_transition=1;
  }
              
  //-- Establecer la nueva posicion de referencia
  pos = (int) round(gen->f[gen->n]);
  return pos;
}

/***********************************/
/* Leer vector de posicion inicial */
/***********************************/
void sec_get_vector_ini(T1D_Robot *worm, int *vec)
{
  for (int i=0; i<worm->nm; i++) {
    vec[i]=gen_get_ini_pos(&(worm->gen[i]));
  }
}

/*************************************/
/* Leer vector de posicion siguiente */
/*************************************/
void sec_get_vector(T1D_Robot *worm, int *vec, int dir)
{
  for (int i=0; i<worm->nm; i++) {
    if (dir==DIR_ADELANTE) 
      vec[i]=gen_get_pos(&(worm->gen[i]));
    else
      vec[i]=gen_get_pos_ant(&(worm->gen[i]));
  }
}

/***************************************/
/* Imprimir un vector de estado        */
/***************************************/
void vector_print(T1D_Robot *worm, int *vec)
{
  printf ("[");
  for (int i=0; i<worm->nm; i++) {
    printf ("%d, ",vec[i]);
  }
  printf ("];\n");
    
}

/***********************************************************/
/* Devolver la distancia entre dos vectores de posicion    */
/***********************************************************/
int vector_distancia(T1D_Robot *worm, int *v1, int *v2)
{
  int v_resta[RTK_MAX_MOD];
  int max;

  
  //-- Calcular el vector resta: v2 - v1
  for (int i=0; i<worm->nm; i++) {
    v_resta[i]= ABS(v2[i]-v1[i]);
  }
  
  max = 0;
  
  //-- Obtener el valor maximo
  for (int i=0; i<worm->nm; i++) {
    if (v_resta[i]>max) max=v_resta[i];
  }
  
  return max;
}

/*******************************************/
/* Asignar un vector a otro                */
/*******************************************/
void vector_asignar(T1D_Robot *worm, int *v_dest, int *v_fuente)
{
  for (int i=0; i<worm->nm; i++) {
    v_dest[i]= v_fuente[i];
  }
}

/******************************************/
/* Calcular el tiempo de transito         */
/******************************************/
unsigned long vector_tiempo_trans(T1D_Robot *worm, int *v1, int *v2, 
                                  unsigned long ct)
{
  unsigned long tt;
  int d;
  
  /* Calcular la distancia entre v1 y v2*/
  d = vector_distancia(worm,v1,v2);

  /* Calcular tiempo de transito */  
  tt = (unsigned long) (d*ct);
  
  /* Devolver el tiempo de transito */
  return tt;
}

/*************************************************************/
/* Posicionar el robot fisico                                */
/* Para el posicionamiento se utiliza la matriz de conexion  */
/*************************************************************/
void vector_posicionar(T1D_Robot *worm, int *v)
{
  for (int i=0; i<worm->nm; i++) {
    sg_servos8_pos1_grados(conexion[i+1], -v[i]);
  }
}

int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}



int inicio()
{
  int status;
  int intentos=0;

  do {
    printf ("  Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) {
    printf ("  Conexion establecida\n");
		sg_servos8_enable(0xFF);
		return 1;
  }
  else printf ("  Conexion NO establecida\n");
  printf ("\n");
  return 0;
}


/***********************************************************/
/* Obtener el numero de servo. Si hay error se devuelve 0  */
/***********************************************************/
int procesar_numero_servo(char *param)
{
  //-- El servo empieza por 's' o 'S'. Sino el argumento es incorrecto
  if (param[0]!='s' && param[0]!='S') return 0;
    
  return atoi(&param[1]);
}

/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static int analizar_parametros(T1D_Robot *worm,int argc, char* argv[])
{
  int servo=0;
  int f=0;
 
  //-- Si argumentos incorrectos
  if (argc<3) {
    help();
    return 0;
  }
    
  int m=0;
  int ok;
  
  //-- Leer todas las funciones
  do {
    ok = Rtk_Sampled_Function_new_from_mvm_file(&(worm->sf[m]), argv[1],m+1);
       
    //printf ("Modulo: %d, ok: %d\n",m,ok);
    if (ok==1) m++;
  } while (ok==1);
    
  //-- Almacenar numero de modulos
  worm->nm=m;
  
  //-- Leer el puerto serie
  if (argc>=3) {
    strcpy(disp_serie, argv[2]);
  }
  
  //-- Leer matriz de conexionado (parametro opcional)
  printf ("\n");
  printf ("Conexion con ROBOT REAL:\n");
  for (int i=3; i<=argc-1; i++) {
    //servo=atoi(argv[i]);
    servo=procesar_numero_servo(argv[i]);
    
    if (servo==0) {
      printf ("  Error en el numero de servo: %s\n",argv[i]);
      help();
      exit(1);
    }
    
    f=i-2;
    conexion[f]=servo;
    conexion[servo]=f;
    printf ("  Funcion %d --> Servo %d\n",f,servo);
  }  
   
  return 1;
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  unsigned long pausa;
  char c;
  char cant=0;
  int serial_fd;  //-- Descriptor del puerto serie
  int modo=NORMAL;
  int dir=DIR_ADELANTE;
  
  
  //-- Analizar parametros y terminar si hay algun error
  ok=analizar_parametros(&worm,argc,argv);
  if (!ok) return 0;
  
  printf ("\n");
  printf ("Fichero: %s\n",argv[1]);  
  printf ("Numero de modulos: %d\n",worm.nm);
  printf ("Dispositivo serie: %s\n",disp_serie);
  
  //-- Debug: imprimir todas las funciones
  /*for (int i=0; i<worm.nm; i++) 
    Rtk_Sampled_Function_print(&(worm.sf[i]));
  */
  
  //------------------- INICIALIZAR --------------
  //-- Crear los generadores y asignar las funciones
  for (int i=0; i<worm.nm; i++) {
    Rtk_Generator_new(&(worm.gen[i]));
    Rtk_Generator_set_func(&(worm.gen[i]),&(worm.sf[i]));
  }
  
  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp_serie);
  if (serial_fd==-1) {
    perror ("  Puerto serie");
    return 1;    
  }

  //-- Inicializar el módulo sg-tramas
  sg_tramas_init(serial_fd);
	sg_servos8_init(serial_fd);
  
  inicio();
  
  printf ("----------------------------------------\n");
  printf ("Teclas: \n");
  printf ("  p: Pausa\n");
  printf ("  d: Cambio de direccion\n");
  printf ("  t: Ejecutar solo un periodo\n");
  printf ("  ESC: Terminar\n");
  printf ("----------------------------------------\n");
  
  //-- Leer vector con posicion inicial
  sec_get_vector_ini(&worm,v_ini);
  vector_print(&worm,v_ini);
	vector_posicionar(&worm,v_ini);
  usleep(342000);
  
  //-- Configurar la consola
  abrir_consola();
  
  //----------------------------- Bucle principal ---------------------
  do {
    /* Leer el vector de posicion */
    sec_get_vector(&worm,v,dir);
    vector_print(&worm,v);
    
    /* Calcular tiempo de transito en ms*/
    pausa = vector_tiempo_trans(&worm,v_ini,v,ct);
    
    //printf ("  Pausa: %ld\n",pausa);
        
    /* Mover las articulaciones */
    vector_posicionar(&worm,v);
    usleep(pausa);
    
    if (pausa==0) usleep(10000);
      
    // vini=v;
    vector_asignar(&worm,v_ini,v);
    
    switch(modo) {
      case PASO:  //-- Modo paso
        if (worm.gen[0].period_transition) {
          printf ("PASO!!\n");
          cant=getch();
          modo=NORMAL;
        }
        break;
        
      case PAUSA:  //-- Modo pausa
        cant=getch();
        modo=NORMAL;
        break;        
    }
    
    if (kbhit() || cant!=0) {
				if  (kbhit()) c=getch();
        else c=cant;
				if (c==27) break;
				switch(c) {
					case 'p': 
						modo=PAUSA;
					  break;
          case 't':
            modo=PASO;
            break;
          case 'd':
            if (dir==DIR_ADELANTE)
              dir=DIR_ATRAS;
            else
              dir=DIR_ADELANTE;
				}
      cant=0;         
		}
    
  } while (c!=27);
  
  //-- Consola a su estado inicial
  cerrar_consola();
  
  //-- Cerrar puerto serie
  close(serial_fd);
}
