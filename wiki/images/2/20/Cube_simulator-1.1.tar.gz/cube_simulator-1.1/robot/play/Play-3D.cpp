/*---------------------------------------------------------------------------*/
/**  \file Play-3D.cpp
  *  \brief Reproduction of sinusoidal sequences
  *
  *  The sequence is generated and sent to the real robot. It is also shown
  *  in the virtual robot
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/

#include <unistd.h>
#include <string.h>

#include "Rtk-3D.h"
#include "sg-serial.h"
#include "sg-tramas.h"
#include "T1D.h"
#include "sg-tramas-servos8.h"

/****************************/
/* VARIABLES                */
/****************************/

//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

//-- Cadena con el dispositivo serie
static char disp_serie[255];

//-- Matriz de conexionado
//-- Indica hacia que servo fisico se envia la funcion indicada por el 
//-- indice. Ejemplo:
//-- conexion[1] contiene el numero de servo al que enviar la funcion 1
static int conexion[]={0,1,2,3,4,5,6,7,8};

/**************************************************/
/* FUNCION DE RETROLLAMADA.                       */
/* Se invoca cuando se pulsa una tecla            */
/**************************************************/
static void command (int cmd)
{
	
	if (cmd=='1') {
    
  }
  else if (cmd=='2') {
    printf ("TIEMPO DE CICLO: %d\n",worm.t);
  }
  else if (cmd=='q') {
    dsStop();
  }
}


/***************************************************/
/* Simulacion de un paso                           */
/* Esta funcion se invoca cada vez que hay que     */
/* realizar un paso de simulacion                  */
/***************************************************/
static void simLoop (int pause)
{
  
	if (!pause) {
    
    //-- Realizar un paso de simulacion
    T1D_step(&worm);
    
    //-- Comprobar timeout
    if (worm.timeout)
      printf ("Timeout!!\n");    
    
    //-- Se ejecuta al comienzo de cada nuevo periodo
    if (worm.period_transition) {
      printf ("\n");
      printf ("---------- FIN CICLO %d ------------\n",worm.period_counter-1);
    }  
     
  }
	
  //-- Renderizar
  Rtk_3D_render(&(worm.sim));
  
  //-- Pequena pausa para no cargar tanto la CPU
  //-- Si la simulacion va lenta se puede eliminar
  //usleep(int (sim.step*1000000));	
  usleep(10);
}




/************************/
/* Mostrar la ayuda     */
/************************/
static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  Play-3D Dispositivo-Serie [S1] [S2]... [A T F O,...] [P|Y|X, ...]\n");
  printf ("donde,\n");
  printf ("  -Dispositivo-Serie: Nombre del puerto serie usado\n");
  printf ("  -Sx: Numero de servo asociado a la funcion 1, 2, 3...\n");
  printf ("  -El resto de parametros son los valores de los generadores y la \n");
  printf ("   estructura de la configuracion. Se pueden usar los programas \n");
  printf ("   Pn y PYn para simplificar\n");
  printf ("Ejemplo:\n");
  printf ("  Play-3D  /dev/ttyUSB0 `./Pn 2 40 100 120 0`\n");
  printf ("  Play /dev/ttyS0 S5 S7 S3  `./PYn 3 10 45 45 0 0 0 0 90` \n");
}

/*************************************************************/
/* Posicionar el robot fisico                                */
/* Para el posicionamiento se utiliza la matriz de conexion  */
/*************************************************************/
void vector_posicionar(T1D_Robot *worm, int *v)
{
  for (int i=0; i<worm->nm; i++) {
    sg_servos8_pos1_grados(conexion[i+1], -v[i]);
  }
}

int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}



int inicio()
{
  int status;
  int intentos=0;

  do {
    printf ("  Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) {
    printf ("  Conexion establecida\n");
		sg_servos8_enable(0xFF);
		return 1;
  }
  else printf ("  Conexion NO establecida\n");
  printf ("\n");
  return 0;
}


/***********************************************************/
/* Obtener el numero de servo. Si hay error se devuelve 0  */
/***********************************************************/
int procesar_numero_servo(char *param)
{
  //-- El servo empieza por 's' o 'S'. Sino el argumento es incorrecto
  if (param[0]!='s' && param[0]!='S') return 0;
    
  return atoi(&param[1]);
}

/****************************************************/
/* Analizar los parametros de la linea de comandos  */
/****************************************************/
static int analizar_parametros(T1D_Robot *worm,int argc, char* argv[])
{
  int servo=0;
  int f=0;
 
  //-- Si argumentos incorrectos
  if (argc<3) {
    help();
    return 0;
  }
    
  int ok;
  
  //-- Leer el puerto serie
  strcpy(disp_serie, argv[1]);
  
  //-- Leer matriz de conexionado (parametro opcional)
  //-- Por defecto se deja la identidad:
  for (int i=0; i<=8; i++)
    worm->conexion[i]=i;
  
  
  int i=2;
  do {
    
    servo=procesar_numero_servo(argv[i]); 
    if (servo!=0) {
      f=i-1;
      printf ("  Funcion %d --> Servo %d\n",f,servo);
      worm->conexion[f]=servo;
      ///worm->conexion[servo]=f;
      i++;
    }
    
    if (i>=argc) {
      printf ("FALTAN ARGUMENTOS\n");
      help();
      exit(1);
    }
    
     //printf ("argc: %d, i: %d\n",argc,i);
  } while (servo!=0);
   
  //-- Analizar parametros pasados por el usuario
  ok=T1D_get_args(worm,argc-(i-1),&argv[i-1],true);
  
  if (!ok) {
    help();
    exit(1);
  }
   
  return 1;
}


/*******************/
/*     MAIN        */
/*******************/
int main (int argc, char **argv)
{
  int ok;
  int serial_fd;  //-- Descriptor del puerto serie
  
  //-- Analizar parametros y terminar si hay algun error
  ok=analizar_parametros(&worm,argc,argv);
  if (!ok) return 0;
    
  //-- CONSTRUIR CONFIGURACION y simulacion
  //-- Inicializar variables internas de la simulacion  
  T1D_new_robot(&worm,true,true);
  
  worm.intervalo_ciclo_ini=1;
  worm.intervalo_ciclos=2;
  
  printf ("\n");
  printf ("Fichero: %s\n",argv[1]);  
  printf ("Numero de modulos: %d\n",worm.nm);
  printf ("Dispositivo serie: %s\n",disp_serie);
  
  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp_serie);
  if (serial_fd==-1) {
    perror ("  Puerto serie");
    return 1;    
  }

  //-- Inicializar el módulo sg-tramas
  sg_tramas_init(serial_fd);
	sg_servos8_init(serial_fd);
  
  //-- Anadir el puerto serie a la simulacion
  Rtk_Simulation_Engine_set_serialfd(&(worm.sim),serial_fd);
  
  inicio();
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  Rtk_3D_Simulation_Loop(argc,argv, &simLoop, &command);
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
  
  
  //-- Cerrar puerto serie
  close(serial_fd);
}
