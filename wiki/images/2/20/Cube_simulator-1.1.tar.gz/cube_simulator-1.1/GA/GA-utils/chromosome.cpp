/*---------------------------------------------------------------------------*/
/**  \file chromosome.cpp
  *  \brief Functions for working with chromosomes
  *
  *  Module for working with chromosomes
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "T1D.h"
#include "chromosome.h"



/*---------------------------------------------------------------------------*/
/*                      T_Av_Ah_DFv_DFh_DFvh                                 */
/*---------------------------------------------------------------------------*/

/******************************************************/
/* Crear un cromosoma del tipo T_Av_Ah_DFv_DFh_DFvh   */
/******************************************************/
static void chromosome_new_T_Av_Ah_DFv_DFh_DFvh(Chromosome *chromo, int nm)
{
  //--          0    1   2    3     4     5
  //--          T,  Av, Ah,  DFv,   DFh, DFvh
  int upper[6]={255, 90,90,   180,  180, 180};
  int lower[6]={2,   0, 0,   -180, -180, -180};
 
  
  //-- El tamano es fijo (no depende del numero de modulos)
  chromo->size=6;
  
  //-- Crear limite superior
  memcpy(chromo->data_upper, upper, 6*sizeof(int));
  
  //-- Crear limite inferior
  memcpy(chromo->data_lower, lower, 6*sizeof(int));
  
  //-- Almacenar el numero de modulos
  chromo->nm=nm;
}

/*************************************/
/* Imprimir el cromosoma             */
/*************************************/
static void chromosome_print_T_Av_Ah_DFv_DFh_DFvh(FILE *fd, Chromosome *chromo)
{
  fprintf (fd,"`./PYn %d ",chromo->nm);
  
   for (int i=0; i<3; i++)
    fprintf (fd,"%d ",chromo->data[i]);
   
   fprintf (fd,"0 0 ");
   
   for (int i=3; i<chromo->size; i++)
    fprintf (fd,"%d ",chromo->data[i]);
  
   fprintf (fd,"`");
   
}

/***************************************/
/* Convertir el cromosoma en genotipo  */
/***************************************/
void chromosome_fenotipo_get_T_Av_Ah_DFv_DFh_DFvh(Chromosome *chromo,
                                                 T1D_Robot *worm)
{
  //-- Codificacion Cromosoma: 
  //-- 0    1   2    3     4     5
  //-- T,  Av, Ah,  DFv,   DFh, DFvh
  
  //-- Hay un generador asociado a cada modulo
  //-- Recorrer todos los modulos  
  for (int i=0; i<worm->nm; i++) {
    
    //-- Leer periodo. Mismo para modulos pitch y yaw
    worm->cpg_T[i]=chromo->data[0];
    
    //-- El offset esta a 0
    worm->cpg_O[i]=0;
    
    //-- Los modulos pares son los pitch
    if (i%2==0) {
      
      //-- Establecer la amplitud
      worm->cpg_A[i]=chromo->data[1];
      
      //-- Establecer la fase
      worm->cpg_F[i]=i*chromo->data[3]/2;
    }
    else { //-- Los impares son los yaw
      
      //-- Establecer amplitud
      worm->cpg_A[i]=chromo->data[2];
      
      //-- Leer fase
      worm->cpg_F[i]=chromo->data[5] + (i-1)*chromo->data[4]/2;
      
    }
    
    //-- Calcular las funciones del generdor i
    Rtk_Sampled_Function_new_from_sine_func(&(worm->sf[i]),
                                           worm->cpg_A[i],   // A
                                           worm->cpg_F[i],   // Fase
                                           worm->cpg_O[i],   // Offset
                                           worm->cpg_T[i]);  // Period
  }
  
}


/*---------------------------------------------------------------------------*/
/*                      T_DF_A                                               */
/*---------------------------------------------------------------------------*/

/**************************/
/* Crear un cromosoma     */
/**************************/
static void chromosome_new_T_DF_A(Chromosome *chromo, int nm)
{
  //--          0    1   2   
  //--          T,   DF, A 
  int upper[]={255, 180, 90};
  int lower[]={2,   -180, 0};
 
  
  //-- El tamano es fijo (no depende del numero de modulos)
  chromo->size=3;
  
  //-- Crear limite superior
  memcpy(chromo->data_upper, upper, 3*sizeof(int));
  
  //-- Crear limite inferior
  memcpy(chromo->data_lower, lower, 3*sizeof(int));
  
  //-- Almacenar el numero de modulos
  chromo->nm=nm;
}

/*************************************/
/* Imprimir el cromosoma             */
/*************************************/
static void chromosome_print_T_DF_A(FILE *fd, Chromosome *chromo)
{
  
  //--   0    1   2   
  //--   T,   DF, A 
  fprintf (fd,"`./Pn %d ",chromo->nm);
  
  fprintf (fd,"%d %d %d 0`",chromo->data[2], chromo->data[0], chromo->data[1]);
   
}

/***************************************/
/* Convertir el cromosoma en genotipo  */
/***************************************/
static void chromosome_fenotipo_get_T_DF_A(Chromosome *chromo, T1D_Robot *worm)
{
  //-- Codificacion Cromosoma: 
  //--   0    1   2   
  //--   T,   DF, A 
  
  //-- Hay un generador asociado a cada modulo
  //-- Recorrer todos los modulos  
  for (int i=0; i<worm->nm; i++) {
    
    //-- Leer periodo
    worm->cpg_T[i]=chromo->data[0];
    
    //-- Leer la fase
    worm->cpg_F[i]=i*chromo->data[1];
    
    //-- Leer amplitud
    worm->cpg_A[i]=chromo->data[2];
    
    //-- El offset esta a 0
    worm->cpg_O[i]=0;
    
    //-- Calcular las funciones del generdor i
    Rtk_Sampled_Function_new_from_sine_func(&(worm->sf[i]),
                                           worm->cpg_A[i],   // A
                                           worm->cpg_F[i],   // Fase
                                           worm->cpg_O[i],   // Offset
                                           worm->cpg_T[i]);  // Period
  }
  
}

/*---------------------------------------------------------------------------*/
/*                      RAW                                                  */
/*---------------------------------------------------------------------------*/

/**************************/
/* Crear un cromosoma     */
/**************************/
static void chromosome_new_RAW(Chromosome *chromo, int nm, int nsamples)
{
  //-- La codificacion es:
  //--  f1_1 f1_2 f1_3 ... f1_N , f2_1, f2_2, f2_3 ... f2_N, ...
  //-- Se utilizan directamente las muestras de las senales para hacer el 
  //-- cromosoma.  
  
  //-- El tamano es nsamples * nm
  chromo->size=nsamples * nm;
  
  //-- Crear limite superior e inferior
  for (int i=0; i<chromo->size; i++) {
    chromo->data_upper[i]=90;
    chromo->data_lower[i]=-90;
  }
  
  //-- Almacenar el numero de modulos
  chromo->nm=nm;
  
  //-- Almacenar numero de muestras
  chromo->nsamples=nsamples;
}

/**********************************/
/* Imprmir el cromosoma           */
/**********************************/
static void chromosome_print_RAW(FILE *fd, Chromosome *chromo)
{
  for (int nm=0; nm<chromo->nm; nm++) {
    for (int i=0; i<chromo->nsamples; i++) {
      fprintf (fd,"%d ",chromo->data[chromo->nsamples*nm + i]);
    }
    if (nm<chromo->nm-1)
     fprintf (fd,"\n");
  }
   
}

/***************************************/
/* Convertir el cromosoma en genotipo  */
/***************************************/
static void chromosome_fenotipo_get_RAW(Chromosome *chromo, T1D_Robot *worm)
{
  for (int nm=0; nm<chromo->nm; nm++) {
    for (int i=0; i<chromo->nsamples; i++) {
      worm->sf[nm].f[i]=chromo->data[chromo->nsamples*nm + i]; 
    }
    worm->sf[nm].N=chromo->nsamples;
  }
  
}

/*---------------------------------------------------------------------------*/
/*                      Ti_Ai_Oi_Fi                                          */
/*---------------------------------------------------------------------------*/

/**************************/
/* Crear un cromosoma     */
/**************************/
static void chromosome_new_Ti_Ai_Oi_Fi(Chromosome *chromo, int nm)
{
  
  //--  T1 T2 ... A1 A2... O1 O2 ... Fi F2 ...
 
  //-- El tamano es variable: depende del numero de modulos
  chromo->size=nm*4;
  
  //-- Almacenar el numero de modulos
  chromo->nm=nm;
  
  //-- Crear limite superior e inferior
  for (int i=0; i<chromo->size; i++) {
    
    if (i<chromo->nm) {  //-- T
      chromo->data_upper[i]=255;
      chromo->data_lower[i]=2;
    }
    else if (i<chromo->nm*2) {  //-- A
      chromo->data_upper[i]=90; 
      chromo->data_lower[i]=0;
    }
    else if (i<chromo->nm*3) {
      chromo->data_upper[i]=90;   //-- O
      chromo->data_lower[i]=-90;
    }
    else if (i<chromo->nm*4) {
      chromo->data_upper[i]=180;  //-- F
      chromo->data_lower[i]=-180;
    }  
  }
  
}

/**********************/
/* Imprimir cromosoma */
/**********************/
static void chromosome_print_Ti_Ai_Oi_Fi(FILE *fd, Chromosome *chromo)
{
  
  for (int i=0; i<chromo->size; i++) {
    fprintf (fd,"%d ",chromo->data[i]);
  }
   
}

/***************************************/
/* Convertir el cromosoma en genotipo  */
/***************************************/
static void chromosome_fenotipo_get_Ti_Ai_Oi_Fi(Chromosome *chromo,
                                                T1D_Robot *worm)
{
 
  //-- Codificacion Cromosoma: 
  //--  T1 T2 ... A1 A2... O1 O2 ... Fi F2 ... 
  for (int m=0; m<worm->nm; m++) {
    
    //-- Leer periodo
    worm->cpg_T[m]=chromo->data[chromo->nm*0 + m];
    
     //-- Leer amplitud
    worm->cpg_A[m]=chromo->data[chromo->nm*1 + m];
    
    //-- Leer offset
    worm->cpg_O[m]=chromo->data[chromo->nm*2 + m];
    
    //-- Se debe cumplir que cuando el offset es positivo,
    //-- offset + amplitud <= 90
    if (abs(worm->cpg_O[m])+worm->cpg_A[m]>90) {
      if (worm->cpg_O[m]>0) worm->cpg_O[m]=90-worm->cpg_A[m];
      else worm->cpg_O[m]=-90 + worm->cpg_A[m];
    }
 
    //-- Leer la fase
    worm->cpg_F[m]=chromo->data[chromo->nm*3 + m];
    
    //-- Calcular las funciones del generdor i
    Rtk_Sampled_Function_new_from_sine_func(&(worm->sf[m]),
                                           worm->cpg_A[m],   // A
                                           worm->cpg_F[m],   // Fase
                                           worm->cpg_O[m],   // Offset
                                           worm->cpg_T[m]);  // Period
  }
}



/*---------------------------------------------------------------------------*/
/*   F U N C I O N E S     G E N E R A L E S               (M U X)           */
/*---------------------------------------------------------------------------*/


/*************************************************************************/
/* Crear un cromosoma nuevo a partir de su tipo y del numero de modulos  */
/*************************************************************************/
void chromosome_new(Chromosome *chromo, int chromo_type, int nm, int data)
{
  
  //-- Almacenar el tipo de cromosoma
  chromo->type=chromo_type;
  
  //-- Segun el tipo que sea, llamar a la funcion correspondiente (MUX)
  switch(chromo_type) {
    
    case T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh:
      chromosome_new_T_Av_Ah_DFv_DFh_DFvh(chromo, nm);
      break;
    
    case T1D_CHROMO_T_DF_A:
      chromosome_new_T_DF_A(chromo,nm);
      break;
    
    case T1D_CHROMO_RAW:
      chromosome_new_RAW(chromo,nm, data);
      break;
    
    case T1D_CHROMO_Ti_Ai_Oi_Fi:
      chromosome_new_Ti_Ai_Oi_Fi(chromo,nm);
      break;
    
    default:
      printf (" *********************************************\n");
      printf ("  WARNING!!!!! Tipo de cromosoma incorrecto!!!\n");
      printf (" *********************************************\n");
  }
}



/**************************************************************************/
/* Leer el chromosoma                                                     */
/**************************************************************************/
void chromosome_get(Chromosome *chromo,PGAContext *ctx, int p, int pop)
{
  //-- Copiar el chromosoma al campo data
  for (int i=0; i<chromo->size; i++)
    chromo->data[i]=PGAGetIntegerAllele(ctx, p, pop, i);
  
}

/************************************************/
/* Imprimir el cromosoma                        */
/************************************************/
void chromosome_print(FILE *fd, Chromosome *chromo)
{
  //-- Segun el tipo que sea, llamar a la funcion correspondiente (MUX)
  switch(chromo->type) {
    
    case T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh:
      chromosome_print_T_Av_Ah_DFv_DFh_DFvh(fd,chromo);
      break;
    
    case T1D_CHROMO_T_DF_A:
      chromosome_print_T_DF_A(fd,chromo);
      break;
    
    case T1D_CHROMO_RAW:
      chromosome_print_RAW(fd,chromo);
      break;
    
    case T1D_CHROMO_Ti_Ai_Oi_Fi:
      chromosome_print_Ti_Ai_Oi_Fi(fd,chromo);
      break;
    
    default:
      printf (" *********************************************\n");
      printf ("  WARNING!!!!! Tipo de cromosoma incorrecto!!!\n");
      printf (" *********************************************\n");
  }
}

/*************************************************************/
/* Obtener el fenotipo a partir del cromosoma                */
/*************************************************************/
void chromosome_fenotipo_get(Chromosome *chromo,T1D_Robot *worm)
{
   //-- Segun el tipo que sea, llamar a la funcion correspondiente (MUX)
  switch(chromo->type) {
    
    case T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh:
      chromosome_fenotipo_get_T_Av_Ah_DFv_DFh_DFvh(chromo,worm);
      break;
    
    case T1D_CHROMO_T_DF_A:
      chromosome_fenotipo_get_T_DF_A(chromo,worm);
      break;
    
    case T1D_CHROMO_RAW:
      chromosome_fenotipo_get_RAW(chromo,worm);
      break;
    
    case T1D_CHROMO_Ti_Ai_Oi_Fi:
      chromosome_fenotipo_get_Ti_Ai_Oi_Fi(chromo,worm);
      break;
    
    default:
      printf (" *********************************************\n");
      printf ("  WARNING!!!!! Tipo de cromosoma incorrecto!!!\n");
      printf (" *********************************************\n");
  }
  
}
