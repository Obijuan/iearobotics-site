/*---------------------------------------------------------------------------*/
/**  \file GA.cpp
  *  \brief Genetics algorithms for the PYn and Pn configurations
  *
  *  Using GA for searching different spaces. The space is specified by the
  *  user.
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date March 2007
*/
/*---------------------------------------------------------------------------*/
#include <unistd.h>
#include <stdio.h>
#include <ode/ode.h>
//#include <pgapack.h>
#include "T1D.h"
#include "chromosome.h"
#include "Rtk-3D.h"

/******************************/
/* CONSTANTES                 */
/******************************/

//-- CAMBIAR ESTE VALOR PARA ELIMINAR LOS INDIVIDUOS QUE VUELQUEN
//-- VOLCADO=0: deshabilitado. 1=habilitada comprobacion volcado
#define VOLCADO 0
static int volcado_check=VOLCADO;


//-- Numero maximo de modulos permitidos
#define MAX_MOD 20

//-- Numero maximo de modulos para considerar que ha habido un timeout
#define TICKS_TIMEOUT 1700

//-- Tamano de la poblacion por defecto
#define TAMANO_POBLACION 100

//-- Numero de iteraciones por defecto
#define NUM_ITERACIONES  100




/**************************/
/* ESTRUCTURAS            */
/**************************/

//-- Estructura de un CPG sinusoidal
struct SCPG {
  int amplitud;  //-- Amplitud. Entre 0 y 90 grados
  int periodo;   //-- Periodo. Entre 0 y 255 ticks
  int fase;      //-- Fase. Entre -180 y 180
  int offset;    //-- Offset. Entre -90 y 90
};

/****************************/
/* VARIABLES                */
/****************************/
//-- Configuracion del robot y la simulacion
static T1D_Robot worm;

//static int num_mod;     //-- Numero de modulos de la configuracion

//-- Tamano de la poblacion
static int tam_pob=TAMANO_POBLACION;

//-- Numero de iteraciones
static int num_itera=NUM_ITERACIONES;

//-- Numero de ciclos del intervalo donde realizar la medicion
static int ciclos;

//-- Ciclo inicial
static int ciclos_ini;

//-- Almacenar el fitness de todas las generaciones
static double fitness[5000];

//-- Tipo de funcion de fitness a usar
static int fitness_type;

//-- Almacenar los parametros leidos
int param_estructura;  //-- Tipo de estructura PYn o Pn

//-- Tipo de chromosoma
int chromo_type;

//-- Numero de muestras (para cromosomas de tipo RAW)
int samples=2;

//-- Cromosoma;
Chromosome chromo;


//-- Nombre del fichero para guardar los individuos
char fich2[200];
FILE *fd2;


/*---------------------------------------------------------------*/
/*  FUNCIONES DE APOYO                                           */
/*---------------------------------------------------------------*/

/**********************************************/
/* Imprimir un fenotipo junto con su fitness  */
/**********************************************/
static void Fenotipo_print(FILE *fd,PGAContext *ctx, int p, int pop)
{ 
  //-- Obtener el chromosoma
  chromosome_get(&chromo,ctx,p,pop);
  
  fprintf (fd,"%d: Fitness: %.2f ",p,PGAGetFitness(ctx,p,pop));
  fprintf (fd,"\n");
  fprintf (fd,"   ");
  
  //-- Imprimir cromosoma
  chromosome_print(fd,&chromo);

  fprintf (fd,"\n");
}

/******************************************/
/* Generar el fichero .mvm                */
/******************************************/
static void generar_fichero_mvm(char *filename)
{
  FILE *fd;

  
  //-- Por hacer: control de errores...
  fd = fopen(filename,"w");
 
  //-- Crear fichero
  for (int i=0; i<worm.nm; i++) {
    Rtk_Sampled_Function_output_mrs(fd, &(worm.sf[i]));
  } 
  
  fclose(fd);
}

/****************************************************/
/* Imprimir todos los individuos de una generacion  */
/****************************************************/
static void Generation_print_all(FILE *fd,PGAContext *ctx, int pop,int gen)
{
  int tam;
  tam = PGAGetPopSize(ctx);
  
  fprintf (fd,"%d-----------------------------------------------------\n",gen);
  for (int i=0; i<tam; i++) {
    Fenotipo_print(fd,ctx, i, pop);
  }
  fprintf (fd,"\n");
}

/***********************************************************/
/* Imprimir solo los individuos que no seran reemplazados  */
/***********************************************************/
static void Generation_print_no_replace(FILE *fd,PGAContext *ctx,int pop)
{
  char filename[100];
  
  int rep = PGAGetNumReplaceValue(ctx);
  int tam = PGAGetPopSize(ctx);
  
  for (int i=0; i<tam-rep; i++) {
    
    //-- Imprimir
    Fenotipo_print(fd,ctx, i, pop);
    
    //-- Generar fichero
    if (i<5) {
      //-- Obtener el chromosoma
      chromosome_get(&chromo,ctx,i,pop);
  
      //-- Obtener el fenotipo
      chromosome_fenotipo_get(&chromo,&worm);
      sprintf (filename,"GA_ind%d.mvm",i);
      
      generar_fichero_mvm(filename);
      printf ("  %s\n",filename);
    }  
  }  
}

/****************************************************************/
/* Generar fichero OCTAVE con la evolucion de las generaciones  */
/* Se pasa como parametro el numero total de generaciones       */
/****************************************************************/
static void generar_fichero_generaciones(int gen)
{
  FILE *fd;
  char fich[200];
  
  //-- Crerar nombre del fichero, con la poblacion y iteraciones
  sprintf (fich,"exp15_HX_pob%d_iter%d_evol.m",tam_pob,num_itera);
  
  //-- Abrir fichero para escritura
  fd = fopen(fich,"w");
  
  
  fprintf (fd,"fit=[");
  for (int i=0; i<=gen; i++)
    fprintf (fd,"%.2f,",fitness[i]);
  fprintf (fd,"];\n");
  
  fprintf (fd,"gen=[0:1:%d];\n",gen);
  fprintf (fd,"title('Evolucion del fitness')\n");
  fprintf (fd,"xlabel('Iteraciones')\n");
  fprintf (fd,"ylabel('Fitness (cm)')\n");
  fprintf (fd,"axis([0,%d,0,35]);\n",gen);
  fprintf (fd,"grid on;\n");
  fprintf (fd,"plot(gen,fit);\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd);
  printf ("Fichero: %s\n",fich);
}



/***************************************************/
/* Simulacion de un paso                           */
/* Devuelve false cuando se ha terminado           */
/***************************************************/
static bool simLoop (void)
{
  
  //-- Realizar un paso de simulacion
  T1D_step(&worm);
    
  //-- Comprobar timeout
  if (worm.timeout) {
    printf ("Timeout!!\n");
    return false;
  }
  
  //-- Si comprobacion de volcado habilitada...
  if (volcado_check==1) {
    //-- Control anti-volcado!
    if (worm.period_transition) {
      if (worm.volcado_ciclo) return false;
    }
  }  
  
  //-- Al terminar un intervalo finaliza la simulacion
  if (worm.intervalo_transicion && worm.intervalo_numero==2) {
    return false;
  }  
    
  return true;
}

static void help()
{
  printf ("Error en los parametros pasados\n");
  printf ("Forma de uso: \n");
  printf ("  GA struct num_mod fit c_ini ciclos tam iter cromo-type\n");
  printf ("donde,\n");
  printf ("  -struct: Tipo de configuracion: PYn o Pn\n");
  printf ("  -Num_mod: Numero de modulos\n");
  printf ("  -fit: Tipo de fitness a medir: Dx,Dy,Vx,Vy,Yaw,Roll, W-Yaw, W-Roll\n");
  printf ("  -c_ini: ciclo inicial desde el que empezar a 'medir'\n");
  printf ("  -ciclos: Numero de ciclos del intervalo a medir\n");
  printf ("  -Tam: Es el tamano de la poblacion\n");
  printf ("  -Iter: Numero de iteraciones\n");
  printf ("  -Cromo-type: Tipo de cromosoma\n");
  printf ("Ejemplo:\n");
  printf ("  GA PYn 3 DX 1 2 100 100 T_Av_Ah_DFv_DFh_DFvh\n");
}


/********************************************/
/* Evaluar un individuo                     */
/********************************************/
double evaluar(PGAContext *ctx, int p, int pop)
{
  double fitness_value;
  
  
  //-- Obtener el chromosoma
  chromosome_get(&chromo,ctx,p,pop);
  
  //-- Obtener el fenotipo
  chromosome_fenotipo_get(&chromo,&worm);
  
  //-- CONSTRUIR CONFIGURACION y simulacion
  T1D_new_robot(&worm,false,false);
  
  //-- Para el caso de usar un cromosoma NO UNIFORME, esto es, que cada
  //-- modulo tiene un Ti diferente, el modulo de referencia que hay que 
  //-- tomar es el de mayor periodo
  //-- El problema es que el fitness depende del periodo elegido. Si en el
  //-- genetico se una uno, en las herramientas de visualizacion utilizadas
  //-- se debe usar el mismo. Sino, aunque el movimiento sea el mismo, el 
  //-- fitness calculado sera otro.
 
  if (chromo.type==T1D_CHROMO_Ti_Ai_Oi_Fi) {
    int mr=0;
    int maxT=worm.sf[0].N;
    for (int m=1; m<worm.nm; m++) {
      if (worm.sf[m].N>maxT) {
        maxT=worm.sf[m].N;
        mr=m;
      }  
    }
    
    //-- Establecer nuevo modulo de referencia
    worm.mod_ref=mr;
  }
  
  
  worm.intervalo_ciclo_ini=ciclos_ini;
  worm.intervalo_ciclos=ciclos;
  
  /********************************/
  /** COMENZAR LA SIMULACION!!!!  */
	/********************************/
  
  do {
  } while (simLoop());
  
  /************************/
	/* FIN DE LA SIMULACION */
	/************************/
  Rtk_Simulation_Engine_end(&(worm.sim));
    
  //-- Seleccionar la funcion de fitness
  if (worm.timeout) {
    fitness_value=0.0;
  }
  else {
    fitness_value = T1D_get_fitness(&worm,fitness_type);
  }  
    
  //-- Asegurarse de que el fitness es siempre positivo 
  if (fitness_value<0) fitness_value = -fitness_value;    
  
  
  //-- Si control del volcado habilitado...
  if (volcado_check==1) {
  
    //-- Restriccion para que no se produzca roll  
    if (fabs(RTK_TO_GRADOS(worm.rollinc_int))>50) {
      fitness_value=0.0;
    }
    
    //-- Un volcado provoca un fitness 0
    if (worm.volcado_ciclo) {
      fitness_value=0.0;
    }
  }  
  
  //-- Devolver fitness
  return fitness_value;
}

/*******************************/
/* Analizar los parametros     */
/*******************************/
static int analizar_parametros(T1D_Robot *worm, int argc, char **argv)
{
  int ok;
  
  //-- Comprobar el numero minimo de parametros
  if (argc<9) {
    return 0;
  }
  
  //-- Parametro: Tipo de estructura
  //-- Leer la estructura del robot
  ok = T1D_get_structure_type(argv[1], &param_estructura);
  if (!ok) {
    printf ("Parametro incorrecto: %s\n",argv[1]);
    return 0;
  }  
  
  //-- Parametro: Numero de modulos
  int nm;
  nm=atoi(argv[2]);
  
  if (nm<=0) {
    printf ("ERROR. Numero de modulos incorrecto\n");
    return 0;
  }
  worm->nm=nm;
  
  //-- Leer la funcion de fitness
  ok=T1D_get_fitness_type(argv[3],&fitness_type);
  if (!ok) {
    help();
    exit(1);
  }
  
  //-- Leer ciclo inicial y longitud del intervalo
  ciclos_ini=atoi(argv[4]);
    if (ciclos_ini==0) ciclos_ini=1;
      
  ciclos=atoi(argv[5]);
    if (ciclos==0) ciclos=1;
 
  //-- Leer tamano poblacion y numero de iteraciones
  tam_pob=atoi(argv[6]);
  num_itera=atoi(argv[7]);
  
  //-- Si alguno de los parametros es 0 se toma su valor por defecto
  if (tam_pob==0)
    tam_pob=TAMANO_POBLACION;
  
  if (num_itera==0)
    num_itera=NUM_ITERACIONES;
  
  
  //-- Leer el tipo de Cromosoma
  ok=T1D_get_chromosome_type(argv[8], &chromo_type);
  if (!ok) {
    printf ("ERROR. Cromosoma incorrecto: %s\n",argv[8]);
    return 0;
  }  
  
  //-- Para los cromosomas de tipo RAW, debe haber un parametro mas que 
  //-- indique el numero de muestras
  if (chromo_type==T1D_CHROMO_RAW) {
    
    if (argc<10) {
      printf ("ERROR. Si el cromosoma es de tipo RAW hay que indicar el numero\n");
      printf (" de muestras\n");
      return 0;
    }
    
    samples = atoi(argv[9]);
    if (samples==0) {
      printf ("ERROR. Numero de muestras incorrecto: %s\n",argv[9]);
      return 0;
    }
    
  }
  
  
  //-- Especificar la estructura del robot.
  T1D_set_structure(worm,param_estructura);
   
  return 1;
}


/**************************************************/
/* Establecer los parametros del GA para el exp 7 */
/**************************************************/
void set_PGA_param_exp7(PGAContext *ctx)
{
  PGASetNoDuplicatesFlag(ctx,PGA_TRUE);   //-- No queremos duplicados
  PGASetNumReplaceValue(ctx,tam_pob/2);   //-- Reemplezo de la poblacion
  PGASetSelectType(ctx,PGA_SELECT_PTOURNAMENT); //-- Seleccion poblacion
  PGASetCrossoverType(ctx,PGA_CROSSOVER_UNIFORM); //- Crossover uniforme
}

void set_PGA_clasic(PGAContext *ctx)
{
  PGASetNumReplaceValue(ctx,tam_pob);
  PGASetSelectType(ctx,PGA_SELECT_PTOURNAMENT);
  PGASetCrossoverType(ctx,PGA_CROSSOVER_UNIFORM);
  PGASetMutationAndCrossoverFlag(ctx,PGA_TRUE);
  PGASetSelectType(ctx,PGA_SELECT_PTOURNAMENT); //-- Seleccion poblacion
  
}

/***********************/
/* MAIN                */
/***********************/
int main( int argc, char **argv )
{
  int ok;
  
  //-- Analizar los parametros
  ok=analizar_parametros(&worm,argc,argv);
  
  //-- Comprobar si todo es correcto, sino terminar
  if (ok==0) {
    help();
    return 0;
  }
  
  //-- Mostrar los parametros leidos
  
  printf ("Estructura:           : ");
    T1D_print_structure_type(param_estructura);
    printf ("\n");
  printf ("Numero de modulos     : %d\n",worm.nm);
    printf ("Funcion de Fitness    : ");
    T1D_print_fitness_type(fitness_type);
  printf ("\n");
  
  printf ("Ciclo inicial         : %d\n",ciclos_ini);
  printf ("Numero de ciclos      : %d\n",ciclos);
 
  
  printf ("Tamano de la poblacion: %d\n",tam_pob);
  printf ("Numero de iteraciones : %d\n",num_itera);
  printf ("Tipo de cromosoma     : ");
    T1D_print_chromosome(chromo_type);
    printf ("\n");
  
  if (chromo_type==T1D_CHROMO_RAW) {
    printf ("Numero de muestras    : %d\n",samples);
  }
  printf ("Control VOLCADO       : %s\n", (volcado_check)?"SI":"NO");
  
  //-- Crear el cromosoma
  chromosome_new(&chromo, chromo_type, worm.nm, samples);
  
  //-- Inicializacion del paquete PGA  
  PGAContext *ctx;
  ctx = PGACreate(&argc, argv, PGA_DATATYPE_INTEGER,chromo.size, PGA_MAXIMIZE);
  
  /*---------------------------------------------*/
  /* Establecer algunos parametros del algoritmo */
  /*---------------------------------------------*/
  PGASetPopSize(ctx, tam_pob);            //-- Tamano poblacion
  PGASetMaxGAIterValue(ctx,num_itera);    //-- Numero de iteraciones
  
  //-- Establecer resto de parametros del genetico
  set_PGA_param_exp7(ctx);
 
  //set_PGA_clasic(ctx);
  
  //-- Establecer rangos para los valores enteros
  PGASetIntegerInitRange(ctx, chromo.data_lower, chromo.data_upper);
  
  //-- Configurar resto de parametros (por defecto)
  PGASetUp(ctx);
  
  //-- Crear la poblacion inicial
  PGAEvaluate(ctx, PGA_OLDPOP, evaluar, NULL);
  PGAFitness (ctx, PGA_OLDPOP);
  
  
  //-- Imprimir y sacar estadisticas de la poblacion inicial
  Generation_print_all(stdout,ctx,PGA_OLDPOP,0);
  printf ("\n");
  
  int gen=0;
  int bi=PGAGetBestIndex(ctx,PGA_OLDPOP);
  double fit=0;
  double fit_old=0;
  fitness[gen]=PGAGetFitness(ctx,bi,PGA_OLDPOP);
  
  //-- Crerar nombre del fichero, con la poblacion y iteraciones para
  //-- guardar los individuos de las diferentes generaciones
  sprintf (fich2,"exp15_HX_pob%d_iter%d_evol.txt",tam_pob,num_itera);
  
  //-- Abrir fichero para escritura
  fd2 = fopen(fich2,"w");
  
  //-- Bucle principal
  while(!PGADone(ctx, NULL)) {
    PGASelect (ctx, PGA_OLDPOP);
    PGARunMutationAndCrossover(ctx, PGA_OLDPOP, PGA_NEWPOP);
    PGAEvaluate(ctx, PGA_NEWPOP, evaluar, NULL);
    PGAFitness (ctx, PGA_NEWPOP);
    PGAUpdateGeneration(ctx, NULL);
    
    gen++;
    
    bi=PGAGetBestIndex(ctx,PGA_OLDPOP);
    fit=PGAGetFitness(ctx,bi,PGA_OLDPOP);
    fitness[gen]=fit;
    printf ("->Gen: %d. Index ",gen);
    
    
    Fenotipo_print(stdout,ctx, bi, PGA_OLDPOP);

    //-- Guardar informacion en el fichero
    if (fit!=fit_old) {     
      fprintf (fd2,"->Gen: %d. Index",gen);
      Fenotipo_print(fd2,ctx, bi, PGA_OLDPOP);
      Generation_print_all(fd2,ctx,PGA_OLDPOP,gen);
    }  
    fit_old=fit;
  }  
  
  //-- Fin
  printf ("\n");
  printf ("FIN--------------------------------------\n");
  Generation_print_no_replace(stdout,ctx, PGA_OLDPOP);
  generar_fichero_generaciones(gen);
  
  //-- Destruir variable de contexto
  PGADestroy(ctx);
  
  //-- Cerrar fichero
  printf ("Fichero: %s\n",fich2);
  fclose(fd2);
    
  return(0);
}
