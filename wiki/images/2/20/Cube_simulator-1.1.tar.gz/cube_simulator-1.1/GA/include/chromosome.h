/*---------------------------------------------------------------------------*/
/**  \file T1D.h
  *  \brief Definiciones, estructuras de datos y prototipos de T1D           *
  *  Structuras de datos, definiciones y prototipos de T1D                   */
/*---------------------------------------------------------------------------*/

#ifndef _CHROMOSOME_H
#define _CHROMOSOME_H

#include <stdio.h>
#include "pgapack.h"

/*----------------------------*/
/* CONSTANTES                 */
/*----------------------------*/

//-- Longitud maxima del cromosoma
#define MAX_CHROMOSOME_LENGTH 100


/*--------------------------------------------------------------------------*/
/*                        ESTRUCTURAS DE DATOS                              */
/*--------------------------------------------------------------------------*/

//-- Cromosoma
struct Chromosome {
  
  //-- Datos del cromosoma
  int data[MAX_CHROMOSOME_LENGTH];
  
  //-- Valores superiores
  int data_upper[MAX_CHROMOSOME_LENGTH];
  
  //-- Valores inferiores
  int data_lower[MAX_CHROMOSOME_LENGTH];
  
  //-- Tamano del cromosoma (en bytes)
  int size;
  
  //-- Tipo de cromosoma
  int type;

  //-- Numero de modulos
  int nm;  
  
  //-- Numero de muestras (Solo para cromosomas RAW)
  int nsamples;
};


/*------------------------------------------------------------------*/
/*        PROTOTIPOS DE LAS FUNCIONES                               */
/*------------------------------------------------------------------*/

void chromosome_new(Chromosome *chromo, int chomo_type, int nm, int data);
void chromosome_get(Chromosome *chromo,PGAContext *ctx, int p, int pop);
void chromosome_print(FILE *fd, Chromosome *chromo);
void chromosome_fenotipo_get(Chromosome *chromo,T1D_Robot *worm);

#endif   // _CHROMOSOME_H
