﻿namespace wii_leds
{
    partial class Wii_leds
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Led1 = new System.Windows.Forms.CheckBox();
            this.Led2 = new System.Windows.Forms.CheckBox();
            this.Led3 = new System.Windows.Forms.CheckBox();
            this.Led4 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Led1
            // 
            this.Led1.AutoSize = true;
            this.Led1.Location = new System.Drawing.Point(31, 13);
            this.Led1.Name = "Led1";
            this.Led1.Size = new System.Drawing.Size(15, 14);
            this.Led1.TabIndex = 0;
            this.Led1.UseVisualStyleBackColor = true;
            this.Led1.CheckedChanged += new System.EventHandler(this.Led1_CheckedChanged);
            // 
            // Led2
            // 
            this.Led2.AutoSize = true;
            this.Led2.Location = new System.Drawing.Point(53, 13);
            this.Led2.Name = "Led2";
            this.Led2.Size = new System.Drawing.Size(15, 14);
            this.Led2.TabIndex = 1;
            this.Led2.UseVisualStyleBackColor = true;
            this.Led2.CheckedChanged += new System.EventHandler(this.Led2_CheckedChanged);
            // 
            // Led3
            // 
            this.Led3.AutoSize = true;
            this.Led3.Location = new System.Drawing.Point(76, 13);
            this.Led3.Name = "Led3";
            this.Led3.Size = new System.Drawing.Size(15, 14);
            this.Led3.TabIndex = 2;
            this.Led3.UseVisualStyleBackColor = true;
            this.Led3.CheckedChanged += new System.EventHandler(this.Led3_CheckedChanged);
            // 
            // Led4
            // 
            this.Led4.AutoSize = true;
            this.Led4.Location = new System.Drawing.Point(99, 13);
            this.Led4.Name = "Led4";
            this.Led4.Size = new System.Drawing.Size(15, 14);
            this.Led4.TabIndex = 3;
            this.Led4.UseVisualStyleBackColor = true;
            this.Led4.CheckedChanged += new System.EventHandler(this.Led4_CheckedChanged);
            // 
            // Wii_leds
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(160, 37);
            this.Controls.Add(this.Led4);
            this.Controls.Add(this.Led3);
            this.Controls.Add(this.Led2);
            this.Controls.Add(this.Led1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Wii_leds";
            this.Text = "Wii_Leds";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Wii_leds_FormClosing);
            this.Load += new System.EventHandler(this.Wii_leds_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Led1;
        private System.Windows.Forms.CheckBox Led2;
        private System.Windows.Forms.CheckBox Led3;
        private System.Windows.Forms.CheckBox Led4;
    }
}

