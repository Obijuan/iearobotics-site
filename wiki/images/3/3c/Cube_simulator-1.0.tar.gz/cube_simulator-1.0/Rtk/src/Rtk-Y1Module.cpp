/*-------------------------------------------------------------------------*/
/**  \file Rtk-Y1Module.cpp
  *  \brief Modelado y simulacion de un modulo Y1
  *
  *  Este fichero incluye las funciones para crear el modelo ODE para 
  *  los modulos Y1, simular el controlador del servo, posicionarlo y 
  *  leer su posicion y velocidad. No incluye nada relacionado con la 
  *  renderizacion 3D. Esto permite realizar simulaciones para consola.
  *  Para hacer simulaciones 3D hay que utilizar el fichero modulo-y1-3D.
  *  \n Mas informacion en el fichero modulo-y1.h  
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Treviño.
  *  \date Agosto 2006. Licencia GPL                                        */
/*--------------------------------------------------------------------------*/

//-- Esto se utiliza para mover el servo real a la vez que el virtual
//#include "sg-tramas-servos8.h"


#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/
/*******************************************************/
/* Crear un segmento del modulo                        */
/* ENTRADAS:                                           */
/*   -mod: Puntero al modulo                           */
/*   -ns:  Numero de segmento. 0 Izquierdo. 1 derecho  */
/*   -ext: Posicion del extremo izquierdo              */
/*   -(x,y): Posicion de la parte izquierda            */
/*******************************************************/
static void Crear_segmento(RtkY1Module *mod, int ns, dReal x, dReal y)
{
  dReal Ls;  //-- Longitud del segmento
  dReal Ms;  //-- Masa del segmento
  
  //-- Seleccionar longitud y masa el segmento, segun sea el
  //-- de la derecha o izquierda
  if (ns==0) {
    Ls=mod->Li;
    Ms=mod->Mi;
  }  
  else {
    Ls=mod->Ld;
    Ms=mod->Md;
  }   
  
	//-- Crear segmento y asociarlo al cuerpo
	mod->seg[ns].body = dBodyCreate(mod->sim->world);
  
	//-- Posicion inicial del segmento
	dBodySetPosition(mod->seg[ns].body, x, y-Ls/2.0, 
                   mod->altura/2.0 + mod->zini); 
	
	//-- Establecer la orientaion
	dMatrix3 R;
	dRFromAxisAndAngle(R,0,0,1,0);
	dBodySetRotation (mod->seg[ns].body,R);
	
	//-- Establecer la masa
	dMass m;
	dMassSetBoxTotal (&m, Ms, mod->grosor,Ls,mod->altura);
	dBodySetMass (mod->seg[ns].body,&m);
	
	//-- Crear la geometria
	mod->seg[ns].geom = dCreateBox (mod->sim->space,mod->grosor,Ls, 
                                  mod->altura);
	
	//-- Asociar el cuerpo con la geometria
	dGeomSetBody (mod->seg[ns].geom,mod->seg[ns].body);
  
  /********************************************************/
  /* Almacenar el estado inicial, para poder hacer reset  */
  /********************************************************/
  
  //-- Almacenar la posicion inicial
  const dReal *pos_ini;
  pos_ini = dBodyGetPosition(mod->seg[ns].body);
  memcpy(mod->seg[ns].pos_ini, pos_ini, sizeof(dVector3));
  
  //-- Almacenar la rotacion inicial
  const dReal *Rot_ini;
  Rot_ini=dBodyGetRotation(mod->seg[ns].body);
  memcpy(mod->seg[ns].Rot_ini, Rot_ini, sizeof(dMatrix3));
  
}

/******************************************************/
/* Crear el servo.                                    */
/* Entradas:                                          */
/*    -mod: Puntero al modulo                         */
/*    -pitch: 0 servo pitch, 1 servo yaw              */
/******************************************************/
static void Crear_servo(RtkY1Module *mod)
{
	//-- Crear la articulacion
	mod->servo=dJointCreateHinge (mod->sim->world, 0);
	
	//-- Unir articulacion a los dos segmentos
	dJointAttach (mod->servo, mod->seg[0].body, mod->seg[1].body);
	
	//-- Definir el eje de rotacion
	//-- Depende de si es pitch o yaw. El eje para pitch es (1,0,0)
	//-- El eje para Yaw es 0,0,1
	if (mod->pitch) {  
	  dJointSetHingeAxis (mod->servo, 1,0,0);
	}	
	else { 
	  dJointSetHingeAxis (mod->servo, 0,0,1);
	}
	
	//-- Posicionar Punto de anclaje para el eje
  //-- Se situa en el extremo derecho del segmento izquierdo
    //-- Obtener posicion x,y del segmento izquierdo
    const dReal *pos;
    pos=dBodyGetPosition(mod->seg[0].body);
  
    //-- Establecer punto de anclaje
	  dJointSetHingeAnchor (mod->servo, pos[0], 
                         (pos[1]+mod->Li/2.0) - mod->Li,
                          mod->altura/2.0 + mod->zini);
	
	//-- Establecer otros parametros del servo
	dJointSetHingeParam(mod->servo, dParamFMax, mod->par);
  dJointSetHingeParam(mod->servo, dParamVel, 0.0);
  
  /********************************************************/
  /* Almacenar el estado inicial, para poder hacer reset  */
  /********************************************************/
  
  //-- Leer punto de anclaje de la articulacion
  dJointGetHingeAnchor (mod->servo, mod->anclaje_ini);
  
}

/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/


/*****************************************************************************/
/** \brief Crear un nuevo modulo. Se inicializa con los valores por defecto  
*
*   \param mod : SALIDA. Modulo con los parametros por defecto               */
/*****************************************************************************/
void  Rtk_Y1Module_new(RtkY1Module *mod)
{
  //-- Poner a cero el modulo
  memset(mod, 0, sizeof(RtkY1Module));
  
  /*-------------------------------------------------*/
  /* INICIALIZAR LOS CAMPOS COMUNES                  */
  /*-------------------------------------------------*/
  mod->type=RTK_TYPE_Y1MODULE;
  mod->Parent=NULL;
  mod->Parent_type=RTK_TYPE_UNKNOW;
  mod->sim=NULL;
  
  
  /*----------------------------------------------------------*/
  /* INICIALIZAR LOS ATRIBUTOS PARTICULACIONES DEL MODULO Y1  */
  /* Se establecen los valores por defecto                    */
  /*----------------------------------------------------------*/
  
  mod->pos_ref=0.0;
  mod->error=0.0;
  mod->error_min=RTK_TO_RADIANES(ERROR_MIN);
  mod->xini=0.0;
  mod->yini=0.0;
  mod->zini=0.0;
  mod->pitch=1;
  
  mod->Li=RTK_MM_TO_METROS(LONG_mm/2.0);     //-- Longitud del brazo izquierdo
  mod->Ld=RTK_MM_TO_METROS(LONG_mm/2.0);     //-- Longitud del brazo derecho
  mod->L= mod->Li + mod->Ld;                 //-- Longitud total del modulo
  mod->grosor=RTK_MM_TO_METROS(GROSOR_mm);   //-- Grosor en mm
  mod->altura=RTK_MM_TO_METROS(ALTURA_mm);   //-- Altura en mm
  
  mod->Mi=RTK_GR_TO_KILOS(MASA_gr/2.0);      //-- Masa del segmento izqdo
  mod->Md=RTK_GR_TO_KILOS(MASA_gr/2.0);      //-- Masa del segmento derecho
  mod->M= mod->Mi + mod->Md;             //-- Masa total del modulo
  mod->par=SERVO_PAR_Nm;                 //-- Par en N.m
  mod->Kp=KP;                            //-- Constante controlador P
  mod->wmax=WMAX;                        //-- Vel. ang. servo (rad/seg)
  
  //-- Para controlador integral
  mod->estado_integral=0;
  mod->Ki=KI;
  
  //-- Para controlador diferencial
  mod->estado_dif=0;
  mod->Kd=KD;
  
  //-- Generador
  mod->gen=NULL;
  mod->generator_type=RTK_TYPE_GENERATOR;
  
  /*-----------------------------------------------*/
  /* Atributos relacionados con el renderizado 3D  */
  /*-----------------------------------------------*/
  //-- Color por defecto del modulo
  mod->red=1;
  mod->green=1;
  mod->blue=0;
  
  //---- Por defecto el numero de servo es 0 (ninguno)
  mod->servo_real=0;
}


/************************************************************/
/* Crear e inicializar un modulo Y1                         */
/************************************************************/
void Rtk_Y1module_create(RtkSimulationEngine *sim, RtkY1Module *mod)
{
  RtkGenerator *gen;
 
  if (sim==NULL) {
    printf ("Warning: Puntero a simulacion NULO!!\n");
    return;
  }
  
  if (mod==NULL) {
    printf ("Warning: Puntero a modulo NULO!!\n");
  }
  
  //-- Poner el puntero al contexto
  mod->sim=sim;
  
  //-- Segmento izquierdo
  Crear_segmento(mod, 0, mod->xini, mod->yini);
  
  //-- Segmento derecho
  Crear_segmento(mod, 1, mod->xini, mod->yini - mod->Li );
  
  //-- Articulacion
	Crear_servo(mod);
  
  //-- Si hay un generador asociado, crearlo
  if (mod->gen!=NULL) {
    gen=mod->gen;
    Rtk_Generator_create(sim,gen);
  }  
}


/***********************************************************/
/* Realizar un paso de simulacion del servo                */
/* Se calcula el nuevo "error" y se modifica la velocidad  */
/* CONTROLADOR DEL SERVO!!                                 */
/* Prueba de controlador PID                               */
/* Entradas:                                               */
/*    -simulate_generator: 1, se simula el generador       */
/*                         0, no se simula                 */
/***********************************************************/
void Rtk_Y1module_simulate(RtkY1Module *mod, int simulate_generator)
{
  if (mod==NULL) {
    printf ("Warning. Rtk_Y1Module_simulate. mod==NULL\n");
    return;
  }
  
  
  //-- Obtener la posicion actual del servo
  dReal posicion_actual = dJointGetHingeAngle(mod->servo);
  
  //-- Calcular el error: lo que falta para llegar a la posicion especificada
  //-- Mide la "distancia" que queda por recorrer
	mod->error = posicion_actual - mod->pos_ref;
  
  //-- Conotrolador proporcional: la velocidad es proporcional al error
  //-- Si la distancia que queda es grande, la velocidad es grande.
  //-- Si la distancia es pequena, la velocidad es pequena
  //-- Si ha llegado a la posicion deseada, la velocidad sera cero
  dReal term_prop = -mod->error * mod->Kp;
  
  
  // Estado integral: acumular el error
  mod->estado_integral += mod->error;
  
  //-- Limitar el valor maximo del estado integral
  if (mod->estado_integral > 100.0) mod->estado_integral=100.0;
  else if (mod->estado_integral < -100.0) mod->estado_integral=-100.0;
 
    
  //-- Calcular el termino integral
  dReal term_integral = mod->Ki * mod->estado_integral;
 
  //-- Calcular termino diferencial  
  dReal term_diferencial = mod->Kd * (posicion_actual - mod->estado_dif);
  
  //-- EStado diferencial: almacenar posicion actual
  mod->estado_dif = posicion_actual;
  
  //-- La velocidad es la suma de los tres terminos
  dReal velocidad=term_prop + term_integral - term_diferencial;
  
  //-- Limitar la velocidad. No puede ser mayor que la maxima del servo
  if (velocidad > mod->wmax) velocidad = mod->wmax;
  if (velocidad < -mod->wmax) velocidad = -mod->wmax;
  
  //-- Establecer la velocidad
	dJointSetHingeParam(mod->servo, dParamVel, velocidad);
 
  /*------------------------------------------*/
  /* Controlador de posiciones de referencia  */
  /*------------------------------------------*/
  RtkGenerator *gen;
  
  gen=(RtkGenerator *)mod->gen;
  
  //-- Si no hay generador se termina
  if (mod->gen==NULL) return;
  
  //-- Simular el generador
  Rtk_Generator_simulate(gen);
  
  //-- Utilizar controlador del modulo, si se habia solicitado
  if (simulate_generator) {
    
    //-- Comprobar si el controlador se ha disparado y el generador debe
    //-- enviar la siguiente posicion de referencia
    if (Rtk_Y1Module_trigger(mod)) {
       Rtk_Generator_next_sample(gen);
    }
  } 
  
}


/****************************************/
/* Imprimir la estructura del modulo Y1 */
/****************************************/
void Rtk_Y1Module_print(RtkY1Module *mod, int depth)
{
  RtkGenerator *gen;
  
  if (mod==NULL) {
    printf ("Warning. Rtk_Y1Module_simulate. mod==NULL\n");
    return;
  }
  
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Y1 MODULE\n");
  
  
  //-- Imprimir el generador si esta conectado
  gen=(RtkGenerator *)mod->gen;
  
  if (mod->gen!=NULL)
    Rtk_Generator_print(gen,depth+2);  
}


/********************************************************************/
/* Posicionar el servo del modulo                                   */
/* Se especifica la posicion deseada. Con cada tick de simulacion   */
/* el servo se ira posicionando                                     */
/* ENTRADAS:                                                        */
/*   -mod: Puntero al modulo                                        */
/*   -pos: Posicion del servo. En radianes. Los valores deben estar */
/*         comprendidos entre [-M_PI/2, M_PI/2]                     */
/********************************************************************/
void Rtk_Y1Module_set_pos_ref(RtkY1Module *mod, dReal pos)
{
  mod->pos_ref=pos;
}

/********************************************************************/
/* Posicionar el servo del modulo                                   */
/* Se especifica la posicion deseada en GRADOS.                     */
/* el servo se ira posicionando                                     */
/* ENTRADAS:                                                        */
/*   -mod: Puntero al modulo                                        */
/*   -pos: Posicion del servo. En Grados. Los valores deben estar   */
/*         comprendidos entre [-90, 90]                             */
/********************************************************************/
void Rtk_Y1Module_set_pos_ref_grados(RtkY1Module *mod, dReal pos)
{
  mod->pos_ref=RTK_TO_RADIANES(pos);
  
  //-- Actuar sobre el servo fisico si estaba abierto puerto serie
  if (mod->sim->serial_fd>0) {
    
    //-- Si numero de servo distinto de cero mover servo
    if (mod->servo_real!=0) {
      
      //-- Esto se utiliza para mover el robot real a la vez que el virtual
      //sg_servos8_pos1_grados(mod->servo_real, -(int)round(pos));
      
      //-- Debug
      //printf ("  Servo: %d!\n",mod->servo_real);
    }  
  }
}

/*----------------------------------------------------*/
/* Establecer nuevos datos para el modulo             */
/*----------------------------------------------------*/
void Rtk_Y1Module_set_data(RtkY1Module *mod)
{
  //-- Asegurarse que L = Li + Ld
  mod->L = mod->Li + mod->Ld;
  
  //-- Asegurarse que M = Mi + Md
  mod->M = mod->Mi + mod->Md;
}

/*********************************************************************/
/* Determinar si el servo esta en una situacion estable, es decir,   */
/* que si esta parado o muy proximo a su posicion final              */
/* DEVUELVE:                                                         */
/*    0: No ha alcanzado una posicion estable                        */
/*    1: Ha llegado a posicion estable                               */
/*********************************************************************/
int Rtk_Y1Module_stable(RtkY1Module *mod)
{
  if (mod->error < -mod->error_min || mod->error > mod->error_min) {
    return 0;  //-- El error no es lo suficientemente pequeno
  }
  else {
    return 1; //-- Situacion estable
  }
}

/**********************************************************************/
/* Obtener la posicion actual del servo en RADIANES                   */
/**********************************************************************/
dReal Rtk_Y1Module_get_pos(RtkY1Module *mod)
{
  return dJointGetHingeAngle(mod->servo);
}

/**********************************************************************/
/* Obtener la posicion actual del servo en GRADOS                     */
/**********************************************************************/
dReal Rtk_Y1Module_get_pos_grad(RtkY1Module *mod)
{
  return RTK_TO_GRADOS(dJointGetHingeAngle(mod->servo));
}

/*********************************************************/
/* Obtener la velocidad actual del servo en grados/seg   */
/*********************************************************/
dReal Rtk_Y1Module_get_vel(RtkY1Module *mod)
{
  return RTK_TO_GRADOS(dJointGetHingeParam(mod->servo, dParamVel));
}

/***************************************************/
/* Anadir un generador al modulo Y1                */
/***************************************************/
void Rtk_Y1Module_generator_add(RtkY1Module *mod, RtkGenerator *gen)
{
  //-- Enlazar desde el modulo al generador
  mod->gen=gen;
  mod->generator_type=gen->type;
  
  //-- Enlazar desde el generador al modulo
  gen->Parent=mod;
  gen->Parent_type=mod->type;
  
}

/*******************************************/
/* Comprobar el critero de "disparo"       */
/*******************************************/
int Rtk_Y1Module_trigger(RtkY1Module *mod)
{
  //-- En un moduloY1, de momento el critero de disparo es que
  //-- se haya alcanzado la posicion de referia con un error
  return Rtk_Y1Module_stable(mod);
}

/**************************************************/
/* Obtener las coordenadas del centro del modulo  */
/**************************************************/
void Rtk_Y1Module_get_center(RtkY1Module *mod, dVector3 pos)
{
  
  //-- Leer posicion de la fijacion
  dJointGetHingeAnchor(mod->servo,pos);  
}

/**********************************************/
/* Llevar el modulo a su estado inicial       */
/**********************************************/
void Rtk_Y1Module_reset(RtkY1Module *mod)
{
  OdeObject *si,*sd;
  
  si=&(mod->seg[0]);
  sd=&(mod->seg[1]);
  
  //-- Establecer Posicion y rotacion iniciales del segmento izquierdo
	dBodySetPosition(si->body, si->pos_ini[X], si->pos_ini[Y], si->pos_ini[Z]);
  dBodySetRotation (si->body,si->Rot_ini);
  
  //-- Establecer Posicion y rotacion iniciales del segmento derecho
	dBodySetPosition(sd->body, sd->pos_ini[X], sd->pos_ini[Y], sd->pos_ini[Z]);
  dBodySetRotation (sd->body,sd->Rot_ini);
  
  //-- Establecer punto de anclaje del servo
  dJointSetHingeAnchor (mod->servo, mod->anclaje_ini[X], 
                         mod->anclaje_ini[Y],
                         mod->anclaje_ini[Z]);
  
  //-- Posicion de referencia 0
  mod->pos_ref=0;
  
  //-- Velocidad del servo a 0
  dJointSetHingeParam(mod->servo, dParamVel, 0.0);
  
  //-- Inicializar el generador, si lo hubiese
  if (mod->gen!=NULL)
    Rtk_Generator_reset(mod->gen);
}

/**************************************************/
/* Obtener el generador asociado al modulo        */
/**************************************************/
RtkGenerator *Rtk_Y1Module_get_generator(RtkY1Module *mod)
{
  return mod->gen;
}
