/**  \file Rtk-Chain.cpp
  *  \brief Cadena de modulos
  *
  *  \author Juan Gonzalez Gomez. 
  *  \author Rafael Trevino
  *  \date Septiembre 2006. Licencia GPL
*/

#include "Rtk.h"

/*--------------------------------------------------*/
/* FUNCIONES PRIVADAS                               */
/*--------------------------------------------------*/
/***************************************************************/
/* Unir los modulos izquierdo y derecho mediante una fijacion  */
/***************************************************************/
static void Crear_fijacion(RtkChain *chain, int fij, int mi, int md)
{
  RtkY1Module *modi, *modd;
  
  //-- Punteros a los modulos a unir
  modi= chain->module[mi];
  modd= chain->module[md];
  
	//-- Crear la fijacion
	chain->fixation[fij]=dJointCreateHinge (chain->sim->world, 0);
	
	//-- Unir los dos modulos. Segmento derecho del modulo Izquierdo, con
  //-- el segmento izquierdo del modulo derecho
	dJointAttach (chain->fixation[fij], modi->seg[1].body, modd->seg[0].body);
	
	//-- Definir el eje de rotacion. En realidad nunca habra rotacion, pero
  //-- para "unir" dos objetos hay que usar una articulacion 
	dJointSetHingeAxis (chain->fixation[fij], 1,0,0);
  
  //-- Anclar el eje. Estara situado en el punto medio entre los dos
  //-- modulos. Para su calculo se puede obtener la posicion del 
  //-- segmento derecho del modulo izquierdo y restarle LONG/4 a la 
  //-- coordenada y
    const dReal *pos;
    pos=dBodyGetPosition(modi->seg[1].body);
  
    //-- Establecer punto de anclaje
	  dJointSetHingeAnchor (chain->fixation[fij], pos[0], 
                          (pos[1]-modi->Ld/2.0), modd->altura/2.0);
	
	//-- Establecer otros parametros del servo
	dJointSetHingeParam(chain->fixation[fij], dParamFMax, 1000);
  dJointSetHingeParam(chain->fixation[fij], dParamVel, 0.0);
  
  //-- Es posible establecer una posicion "inicial" de esta articulacion
  //-- lo que permitiria conectar los dos modulos Y1 con otra orientacion
  
  /********************************************************/
  /* Almacenar el estado inicial, para poder hacer reset  */
  /********************************************************/
  //-- Leer punto de anclaje de la articulacion 
  dJointGetHingeAnchor (chain->fixation[fij], chain->fixation_ini[fij]);
}


/*-----------------------------------------------------------------------*/
/*                 FUNCIONES DE INTERFAZ                                 */
/*-----------------------------------------------------------------------*/

/***********************************/
/* Crear una nueva cadena          */
/***********************************/
void Rtk_Chain_new(RtkChain *chain)
{
  //-- Poner a cero el objeto
  memset(chain, 0, sizeof(RtkChain));
  
  
  //-- Iniciar los valores por defecto
  
  //-- Indica el tipo de roboget
  chain->type=RTK_TYPE_CHAIN;
  
  //-- Roboget padre
  chain->Parent=NULL;
  
  //-- Tipo del roboget padre
  chain->Parent_type=RTK_TYPE_UNKNOW;
  
  //-- Enlace al simulador
  chain->sim=NULL;
  
  /**********************************/
  /* CAMPOS PARTICULARES DEL GRUPO  */
  /**********************************/
  
  //! Modulos dentro de la cadena
  for (int i=0; i<RTK_MAX_MOD; i++)
    chain->module[i]=NULL;
  
  //-- Numero de modulos en el grupo
  chain->size=0;
  
  //-- Tipo de control
  chain->centralized_controller=1;
  
  //-- Posiciones iniciales de la configuracion
  chain->xini=0;
  chain->yini=0;
  chain->zini=0;
}

/*********************************/
/* Anadir un modulo a la cadena  */
/*********************************/
void  Rtk_Chain_add(RtkChain *chain, RtkY1Module *mod)
{
  //-- Enlace de la cadena al modulo
  chain->module[chain->size] = mod;
  chain->size++;
  
  //-- Enlace del modulo a la cadena
  mod->Parent=chain;
  mod->Parent_type=chain->type;
}


/********************************/
/* Crear la cadena              */
/********************************/
void Rtk_Chain_create(RtkSimulationEngine *sim, RtkChain *chain)
{
  RtkY1Module *mod;
  
  //-- Enlazar con la simulacion
  chain->sim=sim;
  
  //-- Crear modulo izquierdo
  mod = (RtkY1Module *)chain->module[0];
  Rtk_Y1module_create(sim,mod);
   
  //-- Recorrer la cadena estableciendo las coordenadas iniciales
  for (int i=1; i<chain->size; i++) {
    chain->module[i]->yini = mod->yini - chain->module[i]->L;
    chain->module[i]->xini = mod->xini;
    chain->module[i]->zini = mod->zini;
    
    //-- Crear el modulo
    mod = chain->module[i];
    Rtk_Y1module_create(sim,mod);
    
  }
  
  //-- Crear las fijaciones
  for (int i=0; i<chain->size-1; i++) {
    Crear_fijacion(chain,i,i,i+1);
  }
  
  //Crear_fijacion(chain,0,0,1);
  //Crear_fijacion(chain,1,1,2);
}

/*************************************************************/
/* Comprobar si todos los modulos de la cadena son estables  */
/*************************************************************/
int Rtk_Chain_stable(RtkChain *chain)
{
  
  //-- Simular cada uno de los modulos
  for (int i=0; i<chain->size; i++) {
    if (!Rtk_Y1Module_stable(chain->module[i]))
      return 0;
  }  
  
  //-- Si llega aqui es que todos son estables
  return 1;
}


/************************************/
/* Simular la cadena                */
/************************************/
void Rtk_Chain_simulate(RtkChain *chain)
{
  RtkGenerator *gen;
  RtkY1Module  *mod;
  int stable;
  
  if (chain==NULL) {
    printf ("Warning: Rtk_Chain_simulate. chain==NULL\n");
    return;
  }
  
  //-- Si el cocntrol esta realizado por la cadena
  if (chain->centralized_controller) {
    
    //-- Simular modulos
    for (int i=0; i<chain->size; i++)
      Rtk_Y1module_simulate(chain->module[i],0);
    
    //-- Condicion de disparo
    if (Rtk_Chain_stable(chain)) {
      for (int i=0; i<chain->size; i++) {
        //-- POR HACER: CONTROL DE NULL!!!!
        mod = (RtkY1Module *)chain->module[i];
        gen = (RtkGenerator *)mod->gen;
        Rtk_Generator_next_sample(gen);
      }  
    }
    
  }
  else {
    //-- Control no centralizado
    //-- Simular cada uno de los modulos de forma independiente
    for (int i=0; i<chain->size; i++) {
      Rtk_Y1module_simulate(chain->module[i],1);
    }
  }
  
  
}


/***********************************************/
/* Imprimir La cadena de modulos               */
/***********************************************/
void Rtk_Chain_print(RtkChain *chain, int depth)
{
  if (chain==NULL) {
    printf ("Warning: Rtk_Chain_print. chain==NULL\n");
    return;
  }
  
  for (int i=0; i<depth; i++)
    printf (" ");
  
  printf ("* Chain\n");
  
  //-- Imprimir cada uno de los modulos
  for (int i=0; i<chain->size; i++)
    Rtk_Y1Module_print(chain->module[i],depth+2);
}

/*************************************/
/* Hacer un reset de la cadena       */
/*************************************/
void Rtk_Chain_reset(RtkChain *chain)
{
   if (chain==NULL) {
    printf ("Warning: Rtk_Chain_reset. chain==NULL\n");
    return;
  }
  
  //-- Hacer reset de cada uno de los modulos
  for (int i=0; i<chain->size; i++)
    Rtk_Y1Module_reset(chain->module[i]);
  
  //-- Llevar las fijaciones a su estado inicial
  for (int i=0; i<chain->size-1; i++) {
    dJointSetHingeAnchor (chain->fixation[i], chain->fixation_ini[i][X], 
                          chain->fixation_ini[i][Y],
                          chain->fixation_ini[i][Z]);
  
    //-- Velocidad  a 0
    dJointSetHingeParam(chain->fixation[i], dParamVel, 0.0);
  }  
}

/****************************************************/
/* Leeer la posicion del primer modulo de la cadena */
/****************************************************/
void Rtk_Chain_get_center(RtkChain *chain, dVector3 pos)
{
  
  RtkY1Module *mod;
  
  mod=(RtkY1Module *)chain->module[0];
  Rtk_Y1Module_get_center(mod,pos);
}
 
/***************************************/
/* Devolver un generador de la cadena  */
/***************************************/
RtkGenerator *Rtk_Chain_get_generator(RtkChain *chain)
{
  RtkY1Module *mod;
  
  mod=(RtkY1Module *)chain->module[0];
  return Rtk_Y1Module_get_generator(mod);
}

void Rtk_Chain_set_initial_pos(RtkChain *chain, dReal x, dReal y, dReal z)
{
  //-- Establecer la posicion del modulo de la izquierda
  chain->module[0]->xini=x;
  chain->module[0]->yini=y;
  chain->module[0]->zini=z;
}
