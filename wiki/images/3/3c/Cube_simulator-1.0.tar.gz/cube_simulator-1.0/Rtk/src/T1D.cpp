/*---------------------------------------------------------------------------*/
/**  \file T1D.cpp
  *  \brief Common function for working with 1D topologies: Pn, PXn and PYn
  *         using sinusoidal CPGs      
  *
  *  Only topology is moved. 
  *  \author Juan Gonzalez Gomez. Licencia GPL
  *  \date January 2007
*/
/*---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "T1D.h"

/*-------------------*/
/* CONSTANTES        */
/*-------------------*/
//-- Identificadores para referirse al segmento derecho o izquierdo de un
//-- modulo
#define IZQ 0
#define DER 1


static void calcular_angulos(T1D_Robot *worm);

/*----------------------------------------------------------------------*/
/*    FUNCIONES DE INTERFAZ                                             */
/*----------------------------------------------------------------------*/


/*************************************************************************/
/* Obtener los parametros del usuario, procesarlos y almacenarlos en el  */
/* tipo del robot                                                        */
/* DEVUELVE:                                                             */
/*   0 : Error al procesar los argumentos                                */
/*   1 : OK                                                              */
/*************************************************************************/
int T1D_get_args(T1D_Robot *worm, int argc, char* argv[],bool verbose)
{
  
  //-- Al menos debe haber un modulo. Eso implica 6 parametros, por tanto
  //-- argc debe ser >= que 7
  if (argc<7) {
    if (verbose) {
      printf ("FALTAN ARGUMENTOS\n");
    }  
    return 0;
  }
  
  //-- Leer numero de modulos y comprobar que es correcto
  int num_mod;
  num_mod=atoi(argv[1]);
  
  if (num_mod<=0) {
    if (verbose)
      printf ("ERROR. Numero de modulos incorrecto\n");
    return 0;
  }
  
  if (num_mod>RTK_MAX_MOD) {
    if (verbose)
      printf ("ERROR. Numero maximo de modulos permitidos: %d\n",RTK_MAX_MOD);
    return 0;
  }
  
  //-- Comprobar que el numero de argumentos totales es correcto
  //-- Debe haber 1 + 4*num_mod + num_mod
  if (argc!=(1+1+4*num_mod + num_mod)) {
    if (verbose)
      printf ("ERROR. Numero de argumentos incorrecto\n");
    return 0;
  }
  
  //-- Leer parametros de los CPGs
  for (int i=0; i<num_mod; i++) {
    worm->cpg_A[i]=atoi(argv[4*i+2]);
    worm->cpg_T[i]=atoi(argv[4*i+3]);
    worm->cpg_F[i]=atoi(argv[4*i+4]);
    worm->cpg_O[i]=atoi(argv[4*i+5]);
    
    //-- El periodo no puede ser 0. Si es asi se pone a 2
    if (worm->cpg_T[i]==0) 
      worm->cpg_T[i]=2;
  }  
  
  //-- Leer la estructura del robot (P=pitch, X=desconectado, Y=yaw)
  int offset=num_mod*4 +2;
  for (int i=offset; i<argc; i++) {
    if (argv[i][0]=='P' || argv[i][0]=='p') 
      worm->estructura[i-offset]=T1D_PITCH;
    else if (argv[i][0]=='Y' || argv[i][0]=='y')
      worm->estructura[i-offset]=T1D_YAW;
    else if (argv[i][0]=='X' || argv[i][0]=='x') 
      worm->estructura[i-offset]=T1D_X;
    else {
      if (verbose)
        printf ("ERROR. Estructura del robot incorrecta\n");
      
      return 0;
    }
  }
  
  //-- Almacenar numero de modulos
  worm->nm=num_mod;
  
  //-- Debug: Imprimir la estructura
  /*
  printf ("DEBUG: ");
  for (int i=0; i<num_mod; i++) {
    if (worm->estructura[i]==T1D_PITCH) 
      printf ("P ");
    else if (worm->estructura[i]==T1D_YAW)
      printf ("Y ");      
    else if (worm->estructura[i]==T1D_X)
      printf ("X ");
    else printf ("Error ");
  }
  
  printf ("\n");
  */
  
  return 1;
}

/*************************************/
/* Pasar una cadena a mayusculas     */
/*************************************/
static void upcase(char *cad)
{
  for (unsigned int i=0; i<strlen(cad); i++) {
    cad[i]=toupper(cad[i]);
  }  
}

/********************************************/
/* Imprimir el tipo de estructura           */
/********************************************/
void T1D_print_structure_type(int estructura)
{
  switch(estructura) {
    case T1D_Pn: 
      printf ("Pn");
      break;
    case T1D_PYn:
      printf ("PYn");
      break;
    default:
      printf ("UNKNOW");
      break;
  }

}


/***************************************************/
/* Obtener el tipo de cromosoma                    */
/***************************************************/
int T1D_get_chromosome_type(char *chromo, int *chromo_type)
{
  upcase(chromo);
  
  if (strcmp(chromo,"T_AV_AH_DFV_DFH_DFVH")==0) {
    *chromo_type=T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh;
    return 1;
    
  }else if (strcmp(chromo,"T_DF_A")==0) {
    *chromo_type=T1D_CHROMO_T_DF_A;
    return 1;
    
  }else if (strcmp(chromo,"RAW")==0) {
    *chromo_type=T1D_CHROMO_RAW;
    return 1; 
    
  }else if (strcmp(chromo,"TI_AI_OI_FI")==0) {
    *chromo_type=T1D_CHROMO_Ti_Ai_Oi_Fi;
    return 1;   
    
  }else {
    return 0;
  }   
}

/********************************************/
/* Imprimir el tipo de cromosoma            */
/********************************************/
void T1D_print_chromosome(int chromo_type)
{
   switch(chromo_type) {
    case T1D_CHROMO_T_Av_Ah_DFv_DFh_DFvh: 
      printf ("T_Av_Ah_DFv_DFh_DFvh");
      break;
    
    case T1D_CHROMO_T_DF_A: 
      printf ("T_DF_A");
      break;
    
    case T1D_CHROMO_RAW: 
      printf ("RAW");
      break;
    
    case T1D_CHROMO_Ti_Ai_Oi_Fi: 
      printf ("Ti_Ai_Oi_Fi");
      break;
    
    default:
      printf ("UNKNOW");
      break;
  }
}

/*********************************************************************/
/* Devolver el tipo de funcion de fitness segun la cadena pasada     */
/*********************************************************************/
int T1D_get_fitness_type(char *fit, int *fit_type)
{
  upcase(fit);
  
  if (strcmp(fit,"DX")==0) {
    *fit_type=T1D_FITNESS_DX;
    return 1;
  }else if (strcmp(fit,"DY")==0) {
    *fit_type=T1D_FITNESS_DY;
    return 1;
  } else if (strcmp(fit,"DL")==0) {
    *fit_type=T1D_FITNESS_DL;
    return 1;    
  }else if (strcmp(fit,"VX")==0) {
    *fit_type=T1D_FITNESS_VX;
    return 1;
  }else if (strcmp(fit,"VY")==0) {
    *fit_type=T1D_FITNESS_VY;
    return 1;
  }else if (strcmp(fit,"YAW")==0) {
    *fit_type=T1D_FITNESS_YAW;
    return 1;
  }else if (strcmp(fit,"ROLL")==0) {
    *fit_type=T1D_FITNESS_ROLL;
    return 1;
  }else if (strcmp(fit,"WYAW")==0) {
    *fit_type=T1D_FITNESS_WYAW;
    return 1;
  }else if (strcmp(fit,"WROLL")==0) {
    *fit_type=T1D_FITNESS_WROLL;
    return 1;
  }else {
    return 0;
  }   
}

/*********************************************/
/* Imprimir el tipo de funcion de fitness    */
/*********************************************/
void T1D_print_fitness_type(int fitness_type)
{
  switch(fitness_type) {
    case T1D_FITNESS_DX: 
      printf ("DX");
      break;
    case T1D_FITNESS_DY:
      printf ("DY");
      break;
    case T1D_FITNESS_DL:
      printf ("DL");
      break;
    case T1D_FITNESS_VX:
      printf ("VX");
      break;
    case T1D_FITNESS_VY:
      printf ("VY");
      break;
    case T1D_FITNESS_YAW:
      printf ("YAW");
      break;
    case T1D_FITNESS_ROLL:
      printf ("ROLL");
      break;
    case T1D_FITNESS_WYAW:
      printf ("W-YAW");
      break;
    case T1D_FITNESS_WROLL:
      printf ("W-ROLL");
      break;
  }
}

/****************************************************************/
/* Devolver el fitness especificado del gusano                  */
/****************************************************************/
dReal T1D_get_fitness(T1D_Robot *worm, int fitness_type) 
{
  dReal fitness_value;
  dReal x,y;
  
  switch(fitness_type) {
    case T1D_FITNESS_DX: 
      fitness_value=worm->xinc_int/worm->intervalo_ciclos;
      break;
    case T1D_FITNESS_DY:
      fitness_value=worm->yinc_int/worm->intervalo_ciclos;
      break;
    case T1D_FITNESS_DL:
      x = worm->xinc_int/worm->intervalo_ciclos;
      y = worm->yinc_int/worm->intervalo_ciclos;
      fitness_value=sqrt(x*x + y*y);
      break;
    case T1D_FITNESS_VX:
      fitness_value=worm->vx_int;
      break;
    case T1D_FITNESS_VY:
      fitness_value=worm->vy_int;
      break;
    case T1D_FITNESS_YAW:
      fitness_value=RTK_TO_GRADOS(worm->yawinc_int/worm->intervalo_ciclos);
      break;
    case T1D_FITNESS_ROLL:
      fitness_value=RTK_TO_GRADOS(worm->rollinc_int/worm->intervalo_ciclos);
      break;
    case T1D_FITNESS_WYAW:
      fitness_value=RTK_TO_GRADOS(worm->wyaw_int);
      break;
    case T1D_FITNESS_WROLL:
      fitness_value=RTK_TO_GRADOS(worm->wroll_int);
      break;
    default:
      printf ("T1D_get_fitness. WARNING: tipo de fitness incorrecto!\n");
      fitness_value=0.0;
  }
  
  return fitness_value;
}
    
    
/**********************************************************/
/* Devolver el tipo de estructura segun la cadena pasada  */
/**********************************************************/
int T1D_get_structure_type(char *structure, int *structure_type)
{
  upcase(structure);
  
  if (strcmp(structure,"PYN")==0) {
    *structure_type=T1D_PYn;
    return 1;
  }else if (strcmp(structure,"PN")==0) {
    *structure_type=T1D_Pn;
    return 1;
  } else if (strcmp(structure,"YN")==0) {
    *structure_type=T1D_Yn;
    return 1;    
  }else {
    return 0;
  }   
}

/****************************************************/
/* Establecer la estructura del robot               */
/****************************************************/
void T1D_set_structure(T1D_Robot *worm, int estructura)
{
   if (estructura==T1D_PYn) {  //-- Estructura PYn
  
    for (int i=0; i<worm->nm; i++) {
      if (i%2==0)
        worm->estructura[i]=T1D_PITCH;
      else
        worm->estructura[i]=T1D_YAW;
    }
  }
  else {   //-- Estructura Pn
    for (int i=0; i<worm->nm; i++) {
        worm->estructura[i]=T1D_PITCH;
    }
  }  
}


/******************************************************************/
/* Crear el robot a partir de la descripcion de su estructura     */
/* ENTRADAS:                                                      */
/*   -cpgs: TRUE: crear las funciones a partir de los cpgs        */
/*          FALSE: No se asignan valores a las funciones          */
/*   -robot_real: TRUE: se usa un robot conectado al puerto serie */
/*                FALSE: No hay robot real                        */
/******************************************************************/
void T1D_new_robot(T1D_Robot *worm, bool cpgs, bool robot_real)
{
  //-- Si no hay robot real, poner la matriz de conexion a 0
  if (!robot_real) {
    for (int i=0; i<=8; i++)
      worm->conexion[i]=0;
  }
  
  //-- Calcular el modulo de referencia: modulo central.
  if (worm->nm%2==0) 
     worm->mod_ref=(worm->nm/2)-1;   //-- Si numero par de modulos
  else 
     worm->mod_ref=(worm->nm-1)/2;   //-- Si numero impar
  
  //-- Crear la cadena
  Rtk_Chain_new(&(worm->cadena));
  
  for (int i=0; i<worm->nm; i++) {
    
    //-- Modulo Y1
    Rtk_Y1Module_new(&(worm->mod[i]));
    
    //-- Asignar servo fisico
    worm->mod[i].servo_real=worm->conexion[i+1];
    
    //-- Puede ser de tipo Pitch o Yaw
    if (worm->estructura[i]==T1D_YAW) {
      worm->mod[i].pitch=0;
      
      //-- Las de tipo Yaw se pintan en rojo
      worm->mod[i].red=1;
      worm->mod[i].green=0;
      worm->mod[i].blue=0;
    }  
    else if (worm->estructura[i]==T1D_PITCH){
      //-- Para las de tipo pitch se usan los colores por defecto
      worm->mod[i].pitch=1;
    }
    else {
      //-- Los deshabilitados se dibujan en blanco
      worm->mod[i].pitch=1;
      worm->mod[i].red=1;
      worm->mod[i].green=1;
      worm->mod[i].blue=1;
    }
    
    //-- BUG: Cuando hay muchos puntos de contactos el simulador peta
    //-- Si el robot comienza a una cierta altura del suelo, le da tiempo
    //-- a adoptar una forma y que haya menos puntos de contacto
    worm->mod[0].zini=0.1;
    
    //-- Generador
    Rtk_Generator_new(&(worm->gen[i]));
    
    //-- Anadir generador al modulo Y1
    Rtk_Y1Module_generator_add(&(worm->mod[i]),&(worm->gen[i]));
    
    //-----------------------------------------------
    //-- Crear las funciones a partir de los CPGs
    //-----------------------------------------------
    if (cpgs) {
      if (worm->estructura[i]==T1D_X) {
        //-- Si es del tipo X, se deshabilita
        Rtk_Sampled_Function_new_from_sine_func(&(worm->sf[i]),
                                           0,   // A
                                           0,   // Fase
                                           0,   // Offset
                                           worm->cpg_T[i]);  // Period
      }  
      else {
        //-- Tipos pitch y yaw no deshabilitados
        Rtk_Sampled_Function_new_from_sine_func(&(worm->sf[i]),
                                           worm->cpg_A[i],   // A
                                           worm->cpg_F[i],   // Fase
                                           worm->cpg_O[i],   // Offset
                                           worm->cpg_T[i]);  // Period
      }
    }  
         
    //-- Asignar la funcion al generador
    Rtk_Generator_set_func(&(worm->gen[i]),&(worm->sf[i]));
    
    //-- Anadir modulo a la cadena
    Rtk_Chain_add(&(worm->cadena), &(worm->mod[i]));
  }
  
  //-- Robot 
  Rtk_Robot_new(&(worm->robot));
  Rtk_Robot_add(&(worm->robot),&(worm->cadena),worm->cadena.type);
  
  /*-----------------------------*/
  /* CREAR EL GRUPO DE ROBOTS    */
  /*-----------------------------*/
  Rtk_Robot_Group_new(&(worm->group));
  Rtk_Robot_Group_add(&(worm->group), &(worm->robot));
  
  /*----------------------------*/
  /* CREAR LA SIMULACION        */
  /*----------------------------*/
  Rtk_Simulation_Engine_new(&(worm->sim));
  
  //-- Anadir los robots a la simulacion
  Rtk_Simulation_Engine_Add(&(worm->sim),&(worm->group),(worm->group.type));
  
  //-- Inicializar todas las variables internas
  worm->timeout=0;
  worm->period_transition= 
    (worm->gen[worm->mod_ref].period_transition) ? true : false;
  worm->period_counter=worm->gen[worm->mod_ref].period_counter;

  worm->vx_ciclo=0.0;
  worm->vy_ciclo=0.0;
  worm->vz_ciclo=0.0;
   
  
  //----------------- INICIALIZAR VARIABLES DE ESTADO --------------------
  worm->t=0;
  
  const dReal *pos;
  pos=dBodyGetPosition(worm->mod[worm->mod_ref].seg[DER].body);
  worm->y= worm->yold = pos[Y]*100;
  worm->x= worm->xold = pos[X]*100;
  worm->z= worm->zold = pos[Z]*100;
  
  worm->xold=worm->x;
  worm->yold=worm->y;
  worm->zold=worm->z;
  
  worm->xinc=0.0;
  worm->yinc=0.0;
  worm->zinc=0.0;
  
  worm->xinc_acum=0.0;
  worm->yinc_acum=0.0;
  worm->zinc_acum=0.0;
  
  //-- Posicion inicial al comienzo del ciclo
  worm->xini = worm->x;
  worm->yini = worm->y;
  worm->zini = worm->z;
  
  //-- Valor maximo de z
  worm->zmax_ciclo=0.0;
  worm->zmax=0.0;
  
  //-- Periodo
  worm->period=0.0;
  
  worm->xinc_ciclo=0.0;
  worm->yinc_ciclo=0.0;
  worm->zinc_ciclo=0.0;
  
  //-- Posiciones angulares instantaneas
  worm->pitch=0.0;
  worm->yaw=0.0;
  worm->roll=0.0;
  
  
  //-- Relacionado con los intervalos
  worm->intervalo_numero=0;
  worm->contador_ciclos=0;
  worm->intervalo_ciclos=1;        //-- Numero de ciclos de un intervalo
  worm->intervalo_duracion=0.0;    //-- Por defecto, el intervalo dura 1 ciclo
  worm->intervalo_tiempo_acum=0.0;
  
  //-- Por defecto, el intervalo empieza en el ciclo 2
  worm->intervalo_ciclo_ini=2;
  
  worm->intervalo_transicion=false;
  
  //-- Posiciones x,y,z al comenzar el intervalo
  worm->xini_int=worm->x;
  worm->yini_int=worm->y;
  worm->zini_int=worm->z;
  
  worm->xinc_int=0.0;
  worm->yinc_int=0.0;
  worm->zinc_int=0.0;
  
  worm->vx_int=0.0;
  worm->vy_int=0.0;
  worm->vz_int=0.0;
  
  worm->t_int=0;
  worm->intervalo_ticks=0;
  
  //-- Inicializar variables de la cinematica angular
  calcular_angulos(worm);
  
  worm->yawold=worm->yaw;
  worm->pitchold=worm->pitch;
  worm->rollold=worm->roll;
  
  worm->yawinc=0.0;
  worm->pitchinc=0.0;
  worm->rollinc=0.0;
  
  worm->yawinc_acum=0.0;
  worm->pitchinc_acum=0.0;
  worm->rollinc_acum=0.0;
  
  worm->yawinc_ciclo=0.0;
  worm->pitchinc_ciclo=0.0;
  worm->rollinc_ciclo=0.0;
  
  worm->yawini=worm->yaw;
  worm->pitchini=worm->pitch;
  worm->rollini=worm->roll;
  
  worm->wyaw=0.0;
  worm->wpitch=0.0;
  worm->roll=0.0;
  
  worm->wyaw_ciclo=0.0;
  worm->wpitch_ciclo=0.0;
  worm->wroll_ciclo=0.0;
  
  worm->yawini_int=worm->yaw;
  worm->pitchini_int=worm->pitch;
  worm->rollini_int=worm->roll;
  
  worm->yawinc_int=0.0;
  worm->pitchinc_int=0.0;
  worm->rollinc_int=0.0;
  
  worm->yawinc_acum_int=0.0;
  worm->pitchinc_acum_int=0.0;
  worm->rollinc_acum_int=0.0;
  
  worm->wyaw_int = 0.0;
  worm->wpitch_int = 0.0;
  worm->wroll_int = 0.0;
  
  worm->volcado=false;
  worm->volcado_ciclo=false;
  
}


static dReal signo(dReal x)
{
  if (x<0.0) return -1.0;
  else return 1.0;
}


/******************************************************/
/* Calcular Yaw, Pitch y Roll                         */
/* Los angulos se devuelven en el intervalo [-90,90]  */
/******************************************************/
static void calcular_angulos(T1D_Robot *worm)
{
  //-- Obtener los angulos de rotacion
  const dReal *q;
 
  //-- Leer el quaternion del modulo de referencia
  q = dBodyGetQuaternion(worm->mod[worm->mod_ref].seg[DER].body);
  
  //-------------------
  //-- Obtener el Roll
  //-------------------
  dReal roll_arg = 2*(q[0]*q[2]-q[3]*q[1]);
  worm->roll=asin(roll_arg);
  
  //-- Comprobar si hay o no singularidad
  if (fabs(roll_arg)<0.999) {
    
    //-- NO HAY SINGULARIDAD
  
    //-- Yaw
   dReal yaw_arg = 2*(q[0]*q[3]+q[1]*q[2])/(1-2*(q[2]*q[2]+q[3]*q[3]));
   worm->yaw=atan(yaw_arg);
  
    //-- Pitch
   dReal pitch_arg = 2*(q[0]*q[1]+q[2]*q[3])/(1-2*(q[1]*q[1]+q[2]*q[2]));
   worm->pitch=atan(pitch_arg);
  }
  else {  // HAY SINGULARIDAD
    //printf ("Singularidad en Roll\n");
    
    /* En este caso no se calculan los angulos pitch y yaw, se     */
    /* mantinen los anteriores, hasta que se pase la singularidad  */    
  }
  
}




/******************************************************************/
/* Realizar un paso de simulacion                                 */
/******************************************************************/
void T1D_step(T1D_Robot *worm)
{
  //-- Almacenar las posiciones del instante actual (t)
  worm->xold=worm->x;
  worm->yold=worm->y;
  worm->zold=worm->z;
  
  //-- Almacenas las posiciones angulares del instante actual (t)
  worm->yawold=worm->yaw;
  worm->pitchold=worm->pitch;
  worm->rollold=worm->roll;
  
  //----------------------------------------
  //-- Incrementar el instante. Pasar a t+1
  //----------------------------------------
  Rtk_Simulation_Engine_step(&(worm->sim));
  
  //-- Incrementar el contador de ticks del ciclo actual
  worm->t++;
  worm->t_int++;
  
  //-----------------------------------------------
  //-- Calculos de la cinematica lineal (x,y,z)
  //-----------------------------------------------
  
  //-- Se puede utilizar bien el modulo de referencia o bien el centro de
  //-- gravedad
  
  //-------------------------------------------------------------
  //-- OPCION 1: MODULO DE REFERENCIA
  //-------------------------------------------------------------
  //-- Leer la nueva posicion en t+1
  const dReal *pos;
  pos=dBodyGetPosition(worm->mod[worm->mod_ref].seg[DER].body);
  worm->y=pos[Y]*100;
  worm->x=pos[X]*100;
  worm->z=pos[Z]*100;
  
  //-------------------------------------------------------
  //-- OPCION 2: CENTRO DE MASAS
  //-------------------------------------------------------
  
  dReal xm,ym,zm;
  const dReal *pos_izq;
  const dReal *pos_der;
  
  worm->y=0;
  worm->x=0;
  worm->z=0;
  
  //-- Recorrer Modulos
  for (int i=0; i<worm->nm; i++) {
    pos_izq=dBodyGetPosition(worm->mod[i].seg[IZQ].body);
    pos_der=dBodyGetPosition(worm->mod[i].seg[DER].body);
    
    
    //-- Calcular Cm del modulo: bloque_izq + bloque_der /2
    xm = (pos_izq[X] + pos_der[X] )/2 *100;
    ym = (pos_izq[Y] + pos_der[Y] )/2 *100;
    zm = (pos_izq[Z] + pos_der[Z] )/2 *100;
    
    //-- Acumular valor..
    worm->x = worm->x + xm;
    worm->y = worm->y + ym;
    worm->z = worm->z + zm;
  }
  
  //-- Calcular las coordenadas del centro de masas final
  worm->x = worm->x/worm->nm;
  worm->y = worm->y/worm->nm;
  worm->z = worm->z/worm->nm;
  
  //-------------------------------------------------------
  
  
  //-- Calcular la z maxima hasta el momento
  if (worm->z > worm->zmax) worm->zmax=worm->z;
  
  //-- Calcular el incremento de posicion: r(t+1) - r(t)
  worm->xinc = worm->x - worm->xold;
  worm->yinc = worm->y - worm->yold;
  worm->zinc = worm->z - worm->zold;
  
  //-- Calcular el incremento acumulado
  worm->xinc_acum+= worm->xinc;
  worm->yinc_acum+= worm->yinc;
  worm->zinc_acum+= worm->zinc;
  
  //---------------------------------------------------------
  //-- Calculos de la cinematica angular (pitch, roll, yaw)
  //---------------------------------------------------------
  
  //-- Obtener los angulos pitch, yaw, roll instantaneos
  calcular_angulos(worm);
  
  //-- Obtener la velocidad angular instantanea
  const dReal *w;
  w = dBodyGetAngularVel (worm->mod[worm->mod_ref].seg[DER].body);
  worm->wyaw=w[Z];
  worm->wroll=w[Y];
  worm->wpitch=w[X];
  
  //-- Calcular el incremento angular ang(t+1) - ang(t)
  dReal dif_yaw;
  dif_yaw = worm->yaw - worm->yawold;
  
  //-- Hay que tener en cuenta las DISCONTINUIDADES. Por ejemplo, en el 
  //-- caso del angulo yaw, hay saltos desde -90 a 90
  //-- Tomaremos como criterio que ha ocurrido una discontinuidad si el salto
  //-- es mayor de 90, lo cual no es posible porque solo ha transcurrido un
  //-- tick de simulacion
  if (fabs(dif_yaw)>M_PI/2) {
    
    //-- Cuando hay discontinuidad el incremento se calcula sumando de
    //-- esta manera. El signo lo determina la velocidad angular
    worm->yawinc = signo(worm->wyaw)*fabs(M_PI/2-fabs(worm->yaw)+ 
                                    M_PI/2 - fabs(worm->yawold));
  }
  else
    worm->yawinc = dif_yaw;
  
  //-- Calcular el incremento angular acumulado hasta el momento
  worm->yawinc_acum += worm->yawinc;
  
  //-- En el caso del roll no hay discontinuidades. Si se rota una vuelta 
  //-- completa, los angulos varian desde 0 a -90, luego a 0, a 90 y
  //-- finalmente a 0. Lo unico que hay que tener en cuenta es el que
  //-- el signo del incremento angular no implica que se mueva hacia un
  //-- sentido u otro
  worm->rollinc= -signo(worm->wroll)*fabs(worm->roll - worm->rollold);
  worm->rollinc_acum += worm->rollinc;
  
  //-- POR HACER: Discontinuidades en PITCH!
  
  //-- Calcular el incremento angular pitch y el acumulado hasta el momento
  worm->pitchinc=worm->pitch - worm->pitchold;
  worm->pitchinc_acum += worm->pitchinc;
  
  //-- Calcular los pasos angulares acumulados
  worm->yawinc_acum_int+= worm->yawinc;
  worm->rollinc_acum_int+=worm->rollinc;
  worm->pitchinc_acum_int+=worm->pitchinc;
  
  //-- Comprobar el "volcado"
  if (fabs(worm->rollinc_acum)>M_PI/4) worm->volcado=true;
  //printf ("roll: %.2f\n",worm->rollinc_acum);
  
  //-- Comprobar si se ha superado el periodo maximo permitido
  //-- Si es asi, indicarlo
  //if (worm->t>=T1D_TICKS_TIMEOUT)
  if ( (worm->t*worm->sim.step)>T1D_T_TIMEOUT_SEG)
    worm->timeout=1;
  
  //-- Actualizar flag de transicion
  worm->period_transition= 
    (worm->gen[worm->mod_ref].period_transition) ? true : false;
  
  //-- Actualizar contador de periodos
  worm->period_counter=worm->gen[worm->mod_ref].period_counter;
  
  //-- Valor por defecto de la transicion entre intervalos
  worm->intervalo_transicion=false;
  
  //-------------------------------------------------------------------
  //-- Calculos a realizar cada vez que se comienza un periodo nuevo 
  //-------------------------------------------------------------------
  //-- NOTA: Se utiliza el generador del modulo de referencia
  if (worm->period_transition) {
      
    //-- Calcular el periodo del ciclo que ha terminado
    worm->period=worm->t*worm->sim.step;
    
    //-- Poner el tiempo de ciclo a 0
    worm->t=0;
    
    //-- Calcular los pasos medios por ciclo
    worm->yinc_ciclo= worm->y - worm->yini;
    worm->xinc_ciclo= worm->x - worm->xini;
    worm->zinc_ciclo= worm->z - worm->zini;
    
    //-- Almacenar la posicion al comienzo del nuevo ciclo
    worm->xini = worm->x;
    worm->yini = worm->y;
    worm->zini = worm->z;
    
    //-- Calcular las velocidades lineales medias por ciclo
    worm->vx_ciclo = worm->xinc_ciclo / worm->period;
    worm->vy_ciclo = worm->yinc_ciclo / worm->period;
    worm->vz_ciclo = worm->zinc_ciclo / worm->period;
    
     //-- Poner a cero el paso acumulado
    worm->xinc_acum=0.0;
    worm->yinc_acum=0.0;
    worm->zinc_acum=0.0;
    

    //-- Calcular los pasos medios angulares
    worm->yawinc_ciclo=worm->yawinc_acum;
    worm->rollinc_ciclo=worm->rollinc_acum;
    worm->pitchinc_ciclo=worm->pitchinc_acum;
    
    //-- Calcular las velocidades angulares medias por ciclo
    worm->wyaw_ciclo= worm->yawinc_ciclo / worm->period;
    worm->wpitch_ciclo = worm->pitchinc_ciclo / worm->period;
    worm->wroll_ciclo = worm->rollinc_ciclo / worm->period;
    
    //-- Acumulador de incrementos a cero
    worm->yawinc_acum=0.0;
    worm->rollinc_acum=0.0;
    worm->pitchinc_acum=0.0;
    
    //-- Almacenar la posicion angular al comienzo de un nuevo ciclo
    worm->yawini=worm->yaw;
    worm->pitchini=worm->pitch;
    worm->rollini=worm->roll;
    
    //-- Actualizar flag de "volcado"
    if (worm->volcado) worm->volcado_ciclo=true;
    else worm->volcado_ciclo=false;
      
    //-- Poner flag de volcado a false al comienzo de cada ciclo
    worm->volcado=false;
    
    //-- Almacenar valor de zmax
    worm->zmax_ciclo=worm->zmax;
    
    //-- Poner zmax a 0
    worm->zmax=0.0;
    
    //-- Calcular los pasos acumulados en el intervalo actual
    //worm->yawinc_acum_int+= worm->yawinc_ciclo;
    //worm->pitchinc_acum_int+= worm->pitchinc_ciclo;
    //worm->rollinc_acum_int+= worm->rollinc_ciclo;
    
    //-------------------- CALCULOS DEL INTERVALO ---------------------------
    //-- Incrementar contador de ciclos
    worm->contador_ciclos++;
    
    //-- Actualizar el tiempo acumulado
    worm->intervalo_tiempo_acum+=worm->period;
    
    //-- Si es un intervalo nuevo, bien porque sea el primero o cualquier
    //-- otro...
    if (worm->contador_ciclos==worm->intervalo_ciclo_ini
        && worm->intervalo_numero==0 ||
        worm->contador_ciclos==worm->intervalo_ciclos
        && worm->intervalo_numero>0) {
      
      //-- Guardar el tiempo de intervalo en ticks
      //-- y poner el tiempo de intervalo a 0
      worm->intervalo_ticks=worm->t_int;
      worm->t_int=0;    
          
      //-- Inicializar contador de ciclos          
      worm->contador_ciclos=0;
          
      //-- Incrementar numero de intervalo
      worm->intervalo_numero++;
          
      //-- Senalizar que ha habido una transicion    
      worm->intervalo_transicion=true;
          
      //-- Calcular el tiempo del intervalo
      //-- Calcular el periodo del ciclo que ha terminado
      worm->intervalo_duracion=worm->intervalo_tiempo_acum;
      worm->intervalo_tiempo_acum=0.0;          
      
      //-- Calcular los pasos medios por intervalo
      worm->yinc_int= worm->y - worm->yini_int;
      worm->xinc_int= worm->x - worm->xini_int;
      worm->zinc_int= worm->z - worm->zini_int;
    
      //-- Almacenar la posicion al comienzo del nuevo intervalo
      worm->xini_int = worm->x;
      worm->yini_int = worm->y;
      worm->zini_int = worm->z;

      //-- Calcular las velocidades lineales medias del intervalo
      worm->vx_int = worm->xinc_int / worm->intervalo_duracion;
      worm->vy_int = worm->yinc_int / worm->intervalo_duracion;
      worm->vz_int = worm->zinc_int / worm->intervalo_duracion;
      
      //-- Calculas los pasos angulares medios por intervalo
      worm->yawinc_int = worm->yawinc_acum_int;
      worm->pitchinc_int = worm->pitchinc_acum_int;
      worm->rollinc_int = worm->rollinc_acum_int;
      
      //-- Inicializar acumulador de pasos angulares
      worm->yawinc_acum_int= 0.0;
      worm->pitchinc_acum_int= 0.0;
      worm->rollinc_acum_int= 0.0;
      
      //-- Calcular la velocidad angular media del intervalo
      worm->wyaw_int= worm->yawinc_int / worm->intervalo_duracion;
      worm->wpitch_int = worm->pitchinc_int / worm->intervalo_duracion;
      worm->wroll_int  = worm->rollinc_int / worm->intervalo_duracion;
      
      //-- Almacenas la posicion angular al comienzo del intervalo
      worm->yawini = worm->yaw;
      worm->rollini = worm->roll;
      worm->pitchini = worm->pitch;
      
    }
    
  }  
  
}


/**********************************************************/
/* Generar un fichero para octave                         */
/**********************************************************/
void T1D_file_octave_data(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel)   //-- Etiqueta eje Y
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  fprintf (fd,"#!/usr/bin/octave\n");
  
  //-- Datos del primer servo
  fprintf (fd,"y=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%f,",buf1[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(worm->intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('%s')\n",titulo);
  fprintf (fd,"xlabel('%s')\n",xlabel);
  fprintf (fd,"ylabel('%s')\n",ylabel);
  fprintf (fd,"axis([0,%d])\n",worm->intervalo_ticks);
  fprintf (fd,"plot(t,y,';1;');\n");
  fprintf (fd,"pause;\n");
  
  fclose(fd); 
  
  printf ("----> Fichero %s creado!!!\n",fich);
}

void T1D_file_octave_data3(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          dReal buf3[],   //-- Buffer de datos 3
                          char *name3,    //-- Nombre de los datos 3
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel)   //-- Etiqueta eje Y
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  fprintf (fd,"#!/usr/bin/octave\n");
  
  //-- Primera funcion
  fprintf (fd,"y1=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%f,",buf1[i]);
  fprintf (fd,"];\n");
  
  //-- Segunda funcion
  fprintf (fd,"y2=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%f,",buf2[i]);
  fprintf (fd,"];\n");
  
  //-- Tercera funcion
  fprintf (fd,"y3=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%f,",buf3[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(worm->intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('%s')\n",titulo);
  fprintf (fd,"xlabel('%s')\n",xlabel);
  fprintf (fd,"ylabel('%s')\n",ylabel);
  fprintf (fd,"axis([0,%d])\n",worm->intervalo_ticks);
  fprintf (fd,"plot(t,y1,';%s;',t,y2,';%s;',t,y3,';%s;');\n",name1,name2,name3);
  fprintf (fd,"pause;\n");
  
  fclose(fd); 
  
  printf ("----> Fichero %s creado!!!\n",fich);
  
}

void T1D_file_octave_data2(T1D_Robot *worm,
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel)   //-- Etiqueta eje Y
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  fprintf (fd,"#!/usr/bin/octave\n");
  //-- Primera funcion
  fprintf (fd,"y1=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%.2f,",buf1[i]);
  fprintf (fd,"];\n");
  
  //-- Segunda funcion
  fprintf (fd,"y2=[");
  
  for (int i=0; i<worm->intervalo_ticks; i++)
     fprintf (fd,"%.2f,",buf2[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[0:1:%d];\n",(worm->intervalo_ticks-1));
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('%s')\n",titulo);
  fprintf (fd,"xlabel('%s')\n",xlabel);
  fprintf (fd,"ylabel('%s')\n",ylabel);
  fprintf (fd,"axis([0,%d])\n",worm->intervalo_ticks);
  fprintf (fd,"plot(t,y1,';%s;',t,y2,';%s;');\n",name1,name2);
  fprintf (fd,"pause;\n");
  
  fclose(fd); 
  
  printf ("----> Fichero %s creado!!!\n",fich);
  
}

void T1D_file_octave_data2(int ini,       //-- Indice inicial
                           int fin,       //-- Indice final
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          dReal buf2[],   //-- Buffer de datos 2
                          char *name2,    //-- Nombre de los datos 2
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel)   //-- Etiqueta eje Y
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  fprintf (fd,"#!/usr/bin/octave\n");
  //-- Primera funcion
  fprintf (fd,"y1=[");
  
  for (int i=ini; i<=fin; i++)
     fprintf (fd,"%.2f,",buf1[i]);
  fprintf (fd,"];\n");
  
  //-- Segunda funcion
  fprintf (fd,"y2=[");
  
  for (int i=ini; i<=fin; i++)
     fprintf (fd,"%.2f,",buf2[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[%d:1:%d];\n",ini,fin);
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('%s')\n",titulo);
  fprintf (fd,"xlabel('%s')\n",xlabel);
  fprintf (fd,"ylabel('%s')\n",ylabel);
  fprintf (fd,"axis([%d,%d])\n",ini,fin);
  fprintf (fd,"plot(t,y1,';%s;',t,y2,';%s;');\n",name1,name2);
  fprintf (fd,"pause;\n");
  
  fclose(fd); 
  
  printf ("----> Fichero %s creado!!!\n",fich);
  
}

void T1D_file_octave_data(int ini,       //-- Indice inicial
                          int fin,       //-- Indice final
                          char fich[],    //-- Nombre de fichero
                          dReal buf1[],   //-- Buffer de datos 1
                          char *name1,    //-- Nombre de los datos 1
                          char *titulo,   //-- Titulo
                          char *xlabel,   //-- Etiqueta eje X
                          char *ylabel)   //-- Etiqueta eje Y
{
  FILE *fd;
  
  fd = fopen(fich,"w");
  fprintf (fd,"#!/usr/bin/octave\n");
  //-- Primera funcion
  fprintf (fd,"y1=[");
  
  for (int i=ini; i<=fin; i++)
     fprintf (fd,"%f,",buf1[i]);
  fprintf (fd,"];\n");
  
  //-- Generar parte final
  fprintf (fd,"t=[%d:1:%d];\n",ini,fin);
  fprintf (fd,"grid on;\n");
  fprintf (fd,"title('%s')\n",titulo);
  fprintf (fd,"xlabel('%s')\n",xlabel);
  fprintf (fd,"ylabel('%s')\n",ylabel);
  fprintf (fd,"axis([%d,%d])\n",ini,fin);
  fprintf (fd,"plot(t,y1,';%s;');\n",name1);
  fprintf (fd,"pause;\n");
  
  fclose(fd); 
  
  printf ("----> Fichero %s creado!!!\n",fich);
  
}
