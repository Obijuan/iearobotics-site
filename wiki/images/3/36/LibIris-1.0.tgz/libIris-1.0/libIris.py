#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: File downloader library for SkyPIC
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys, serial, time, urllib2

#############
# CONSTANTS #
#############

VERSION = '1.0'

############################
# TIMEOUT VALUES (seconds) #
############################

TIMEOUT_IDENT = 0.1
TIMEOUT_WRITING = 0.3

#################
# URL CONSTANTS #
#################

URL_BASE = 'http://www.iearobotics.com/proyectos/stargate/servidores/'
URL_DICT = {'sg-echo' : 'sg-echo-pic16F876A-skypic-0-BOOT.hex',
		'sg-generic' : 'sg-generic-pic16f876a-skypic-0-BOOT.hex',
		'sg-null' : 'sg-null-pic16F876A-skypic-0-BOOT.hex',
		'sg-picp' : 'sg-picp-pic16f876-skypic-0.hex', # Non-Skypic
		'sg-servos8' : 'sg-servos8-pic16f876-skypic.hex'}

class ReaderError (Exception):
	pass

class HexReader:

	# Read a program from fd and return its contents
	def readHex (self, fd):
		# Read file
		lines = fd.readlines ()
		fd.close ()

		# Init variables
		prog = []

		for line in lines:
			if line [0] != ':':
				raise ReaderError, 'Bad HEX file format.'

			count = int (line [1:3], 16)
			addr = int (line [3:7], 16) / 2
			rectype = int (line [7:9], 16)

			if rectype == 1:
				return prog

			if rectype > 1:
				raise ReaderError, 'Can\'t handle %X record type.' % rectype

			for loop in xrange (0, count / 2):
				data = (int (line [11 + 4 * loop: 13 + 4 * loop], 16),
						int (line [9 + 4 * loop: 11 + 4 * loop], 16))
				if data [0] > 0x3F:
					raise ReaderError, 'Bad HEX file format.'
				prog.append ((addr, data))
				addr += 1

		raise ReaderError, 'Bad HEX file format.'
		
class IrisError (Exception):
	pass

class Iris:

	def __init__ (self, serialName, serial = None):
		self.__serialName = serialName
		self.__serial = serial
		self.__managed = False
		self.__baudrate = None
		if self.__serial:
			self.__managed = True
			self.__baudrate = self.__serial.baudrate
	
	def __openSerial (self):
		# Open and serial port
		try:
			self.__serial = serial.Serial (self.__serialName, 38400)
		except serial.SerialException:
			raise IrisError, 'Unable to open %s port.' % self.__serialName

		# Empty buffers
		self.__serial.flushInput ()
		self.__serial.flushOutput ()

		print 'Serial port %s opened.' % self.__serialName
	
	def __skypicReset (self):
		self.__serial.setDTR (0)
		time.sleep (0.5)
		self.__serial.setDTR (1)

	def __identBootloader (self):
		# Configure Port
		self.__serial.timeout = TIMEOUT_IDENT

		print 'Identifing bootloader. (press skypic reset button if hangs)'

		# Timeout or bad reply
		for i in xrange (60):
			
			# Send identification
			self.__serial.write ('\xEA')
		
			# Wait reply
			id = self.__serial.read (1)
			
			self.__serial.flushOutput ()

			if len (id) == 1 and id == '\xEB':
				break
		else:
			raise IrisError, 'Bootloader not identified.'

	def __write (self, prog):
		sys.stdout.write ('Writing... ')
		sys.stdout.flush ()

		self.__serial.timeout = TIMEOUT_WRITING

		#-- Writting algorithm: 
		#--  1)	Find contiguous blocks with length less or equal to 0
		#--  2) Write the block
		
		while len (prog):

			data = []
			
			# Initial address and data
			address, (d0, d1) = prog [0]
			
			data.append (d0)
			data.append (d1)

			a = address

			# Find the next contiguous block with a
			# length less or equal to 32 words (16 double-words)
			for i in xrange (1, 16):
				try:
					b, (d0, d1) = prog [i]
				except IndexError:
					break
				if a + 1 == b:
					data.append (d0)
					data.append (d1)
					a = b
				else:
					break;

			count = len (data)
			del prog [:count / 2]

			# Calcule the checksum
			chk = sum (data)
			
			#print 'address: %x %x' % (address >> 8, address & 0xFF)
			
			# Write down!
			self.__serial.write ('\xE3')
			self.__serial.write ('%c%c' % (chr (address >> 8 & 0xFF), chr (address & 0xFF)))
			self.__serial.write (chr (count & 0xFF))
			self.__serial.write (chr (chk & 0xFF))
			for d in data:
				self.__serial.write (chr (d))
				# sys.stdout.write ('%X ' % d);

			# Wait reply (data ok?)
			ch = self.__serial.read (1)
			if ch != '\xE7':
				raise IrisError, 'Data error.'

			# Wait reply (write ok?)
			ch = self.__serial.read (1)
			if ch != '\xE4':
				raise IrisError, 'Write error.'

		print 'OK'

	def __sendDone (self):
		sys.stdout.write ('Activating program... ')

		# Write Done
		self.__serial.write ('\xED')
		
		# Wait reply
		ch = self.__serial.read (1)
		if ch != '\xE4':
			raise IrisError, 'Done Error'
		print 'OK'
		
	def download (self, file):
		fd = None
		try:
			fd = open (file)
		except IOError:
			url = URL_DICT.get (file, None)
			if url:
				file = '%s%s%s%s' % (URL_BASE, file, '/download/', url)
				
			try:
				fd = urllib2.urlopen (file)
			except ValueError, URLError:
				raise IrisError, 'Invalid filename or url "%s".' % file
			
			print 'File from "%s" opened.' % file
		else:
			print 'File "%s" opened.' % file
		
		if self.__managed:
			self.__serial.baudrate = 38400
		else:
			self.__openSerial ()
		try:
			self.__skypicReset ()
			self.__identBootloader ()
			hr = HexReader ()
			self.__write (hr.readHex (fd))
			self.__sendDone ()
		except IrisError:
			if self.__managed:
				self.__serial.baudrate = self.__baudrate
			else:
				self.__serial.close ()
				self.__serial = None
			raise
		else:
			if self.__managed:
				self.__serial.baudrate = self.__baudrate
			else:
				self.__serial.close ()
				self.__serial = None
