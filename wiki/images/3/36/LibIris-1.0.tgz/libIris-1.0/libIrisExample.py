#!/usr/bin/env python
# -*- coding: iso-8859-15 -*-

# Description: Example of use of libIris
# Copyright (C) 2007 by Rafael Treviño Menéndez
# Author: Rafael Treviño Menéndez <skasi.7@gmail.com>

# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU Library General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Library General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

import sys
import libIris

if __name__ == '__main__':
	# Initial message
	print 'Stargate Iris %s. Download programs to Skypic board.' % libIris.VERSION
	print 'GPL license\n'
	
	# Parameter analisys
	try:
		file = sys.argv [1]
		serialName = sys.argv [2]
	except IndexError:
		print 'Use: %s <file | url | server type> <port>' % sys.argv [0]
		print 'server types: {%s}' % (' | '.join ([k for k, v in libIris.URL_DICT.iteritems ()]))
		sys.exit (-1)

	# Verbose output
	print 'File: "%s"' % file
	print 'Serial port: %s\n' % serialName

	# Main thing
	iris = libIris.Iris(serialName)

	# Check for errors (can be ommited)
	try:
		iris.download (file)
	except:
		print 'Download failed.'
