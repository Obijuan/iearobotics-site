import os, sys, time, pygame
sys.path = ['./pywii'] + sys.path
from pywii import Wiimote
from wiicon import WiiconError

class WiiView:

	def __init__ (self, width, height):
		self.__width = width
		self.__height = height
		self.__state = 1

		self.__wiimote = Wiimote ()
	
	def __drawBackground (self):
		sx, sy = (self.__width - 10, self.__height - 10)

		bg = pygame.Surface (self.__screen.get_size ()).convert ()
		pygame.draw.aaline (bg, (255, 255, 255), (10, 10), (10, sy))
		pygame.draw.aaline (bg, (255, 255, 255), (10, sy), (sx, sy))

		self.__background = bg
	
	def start (self, address):
		try:
			self.__wiimote.start (address)
		except WiiconError:
			print 'Error al iniciar servicio Bluetooth'
			sys.exit (-1)

		print 'Pulsa Home para salir'

		pygame.init ()
		pygame.display.set_caption ('wiiview')

		self.__screen = pygame.display.set_mode ((self.__width, self.__height))
		self.__drawBackground ()

	def __drawVector (self, v, c):
		sx, sy = (self.__width / 2, self.__height / 2)
		pygame.draw.aaline (self.__screen, c, (sx, sy), (sx + 100 * v.y, sy + 100 * v.z))

	def mainLoop (self):
		while self.__state:
			for ev in pygame.event.get ():
				if ev.type == pygame.QUIT:
					self.__state = 0
					break

			for ev in self.__wiimote.getEvents ():
				if ev.type == 'Motion':
					self.__screen.blit (self.__background, (0, 0))
					self.__drawVector (ev.data, (255, 255, 255))
					# print 'Motion event:', ev.data
			
				elif ev.type == 'ButtonPress':
					print 'Button press event', ev.data
					if ev.data == 'Home':
						self.__state = 0
						break
			
				elif ev.type == 'ButtonRelease':
					print 'Button release event', ev.data

			pygame.display.flip ()
			time.sleep (0.01)

		self.__wiimote.stop ()


if __name__ == '__main__':
	wiiview = WiiView (640, 480)

	try:
		wiiview.start (sys.argv [1])
	except IndexError:
		print 'Uso: %s <address>' % sys.argv [0]
		sys.exit (-1)
	
	wiiview.mainLoop ()
