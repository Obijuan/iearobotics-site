// Libreria interfaz

int llamada_status_driver();
int llamada_read_driver(int pos);
int llamada_write_driver(int pos, int valor);