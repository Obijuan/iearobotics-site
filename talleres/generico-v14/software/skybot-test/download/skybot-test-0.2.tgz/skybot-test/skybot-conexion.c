/**********************************************************************/
/* skybot-conexion.c      Juan Gonzalez Gomez.   Julio 2005          */
/*--------------------------------------------------------------------*/
/* Ejemplo de prueba para comprobar la conexion serie con el Skybot.  */
/* Debe estar grabado el skybot-monitor.hex en la skypic              */
/* Si todo es correcto, aparecera una barrita que dara vueltas        */
/* mientras haya conexion                                             */
/*--------------------------------------------------------------------*/
/* Licencia GPL                                                       */
/**********************************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stargate/stargate.h>

#include "consola_io.h"
#include "animatxt.h"

/*****************************/
/*    FUNCIONES              */
/*****************************/

/********************************/
/* Identificacion del servidor  */
/********************************/
int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}


/********************************************************/
/* Bucle principal. Esta constantemente haciendo PINGs  */
/********************************************************/
void principal(void)
{
  char c;
  int status;

  printf ("Pulse ESC para terminar\n");
  
  //-- Esperar hasta que se pulse ESC
  do {
    //-- Ha pulsado el usuario una tecla?
		if (consola_io_kbhit()) {
      
      //-- Si, leerla 
			c=consola_io_getch();
		}	
		else {	
      //-- Hacer un ping
      status=sg_ping();
      
      //-- Si hay respuesta del ping: todo ok. Animar la barrita
      if (status==1) {
        animatxt_barra_print();
        usleep(50000);
      }
      else {  //-- No hay conexion
        printf ("Conexion perdida!\n");
        usleep(500000);
      }
        
		}
  } while (c!=27);
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Prueba de conexion con el SKYBOT\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexi�n establecida\n");
  else printf ("Conexi�n NO establecida\n");

}

/***********************/
/* PROGRAMA PRINCIPAL  */
/***********************/
int main (void)
{
  int serial_fd;  /*-- Descriptor puerto serie */

  //-- Configurar la consola
  consola_io_open();
  
  //-- Inicializar animacion de la barrita que rota
  animatxt_barra_init();

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open("/dev/ttyS0");

  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  inicio();
  
  //-- Programa principal
  principal();

  //-- Consola a su estado inicial
  consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
