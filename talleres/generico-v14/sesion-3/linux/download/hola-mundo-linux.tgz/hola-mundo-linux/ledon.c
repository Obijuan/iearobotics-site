/*
Ejemplo de programaci�n del Skybot 
usando la libreria_skybot

Ejemplo1:
Al apretar el Pulsador el LED se enciende

Julio-2007
*/

#include "libreria_skybot.h"

//----------------------------
//- Comienzo del programa  
//----------------------------

void main(void)
{
  ConfigurarSkybot();  EncenderLed();
  while(1);
}
