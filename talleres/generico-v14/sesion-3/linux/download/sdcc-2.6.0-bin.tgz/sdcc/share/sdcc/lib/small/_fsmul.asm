;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:54 2006
;--------------------------------------------------------
	.module _fsmul
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_fsmul.c:27: static void dummy(void) _naked
;	-----------------------------------------
;	 function dummy
;	-----------------------------------------
_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_fsmul.c:188: mul	ab			// r4 * r7
;	genInline
	        .globl ___fsmul
___fsmul:
	        lcall fsgetargs
	        cjne r4, #0, 00002$
00001$:
	        ljmp fs_return_zero
00002$:
	        mov a, r7
	        jz 00001$
	        jnb psw.5, 00003$
	        cpl psw.1
00003$:
	        mov a, dph
	        cjne a, #0xFF, 00004$
	        ljmp fs_return_inf
00004$:
	        mov a, dpl
	        cjne a, #0xFF, 00005$
	        ljmp fs_return_inf
00005$:
	        add a, dph
	        jc 00006$
	        add a, #130
	        jc 00007$
	        ljmp fs_return_zero
00006$:
	        add a, #131
	        dec a
	        jnc 00007$
	        ljmp fs_return_inf
00007$:
	        mov dpl, a
;	# 94 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_fsmul.c"
	        mov a, r2
	        mov b, r5
	        mul ab
	        mov r0, b
	        mov a, r2
	        mov b, r6
	        mul ab
	        add a, r0
	        mov r0, a
	        clr a
	        addc a, b
	        mov r1, a
	        mov a, r3
	        mov b, r5
	        mul ab
	        add a, r0
	        mov a, r1
	        addc a, b
	        mov r1, a
	        clr a
	        rlc a
	        xch a, r2
	        mov b, r7
	        mul ab
	        add a, r1
	        mov r1, a
	        mov a, r2
	        addc a, b
	        mov r2, a
	        mov a, r3
	        mov r0, a
	        mov b, r6
	        mul ab
	        add a, r1
	        mov r1, a
	        mov a, r2
	        addc a, b
	        mov r2, a
	        clr a
	        rlc a
	        mov r3, a
	        mov a, r4
	        mov b, r5
	        mul ab
	        add a, r1
	        mov r1, a
	        mov a, r2
	        addc a, b
	        mov r2, a
	        clr a
	        addc a, r3
	        mov r3, a
	        mov a, r0
	        mov b, r7
	        mul ab
	        add a, r2
	        mov r2, a
	        mov a, r3
	        addc a, b
	        mov r3, a
	        clr a
	        rlc a
	        xch a, r4
	        mov r5, a
	        mov b, r6
	        mul ab
	        add a, r2
	        mov r2, a
	        mov a, r3
	        addc a, b
	        mov r3, a
	        clr a
	        addc a, r4
	        mov r4, a
	        mov a, r5
	        mov b, r7
	        mul ab
	        add a, r3
	        mov r3, a
	        mov a, r4
	        addc a, b
	        mov r4, a
	        jb acc.7, 00010$
	        lcall fs_normalize_a
00010$:
	        ljmp fs_round_and_return
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
