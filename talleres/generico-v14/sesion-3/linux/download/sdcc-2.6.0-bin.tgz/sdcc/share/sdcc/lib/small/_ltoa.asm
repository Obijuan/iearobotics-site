;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:55 2006
;--------------------------------------------------------
	.module _ltoa
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __ltoa
	.globl __ultoa
	.globl __ltoa_PARM_3
	.globl __ltoa_PARM_2
	.globl __ultoa_PARM_3
	.globl __ultoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__ultoa_PARM_2:
	.ds 3
__ultoa_PARM_3:
	.ds 1
__ultoa_value_1_1:
	.ds 4
__ultoa_buffer_1_1:
	.ds 32
__ultoa_sloc0_1_0:
	.ds 4
__ltoa_PARM_2:
	.ds 3
__ltoa_PARM_3:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_ultoa'
;------------------------------------------------------------
;string                    Allocated with name '__ultoa_PARM_2'
;radix                     Allocated with name '__ultoa_PARM_3'
;value                     Allocated with name '__ultoa_value_1_1'
;index                     Allocated to registers r4 
;buffer                    Allocated with name '__ultoa_buffer_1_1'
;sloc0                     Allocated with name '__ultoa_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:18: void _ultoa(unsigned long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ultoa
;	-----------------------------------------
__ultoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	__ultoa_value_1_1,dpl
	mov	(__ultoa_value_1_1 + 1),dph
	mov	(__ultoa_value_1_1 + 2),b
	mov	(__ultoa_value_1_1 + 3),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:25: do {
;	genAssign
	mov	r4,#0x20
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:26: buffer[--index] = '0' + (value % radix);
;	genMinus
;	genMinusDec
	dec	r4
;	genPlus
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	add	a,#__ultoa_buffer_1_1
	mov	r0,a
;	genCast
	mov	__ultoa_sloc0_1_0,__ultoa_PARM_3
	mov	(__ultoa_sloc0_1_0 + 1),#0x00
	mov	(__ultoa_sloc0_1_0 + 2),#0x00
	mov	(__ultoa_sloc0_1_0 + 3),#0x00
;	genAssign
	mov	__modulong_PARM_2,__ultoa_sloc0_1_0
	mov	(__modulong_PARM_2 + 1),(__ultoa_sloc0_1_0 + 1)
	mov	(__modulong_PARM_2 + 2),(__ultoa_sloc0_1_0 + 2)
	mov	(__modulong_PARM_2 + 3),(__ultoa_sloc0_1_0 + 3)
;	genCall
	mov	dpl,__ultoa_value_1_1
	mov	dph,(__ultoa_value_1_1 + 1)
	mov	b,(__ultoa_value_1_1 + 2)
	mov	a,(__ultoa_value_1_1 + 3)
	push	ar4
	push	ar0
	lcall	__modulong
	mov	r7,dpl
	mov	r6,dph
	mov	r2,b
	mov	r3,a
	pop	ar0
	pop	ar4
;	genCast
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
;	genPointerSet
;	genNearPointerSet
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00117$
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	genPointerSet
;	genNearPointerSet
	mov	@r0,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:28: value /= radix;
;	genAssign
	mov	__divulong_PARM_2,__ultoa_sloc0_1_0
	mov	(__divulong_PARM_2 + 1),(__ultoa_sloc0_1_0 + 1)
	mov	(__divulong_PARM_2 + 2),(__ultoa_sloc0_1_0 + 2)
	mov	(__divulong_PARM_2 + 3),(__ultoa_sloc0_1_0 + 3)
;	genCall
	mov	dpl,__ultoa_value_1_1
	mov	dph,(__ultoa_value_1_1 + 1)
	mov	b,(__ultoa_value_1_1 + 2)
	mov	a,(__ultoa_value_1_1 + 3)
	push	ar4
	lcall	__divulong
	mov	__ultoa_value_1_1,dpl
	mov	(__ultoa_value_1_1 + 1),dph
	mov	(__ultoa_value_1_1 + 2),b
	mov	(__ultoa_value_1_1 + 3),a
	pop	ar4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:29: } while (value != 0);
;	genCmpEq
;	gencjneshort
	mov	a,__ultoa_value_1_1
	jnz	00118$
	mov	a,(__ultoa_value_1_1 + 1)
	jnz	00118$
	mov	a,(__ultoa_value_1_1 + 2)
	jnz	00118$
	mov	a,(__ultoa_value_1_1 + 3)
;	Peephole 160.c	removed sjmp by inverse jump logic
	jz	00119$
00118$:
	ljmp	00103$
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:31: do {
;	genAssign
	mov	ar2,r4
;	genAssign
	mov	r3,__ultoa_PARM_2
	mov	r4,(__ultoa_PARM_2 + 1)
	mov	r5,(__ultoa_PARM_2 + 2)
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:32: *string++ = buffer[index++];
;	genAssign
	mov	ar6,r2
;	genPlus
;     genPlusIncr
	inc	r2
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,#__ultoa_buffer_1_1
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar6,@r0
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r6
	lcall	__gptrput
	inc	dptr
	mov	r3,dpl
	mov	r4,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:33: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt
;	genCmp
	cjne	r2,#0x20,00120$
00120$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00106$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:35: *string = 0;  /* string terminator */
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__gptrput
;
;------------------------------------------------------------
;Allocation info for local variables in function '_ltoa'
;------------------------------------------------------------
;string                    Allocated with name '__ltoa_PARM_2'
;radix                     Allocated with name '__ltoa_PARM_3'
;value                     Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:38: void _ltoa(long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ltoa
;	-----------------------------------------
__ltoa:
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:40: if (value < 0 && radix == 10) {
;	genCmpLt
;	genCmp
	mov	r5,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00102$
;	Peephole 300	removed redundant label 00108$
;	genCmpEq
;	gencjneshort
	mov	a,__ltoa_PARM_3
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	a,#0x0A,00102$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00109$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:41: *string++ = '-';
;	genAssign
	mov	r6,__ltoa_PARM_2
	mov	r7,(__ltoa_PARM_2 + 1)
	mov	r0,(__ltoa_PARM_2 + 2)
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	__ltoa_PARM_2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	mov	(__ltoa_PARM_2 + 1),a
	mov	(__ltoa_PARM_2 + 2),r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:42: value = -value;
;	genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r5
	mov	r5,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:44: _ultoa(value, string, radix);
;	genAssign
	mov	__ultoa_PARM_2,__ltoa_PARM_2
	mov	(__ultoa_PARM_2 + 1),(__ltoa_PARM_2 + 1)
	mov	(__ultoa_PARM_2 + 2),(__ltoa_PARM_2 + 2)
;	genAssign
	mov	__ultoa_PARM_3,__ltoa_PARM_3
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__ultoa
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
