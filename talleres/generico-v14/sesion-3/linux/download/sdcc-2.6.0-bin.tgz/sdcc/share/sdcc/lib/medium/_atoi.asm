;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:05 2006
;--------------------------------------------------------
	.module _atoi
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atoi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_atoi_rv_1_1:
	.ds 2
_atoi_sloc1_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atoi'
;------------------------------------------------------------
;rv                        Allocated with name '_atoi_rv_1_1'
;sign                      Allocated to registers r7 
;sloc0                     Allocated with name '_atoi_sloc0_1_0'
;sloc1                     Allocated with name '_atoi_sloc1_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:25: int atoi(char * s)
;	-----------------------------------------
;	 function atoi
;	-----------------------------------------
_atoi:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:27: register int rv=0; 
;	genAssign
	clr	a
	mov	_atoi_rv_1_1,a
	mov	(_atoi_rv_1_1 + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:31: while (*s) {
;	genAssign
	mov	ar7,r2
	mov	ar5,r3
	mov	ar6,r4
00107$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00133$
;	Peephole 300	removed redundant label 00135$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:32: if (*s <= '9' && *s >= '0')
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpLt
;	genCmp
	jc	00102$
;	Peephole 300	removed redundant label 00136$
;	Peephole 256.a	removed redundant clr c
	mov	a,r2
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00133$
;	Peephole 300	removed redundant label 00137$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:33: break;
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:34: if (*s == '-' || *s == '+') 
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r2,a
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x2D,00138$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00138$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x2B,00139$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00139$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:36: s++;
;	genPlus
;     genPlusIncr
	inc	r7
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 243	avoided branch to sjmp
	cjne	r7,#0x00,00107$
	inc	r5
;	Peephole 300	removed redundant label 00140$
	sjmp	00107$
00133$:
;	genAssign
	mov	ar2,r7
	mov	ar3,r5
	mov	ar4,r6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:39: sign = (*s == '-');
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r5
	mov	b,r6
	lcall	__gptrget
	mov	r5,a
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r5,#0x2D,00141$
	inc	a
00141$:
;	Peephole 300	removed redundant label 00142$
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:40: if (*s == '-' || *s == '+') s++;
;	genIfx
	mov	r6,a
	mov	ar7,r6
;	Peephole 166	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00110$
;	Peephole 300	removed redundant label 00143$
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r5,#0x2B,00131$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00144$
;	Peephole 300	removed redundant label 00145$
00110$:
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00146$
	inc	r3
00146$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
;	genAssign
00115$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfx
	mov	r5,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00147$
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r5
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpGt
;	genCmp
	jc	00117$
;	Peephole 300	removed redundant label 00148$
;	Peephole 256.a	removed redundant clr c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r5
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00117$
;	Peephole 300	removed redundant label 00149$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:43: rv = (rv * 10) + (*s - '0');
;	genIpush
	push	ar7
;	genAssign
	mov	r0,#__mulint_PARM_2
	mov	a,#0x0A
	movx	@r0,a
	clr	a
	inc	r0
	movx	@r0,a
;	genCall
	mov	dpl,_atoi_rv_1_1
	mov	dph,(_atoi_rv_1_1 + 1)
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar7
	lcall	__mulint
	mov	_atoi_sloc1_1_0,dpl
	mov	(_atoi_sloc1_1_0 + 1),dph
	pop	ar7
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r6,a
;	genMinus
	mov	a,r5
	add	a,#0xd0
	mov	r5,a
	mov	a,r6
	addc	a,#0xff
	mov	r6,a
;	genPlus
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	add	a,_atoi_sloc1_1_0
	mov	_atoi_rv_1_1,a
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	addc	a,(_atoi_sloc1_1_0 + 1)
	mov	(_atoi_rv_1_1 + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:44: s++;
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00150$
	inc	r3
00150$:
;	genIpop
	pop	ar7
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:47: return (sign ? -rv : rv);
;	genIfx
	mov	a,r7
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00120$
;	Peephole 300	removed redundant label 00151$
;	genUminus
	clr	c
	clr	a
	subb	a,_atoi_rv_1_1
	mov	r2,a
	clr	a
	subb	a,(_atoi_rv_1_1 + 1)
	mov	r3,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00120$:
;	genAssign
	mov	r2,_atoi_rv_1_1
	mov	r3,(_atoi_rv_1_1 + 1)
00121$:
;	genRet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 300	removed redundant label 00118$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
