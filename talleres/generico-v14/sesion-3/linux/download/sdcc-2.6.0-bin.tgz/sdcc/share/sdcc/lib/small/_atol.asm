;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:53 2006
;--------------------------------------------------------
	.module _atol
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atol
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_atol_s_1_1:
	.ds 3
_atol_sloc1_1_0:
	.ds 3
_atol_sloc2_1_0:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atol'
;------------------------------------------------------------
;s                         Allocated with name '_atol_s_1_1'
;rv                        Allocated to registers r5 r6 r7 r0 
;sign                      Allocated to registers r4 
;sloc0                     Allocated with name '_atol_sloc0_1_0'
;sloc1                     Allocated with name '_atol_sloc1_1_0'
;sloc2                     Allocated with name '_atol_sloc2_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:25: long atol(char * s)
;	-----------------------------------------
;	 function atol
;	-----------------------------------------
_atol:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	_atol_s_1_1,dpl
	mov	(_atol_s_1_1 + 1),dph
	mov	(_atol_s_1_1 + 2),b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:27: register long rv=0; 
;	genAssign
	mov	r5,#0x00
	mov	r6,#0x00
	mov	r7,#0x00
	mov	r0,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:31: while (*s) {
;	genAssign
	mov	r1,_atol_s_1_1
	mov	r2,(_atol_s_1_1 + 1)
	mov	r3,(_atol_s_1_1 + 2)
00107$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
;	genIfx
	mov	r4,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00133$
;	Peephole 300	removed redundant label 00135$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:32: if (*s <= '9' && *s >= '0')
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpLt
;	genCmp
	jc	00102$
;	Peephole 300	removed redundant label 00136$
;	Peephole 256.a	removed redundant clr c
	mov	a,r4
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00133$
;	Peephole 300	removed redundant label 00137$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:33: break;
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:34: if (*s == '-' || *s == '+') 
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r4,a
;	genCmpEq
;	gencjneshort
	cjne	r4,#0x2D,00138$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00138$:
;	genCmpEq
;	gencjneshort
	cjne	r4,#0x2B,00139$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00139$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:36: s++;
;	genPlus
;     genPlusIncr
	inc	r1
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 243	avoided branch to sjmp
	cjne	r1,#0x00,00107$
	inc	r2
;	Peephole 300	removed redundant label 00140$
	sjmp	00107$
00133$:
;	genAssign
	mov	_atol_s_1_1,r1
	mov	(_atol_s_1_1 + 1),r2
	mov	(_atol_s_1_1 + 2),r3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:39: sign = (*s == '-');
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r1
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r2,a
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r2,#0x2D,00141$
	inc	a
00141$:
;	Peephole 300	removed redundant label 00142$
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:40: if (*s == '-' || *s == '+') s++;
;	genIfx
	mov	r3,a
	mov	ar4,r3
;	Peephole 166	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00110$
;	Peephole 300	removed redundant label 00143$
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r2,#0x2B,00131$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00144$
;	Peephole 300	removed redundant label 00145$
00110$:
;	genPlus
;     genPlusIncr
	inc	_atol_s_1_1
	clr	a
	cjne	a,_atol_s_1_1,00146$
	inc	(_atol_s_1_1 + 1)
00146$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
;	genAssign
	mov	_atol_sloc1_1_0,_atol_s_1_1
	mov	(_atol_sloc1_1_0 + 1),(_atol_s_1_1 + 1)
	mov	(_atol_sloc1_1_0 + 2),(_atol_s_1_1 + 2)
00115$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atol_sloc1_1_0
	mov	dph,(_atol_sloc1_1_0 + 1)
	mov	b,(_atol_sloc1_1_0 + 2)
	lcall	__gptrget
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00147$
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r2
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpGt
;	genCmp
	jc	00117$
;	Peephole 300	removed redundant label 00148$
;	Peephole 256.a	removed redundant clr c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00117$
;	Peephole 300	removed redundant label 00149$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:43: rv = (rv * 10) + (*s - '0');
;	genIpush
	push	ar4
;	genAssign
	mov	__mullong_PARM_2,#0x0A
	clr	a
	mov	(__mullong_PARM_2 + 1),a
	mov	(__mullong_PARM_2 + 2),a
	mov	(__mullong_PARM_2 + 3),a
;	genCall
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r0
	push	ar2
	push	ar4
	lcall	__mullong
	mov	_atol_sloc2_1_0,dpl
	mov	(_atol_sloc2_1_0 + 1),dph
	mov	(_atol_sloc2_1_0 + 2),b
	mov	(_atol_sloc2_1_0 + 3),a
	pop	ar4
	pop	ar2
;	genCast
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r3,a
;	genMinus
	mov	a,r2
	add	a,#0xd0
	mov	r2,a
	mov	a,r3
	addc	a,#0xff
;	genCast
	mov	r3,a
;	Peephole 105	removed redundant mov
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r1,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,_atol_sloc2_1_0
	mov	r5,a
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	addc	a,(_atol_sloc2_1_0 + 1)
	mov	r6,a
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	addc	a,(_atol_sloc2_1_0 + 2)
	mov	r7,a
;	Peephole 236.g	used r1 instead of ar1
	mov	a,r1
	addc	a,(_atol_sloc2_1_0 + 3)
	mov	r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:44: s++;
;	genPlus
;     genPlusIncr
	inc	_atol_sloc1_1_0
	clr	a
	cjne	a,_atol_sloc1_1_0,00150$
	inc	(_atol_sloc1_1_0 + 1)
00150$:
;	genIpop
	pop	ar4
	ljmp	00115$
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atol.c:47: return (sign ? -rv : rv);
;	genIfx
	mov	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00120$
;	Peephole 300	removed redundant label 00151$
;	genUminus
	clr	c
	clr	a
	subb	a,r5
	mov	r2,a
	clr	a
	subb	a,r6
	mov	r3,a
	clr	a
	subb	a,r7
	mov	r4,a
	clr	a
	subb	a,r0
	mov	r1,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00120$:
;	genAssign
	mov	ar2,r5
	mov	ar3,r6
	mov	ar4,r7
	mov	ar1,r0
00121$:
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r1
;	Peephole 300	removed redundant label 00118$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
