;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:07 2006
;--------------------------------------------------------
	.module sprintf
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _vsprintf
	.globl _sprintf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'put_char_to_string'
;------------------------------------------------------------
;p                         Allocated to stack - offset -5
;c                         Allocated to stack - offset 1
;buf                       Allocated to registers 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:29: static void put_char_to_string( char c, void* p ) _REENTRANT
;	-----------------------------------------
;	 function put_char_to_string
;	-----------------------------------------
_put_char_to_string:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:31: char **buf = (char **)p;
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:32: *(*buf)++ = c;
;	genPointerGet
;	genGenPointerGet
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r6,a
	inc	dptr
	lcall	__gptrget
	mov	r7,a
	inc	dptr
	lcall	__gptrget
	mov	r2,a
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	r3,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	mov	r4,a
	mov	ar5,r2
;	genPointerSet
;	genGenPointerSet
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	mov	a,r3
	lcall	__gptrput
	inc	dptr
	mov	a,r4
	lcall	__gptrput
	inc	dptr
	mov	a,r5
	lcall	__gptrput
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	lcall	__gptrput
;	Peephole 300	removed redundant label 00101$
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'vsprintf'
;------------------------------------------------------------
;format                    Allocated to stack - offset -5
;ap                        Allocated to stack - offset -6
;buf                       Allocated to stack - offset 1
;i                         Allocated to registers r2 r3 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:35: int vsprintf (char *buf, const char *format, va_list ap)
;	-----------------------------------------
;	 function vsprintf
;	-----------------------------------------
_vsprintf:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:38: i = _print_format( put_char_to_string, &buf, format, ap );
;	genAddrOf
;	Peephole 212	reduced add sequence to inc
	mov	r2,_bp
	inc	r2
;	genCast
	mov	r3,#0x00
	mov	r4,#0x40
;	genIpush
	mov	a,_bp
	add	a,#0xfffffffa
	mov	r0,a
	mov	a,@r0
	push	acc
;	genIpush
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genCall
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_put_char_to_string
	lcall	__print_format
	mov	r2,dpl
	mov	r3,dph
	mov	a,sp
	add	a,#0xf9
	mov	sp,a
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:39: *buf = 0;
;	genAssign
	mov	r0,_bp
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:40: return i;
;	genRet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 300	removed redundant label 00101$
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'sprintf'
;------------------------------------------------------------
;buf                       Allocated to stack - offset -5
;format                    Allocated to stack - offset -8
;arg                       Allocated to registers 
;i                         Allocated to registers r2 r3 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:43: int sprintf (char *buf, const char *format, ...)
;	-----------------------------------------
;	 function sprintf
;	-----------------------------------------
_sprintf:
	push	_bp
	mov	_bp,sp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:48: va_start (arg, format);
;	genAddrOf
	mov	a,_bp
	add	a,#0xf8
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:49: i = _print_format( put_char_to_string, &buf, format, arg );
;	genAddrOf
	mov	a,_bp
	add	a,#0xfb
	mov	r3,a
;	genCast
	mov	r4,#0x00
	mov	r5,#0x40
;	genIpush
	push	ar2
;	genIpush
	mov	a,_bp
	add	a,#0xfffffff8
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	push	ar3
	push	ar4
	push	ar5
;	genCall
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_put_char_to_string
	lcall	__print_format
	mov	r2,dpl
	mov	r3,dph
	mov	a,sp
	add	a,#0xf9
	mov	sp,a
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:50: *buf = 0;
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/sprintf.c:53: return i;
;	genRet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 300	removed redundant label 00101$
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
