;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:24 2006
;--------------------------------------------------------
	.module _memmove
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memmove_PARM_3
	.globl _memmove_PARM_2
	.globl _memmove
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_memmove_sloc1_1_0::
	.ds 3
_memmove_sloc2_1_0::
	.ds 3
_memmove_sloc3_1_0::
	.ds 3
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_memmove_PARM_2:
	.ds 3
_memmove_PARM_3:
	.ds 2
_memmove_dst_1_1:
	.ds 3
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memmove'
;------------------------------------------------------------
;src                       Allocated with name '_memmove_PARM_2'
;acount                    Allocated with name '_memmove_PARM_3'
;dst                       Allocated with name '_memmove_dst_1_1'
;ret                       Allocated with name '_memmove_ret_1_1'
;d                         Allocated with name '_memmove_d_1_1'
;s                         Allocated with name '_memmove_s_1_1'
;sloc0                     Allocated with name '_memmove_sloc0_1_0'
;sloc1                     Allocated with name '_memmove_sloc1_1_0'
;sloc2                     Allocated with name '_memmove_sloc2_1_0'
;sloc3                     Allocated with name '_memmove_sloc3_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:35: void * memmove (
;	-----------------------------------------
;	 function memmove
;	-----------------------------------------
_memmove:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_memmove_dst_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:96: void * ret = dst;
;	genAssign
	mov	dptr,#_memmove_dst_1_1
	movx	a,@dptr
	mov	_memmove_sloc3_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_sloc3_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_sloc3_1_0 + 2),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:100: if (((int)src < (int)dst) && ((((int)src)+acount) > (int)dst)) {
;	genAssign
	mov	dptr,#_memmove_PARM_2
	movx	a,@dptr
	mov	_memmove_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_sloc1_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_sloc1_1_0 + 2),a
;	genCast
	mov	r2,_memmove_sloc1_1_0
	mov	r6,(_memmove_sloc1_1_0 + 1)
;	genAssign
	mov	r0,_memmove_sloc3_1_0
	mov	r1,(_memmove_sloc3_1_0 + 1)
	mov	r5,(_memmove_sloc3_1_0 + 2)
;	genCast
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r0
	mov	a,r6
	xrl	a,#0x80
	mov	b,r1
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00121$
	ljmp	00108$
00121$:
;	genAssign
	mov	r5,_memmove_sloc1_1_0
	mov	r6,(_memmove_sloc1_1_0 + 1)
	mov	r7,(_memmove_sloc1_1_0 + 2)
;	genCast
;	genAssign
	mov	dptr,#_memmove_PARM_3
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genPlus
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r2,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r3,a
;	genAssign
	mov	r1,_memmove_sloc3_1_0
	mov	r5,(_memmove_sloc3_1_0 + 1)
	mov	r6,(_memmove_sloc3_1_0 + 2)
;	genCast
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r1
	subb	a,r2
	mov	a,r5
	subb	a,r3
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00108$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:104: d = ((char *)dst)+acount-1;
;	genPlus
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	add	a,_memmove_sloc3_1_0
	mov	r5,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
	addc	a,(_memmove_sloc3_1_0 + 1)
	mov	r6,a
	mov	r1,(_memmove_sloc3_1_0 + 2)
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xff
	mov	r2,a
	mov	a,r6
	addc	a,#0xff
	mov	r3,a
	mov	ar4,r1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:105: s = ((char *)src)+acount-1;
;	genPlus
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	add	a,_memmove_sloc1_1_0
	mov	r5,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
	addc	a,(_memmove_sloc1_1_0 + 1)
	mov	r6,a
	mov	r1,(_memmove_sloc1_1_0 + 2)
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00123$
	dec	r6
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:106: while (acount--) {
;	genAssign
;	genAssign
	mov	_memmove_sloc2_1_0,r2
	mov	(_memmove_sloc2_1_0 + 1),r3
	mov	(_memmove_sloc2_1_0 + 2),r4
;	genAssign
00101$:
;	genAssign
	mov	ar2,r7
	mov	ar3,r0
;	genMinus
;	genMinusDec
	dec	r7
	cjne	r7,#0xff,00124$
	dec	r0
00124$:
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:107: *d-- = *s--;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00126$
	dec	r6
00126$:
;	genPointerSet
;	genGenPointerSet
	mov	dpl,_memmove_sloc2_1_0
	mov	dph,(_memmove_sloc2_1_0 + 1)
	mov	b,(_memmove_sloc2_1_0 + 2)
	mov	a,r2
	lcall	__gptrput
;	genMinus
;	genMinusDec
;	tail decrement optimized (range 7)
	dec	_memmove_sloc2_1_0
	mov	a,#0xff
	cjne	a,_memmove_sloc2_1_0,00101$
	dec	(_memmove_sloc2_1_0 + 1)
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:114: d = dst;
;	genAssign
	mov	dptr,#_memmove_dst_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:116: while (acount--) {
;	genAssign
	mov	r5,_memmove_sloc1_1_0
	mov	r6,(_memmove_sloc1_1_0 + 1)
	mov	r7,(_memmove_sloc1_1_0 + 2)
;	genAssign
;	genAssign
	mov	dptr,#_memmove_PARM_3
	movx	a,@dptr
	mov	_memmove_sloc2_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_sloc2_1_0 + 1),a
00104$:
;	genAssign
	mov	r0,_memmove_sloc2_1_0
	mov	r1,(_memmove_sloc2_1_0 + 1)
;	genMinus
;	genMinusDec
	dec	_memmove_sloc2_1_0
	mov	a,#0xff
	cjne	a,_memmove_sloc2_1_0,00127$
	dec	(_memmove_sloc2_1_0 + 1)
00127$:
;	genIfx
	mov	a,r0
	orl	a,r1
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:117: *d++ = *s++;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r0,a
	inc	dptr
	mov	r5,dpl
	mov	r6,dph
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r0
	lcall	__gptrput
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:121: return(ret);
;	genRet
	mov	dpl,_memmove_sloc3_1_0
	mov	dph,(_memmove_sloc3_1_0 + 1)
	mov	b,(_memmove_sloc3_1_0 + 2)
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
