;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:07 2006
;--------------------------------------------------------
	.module printf_large
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __print_format
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; overlayable bit register bank
;--------------------------------------------------------
	.area BIT_BANK	(REL,OVR,DATA)
bits:
	.ds 1
	b0 = bits[0]
	b1 = bits[1]
	b2 = bits[2]
	b3 = bits[3]
	b4 = bits[4]
	b5 = bits[5]
	b6 = bits[6]
	b7 = bits[7]
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'output_digit'
;------------------------------------------------------------
;output_char               Allocated to stack - offset -4
;p                         Allocated to stack - offset -7
;lower_case                Allocated to registers b0 
;n                         Allocated to registers r2 
;c                         Allocated to registers r2 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:98: static void output_digit( unsigned char n, BOOL lower_case, pfn_outputchar output_char, void* p )
;	-----------------------------------------
;	 function output_digit
;	-----------------------------------------
_output_digit:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;	genReceive
	mov	r2,dpl
;	genReceive
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:100: register unsigned char c = n + (unsigned char)'0';
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:102: if (c > (unsigned char)'9')
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r2,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x39
	jnc	00104$
;	Peephole 300	removed redundant label 00109$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:104: c += (unsigned char)('A' - '0' - 10);
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:105: if (lower_case)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b0,00104$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:106: c += (unsigned char)('a' - 'A');
;	genPlus
;     genPlusIncr
	mov	a,#0x20
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:108: output_char( c, p );
;	genIpush
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00111$
	push	acc
	mov	a,#(00111$ >> 8)
	push	acc
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00111$:
	dec	sp
	dec	sp
	dec	sp
;	Peephole 300	removed redundant label 00105$
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_2digits'
;------------------------------------------------------------
;output_char               Allocated to stack - offset -4
;p                         Allocated to stack - offset -7
;lower_case                Allocated to registers b0 
;b                         Allocated to registers r2 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:129: static void output_2digits( unsigned char b, BOOL lower_case, pfn_outputchar output_char, void* p )
;	-----------------------------------------
;	 function output_2digits
;	-----------------------------------------
_output_2digits:
	push	_bp
	mov	_bp,sp
;	genReceive
;	genReceive
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:131: output_digit( b>>4,   lower_case, output_char, p );
;	genRightShift
;	genRightShiftLiteral
;	genrshOne
;	peephole 177.g	optimized mov sequence
	mov	a,dpl
	mov	r2,a
	swap	a
	anl	a,#0x0f
	mov	r3,a
;	genIpush
	push	ar2
	push	bits
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genCall
	mov	c,b0
	mov	b[0],c
	mov	bits,b
	mov	dpl,r3
	lcall	_output_digit
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
	pop	bits
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:132: output_digit( b&0x0F, lower_case, output_char, p );
;	genAnd
	anl	ar2,#0x0F
;	genIpush
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genCall
	mov	c,b0
	mov	b[0],c
	mov	bits,b
	mov	dpl,r2
	lcall	_output_digit
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
;	Peephole 300	removed redundant label 00101$
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'calculate_digit'
;------------------------------------------------------------
;radix                     Allocated to stack - offset -3
;value                     Allocated to registers r0 
;ul                        Allocated to registers r2 r3 r4 r5 
;pb4                       Allocated to registers r1 
;i                         Allocated to stack - offset 1
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:146: static void calculate_digit( value_t _AUTOMEM * value, unsigned char radix )
;	-----------------------------------------
;	 function calculate_digit
;	-----------------------------------------
_calculate_digit:
	push	_bp
	mov	_bp,sp
	inc	sp
;	genReceive
	mov	r0,dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:148: unsigned long ul = value->ul;
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	dec	r0
	dec	r0
	dec	r0
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:149: unsigned char _AUTOMEM * pb4 = &value->byte[4];
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r0 instead of ar0
	add	a,r0
	mov	r1,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:152: do
;	genAssign
	push	ar0
	mov	r0,_bp
	inc	r0
	mov	@r0,#0x20
	pop	ar0
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:154: *pb4 = (*pb4 << 1) | ((ul >> 31) & 0x01);
;	genIpush
	push	ar0
;	genPointerGet
;	genNearPointerGet
;	genLeftShift
;	genLeftShiftLiteral
;	genlshOne
;	Peephole 140	removed redundant mov
	mov	a,@r1
	add	a,@r1
	mov	r7,a
;	genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
;	genOr
	mov	r6,a
;	Peephole 105	removed redundant mov
	orl	ar7,a
;	genPointerSet
;	genNearPointerSet
	mov	@r1,ar7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:155: ul <<= 1;
;	genLeftShift
;	genLeftShiftLiteral
;	genlshFour
	mov	a,r2
;	Peephole 254	optimized left shift
	add	a,r2
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:157: if (radix <= *pb4 )
;	genPointerGet
;	genNearPointerGet
	mov	ar6,@r1
;	genCmpGt
	push	ar0
	mov	r0,_bp
	dec	r0
	dec	r0
	dec	r0
;	genCmp
	clr	c
	mov	a,r6
	subb	a,@r0
	pop	ar0
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	Peephole 129.b	optimized condition
	pop	ar0
	jc	00104$
;	Peephole 300	removed redundant label 00112$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:159: *pb4 -= radix;
;	genPointerGet
;	genNearPointerGet
	mov	ar6,@r1
;	genMinus
	push	ar0
	mov	r0,_bp
	dec	r0
	dec	r0
	dec	r0
	mov	a,r6
	clr	c
	subb	a,@r0
	mov	r6,a
	pop	ar0
;	genPointerSet
;	genNearPointerSet
	mov	@r1,ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:160: ul |= 1;
;	genOr
	orl	ar2,#0x01
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:162: } while (--i);
;	genDjnz
	push	ar0
	mov	r0,_bp
	inc	r0
	dec	@r0
	mov	a,@r0
	pop	ar0
;	Peephole 160.c	removed sjmp by inverse jump logic
	jz	00114$
;	Peephole 300	removed redundant label 00113$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:163: value->ul = ul;
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;	Peephole 300	removed redundant label 00106$
	mov	sp,_bp
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_print_format'
;------------------------------------------------------------
;pvoid                     Allocated to stack - offset -5
;format                    Allocated to stack - offset -8
;ap                        Allocated to stack - offset -9
;pfn                       Allocated to stack - offset 1
;left_justify              Allocated to registers b0 
;zero_padding              Allocated to registers b1 
;prefix_sign               Allocated to registers b2 
;prefix_space              Allocated to registers b3 
;signed_argument           Allocated to registers b4 
;char_argument             Allocated to registers b5 
;long_argument             Allocated to registers b6 
;float_argument            Allocated to registers b7 
;lower_case                Allocated to stack - offset 3
;value                     Allocated to stack - offset 4
;charsOutputted            Allocated to stack - offset 26
;lsd                       Allocated to registers b5 
;radix                     Allocated to stack - offset 9
;width                     Allocated to stack - offset 10
;decimals                  Allocated to registers r3 
;length                    Allocated to stack - offset 11
;c                         Allocated to registers r2 
;memtype                   Allocated to registers r2 
;store                     Allocated to stack - offset 12
;pstore                    Allocated to registers r2 
;sloc0                     Allocated to stack - offset 18
;sloc1                     Allocated to stack - offset 36
;sloc2                     Allocated to stack - offset 21
;sloc3                     Allocated to stack - offset 23
;sloc4                     Allocated to stack - offset 26
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:385: int _print_format (pfn_outputchar pfn, void* pvoid, const char *format, va_list ap)
;	-----------------------------------------
;	 function _print_format
;	-----------------------------------------
__print_format:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	mov	a,sp
	add	a,#0x1b
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:417: charsOutputted = 0;
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	clr	a
	mov	@r0,a
	inc	r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:425: while( c=*format++ )
;	genAddrOf
	mov	a,_bp
	add	a,#0x0c
	mov	r6,a
;	genPlus
;     genPlusIncr
	mov	a,#0x05
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	r6,a
00234$:
;	genIpush
	push	ar6
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff8
	mov	r0,a
	mov	ar7,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar2,@r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r6
	mov	b,r2
	lcall	__gptrget
	mov	r3,a
;	genPlus
	mov	a,_bp
	add	a,#0xfffffff8
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar2
;	genAssign
	mov	ar2,r3
;	genIpop
	pop	ar6
;	genIfx
	mov	a,r3
;	genIfxJump
	jnz	00320$
	ljmp	00236$
00320$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:427: if ( c=='%' )
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x25,00321$
	sjmp	00322$
00321$:
	ljmp	00232$
00322$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:429: left_justify    = 0;
;	genAssign
	clr	b0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:430: zero_padding    = 0;
;	genAssign
	clr	b1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:431: prefix_sign     = 0;
;	genAssign
	clr	b2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:432: prefix_space    = 0;
;	genAssign
	clr	b3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:433: signed_argument = 0;
;	genAssign
	clr	b4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:434: char_argument   = 0;
;	genAssign
	clr	b5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:435: long_argument   = 0;
;	genAssign
	clr	b6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:436: float_argument  = 0;
;	genAssign
	clr	b7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:437: radix           = 0;
;	genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:438: width           = 0;
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:439: decimals        = -1;
;	genAssign
	mov	r3,#0xFF
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:441: get_conversion_spec:
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff8
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
00101$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:443: c = *format++;
;	genIpush
	push	ar6
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r7
	lcall	__gptrget
	mov	r6,a
	inc	dptr
	mov	r4,dpl
	mov	r5,dph
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff8
	mov	r0,a
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
;	genAssign
	mov	ar2,r6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:445: if (c=='%') {
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r2,#0x25,00323$
	inc	a
00323$:
;	Peephole 300	removed redundant label 00324$
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00103$
;	Peephole 300	removed redundant label 00325$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:446: OUTPUT_CHAR(c, p);
;	genIpush
	push	ar6
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00326$
	push	acc
	mov	a,#(00326$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00326$:
	dec	sp
	dec	sp
	dec	sp
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:447: continue;
	ljmp	00234$
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:450: if (isdigit(c)) {
;	genIpush
	push	ar6
;	genAssign
	mov	ar6,r2
;	genCmpLt
;	genCmp
	cjne	r6,#0x30,00327$
00327$:
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	Peephole 129.b	optimized condition
	pop	ar6
	jc	00110$
;	Peephole 300	removed redundant label 00328$
;	genIpush
	push	ar6
;	genAssign
	mov	ar6,r2
;	genCmpGt
;	genCmp
	clr	c
	mov	a,#0x39
	subb	a,r6
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	Peephole 129.b	optimized condition
	pop	ar6
	jc	00110$
;	Peephole 300	removed redundant label 00329$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:451: if (decimals==-1) {
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r3,#0xFF,00107$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00330$
;	Peephole 300	removed redundant label 00331$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:452: width = 10*width + (c - '0');
;	genIpush
	push	ar6
;	genMult
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genMultOneByte
	mov	a,@r0
	mov	b,#0x0A
	mul	ab
	mov	r6,a
;	genMinus
	mov	a,r2
	add	a,#0xd0
;	genPlus
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	r6,a
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:453: if (width == 0) {
;	genIpop
	pop	ar6
;	genIfx
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,@r0
;	genIfxJump
	jz	00332$
	ljmp	00101$
00332$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:455: zero_padding = 1;
;	genAssign
	setb	b1
	ljmp	00101$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:458: decimals = 10*decimals + (c-'0');
;	genIpush
	push	ar6
;	genMult
;	genMultOneByte
	mov	a,r3
	mov	b,#0x0A
	mul	ab
	mov	r6,a
;	genMinus
	mov	a,r2
	add	a,#0xd0
;	genPlus
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	r6,a
;	genAssign
	mov	ar3,r6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:460: goto get_conversion_spec;
;	genIpop
	pop	ar6
	ljmp	00101$
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:463: if (c=='.') {
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r2,#0x2E,00115$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00333$
;	Peephole 300	removed redundant label 00334$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:464: if (decimals=-1) decimals=0;
;	genAssign
	mov	r3,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:467: goto get_conversion_spec;
	ljmp	00101$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:470: lower_case = islower(c);
;	genCall
	mov	dpl,r2
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	bits
	lcall	_islower
	pop	bits
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	@r0,dpl
;	genAssign
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:471: if (lower_case)
;	genIfx
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	a,@r0
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00335$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:473: c = toupper(c);
;	genAnd
	anl	ar2,#0xDF
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:476: switch( c )
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x20,00336$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00120$
00336$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x2B,00337$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00119$
00337$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x2D,00338$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00118$
00338$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x42,00339$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00339$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x43,00340$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00123$
00340$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x44,00341$
	ljmp	00157$
00341$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x46,00342$
	ljmp	00161$
00342$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x49,00343$
	ljmp	00157$
00343$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x4C,00344$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00122$
00344$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x4F,00345$
	ljmp	00158$
00345$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x50,00346$
	ljmp	00143$
00346$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x53,00347$
	ljmp	00124$
00347$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x55,00348$
	ljmp	00159$
00348$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x58,00349$
	ljmp	00160$
00349$:
	ljmp	00162$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:478: case '-':
00118$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:479: left_justify = 1;
;	genAssign
	setb	b0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:480: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:481: case '+':
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:482: prefix_sign = 1;
;	genAssign
	setb	b2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:483: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:484: case ' ':
00120$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:485: prefix_space = 1;
;	genAssign
	setb	b3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:486: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:487: case 'B':
00121$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:488: char_argument = 1;
;	genAssign
	setb	b5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:489: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:490: case 'L':
00122$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:491: long_argument = 1;
;	genAssign
	setb	b6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:492: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:494: case 'C':
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:495: OUTPUT_CHAR( va_arg(ap,int), p );
;	genIpush
	push	ar6
;	genMinus
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r1,a
;	genMinusDec
	mov	a,@r1
	add	a,#0xfe
	mov	r0,a
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r1,a
	mov	@r1,ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar6,@r0
	inc	r0
	mov	ar2,@r0
	dec	r0
;	genCast
;	genIpush
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00350$
	push	acc
	mov	a,#(00350$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r6
	ret
00350$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:496: break;
;	genIpop
	pop	ar6
	ljmp	00163$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:498: case 'S':
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:499: PTR = va_arg(ap,ptr_t);
;	genIpush
	push	ar6
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfd
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r1
	inc	r1
	mov	ar6,@r1
	inc	r1
	mov	ar7,@r1
	dec	r1
	dec	r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:509: length = strlen(PTR);
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
;	genCall
	mov	dpl,r2
	mov	dph,r6
	mov	b,r7
	push	ar3
	push	bits
	lcall	_strlen
	mov	r2,dpl
	mov	r6,dph
	pop	bits
	pop	ar3
;	genCast
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
	mov	@r0,ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:511: if ( decimals == -1 )
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r3,#0xFF,00351$
	inc	a
00351$:
;	Peephole 300	removed redundant label 00352$
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00126$
;	Peephole 300	removed redundant label 00353$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:513: decimals = length;
;	genAssign
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
	mov	ar3,@r0
00126$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:515: if ( ( !left_justify ) && (length < width) )
;	genIfx
;	genIfxJump
	jnb	b0,00354$
	ljmp	00273$
00354$:
;	genCmpLt
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
	mov	a,_bp
	add	a,#0x0a
	mov	r1,a
;	genCmp
	clr	c
	mov	a,@r0
	subb	a,@r1
;	genIfxJump
	jc	00355$
	ljmp	00273$
00355$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:517: width -= length;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:518: while( width-- != 0 )
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	ar2,@r0
	inc	r0
	mov	ar7,@r0
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar4,@r0
00127$:
;	genIpush
	push	ar6
;	genAssign
	mov	ar6,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar4
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r6,#0x00,00356$
	inc	a
00356$:
;	Peephole 300	removed redundant label 00357$
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00313$
;	Peephole 300	removed redundant label 00358$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:520: OUTPUT_CHAR( ' ', p );
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	push	ar7
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00359$
	push	acc
	mov	a,#(00359$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x20
	ret
00359$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar7
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00360$
	inc	r7
00360$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:524: while ( *PTR  && (decimals-- > 0))
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00127$
00313$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar7
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar4
00273$:
;	genAssign
	mov	ar4,r3
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	a,_bp
	add	a,#0x15
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00134$:
;	genIpush
	push	ar6
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar7,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar3,@r0
	dec	r0
	dec	r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r6
	mov	b,r3
	lcall	__gptrget
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
	jnz	00361$
	ljmp	00314$
00361$:
;	genAssign
	mov	ar3,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x00 ^ 0x80)
	mov	b,r3
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00362$
	ljmp	00314$
00362$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:526: OUTPUT_CHAR( *PTR++, p );
;	genIpush
	push	ar6
;	genPointerGet
;	genNearPointerGet
	mov	a,_bp
	add	a,#0x17
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	inc	r0
	mov	a,@r0
	inc	r1
	mov	@r1,a
	dec	r0
	dec	r0
;	genPlus
	mov	a,_bp
	add	a,#0x17
	mov	r1,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r1
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r1
	addc	a,@r1
	mov	r3,a
	inc	r1
	mov	ar6,@r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar6
	dec	r0
	dec	r0
;	genPointerGet
;	genGenPointerGet
	mov	a,_bp
	add	a,#0x17
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r2,a
;	genIpush
	push	ar4
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00363$
	push	acc
	mov	a,#(00363$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00363$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar4
;	genPlus
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	genAssign
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	a,_bp
	add	a,#0x1a
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
;	genIpop
	pop	ar6
	ljmp	00134$
00314$:
;	genAssign
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	a,_bp
	add	a,#0x1a
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:529: if ( left_justify && (length < width))
;	genIfx
;	genIfxJump
	jb	b0,00364$
	ljmp	00163$
00364$:
;	genCmpLt
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
	mov	a,_bp
	add	a,#0x0a
	mov	r1,a
;	genCmp
	clr	c
	mov	a,@r0
	subb	a,@r1
;	genIfxJump
	jc	00365$
	ljmp	00163$
00365$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:531: width -= length;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:532: while( width-- != 0 )
;	genAssign
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar7,@r0
00137$:
;	genIpush
	push	ar6
;	genAssign
	mov	ar6,r7
;	genMinus
;	genMinusDec
	dec	r7
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar7
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r6,#0x00,00366$
	inc	a
00366$:
;	Peephole 300	removed redundant label 00367$
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
	jz	00368$
	ljmp	00315$
00368$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:534: OUTPUT_CHAR( ' ', p );
;	genIpush
	push	ar2
	push	ar3
	push	ar6
	push	ar7
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00369$
	push	acc
	mov	a,#(00369$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x20
	ret
00369$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar7
	pop	ar6
	pop	ar3
	pop	ar2
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00370$
	inc	r3
00370$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:539: case 'P':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00137$
00143$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:540: PTR = va_arg(ap,ptr_t);
;	genIpush
	push	ar6
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfd
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar6,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	dec	r1
	dec	r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:563: unsigned char memtype = value.byte[2];
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x02
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r0
;	genAssign
	mov	ar2,r4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:564: if (memtype > 0x80)
;	genCmpGt
;	genCmp
	clr	c
	mov	a,#0x80
	subb	a,r2
	clr	a
	rlc	a
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00151$
;	Peephole 300	removed redundant label 00371$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:565: c = 'C';
;	genAssign
	mov	r2,#0x43
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00151$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:566: else if (memtype > 0x60)
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r2
	add	a,#0xff - 0x60
	jnc	00148$
;	Peephole 300	removed redundant label 00372$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:567: c = 'P';
;	genAssign
	mov	r2,#0x50
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00148$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:568: else if (memtype > 0x40)
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r2
	add	a,#0xff - 0x40
	jnc	00145$
;	Peephole 300	removed redundant label 00373$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:569: c = 'I';
;	genAssign
	mov	r2,#0x49
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00145$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:571: c = 'X';
;	genAssign
	mov	r2,#0x58
00152$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:573: OUTPUT_CHAR(c, p);
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00374$
	push	acc
	mov	a,#(00374$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00374$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:574: OUTPUT_CHAR(':', p);
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00375$
	push	acc
	mov	a,#(00375$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x3A
	ret
00375$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:575: OUTPUT_CHAR('0', p);
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00376$
	push	acc
	mov	a,#(00376$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x30
	ret
00376$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:576: OUTPUT_CHAR('x', p);
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00377$
	push	acc
	mov	a,#(00377$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x78
	ret
00377$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:577: if ((c != 'I' /* idata */) &&
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x49,00378$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00154$
00378$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:578: (c != 'P' /* pdata */))
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x50,00379$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00154$
00379$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:580: OUTPUT_2DIGITS( value.byte[1] );
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r0
;	genIpush
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genCall
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	a,@r0
	add	a,#0xff
	mov	b[0],c
	mov	bits,b
	mov	dpl,r4
	lcall	_output_2digits
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
	pop	bits
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x02
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
00154$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:582: OUTPUT_2DIGITS( value.byte[0] );
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r0
;	genIpush
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genCall
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	a,@r0
	add	a,#0xff
	mov	b[0],c
	mov	bits,b
	mov	dpl,r4
	lcall	_output_2digits
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
	pop	bits
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x02
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:589: break;
	ljmp	00163$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:592: case 'I':
00157$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:593: signed_argument = 1;
;	genAssign
	setb	b4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:594: radix = 10;
;	genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,#0x0A
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:595: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:597: case 'O':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00158$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:598: radix = 8;
;	genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,#0x08
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:599: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:601: case 'U':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00159$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:602: radix = 10;
;	genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,#0x0A
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:603: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:605: case 'X':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00160$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:606: radix = 16;
;	genAssign
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
	mov	@r0,#0x10
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:607: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:609: case 'F':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00161$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:610: float_argument=1;
;	genAssign
	setb	b7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:611: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:613: default:
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00162$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:615: OUTPUT_CHAR( c, p );
;	genIpush
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00380$
	push	acc
	mov	a,#(00380$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00380$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:617: }
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00315$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar7
00163$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:619: if (float_argument) {
;	genIfx
;	genIfxJump
	jb	b7,00381$
	ljmp	00229$
00381$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:620: value.f=va_arg(ap,float);
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfc
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	dec	r1
	dec	r1
	dec	r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	dec	r0
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:622: PTR="<NO FLOAT>";
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genPointerSet
;	genNearPointerSet
	mov	@r0,#__str_0
	inc	r0
	mov	@r0,#(__str_0 >> 8)
	inc	r0
	mov	@r0,#0x80
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:623: while (c=*PTR++)
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	a,_bp
	add	a,#0x15
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00164$:
;	genIpush
	push	ar6
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r6,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r2,a
	mov	ar3,r7
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	dec	r0
	dec	r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r7
	lcall	__gptrget
	mov	r4,a
;	genAssign
	mov	ar2,r4
;	genIpop
	pop	ar6
;	genIfx
	mov	a,r4
;	genIfxJump
	jnz	00382$
	ljmp	00234$
00382$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:625: OUTPUT_CHAR (c, p);
;	genIpush
	push	ar6
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00383$
	push	acc
	mov	a,#(00383$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00383$:
	dec	sp
	dec	sp
	dec	sp
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	genAssign
	mov	a,_bp
	add	a,#0x15
	mov	r0,a
	mov	a,_bp
	add	a,#0x1a
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	ljmp	00164$
00229$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:642: } else if (radix != 0)
;	genCmpEq
	mov	a,_bp
	add	a,#0x09
	mov	r0,a
;	gencjneshort
	cjne	@r0,#0x00,00384$
	ljmp	00234$
00384$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:647: unsigned char _AUTOMEM *pstore = &store[5];
;	genAssign
	mov	ar2,r6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:650: if (char_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b5,00175$
;	Peephole 300	removed redundant label 00385$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:652: value.l = va_arg(ap,char);
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	dec	a
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r1
;	genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
	mov	r7,a
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:653: if (!signed_argument)
;	genIfx
;	genIfxJump
	jnb	b4,00386$
	ljmp	00176$
00386$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:655: value.l &= 0xFF;
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
	dec	r0
;	genAnd
	mov	r4,#0x00
	mov	r5,#0x00
	mov	r7,#0x00
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
	ljmp	00176$
00175$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:658: else if (long_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b6,00172$
;	Peephole 300	removed redundant label 00387$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:660: value.l = va_arg(ap,long);
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfc
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	inc	r1
	mov	ar7,@r1
	dec	r1
	dec	r1
	dec	r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00176$
00172$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:664: value.l = va_arg(ap,int);
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genMinus
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfe
	mov	r1,a
	pop	ar0
;	genAssign
	push	ar0
	mov	a,_bp
	add	a,#0xfffffff7
	mov	r0,a
	mov	@r0,ar1
	pop	ar0
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r1
	inc	r1
	mov	ar4,@r1
	dec	r1
;	genCast
	mov	a,r4
	rlc	a
	subb	a,acc
	mov	r5,a
	mov	r7,a
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:665: if (!signed_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	b4,00176$
;	Peephole 300	removed redundant label 00388$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:667: value.l &= 0xFFFF;
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
	dec	r0
;	genAnd
	mov	r5,#0x00
	mov	r7,#0x00
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
00176$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:671: if ( signed_argument )
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b4,00181$
;	Peephole 300	removed redundant label 00389$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:673: if (value.l < 0)
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
	dec	r0
;	genCmpLt
;	genCmp
	mov	a,r7
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00178$
;	Peephole 300	removed redundant label 00390$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:674: value.l = -value.l;
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
	dec	r0
;	genUminus
	clr	c
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r5
	mov	r5,a
	clr	a
	subb	a,r7
	mov	r7,a
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar7
	dec	r0
	dec	r0
	dec	r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00181$
00178$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:676: signed_argument = 0;
;	genAssign
	clr	b4
00181$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:680: lsd = 1;
;	genAssign
	setb	b5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:682: do {
;	genAssign
	mov	ar0,r2
;	genAssign
	mov	a,_bp
	add	a,#0x0b
	mov	r1,a
	mov	@r1,#0x00
00185$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:683: value.byte[4] = 0;
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
;	genPointerSet
;	genNearPointerSet
;	Peephole 239	used a instead of acc
	mov	r1,a
	mov	@r1,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:685: calculate_digit(&value, radix);
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genIpush
	push	ar6
	push	ar0
	push	bits
	mov	a,_bp
	add	a,#0x09
	mov	r1,a
	mov	a,@r1
	push	acc
;	genCall
	mov	dpl,r4
	lcall	_calculate_digit
	dec	sp
	pop	bits
	pop	ar0
	pop	ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:689: if (!lsd)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	b5,00183$
;	Peephole 300	removed redundant label 00391$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:691: *pstore = (value.byte[4] << 4) | (value.byte[4] >> 4) | *pstore;
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r1
;     genSwap
	mov	a,r4
	swap	a
	mov	r4,a
;	genPointerGet
;	genNearPointerGet
	mov	ar5,@r0
;	genOr
	mov	a,r5
	orl	ar4,a
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:692: pstore--;
;	genMinus
;	genMinusDec
	dec	r0
;	genAssign
	mov	ar2,r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00184$
00183$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:696: *pstore = value.byte[4];
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r1
;	genPointerSet
;	genNearPointerSet
	mov	@r0,ar4
00184$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:698: length++;
;	genPlus
	mov	a,_bp
	add	a,#0x0b
	mov	r1,a
;     genPlusIncr
	inc	@r1
;	genAssign
	mov	a,_bp
	add	a,#0x0b
	mov	r1,a
	push	ar0
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
	mov	a,@r1
	mov	@r0,a
	pop	ar0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:699: lsd = !lsd;
;	genNot
	cpl	b5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:700: } while( value.ul );
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar4,@r1
	inc	r1
	mov	ar5,@r1
	inc	r1
	mov	ar7,@r1
	inc	r1
	mov	ar3,@r1
	dec	r1
	dec	r1
	dec	r1
;	genIfx
	mov	a,r4
	orl	a,r5
	orl	a,r7
	orl	a,r3
;	genIfxJump
	jz	00392$
	ljmp	00185$
00392$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:702: if (width == 0)
;	genAssign
	mov	ar2,r0
;	genAssign
	mov	a,_bp
	add	a,#0x0b
	mov	r0,a
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
;	genIfx
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,@r0
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00189$
;	Peephole 300	removed redundant label 00393$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:707: width=1;
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,#0x01
00189$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:711: if (!zero_padding && !left_justify)
;	genIfx
;	genIfxJump
	jnb	b1,00394$
	ljmp	00194$
00394$:
;	genIfx
;	genIfxJump
	jnb	b0,00395$
	ljmp	00194$
00395$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:713: while ( width > (unsigned char) (length+1) )
;	genPlus
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	r3,a
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar7,@r0
00190$:
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r3
	subb	a,r7
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00317$
;	Peephole 300	removed redundant label 00396$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:715: OUTPUT_CHAR( ' ', p );
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00397$
	push	acc
	mov	a,#(00397$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x20
	ret
00397$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genPlus
;     genPlusIncr
	inc	r4
	cjne	r4,#0x00,00398$
	inc	r5
00398$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:716: width--;
;	genMinus
;	genMinusDec
	dec	r7
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00190$
00317$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar4
	inc	r0
	mov	@r0,ar5
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar7
00194$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:720: if (signed_argument) // this now means the original value was negative
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b4,00204$
;	Peephole 300	removed redundant label 00399$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:722: OUTPUT_CHAR( '-', p );
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00400$
	push	acc
	mov	a,#(00400$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x2D
	ret
00400$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:724: width--;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genMinusDec
	dec	@r0
	ljmp	00205$
00204$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:726: else if (length != 0)
;	genCmpEq
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
;	gencjneshort
	cjne	@r0,#0x00,00401$
	ljmp	00205$
00401$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:729: if (prefix_sign)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b2,00199$
;	Peephole 300	removed redundant label 00402$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:731: OUTPUT_CHAR( '+', p );
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00403$
	push	acc
	mov	a,#(00403$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x2B
	ret
00403$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:733: width--;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genMinusDec
	dec	@r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00205$
00199$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:735: else if (prefix_space)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b3,00205$
;	Peephole 300	removed redundant label 00404$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:737: OUTPUT_CHAR( ' ', p );
;	genIpush
	push	ar2
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00405$
	push	acc
	mov	a,#(00405$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x20
	ret
00405$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar2
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:739: width--;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genMinusDec
	dec	@r0
00205$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:744: if (!left_justify)
;	genIfx
;	genIfxJump
	jnb	b0,00406$
	ljmp	00213$
00406$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:745: while ( width-- > length )
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar5,@r0
00206$:
;	genAssign
	mov	ar7,r5
;	genMinus
;	genMinusDec
	dec	r5
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar5
;	genCmpGt
	mov	a,_bp
	add	a,#0x12
	mov	r0,a
;	genCmp
	clr	c
	mov	a,@r0
	subb	a,r7
;	genIfxJump
	jc	00407$
	ljmp	00318$
00407$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:747: OUTPUT_CHAR( zero_padding ? '0' : ' ', p );
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	b1,00239$
;	Peephole 300	removed redundant label 00408$
;	genAssign
	mov	r7,#0x30
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00240$
00239$:
;	genAssign
	mov	r7,#0x20
00240$:
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00409$
	push	acc
	mov	a,#(00409$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r7
	ret
00409$:
	dec	sp
	dec	sp
	dec	sp
	pop	bits
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genPlus
;     genPlusIncr
	inc	r3
	cjne	r3,#0x00,00410$
	inc	r4
00410$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00206$
00213$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:752: if (width > length)
;	genCmpGt
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
;	genCmp
	clr	c
	mov	a,@r1
	subb	a,@r0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00210$
;	Peephole 300	removed redundant label 00411$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:753: width -= length;
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
	mov	a,@r0
	clr	c
	subb	a,@r1
	mov	@r0,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00310$
00210$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:755: width = 0;
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:759: while( length-- )
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00310$
00318$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar5
00310$:
;	genAssign
	mov	ar0,r2
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r1,a
	mov	ar2,@r1
	inc	r1
	mov	ar3,@r1
;	genAssign
	mov	a,_bp
	add	a,#0x12
	mov	r1,a
	mov	ar4,@r1
00218$:
;	genAssign
	mov	ar5,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genIfx
	mov	a,r5
;	genIfxJump
	jnz	00412$
	ljmp	00319$
00412$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:761: lsd = !lsd;
;	genNot
	cpl	b5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:762: if (!lsd)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	b5,00216$
;	Peephole 300	removed redundant label 00413$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:764: pstore++;
;	genPlus
;     genPlusIncr
	inc	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:765: value.byte[4] = *pstore >> 4;
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r5,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar5,@r0
;	genRightShift
;	genRightShiftLiteral
;	genrshOne
	mov	a,r5
	swap	a
	anl	a,#0x0f
;	genPointerSet
;	genNearPointerSet
	mov	r5,a
;	Peephole 192	used a instead of ar5 as source
	mov	@r1,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00217$
00216$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:769: value.byte[4] = *pstore & 0x0F;
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r5,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar5,@r0
;	genAnd
	mov	a,#0x0F
	anl	a,r5
;	genPointerSet
;	genNearPointerSet
	mov	@r1,a
00217$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:772: output_digit( value.byte[4], lower_case, output_char, p );
;	genAddrOf
	mov	a,_bp
	add	a,#0x04
	mov	r5,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r1,a
;	genPointerGet
;	genNearPointerGet
	mov	ar5,@r1
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	push	ar0
	push	bits
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r1,a
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
;	genIpush
	mov	r1,_bp
	inc	r1
	mov	a,@r1
	push	acc
	inc	r1
	mov	a,@r1
	push	acc
;	genCall
	mov	r1,_bp
	inc	r1
	inc	r1
	inc	r1
	mov	a,@r1
	add	a,#0xff
	mov	b[0],c
	mov	bits,b
	mov	dpl,r5
	lcall	_output_digit
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
	pop	bits
	pop	ar0
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:773: charsOutputted++;
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00414$
	inc	r3
00414$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r1,a
	mov	@r1,ar2
	inc	r1
	mov	@r1,ar3
	ljmp	00218$
00319$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:778: if (left_justify)
;	genIfx
;	genIfxJump
	jb	b0,00415$
	ljmp	00234$
00415$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:779: while (width-- > 0)
;	genAssign
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar4,@r0
00221$:
;	genAssign
	mov	ar5,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genIfx
	mov	a,r5
;	genIfxJump
	jnz	00416$
	ljmp	00234$
00416$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:781: OUTPUT_CHAR(' ', p);
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00417$
	push	acc
	mov	a,#(00417$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,#0x20
	ret
00417$:
	dec	sp
	dec	sp
	dec	sp
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00418$
	inc	r3
00418$:
;	genAssign
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00221$
00232$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:788: OUTPUT_CHAR( c, p );
;	genIpush
	push	ar6
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genPcall
	mov	a,#00419$
	push	acc
	mov	a,#(00419$ >> 8)
	push	acc
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
	mov	dpl,r2
	ret
00419$:
	dec	sp
	dec	sp
	dec	sp
	pop	ar6
;	genPlus
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
	ljmp	00234$
00236$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	genRet
	mov	a,_bp
	add	a,#0x1a
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
;	Peephole 300	removed redundant label 00237$
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
__str_0:
	.ascii "<NO FLOAT>"
	.db 0x00
	.area XINIT   (CODE)
