;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:08 2006
;--------------------------------------------------------
	.module _modulong
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __modulong_PARM_2
	.globl __modulong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__modulong_PARM_2:
	.ds 4
__modulong_count_1_1:
	.ds 1
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modulong'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:340: _modulong (unsigned long a, unsigned long b)
;	-----------------------------------------
;	 function _modulong
;	-----------------------------------------
__modulong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:342: unsigned char count = 0;
;	genAssign
	mov	r6,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:344: while (!MSB_SET(b))
;	genAssign
	mov	r0,#__modulong_count_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
00103$:
;	genGetHbit
;	Peephole 263.a	optimized loading const
	mov	r0,#(__modulong_PARM_2 + 3)
	movx	a,@r0
	rl	a
	anl	a,#0x01
;	genIfx
	mov	r7,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00117$
;	Peephole 300	removed redundant label 00120$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:346: b <<= 1;
;	genLeftShift
;	genLeftShiftLiteral
	mov	r0,#__modulong_PARM_2
;	genlshFour
	movx	a,@r0
	add	a,acc
	movx	@r0,a
	inc	r0
	movx	a,@r0
	rlc	a
	movx	@r0,a
	inc	r0
	movx	a,@r0
	rlc	a
	movx	@r0,a
	inc	r0
	movx	a,@r0
	rlc	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:347: if (b > a)
;	genCmpGt
	mov	r0,#__modulong_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r2
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r3
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r4
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r5
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:349: b >>=1;
;	genRightShift
;	genRightShiftLiteral
;	genrshFour
;	Peephole 263.a	optimized loading const
	mov	r0,#(__modulong_PARM_2 + 3)
	movx	a,@r0
	clr	c
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:350: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00117$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:352: count++;
;	genPlus
	mov	r0,#__modulong_count_1_1
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
;	genAssign
	mov	r0,#__modulong_count_1_1
	movx	a,@r0
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:354: do
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00117$:
;	genAssign
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:356: if (a >= b)
;	genCmpLt
	mov	r0,#__modulong_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r2
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r3
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r4
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r5
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00107$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:357: a -= b;
;	genMinus
	mov	r0,#__modulong_PARM_2
	setb	c
	movx	a,@r0
;	Peephole 236.l	used r2 instead of ar2
	subb	a,r2
	cpl	a
	cpl	c
	mov	r2,a
	cpl	c
	inc	r0
	movx	a,@r0
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	cpl	a
	cpl	c
	mov	r3,a
	cpl	c
	inc	r0
	movx	a,@r0
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	cpl	a
	cpl	c
	mov	r4,a
	cpl	c
	inc	r0
	movx	a,@r0
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	cpl	a
	mov	r5,a
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:358: b >>= 1;
;	genRightShift
;	genRightShiftLiteral
;	genrshFour
;	Peephole 263.a	optimized loading const
	mov	r0,#(__modulong_PARM_2 + 3)
	movx	a,@r0
	clr	c
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
	dec	r0
	movx	a,@r0
	rrc	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:360: while (count--);
;	genAssign
	mov	ar7,r6
;	genMinus
;	genMinusDec
	dec	r6
;	genIfx
	mov	a,r7
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00108$
;	Peephole 300	removed redundant label 00123$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:362: return a;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
