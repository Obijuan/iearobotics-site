;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:02 2006
;--------------------------------------------------------
	.module _moduint
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_moduint_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:47: _moduint_dummy (void) _naked
;	-----------------------------------------
;	 function _moduint_dummy
;	-----------------------------------------
__moduint_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:137: 
;	genInline
	                .globl __moduint
        __moduint:
	                ar0 = 0 ; BUG register set is not considered
	                ar1 = 1
	                .globl __modint
	                mov a,sp
	                add a,#-2 ; 2 bytes return address
	                mov r0,a ; r0 points to bh
	                mov ar1,@r0 ; load bh
	                dec r0
	                mov ar0,@r0 ; load bl
        __modint:
; entry point for __modsint
;	# 105 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c"
	                mov a,r0 ; avoid endless loop
	                orl a,r1
	                jz div_by_0
	                mov r2,#1
        loop1:
	mov a,r0 ; b <<= 1
	                add a,acc
	                mov r0,a
	                mov a,r1
	                rlc a
	                jc msbset
	                mov r1,a
	                mov a,dpl ; a - b
	                subb a,r0 ; here carry is always clear
	                mov a,dph
	                subb a,r1
	                jc start
	                inc r2
	                sjmp loop1
        start:
	clr c
	                mov a,r1 ; b >>= 1;
        msbset:
	rrc a
	                mov r1,a
	                mov a,r0
	                rrc a
	                mov r0,a
        loop2:
	clr c
	                mov a,dpl ; a - b
	                subb a,r0
	                mov b,a
	                mov a,dph
	                subb a,r1
	                jc smaller ; a >= b?
	                mov dph,a ; -> yes; a = a - b;
	                mov dpl,b
        smaller:
; -> no
	                clr c
	                mov a,r1 ; b >>= 1;
	                rrc a
	                mov r1,a
	                mov a,r0
	                rrc a
	                mov r0,a
	                djnz r2,loop2
        div_by_0:
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
