;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:55 2006
;--------------------------------------------------------
	.module _memmove
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memmove_PARM_3
	.globl _memmove_PARM_2
	.globl _memmove
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_memmove_PARM_2::
	.ds 3
_memmove_PARM_3::
	.ds 2
_memmove_ret_1_1::
	.ds 3
_memmove_s_1_1::
	.ds 3
_memmove_sloc1_1_0::
	.ds 3
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memmove'
;------------------------------------------------------------
;src                       Allocated with name '_memmove_PARM_2'
;acount                    Allocated with name '_memmove_PARM_3'
;dst                       Allocated to registers r2 r3 r4 
;ret                       Allocated with name '_memmove_ret_1_1'
;d                         Allocated to registers r2 r3 r4 
;s                         Allocated with name '_memmove_s_1_1'
;sloc0                     Allocated with name '_memmove_sloc0_1_0'
;sloc1                     Allocated with name '_memmove_sloc1_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:35: void * memmove (
;	-----------------------------------------
;	 function memmove
;	-----------------------------------------
_memmove:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:96: void * ret = dst;
;	genAssign
	mov	_memmove_ret_1_1,r2
	mov	(_memmove_ret_1_1 + 1),r3
	mov	(_memmove_ret_1_1 + 2),r4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:100: if (((int)src < (int)dst) && ((((int)src)+acount) > (int)dst)) {
;	genCast
	mov	r0,_memmove_PARM_2
	mov	r1,(_memmove_PARM_2 + 1)
;	genCast
	mov	ar5,r2
	mov	ar6,r3
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r0
	subb	a,r5
	mov	a,r1
	xrl	a,#0x80
	mov	b,r6
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.b	removed sjmp by inverse jump logic
	jnc	00108$
;	Peephole 300	removed redundant label 00121$
;	genPlus
	mov	a,_memmove_PARM_3
;	Peephole 236.a	used r0 instead of ar0
	add	a,r0
	mov	r0,a
	mov	a,(_memmove_PARM_3 + 1)
;	Peephole 236.b	used r1 instead of ar1
	addc	a,r1
	mov	r1,a
;	genAssign
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r5
	subb	a,r0
	mov	a,r6
	subb	a,r1
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00108$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:104: d = ((char *)dst)+acount-1;
;	genPlus
	mov	a,_memmove_PARM_3
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
	mov	a,(_memmove_PARM_3 + 1)
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xff
	mov	r2,a
	mov	a,r6
	addc	a,#0xff
	mov	r3,a
	mov	ar4,r7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:105: s = ((char *)src)+acount-1;
;	genPlus
	mov	a,_memmove_PARM_3
	add	a,_memmove_PARM_2
	mov	r0,a
	mov	a,(_memmove_PARM_3 + 1)
	addc	a,(_memmove_PARM_2 + 1)
	mov	r1,a
	mov	r5,(_memmove_PARM_2 + 2)
;	genMinus
;	genMinusDec
	mov	a,r0
	add	a,#0xff
	mov	r7,a
	mov	a,r1
	addc	a,#0xff
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:106: while (acount--) {
;	genAssign
;	genAssign
	mov	_memmove_sloc1_1_0,r2
	mov	(_memmove_sloc1_1_0 + 1),r3
	mov	(_memmove_sloc1_1_0 + 2),r4
;	genAssign
	mov	r2,_memmove_PARM_3
	mov	r3,(_memmove_PARM_3 + 1)
00101$:
;	genAssign
	mov	ar0,r2
	mov	ar1,r3
;	genMinus
;	genMinusDec
	dec	r2
	cjne	r2,#0xff,00123$
	dec	r3
00123$:
;	genIfx
	mov	a,r0
	orl	a,r1
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00124$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:107: *d-- = *s--;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r6
	mov	b,r5
	lcall	__gptrget
	mov	r0,a
;	genMinus
;	genMinusDec
	dec	r7
	cjne	r7,#0xff,00125$
	dec	r6
00125$:
;	genPointerSet
;	genGenPointerSet
	mov	dpl,_memmove_sloc1_1_0
	mov	dph,(_memmove_sloc1_1_0 + 1)
	mov	b,(_memmove_sloc1_1_0 + 2)
	mov	a,r0
	lcall	__gptrput
;	genMinus
;	genMinusDec
;	tail decrement optimized (range 7)
	dec	_memmove_sloc1_1_0
	mov	a,#0xff
	cjne	a,_memmove_sloc1_1_0,00101$
	dec	(_memmove_sloc1_1_0 + 1)
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:115: s = src;
;	genAssign
	mov	r5,_memmove_PARM_2
	mov	r6,(_memmove_PARM_2 + 1)
	mov	r7,(_memmove_PARM_2 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:116: while (acount--) {
;	genAssign
	mov	_memmove_s_1_1,r5
	mov	(_memmove_s_1_1 + 1),r6
	mov	(_memmove_s_1_1 + 2),r7
;	genAssign
;	genAssign
	mov	r0,_memmove_PARM_3
	mov	r1,(_memmove_PARM_3 + 1)
00104$:
;	genAssign
	mov	ar5,r0
	mov	ar6,r1
;	genMinus
;	genMinusDec
	dec	r0
	cjne	r0,#0xff,00126$
	dec	r1
00126$:
;	genIfx
	mov	a,r5
	orl	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:117: *d++ = *s++;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_memmove_s_1_1
	mov	dph,(_memmove_s_1_1 + 1)
	mov	b,(_memmove_s_1_1 + 2)
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	mov	_memmove_s_1_1,dpl
	mov	(_memmove_s_1_1 + 1),dph
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__gptrput
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:121: return(ret);
;	genRet
	mov	dpl,_memmove_ret_1_1
	mov	dph,(_memmove_ret_1_1 + 1)
	mov	b,(_memmove_ret_1_1 + 2)
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
