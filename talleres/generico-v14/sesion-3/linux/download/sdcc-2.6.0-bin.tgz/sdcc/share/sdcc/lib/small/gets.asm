;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:58 2006
;--------------------------------------------------------
	.module gets
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _gets
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_gets_str_1_1:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'gets'
;------------------------------------------------------------
;str                       Allocated with name '_gets_str_1_1'
;s                         Allocated to registers r5 r6 r7 
;c                         Allocated to registers r2 
;count                     Allocated to registers r0 r1 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:3: char * gets(const char *str) {
;	-----------------------------------------
;	 function gets
;	-----------------------------------------
_gets:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	_gets_str_1_1,dpl
	mov	(_gets_str_1_1 + 1),dph
	mov	(_gets_str_1_1 + 2),b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:4: char *s=str;
;	genAssign
	mov	r5,_gets_str_1_1
	mov	r6,(_gets_str_1_1 + 1)
	mov	r7,(_gets_str_1_1 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:6: unsigned int count=0;
;	genAssign
	mov	r0,#0x00
	mov	r1,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:8: while (1) {
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:9: c=getchar();
;	genCall
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_getchar
	mov	r2,dpl
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:10: switch(c) {
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x08,00118$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00118$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x0A,00119$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00119$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x0D,00120$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00120$:
	ljmp	00106$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:11: case '\b': // backspace
00101$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:12: if (count) {
;	genIfx
	mov	a,r0
	orl	a,r1
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:13: putchar ('\b');
;	genCall
	mov	dpl,#0x08
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_putchar
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:14: putchar (' ');
;	genCall
	mov	dpl,#0x20
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_putchar
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:15: putchar ('\b');
;	genCall
	mov	dpl,#0x08
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_putchar
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:16: s--;
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00122$
	dec	r6
00122$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:17: count--;
;	genMinus
;	genMinusDec
	dec	r0
	cjne	r0,#0xff,00123$
	dec	r1
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:19: break;
	ljmp	00109$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:21: case '\r': // CR or LF
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:22: putchar('\r');
;	genCall
	mov	dpl,#0x0D
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:23: putchar('\n');
;	genCall
	mov	dpl,#0x0A
	push	ar5
	push	ar6
	push	ar7
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:24: *s=0;
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:25: return str;
;	genRet
	mov	dpl,_gets_str_1_1
	mov	dph,(_gets_str_1_1 + 1)
	mov	b,(_gets_str_1_1 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:26: default:
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:27: *s++=c;
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r2
	lcall	__gptrput
	inc	dptr
	mov	r5,dpl
	mov	r6,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:28: count++;
;	genPlus
;     genPlusIncr
	inc	r0
	cjne	r0,#0x00,00124$
	inc	r1
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:29: putchar(c);
;	genCall
	mov	dpl,r2
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_putchar
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:31: }
	ljmp	00109$
;	Peephole 259.b	removed redundant label 00111$ and ret
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
