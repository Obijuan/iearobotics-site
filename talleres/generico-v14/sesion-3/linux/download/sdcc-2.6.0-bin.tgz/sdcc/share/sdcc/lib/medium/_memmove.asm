;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:07 2006
;--------------------------------------------------------
	.module _memmove
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memmove_PARM_3
	.globl _memmove_PARM_2
	.globl _memmove
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_memmove_sloc0_1_0::
	.ds 2
_memmove_sloc1_1_0::
	.ds 3
_memmove_sloc2_1_0::
	.ds 3
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_memmove_PARM_2:
	.ds 3
_memmove_PARM_3:
	.ds 2
_memmove_ret_1_1:
	.ds 3
_memmove_d_1_1:
	.ds 3
_memmove_s_1_1:
	.ds 3
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memmove'
;------------------------------------------------------------
;sloc0                     Allocated with name '_memmove_sloc0_1_0'
;sloc1                     Allocated with name '_memmove_sloc1_1_0'
;sloc2                     Allocated with name '_memmove_sloc2_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:35: void * memmove (
;	-----------------------------------------
;	 function memmove
;	-----------------------------------------
_memmove:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:96: void * ret = dst;
;	genAssign
	mov	r0,#_memmove_ret_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:100: if (((int)src < (int)dst) && ((((int)src)+acount) > (int)dst)) {
;	genCast
	mov	r0,#_memmove_PARM_2
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
;	genCast
	mov	_memmove_sloc0_1_0,r2
	mov	(_memmove_sloc0_1_0 + 1),r3
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r5
	subb	a,_memmove_sloc0_1_0
	mov	a,r6
	xrl	a,#0x80
	mov	b,(_memmove_sloc0_1_0 + 1)
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00121$
	ljmp	00108$
00121$:
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genPlus
	mov	r0,#_memmove_PARM_3
	movx	a,@r0
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r6,a
;	genAssign
	mov	r7,_memmove_sloc0_1_0
	mov	r2,(_memmove_sloc0_1_0 + 1)
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r7
	subb	a,r5
	mov	a,r2
	subb	a,r6
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 129.d	optimized condition
	pop	ar4
	pop	ar3
	pop	ar2
	jc	00122$
	ljmp	00108$
00122$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:104: d = ((char *)dst)+acount-1;
;	genPlus
	mov	r0,#_memmove_PARM_3
	movx	a,@r0
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xff
	mov	r2,a
	mov	a,r6
	addc	a,#0xff
	mov	r3,a
	mov	ar4,r7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:105: s = ((char *)src)+acount-1;
;	genPlus
	mov	r0,#_memmove_PARM_2
	mov	r1,#_memmove_PARM_3
	movx	a,@r1
	xch	a,b
	movx	a,@r0
	add	a,b
	mov	r5,a
	inc	r1
	movx	a,@r1
	xch	a,b
	inc	r0
	movx	a,@r0
	addc	a,b
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00123$
	dec	r6
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:106: while (acount--) {
;	genAssign
	mov	_memmove_sloc2_1_0,r5
	mov	(_memmove_sloc2_1_0 + 1),r6
	mov	(_memmove_sloc2_1_0 + 2),r7
;	genAssign
	mov	_memmove_sloc1_1_0,r2
	mov	(_memmove_sloc1_1_0 + 1),r3
	mov	(_memmove_sloc1_1_0 + 2),r4
;	genAssign
	mov	r0,#_memmove_PARM_3
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
00101$:
;	genAssign
	mov	ar5,r2
	mov	ar6,r3
;	genMinus
;	genMinusDec
	dec	r2
	cjne	r2,#0xff,00124$
	dec	r3
00124$:
;	genIfx
	mov	a,r5
	orl	a,r6
;	genIfxJump
	jnz	00125$
	ljmp	00109$
00125$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:107: *d-- = *s--;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_memmove_sloc2_1_0
	mov	dph,(_memmove_sloc2_1_0 + 1)
	mov	b,(_memmove_sloc2_1_0 + 2)
	lcall	__gptrget
	mov	r5,a
;	genMinus
;	genMinusDec
	dec	_memmove_sloc2_1_0
	mov	a,#0xff
	cjne	a,_memmove_sloc2_1_0,00126$
	dec	(_memmove_sloc2_1_0 + 1)
00126$:
;	genPointerSet
;	genGenPointerSet
	mov	dpl,_memmove_sloc1_1_0
	mov	dph,(_memmove_sloc1_1_0 + 1)
	mov	b,(_memmove_sloc1_1_0 + 2)
	mov	a,r5
	lcall	__gptrput
;	genMinus
;	genMinusDec
;	tail decrement optimized (range 7)
	dec	_memmove_sloc1_1_0
	mov	a,#0xff
	cjne	a,_memmove_sloc1_1_0,00101$
	dec	(_memmove_sloc1_1_0 + 1)
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:115: s = src;
;	genAssign
	mov	r0,#_memmove_PARM_2
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:116: while (acount--) {
;	genAssign
	mov	r0,#_memmove_s_1_1
	mov	a,r5
	movx	@r0,a
	inc	r0
	mov	a,r6
	movx	@r0,a
	inc	r0
	mov	a,r7
	movx	@r0,a
;	genAssign
	mov	r0,#_memmove_d_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
;	genAssign
	mov	r0,#_memmove_PARM_3
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
00104$:
;	genAssign
	mov	ar7,r5
	mov	ar2,r6
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00127$
	dec	r6
00127$:
;	genIfx
	mov	a,r7
	orl	a,r2
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:117: *d++ = *s++;
;	genPointerGet
;	genGenPointerGet
	mov	r0,#_memmove_s_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	dec	r0
	dec	r0
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
;	genPointerSet
;	genGenPointerSet
	mov	r0,#_memmove_d_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r2
	lcall	__gptrput
	inc	dptr
	dec	r0
	dec	r0
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:121: return(ret);
;	genRet
	mov	r0,#_memmove_ret_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
