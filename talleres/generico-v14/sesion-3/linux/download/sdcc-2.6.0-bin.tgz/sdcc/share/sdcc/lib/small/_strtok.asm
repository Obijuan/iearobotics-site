;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:57 2006
;--------------------------------------------------------
	.module _strtok
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strtok_PARM_2
	.globl _strtok
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_strtok_s_1_1:
	.ds 3
_strtok_PARM_2:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strtok'
;------------------------------------------------------------
;s                         Allocated with name '_strtok_s_1_1'
;control                   Allocated with name '_strtok_PARM_2'
;str                       Allocated to registers r2 r3 r4 
;s1                        Allocated to registers r2 r3 r4 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:31: char * strtok (
;	-----------------------------------------
;	 function strtok
;	-----------------------------------------
_strtok:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:38: if ( str )
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00130$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:39: s = str ;
;	genAssign
	mov	_strtok_s_1_1,r2
	mov	(_strtok_s_1_1 + 1),r3
	mov	(_strtok_s_1_1 + 2),r4
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:40: if ( !s )
;	genIfx
	mov	a,_strtok_s_1_1
	orl	a,(_strtok_s_1_1 + 1)
	orl	a,(_strtok_s_1_1 + 2)
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:41: return NULL;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	jnz	00108$
;	Peephole 300	removed redundant label 00131$
	mov	dptr,#0x0000
;	Peephole 256.d	loading b with zero from a
	mov	b,a
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:43: while (*s) {
00108$:
;	genAssign
	mov	r2,_strtok_s_1_1
	mov	r3,(_strtok_s_1_1 + 1)
	mov	r4,(_strtok_s_1_1 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00132$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:44: if (strchr(control,*s))
;	genAssign
	mov	r2,_strtok_s_1_1
	mov	r3,(_strtok_s_1_1 + 1)
	mov	r4,(_strtok_s_1_1 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	_strchr_PARM_2,a
;	genCall
	mov	dpl,_strtok_PARM_2
	mov	dph,(_strtok_PARM_2 + 1)
	mov	b,(_strtok_PARM_2 + 2)
	lcall	_strchr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00133$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:45: s++;
;	genPlus
;     genPlusIncr
;	tail increment optimized (range 9)
	inc	_strtok_s_1_1
	clr	a
	cjne	a,_strtok_s_1_1,00108$
	inc	(_strtok_s_1_1 + 1)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:47: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00108$
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:50: s1 = s ;
;	genAssign
	mov	r2,_strtok_s_1_1
	mov	r3,(_strtok_s_1_1 + 1)
	mov	r4,(_strtok_s_1_1 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:52: while (*s) {
00113$:
;	genAssign
	mov	r5,_strtok_s_1_1
	mov	r6,(_strtok_s_1_1 + 1)
	mov	r7,(_strtok_s_1_1 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00115$
;	Peephole 300	removed redundant label 00134$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:53: if (strchr(control,*s)) {
;	genAssign
	mov	r5,_strtok_s_1_1
	mov	r6,(_strtok_s_1_1 + 1)
	mov	r7,(_strtok_s_1_1 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	_strchr_PARM_2,a
;	genCall
	mov	dpl,_strtok_PARM_2
	mov	dph,(_strtok_PARM_2 + 1)
	mov	b,(_strtok_PARM_2 + 2)
	push	ar2
	push	ar3
	push	ar4
	lcall	_strchr
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	mov	a,r5
	orl	a,r6
	orl	a,r7
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00112$
;	Peephole 300	removed redundant label 00135$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:54: *s++ = '\0';
;	genAssign
	mov	r5,_strtok_s_1_1
	mov	r6,(_strtok_s_1_1 + 1)
	mov	r7,(_strtok_s_1_1 + 2)
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	genPlus
;     genPlusIncr
	inc	_strtok_s_1_1
	clr	a
	cjne	a,_strtok_s_1_1,00136$
	inc	(_strtok_s_1_1 + 1)
00136$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:55: return s1 ;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00112$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:57: s++ ;
;	genPlus
;     genPlusIncr
	inc	_strtok_s_1_1
	clr	a
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 243	avoided branch to sjmp
	cjne	a,_strtok_s_1_1,00113$
	inc	(_strtok_s_1_1 + 1)
;	Peephole 300	removed redundant label 00137$
	sjmp	00113$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:60: s = NULL;
;	genAssign
	clr	a
	mov	_strtok_s_1_1,a
	mov	(_strtok_s_1_1 + 1),a
	mov	(_strtok_s_1_1 + 2),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:62: if (*s1)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00138$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:63: return s1;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:65: return NULL;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
	mov	b,#0x00
;	Peephole 300	removed redundant label 00119$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
