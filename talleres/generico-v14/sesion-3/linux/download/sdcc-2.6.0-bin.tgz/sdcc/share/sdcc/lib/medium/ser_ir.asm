;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:11 2006
;--------------------------------------------------------
	.module ser_ir
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _PS
	.globl _PT1
	.globl _PX1
	.globl _PT0
	.globl _PX0
	.globl _RD
	.globl _WR
	.globl _T1
	.globl _T0
	.globl _INT1
	.globl _INT0
	.globl _TXD
	.globl _RXD
	.globl _P3_7
	.globl _P3_6
	.globl _P3_5
	.globl _P3_4
	.globl _P3_3
	.globl _P3_2
	.globl _P3_1
	.globl _P3_0
	.globl _EA
	.globl _ES
	.globl _ET1
	.globl _EX1
	.globl _ET0
	.globl _EX0
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _SM0
	.globl _SM1
	.globl _SM2
	.globl _REN
	.globl _TB8
	.globl _RB8
	.globl _TI
	.globl _RI
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _TF1
	.globl _TR1
	.globl _TF0
	.globl _TR0
	.globl _IE1
	.globl _IT1
	.globl _IE0
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _IP
	.globl _P3
	.globl _IE
	.globl _P2
	.globl _SBUF
	.globl _SCON
	.globl _P1
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _PCON
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _P0
	.globl _ser_gets_PARM_2
	.globl _ser_init
	.globl _ser_handler
	.globl _ser_putc
	.globl _ser_getc
	.globl _ser_puts
	.globl _ser_gets
	.globl _ser_can_xmt
	.globl _ser_can_rcv
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_busy:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_rbuf:
	.ds 8
_xbuf:
	.ds 4
_rcnt:
	.ds 1
_xcnt:
	.ds 1
_rpos:
	.ds 1
_xpos:
	.ds 1
_ser_gets_PARM_2:
	.ds 1
_ser_gets_s_1_1:
	.ds 3
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_init'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:48: void ser_init (void)
;	-----------------------------------------
;	 function ser_init
;	-----------------------------------------
_ser_init:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:50: ES = 0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:51: rcnt = xcnt = rpos = xpos = 0;  /* init buffers */
;	genAssign
	mov	r0,#_xpos
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	genAssign
	mov	r0,#_rpos
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	genAssign
	mov	r0,#_xcnt
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	genAssign
	mov	r0,#_rcnt
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:52: busy = 0;
;	genAssign
	clr	_busy
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:53: SCON = 0x50;
;	genAssign
	mov	_SCON,#0x50
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:54: PCON |= 0x80;                   /* SMOD = 1; */
;	genOr
	orl	_PCON,#0x80
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:55: TMOD &= 0x0f;                   /* use timer 1 */
;	genAnd
	anl	_TMOD,#0x0F
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:56: TMOD |= 0x20;
;	genOr
	orl	_TMOD,#0x20
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:57: TL1 = -3; TH1 = -3; TR1 = 1;    /* 19200bps with 11.059MHz crystal */
;	genAssign
	mov	_TL1,#0xFD
;	genAssign
	mov	_TH1,#0xFD
;	genAssign
	setb	_TR1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:58: ES = 1;
;	genAssign
	setb	_ES
;	Peephole 300	removed redundant label 00101$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_handler'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:61: void ser_handler (void) interrupt 4
;	-----------------------------------------
;	 function ser_handler
;	-----------------------------------------
_ser_handler:
	push	acc
	push	ar2
	push	ar0
	push	psw
	mov	psw,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:63: if (RI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:64: RI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_RI,00118$
	sjmp	00104$
00118$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:66: if (rcnt < RBUFLEN)
;	genCmpLt
	mov	r0,#_rcnt
;	genCmp
	movx	a,@r0
	cjne	a,#0x08,00119$
00119$:
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00104$
;	Peephole 300	removed redundant label 00120$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:67: rbuf [(unsigned char)(rpos+rcnt++) % RBUFLEN] = SBUF;
;	genAssign
	mov	r0,#_rcnt
	movx	a,@r0
	mov	r2,a
;	genPlus
	mov	r0,#_rcnt
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@r0,a
;	genPlus
	mov	r0,#_rpos
	movx	a,@r0
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	genAnd
	anl	a,#0x07
;	genPlus
	add	a,#_rbuf
;	genPointerSet
;	genPagedPointerSet
;	Peephole 239	used a instead of acc
	mov	r0,a
	mov	a,_SBUF
	movx	@r0,a
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:69: if (TI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:70: TI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_TI,00121$
	sjmp	00111$
00121$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:71: if (busy = xcnt) {   /* Assignment, _not_ comparison! */
;	genAssign
	mov	r0,#_xcnt
	movx	a,@r0
	add	a,#0xff
	mov	_busy,c
;	genIfx
	mov	r0,#_xcnt
	movx	a,@r0
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00111$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:72: xcnt--;
;	genMinus
	mov	r0,#_xcnt
;	genMinusDec
	movx	a,@r0
	dec	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:73: SBUF = xbuf [xpos++];
;	genAssign
	mov	r0,#_xpos
	movx	a,@r0
	mov	r2,a
;	genPlus
	mov	r0,#_xpos
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@r0,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,#_xbuf
	mov	r0,a
;	genPointerGet
;	genPagedPointerGet
	movx	a,@r0
	mov	_SBUF,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:74: if (xpos >= XBUFLEN)
;	genCmpLt
	mov	r0,#_xpos
;	genCmp
	movx	a,@r0
	cjne	a,#0x04,00123$
00123$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00111$
;	Peephole 300	removed redundant label 00124$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:75: xpos = 0;
;	genAssign
	mov	r0,#_xpos
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
00111$:
	pop	psw
	pop	ar0
	pop	ar2
	pop	acc
	reti
;	eliminated unneeded push/pop ar1
;	eliminated unneeded push/pop dpl
;	eliminated unneeded push/pop dph
;	eliminated unneeded push/pop b
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_putc'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:80: void ser_putc (unsigned char c)
;	-----------------------------------------
;	 function ser_putc
;	-----------------------------------------
_ser_putc:
;	genReceive
	mov	r2,dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:82: while (xcnt >= XBUFLEN) /* wait for room in buffer */
00101$:
;	genCmpLt
	mov	r0,#_xcnt
;	genCmp
	movx	a,@r0
	cjne	a,#0x04,00112$
00112$:
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00101$
;	Peephole 300	removed redundant label 00113$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:84: ES = 0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:85: if (busy) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_busy,00105$
;	Peephole 300	removed redundant label 00114$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:86: xbuf[(unsigned char)(xpos+xcnt++) % XBUFLEN] = c;
;	genAssign
	mov	r0,#_xcnt
	movx	a,@r0
	mov	r3,a
;	genPlus
	mov	r0,#_xcnt
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@r0,a
;	genPlus
	mov	r0,#_xpos
	movx	a,@r0
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
;	genAnd
	anl	a,#0x03
;	genPlus
	add	a,#_xbuf
;	genPointerSet
;	genPagedPointerSet
;	Peephole 239	used a instead of acc
	mov	r0,a
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00106$
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:88: SBUF = c;
;	genAssign
	mov	_SBUF,r2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:89: busy = 1;
;	genAssign
	setb	_busy
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:91: ES = 1;
;	genAssign
	setb	_ES
;	Peephole 300	removed redundant label 00107$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_getc'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:94: unsigned char ser_getc (void)
;	-----------------------------------------
;	 function ser_getc
;	-----------------------------------------
_ser_getc:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:97: while (!rcnt)   /* wait for character */
00101$:
;	genIfx
	mov	r0,#_rcnt
	movx	a,@r0
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00101$
;	Peephole 300	removed redundant label 00111$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:99: ES = 0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:100: rcnt--;
;	genMinus
	mov	r0,#_rcnt
;	genMinusDec
	movx	a,@r0
	dec	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:101: c = rbuf [rpos++];
;	genAssign
	mov	r0,#_rpos
	movx	a,@r0
	mov	r2,a
;	genPlus
	mov	r0,#_rpos
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@r0,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,#_rbuf
	mov	r0,a
;	genPointerGet
;	genPagedPointerGet
	movx	a,@r0
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:102: if (rpos >= RBUFLEN)
;	genCmpLt
	mov	r0,#_rpos
;	genCmp
	movx	a,@r0
	cjne	a,#0x08,00112$
00112$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00105$
;	Peephole 300	removed redundant label 00113$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:103: rpos = 0;
;	genAssign
	mov	r0,#_rpos
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:104: ES = 1;
;	genAssign
	setb	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:105: return (c);
;	genRet
	mov	dpl,r2
;	Peephole 300	removed redundant label 00106$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_puts'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:109: void ser_puts (unsigned char *s)
;	-----------------------------------------
;	 function ser_puts
;	-----------------------------------------
_ser_puts:
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:112: while (c=*s++) {
00103$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;	genAssign
;	genIfx
;	peephole 177.h	optimized mov sequence
	mov	a,r5
;	Peephole 236.i	used r6 instead of ar6
	mov	r6,a
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00106$
;	Peephole 300	removed redundant label 00111$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:113: if (c == '\n') ser_putc ('\r');
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r6,#0x0A,00102$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00112$
;	Peephole 300	removed redundant label 00113$
;	genCall
	mov	dpl,#0x0D
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	lcall	_ser_putc
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:114: ser_putc (c);
;	genCall
	mov	dpl,r6
	push	ar2
	push	ar3
	push	ar4
	lcall	_ser_putc
	pop	ar4
	pop	ar3
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00106$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_gets'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:118: void ser_gets (unsigned char *s, unsigned char len)
;	-----------------------------------------
;	 function ser_gets
;	-----------------------------------------
_ser_gets:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	r0,#_ser_gets_s_1_1
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r2
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:123: while (pos <= len) {
;	genAssign
	mov	r5,#0x00
00105$:
;	genCmpGt
	mov	r0,#_ser_gets_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	subb	a,r5
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00107$
;	Peephole 300	removed redundant label 00114$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:124: c = ser_getc ();
;	genCall
	push	ar5
	lcall	_ser_getc
	mov	r6,dpl
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:125: if (c == '\r') continue;        /* discard CR's */
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x0D,00115$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:126: s[pos++] = c;
;	genAssign
	mov	ar7,r5
;	genPlus
;     genPlusIncr
	inc	r5
;	genPlus
	mov	r0,#_ser_gets_s_1_1
	movx	a,@r0
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	mov	r7,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	mov	a,r6
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:127: if (c == '\n') break;           /* NL terminates */
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r6,#0x0A,00105$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00116$
;	Peephole 300	removed redundant label 00117$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:129: s[pos] = '\0';
;	genPlus
	mov	r0,#_ser_gets_s_1_1
	movx	a,@r0
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r5
	mov	dph,r2
	mov	b,r3
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__gptrput
;
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_can_xmt'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:132: unsigned char ser_can_xmt (void)
;	-----------------------------------------
;	 function ser_can_xmt
;	-----------------------------------------
_ser_can_xmt:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:134: return XBUFLEN - xcnt;
;	genMinus
	mov	r0,#_xcnt
	setb	c
	movx	a,@r0
	subb	a,#0x04
	cpl	a
;	genRet
;	Peephole 234.a	loading dpl directly from a(ccumulator), r2 not set
	mov	dpl,a
;	Peephole 300	removed redundant label 00101$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_can_rcv'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:137: unsigned char ser_can_rcv (void)
;	-----------------------------------------
;	 function ser_can_rcv
;	-----------------------------------------
_ser_can_rcv:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/ser_ir.c:139: return rcnt;
;	genRet
	mov	r0,#_rcnt
	movx	a,@r0
	mov	dpl,a
;	Peephole 300	removed redundant label 00101$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
