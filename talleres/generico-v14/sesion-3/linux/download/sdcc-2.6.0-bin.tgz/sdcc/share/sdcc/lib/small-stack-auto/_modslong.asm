;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:02 2006
;--------------------------------------------------------
	.module _modslong
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modslong_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modslong.c:149: _modslong_dummy (void) _naked
;	-----------------------------------------
;	 function _modslong_dummy
;	-----------------------------------------
__modslong_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modslong.c:240: mov	a1,a
;	genInline
;	# 163 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modslong.c"
	                ar2 = 2 ; BUG register set is not considered
	                ar3 = 3
	                ar4 = 4
	                ar5 = 5
	                .globl __modslong
        __modslong:
	                                        ; r1 in acc
	                mov r1,a ; save r1
	                clr F0 ; F0 (Flag 0)
	                                        ; available to user for general purpose
	                jnb acc.7,a_not_negative
	                setb F0
	                clr a ; a = -a;
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r1
	                mov r1,a
        a_not_negative:
	                mov a,sp
	                add a,#-2-3 ; 2 bytes return address, 3 bytes param b
	                mov r0,a ; r1 points to r2
	                mov ar2,@r0 ; load r2
	                inc r0 ; r0 points to r3
	                mov ar3,@r0 ; r3
	                inc r0
	                mov ar4,@r0 ; r4
	                inc r0
	                mov a,@r0 ; r5
	                mov r5,a
	                jnb acc.7,b_not_negative
	                clr a ; b = -b;
	                clr c
	                subb a,r2
	                mov r2,a
	                clr a
	                subb a,r3
	                mov r3,a
	                clr a
	                subb a,r4
	                mov r4,a
	                clr a
	                subb a,r5
	                mov r5,a
        b_not_negative:
	                lcall __modlong
	                jnb F0,not_negative
	                                ; result in (a == r1), b, dph, dpl
	                clr a
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r1 ; result in a, b, dph, dpl
        not_negative:
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
