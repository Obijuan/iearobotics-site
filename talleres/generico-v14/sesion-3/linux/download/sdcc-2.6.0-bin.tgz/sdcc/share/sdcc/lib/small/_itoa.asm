;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:55 2006
;--------------------------------------------------------
	.module _itoa
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __itoa
	.globl __uitoa
	.globl __itoa_PARM_3
	.globl __itoa_PARM_2
	.globl __uitoa_PARM_3
	.globl __uitoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__uitoa_PARM_2:
	.ds 3
__uitoa_PARM_3:
	.ds 1
__uitoa_value_1_1:
	.ds 2
__itoa_PARM_2:
	.ds 3
__itoa_PARM_3:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_uitoa'
;------------------------------------------------------------
;string                    Allocated with name '__uitoa_PARM_2'
;radix                     Allocated with name '__uitoa_PARM_3'
;value                     Allocated with name '__uitoa_value_1_1'
;index                     Allocated to registers r3 
;i                         Allocated to registers r2 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:18: void _uitoa(unsigned int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _uitoa
;	-----------------------------------------
__uitoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	__uitoa_value_1_1,dpl
	mov	(__uitoa_value_1_1 + 1),dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:26: do {
;	genAssign
	mov	r3,#0x10
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:27: string[--index] = '0' + (value % radix);
;	genMinus
;	genMinusDec
	dec	r3
;	genPlus
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	add	a,__uitoa_PARM_2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(__uitoa_PARM_2 + 1)
	mov	r6,a
	mov	r7,(__uitoa_PARM_2 + 2)
;	genCast
	mov	r0,__uitoa_PARM_3
	mov	r1,#0x00
;	genAssign
	mov	__moduint_PARM_2,r0
	mov	(__moduint_PARM_2 + 1),r1
;	genCall
	mov	dpl,__uitoa_value_1_1
	mov	dph,(__uitoa_value_1_1 + 1)
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	__moduint
	mov	r4,dpl
	mov	r2,dph
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
;	genCast
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
;	genPointerSet
;	genGenPointerSet
	mov	r4,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 191	removed redundant mov
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00117$
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	genPointerSet
;	genGenPointerSet
	mov	r2,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 191	removed redundant mov
	lcall	__gptrput
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:29: value /= radix;
;	genAssign
	mov	__divuint_PARM_2,r0
	mov	(__divuint_PARM_2 + 1),r1
;	genCall
	mov	dpl,__uitoa_value_1_1
	mov	dph,(__uitoa_value_1_1 + 1)
	push	ar3
	lcall	__divuint
	mov	__uitoa_value_1_1,dpl
	mov	(__uitoa_value_1_1 + 1),dph
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:30: } while (value != 0);
;	genCmpEq
;	gencjneshort
	mov	a,__uitoa_value_1_1
	jnz	00118$
	mov	a,(__uitoa_value_1_1 + 1)
;	Peephole 160.c	removed sjmp by inverse jump logic
	jz	00119$
00118$:
	ljmp	00103$
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:32: do {
;	genAssign
	mov	r2,#0x00
;	genAssign
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:33: string[i++] = string[index++];
;	genAssign
	mov	ar4,r2
;	genPlus
;     genPlusIncr
	inc	r2
;	genPlus
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	add	a,__uitoa_PARM_2
	mov	r4,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(__uitoa_PARM_2 + 1)
	mov	r5,a
	mov	r6,(__uitoa_PARM_2 + 2)
;	genAssign
	mov	ar7,r3
;	genPlus
;     genPlusIncr
	inc	r3
;	genPlus
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	add	a,__uitoa_PARM_2
	mov	r7,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(__uitoa_PARM_2 + 1)
	mov	r0,a
	mov	r1,(__uitoa_PARM_2 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r0
	mov	b,r1
	lcall	__gptrget
;	genPointerSet
;	genGenPointerSet
	mov	r7,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
;	Peephole 191	removed redundant mov
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:34: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt
;	genCmp
	cjne	r3,#0x10,00120$
00120$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00106$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:36: string[i] = 0; /* string terminator */
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,__uitoa_PARM_2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(__uitoa_PARM_2 + 1)
	mov	r3,a
	mov	r4,(__uitoa_PARM_2 + 2)
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__gptrput
;
;------------------------------------------------------------
;Allocation info for local variables in function '_itoa'
;------------------------------------------------------------
;string                    Allocated with name '__itoa_PARM_2'
;radix                     Allocated with name '__itoa_PARM_3'
;value                     Allocated to registers r2 r3 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:39: void _itoa(int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _itoa
;	-----------------------------------------
__itoa:
;	genReceive
	mov	r2,dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:41: if (value < 0 && radix == 10) {
;	genCmpLt
;	genCmp
;	peephole 177.g	optimized mov sequence
	mov	a,dph
	mov	r3,a
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00102$
;	Peephole 300	removed redundant label 00108$
;	genCmpEq
;	gencjneshort
	mov	a,__itoa_PARM_3
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	a,#0x0A,00102$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00109$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:42: *string++ = '-';
;	genAssign
	mov	r4,__itoa_PARM_2
	mov	r5,(__itoa_PARM_2 + 1)
	mov	r6,(__itoa_PARM_2 + 2)
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	__itoa_PARM_2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	(__itoa_PARM_2 + 1),a
	mov	(__itoa_PARM_2 + 2),r6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:43: value = -value;
;	genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:45: _uitoa(value, string, radix);
;	genAssign
	mov	__uitoa_PARM_2,__itoa_PARM_2
	mov	(__uitoa_PARM_2 + 1),(__itoa_PARM_2 + 1)
	mov	(__uitoa_PARM_2 + 2),(__itoa_PARM_2 + 2)
;	genAssign
	mov	__uitoa_PARM_3,__itoa_PARM_3
;	genCall
	mov	dpl,r2
	mov	dph,r3
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__uitoa
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
