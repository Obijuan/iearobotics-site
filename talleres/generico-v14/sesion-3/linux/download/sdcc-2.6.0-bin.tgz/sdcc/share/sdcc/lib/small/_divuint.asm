;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:53 2006
;--------------------------------------------------------
	.module _divuint
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divuint_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c:47: _divuint_dummy (void) _naked
;	-----------------------------------------
;	 function _divuint_dummy
;	-----------------------------------------
__divuint_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c:108: clr	a
;	genInline
	                .globl __divuint
        __divuint:
;	# 89 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c"
	                .area OSEG (OVR,DATA)
	                .globl __divuint_PARM_2
	                .globl __divsint_PARM_2
        __divuint_PARM_2:
        __divsint_PARM_2:
	                .ds 2
	                .area CSEG (CODE)
	                mov r2,#16
	                clr a
	                mov r3,a
	                mov r4,a
        loop:
	mov a,dpl ; x <<= 1
	                add a,acc
	                mov dpl,a
	                mov a,dph
	                rlc a
	                mov dph,a
	                mov a,r3 ; reste <<= 1
	                rlc a ; feed in carry
	                mov r3,a
	                mov a,r4
	                rlc a
	                mov r4,a
	                mov a,r3 ; reste - y
	                subb a,(__divuint_PARM_2) ; here carry is always clear, because
	                                        ; reste <<= 1 never overflows
	                mov b,a
	                mov a,r4
	                subb a,(__divuint_PARM_2 + 1)
	                jc smaller ; reste >= y?
	                mov r4,a ; -> yes; reste = reste - y;
	                mov r3,b
	                orl dpl,#1
        smaller:
; -> no
	                djnz r2,loop
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
