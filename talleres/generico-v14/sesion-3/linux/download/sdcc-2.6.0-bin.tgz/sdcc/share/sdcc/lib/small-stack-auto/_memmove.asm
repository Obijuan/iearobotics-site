;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:02 2006
;--------------------------------------------------------
	.module _memmove
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memmove
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memmove'
;------------------------------------------------------------
;src                       Allocated to stack - offset -5
;acount                    Allocated to stack - offset -7
;dst                       Allocated to registers r2 r3 r4 
;ret                       Allocated to stack - offset 1
;d                         Allocated to stack - offset 4
;s                         Allocated to stack - offset 7
;sloc0                     Allocated to stack - offset 10
;sloc1                     Allocated to stack - offset 12
;sloc2                     Allocated to stack - offset 15
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:35: void * memmove (
;	-----------------------------------------
;	 function memmove
;	-----------------------------------------
_memmove:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
;	peephole 177.h	optimized mov sequence
	mov	a,sp
	mov	_bp,a
	add	a,#0x11
	mov	sp,a
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:96: void * ret = dst;
;	genAssign
	mov	r0,_bp
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:100: if (((int)src < (int)dst) && ((((int)src)+acount) > (int)dst)) {
;	genCast
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;	genCast
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	genCmpLt
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genCmp
	clr	c
	mov	a,r5
	subb	a,@r0
	mov	a,r6
	xrl	a,#0x80
	inc	r0
	mov	b,@r0
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00121$
	ljmp	00108$
00121$:
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genPlus
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	inc	r0
	mov	a,@r0
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r6,a
;	genAssign
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r7
	subb	a,r5
	mov	a,r2
	subb	a,r6
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 129.d	optimized condition
	pop	ar4
	pop	ar3
	pop	ar2
	jc	00122$
	ljmp	00108$
00122$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:104: d = ((char *)dst)+acount-1;
;	genPlus
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
	inc	r0
	mov	a,@r0
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xff
	mov	r2,a
	mov	a,r6
	addc	a,#0xff
	mov	r3,a
	mov	ar4,r7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:105: s = ((char *)src)+acount-1;
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
;	genPlus
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	a,@r0
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	inc	r0
	mov	a,@r0
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r6,a
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00123$
	dec	r6
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:106: while (acount--) {
;	genAssign
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
;	genAssign
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
00101$:
;	genAssign
	mov	ar5,r2
	mov	ar6,r3
;	genMinus
;	genMinusDec
	dec	r2
	cjne	r2,#0xff,00124$
	dec	r3
00124$:
;	genIfx
	mov	a,r5
	orl	a,r6
;	genIfxJump
	jnz	00125$
	ljmp	00109$
00125$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:107: *d-- = *s--;
;	genPointerGet
;	genGenPointerGet
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r5,a
;	genMinus
	mov	a,_bp
	add	a,#0x0f
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;	genPointerSet
;	genGenPointerSet
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	mov	a,r5
	lcall	__gptrput
;	genMinus
	mov	a,_bp
	add	a,#0x0c
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:115: s = src;
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:116: while (acount--) {
;	genAssign
	mov	a,_bp
	add	a,#0x07
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
;	genAssign
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
	inc	r0
	mov	@r0,ar4
;	genAssign
	mov	a,_bp
	add	a,#0xfffffff9
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
00104$:
;	genAssign
	mov	ar7,r5
	mov	ar2,r6
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00126$
	dec	r6
00126$:
;	genIfx
	mov	a,r7
	orl	a,r2
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:117: *d++ = *s++;
;	genPointerGet
;	genGenPointerGet
	mov	a,_bp
	add	a,#0x07
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	dec	r0
	dec	r0
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
;	genPointerSet
;	genGenPointerSet
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	mov	a,r2
	lcall	__gptrput
	inc	dptr
	dec	r0
	dec	r0
	mov	@r0,dpl
	inc	r0
	mov	@r0,dph
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_memmove.c:121: return(ret);
;	genRet
	mov	r0,_bp
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
;	Peephole 300	removed redundant label 00111$
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
