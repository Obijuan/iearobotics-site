;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:11 2006
;--------------------------------------------------------
	.module realloc
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc_PARM_2
	.globl _realloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_realloc_PARM_2:
	.ds 2
_realloc_p_1_1:
	.ds 3
_realloc_pthis_1_1:
	.ds 2
_realloc_pnew_1_1:
	.ds 2
_realloc_ret_1_1:
	.ds 2
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'realloc'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:67: void xdata * realloc (void * p, size_t size)
;	-----------------------------------------
;	 function realloc
;	-----------------------------------------
_realloc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	r0,#_realloc_p_1_1
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r2
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:75: pthis = _sdcc_find_memheader(p);
;	genCast
	mov	r0,#_realloc_p_1_1
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
;	genCall
	mov	dpl,r5
	mov	dph,r6
	lcall	__sdcc_find_memheader
	mov	r0,#_realloc_pthis_1_1
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:76: if (pthis)
;	genIfx
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
;	genIfxJump
	jnz	00124$
	ljmp	00114$
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
;	genCmpGt
	mov	r0,#_realloc_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,#0xFB
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,#0xFF
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00111$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
;	genAssign
	mov	r0,#_realloc_ret_1_1
	clr	a
	movx	@r0,a
	inc	r0
	movx	@r0,a
	ljmp	00115$
00111$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
;	genPlus
	mov	r0,#_realloc_PARM_2
	movx	a,@r0
	add	a,#0x04
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
;	genPointerGet
;	genFarPointerGet
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	genCast
	mov	ar3,r7
	mov	ar4,r2
;	genCast
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
;	genMinus
	mov	a,r3
	clr	c
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r3,a
	mov	a,r4
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	mov	r4,a
;	genCmpLt
	mov	r0,#_realloc_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r3
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r4
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00108$
;	Peephole 300	removed redundant label 00126$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:88: pthis->len = size;
;	genPlus
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	add	a,#0x02
	mov	dpl,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	dph,a
;	genPointerSet
;     genFarPointerSet
	mov	r0,#_realloc_PARM_2
	movx	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	movx	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:89: ret = p;
;	genCast
	mov	r0,#_realloc_p_1_1
	mov	r1,#_realloc_ret_1_1
	movx	a,@r0
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
	ljmp	00115$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:93: if ((_sdcc_prev_memheader) &&
;	genIfx
	mov	r0,#__sdcc_prev_memheader
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
;	genIfxJump
	jnz	00127$
	ljmp	00104$
00127$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:94: ((((unsigned int)pthis->next) -
;	genAssign
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
;	genCast
	mov	r0,#__sdcc_prev_memheader
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r7,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:96: _sdcc_prev_memheader->len) >= size))
;	genAssign
	mov	r0,#__sdcc_prev_memheader
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r7,a
	mov	a,r2
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	mov	r2,a
;	genCmpLt
	mov	r0,#_realloc_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r7
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r2
	subb	a,b
;	genIfxJump
	jnc	00128$
	ljmp	00104$
00128$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
;	genAssign
;	genPlus
;     genPlusIncr
	mov	dpl,r3
	mov	dph,r4
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPlus
	mov	r0,#_realloc_pnew_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@r0,a
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	r0
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:99: _sdcc_prev_memheader->next = pnew;
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	r0,#_realloc_pnew_1_1
	movx	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	movx	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:105: memmove(pnew, pthis, pthis->len);
;	genCast
	mov	r0,#_realloc_pnew_1_1
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	mov	r6,#0x0
;	genCast
	mov	r0,#_realloc_pthis_1_1
	mov	r1,#_memmove_PARM_2
	movx	a,@r0
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
	inc	r1
	mov	a,#0x0
	movx	@r1,a
;	genPlus
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	add	a,#0x02
	mov	dpl,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	dph,a
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	r0,#_memmove_PARM_3
	mov	a,r7
	movx	@r0,a
	inc	r0
	mov	a,r2
	movx	@r0,a
;	genCall
	mov	dpl,r3
	mov	dph,r4
	mov	b,r6
	lcall	_memmove
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:106: pnew->len = size;
;	genPlus
	mov	r0,#_realloc_pnew_1_1
	movx	a,@r0
	add	a,#0x02
	mov	dpl,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	dph,a
;	genPointerSet
;     genFarPointerSet
	mov	r0,#_realloc_PARM_2
	movx	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	movx	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:107: ret = MEM(pnew);
;	genPlus
	mov	r0,#_realloc_pnew_1_1
	mov	r1,#_realloc_ret_1_1
	movx	a,@r0
	add	a,#0x04
	movx	@r1,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	inc	r1
	movx	@r1,a
	ljmp	00115$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:111: ret = malloc(size - HEADER_SIZE);
;	genMinus
	mov	r0,#_realloc_PARM_2
;	genMinusDec
	movx	a,@r0
	add	a,#0xfc
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0xff
	mov	r3,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	_malloc
	mov	r0,#_realloc_ret_1_1
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:112: if (ret)
;	genIfx
	mov	r0,#_realloc_ret_1_1
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	orl	a,b
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00115$
;	Peephole 300	removed redundant label 00129$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:114: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
;	genCast
	mov	r0,#_realloc_ret_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	mov	r4,#0x0
;	genPlus
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	add	a,#0x04
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
;	genCast
	mov	r0,#_memcpy_PARM_2
	mov	a,r5
	movx	@r0,a
	inc	r0
	mov	a,r6
	movx	@r0,a
	inc	r0
	mov	a,#0x0
	movx	@r0,a
;	genPlus
	mov	r0,#_realloc_pthis_1_1
	movx	a,@r0
	add	a,#0x02
	mov	dpl,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	dph,a
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genMinus
	mov	r0,#_memcpy_PARM_3
;	genMinusDec
	mov	a,r5
	add	a,#0xfc
	movx	@r0,a
	mov	a,r6
	addc	a,#0xff
	inc	r0
	movx	@r0,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_memcpy
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:115: free(p);
;	genCall
	mov	r0,#_realloc_p_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	lcall	_free
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:123: ret = malloc(size);
;	genCall
	mov	r0,#_realloc_PARM_2
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	lcall	_malloc
	mov	r0,#_realloc_ret_1_1
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:126: return ret;
;	genRet
	mov	r0,#_realloc_ret_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
;	Peephole 300	removed redundant label 00116$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
