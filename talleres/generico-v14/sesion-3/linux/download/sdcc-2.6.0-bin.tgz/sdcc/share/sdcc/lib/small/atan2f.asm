;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:03 2006
;--------------------------------------------------------
	.module atan2f
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atan2f_PARM_2
	.globl _atan2f
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_atan2f_PARM_2:
	.ds 4
_atan2f_x_1_1:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atan2f'
;------------------------------------------------------------
;y                         Allocated with name '_atan2f_PARM_2'
;x                         Allocated with name '_atan2f_x_1_1'
;r                         Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:24: float atan2f(const float x, const float y)
;	-----------------------------------------
;	 function atan2f
;	-----------------------------------------
_atan2f:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	_atan2f_x_1_1,dpl
	mov	(_atan2f_x_1_1 + 1),dph
	mov	(_atan2f_x_1_1 + 2),b
	mov	(_atan2f_x_1_1 + 3),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:28: if ((x==0.0) && (y==0.0))
;	genIfx
	mov	a,_atan2f_x_1_1
	orl	a,(_atan2f_x_1_1 + 1)
	orl	a,(_atan2f_x_1_1 + 2)
	orl	a,(_atan2f_x_1_1 + 3)
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00102$
;	Peephole 300	removed redundant label 00121$
;	genIfx
	mov	a,_atan2f_PARM_2
	orl	a,(_atan2f_PARM_2 + 1)
	orl	a,(_atan2f_PARM_2 + 2)
	orl	a,(_atan2f_PARM_2 + 3)
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00102$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:30: errno=EDOM;
;	genAssign
	mov	_errno,#0x21
	clr	a
	mov	(_errno + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:31: return 0.0;
;	genRet
;	Peephole 3.a	changed mov to clr
;	Peephole 3.b	changed mov to clr
;	Peephole 182.d	used 16 bit load of dptr
	mov	dptr,#(0x00&0x00ff)
	clr	a
	mov	b,a
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:34: if(fabsf(y)>=fabsf(x))
;	genCall
	mov	dpl,_atan2f_PARM_2
	mov	dph,(_atan2f_PARM_2 + 1)
	mov	b,(_atan2f_PARM_2 + 2)
	mov	a,(_atan2f_PARM_2 + 3)
	lcall	_fabsf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
;	genCall
	mov	dpl,_atan2f_x_1_1
	mov	dph,(_atan2f_x_1_1 + 1)
	mov	b,(_atan2f_x_1_1 + 2)
	mov	a,(_atan2f_x_1_1 + 3)
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	_fabsf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fslt
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r2
;	genIfxJump
	jz	00123$
	ljmp	00107$
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:36: r=atanf(x/y);
;	genIpush
	push	_atan2f_PARM_2
	push	(_atan2f_PARM_2 + 1)
	push	(_atan2f_PARM_2 + 2)
	push	(_atan2f_PARM_2 + 3)
;	genCall
	mov	dpl,_atan2f_x_1_1
	mov	dph,(_atan2f_x_1_1 + 1)
	mov	b,(_atan2f_x_1_1 + 2)
	mov	a,(_atan2f_x_1_1 + 3)
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	_atanf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:37: if(y<0.0) r+=(x>=0?PI:-PI);
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_atan2f_PARM_2
	mov	dph,(_atan2f_PARM_2 + 1)
	mov	b,(_atan2f_PARM_2 + 2)
	mov	a,(_atan2f_PARM_2 + 3)
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	mov	a,r6
;	genIfxJump
	jnz	00124$
	ljmp	00108$
00124$:
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_atan2f_x_1_1
	mov	dph,(_atan2f_x_1_1 + 1)
	mov	b,(_atan2f_x_1_1 + 2)
	mov	a,(_atan2f_x_1_1 + 3)
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genNot
	mov	a,r6
	cjne	a,#0x01,00125$
00125$:
	clr	a
	rlc	a
;	genIfx
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00111$
;	Peephole 300	removed redundant label 00126$
;	genAssign
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0x49
	mov	r1,#0x40
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00112$
00111$:
;	genAssign
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0x49
	mov	r1,#0xC0
00112$:
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	ljmp	00108$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:41: r=-atanf(y/x);
;	genIpush
	push	_atan2f_x_1_1
	push	(_atan2f_x_1_1 + 1)
	push	(_atan2f_x_1_1 + 2)
	push	(_atan2f_x_1_1 + 3)
;	genCall
	mov	dpl,_atan2f_PARM_2
	mov	dph,(_atan2f_PARM_2 + 1)
	mov	b,(_atan2f_PARM_2 + 2)
	mov	a,(_atan2f_PARM_2 + 3)
	lcall	___fsdiv
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	_atanf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
;	genUminus
;	genUminusFloat
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	a,r1
	cpl	acc.7
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:42: r+=(x<0.0?-HALF_PI:HALF_PI);
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_atan2f_x_1_1
	mov	dph,(_atan2f_x_1_1 + 1)
	mov	b,(_atan2f_x_1_1 + 2)
	mov	a,(_atan2f_x_1_1 + 3)
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00113$
;	Peephole 300	removed redundant label 00127$
;	genAssign
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0xC9
	mov	r1,#0xBF
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00114$
00113$:
;	genAssign
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0xC9
	mov	r1,#0x3F
00114$:
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/atan2f.c:44: return r;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
;	Peephole 300	removed redundant label 00109$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
