;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:59 2006
;--------------------------------------------------------
	.module _atoi
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atoi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atoi'
;------------------------------------------------------------
;s                         Allocated to stack - offset 1
;rv                        Allocated to registers r5 r6 
;sign                      Allocated to registers r4 
;sloc0                     Allocated to stack - offset 7
;sloc1                     Allocated to stack - offset 4
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:25: int atoi(char * s)
;	-----------------------------------------
;	 function atoi
;	-----------------------------------------
_atoi:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	inc	sp
	inc	sp
	inc	sp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:27: register int rv=0; 
;	genAssign
	mov	r5,#0x00
	mov	r6,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:31: while (*s) {
;	genAssign
	mov	r0,_bp
	inc	r0
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
00107$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
;	genIfx
	mov	r4,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00133$
;	Peephole 300	removed redundant label 00135$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:32: if (*s <= '9' && *s >= '0')
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpLt
;	genCmp
	jc	00102$
;	Peephole 300	removed redundant label 00136$
;	Peephole 256.a	removed redundant clr c
	mov	a,r4
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00133$
;	Peephole 300	removed redundant label 00137$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:33: break;
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:34: if (*s == '-' || *s == '+') 
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r4,a
;	genCmpEq
;	gencjneshort
	cjne	r4,#0x2D,00138$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00138$:
;	genCmpEq
;	gencjneshort
	cjne	r4,#0x2B,00139$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00133$
00139$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:36: s++;
;	genPlus
;     genPlusIncr
	inc	r7
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 243	avoided branch to sjmp
	cjne	r7,#0x00,00107$
	inc	r2
;	Peephole 300	removed redundant label 00140$
	sjmp	00107$
00133$:
;	genAssign
	mov	r0,_bp
	inc	r0
	mov	@r0,ar7
	inc	r0
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:39: sign = (*s == '-');
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
	mov	r2,a
;	genCmpEq
;	gencjne
;	gencjneshort
;	Peephole 241.d	optimized compare
	clr	a
	cjne	r2,#0x2D,00141$
	inc	a
00141$:
;	Peephole 300	removed redundant label 00142$
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:40: if (*s == '-' || *s == '+') s++;
;	genIfx
	mov	r3,a
	mov	ar4,r3
;	Peephole 166	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00110$
;	Peephole 300	removed redundant label 00143$
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r2,#0x2B,00131$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00144$
;	Peephole 300	removed redundant label 00145$
00110$:
;	genPlus
	mov	r0,_bp
	inc	r0
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
;	genAssign
	mov	r0,_bp
	inc	r0
	mov	a,_bp
	add	a,#0x04
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
00115$:
;	genPointerGet
;	genGenPointerGet
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	__gptrget
;	genIfx
	mov	r3,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00146$
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r3
	xrl	a,#0x80
	subb	a,#0xb0
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
;	genCmpGt
;	genCmp
	jc	00117$
;	Peephole 300	removed redundant label 00147$
;	Peephole 256.a	removed redundant clr c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r3
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00117$
;	Peephole 300	removed redundant label 00148$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:43: rv = (rv * 10) + (*s - '0');
;	genIpush
	push	ar4
;	genIpush
	push	ar3
	mov	a,#0x0A
	push	acc
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
;	genCall
	mov	dpl,r5
	mov	dph,r6
	lcall	__mulint
	mov	r4,dpl
	mov	r2,dph
	dec	sp
	dec	sp
	pop	ar3
;	genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r7,a
;	genMinus
	mov	a,r3
	add	a,#0xd0
	mov	r3,a
	mov	a,r7
	addc	a,#0xff
	mov	r7,a
;	genPlus
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r4,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
;	Peephole 236.b	used r2 instead of ar2
	addc	a,r2
	mov	r2,a
;	genAssign
	mov	ar5,r4
	mov	ar6,r2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:44: s++;
;	genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	genIpop
	pop	ar4
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atoi.c:47: return (sign ? -rv : rv);
;	genIfx
	mov	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00120$
;	Peephole 300	removed redundant label 00149$
;	genUminus
	clr	c
	clr	a
	subb	a,r5
	mov	r2,a
	clr	a
	subb	a,r6
	mov	r3,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00120$:
;	genAssign
	mov	ar2,r5
	mov	ar3,r6
00121$:
;	genRet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 300	removed redundant label 00118$
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
