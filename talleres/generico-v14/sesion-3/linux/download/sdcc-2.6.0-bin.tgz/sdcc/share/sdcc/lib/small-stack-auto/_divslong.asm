;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:59 2006
;--------------------------------------------------------
	.module _divslong
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divslong_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:154: _divslong_dummy (void) _naked
;	-----------------------------------------
;	 function _divslong_dummy
;	-----------------------------------------
__divslong_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:249: _endasm ;
;	genInline
	                .globl __divslong
        __divslong:
	                                        ; r3 in acc
	                mov r3,a ; save r3
	                clr F0 ; Flag 0 in PSW
	                                        ; available to user for general purpose
	                jnb acc.7,a_not_negative
	                setb F0
	                clr a
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r3
	                mov r3,a
        a_not_negative:
	                mov a,sp
	                add a,#-2 ; 2 bytes return address
	                mov r0,a ; r0 points to y3
	                mov a,@r0 ; y3
	                jnb acc.7,b_not_negative
	                cpl F0
	                dec r0
	                dec r0
	                dec r0
	                clr a
	                clr c
	                subb a,@r0 ; y0
	                mov @r0,a
	                clr a
	                inc r0
	                subb a,@r0 ; y1
	                mov @r0,a
	                clr a
	                inc r0
	                subb a,@r0 ; y2
	                mov @r0,a
	                clr a
	                inc r0
	                subb a,@r0 ; y3
	                mov @r0,a
        b_not_negative:
	                dec r0
	                dec r0
	                dec r0 ; r0 points to y0
	                lcall __divlong
	                jnb F0,not_negative
	                mov r3,a ; save r3
	                clr a
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r3 ; r3 ends in acc
        not_negative:
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
