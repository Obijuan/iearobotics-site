;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:07 2006
;--------------------------------------------------------
	.module _ltoa
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __ltoa
	.globl __ultoa
	.globl __ltoa_PARM_3
	.globl __ltoa_PARM_2
	.globl __ultoa_PARM_3
	.globl __ultoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__ultoa_sloc0_1_0:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__ultoa_PARM_2:
	.ds 3
__ultoa_PARM_3:
	.ds 1
__ultoa_value_1_1:
	.ds 4
__ultoa_buffer_1_1:
	.ds 32
__ltoa_PARM_2:
	.ds 3
__ltoa_PARM_3:
	.ds 1
__ltoa_value_1_1:
	.ds 4
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_ultoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__ultoa_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:18: void _ultoa(unsigned long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ultoa
;	-----------------------------------------
__ultoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	r0,#__ultoa_value_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
	inc	r0
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:25: do {
;	genAssign
	mov	r4,#0x20
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:26: buffer[--index] = '0' + (value % radix);
;	genMinus
;	genMinusDec
	dec	r4
;	genPlus
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	add	a,#__ultoa_buffer_1_1
	mov	r0,a
;	genCast
	mov	r1,#__ultoa_PARM_3
	movx	a,@r1
	mov	__ultoa_sloc0_1_0,a
	mov	(__ultoa_sloc0_1_0 + 1),#0x00
	mov	(__ultoa_sloc0_1_0 + 2),#0x00
	mov	(__ultoa_sloc0_1_0 + 3),#0x00
;	genAssign
	mov	r1,#__modulong_PARM_2
	mov	a,__ultoa_sloc0_1_0
	movx	@r1,a
	inc	r1
	mov	a,(__ultoa_sloc0_1_0 + 1)
	movx	@r1,a
	inc	r1
	mov	a,(__ultoa_sloc0_1_0 + 2)
	movx	@r1,a
	inc	r1
	mov	a,(__ultoa_sloc0_1_0 + 3)
	movx	@r1,a
;	genCall
	mov	r1,#__ultoa_value_1_1
	movx	a,@r1
	mov	dpl,a
	inc	r1
	movx	a,@r1
	mov	dph,a
	inc	r1
	movx	a,@r1
	mov	b,a
	inc	r1
	movx	a,@r1
	push	ar4
	push	ar0
	lcall	__modulong
	mov	r7,dpl
	mov	r6,dph
	mov	r2,b
	mov	r3,a
	pop	ar0
	pop	ar4
;	genCast
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
;	genPointerSet
;	genPagedPointerSet
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
;	genPointerGet
;	genPagedPointerGet
	movx	a,@r0
	mov	r2,a
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00117$
;	genPointerGet
;	genPagedPointerGet
	movx	a,@r0
	mov	r2,a
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	genPointerSet
;	genPagedPointerSet
	movx	@r0,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:28: value /= radix;
;	genAssign
	mov	r0,#__divulong_PARM_2
	mov	a,__ultoa_sloc0_1_0
	movx	@r0,a
	inc	r0
	mov	a,(__ultoa_sloc0_1_0 + 1)
	movx	@r0,a
	inc	r0
	mov	a,(__ultoa_sloc0_1_0 + 2)
	movx	@r0,a
	inc	r0
	mov	a,(__ultoa_sloc0_1_0 + 3)
	movx	@r0,a
;	genCall
	mov	r0,#__ultoa_value_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	push	ar4
	lcall	__divulong
	mov	r0,#__ultoa_value_1_1
	push	acc
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
	inc	r0
	mov	a,b
	movx	@r0,a
	pop	acc
	inc	r0
	movx	@r0,a
	pop	ar4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:29: } while (value != 0);
;	genCmpEq
	mov	r0,#__ultoa_value_1_1
;	gencjneshort
	movx	a,@r0
	cjne	a,#0x00,00118$
	inc	r0
	movx	a,@r0
	cjne	a,#0x00,00118$
	inc	r0
	movx	a,@r0
	cjne	a,#0x00,00118$
	inc	r0
	movx	a,@r0
	cjne	a,#0x00,00118$
	sjmp	00119$
00118$:
	ljmp	00103$
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:31: do {
;	genAssign
	mov	ar2,r4
;	genAssign
	mov	r0,#__ultoa_PARM_2
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:32: *string++ = buffer[index++];
;	genAssign
	mov	ar6,r2
;	genPlus
;     genPlusIncr
	inc	r2
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,#__ultoa_buffer_1_1
	mov	r0,a
;	genPointerGet
;	genPagedPointerGet
	movx	a,@r0
;	genPointerSet
;	genGenPointerSet
	mov	r6,a
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;	Peephole 191	removed redundant mov
	lcall	__gptrput
	inc	dptr
	mov	r3,dpl
	mov	r4,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:33: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt
;	genCmp
	cjne	r2,#0x20,00120$
00120$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00106$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:35: *string = 0;  /* string terminator */
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__gptrput
;
;------------------------------------------------------------
;Allocation info for local variables in function '_ltoa'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:38: void _ltoa(long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ltoa
;	-----------------------------------------
__ltoa:
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	r0,#__ltoa_value_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
	inc	r0
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:40: if (value < 0 && radix == 10) {
;	genCmpLt
;	genCmp
;	Peephole 263.a	optimized loading const
	mov	r0,#(__ltoa_value_1_1 + 3)
	movx	a,@r0
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00102$
;	Peephole 300	removed redundant label 00108$
;	genCmpEq
	mov	r0,#__ltoa_PARM_3
;	gencjneshort
	movx	a,@r0
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	a,#0x0A,00102$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00109$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:41: *string++ = '-';
;	genAssign
	mov	r0,#__ltoa_PARM_2
	movx	a,@r0
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	inc	r0
	movx	a,@r0
	mov	r2,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus
	mov	r0,#__ltoa_PARM_2
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	movx	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	inc	r0
	movx	@r0,a
	inc	r0
	mov	a,r2
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:42: value = -value;
;	genUminus
	mov	r0,#__ltoa_value_1_1
	movx	a,@r0
	setb	c
	cpl	a
	addc	a,#0
	movx	@r0,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	movx	@r0,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	movx	@r0,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	movx	@r0,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ltoa.c:44: _ultoa(value, string, radix);
;	genAssign
	mov	r0,#__ltoa_PARM_2
	mov	r1,#__ultoa_PARM_2
	movx	a,@r0
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
;	genAssign
	mov	r0,#__ltoa_PARM_3
	mov	r1,#__ultoa_PARM_3
	movx	a,@r0
	movx	@r1,a
;	genCall
	mov	r0,#__ltoa_value_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__ultoa
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
