;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:05 2006
;--------------------------------------------------------
	.module realloc
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'realloc'
;------------------------------------------------------------
;size                      Allocated to stack - offset -4
;p                         Allocated to stack - offset 1
;pthis                     Allocated to stack - offset 4
;pnew                      Allocated to stack - offset 6
;ret                       Allocated to stack - offset 8
;sloc0                     Allocated to stack - offset 10
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:67: void xdata * realloc (void * p, size_t size)
;	-----------------------------------------
;	 function realloc
;	-----------------------------------------
_realloc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	push	b
	mov	a,sp
	add	a,#0x0b
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:125: }
;	genCritical
	setb	c
	jbc	ea,00124$
	clr	c
00124$:
	push	psw
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:75: pthis = _sdcc_find_memheader(p);
;	genCast
	mov	r0,_bp
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
;	genCall
	lcall	__sdcc_find_memheader
	mov	r5,dpl
	mov	r6,dph
;	genAssign
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	@r0,ar5
	inc	r0
	mov	@r0,ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:76: if (pthis)
;	genIfx
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;	genIfxJump
	jnz	00125$
	ljmp	00114$
00125$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
;	genCmpGt
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;	genCmp
	clr	c
	mov	a,#0xFB
	subb	a,@r0
	mov	a,#0xFF
	inc	r0
	subb	a,@r0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00111$
;	Peephole 300	removed redundant label 00126$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
;	genAssign
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	clr	a
	mov	@r0,a
	inc	r0
	mov	@r0,a
	ljmp	00115$
00111$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
;	genPointerGet
;	genFarPointerGet
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	genCast
	mov	ar3,r7
	mov	ar4,r2
;	genCast
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	ar5,@r0
	inc	r0
	mov	ar6,@r0
;	genMinus
	mov	a,r3
	clr	c
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r3,a
	mov	a,r4
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	mov	r4,a
;	genCmpLt
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;	genCmp
	clr	c
	mov	a,r3
	subb	a,@r0
	mov	a,r4
	inc	r0
	subb	a,@r0
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00108$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:88: pthis->len = size;
;	genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:89: ret = p;
;	genCast
	mov	r0,_bp
	inc	r0
	mov	a,_bp
	add	a,#0x08
	mov	r1,a
	mov	a,@r0
	mov	@r1,a
	inc	r0
	inc	r1
	mov	a,@r0
	mov	@r1,a
	ljmp	00115$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:93: if ((_sdcc_prev_memheader) &&
;	genIfx
	mov	a,__sdcc_prev_memheader
	orl	a,(__sdcc_prev_memheader + 1)
;	genIfxJump
	jnz	00128$
	ljmp	00104$
00128$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:94: ((((unsigned int)pthis->next) -
;	genAssign
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
;	genCast
	mov	r3,__sdcc_prev_memheader
	mov	r4,(__sdcc_prev_memheader + 1)
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r7,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:96: _sdcc_prev_memheader->len) >= size))
;	genPlus
;     genPlusIncr
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r7,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	genCmpLt
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;	genCmp
	clr	c
	mov	a,r7
	subb	a,@r0
	mov	a,r2
	inc	r0
	subb	a,@r0
;	genIfxJump
	jnc	00129$
	ljmp	00104$
00129$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
;	genPlus
;     genPlusIncr
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,__sdcc_prev_memheader
	mov	r2,a
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	addc	a,(__sdcc_prev_memheader + 1)
	mov	r3,a
;	genAssign
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:99: _sdcc_prev_memheader->next = pnew;
;	genAssign
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
;	genPointerSet
;     genFarPointerSet
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:105: memmove(pnew, pthis, pthis->len);
;	genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	movx	a,@dptr
	mov	@r0,a
	inc	dptr
	movx	a,@dptr
	inc	r0
	mov	@r0,a
;	genCast
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
	mov	ar6,@r0
	inc	r0
	mov	ar7,@r0
	mov	r2,#0x0
;	genCast
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	mov	r5,#0x0
;	genIpush
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	push	ar6
	push	ar7
	push	ar2
;	genCall
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	_memmove
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:106: pnew->len = size;
;	genPlus
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
;     genPlusIncr
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:107: ret = MEM(pnew);
;	genPlus
	mov	a,_bp
	add	a,#0x06
	mov	r0,a
	mov	a,_bp
	add	a,#0x08
	mov	r1,a
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	@r1,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	inc	r1
	mov	@r1,a
	ljmp	00115$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:111: ret = malloc(size - HEADER_SIZE);
;	genMinus
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xfc
	mov	dpl,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	dph,a
;	genCall
	lcall	_malloc
	mov	r2,dpl
	mov	r3,dph
;	genAssign
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:112: if (ret)
;	genIfx
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	mov	a,@r0
	inc	r0
	orl	a,@r0
;	genIfxJump
	jnz	00130$
	ljmp	00115$
00130$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:114: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
;	genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genMinus
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
;	genMinusDec
	mov	a,r2
	add	a,#0xfc
	mov	@r0,a
	mov	a,r3
	addc	a,#0xff
	inc	r0
	mov	@r0,a
;	genPlus
	mov	a,_bp
	add	a,#0x04
	mov	r0,a
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	r4,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	r5,a
;	genCast
	mov	r6,#0x0
;	genCast
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	mov	ar7,@r0
	inc	r0
	mov	ar2,@r0
	mov	r3,#0x0
;	genIpush
	mov	a,_bp
	add	a,#0x0a
	mov	r0,a
	mov	a,@r0
	push	acc
	inc	r0
	mov	a,@r0
	push	acc
;	genIpush
	push	ar4
	push	ar5
	push	ar6
;	genCall
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	_memcpy
	mov	a,sp
	add	a,#0xfb
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:115: free(p);
;	genCall
	mov	r0,_bp
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	r0
	mov	b,@r0
	lcall	_free
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:123: ret = malloc(size);
;	genCall
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	lcall	_malloc
	mov	r2,dpl
	mov	r3,dph
;	genAssign
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	mov	@r0,ar2
	inc	r0
	mov	@r0,ar3
00115$:
;     genEndCritical
	pop	psw
	mov	ea,c
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:126: return ret;
;	genRet
	mov	a,_bp
	add	a,#0x08
	mov	r0,a
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
;	Peephole 300	removed redundant label 00116$
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
