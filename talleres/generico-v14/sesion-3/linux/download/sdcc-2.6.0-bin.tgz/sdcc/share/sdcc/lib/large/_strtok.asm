;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:26 2006
;--------------------------------------------------------
	.module _strtok
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strtok_PARM_2
	.globl _strtok
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strtok_PARM_2:
	.ds 3
_strtok_str_1_1:
	.ds 3
_strtok_s_1_1:
	.ds 3
_strtok_s1_1_1:
	.ds 3
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strtok'
;------------------------------------------------------------
;control                   Allocated with name '_strtok_PARM_2'
;str                       Allocated with name '_strtok_str_1_1'
;s                         Allocated with name '_strtok_s_1_1'
;s1                        Allocated with name '_strtok_s1_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:31: char * strtok (
;	-----------------------------------------
;	 function strtok
;	-----------------------------------------
_strtok:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_strtok_str_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:38: if ( str )
;	genAssign
	mov	dptr,#_strtok_str_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00130$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:39: s = str ;
;	genAssign
	mov	dptr,#_strtok_s_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:40: if ( !s )
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:41: return NULL;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	jnz	00108$
;	Peephole 300	removed redundant label 00131$
	mov	dptr,#0x0000
;	Peephole 256.d	loading b with zero from a
	mov	b,a
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:43: while (*s) {
00108$:
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00132$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:44: if (strchr(control,*s))
;	genAssign
	mov	dptr,#_strtok_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign
	mov	dptr,#_strchr_PARM_2
	mov	a,r2
	movx	@dptr,a
;	genCall
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	_strchr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00133$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:45: s++;
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:47: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00108$
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:50: s1 = s ;
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign
	mov	dptr,#_strtok_s1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:52: while (*s) {
00113$:
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
	jnz	00134$
	ljmp	00115$
00134$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:53: if (strchr(control,*s)) {
;	genAssign
	mov	dptr,#_strtok_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign
	mov	dptr,#_strchr_PARM_2
	mov	a,r2
	movx	@dptr,a
;	genCall
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	_strchr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00112$
;	Peephole 300	removed redundant label 00135$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:54: *s++ = '\0';
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:55: return s1 ;
;	genAssign
	mov	dptr,#_strtok_s1_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00112$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:57: s++ ;
;	genAssign
	mov	dptr,#_strtok_s_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
	mov	dptr,#_strtok_s_1_1
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	ljmp	00113$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:60: s = NULL;
;	genAssign
	mov	dptr,#_strtok_s_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:62: if (*s1)
;	genAssign
	mov	dptr,#_strtok_s1_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00136$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:63: return s1;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strtok.c:65: return NULL;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
	mov	b,#0x00
;	Peephole 300	removed redundant label 00119$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
