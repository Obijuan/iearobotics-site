;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:05 2006
;--------------------------------------------------------
	.module free
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __sdcc_find_memheader
	.globl __sdcc_prev_memheader
	.globl _free
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__sdcc_prev_memheader::
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_sdcc_find_memheader'
;------------------------------------------------------------
;p                         Allocated to registers r2 r3 
;pthis                     Allocated to registers r2 r3 
;cur_header                Allocated to registers r4 r5 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:112: MEMHEADER xdata * _sdcc_find_memheader(void xdata * p)
;	-----------------------------------------
;	 function _sdcc_find_memheader
;	-----------------------------------------
__sdcc_find_memheader:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:117: if (!p)
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00102$
;	Peephole 300	removed redundant label 00113$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:118: return NULL;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:120: pthis -= 1; //to start of header
;	genMinus
;	genMinusDec
	mov	a,r2
	add	a,#0xfc
	mov	r2,a
	mov	a,r3
	addc	a,#0xff
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:121: cur_header = _sdcc_first_memheader;
;	genAssign
	mov	r4,__sdcc_first_memheader
	mov	r5,(__sdcc_first_memheader + 1)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:122: _sdcc_prev_memheader = NULL;
;	genAssign
	clr	a
	mov	__sdcc_prev_memheader,a
	mov	(__sdcc_prev_memheader + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:123: while (cur_header && pthis != cur_header)
00104$:
;	genIfx
	mov	a,r4
	orl	a,r5
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00106$
;	Peephole 300	removed redundant label 00114$
;	genCmpEq
;	gencjneshort
	mov	a,r2
	cjne	a,ar4,00115$
	mov	a,r3
	cjne	a,ar5,00115$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00106$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:125: _sdcc_prev_memheader = cur_header;
;	genAssign
	mov	__sdcc_prev_memheader,r4
	mov	(__sdcc_prev_memheader + 1),r5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:126: cur_header = cur_header->next;
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:128: return (cur_header);
;	genRet
	mov	dpl,r4
	mov	dph,r5
;	Peephole 300	removed redundant label 00107$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'free'
;------------------------------------------------------------
;p                         Allocated to registers r2 r3 r4 
;pthis                     Allocated to registers r2 r3 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:131: void free (void * p)
;	-----------------------------------------
;	 function free
;	-----------------------------------------
_free:
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:149: }
;	genCritical
	setb	c
	jbc	ea,00110$
	clr	c
00110$:
	push	psw
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:137: pthis = _sdcc_find_memheader(p);
;	genCast
	mov	dpl,r2
	mov	dph,r3
;	genCall
	lcall	__sdcc_find_memheader
	mov	r2,dpl
	mov	r3,dph
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:138: if (pthis) //For allocated pointers only!
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00105$
;	Peephole 300	removed redundant label 00111$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:140: if (!_sdcc_prev_memheader)
;	genIfx
	mov	a,__sdcc_prev_memheader
	orl	a,(__sdcc_prev_memheader + 1)
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00102$
;	Peephole 300	removed redundant label 00112$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:142: pthis->len = 0;
;	genPlus
;     genPlusIncr
	mov	dpl,r2
	mov	dph,r3
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/free.c:146: _sdcc_prev_memheader->next = pthis->next;
;	genAssign
	mov	r4,__sdcc_prev_memheader
	mov	r5,(__sdcc_prev_memheader + 1)
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
00105$:
;     genEndCritical
	pop	psw
	mov	ea,c
;	Peephole 300	removed redundant label 00106$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
