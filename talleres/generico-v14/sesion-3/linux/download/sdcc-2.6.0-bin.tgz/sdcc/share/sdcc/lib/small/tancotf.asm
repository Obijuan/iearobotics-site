;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:02 2006
;--------------------------------------------------------
	.module tancotf
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _tancotf
	.globl _tancotf_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_tancotf_PARM_2:
	.ds 2
_tancotf_x_1_1:
	.ds 4
_tancotf_f_1_1:
	.ds 4
_tancotf_g_1_1:
	.ds 4
_tancotf_xn_1_1:
	.ds 4
_tancotf_xden_1_1:
	.ds 4
_tancotf_n_1_1:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'tancotf'
;------------------------------------------------------------
;iscotan                   Allocated with name '_tancotf_PARM_2'
;x                         Allocated with name '_tancotf_x_1_1'
;f                         Allocated with name '_tancotf_f_1_1'
;g                         Allocated with name '_tancotf_g_1_1'
;xn                        Allocated with name '_tancotf_xn_1_1'
;xnum                      Allocated to registers r0 r1 r2 r3 
;xden                      Allocated with name '_tancotf_xden_1_1'
;n                         Allocated with name '_tancotf_n_1_1'
;sloc0                     Allocated with name '_tancotf_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:42: float tancotf(const float x, const int iscotan)
;	-----------------------------------------
;	 function tancotf
;	-----------------------------------------
_tancotf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:47: if (fabsf(x) > YMAX)
;	genCall
	mov	_tancotf_x_1_1,dpl
	mov	(_tancotf_x_1_1 + 1),dph
	mov	(_tancotf_x_1_1 + 2),b
	mov	(_tancotf_x_1_1 + 3),a
;	Peephole 238.b	removed 3 redundant moves
;	Peephole 191	removed redundant mov
	lcall	_fabsf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	mov	a,#0x08
	push	acc
	mov	a,#0xC9
	push	acc
	mov	a,#0x45
	push	acc
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsgt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:49: errno = ERANGE;
;	genAssign
	mov	_errno,#0x22
	clr	a
	mov	(_errno + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:50: return 0.0;
;	genRet
;	Peephole 3.a	changed mov to clr
;	Peephole 3.b	changed mov to clr
;	Peephole 182.d	used 16 bit load of dptr
	mov	dptr,#(0x00&0x00ff)
	clr	a
	mov	b,a
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:54: n=(x*TWO_O_PI+(x>0.0?0.5:-0.5)); /*works for +-x*/
;	genIpush
	mov	a,#0x83
	push	acc
	mov	a,#0xF9
	push	acc
	mov	a,#0x22
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,_tancotf_x_1_1
	mov	dph,(_tancotf_x_1_1 + 1)
	mov	b,(_tancotf_x_1_1 + 2)
	mov	a,(_tancotf_x_1_1 + 3)
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_tancotf_x_1_1
	mov	dph,(_tancotf_x_1_1 + 1)
	mov	b,(_tancotf_x_1_1 + 2)
	mov	a,(_tancotf_x_1_1 + 3)
	lcall	___fsgt
	mov	r2,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
;	genIfx
	mov	a,r2
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00117$
;	Peephole 300	removed redundant label 00126$
;	genAssign
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0x3F
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00118$
00117$:
;	genAssign
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0xBF
00118$:
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fs2sint
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:55: xn=n;
;	genCall
	mov	_tancotf_n_1_1,dpl
;	Peephole 177.d	removed redundant move
	mov  (_tancotf_n_1_1 + 1),dph
;	Peephole 177.a	removed redundant mov
	lcall	___sint2fs
	mov	_tancotf_xn_1_1,dpl
	mov	(_tancotf_xn_1_1 + 1),dph
	mov	(_tancotf_xn_1_1 + 2),b
	mov	(_tancotf_xn_1_1 + 3),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:57: xnum=(int)x;
;	genCall
	mov	dpl,_tancotf_x_1_1
	mov	dph,(_tancotf_x_1_1 + 1)
	mov	b,(_tancotf_x_1_1 + 2)
	mov	a,(_tancotf_x_1_1 + 3)
	lcall	___fs2sint
;	genCall
	mov	r0,dpl
;	Peephole 177.d	removed redundant move
	mov  r1,dph
;	Peephole 177.a	removed redundant mov
	lcall	___sint2fs
	mov	r0,dpl
	mov	r1,dph
	mov	r2,b
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:58: xden=x-xnum;
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
	push	ar0
	push	ar1
	push	ar2
	push	ar3
;	genCall
	mov	dpl,_tancotf_x_1_1
	mov	dph,(_tancotf_x_1_1 + 1)
	mov	b,(_tancotf_x_1_1 + 2)
	mov	a,(_tancotf_x_1_1 + 3)
	lcall	___fssub
	mov	_tancotf_xden_1_1,dpl
	mov	(_tancotf_xden_1_1 + 1),dph
	mov	(_tancotf_xden_1_1 + 2),b
	mov	(_tancotf_xden_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:59: f=((xnum-xn*C1)+xden)-xn*C2;
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0xC9
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,_tancotf_xn_1_1
	mov	dph,(_tancotf_xn_1_1 + 1)
	mov	b,(_tancotf_xn_1_1 + 2)
	mov	a,(_tancotf_xn_1_1 + 3)
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	genIpush
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;	genCall
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	mov	a,r3
	lcall	___fssub
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_tancotf_xden_1_1
	push	(_tancotf_xden_1_1 + 1)
	push	(_tancotf_xden_1_1 + 2)
	push	(_tancotf_xden_1_1 + 3)
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsadd
	mov	r2,dpl
	mov	r3,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
	mov	a,#0x22
	push	acc
	mov	a,#0xAA
	push	acc
	mov	a,#0xFD
	push	acc
	mov	a,#0x39
	push	acc
;	genCall
	mov	dpl,_tancotf_xn_1_1
	mov	dph,(_tancotf_xn_1_1 + 1)
	mov	b,(_tancotf_xn_1_1 + 2)
	mov	a,(_tancotf_xn_1_1 + 3)
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	genIpush
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r0
	mov	a,r1
	lcall	___fssub
	mov	_tancotf_f_1_1,dpl
	mov	(_tancotf_f_1_1 + 1),dph
	mov	(_tancotf_f_1_1 + 2),b
	mov	(_tancotf_f_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:61: if (fabsf(f) < EPS)
;	genCall
	mov	dpl,_tancotf_f_1_1
	mov	dph,(_tancotf_f_1_1 + 1)
	mov	b,(_tancotf_f_1_1 + 2)
	mov	a,(_tancotf_f_1_1 + 3)
	lcall	_fabsf
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x39
	push	acc
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fslt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00104$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:63: xnum = f;
;	genAssign
	mov	r0,_tancotf_f_1_1
	mov	r1,(_tancotf_f_1_1 + 1)
	mov	r2,(_tancotf_f_1_1 + 2)
	mov	r3,(_tancotf_f_1_1 + 3)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:64: xden = 1.0;
;	genAssign
	mov	_tancotf_xden_1_1,#0x00
	mov	(_tancotf_xden_1_1 + 1),#0x00
	mov	(_tancotf_xden_1_1 + 2),#0x80
	mov	(_tancotf_xden_1_1 + 3),#0x3F
	ljmp	00105$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:68: g = f*f;
;	genIpush
	push	_tancotf_f_1_1
	push	(_tancotf_f_1_1 + 1)
	push	(_tancotf_f_1_1 + 2)
	push	(_tancotf_f_1_1 + 3)
;	genCall
	mov	dpl,_tancotf_f_1_1
	mov	dph,(_tancotf_f_1_1 + 1)
	mov	b,(_tancotf_f_1_1 + 2)
	mov	a,(_tancotf_f_1_1 + 3)
	lcall	___fsmul
	mov	_tancotf_g_1_1,dpl
	mov	(_tancotf_g_1_1 + 1),dph
	mov	(_tancotf_g_1_1 + 2),b
	mov	(_tancotf_g_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:69: xnum = P(f,g);
;	genIpush
	mov	a,#0xB8
	push	acc
	mov	a,#0x33
	push	acc
	mov	a,#0xC4
	push	acc
	mov	a,#0xBD
	push	acc
;	genCall
	mov	dpl,_tancotf_g_1_1
	mov	dph,(_tancotf_g_1_1 + 1)
	mov	b,(_tancotf_g_1_1 + 2)
	mov	a,(_tancotf_g_1_1 + 3)
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_tancotf_f_1_1
	push	(_tancotf_f_1_1 + 1)
	push	(_tancotf_f_1_1 + 2)
	push	(_tancotf_f_1_1 + 3)
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_tancotf_f_1_1
	push	(_tancotf_f_1_1 + 1)
	push	(_tancotf_f_1_1 + 2)
	push	(_tancotf_f_1_1 + 3)
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsadd
	mov	r0,dpl
	mov	r1,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:70: xden = Q(g);
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
	mov	a,#0x75
	push	acc
	mov	a,#0x33
	push	acc
	mov	a,#0x1F
	push	acc
	mov	a,#0x3C
	push	acc
;	genCall
	mov	dpl,_tancotf_g_1_1
	mov	dph,(_tancotf_g_1_1 + 1)
	mov	b,(_tancotf_g_1_1 + 2)
	mov	a,(_tancotf_g_1_1 + 3)
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
	mov	a,#0xAF
	push	acc
	mov	a,#0xB7
	push	acc
	mov	a,#0xDB
	push	acc
	mov	a,#0xBE
	push	acc
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
	push	_tancotf_g_1_1
	push	(_tancotf_g_1_1 + 1)
	push	(_tancotf_g_1_1 + 2)
	push	(_tancotf_g_1_1 + 3)
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsmul
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar0
	push	ar1
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsadd
	mov	_tancotf_xden_1_1,dpl
	mov	(_tancotf_xden_1_1 + 1),dph
	mov	(_tancotf_xden_1_1 + 2),b
	mov	(_tancotf_xden_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar1
	pop	ar0
	pop	ar3
	pop	ar2
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:73: if(n&1)
;	genAnd
	mov	a,_tancotf_n_1_1
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.0,00113$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:76: if(iscotan) return (-xnum/xden);
;	genIfx
	mov	a,_tancotf_PARM_2
	orl	a,(_tancotf_PARM_2 + 1)
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00107$
;	Peephole 300	removed redundant label 00129$
;	genUminus
;	genUminusFloat
	mov	ar4,r0
	mov	ar5,r1
	mov	ar6,r2
	mov	a,r3
	cpl	acc.7
	mov	r7,a
;	genIpush
	push	_tancotf_xden_1_1
	push	(_tancotf_xden_1_1 + 1)
	push	(_tancotf_xden_1_1 + 2)
	push	(_tancotf_xden_1_1 + 3)
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsdiv
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genRet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:77: else return (-xden/xnum);
;	genUminus
;	genUminusFloat
	mov	r4,_tancotf_xden_1_1
	mov	r5,(_tancotf_xden_1_1 + 1)
	mov	r6,(_tancotf_xden_1_1 + 2)
	mov	a,(_tancotf_xden_1_1 + 3)
	cpl	acc.7
	mov	r7,a
;	genIpush
	push	ar0
	push	ar1
	push	ar2
	push	ar3
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
	lcall	___fsdiv
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genRet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00113$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:81: if(iscotan) return (xden/xnum);
;	genIfx
	mov	a,_tancotf_PARM_2
	orl	a,(_tancotf_PARM_2 + 1)
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00130$
;	genIpush
	push	ar0
	push	ar1
	push	ar2
	push	ar3
;	genCall
	mov	dpl,_tancotf_xden_1_1
	mov	dph,(_tancotf_xden_1_1 + 1)
	mov	b,(_tancotf_xden_1_1 + 2)
	mov	a,(_tancotf_xden_1_1 + 3)
	lcall	___fsdiv
	mov	r4,dpl
	mov	r5,dph
	mov	r6,b
	mov	r7,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genRet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,r7
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/tancotf.c:82: else return (xnum/xden);
;	genIpush
	push	_tancotf_xden_1_1
	push	(_tancotf_xden_1_1 + 1)
	push	(_tancotf_xden_1_1 + 2)
	push	(_tancotf_xden_1_1 + 3)
;	genCall
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	mov	a,r3
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
;	Peephole 300	removed redundant label 00115$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
