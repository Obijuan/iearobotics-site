;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:25 2006
;--------------------------------------------------------
	.module _ser
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _TF2
	.globl _EXF2
	.globl _RCLK
	.globl _TCLK
	.globl _EXEN2
	.globl _TR2
	.globl _C_T2
	.globl _CP_RL2
	.globl _T2CON_7
	.globl _T2CON_6
	.globl _T2CON_5
	.globl _T2CON_4
	.globl _T2CON_3
	.globl _T2CON_2
	.globl _T2CON_1
	.globl _T2CON_0
	.globl _PT2
	.globl _ET2
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _PS
	.globl _PT1
	.globl _PX1
	.globl _PT0
	.globl _PX0
	.globl _RD
	.globl _WR
	.globl _T1
	.globl _T0
	.globl _INT1
	.globl _INT0
	.globl _TXD
	.globl _RXD
	.globl _P3_7
	.globl _P3_6
	.globl _P3_5
	.globl _P3_4
	.globl _P3_3
	.globl _P3_2
	.globl _P3_1
	.globl _P3_0
	.globl _EA
	.globl _ES
	.globl _ET1
	.globl _EX1
	.globl _ET0
	.globl _EX0
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _SM0
	.globl _SM1
	.globl _SM2
	.globl _REN
	.globl _TB8
	.globl _RB8
	.globl _TI
	.globl _RI
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _TF1
	.globl _TR1
	.globl _TF0
	.globl _TR0
	.globl _IE1
	.globl _IT1
	.globl _IE0
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _TH2
	.globl _TL2
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _T2CON
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _IP
	.globl _P3
	.globl _IE
	.globl _P2
	.globl _SBUF
	.globl _SCON
	.globl _P1
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _PCON
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _P0
	.globl _ser_rxBuffer
	.globl _ser_txBuffer
	.globl _ser_rxIndexOut
	.globl _ser_rxIndexIn
	.globl _ser_txIndexOut
	.globl _ser_txIndexIn
	.globl _ser_init
	.globl _ser_interrupt_handler
	.globl _ser_putc
	.globl _ser_getc
	.globl _ser_printString
	.globl _ser_charAvail
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_T2CON	=	0x00c8
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_TL2	=	0x00cc
_TH2	=	0x00cd
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_ET2	=	0x00ad
_PT2	=	0x00bd
_T2CON_0	=	0x00c8
_T2CON_1	=	0x00c9
_T2CON_2	=	0x00ca
_T2CON_3	=	0x00cb
_T2CON_4	=	0x00cc
_T2CON_5	=	0x00cd
_T2CON_6	=	0x00ce
_T2CON_7	=	0x00cf
_CP_RL2	=	0x00c8
_C_T2	=	0x00c9
_TR2	=	0x00ca
_EXEN2	=	0x00cb
_TCLK	=	0x00cc
_RCLK	=	0x00cd
_EXF2	=	0x00ce
_TF2	=	0x00cf
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_1	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ser_txBusy:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_ser_txIndexIn::
	.ds 1
_ser_txIndexOut::
	.ds 1
_ser_rxIndexIn::
	.ds 1
_ser_rxIndexOut::
	.ds 1
_ser_txBuffer::
	.ds 256
_ser_rxBuffer::
	.ds 256
_ser_putc_c_1_1:
	.ds 1
_ser_getc_tmp_1_1:
	.ds 1
_ser_printString_String_1_1:
	.ds 3
_ser_charAvail_ret_1_1:
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_init'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:49: ser_init(void)
;	-----------------------------------------
;	 function ser_init
;	-----------------------------------------
_ser_init:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:51: ES = 0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:53: ser_txBusy     = 0;
;	genAssign
	clr	_ser_txBusy
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:55: ser_txIndexIn  = 0;
;	genAssign
	mov	dptr,#_ser_txIndexIn
;	Peephole 181	changed mov to clr
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:56: ser_txIndexOut = 0;
;	genAssign
;	Peephole 181	changed mov to clr
;	Peephole 219.a	removed redundant clear
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:57: ser_rxIndexIn  = 0;
;	genAssign
;	Peephole 181	changed mov to clr
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:58: ser_rxIndexOut = 0;
;	genAssign
;	Peephole 181	changed mov to clr
;	Peephole 219.a	removed redundant clear
	clr	a
	movx	@dptr,a
	mov	dptr,#_ser_txIndexOut
	movx	@dptr,a
	mov	dptr,#_ser_rxIndexIn
;	Peephole 219.b	removed redundant clear
	movx	@dptr,a
	mov	dptr,#_ser_rxIndexOut
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:60: T2CON = 0x30;
;	genAssign
	mov	_T2CON,#0x30
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:63: RCAP2H = 0xFF;
;	genAssign
	mov	_RCAP2H,#0xFF
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:64: RCAP2L = 0xDD;
;	genAssign
	mov	_RCAP2L,#0xDD
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:67: T2CON = 0x34;
;	genAssign
	mov	_T2CON,#0x34
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:69: SCON = 0x50;
;	genAssign
	mov	_SCON,#0x50
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:71: if (TI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:72: TI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_TI,00109$
	sjmp	00102$
00109$:
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:74: if (RI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:75: RI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_RI,00110$
	sjmp	00104$
00110$:
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:78: ES=1;  
;	genAssign
	setb	_ES
;	Peephole 300	removed redundant label 00105$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_interrupt_handler'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:82: ser_interrupt_handler(void) interrupt 4 using 1
;	-----------------------------------------
;	 function ser_interrupt_handler
;	-----------------------------------------
_ser_interrupt_handler:
	ar2 = 0x0a
	ar3 = 0x0b
	ar4 = 0x0c
	ar5 = 0x0d
	ar6 = 0x0e
	ar7 = 0x0f
	ar0 = 0x08
	ar1 = 0x09
	push	acc
	push	dpl
	push	dph
	push	psw
	mov	psw,#0x08
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:84: ES=0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:86: if (RI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:87: RI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_RI,00113$
	sjmp	00102$
00113$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:88: ser_rxBuffer[ser_rxIndexIn++] = SBUF;
;	genAssign
	mov	dptr,#_ser_rxIndexIn
	movx	a,@dptr
	mov	r2,a
;	genPlus
	mov	dptr,#_ser_rxIndexIn
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,#_ser_rxBuffer
	mov	dpl,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 8)
	mov	dph,a
;	genPointerSet
;     genFarPointerSet
	mov	a,_SBUF
	movx	@dptr,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:91: if (TI) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:92: TI = 0;
;	genAssign
;	Peephole 250.a	using atomic test and clear
	jbc	_TI,00114$
	sjmp	00107$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:93: if (ser_txIndexIn == ser_txIndexOut) {
;	genAssign
	mov	dptr,#_ser_txIndexIn
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	dptr,#_ser_txIndexOut
	movx	a,@dptr
	mov	r3,a
;	genCmpEq
;	gencjneshort
	mov	a,r2
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	a,ar3,00104$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00115$
;	Peephole 300	removed redundant label 00116$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:94: ser_txBusy = 0;
;	genAssign
	clr	_ser_txBusy
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00107$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:97: SBUF = ser_txBuffer[ser_txIndexOut++];
;	genPlus
	mov	dptr,#_ser_txIndexOut
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@dptr,a
;	genPlus
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	add	a,#_ser_txBuffer
	mov	dpl,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 8)
	mov	dph,a
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	_SBUF,a
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:101: ES=1;
;	genAssign
	setb	_ES
;	Peephole 300	removed redundant label 00108$
	pop	psw
	pop	dph
	pop	dpl
	pop	acc
	reti
;	eliminated unneeded push/pop b
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_putc'
;------------------------------------------------------------
;c                         Allocated with name '_ser_putc_c_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:105: ser_putc(unsigned char c)
;	-----------------------------------------
;	 function ser_putc
;	-----------------------------------------
_ser_putc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	a,dpl
	mov	dptr,#_ser_putc_c_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:107: ES=0;
;	genAssign
	clr	_ES
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:109: if (ser_txBusy) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_ser_txBusy,00102$
;	Peephole 300	removed redundant label 00107$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:110: ser_txBuffer[ser_txIndexIn++] = c;
;	genAssign
	mov	dptr,#_ser_txIndexIn
	movx	a,@dptr
	mov	r2,a
;	genPlus
	mov	dptr,#_ser_txIndexIn
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,#_ser_txBuffer
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 8)
	mov	r3,a
;	genAssign
	mov	dptr,#_ser_putc_c_1_1
	movx	a,@dptr
;	genPointerSet
;     genFarPointerSet
	mov	r4,a
	mov	dpl,r2
	mov	dph,r3
;	Peephole 136	removed redundant move
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:113: ser_txBusy = 1;
;	genAssign
	setb	_ser_txBusy
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:114: SBUF = c;
;	genAssign
	mov	dptr,#_ser_putc_c_1_1
	movx	a,@dptr
	mov	_SBUF,a
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:117: ES=1;
;	genAssign
	setb	_ES
;	Peephole 300	removed redundant label 00104$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_getc'
;------------------------------------------------------------
;tmp                       Allocated with name '_ser_getc_tmp_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:121: ser_getc(void)
;	-----------------------------------------
;	 function ser_getc
;	-----------------------------------------
_ser_getc:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:126: if (ser_rxIndexIn != ser_rxIndexOut) {
;	genAssign
	mov	dptr,#_ser_rxIndexIn
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	dptr,#_ser_rxIndexOut
	movx	a,@dptr
	mov	r3,a
;	genCmpEq
;	gencjneshort
	mov	a,r2
	cjne	a,ar3,00107$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00102$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:127: tmp = ser_rxBuffer[ser_rxIndexOut++];
;	genPlus
	mov	dptr,#_ser_rxIndexOut
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@dptr,a
;	genPlus
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	add	a,#_ser_rxBuffer
	mov	dpl,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 8)
	mov	dph,a
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
;	genAssign
	mov	r2,a
	mov	dptr,#_ser_getc_tmp_1_1
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:130: tmp = 0;
;	genAssign
	mov	dptr,#_ser_getc_tmp_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:134: return(tmp);
;	genAssign
	mov	dptr,#_ser_getc_tmp_1_1
	movx	a,@dptr
;	genRet
;	Peephole 234.a	loading dpl directly from a(ccumulator), r2 not set
	mov	dpl,a
;	Peephole 300	removed redundant label 00104$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_printString'
;------------------------------------------------------------
;String                    Allocated with name '_ser_printString_String_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:138: ser_printString(char *String)
;	-----------------------------------------
;	 function ser_printString
;	-----------------------------------------
_ser_printString:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_ser_printString_String_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:140: while (*String) {
;	genAssign
	mov	dptr,#_ser_printString_String_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
00101$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfx
	mov	r5,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00108$
;	Peephole 300	removed redundant label 00109$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:141: ser_putc(*String++);
;	genAssign
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00110$
	inc	r3
00110$:
;	genAssign
	mov	dptr,#_ser_printString_String_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genCall
	mov	dpl,r5
	push	ar2
	push	ar3
	push	ar4
	lcall	_ser_putc
	pop	ar4
	pop	ar3
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00108$:
;	genAssign
	mov	dptr,#_ser_printString_String_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	Peephole 300	removed redundant label 00104$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_charAvail'
;------------------------------------------------------------
;ret                       Allocated with name '_ser_charAvail_ret_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:146: ser_charAvail(void)
;	-----------------------------------------
;	 function ser_charAvail
;	-----------------------------------------
_ser_charAvail:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:148: char ret = 0;
;	genAssign
	mov	dptr,#_ser_charAvail_ret_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:150: if (ser_rxIndexIn != ser_rxIndexOut) {
;	genAssign
	mov	dptr,#_ser_rxIndexIn
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	dptr,#_ser_rxIndexOut
	movx	a,@dptr
	mov	r3,a
;	genCmpEq
;	gencjneshort
	mov	a,r2
	cjne	a,ar3,00106$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00102$
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:151: ret = 1;
;	genAssign
	mov	dptr,#_ser_charAvail_ret_1_1
	mov	a,#0x01
	movx	@dptr,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_ser.c:154: return(ret);
;	genAssign
	mov	dptr,#_ser_charAvail_ret_1_1
	movx	a,@dptr
;	genRet
;	Peephole 234.a	loading dpl directly from a(ccumulator), r2 not set
	mov	dpl,a
;	Peephole 300	removed redundant label 00103$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
