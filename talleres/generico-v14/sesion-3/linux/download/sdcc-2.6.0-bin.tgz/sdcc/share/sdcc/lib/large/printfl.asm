;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:27 2006
;--------------------------------------------------------
	.module printfl
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _CY
	.globl _AC
	.globl _F0
	.globl _RS1
	.globl _RS0
	.globl _OV
	.globl _F1
	.globl _P
	.globl _PS
	.globl _PT1
	.globl _PX1
	.globl _PT0
	.globl _PX0
	.globl _RD
	.globl _WR
	.globl _T1
	.globl _T0
	.globl _INT1
	.globl _INT0
	.globl _TXD
	.globl _RXD
	.globl _P3_7
	.globl _P3_6
	.globl _P3_5
	.globl _P3_4
	.globl _P3_3
	.globl _P3_2
	.globl _P3_1
	.globl _P3_0
	.globl _EA
	.globl _ES
	.globl _ET1
	.globl _EX1
	.globl _ET0
	.globl _EX0
	.globl _P2_7
	.globl _P2_6
	.globl _P2_5
	.globl _P2_4
	.globl _P2_3
	.globl _P2_2
	.globl _P2_1
	.globl _P2_0
	.globl _SM0
	.globl _SM1
	.globl _SM2
	.globl _REN
	.globl _TB8
	.globl _RB8
	.globl _TI
	.globl _RI
	.globl _P1_7
	.globl _P1_6
	.globl _P1_5
	.globl _P1_4
	.globl _P1_3
	.globl _P1_2
	.globl _P1_1
	.globl _P1_0
	.globl _TF1
	.globl _TR1
	.globl _TF0
	.globl _TR0
	.globl _IE1
	.globl _IT1
	.globl _IE0
	.globl _IT0
	.globl _P0_7
	.globl _P0_6
	.globl _P0_5
	.globl _P0_4
	.globl _P0_3
	.globl _P0_2
	.globl _P0_1
	.globl _P0_0
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _IP
	.globl _P3
	.globl _IE
	.globl _P2
	.globl _SBUF
	.globl _SCON
	.globl _P1
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _PCON
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _P0
	.globl _printf_small
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_radix:
	.ds 1
_str:
	.ds 3
_val:
	.ds 4
_printf_small_buffer_4_8:
	.ds 12
_printf_small_c_4_8:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_long_flag:
	.ds 1
_string_flag:
	.ds 1
_char_flag:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:52: static bit  long_flag = 0;
;	genAssign
	clr	_long_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:53: static bit  string_flag =0;
;	genAssign
	clr	_string_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:54: static bit  char_flag = 0;
;	genAssign
	clr	_char_flag
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'printf_small'
;------------------------------------------------------------
;fmt                       Allocated to stack - offset -5
;ap                        Allocated to registers r2 
;buffer                    Allocated with name '_printf_small_buffer_4_8'
;c                         Allocated with name '_printf_small_c_4_8'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:123: void printf_small (char * fmt, ... ) reentrant
;	-----------------------------------------
;	 function printf_small
;	-----------------------------------------
_printf_small:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:127: va_start(ap,fmt);
;	genAddrOf
	mov	a,_bp
	add	a,#0xfb
	mov	r2,a
;	genAssign
00130$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:129: for (; *fmt ; fmt++ ) {
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
;	genIfx
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
	jnz	00154$
	ljmp	00134$
00154$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:130: if (*fmt == '%') {
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x25,00155$
	sjmp	00156$
00155$:
	ljmp	00128$
00156$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:131: long_flag = string_flag = char_flag = 0;
;	genAssign
	clr	_char_flag
;	genAssign
	clr	_string_flag
;	genAssign
	clr	_long_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:132: fmt++ ;
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:133: switch (*fmt) {
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r7,a
;	genCmpEq
;	gencjneshort
	cjne	r7,#0x68,00157$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00102$
00157$:
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r7,#0x6C,00103$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00158$
;	Peephole 300	removed redundant label 00159$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:135: long_flag = 1;
;	genAssign
	setb	_long_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:136: fmt++;
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:137: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:138: case 'h':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:139: char_flag = 1;
;	genAssign
	setb	_char_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:140: fmt++;
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	r0
	mov	@r0,a
	inc	r0
	mov	@r0,ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:141: }
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:143: switch (*fmt) {
;	genAssign
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r3,a
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x63,00160$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00107$
00160$:
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x64,00161$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00161$:
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x6F,00162$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00108$
00162$:
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x73,00163$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00104$
00163$:
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:144: case 's':
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r3,#0x78,00109$
	sjmp	00106$
;	Peephole 300	removed redundant label 00164$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:145: string_flag = 1;
;	genAssign
	setb	_string_flag
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:146: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:147: case 'd':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:148: radix = 10;
;	genAssign
	mov	_radix,#0x0A
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:149: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:150: case 'x':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:151: radix = 16;
;	genAssign
	mov	_radix,#0x10
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:152: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:153: case 'c':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:154: radix = 0;
;	genAssign
	mov	_radix,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:155: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:156: case 'o':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:157: radix = 8;
;	genAssign
	mov	_radix,#0x08
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:159: }
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:161: if (string_flag) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_string_flag,00114$
;	Peephole 300	removed redundant label 00165$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:162: str = va_arg(ap, char *);
;	genMinus
;	genMinusDec
	mov	a,r2
	add	a,#0xfd
	mov	r0,a
;	genAssign
	mov	ar2,r0
;	genPointerGet
;	genNearPointerGet
	mov	_str,@r0
	inc	r0
	mov	(_str + 1),@r0
	inc	r0
	mov	(_str + 2),@r0
	dec	r0
	dec	r0
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:163: while (*str) putchar(*str++);
00110$:
;	genAssign
	mov	r3,_str
	mov	r4,(_str + 1)
	mov	r5,(_str + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
;	genIfxJump
	jnz	00166$
	ljmp	00132$
00166$:
;	genAssign
	mov	r3,_str
	mov	r4,(_str + 1)
	mov	r5,(_str + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r3,a
;	genPlus
;     genPlusIncr
	inc	_str
	clr	a
	cjne	a,_str,00167$
	inc	(_str + 1)
00167$:
;	genCall
	mov	dpl,r3
	push	ar2
	lcall	_putchar
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:164: continue ;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00110$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:167: if (long_flag)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_long_flag,00119$
;	Peephole 300	removed redundant label 00168$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:168: val = va_arg(ap,long);
;	genMinus
;	genMinusDec
	mov	a,r2
	add	a,#0xfc
	mov	r0,a
;	genAssign
	mov	ar2,r0
;	genPointerGet
;	genNearPointerGet
	mov	_val,@r0
	inc	r0
	mov	(_val + 1),@r0
	inc	r0
	mov	(_val + 2),@r0
	inc	r0
	mov	(_val + 3),@r0
	dec	r0
	dec	r0
	dec	r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00120$
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:170: if (char_flag)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_char_flag,00116$
;	Peephole 300	removed redundant label 00169$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:171: val = va_arg(ap,char);
;	genMinus
;	genMinusDec
	mov	a,r2
	dec	a
	mov	r0,a
;	genAssign
	mov	ar2,r0
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
;	genCast
;	peephole 177.h	optimized mov sequence
	mov	a,r3
	mov	_val,a
	rlc	a
	subb	a,acc
	mov	(_val + 1),a
	mov	(_val + 2),a
	mov	(_val + 3),a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00120$
00116$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:173: val = va_arg(ap,int);
;	genMinus
;	genMinusDec
	mov	a,r2
	add	a,#0xfe
	mov	r0,a
;	genAssign
	mov	ar2,r0
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	dec	r0
;	genCast
	mov	_val,r3
;	peephole 177.h	optimized mov sequence
	mov	a,r4
	mov	(_val + 1),a
	rlc	a
	subb	a,acc
	mov	(_val + 2),a
	mov	(_val + 3),a
00120$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:178: if (radix)
;	genIfx
	mov	a,_radix
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00125$
;	Peephole 300	removed redundant label 00170$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:182: _ltoa (val, buffer, radix);
;	genAssign
	mov	r3,_val
	mov	r4,(_val + 1)
	mov	r5,(_val + 2)
	mov	r7,(_val + 3)
;	genCast
	mov	dptr,#__ltoa_PARM_2
	mov	a,#_printf_small_buffer_4_8
	movx	@dptr,a
	inc	dptr
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x40
	movx	@dptr,a
;	genAssign
	mov	dptr,#__ltoa_PARM_3
	mov	a,_radix
	movx	@dptr,a
;	genCall
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r7
	push	ar2
	lcall	__ltoa
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:183: str = buffer;
;	genCast
	mov	_str,#_printf_small_buffer_4_8
	mov	(_str + 1),#0x00
	mov	(_str + 2),#0x40
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:184: while ((c = *str++) != '\0')
00121$:
;	genAssign
	mov	r3,_str
	mov	r4,(_str + 1)
	mov	r5,(_str + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
	mov	r3,a
;	genPlus
;     genPlusIncr
	inc	_str
	clr	a
	cjne	a,_str,00171$
	inc	(_str + 1)
00171$:
;	genAssign
	mov	_printf_small_c_4_8,r3
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x00,00172$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00132$
00172$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:185: putchar (c);
;	genCall
	mov	dpl,_printf_small_c_4_8
	push	ar2
	lcall	_putchar
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00125$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:189: putchar((char)val);
;	genCast
	mov	r3,_val
;	genCall
	mov	dpl,r3
	push	ar2
	lcall	_putchar
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00132$
00128$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:192: putchar(*fmt);
;	genCall
	mov	dpl,r6
	push	ar2
	lcall	_putchar
	pop	ar2
00132$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printfl.c:129: for (; *fmt ; fmt++ ) {
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffb
	mov	r0,a
;     genPlusIncr
	mov	a,#0x01
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
	ljmp	00130$
00134$:
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
