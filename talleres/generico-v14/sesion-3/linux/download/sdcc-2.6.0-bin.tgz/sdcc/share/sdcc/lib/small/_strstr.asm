;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:57 2006
;--------------------------------------------------------
	.module _strstr
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strstr_PARM_2
	.globl _strstr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
_strstr_PARM_2::
	.ds 3
_strstr_cp_1_1::
	.ds 3
_strstr_s2_1_1::
	.ds 3
_strstr_sloc0_1_0::
	.ds 3
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strstr'
;------------------------------------------------------------
;str2                      Allocated with name '_strstr_PARM_2'
;str1                      Allocated to registers r2 r3 r4 
;cp                        Allocated with name '_strstr_cp_1_1'
;s1                        Allocated to registers r2 r3 r4 
;s2                        Allocated with name '_strstr_s2_1_1'
;sloc0                     Allocated with name '_strstr_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:26: char * strstr (
;	-----------------------------------------
;	 function strstr
;	-----------------------------------------
_strstr:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:31: char * cp = str1;
;	genAssign
	mov	_strstr_cp_1_1,r2
	mov	(_strstr_cp_1_1 + 1),r3
	mov	(_strstr_cp_1_1 + 2),r4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:35: if ( !*str2 )
;	genAssign
	mov	_strstr_s2_1_1,_strstr_PARM_2
	mov	(_strstr_s2_1_1 + 1),(_strstr_PARM_2 + 1)
	mov	(_strstr_s2_1_1 + 2),(_strstr_PARM_2 + 2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_strstr_s2_1_1
	mov	dph,(_strstr_s2_1_1 + 1)
	mov	b,(_strstr_s2_1_1 + 2)
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00122$
;	Peephole 300	removed redundant label 00124$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:36: return str1;
;	genRet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:38: while (*cp)
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00122$:
;	genAssign
00110$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00112$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:41: s2 = str2;
;	genAssign
	mov	r6,_strstr_s2_1_1
	mov	r7,(_strstr_s2_1_1 + 1)
	mov	r5,(_strstr_s2_1_1 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:43: while ( *s1 && *s2 && !(*s1-*s2) )
;	genAssign
	mov	_strstr_sloc0_1_0,r2
	mov	(_strstr_sloc0_1_0 + 1),r3
	mov	(_strstr_sloc0_1_0 + 2),r4
;	genAssign
00105$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_strstr_sloc0_1_0
	mov	dph,(_strstr_sloc0_1_0 + 1)
	mov	b,(_strstr_sloc0_1_0 + 2)
	lcall	__gptrget
;	genIfx
	mov	r0,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00107$
;	Peephole 300	removed redundant label 00126$
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r5
	lcall	__gptrget
;	genIfx
	mov	r1,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00107$
;	Peephole 300	removed redundant label 00127$
;	genMinus
	mov	a,r0
	clr	c
;	Peephole 236.l	used r1 instead of ar1
	subb	a,r1
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00107$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:44: s1++, s2++;
;	genPlus
;     genPlusIncr
	inc	_strstr_sloc0_1_0
	clr	a
	cjne	a,_strstr_sloc0_1_0,00129$
	inc	(_strstr_sloc0_1_0 + 1)
00129$:
;	genPlus
;     genPlusIncr
;	tail increment optimized (range 8)
	inc	r6
	cjne	r6,#0x00,00105$
	inc	r7
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:46: if (!*s2)
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r5
	lcall	__gptrget
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00109$
;	Peephole 300	removed redundant label 00130$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:47: return(cp);
;	genRet
	mov	dpl,_strstr_cp_1_1
	mov	dph,(_strstr_cp_1_1 + 1)
	mov	b,(_strstr_cp_1_1 + 2)
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:49: cp++;
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00131$
	inc	r3
00131$:
;	genAssign
	mov	_strstr_cp_1_1,r2
	mov	(_strstr_cp_1_1 + 1),r3
	mov	(_strstr_cp_1_1 + 2),r4
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00110$
00112$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_strstr.c:52: return (NULL) ;
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
	mov	b,#0x00
;	Peephole 300	removed redundant label 00113$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
