;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:52 2006
;--------------------------------------------------------
	.module _atof
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atof
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_atof_s_1_1:
	.ds 3
_atof_value_1_1:
	.ds 4
_atof_fraction_1_1:
	.ds 4
_atof_sloc0_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_atof_sign_1_1:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atof'
;------------------------------------------------------------
;s                         Allocated with name '_atof_s_1_1'
;value                     Allocated with name '_atof_value_1_1'
;fraction                  Allocated with name '_atof_fraction_1_1'
;iexp                      Allocated to registers r2 
;sloc0                     Allocated with name '_atof_sloc0_1_0'
;sloc1                     Allocated with name '_atof_sloc1_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:23: float atof(char * s)
;	-----------------------------------------
;	 function atof
;	-----------------------------------------
_atof:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	_atof_s_1_1,dpl
	mov	(_atof_s_1_1 + 1),dph
	mov	(_atof_s_1_1 + 2),b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:30: while (isspace(*s)) s++;
;	genAssign
	mov	r5,_atof_s_1_1
	mov	r6,(_atof_s_1_1 + 1)
	mov	r7,(_atof_s_1_1 + 2)
00101$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
;	genCall
	mov	r0,a
;	Peephole 244.c	loading dpl from a instead of r0
	mov	dpl,a
	push	ar5
	push	ar6
	push	ar7
	lcall	_isspace
	mov	a,dpl
	pop	ar7
	pop	ar6
	pop	ar5
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00148$
;	Peephole 300	removed redundant label 00151$
;	genPlus
;     genPlusIncr
;	tail increment optimized (range 5)
	inc	r5
	cjne	r5,#0x00,00101$
	inc	r6
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00148$:
;	genAssign
	mov	_atof_s_1_1,r5
	mov	(_atof_s_1_1 + 1),r6
	mov	(_atof_s_1_1 + 2),r7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:33: if (*s == '-')
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r0,a
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r0,#0x2D,00107$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00152$
;	Peephole 300	removed redundant label 00153$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:35: sign=1;
;	genAssign
	setb	_atof_sign_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:36: s++;
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	_atof_s_1_1,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	(_atof_s_1_1 + 1),a
	mov	(_atof_s_1_1 + 2),r7
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00108$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:40: sign=0;
;	genAssign
	clr	_atof_sign_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:41: if (*s == '+') s++;
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r0,#0x2B,00108$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00154$
;	Peephole 300	removed redundant label 00155$
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	_atof_s_1_1,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	(_atof_s_1_1 + 1),a
	mov	(_atof_s_1_1 + 2),r7
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:45: for (value=0.0; isdigit(*s); s++)
;	genAssign
	mov	_atof_value_1_1,#0x00
	mov	(_atof_value_1_1 + 1),#0x00
	mov	(_atof_value_1_1 + 2),#0x00
	mov	(_atof_value_1_1 + 3),#0x00
;	genAssign
	mov	_atof_sloc0_1_0,_atof_s_1_1
	mov	(_atof_sloc0_1_0 + 1),(_atof_s_1_1 + 1)
	mov	(_atof_sloc0_1_0 + 2),(_atof_s_1_1 + 2)
00121$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_sloc0_1_0
	mov	dph,(_atof_sloc0_1_0 + 1)
	mov	b,(_atof_sloc0_1_0 + 2)
	lcall	__gptrget
;	genCall
	mov	r4,a
;	Peephole 244.c	loading dpl from a instead of r4
	mov	dpl,a
	lcall	_isdigit
	mov	a,dpl
;	genIfx
;	genIfxJump
	jnz	00156$
	ljmp	00149$
00156$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:47: value=10.0*value+(*s-'0');
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x20
	push	acc
	mov	a,#0x41
	push	acc
;	genCall
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
	lcall	___fsmul
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	mov	r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_sloc0_1_0
	mov	dph,(_atof_sloc0_1_0 + 1)
	mov	b,(_atof_sloc0_1_0 + 2)
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	mov	_atof_sloc0_1_0,dpl
	mov	(_atof_sloc0_1_0 + 1),dph
;	genCast
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r3,a
;	genMinus
	mov	a,r2
	add	a,#0xd0
	mov	dpl,a
	mov	a,r3
	addc	a,#0xff
	mov	dph,a
;	genCall
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	lcall	___sint2fs
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r1,a
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar1
;	genCall
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r0
	lcall	___fsadd
	mov	_atof_value_1_1,dpl
	mov	(_atof_value_1_1 + 1),dph
	mov	(_atof_value_1_1 + 2),b
	mov	(_atof_value_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:45: for (value=0.0; isdigit(*s); s++)
	ljmp	00121$
00149$:
;	genAssign
	mov	_atof_s_1_1,_atof_sloc0_1_0
	mov	(_atof_s_1_1 + 1),(_atof_sloc0_1_0 + 1)
	mov	(_atof_s_1_1 + 2),(_atof_sloc0_1_0 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:51: if (*s == '.')
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_sloc0_1_0
	mov	dph,(_atof_sloc0_1_0 + 1)
	mov	b,(_atof_sloc0_1_0 + 2)
	lcall	__gptrget
	mov	r2,a
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x2E,00157$
	sjmp	00158$
00157$:
	ljmp	00110$
00158$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:53: s++;
;	genPlus
;     genPlusIncr
	mov	a,#0x01
	add	a,_atof_sloc0_1_0
	mov	_atof_s_1_1,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(_atof_sloc0_1_0 + 1)
	mov	(_atof_s_1_1 + 1),a
	mov	(_atof_s_1_1 + 2),(_atof_sloc0_1_0 + 2)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
;	genAssign
	mov	_atof_fraction_1_1,#0xCD
	mov	(_atof_fraction_1_1 + 1),#0xCC
	mov	(_atof_fraction_1_1 + 2),#0xCC
	mov	(_atof_fraction_1_1 + 3),#0x3D
;	genAssign
	mov	r2,_atof_s_1_1
	mov	r3,(_atof_s_1_1 + 1)
	mov	r4,(_atof_s_1_1 + 2)
00125$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCall
	mov	r1,a
;	Peephole 244.c	loading dpl from a instead of r1
	mov	dpl,a
	push	ar2
	push	ar3
	push	ar4
	lcall	_isdigit
	mov	a,dpl
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
;	genIfxJump
	jnz	00159$
	ljmp	00150$
00159$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:56: value+=(*s-'0')*fraction;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r1,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;	genCast
	mov	a,r1
	rlc	a
	subb	a,acc
	mov	r5,a
;	genMinus
	mov	a,r1
	add	a,#0xd0
	mov	dpl,a
	mov	a,r5
	addc	a,#0xff
	mov	dph,a
;	genCall
	push	ar2
	push	ar3
	push	ar4
	lcall	___sint2fs
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	mov	r0,a
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	_atof_fraction_1_1
	push	(_atof_fraction_1_1 + 1)
	push	(_atof_fraction_1_1 + 2)
	push	(_atof_fraction_1_1 + 3)
;	genCall
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r0
	lcall	___fsmul
	mov	r5,dpl
	mov	r6,dph
	mov	r7,b
	mov	r0,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	ar0
;	genCall
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
	lcall	___fsadd
	mov	_atof_value_1_1,dpl
	mov	(_atof_value_1_1 + 1),dph
	mov	(_atof_value_1_1 + 2),b
	mov	(_atof_value_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:57: fraction*=0.1;
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	mov	a,#0xCD
	push	acc
	mov	a,#0xCC
	push	acc
	push	acc
	mov	a,#0x3D
	push	acc
;	genCall
	mov	dpl,_atof_fraction_1_1
	mov	dph,(_atof_fraction_1_1 + 1)
	mov	b,(_atof_fraction_1_1 + 2)
	mov	a,(_atof_fraction_1_1 + 3)
	lcall	___fsmul
	mov	_atof_fraction_1_1,dpl
	mov	(_atof_fraction_1_1 + 1),dph
	mov	(_atof_fraction_1_1 + 2),b
	mov	(_atof_fraction_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
	ljmp	00125$
00150$:
;	genAssign
	mov	_atof_s_1_1,r2
	mov	(_atof_s_1_1 + 1),r3
	mov	(_atof_s_1_1 + 2),r4
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:62: if (toupper(*s)=='E')
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_s_1_1
	mov	dph,(_atof_s_1_1 + 1)
	mov	b,(_atof_s_1_1 + 2)
	lcall	__gptrget
;	genCall
	mov	r2,a
;	Peephole 244.c	loading dpl from a instead of r2
	mov	dpl,a
	lcall	_islower
	mov	a,dpl
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00131$
;	Peephole 300	removed redundant label 00160$
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_s_1_1
	mov	dph,(_atof_s_1_1 + 1)
	mov	b,(_atof_s_1_1 + 2)
	lcall	__gptrget
;	genCast
	mov	r2,a
;	Peephole 105	removed redundant mov
	rlc	a
	subb	a,acc
	mov	r3,a
;	genAnd
	anl	ar2,#0xDF
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00132$
00131$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,_atof_s_1_1
	mov	dph,(_atof_s_1_1 + 1)
	mov	b,(_atof_s_1_1 + 2)
	lcall	__gptrget
;	genCast
	mov	r4,a
	mov	ar2,r4
;	Peephole 166	removed redundant mov
	rlc	a
	subb	a,acc
	mov	r3,a
00132$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x45,00161$
	cjne	r3,#0x00,00161$
	sjmp	00162$
00161$:
	ljmp	00118$
00162$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:64: s++;
;	genPlus
;     genPlusIncr
	inc	_atof_s_1_1
	clr	a
	cjne	a,_atof_s_1_1,00163$
	inc	(_atof_s_1_1 + 1)
00163$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:65: iexp=(char)atoi(s);
;	genCall
	mov	dpl,_atof_s_1_1
	mov	dph,(_atof_s_1_1 + 1)
	mov	b,(_atof_s_1_1 + 2)
	lcall	_atoi
	mov	r2,dpl
	mov	r3,dph
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:67: while(iexp!=0)
00114$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x00,00164$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00118$
00164$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:69: if(iexp<0)
;	genCmpLt
;	genCmp
	mov	a,r2
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00112$
;	Peephole 300	removed redundant label 00165$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:71: value*=0.1;
;	genIpush
	push	ar2
	mov	a,#0xCD
	push	acc
	mov	a,#0xCC
	push	acc
	push	acc
	mov	a,#0x3D
	push	acc
;	genCall
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
	lcall	___fsmul
	mov	_atof_value_1_1,dpl
	mov	(_atof_value_1_1 + 1),dph
	mov	(_atof_value_1_1 + 2),b
	mov	(_atof_value_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:72: iexp++;
;	genPlus
;     genPlusIncr
	inc	r2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00114$
00112$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:76: value*=10.0;
;	genIpush
	push	ar2
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x20
	push	acc
	mov	a,#0x41
	push	acc
;	genCall
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
	lcall	___fsmul
	mov	_atof_value_1_1,dpl
	mov	(_atof_value_1_1 + 1),dph
	mov	(_atof_value_1_1 + 2),b
	mov	(_atof_value_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:77: iexp--;
;	genMinus
;	genMinusDec
	dec	r2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00114$
00118$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:83: if(sign) value*=-1.0;
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_atof_sign_1_1,00120$
;	Peephole 300	removed redundant label 00166$
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0xBF
	push	acc
;	genCall
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
	lcall	___fsmul
	mov	_atof_value_1_1,dpl
	mov	(_atof_value_1_1 + 1),dph
	mov	(_atof_value_1_1 + 2),b
	mov	(_atof_value_1_1 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00120$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_atof.c:84: return (value);
;	genRet
	mov	dpl,_atof_value_1_1
	mov	dph,(_atof_value_1_1 + 1)
	mov	b,(_atof_value_1_1 + 2)
	mov	a,(_atof_value_1_1 + 3)
;	Peephole 300	removed redundant label 00129$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
