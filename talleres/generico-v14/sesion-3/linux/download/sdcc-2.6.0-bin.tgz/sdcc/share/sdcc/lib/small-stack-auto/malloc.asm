;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:04 2006
;--------------------------------------------------------
	.module malloc
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __sdcc_first_memheader
	.globl _init_dynamic_memory
	.globl _malloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__sdcc_first_memheader::
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'init_dynamic_memory'
;------------------------------------------------------------
;size                      Allocated to stack - offset -4
;heap                      Allocated to registers r2 r3 
;array                     Allocated to registers r4 r5 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:146: void init_dynamic_memory(void xdata * heap, unsigned int size)
;	-----------------------------------------
;	 function init_dynamic_memory
;	-----------------------------------------
_init_dynamic_memory:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bp
	mov	_bp,sp
;	genReceive
	mov	r2,dpl
	mov	r3,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:167: char xdata * array = (char xdata *)heap;
;	genAssign
	mov	ar4,r2
	mov	ar5,r3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:169: if ( !array ) //Reserved memory starts at 0x0000 but that's NULL...
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00102$
;	Peephole 300	removed redundant label 00106$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:171: array++;
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r4,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:172: size--;
;	genMinus
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
;	genMinusDec
	mov	a,@r0
	add	a,#0xff
	mov	@r0,a
	inc	r0
	mov	a,@r0
	addc	a,#0xff
	mov	@r0,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:174: _sdcc_first_memheader = (MEMHEADER xdata * ) array;
;	genAssign
	mov	__sdcc_first_memheader,r4
	mov	(__sdcc_first_memheader + 1),r5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:176: _sdcc_first_memheader->next = (MEMHEADER xdata * )(array + size - sizeof(MEMHEADER xdata *));
;	genAssign
	mov	r2,__sdcc_first_memheader
	mov	r3,(__sdcc_first_memheader + 1)
;	genPlus
	mov	a,_bp
	add	a,#0xfffffffc
	mov	r0,a
	mov	a,@r0
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r4,a
	inc	r0
	mov	a,@r0
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r5,a
;	genMinus
;	genMinusDec
	mov	a,r4
	add	a,#0xfe
	mov	r4,a
	mov	a,r5
	addc	a,#0xff
	mov	r5,a
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:177: _sdcc_first_memheader->next->next = (MEMHEADER xdata * ) NULL; //And mark it as last
;	genAssign
	mov	dpl,__sdcc_first_memheader
	mov	dph,(__sdcc_first_memheader + 1)
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:178: _sdcc_first_memheader->len        = 0;    //Empty and ready.
;	genPlus
;     genPlusIncr
	mov	dpl,__sdcc_first_memheader
	mov	dph,(__sdcc_first_memheader + 1)
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
;	Peephole 300	removed redundant label 00103$
	pop	_bp
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'malloc'
;------------------------------------------------------------
;size                      Allocated to stack - offset 1
;current_header            Allocated to stack - offset 3
;new_header                Allocated to registers r6 r7 
;ret                       Allocated to registers r2 r3 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:181: void xdata * malloc (unsigned int size)
;	-----------------------------------------
;	 function malloc
;	-----------------------------------------
_malloc:
	push	_bp
	mov	_bp,sp
;     genReceive
	push	dpl
	push	dph
	inc	sp
	inc	sp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:187: if (size>(0xFFFF-HEADER_SIZE)) return (void xdata *) NULL; //To prevent overflow in next line
;	genCmpGt
	mov	r0,_bp
	inc	r0
;	genCmp
	clr	c
	mov	a,#0xFB
	subb	a,@r0
	mov	a,#0xFF
	inc	r0
	subb	a,@r0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00123$
;	genRet
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
	ljmp	00115$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:188: size += HEADER_SIZE; //We need a memory for header too
;	genPlus
	mov	r0,_bp
	inc	r0
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:189: current_header = _sdcc_first_memheader;
;	genAssign
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	@r0,__sdcc_first_memheader
	inc	r0
	mov	@r0,(__sdcc_first_memheader + 1)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:231: }
;	genCritical
	setb	c
	jbc	ea,00124$
	clr	c
00124$:
	push	psw
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:192: while (1)
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:202: if ((((unsigned int)current_header->next) -
;	genPointerGet
;	genFarPointerGet
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genCast
	mov	ar2,r6
	mov	ar3,r7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:203: ((unsigned int)current_header) -
;	genCast
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar5,@r0
;	genMinus
	mov	a,r2
	clr	c
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
	mov	a,r3
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:204: current_header->len) >= size)
;	genPlus
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
;     genPlusIncr
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genMinus
	mov	a,r2
	clr	c
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
	mov	a,r3
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r3,a
;	genCmpLt
	mov	r0,_bp
	inc	r0
;	genCmp
	clr	c
	mov	a,r2
	subb	a,@r0
	mov	a,r3
	inc	r0
	subb	a,@r0
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00104$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:206: ret = current_header->mem;
;	genPlus
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
;     genPlusIncr
	mov	a,#0x04
	add	a,@r0
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:207: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:209: current_header = current_header->next;    //else try next
;	genAssign
;	genAssign
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	@r0,ar6
	inc	r0
	mov	@r0,ar7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:210: if (!current_header->next)
;	genPointerGet
;	genFarPointerGet
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genIfx
	mov	r5,a
;	Peephole 135	removed redundant mov
	orl	a,r4
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:212: ret = (void xdata *) NULL;
;	genAssign
;	Peephole 256.c	loading r2 with zero from a
	jnz	00108$
;	Peephole 300	removed redundant label 00126$
	mov	r2,a
;	Peephole 256.d	loading r3 with zero from a
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:213: break;
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:216: if (ret)
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00114$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:218: if (!current_header->len)
;	genPlus
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
;     genPlusIncr
	mov	a,#0x02
	add	a,@r0
	mov	r4,a
;	Peephole 181	changed mov to clr
	clr	a
	inc	r0
	addc	a,@r0
	mov	r5,a
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r4
	mov	dph,r5
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
;	genIfx
	mov	r7,a
;	Peephole 135	removed redundant mov
	orl	a,r6
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00111$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:220: current_header->len = size; //for first allocation
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00114$
00111$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:224: new_header = (MEMHEADER xdata * )((char xdata *)current_header + current_header->len);
;	genPlus
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,@r0
	mov	r6,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	inc	r0
	addc	a,@r0
	mov	r7,a
;	genAssign
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:225: new_header->next = current_header->next; //and plug it into the chain
;	genPointerGet
;	genFarPointerGet
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:226: current_header->next  = new_header;
;	genPointerSet
;     genFarPointerSet
	mov	r0,_bp
	inc	r0
	inc	r0
	inc	r0
	mov	dpl,@r0
	inc	r0
	mov	dph,@r0
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:227: new_header->len  = size; //mark as used
;	genPlus
;     genPlusIncr
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	r0,_bp
	inc	r0
	mov	a,@r0
	movx	@dptr,a
	inc	dptr
	inc	r0
	mov	a,@r0
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:228: ret = new_header->mem;
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	mov	r3,a
00114$:
;     genEndCritical
	pop	psw
	mov	ea,c
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/malloc.c:232: return ret;
;	genRet
	mov	dpl,r2
	mov	dph,r3
00115$:
	mov	sp,_bp
	pop	_bp
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
