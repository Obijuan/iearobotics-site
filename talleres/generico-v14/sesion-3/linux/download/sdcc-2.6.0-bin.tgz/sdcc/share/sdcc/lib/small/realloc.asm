;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:57 2006
;--------------------------------------------------------
	.module realloc
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc_PARM_2
	.globl _realloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_realloc_PARM_2:
	.ds 2
_realloc_p_1_1:
	.ds 3
_realloc_pthis_1_1:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'realloc'
;------------------------------------------------------------
;size                      Allocated with name '_realloc_PARM_2'
;p                         Allocated with name '_realloc_p_1_1'
;pthis                     Allocated with name '_realloc_pthis_1_1'
;pnew                      Allocated to registers r2 r3 
;ret                       Allocated to registers r7 r0 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:67: void xdata * realloc (void * p, size_t size)
;	-----------------------------------------
;	 function realloc
;	-----------------------------------------
_realloc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	_realloc_p_1_1,dpl
	mov	(_realloc_p_1_1 + 1),dph
	mov	(_realloc_p_1_1 + 2),b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:75: pthis = _sdcc_find_memheader(p);
;	genCast
	mov	dpl,_realloc_p_1_1
	mov	dph,(_realloc_p_1_1 + 1)
;	genCall
	lcall	__sdcc_find_memheader
	mov	_realloc_pthis_1_1,dpl
	mov	(_realloc_pthis_1_1 + 1),dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:76: if (pthis)
;	genIfx
	mov	a,_realloc_pthis_1_1
	orl	a,(_realloc_pthis_1_1 + 1)
;	genIfxJump
	jnz	00124$
	ljmp	00114$
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
;	genCmpGt
;	genCmp
	clr	c
	mov	a,#0xFB
	subb	a,_realloc_PARM_2
	mov	a,#0xFF
	subb	a,(_realloc_PARM_2 + 1)
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00111$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
;	genAssign
	mov	r7,#0x00
	mov	r0,#0x00
	ljmp	00115$
00111$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
;	genPlus
;     genPlusIncr
	mov	a,#0x04
	add	a,_realloc_PARM_2
	mov	_realloc_PARM_2,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(_realloc_PARM_2 + 1)
	mov	(_realloc_PARM_2 + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
;	genPointerGet
;	genFarPointerGet
	mov	dpl,_realloc_pthis_1_1
	mov	dph,(_realloc_pthis_1_1 + 1)
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	genCast
	mov	ar3,r1
	mov	ar4,r2
;	genCast
	mov	r5,_realloc_pthis_1_1
	mov	r6,(_realloc_pthis_1_1 + 1)
;	genMinus
	mov	a,r3
	clr	c
;	Peephole 236.l	used r5 instead of ar5
	subb	a,r5
	mov	r3,a
	mov	a,r4
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	mov	r4,a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r3
	subb	a,_realloc_PARM_2
	mov	a,r4
	subb	a,(_realloc_PARM_2 + 1)
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00108$
;	Peephole 300	removed redundant label 00126$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:88: pthis->len = size;
;	genPlus
;     genPlusIncr
	mov	dpl,_realloc_pthis_1_1
	mov	dph,(_realloc_pthis_1_1 + 1)
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_realloc_PARM_2
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_PARM_2 + 1)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:89: ret = p;
;	genCast
	mov	r7,_realloc_p_1_1
	mov	r0,(_realloc_p_1_1 + 1)
	ljmp	00115$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:93: if ((_sdcc_prev_memheader) &&
;	genIfx
	mov	a,__sdcc_prev_memheader
	orl	a,(__sdcc_prev_memheader + 1)
;	genIfxJump
	jnz	00127$
	ljmp	00104$
00127$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:94: ((((unsigned int)pthis->next) -
;	genAssign
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
;	genCast
	mov	r3,__sdcc_prev_memheader
	mov	r4,(__sdcc_prev_memheader + 1)
;	genMinus
	mov	a,r1
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r1,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:96: _sdcc_prev_memheader->len) >= size))
;	genPlus
;     genPlusIncr
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genMinus
	mov	a,r1
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r1,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r1
	subb	a,_realloc_PARM_2
	mov	a,r2
	subb	a,(_realloc_PARM_2 + 1)
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00104$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
;	genPlus
;     genPlusIncr
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	add	a,__sdcc_prev_memheader
	mov	r2,a
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	addc	a,(__sdcc_prev_memheader + 1)
	mov	r3,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:99: _sdcc_prev_memheader->next = pnew;
;	genAssign
	mov	dpl,__sdcc_prev_memheader
	mov	dph,(__sdcc_prev_memheader + 1)
;	genPointerSet
;     genFarPointerSet
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:105: memmove(pnew, pthis, pthis->len);
;	genCast
	mov	ar4,r2
	mov	ar5,r3
	mov	r6,#0x0
;	genCast
	mov	_memmove_PARM_2,_realloc_pthis_1_1
	mov	(_memmove_PARM_2 + 1),(_realloc_pthis_1_1 + 1)
	mov	(_memmove_PARM_2 + 2),#0x0
;	genPlus
;     genPlusIncr
	mov	dpl,_realloc_pthis_1_1
	mov	dph,(_realloc_pthis_1_1 + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	_memmove_PARM_3,a
	inc	dptr
	movx	a,@dptr
	mov	(_memmove_PARM_3 + 1),a
;	genCall
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	push	ar2
	push	ar3
	lcall	_memmove
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:106: pnew->len = size;
;	genPlus
;     genPlusIncr
	mov	dpl,r2
	mov	dph,r3
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_realloc_PARM_2
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_PARM_2 + 1)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:107: ret = MEM(pnew);
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r7,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r0,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:111: ret = malloc(size - HEADER_SIZE);
;	genMinus
;	genMinusDec
	mov	a,_realloc_PARM_2
	add	a,#0xfc
	mov	dpl,a
	mov	a,(_realloc_PARM_2 + 1)
	addc	a,#0xff
	mov	dph,a
;	genCall
	lcall	_malloc
	mov	r7,dpl
	mov	r0,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:112: if (ret)
;	genIfx
	mov	a,r7
	orl	a,r0
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00115$
;	Peephole 300	removed redundant label 00129$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:114: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
;	genCast
	mov	ar2,r7
	mov	ar3,r0
	mov	r4,#0x0
;	genPlus
;     genPlusIncr
	mov	a,#0x04
	add	a,_realloc_pthis_1_1
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(_realloc_pthis_1_1 + 1)
	mov	r6,a
;	genCast
	mov	_memcpy_PARM_2,r5
	mov	(_memcpy_PARM_2 + 1),r6
	mov	(_memcpy_PARM_2 + 2),#0x0
;	genPlus
;     genPlusIncr
	mov	dpl,_realloc_pthis_1_1
	mov	dph,(_realloc_pthis_1_1 + 1)
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xfc
	mov	_memcpy_PARM_3,a
	mov	a,r6
	addc	a,#0xff
	mov	(_memcpy_PARM_3 + 1),a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	push	ar7
	push	ar0
	lcall	_memcpy
	pop	ar0
	pop	ar7
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:115: free(p);
;	genCall
	mov	dpl,_realloc_p_1_1
	mov	dph,(_realloc_p_1_1 + 1)
	mov	b,(_realloc_p_1_1 + 2)
	push	ar7
	push	ar0
	lcall	_free
	pop	ar0
	pop	ar7
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:123: ret = malloc(size);
;	genCall
	mov	dpl,_realloc_PARM_2
	mov	dph,(_realloc_PARM_2 + 1)
	lcall	_malloc
	mov	r7,dpl
	mov	r0,dph
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:126: return ret;
;	genRet
	mov	dpl,r7
	mov	dph,r0
;	Peephole 300	removed redundant label 00116$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
