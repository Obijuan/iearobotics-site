;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:26 2006
;--------------------------------------------------------
	.module realloc
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc_PARM_2
	.globl _realloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_realloc_sloc0_1_0:
	.ds 2
_realloc_sloc1_1_0:
	.ds 3
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_realloc_PARM_2:
	.ds 2
_realloc_p_1_1:
	.ds 3
_realloc_pnew_1_1:
	.ds 2
_realloc_ret_1_1:
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'realloc'
;------------------------------------------------------------
;sloc0                     Allocated with name '_realloc_sloc0_1_0'
;sloc1                     Allocated with name '_realloc_sloc1_1_0'
;size                      Allocated with name '_realloc_PARM_2'
;p                         Allocated with name '_realloc_p_1_1'
;pthis                     Allocated with name '_realloc_pthis_1_1'
;pnew                      Allocated with name '_realloc_pnew_1_1'
;ret                       Allocated with name '_realloc_ret_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:67: void xdata * realloc (void * p, size_t size)
;	-----------------------------------------
;	 function realloc
;	-----------------------------------------
_realloc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_realloc_p_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:75: pthis = _sdcc_find_memheader(p);
;	genAssign
	mov	dptr,#_realloc_p_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCast
	mov	ar5,r2
	mov	ar6,r3
;	genCall
	mov	dpl,r5
	mov	dph,r6
	push	ar2
	push	ar3
	push	ar4
	lcall	__sdcc_find_memheader
	mov	r5,dpl
	mov	r6,dph
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:76: if (pthis)
;	genIfx
	mov	a,r5
	orl	a,r6
;	genIfxJump
	jnz	00124$
	ljmp	00114$
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
;	genAssign
	mov	dptr,#_realloc_PARM_2
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genCmpGt
;	genCmp
	clr	c
	mov	a,#0xFB
	subb	a,r7
	mov	a,#0xFF
	subb	a,r0
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00111$
;	Peephole 300	removed redundant label 00125$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
;	genAssign
	mov	dptr,#_realloc_ret_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	ljmp	00115$
00111$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genPlus
	mov	dptr,#_realloc_PARM_2
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r0 instead of ar0
	addc	a,r0
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r5
	mov	dph,r6
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genCast
	mov	ar1,r7
	mov	ar2,r0
;	genAssign
	mov	ar3,r5
	mov	ar4,r6
;	genCast
;	genMinus
	mov	a,r1
	clr	c
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	mov	r1,a
	mov	a,r2
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r2,a
;	genAssign
	mov	dptr,#_realloc_PARM_2
	movx	a,@dptr
	mov	_realloc_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_realloc_sloc0_1_0 + 1),a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r1
	subb	a,_realloc_sloc0_1_0
	mov	a,r2
	subb	a,(_realloc_sloc0_1_0 + 1)
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	Peephole 129.d	optimized condition
	pop	ar4
	pop	ar3
	pop	ar2
	jc	00108$
;	Peephole 300	removed redundant label 00126$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:88: pthis->len = size;
;	genPlus
;     genPlusIncr
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_realloc_sloc0_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_sloc0_1_0 + 1)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:89: ret = p;
;	genAssign
;	genCast
	mov	dptr,#_realloc_ret_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	ljmp	00115$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:93: if ((_sdcc_prev_memheader) &&
;	genAssign
	mov	dptr,#__sdcc_prev_memheader
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
;	genIfx
	mov	r3,a
;	Peephole 135	removed redundant mov
	orl	a,r2
;	genIfxJump
	jnz	00127$
	ljmp	00104$
00127$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:94: ((((unsigned int)pthis->next) -
;	genAssign
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
;	genAssign
	mov	ar4,r2
	mov	ar1,r3
;	genCast
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r7,a
	mov	a,r0
;	Peephole 236.l	used r1 instead of ar1
	subb	a,r1
	mov	r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:96: _sdcc_prev_memheader->len) >= size))
;	genPlus
;     genPlusIncr
	mov	dpl,r2
	mov	dph,r3
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus
	mov	a,r7
	clr	c
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	mov	r7,a
	mov	a,r0
;	Peephole 236.l	used r1 instead of ar1
	subb	a,r1
	mov	r0,a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r7
	subb	a,_realloc_sloc0_1_0
	mov	a,r0
	subb	a,(_realloc_sloc0_1_0 + 1)
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00104$
;	Peephole 300	removed redundant label 00128$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
;	genPlus
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r4,a
;	Peephole 236.g	used r1 instead of ar1
	mov	a,r1
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r1,a
;	genAssign
	mov	dptr,#_realloc_pnew_1_1
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:99: _sdcc_prev_memheader->next = pnew;
;	genPointerSet
;     genFarPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:105: memmove(pnew, pthis, pthis->len);
;	genAssign
;	genCast
	mov	r2,#0x0
;	genAssign
	mov	ar3,r5
	mov	ar7,r6
;	genCast
	mov	_realloc_sloc1_1_0,r3
	mov	(_realloc_sloc1_1_0 + 1),r7
	mov	(_realloc_sloc1_1_0 + 2),#0x0
;	genPlus
;     genPlusIncr
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genAssign
	mov	dptr,#_memmove_PARM_2
	mov	a,_realloc_sloc1_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_sloc1_1_0 + 1)
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_sloc1_1_0 + 2)
	movx	@dptr,a
;	genAssign
	mov	dptr,#_memmove_PARM_3
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genCall
	mov	dpl,r4
	mov	dph,r1
	mov	b,r2
	lcall	_memmove
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:106: pnew->len = size;
;	genAssign
	mov	dptr,#_realloc_pnew_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
;     genPlusIncr
	mov	dpl,r2
	mov	dph,r3
	inc	dptr
	inc	dptr
;	genPointerSet
;     genFarPointerSet
	mov	a,_realloc_sloc0_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(_realloc_sloc0_1_0 + 1)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:107: ret = MEM(pnew);
;	genPlus
	mov	dptr,#_realloc_ret_1_1
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
	ljmp	00115$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:111: ret = malloc(size - HEADER_SIZE);
;	genAssign
	mov	dptr,#_realloc_PARM_2
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genMinus
;	genMinusDec
	mov	a,r2
	add	a,#0xfc
	mov	r2,a
	mov	a,r3
	addc	a,#0xff
	mov	r3,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	push	ar5
	push	ar6
	lcall	_malloc
	mov	r2,dpl
	mov	r3,dph
	pop	ar6
	pop	ar5
;	genAssign
	mov	dptr,#_realloc_ret_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:112: if (ret)
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00115$
;	Peephole 300	removed redundant label 00129$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:114: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
;	genAssign
;	genCast
	mov	r4,#0x0
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r7,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r0,a
;	genCast
	mov	r1,#0x0
;	genPlus
;     genPlusIncr
	mov	dpl,r5
	mov	dph,r6
	inc	dptr
	inc	dptr
;	genPointerGet
;	genFarPointerGet
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genMinus
;	genMinusDec
	mov	a,r5
	add	a,#0xfc
	mov	r5,a
	mov	a,r6
	addc	a,#0xff
	mov	r6,a
;	genAssign
	mov	dptr,#_memcpy_PARM_2
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genAssign
	mov	dptr,#_memcpy_PARM_3
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_memcpy
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:115: free(p);
;	genAssign
	mov	dptr,#_realloc_p_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_free
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00115$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:123: ret = malloc(size);
;	genAssign
	mov	dptr,#_realloc_PARM_2
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	lcall	_malloc
	mov	a,dpl
	mov	b,dph
;	genAssign
	mov	dptr,#_realloc_ret_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/realloc.c:126: return ret;
;	genAssign
	mov	dptr,#_realloc_ret_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
;	genRet
;	Peephole 234.b	loading dph directly from a(ccumulator), r3 not set
	mov	dpl,r2
	mov	dph,a
;	Peephole 300	removed redundant label 00116$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
