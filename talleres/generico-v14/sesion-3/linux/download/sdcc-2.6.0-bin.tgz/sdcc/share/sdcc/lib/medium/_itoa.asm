;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:07 2006
;--------------------------------------------------------
	.module _itoa
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __itoa
	.globl __uitoa
	.globl __itoa_PARM_3
	.globl __itoa_PARM_2
	.globl __uitoa_PARM_3
	.globl __uitoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__uitoa_sloc0_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__uitoa_PARM_2:
	.ds 3
__uitoa_PARM_3:
	.ds 1
__uitoa_value_1_1:
	.ds 2
__uitoa_index_1_1:
	.ds 1
__uitoa_i_1_1:
	.ds 1
__itoa_PARM_2:
	.ds 3
__itoa_PARM_3:
	.ds 1
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_uitoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__uitoa_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:18: void _uitoa(unsigned int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _uitoa
;	-----------------------------------------
__uitoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dph
	mov	a,dpl
	mov	r0,#__uitoa_value_1_1
	movx	@r0,a
	inc	r0
	mov	a,r2
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:26: do {
;	genAssign
	mov	r3,#0x10
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:27: string[--index] = '0' + (value % radix);
;	genMinus
;	genMinusDec
	dec	r3
;	genPlus
	mov	r0,#__uitoa_PARM_2
	movx	a,@r0
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	mov	r5,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
;	genCast
	mov	r0,#__uitoa_PARM_3
	movx	a,@r0
	mov	__uitoa_sloc0_1_0,a
	mov	(__uitoa_sloc0_1_0 + 1),#0x00
;	genAssign
	mov	r0,#__moduint_PARM_2
	mov	a,__uitoa_sloc0_1_0
	movx	@r0,a
	inc	r0
	mov	a,(__uitoa_sloc0_1_0 + 1)
	movx	@r0,a
;	genCall
	mov	r0,#__uitoa_value_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	lcall	__moduint
	mov	r4,dpl
	mov	r2,dph
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
;	genCast
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
;	genPointerSet
;	genGenPointerSet
	mov	r4,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 191	removed redundant mov
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00117$
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r2,a
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	genPointerSet
;	genGenPointerSet
	mov	r2,a
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
;	Peephole 191	removed redundant mov
	lcall	__gptrput
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:29: value /= radix;
;	genAssign
	mov	r0,#__divuint_PARM_2
	mov	a,__uitoa_sloc0_1_0
	movx	@r0,a
	inc	r0
	mov	a,(__uitoa_sloc0_1_0 + 1)
	movx	@r0,a
;	genCall
	mov	r0,#__uitoa_value_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	push	ar3
	lcall	__divuint
	mov	r0,#__uitoa_value_1_1
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:30: } while (value != 0);
;	genCmpEq
	mov	r0,#__uitoa_value_1_1
;	gencjneshort
	movx	a,@r0
	cjne	a,#0x00,00118$
	inc	r0
	movx	a,@r0
	cjne	a,#0x00,00118$
	sjmp	00119$
00118$:
	ljmp	00103$
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:32: do {
;	genAssign
	mov	r0,#__uitoa_i_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	genAssign
	mov	r0,#__uitoa_index_1_1
	mov	a,r3
	movx	@r0,a
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:33: string[i++] = string[index++];
;	genAssign
	mov	r0,#__uitoa_i_1_1
	movx	a,@r0
	mov	r4,a
;	genPlus
	mov	r0,#__uitoa_i_1_1
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
;	genPlus
	mov	r0,#__uitoa_PARM_2
	movx	a,@r0
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r4,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
;	genAssign
	mov	r0,#__uitoa_index_1_1
	movx	a,@r0
	mov	r7,a
;	genPlus
	mov	r0,#__uitoa_index_1_1
	movx	a,@r0
	add	a,#0x01
	movx	@r0,a
;	genPlus
	mov	r0,#__uitoa_PARM_2
	movx	a,@r0
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	mov	r7,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r2
	mov	b,r3
	lcall	__gptrget
;	genPointerSet
;	genGenPointerSet
	mov	r7,a
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
;	Peephole 191	removed redundant mov
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:34: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt
	mov	r0,#__uitoa_index_1_1
;	genCmp
	movx	a,@r0
	cjne	a,#0x10,00120$
00120$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00106$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:36: string[i] = 0; /* string terminator */
;	genPlus
	mov	r0,#__uitoa_PARM_2
	mov	r1,#__uitoa_i_1_1
	movx	a,@r1
	xch	a,b
	movx	a,@r0
	add	a,b
	mov	r2,a
	inc	r0
	movx	a,@r0
	addc	a,#0x00
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__gptrput
;
;------------------------------------------------------------
;Allocation info for local variables in function '_itoa'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:39: void _itoa(int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _itoa
;	-----------------------------------------
__itoa:
;	genReceive
	mov	r2,dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:41: if (value < 0 && radix == 10) {
;	genCmpLt
;	genCmp
;	peephole 177.g	optimized mov sequence
	mov	a,dph
	mov	r3,a
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00102$
;	Peephole 300	removed redundant label 00108$
;	genCmpEq
	mov	r0,#__itoa_PARM_3
;	gencjneshort
	movx	a,@r0
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	a,#0x0A,00102$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00109$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:42: *string++ = '-';
;	genAssign
	mov	r0,#__itoa_PARM_2
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
	inc	r0
	movx	a,@r0
	mov	r6,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r6
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus
	mov	r0,#__itoa_PARM_2
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	movx	@r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	inc	r0
	movx	@r0,a
	inc	r0
	mov	a,r6
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:43: value = -value;
;	genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_itoa.c:45: _uitoa(value, string, radix);
;	genAssign
	mov	r0,#__itoa_PARM_2
	mov	r1,#__uitoa_PARM_2
	movx	a,@r0
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
	inc	r0
	movx	a,@r0
	inc	r1
	movx	@r1,a
;	genAssign
	mov	r0,#__itoa_PARM_3
	mov	r1,#__uitoa_PARM_3
	movx	a,@r0
	movx	@r1,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__uitoa
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
