;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:00 2006
;--------------------------------------------------------
	.module _divuint
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divuint_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c:47: _divuint_dummy (void) _naked
;	-----------------------------------------
;	 function _divuint_dummy
;	-----------------------------------------
__divuint_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c:106: 
;	genInline
	                .globl __divuint
        __divuint:
;	# 67 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c"
	                .globl __divint
	                mov a,sp
	                add a,#-2 ; 2 bytes return address
	                mov r0,a ; r0 points to yh
	                mov a,@r0 ; load yh
	                mov r1,a
	                dec r0
	                mov a,@r0 ; load yl
	                mov r0,a
        __divint:
; entry point for __divsint
;	# 107 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divuint.c"
	                mov r2,#16
	                clr a
	                mov r3,a
	                mov r4,a
        loop:
	mov a,dpl ; x <<= 1
	                add a,acc
	                mov dpl,a
	                mov a,dph
	                rlc a
	                mov dph,a
	                mov a,r3 ; reste <<= 1
	                rlc a ; feed in carry
	                mov r3,a
	                mov a,r4
	                rlc a
	                mov r4,a
	                mov a,r3 ; reste - y
	                subb a,r0 ; here carry is always clear, because
	                                        ; reste <<= 1 never overflows
	                mov b,a
	                mov a,r4
	                subb a,r1
	                jc smaller ; reste >= y?
	                mov r4,a ; -> yes; reste = reste - y;
	                mov r3,b
	                orl dpl,#1
        smaller:
; -> no
	                djnz r2,loop
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
