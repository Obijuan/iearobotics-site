;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:27 2006
;--------------------------------------------------------
	.module gets
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _gets
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_gets_str_1_1:
	.ds 3
_gets_s_1_1:
	.ds 3
_gets_count_1_1:
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'gets'
;------------------------------------------------------------
;str                       Allocated with name '_gets_str_1_1'
;s                         Allocated with name '_gets_s_1_1'
;c                         Allocated with name '_gets_c_1_1'
;count                     Allocated with name '_gets_count_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:3: char * gets(const char *str) {
;	-----------------------------------------
;	 function gets
;	-----------------------------------------
_gets:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_gets_str_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:4: char *s=str;
;	genAssign
	mov	dptr,#_gets_str_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign
	mov	dptr,#_gets_s_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:6: unsigned int count=0;
;	genAssign
	mov	dptr,#_gets_count_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:8: while (1) {
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:9: c=getchar();
;	genCall
	lcall	_getchar
	mov	r2,dpl
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:10: switch(c) {
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x08,00118$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00118$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x0A,00119$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00119$:
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x0D,00120$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00120$:
	ljmp	00106$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:11: case '\b': // backspace
00101$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:12: if (count) {
;	genAssign
	mov	dptr,#_gets_count_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
;	genIfx
	mov	r4,a
;	Peephole 135	removed redundant mov
	orl	a,r3
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00109$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:13: putchar ('\b');
;	genCall
	mov	dpl,#0x08
	push	ar3
	push	ar4
	lcall	_putchar
	pop	ar4
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:14: putchar (' ');
;	genCall
	mov	dpl,#0x20
	push	ar3
	push	ar4
	lcall	_putchar
	pop	ar4
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:15: putchar ('\b');
;	genCall
	mov	dpl,#0x08
	push	ar3
	push	ar4
	lcall	_putchar
	pop	ar4
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:16: s--;
;	genAssign
	mov	dptr,#_gets_s_1_1
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00122$
	dec	r6
00122$:
;	genAssign
	mov	dptr,#_gets_s_1_1
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:17: count--;
;	genMinus
;	genMinusDec
	dec	r3
	cjne	r3,#0xff,00123$
	dec	r4
00123$:
;	genAssign
	mov	dptr,#_gets_count_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:19: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:21: case '\r': // CR or LF
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:22: putchar('\r');
;	genCall
	mov	dpl,#0x0D
	lcall	_putchar
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:23: putchar('\n');
;	genCall
	mov	dpl,#0x0A
	lcall	_putchar
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:24: *s=0;
;	genAssign
	mov	dptr,#_gets_s_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:25: return str;
;	genAssign
	mov	dptr,#_gets_str_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genRet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:26: default:
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:27: *s++=c;
;	genAssign
	mov	dptr,#_gets_s_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	mov	a,r2
	lcall	__gptrput
;	genPlus
	mov	dptr,#_gets_s_1_1
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:28: count++;
;	genAssign
	mov	dptr,#_gets_count_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
	mov	dptr,#_gets_count_1_1
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:29: putchar(c);
;	genCall
	mov	dpl,r2
	lcall	_putchar
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/gets.c:31: }
	ljmp	00109$
;	Peephole 259.b	removed redundant label 00111$ and ret
;
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
