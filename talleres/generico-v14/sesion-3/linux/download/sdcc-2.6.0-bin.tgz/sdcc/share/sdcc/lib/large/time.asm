;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:29 2006
;--------------------------------------------------------
	.module time
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___day
	.globl ___month
	.globl _RtcRead
	.globl _time
	.globl _asctime
	.globl _ctime
	.globl _localtime
	.globl _gmtime
	.globl _mktime
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_asctime_sloc0_1_0:
	.ds 2
_asctime_sloc1_1_0:
	.ds 2
_asctime_sloc2_1_0:
	.ds 2
_asctime_sloc3_1_0:
	.ds 2
_gmtime_sloc1_1_0:
	.ds 4
_gmtime_sloc2_1_0:
	.ds 4
_mktime_sloc1_1_0:
	.ds 2
_mktime_sloc2_1_0:
	.ds 4
_mktime_sloc3_1_0:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_time_timeptr_1_1:
	.ds 3
_time_now_1_1:
	.ds 12
_time_t_1_1:
	.ds 4
_ascTimeBuffer:
	.ds 32
_CheckTime_timeptr_1_1:
	.ds 3
_asctime_timeptr_1_1:
	.ds 3
_ctime_timep_1_1:
	.ds 3
_lastTime:
	.ds 12
_localtime_timep_1_1:
	.ds 3
_gmtime_timep_1_1:
	.ds 3
_gmtime_epoch_1_1:
	.ds 4
_gmtime_monthLength_1_1:
	.ds 1
_gmtime_days_1_1:
	.ds 4
_mktime_timeptr_1_1:
	.ds 3
_mktime_seconds_1_1:
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'RtcRead'
;------------------------------------------------------------
;timeptr                   Allocated with name '_RtcRead_timeptr_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:38: unsigned char RtcRead(struct tm *timeptr) {
;	-----------------------------------------
;	 function RtcRead
;	-----------------------------------------
_RtcRead:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:41: return 0;
;	genRet
	mov	dpl,#0x00
;	Peephole 300	removed redundant label 00101$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'time'
;------------------------------------------------------------
;timeptr                   Allocated with name '_time_timeptr_1_1'
;now                       Allocated with name '_time_now_1_1'
;t                         Allocated with name '_time_t_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:46: time_t time(time_t *timeptr) {
;	-----------------------------------------
;	 function time
;	-----------------------------------------
_time:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_time_timeptr_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:48: time_t t=-1;
;	genAssign
	mov	dptr,#_time_t_1_1
	mov	a,#0xFF
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
	inc	dptr
	mov	a,#0xFF
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:50: if (RtcRead(&now)) {
;	genCall
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_time_now_1_1
	mov	b,#0x00
	lcall	_RtcRead
	mov	a,dpl
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00109$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:51: t=mktime(&now);
;	genCall
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_time_now_1_1
	mov	b,#0x00
	lcall	_mktime
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	genAssign
	mov	dptr,#_time_t_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:53: if (timeptr) {
;	genAssign
	mov	dptr,#_time_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genIfx
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00104$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:54: *timeptr=t;
;	genAssign
	mov	dptr,#_time_t_1_1
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__gptrput
	inc	dptr
	mov	a,r6
	lcall	__gptrput
	inc	dptr
	mov	a,r7
	lcall	__gptrput
	inc	dptr
	mov	a,r0
	lcall	__gptrput
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:56: return t;
;	genAssign
	mov	dptr,#_time_t_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genRet
	mov	r5,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 191	removed redundant mov
;	Peephole 300	removed redundant label 00105$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'CheckTime'
;------------------------------------------------------------
;timeptr                   Allocated with name '_CheckTime_timeptr_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:69: static void CheckTime(struct tm *timeptr) {
;	-----------------------------------------
;	 function CheckTime
;	-----------------------------------------
_CheckTime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:80: if (timeptr->tm_sec>59) timeptr->tm_sec=59;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r5,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x3B
	jnc	00102$
;	Peephole 300	removed redundant label 00128$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x3B
	lcall	__gptrput
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:81: if (timeptr->tm_min>59) timeptr->tm_min=59;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00129$
	inc	r3
00129$:
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r5,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x3B
	jnc	00104$
;	Peephole 300	removed redundant label 00130$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x3B
	lcall	__gptrput
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:82: if (timeptr->tm_hour>23) timeptr->tm_hour=23;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x02
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r5,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x17
	jnc	00106$
;	Peephole 300	removed redundant label 00131$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x17
	lcall	__gptrput
00106$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:83: if (timeptr->tm_wday>6) timeptr->tm_wday=6;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r5,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x06
	jnc	00108$
;	Peephole 300	removed redundant label 00132$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x06
	lcall	__gptrput
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:84: if (timeptr->tm_mday<1) timeptr->tm_mday=1;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x03
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;	genCmpLt
;	genCmp
	cjne	r5,#0x01,00133$
00133$:
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00112$
;	Peephole 300	removed redundant label 00134$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x01
	lcall	__gptrput
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00113$
00112$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:85: else if (timeptr->tm_mday>31) timeptr->tm_mday=31;
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r5
	add	a,#0xff - 0x1F
	jnc	00113$
;	Peephole 300	removed redundant label 00135$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x1F
	lcall	__gptrput
00113$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:86: if (timeptr->tm_mon>11) timeptr->tm_mon=11;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r5,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x0B
	jnc	00115$
;	Peephole 300	removed redundant label 00136$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,#0x0B
	lcall	__gptrput
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:87: if (timeptr->tm_year<0) timeptr->tm_year=0;
;	genAssign
	mov	dptr,#_CheckTime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x05
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	lcall	__gptrget
;	genCmpLt
;	genCmp
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00118$
;	Peephole 300	removed redundant label 00137$
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 181	changed mov to clr
	clr	a
	lcall	__gptrput
	inc	dptr
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 253.c	replaced lcall with ljmp
	ljmp	__gptrput
00118$:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'asctime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_asctime_sloc0_1_0'
;sloc1                     Allocated with name '_asctime_sloc1_1_0'
;sloc2                     Allocated with name '_asctime_sloc2_1_0'
;sloc3                     Allocated with name '_asctime_sloc3_1_0'
;timeptr                   Allocated with name '_asctime_timeptr_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:91: char *asctime(struct tm *timeptr) {
;	-----------------------------------------
;	 function asctime
;	-----------------------------------------
_asctime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_asctime_timeptr_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:92: CheckTime(timeptr);
;	genAssign
	mov	dptr,#_asctime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_CheckTime
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:96: timeptr->tm_year+1900);
;	genAssign
	mov	dptr,#_asctime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x05
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	lcall	__gptrget
	mov	r6,a
;	genPlus
;     genPlusIncr
	mov	a,#0x6C
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	mov	a,#0x07
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:95: timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec, 
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r7,a
;	genCast
	mov	_asctime_sloc0_1_0,r7
	mov	(_asctime_sloc0_1_0 + 1),#0x00
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r1,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r7,a
	mov	ar0,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r1
	mov	dph,r7
	mov	b,r0
	lcall	__gptrget
	mov	r1,a
;	genCast
	mov	_asctime_sloc1_1_0,r1
	mov	(_asctime_sloc1_1_0 + 1),#0x00
;	genPlus
;     genPlusIncr
	mov	a,#0x02
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r7,a
	mov	ar1,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r0
	mov	dph,r7
	mov	b,r1
	lcall	__gptrget
	mov	r0,a
;	genCast
	mov	_asctime_sloc2_1_0,r0
	mov	(_asctime_sloc2_1_0 + 1),#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:94: __day[timeptr->tm_wday], __month[timeptr->tm_mon], timeptr->tm_mday,
;	genPlus
;     genPlusIncr
	mov	a,#0x03
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r1,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r7,a
	mov	ar0,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r1
	mov	dph,r7
	mov	b,r0
	lcall	__gptrget
	mov	r1,a
;	genCast
	mov	_asctime_sloc3_1_0,r1
	mov	(_asctime_sloc3_1_0 + 1),#0x00
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r7,a
	mov	ar1,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r0
	mov	dph,r7
	mov	b,r1
	lcall	__gptrget
;	genLeftShift
;	genLeftShiftLiteral
;	genlshOne
;	Peephole 105	removed redundant mov
;	genPlus
;	Peephole 204	removed redundant mov
	add	a,acc
	mov	r0,a
;	Peephole 177.b	removed redundant mov
;	Peephole 181	changed mov to clr
;	genPointerGet
;	genCodePointerGet
;	Peephole 186.c	optimized movc sequence
	mov	r7,a
	mov	dptr,#___month
	movc	a,@a+dptr
	xch	a,r7
	inc	dptr
	movc	a,@a+dptr
	mov	r0,a
;	genCast
	mov	r1,#0x80
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
;	genLeftShift
;	genLeftShiftLiteral
;	genlshOne
;	Peephole 105	removed redundant mov
;	genPlus
;	Peephole 204	removed redundant mov
	add	a,acc
;	Peephole 177.b	removed redundant mov
;	Peephole 181	changed mov to clr
;	genPointerGet
;	genCodePointerGet
;	Peephole 186.c	optimized movc sequence
;	Peephole 177.c	removed redundant move
	mov	r2,a
	mov	dptr,#___day
	movc	a,@a+dptr
	xch	a,r2
	inc	dptr
	movc	a,@a+dptr
	mov	r3,a
;	genCast
	mov	r4,#0x80
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:93: sprintf (ascTimeBuffer, "%s %s %2d %02d:%02d:%02d %04d\n",
;	genIpush
	push	ar5
	push	ar6
;	genIpush
	push	_asctime_sloc0_1_0
	push	(_asctime_sloc0_1_0 + 1)
;	genIpush
	push	_asctime_sloc1_1_0
	push	(_asctime_sloc1_1_0 + 1)
;	genIpush
	push	_asctime_sloc2_1_0
	push	(_asctime_sloc2_1_0 + 1)
;	genIpush
	push	_asctime_sloc3_1_0
	push	(_asctime_sloc3_1_0 + 1)
;	genIpush
	push	ar7
	push	ar0
	push	ar1
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genIpush
	mov	a,#__str_0
	push	acc
	mov	a,#(__str_0 >> 8)
	push	acc
	mov	a,#0x80
	push	acc
;	genIpush
	mov	a,#_ascTimeBuffer
	push	acc
	mov	a,#(_ascTimeBuffer >> 8)
	push	acc
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
;	genCall
	lcall	_sprintf
	mov	a,sp
	add	a,#0xea
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:97: return ascTimeBuffer;
;	genRet
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_ascTimeBuffer
	mov	b,#0x00
;	Peephole 300	removed redundant label 00101$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ctime'
;------------------------------------------------------------
;timep                     Allocated with name '_ctime_timep_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:100: char *ctime(time_t *timep) {
;	-----------------------------------------
;	 function ctime
;	-----------------------------------------
_ctime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_ctime_timep_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:101: return asctime(localtime(timep));
;	genAssign
	mov	dptr,#_ctime_timep_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_localtime
;	genCall
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	Peephole 238.d	removed 3 redundant moves
;	genRet
;	Peephole 150.d	removed misc moves via dph, dpl, b before return
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	_asctime
;
;------------------------------------------------------------
;Allocation info for local variables in function 'localtime'
;------------------------------------------------------------
;timep                     Allocated with name '_localtime_timep_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:117: struct tm *localtime(time_t *timep) {
;	-----------------------------------------
;	 function localtime
;	-----------------------------------------
_localtime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_localtime_timep_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:118: return gmtime(timep);
;	genAssign
	mov	dptr,#_localtime_timep_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	genRet
;	Peephole 150.d	removed misc moves via dph, dpl, b before return
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	_gmtime
;
;------------------------------------------------------------
;Allocation info for local variables in function 'gmtime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_gmtime_sloc0_1_0'
;sloc1                     Allocated with name '_gmtime_sloc1_1_0'
;sloc2                     Allocated with name '_gmtime_sloc2_1_0'
;timep                     Allocated with name '_gmtime_timep_1_1'
;epoch                     Allocated with name '_gmtime_epoch_1_1'
;year                      Allocated with name '_gmtime_year_1_1'
;month                     Allocated with name '_gmtime_month_1_1'
;monthLength               Allocated with name '_gmtime_monthLength_1_1'
;days                      Allocated with name '_gmtime_days_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:121: struct tm *gmtime(time_t *timep) {
;	-----------------------------------------
;	 function gmtime
;	-----------------------------------------
_gmtime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_gmtime_timep_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:122: unsigned long epoch=*timep;
;	genAssign
	mov	dptr,#_gmtime_timep_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	lcall	__gptrget
	mov	r3,a
	inc	dptr
	lcall	__gptrget
	mov	r4,a
	inc	dptr
	lcall	__gptrget
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:127: lastTime.tm_sec=epoch%60;
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	__modulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_lastTime
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:128: epoch/=60; // now it is minutes
;	genAssign
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:129: lastTime.tm_min=epoch%60;
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__divulong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	__modulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0001)
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:130: epoch/=60; // now it is hours
;	genAssign
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:131: lastTime.tm_hour=epoch%24;
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__divulong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	__modulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0002)
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:132: epoch/=24; // now it is days
;	genAssign
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:133: lastTime.tm_wday=(epoch+4)%7;
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	__divulong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r6,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r7,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	mov	r0,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r1,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x07
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	__modulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0007)
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:136: days=0;
;	genAssign
	mov	dptr,#_gmtime_days_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:137: while((days += (LEAP_YEAR(year) ? 366 : 365)) <= epoch) {
;	genAssign
	mov	r6,#0xB2
	mov	r7,#0x07
00101$:
;	genAnd
	mov	a,#0x03
	anl	a,r6
;	genNot
	mov	r0,a
	mov	r1,#0x00
;	Peephole 177.d	removed redundant move
	orl	a,r1
	cjne	a,#0x01,00134$
00134$:
	clr	a
	rlc	a
;	genIfx
	mov	r0,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00119$
;	Peephole 300	removed redundant label 00135$
;	genAssign
	mov	r0,#0x6E
	mov	r1,#0x01
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00120$
00119$:
;	genAssign
	mov	r0,#0x6D
	mov	r1,#0x01
00120$:
;	genIpush
	push	ar6
	push	ar7
;	genAssign
	mov	dptr,#_gmtime_days_1_1
	movx	a,@dptr
	mov	_gmtime_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc1_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc1_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc1_1_0 + 3),a
;	genCast
	mov	ar6,r0
	mov	a,r1
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	r0,a
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,_gmtime_sloc1_1_0
	mov	r6,a
;	Peephole 236.g	used r1 instead of ar1
	mov	a,r1
	addc	a,(_gmtime_sloc1_1_0 + 1)
	mov	r1,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	addc	a,(_gmtime_sloc1_1_0 + 2)
	mov	r7,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
	addc	a,(_gmtime_sloc1_1_0 + 3)
	mov	r0,a
;	genAssign
	mov	dptr,#_gmtime_days_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r6
	mov	a,r3
	subb	a,r1
	mov	a,r4
	subb	a,r7
	mov	a,r5
	subb	a,r0
;	genIpop
;	genIfx
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
;	Peephole 129.c	optimized condition
	pop	ar7
	pop	ar6
	jc	00103$
;	Peephole 300	removed redundant label 00136$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:138: year++;
;	genPlus
;     genPlusIncr
	inc	r6
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 243	avoided branch to sjmp
	cjne	r6,#0x00,00101$
	inc	r7
;	Peephole 300	removed redundant label 00137$
	sjmp	00101$
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:140: lastTime.tm_year=year-1900;
;	genMinus
	mov	a,r6
	add	a,#0x94
	mov	r0,a
	mov	a,r7
	addc	a,#0xf8
	mov	r1,a
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0005)
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:142: days -= LEAP_YEAR(year) ? 366 : 365;
;	genAnd
	anl	ar6,#0x03
	mov	r7,#0x00
;	genNot
	mov	a,r6
	orl	a,r7
	cjne	a,#0x01,00138$
00138$:
	clr	a
	rlc	a
;	genIfx
	mov	r0,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00121$
;	Peephole 300	removed redundant label 00139$
;	genAssign
	mov	r0,#0x6E
	mov	r1,#0x01
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00122$
00121$:
;	genAssign
	mov	r0,#0x6D
	mov	r1,#0x01
00122$:
;	genIpush
	push	ar6
	push	ar7
;	genAssign
	mov	dptr,#_gmtime_days_1_1
	movx	a,@dptr
	mov	_gmtime_sloc2_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc2_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc2_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(_gmtime_sloc2_1_0 + 3),a
;	genCast
	mov	ar6,r0
	mov	a,r1
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	r0,a
;	genMinus
	mov	dptr,#_gmtime_days_1_1
	mov	a,_gmtime_sloc2_1_0
	clr	c
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	movx	@dptr,a
	mov	a,(_gmtime_sloc2_1_0 + 1)
;	Peephole 236.l	used r1 instead of ar1
	subb	a,r1
	inc	dptr
	movx	@dptr,a
	mov	a,(_gmtime_sloc2_1_0 + 2)
;	Peephole 236.l	used r7 instead of ar7
	subb	a,r7
	inc	dptr
	movx	@dptr,a
	mov	a,(_gmtime_sloc2_1_0 + 3)
;	Peephole 236.l	used r0 instead of ar0
	subb	a,r0
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:143: epoch -= days; // now it is days in this year, starting at 0
;	genAssign
	mov	dptr,#_gmtime_days_1_1
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus
	mov	a,r2
	clr	c
;	Peephole 236.l	used r6 instead of ar6
	subb	a,r6
	mov	r2,a
	mov	a,r3
;	Peephole 236.l	used r7 instead of ar7
	subb	a,r7
	mov	r3,a
	mov	a,r4
;	Peephole 236.l	used r0 instead of ar0
	subb	a,r0
	mov	r4,a
	mov	a,r5
;	Peephole 236.l	used r1 instead of ar1
	subb	a,r1
	mov	r5,a
;	genAssign
	mov	dptr,#_gmtime_epoch_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:144: lastTime.tm_yday=epoch;
;	genCast
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0008)
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:171: return &lastTime;
;	genIpop
	pop	ar7
	pop	ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:149: for (month=0; month<12; month++) {
;	genAssign
	mov	r2,#0x00
00113$:
;	genCmpLt
;	genCmp
	cjne	r2,#0x0C,00140$
00140$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.b	removed sjmp by inverse jump logic
	jnc	00116$
;	Peephole 300	removed redundant label 00141$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:150: if (month==1) { // februari
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r2,#0x01,00108$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00142$
;	Peephole 300	removed redundant label 00143$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:151: if (LEAP_YEAR(year)) {
;	genIfx
	mov	a,r6
	orl	a,r7
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00105$
;	Peephole 300	removed redundant label 00144$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:152: monthLength=29;
;	genAssign
	mov	dptr,#_gmtime_monthLength_1_1
	mov	a,#0x1D
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:154: monthLength=28;
;	genAssign
	mov	dptr,#_gmtime_monthLength_1_1
	mov	a,#0x1C
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:157: monthLength = monthDays[month];
;	genPlus
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
;	Peephole 181	changed mov to clr
;	genPointerGet
;	genCodePointerGet
;	Peephole 186.d	optimized movc sequence
	mov	dptr,#_monthDays
	movc	a,@a+dptr
;	genAssign
	mov	r3,a
	mov	dptr,#_gmtime_monthLength_1_1
;	Peephole 100	removed redundant mov
	movx	@dptr,a
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:160: if (epoch>=monthLength) {
;	genAssign
	mov	dptr,#_gmtime_epoch_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genAssign
	mov	dptr,#_gmtime_monthLength_1_1
	movx	a,@dptr
	mov	r1,a
;	genCast
	mov	_gmtime_sloc2_1_0,r1
	mov	(_gmtime_sloc2_1_0 + 1),#0x00
	mov	(_gmtime_sloc2_1_0 + 2),#0x00
	mov	(_gmtime_sloc2_1_0 + 3),#0x00
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r3
	subb	a,_gmtime_sloc2_1_0
	mov	a,r4
	subb	a,(_gmtime_sloc2_1_0 + 1)
	mov	a,r5
	subb	a,(_gmtime_sloc2_1_0 + 2)
	mov	a,r0
	subb	a,(_gmtime_sloc2_1_0 + 3)
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00116$
;	Peephole 300	removed redundant label 00145$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:161: epoch-=monthLength;
;	genMinus
	mov	dptr,#_gmtime_epoch_1_1
	mov	a,r3
	clr	c
	subb	a,_gmtime_sloc2_1_0
	movx	@dptr,a
	mov	a,r4
	subb	a,(_gmtime_sloc2_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	subb	a,(_gmtime_sloc2_1_0 + 2)
	inc	dptr
	movx	@dptr,a
	mov	a,r0
	subb	a,(_gmtime_sloc2_1_0 + 3)
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:149: for (month=0; month<12; month++) {
;	genPlus
;     genPlusIncr
	inc	r2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00113$
00116$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:166: lastTime.tm_mon=month;
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0004)
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:167: lastTime.tm_mday=epoch+1;
;	genAssign
	mov	dptr,#_gmtime_epoch_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genCast
;	genPlus
;     genPlusIncr
	inc	r2
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x0003)
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:169: lastTime.tm_isdst=0;
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_lastTime + 0x000a)
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:171: return &lastTime;
;	genRet
;	Peephole 182.a	used 16 bit load of DPTR
	mov	dptr,#_lastTime
	mov	b,#0x00
;	Peephole 300	removed redundant label 00117$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mktime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_mktime_sloc0_1_0'
;sloc1                     Allocated with name '_mktime_sloc1_1_0'
;sloc2                     Allocated with name '_mktime_sloc2_1_0'
;sloc3                     Allocated with name '_mktime_sloc3_1_0'
;timeptr                   Allocated with name '_mktime_timeptr_1_1'
;year                      Allocated with name '_mktime_year_1_1'
;month                     Allocated with name '_mktime_month_1_1'
;i                         Allocated with name '_mktime_i_1_1'
;seconds                   Allocated with name '_mktime_seconds_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:175: time_t mktime(struct tm *timeptr) {
;	-----------------------------------------
;	 function mktime
;	-----------------------------------------
_mktime:
;	genReceive
	mov	r2,b
	mov	r3,dph
	mov	a,dpl
	mov	dptr,#_mktime_timeptr_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:176: int year=timeptr->tm_year+1900, month=timeptr->tm_mon, i;
;	genAssign
	mov	dptr,#_mktime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x05
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
	inc	dptr
	lcall	__gptrget
	mov	r6,a
;	genPlus
;     genPlusIncr
	mov	a,#0x6C
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r5,a
	mov	a,#0x07
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	mov	r6,a
;	genPlus
;     genPlusIncr
	mov	a,#0x04
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r7,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r0,a
	mov	ar1,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r7
	mov	dph,r0
	mov	b,r1
	lcall	__gptrget
	mov	r7,a
;	genCast
	mov	_mktime_sloc1_1_0,r7
	mov	(_mktime_sloc1_1_0 + 1),#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:179: CheckTime(timeptr);
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	push	ar5
	push	ar6
	lcall	_CheckTime
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:182: seconds= (year-1970)*(60*60*24L*365);
;	genMinus
	mov	a,r5
	add	a,#0x4e
	mov	r2,a
	mov	a,r6
	addc	a,#0xf8
;	genCast
	mov	r3,a
;	Peephole 105	removed redundant mov
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r1,a
;	genAssign
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x33
	movx	@dptr,a
	inc	dptr
	mov	a,#0xE1
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r1
	push	ar5
	push	ar6
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r1,a
	pop	ar6
	pop	ar5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:185: for (i=1970; i<year; i++) {
;	genAssign
;	genAssign
	mov	r7,#0xB2
	mov	r0,#0x07
00107$:
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r7
	subb	a,r5
	mov	a,r0
	xrl	a,#0x80
	mov	b,r6
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00124$
;	Peephole 300	removed redundant label 00126$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:186: if (LEAP_YEAR(i)) {
;	genAssign
	mov	dptr,#__modsint_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r7
	mov	dph,r0
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
	lcall	__modsint
	mov	a,dpl
	mov	b,dph
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	orl	a,b
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00109$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:187: seconds+= 60*60*24L;
;	genPlus
;     genPlusIncr
	mov	a,#0x80
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
	mov	a,#0x51
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
	mov	a,#0x01
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	mov	r4,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r1 instead of ar1
	addc	a,r1
	mov	r1,a
00109$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:185: for (i=1970; i<year; i++) {
;	genPlus
;     genPlusIncr
;	tail increment optimized (range 9)
	inc	r7
	cjne	r7,#0x00,00107$
	inc	r0
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00107$
00124$:
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:192: for (i=0; i<month; i++) {
;	genAssign
	mov	dptr,#__modsint_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall
	mov	dpl,r5
	mov	dph,r6
	lcall	__modsint
	mov	r2,dpl
	mov	r3,dph
;	genAssign
	mov	r4,#0x00
	mov	r5,#0x00
00111$:
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r4
	subb	a,_mktime_sloc1_1_0
	mov	a,r5
	xrl	a,#0x80
	mov	b,(_mktime_sloc1_1_0 + 1)
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00128$
	ljmp	00114$
00128$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:193: if (i==1 && LEAP_YEAR(year)) { 
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.a	optimized misc jump sequence
	cjne	r4,#0x01,00104$
	cjne	r5,#0x00,00104$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00129$
;	Peephole 300	removed redundant label 00130$
;	genIfx
	mov	a,r2
	orl	a,r3
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00104$
;	Peephole 300	removed redundant label 00131$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:194: seconds+= 60*60*24L*29;
;	genIpush
	push	ar2
	push	ar3
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
;     genPlusIncr
	mov	a,#0x80
;	Peephole 236.a	used r6 instead of ar6
	add	a,r6
	movx	@dptr,a
	mov	a,#0x3B
;	Peephole 236.b	used r1 instead of ar1
	addc	a,r1
	inc	dptr
	movx	@dptr,a
	mov	a,#0x26
;	Peephole 236.b	used r2 instead of ar2
	addc	a,r2
	inc	dptr
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
;	genIpop
	pop	ar3
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00113$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:196: seconds+= 60*60*24L*monthDays[i];
;	genIpush
	push	ar2
	push	ar3
;	genPlus
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	add	a,#_monthDays
	mov	dpl,a
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	addc	a,#(_monthDays >> 8)
	mov	dph,a
;	genPointerGet
;	genCodePointerGet
	clr	a
	movc	a,@a+dptr
;	genCast
	mov	r6,a
;	Peephole 105	removed redundant mov
	rlc	a
	subb	a,acc
	mov	r1,a
	mov	r2,a
	mov	r3,a
;	genAssign
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x51
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
	inc	dptr
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	genCall
	mov	dpl,r6
	mov	dph,r1
	mov	b,r2
	mov	a,r3
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	__mullong
	mov	_mktime_sloc2_1_0,dpl
	mov	(_mktime_sloc2_1_0 + 1),dph
	mov	(_mktime_sloc2_1_0 + 2),b
	mov	(_mktime_sloc2_1_0 + 3),a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
	mov	a,_mktime_sloc2_1_0
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 1)
;	Peephole 236.b	used r0 instead of ar0
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 2)
;	Peephole 236.b	used r2 instead of ar2
	addc	a,r2
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 3)
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:204: return seconds;
;	genIpop
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:196: seconds+= 60*60*24L*monthDays[i];
00113$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:192: for (i=0; i<month; i++) {
;	genPlus
;     genPlusIncr
	inc	r4
	cjne	r4,#0x00,00132$
	inc	r5
00132$:
	ljmp	00111$
00114$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:200: seconds+= (timeptr->tm_mday-1)*60*60*24L;
;	genAssign
	mov	dptr,#_mktime_timeptr_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPlus
;     genPlusIncr
	mov	a,#0x03
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
;	genCast
	mov	r6,#0x00
;	genMinus
;	genMinusDec
	dec	r5
	cjne	r5,#0xff,00133$
	dec	r6
00133$:
;	genCast
	mov	a,r6
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	r0,a
;	genAssign
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x51
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
	inc	dptr
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	genCall
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r0
	push	ar2
	push	ar3
	push	ar4
	lcall	__mullong
	mov	_mktime_sloc2_1_0,dpl
	mov	(_mktime_sloc2_1_0 + 1),dph
	mov	(_mktime_sloc2_1_0 + 2),b
	mov	(_mktime_sloc2_1_0 + 3),a
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
	mov	a,_mktime_sloc2_1_0
;	Peephole 236.a	used r1 instead of ar1
	add	a,r1
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 1)
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 2)
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 3)
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:201: seconds+= timeptr->tm_hour*60*60L;
;	genPlus
;     genPlusIncr
	mov	a,#0x02
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
	mov	r5,a
;	genCast
	mov	r6,#0x00
	mov	r7,#0x00
	mov	r0,#0x00
;	genAssign
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x10
	movx	@dptr,a
	inc	dptr
	mov	a,#0x0E
	movx	@dptr,a
	inc	dptr
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
;	Peephole 101	removed redundant mov
	movx	@dptr,a
;	genCall
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	mov	a,r0
	push	ar2
	push	ar3
	push	ar4
	lcall	__mullong
	mov	_mktime_sloc2_1_0,dpl
	mov	(_mktime_sloc2_1_0 + 1),dph
	mov	(_mktime_sloc2_1_0 + 2),b
	mov	(_mktime_sloc2_1_0 + 3),a
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
	mov	a,_mktime_sloc2_1_0
;	Peephole 236.a	used r1 instead of ar1
	add	a,r1
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 1)
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 2)
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,(_mktime_sloc2_1_0 + 3)
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:202: seconds+= timeptr->tm_min*60;
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r5,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r6,a
	mov	ar7,r4
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r5
	mov	dph,r6
	mov	b,r7
	lcall	__gptrget
;	genMult
;	genMultOneByte
	mov	r5,a
;	Peephole 105	removed redundant mov
	mov	b,#0x3C
	mul	ab
	mov	r6,a
	mov	r5,b
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	_mktime_sloc3_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(_mktime_sloc3_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(_mktime_sloc3_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(_mktime_sloc3_1_0 + 3),a
;	genCast
	mov	a,r5
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	r0,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,_mktime_sloc3_1_0
	movx	@dptr,a
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	addc	a,(_mktime_sloc3_1_0 + 1)
	inc	dptr
	movx	@dptr,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	addc	a,(_mktime_sloc3_1_0 + 2)
	inc	dptr
	movx	@dptr,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
	addc	a,(_mktime_sloc3_1_0 + 3)
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:203: seconds+= timeptr->tm_sec;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r2,a
;	genCast
	mov	r3,#0x00
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genPlus
	mov	dptr,#_mktime_seconds_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	movx	@dptr,a
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	inc	dptr
	movx	@dptr,a
;	Peephole 236.g	used r0 instead of ar0
	mov	a,r0
;	Peephole 236.b	used r6 instead of ar6
	addc	a,r6
	inc	dptr
	movx	@dptr,a
;	Peephole 236.g	used r1 instead of ar1
	mov	a,r1
;	Peephole 236.b	used r7 instead of ar7
	addc	a,r7
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/time.c:204: return seconds;
;	genAssign
	mov	dptr,#_mktime_seconds_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genRet
	mov	r5,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 191	removed redundant mov
;	Peephole 300	removed redundant label 00115$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
_monthDays:
	.db #0x1F
	.db #0x1C
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
___month:
	.byte _str_1,(_str_1 >> 8)
	.byte _str_2,(_str_2 >> 8)
	.byte _str_3,(_str_3 >> 8)
	.byte _str_4,(_str_4 >> 8)
	.byte _str_5,(_str_5 >> 8)
	.byte _str_6,(_str_6 >> 8)
	.byte _str_7,(_str_7 >> 8)
	.byte _str_8,(_str_8 >> 8)
	.byte _str_9,(_str_9 >> 8)
	.byte _str_10,(_str_10 >> 8)
	.byte _str_11,(_str_11 >> 8)
	.byte _str_12,(_str_12 >> 8)
___day:
	.byte _str_13,(_str_13 >> 8)
	.byte _str_14,(_str_14 >> 8)
	.byte _str_15,(_str_15 >> 8)
	.byte _str_16,(_str_16 >> 8)
	.byte _str_17,(_str_17 >> 8)
	.byte _str_18,(_str_18 >> 8)
	.byte _str_19,(_str_19 >> 8)
__str_0:
	.ascii "%s %s %2d %02d:%02d:%02d %04d"
	.db 0x0A
	.db 0x00
_str_1:
	.ascii "Jan"
	.db 0x00
_str_2:
	.ascii "Feb"
	.db 0x00
_str_3:
	.ascii "Mar"
	.db 0x00
_str_4:
	.ascii "Apr"
	.db 0x00
_str_5:
	.ascii "May"
	.db 0x00
_str_6:
	.ascii "Jun"
	.db 0x00
_str_7:
	.ascii "Jul"
	.db 0x00
_str_8:
	.ascii "Aug"
	.db 0x00
_str_9:
	.ascii "Sep"
	.db 0x00
_str_10:
	.ascii "Oct"
	.db 0x00
_str_11:
	.ascii "Nov"
	.db 0x00
_str_12:
	.ascii "Dec"
	.db 0x00
_str_13:
	.ascii "Sun"
	.db 0x00
_str_14:
	.ascii "Mon"
	.db 0x00
_str_15:
	.ascii "Tue"
	.db 0x00
_str_16:
	.ascii "Wed"
	.db 0x00
_str_17:
	.ascii "Thu"
	.db 0x00
_str_18:
	.ascii "Fri"
	.db 0x00
_str_19:
	.ascii "Sat"
	.db 0x00
	.area XINIT   (CODE)
