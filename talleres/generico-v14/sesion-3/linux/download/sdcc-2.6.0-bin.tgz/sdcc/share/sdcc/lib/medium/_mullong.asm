;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:09 2006
;--------------------------------------------------------
	.module _mullong
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __mullong_PARM_2
	.globl __mullong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__mullong_PARM_2:
	.ds 4
__mullong_a_1_1:
	.ds 4
__mullong_t_1_1:
	.ds 4
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_mullong'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:709: _mullong (long a, long b)
;	-----------------------------------------
;	 function _mullong
;	-----------------------------------------
__mullong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	r0,#__mullong_a_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
	mov	a,r3
	movx	@r0,a
	inc	r0
	mov	a,r4
	movx	@r0,a
	inc	r0
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:713: t.i.hi = bcast(a)->b.b0 * bcast(b)->b.b2;           // A
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#__mullong_a_1_1
	movx	a,@r0
	mov	r2,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0002)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r3,a
	mov	b,r2
;	Peephole 177.d	removed redundant move
	mul	ab
	mov	r3,a
	mov	r4,b
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#(__mullong_t_1_1 + 0x0002)
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:714: t.i.lo = bcast(a)->b.b0 * bcast(b)->b.b0;           // A
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#__mullong_PARM_2
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r3,a
	mov	b,r2
;	Peephole 177.d	removed redundant move
	mul	ab
	mov	r4,a
	mov	r5,b
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#__mullong_t_1_1
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:715: t.b.b3 += bcast(a)->b.b3 * bcast(b)->b.b0;          // G
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_t_1_1 + 0x0003)
	movx	a,@r0
	mov	r4,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0003)
	movx	a,@r0
	mov	r5,a
;	genMult
;	genMultOneByte
	mov	b,r5
	mov	a,r3
	mul	ab
;	genPlus
	mov	r5,a
;	Peephole 177.b	removed redundant mov
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
;	genPointerSet
;	genPagedPointerSet
;	Peephole 236.g	used r4 instead of ar4
	mov	r4,a
	mov	r0,#(__mullong_t_1_1 + 0x0003)
;	Peephole 177.d	removed redundant move
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:716: t.b.b3 += bcast(a)->b.b2 * bcast(b)->b.b1;          // F
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_t_1_1 + 0x0003)
	movx	a,@r0
	mov	r4,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0002)
	movx	a,@r0
	mov	r5,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0001)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r6,a
	mov	b,r5
;	Peephole 177.d	removed redundant move
	mul	ab
;	genPlus
	mov	r5,a
;	Peephole 177.b	removed redundant mov
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
;	genPointerSet
;	genPagedPointerSet
;	Peephole 236.g	used r4 instead of ar4
	mov	r4,a
	mov	r0,#(__mullong_t_1_1 + 0x0003)
;	Peephole 177.d	removed redundant move
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:717: t.i.hi += bcast(a)->b.b2 * bcast(b)->b.b0;          // E <- b lost in .lst
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_t_1_1 + 0x0002)
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0002)
	movx	a,@r0
	mov	r6,a
;	genMult
;	genMultOneByte
	mov	b,r6
	mov	a,r3
	mul	ab
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	r6,a
	mov	r7,b
;	Peephole 177.d	removed redundant move
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r4,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r5,a
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#(__mullong_t_1_1 + 0x0002)
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:719: t.i.hi += bcast(a)->b.b1 * bcast(b)->b.b1;          // D <- b lost in .lst
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_t_1_1 + 0x0002)
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0001)
	movx	a,@r0
	mov	r6,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0001)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r7,a
	mov	b,r6
;	Peephole 177.d	removed redundant move
	mul	ab
;	genPlus
;	Peephole 236.g	used r7 instead of ar7
	mov	r7,a
	mov	r6,b
;	Peephole 177.d	removed redundant move
;	Peephole 236.a	used r4 instead of ar4
	add	a,r4
	mov	r4,a
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r5,a
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#(__mullong_t_1_1 + 0x0002)
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:721: bcast(a)->bi.b3 = bcast(a)->b.b1 * bcast(b)->b.b2;  // C
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0001)
	movx	a,@r0
	mov	r4,a
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0002)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r5,a
	mov	b,r4
;	Peephole 177.d	removed redundant move
	mul	ab
;	genPointerSet
;	genPagedPointerSet
;	Peephole 236.g	used r4 instead of ar4
	mov	r4,a
	mov	r0,#(__mullong_a_1_1 + 0x0003)
;	Peephole 177.d	removed redundant move
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:722: bcast(a)->bi.i12 = bcast(a)->b.b1 * bcast(b)->b.b0; // C
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_a_1_1 + 0x0001)
	movx	a,@r0
	mov	r4,a
;	genMult
;	genMultOneByte
	mov	b,r4
	mov	a,r3
	mul	ab
	mov	r3,a
	mov	r5,b
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#(__mullong_a_1_1 + 0x0001)
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:724: bcast(b)->bi.b3 = bcast(a)->b.b0 * bcast(b)->b.b3;  // B
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0003)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r3,a
	mov	b,r2
;	Peephole 177.d	removed redundant move
	mul	ab
;	genPointerSet
;	genPagedPointerSet
;	Peephole 236.g	used r3 instead of ar3
	mov	r3,a
	mov	r0,#(__mullong_PARM_2 + 0x0003)
;	Peephole 177.d	removed redundant move
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:725: bcast(b)->bi.i12 = bcast(a)->b.b0 * bcast(b)->b.b1; // B
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#(__mullong_PARM_2 + 0x0001)
	movx	a,@r0
;	genMult
;	genMultOneByte
	mov	r3,a
	mov	b,r2
;	Peephole 177.d	removed redundant move
	mul	ab
	mov	r2,a
	mov	r4,b
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#(__mullong_PARM_2 + 0x0001)
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:727: bcast(b)->bi.b0 = 0;                                // B
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#__mullong_PARM_2
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:728: bcast(a)->bi.b0 = 0;                                // C
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#__mullong_a_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:729: t.l += a;
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#__mullong_t_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genPlus
	mov	r0,#__mullong_a_1_1
	movx	a,@r0
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	mov	r4,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
	mov	r5,a
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#__mullong_t_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_mullong.c:731: return t.l + b;
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#__mullong_t_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genPlus
	mov	r0,#__mullong_PARM_2
	movx	a,@r0
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	mov	r3,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	mov	r4,a
	inc	r0
	movx	a,@r0
;	Peephole 236.b	used r5 instead of ar5
	addc	a,r5
;	genRet
	mov	r5,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 191	removed redundant mov
;	Peephole 300	removed redundant label 00101$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
