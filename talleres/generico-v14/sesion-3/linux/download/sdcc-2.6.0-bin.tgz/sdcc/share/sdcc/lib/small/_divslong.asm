;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:53 2006
;--------------------------------------------------------
	.module _divslong
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divslong_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:52: _divslong_dummy (void) _naked
;	-----------------------------------------
;	 function _divslong_dummy
;	-----------------------------------------
__divslong_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:135: mov	x0,a
;	genInline
	                .globl __divslong
;	# 76 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c"
        __divslong:
	                                        ; r3 in acc
	                                        ; (__divslong_PARM_2 + 3) in (__divslong_PARM_2 + 3)
	                mov r3,a ; save r3
	                clr F0 ; Flag 0 in PSW
	                                        ; available to user for general purpose
	                jnb acc.7,a_not_negative
	                setb F0
	                clr a
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r3
	                mov r3,a
        a_not_negative:
	                mov a,(__divslong_PARM_2 + 3)
	                jnb acc.7,b_not_negative
	                cpl F0
	                clr a
	                clr c
	                subb a,(__divslong_PARM_2)
	                mov (__divslong_PARM_2),a
	                clr a
	                subb a,(__divslong_PARM_2 + 1)
	                mov (__divslong_PARM_2 + 1),a
	                clr a
	                subb a,(__divslong_PARM_2 + 2)
	                mov (__divslong_PARM_2 + 2),a
	                clr a
	                subb a,(__divslong_PARM_2 + 3)
	                mov (__divslong_PARM_2 + 3),a
        b_not_negative:
	                mov a,r3 ; restore r3 in acc
	                lcall __divulong
	                jnb F0,not_negative
	                mov r3,a ; save r3
	                clr a
	                clr c
	                subb a,dpl
	                mov dpl,a
	                clr a
	                subb a,dph
	                mov dph,a
	                clr a
	                subb a,b
	                mov b,a
	                clr a
	                subb a,r3 ; r3 ends in acc
        not_negative:
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
