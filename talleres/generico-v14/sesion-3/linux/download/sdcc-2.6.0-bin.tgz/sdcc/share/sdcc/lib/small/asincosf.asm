;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:02 2006
;--------------------------------------------------------
	.module asincosf
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _asincosf
	.globl _asincosf_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_asincosf_PARM_2:
	.ds 2
_asincosf_x_1_1:
	.ds 4
_asincosf_y_1_1:
	.ds 4
_asincosf_i_1_1:
	.ds 2
_asincosf_sloc0_1_0:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'asincosf'
;------------------------------------------------------------
;isacos                    Allocated with name '_asincosf_PARM_2'
;x                         Allocated with name '_asincosf_x_1_1'
;y                         Allocated with name '_asincosf_y_1_1'
;g                         Allocated to registers r2 r3 r4 r5 
;r                         Allocated to registers r4 r5 r2 r3 
;i                         Allocated with name '_asincosf_i_1_1'
;sloc0                     Allocated with name '_asincosf_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:42: float asincosf(const float x, const int isacos)
;	-----------------------------------------
;	 function asincosf
;	-----------------------------------------
_asincosf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:50: y=fabsf(x);
;	genCall
	mov	_asincosf_x_1_1,dpl
	mov	(_asincosf_x_1_1 + 1),dph
	mov	(_asincosf_x_1_1 + 2),b
	mov	(_asincosf_x_1_1 + 3),a
;	Peephole 238.b	removed 3 redundant moves
;	Peephole 191	removed redundant mov
	lcall	_fabsf
	mov	_asincosf_y_1_1,dpl
	mov	(_asincosf_y_1_1 + 1),dph
	mov	(_asincosf_y_1_1 + 2),b
	mov	(_asincosf_y_1_1 + 3),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:51: i=isacos;
;	genAssign
	mov	_asincosf_i_1_1,_asincosf_PARM_2
	mov	(_asincosf_i_1_1 + 1),(_asincosf_PARM_2 + 1)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:52: if (y < EPS) r=y;
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x39
	push	acc
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fslt
	mov	r4,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r4
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00107$
;	Peephole 300	removed redundant label 00125$
;	genAssign
	mov	r4,_asincosf_y_1_1
	mov	r5,(_asincosf_y_1_1 + 1)
	mov	r2,(_asincosf_y_1_1 + 2)
	mov	r3,(_asincosf_y_1_1 + 3)
	ljmp	00108$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:55: if (y > 0.5)
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsgt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r6
;	genIfxJump
	jnz	00126$
	ljmp	00104$
00126$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:57: i=1-i;
;	genMinus
	mov	a,#0x01
	clr	c
	subb	a,_asincosf_i_1_1
	mov	_asincosf_i_1_1,a
;	Peephole 181	changed mov to clr
	clr	a
	subb	a,(_asincosf_i_1_1 + 1)
	mov	(_asincosf_i_1_1 + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:58: if (y > 1.0)
;	genIpush
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	mov	a,#0x80
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsgt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00127$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:60: errno=EDOM;
;	genAssign
	mov	_errno,#0x21
	clr	a
	mov	(_errno + 1),a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:61: return 0.0;
;	genRet
;	Peephole 3.a	changed mov to clr
;	Peephole 3.b	changed mov to clr
;	Peephole 182.d	used 16 bit load of dptr
	mov	dptr,#(0x00&0x00ff)
	clr	a
	mov	b,a
;	Peephole 251.a	replaced ljmp to ret with ret
	ret
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:63: g=(0.5-y)+0.5;
;	genIpush
	push	_asincosf_y_1_1
	push	(_asincosf_y_1_1 + 1)
	push	(_asincosf_y_1_1 + 2)
	push	(_asincosf_y_1_1 + 3)
;	genCall
;	Peephole 182.b	used 16 bit load of dptr
	mov	dptr,#0x0000
	mov	b,#0x80
	mov	a,#0x3F
	lcall	___fssub
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:64: g=ldexpf(g,-1);
;	genAssign
	mov	_ldexpf_PARM_2,#0xFF
	mov	(_ldexpf_PARM_2 + 1),#0xFF
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	_ldexpf
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:65: y=sqrtf(g);
;	genCall
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	Peephole 238.b	removed 3 redundant moves
;	Peephole 191	removed redundant mov
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	lcall	_sqrtf
	mov	_asincosf_y_1_1,dpl
	mov	(_asincosf_y_1_1 + 1),dph
	mov	(_asincosf_y_1_1 + 2),b
	mov	(_asincosf_y_1_1 + 3),a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:66: y=-(y+y);
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	_asincosf_y_1_1
	push	(_asincosf_y_1_1 + 1)
	push	(_asincosf_y_1_1 + 2)
	push	(_asincosf_y_1_1 + 3)
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genUminus
;	genUminusFloat
	mov	_asincosf_y_1_1,r6
	mov	(_asincosf_y_1_1 + 1),r7
	mov	(_asincosf_y_1_1 + 2),r0
	mov	a,r1
	cpl	acc.7
	mov	(_asincosf_y_1_1 + 3),a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00105$
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:70: g=y*y;
;	genIpush
	push	_asincosf_y_1_1
	push	(_asincosf_y_1_1 + 1)
	push	(_asincosf_y_1_1 + 2)
	push	(_asincosf_y_1_1 + 3)
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00105$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:72: r=y+y*((P(g)*g)/Q(g));
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	mov	a,#0x65
	push	acc
	mov	a,#0x20
	push	acc
	mov	a,#0x01
	push	acc
	mov	a,#0xBF
	push	acc
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	mov	a,#0x6B
	push	acc
	mov	a,#0x16
	push	acc
	mov	a,#0x6F
	push	acc
	mov	a,#0x3F
	push	acc
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsmul
	mov	_asincosf_sloc0_1_0,dpl
	mov	(_asincosf_sloc0_1_0 + 1),dph
	mov	(_asincosf_sloc0_1_0 + 2),b
	mov	(_asincosf_sloc0_1_0 + 3),a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	mov	a,#0x0B
	push	acc
	mov	a,#0x8D
	push	acc
	mov	a,#0xB1
	push	acc
	mov	a,#0xC0
	push	acc
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	mov	a,#0xF0
	push	acc
	mov	a,#0x50
	push	acc
	mov	a,#0xB3
	push	acc
	mov	a,#0x40
	push	acc
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genCall
	mov	dpl,_asincosf_sloc0_1_0
	mov	dph,(_asincosf_sloc0_1_0 + 1)
	mov	b,(_asincosf_sloc0_1_0 + 2)
	mov	a,(_asincosf_sloc0_1_0 + 3)
	lcall	___fsdiv
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genCall
	mov	dpl,_asincosf_y_1_1
	mov	dph,(_asincosf_y_1_1 + 1)
	mov	b,(_asincosf_y_1_1 + 2)
	mov	a,(_asincosf_y_1_1 + 3)
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:74: if (isacos)
;	genIfx
	mov	a,_asincosf_PARM_2
	orl	a,(_asincosf_PARM_2 + 1)
;	genIfxJump
	jnz	00128$
	ljmp	00115$
00128$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:76: if (x < 0.0)
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_asincosf_x_1_1
	mov	dph,(_asincosf_x_1_1 + 1)
	mov	b,(_asincosf_x_1_1 + 2)
	mov	a,(_asincosf_x_1_1 + 3)
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00110$
;	Peephole 300	removed redundant label 00129$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:77: r=(b[i]+r)+b[i];
;	genLeftShift
;	genLeftShiftLiteral
;	genlshTwo
	mov	r6,_asincosf_i_1_1
	mov	a,(_asincosf_i_1_1 + 1)
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,#_asincosf_b_1_1
	mov	dpl,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	addc	a,#(_asincosf_b_1_1 >> 8)
	mov	dph,a
;	genPointerGet
;	genCodePointerGet
	clr	a
	movc	a,@a+dptr
	mov	_asincosf_sloc0_1_0,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 1),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 2),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 3),a
;	genIpush
	push	ar4
	push	ar5
	push	ar2
	push	ar3
;	genCall
	mov	dpl,_asincosf_sloc0_1_0
	mov	dph,(_asincosf_sloc0_1_0 + 1)
	mov	b,(_asincosf_sloc0_1_0 + 2)
	mov	a,(_asincosf_sloc0_1_0 + 3)
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_asincosf_sloc0_1_0
	push	(_asincosf_sloc0_1_0 + 1)
	push	(_asincosf_sloc0_1_0 + 2)
	push	(_asincosf_sloc0_1_0 + 3)
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	ljmp	00116$
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:79: r=(a[i]-r)+a[i];
;	genLeftShift
;	genLeftShiftLiteral
;	genlshTwo
	mov	r6,_asincosf_i_1_1
	mov	a,(_asincosf_i_1_1 + 1)
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,#_asincosf_a_1_1
	mov	dpl,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
;	genPointerGet
;	genCodePointerGet
	clr	a
	movc	a,@a+dptr
	mov	_asincosf_sloc0_1_0,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 1),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 2),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 3),a
;	genIpush
	push	ar4
	push	ar5
	push	ar2
	push	ar3
;	genCall
	mov	dpl,_asincosf_sloc0_1_0
	mov	dph,(_asincosf_sloc0_1_0 + 1)
	mov	b,(_asincosf_sloc0_1_0 + 2)
	mov	a,(_asincosf_sloc0_1_0 + 3)
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_asincosf_sloc0_1_0
	push	(_asincosf_sloc0_1_0 + 1)
	push	(_asincosf_sloc0_1_0 + 2)
	push	(_asincosf_sloc0_1_0 + 3)
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	ljmp	00116$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:83: r=(a[i]+r)+a[i];
;	genLeftShift
;	genLeftShiftLiteral
;	genlshTwo
	mov	r6,_asincosf_i_1_1
	mov	a,(_asincosf_i_1_1 + 1)
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus
;	Peephole 236.g	used r6 instead of ar6
	mov	a,r6
	add	a,#_asincosf_a_1_1
	mov	dpl,a
;	Peephole 236.g	used r7 instead of ar7
	mov	a,r7
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
;	genPointerGet
;	genCodePointerGet
	clr	a
	movc	a,@a+dptr
	mov	_asincosf_sloc0_1_0,a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 1),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 2),a
	inc	dptr
	clr	a
	movc	a,@a+dptr
	mov	(_asincosf_sloc0_1_0 + 3),a
;	genIpush
	push	ar4
	push	ar5
	push	ar2
	push	ar3
;	genCall
	mov	dpl,_asincosf_sloc0_1_0
	mov	dph,(_asincosf_sloc0_1_0 + 1)
	mov	b,(_asincosf_sloc0_1_0 + 2)
	mov	a,(_asincosf_sloc0_1_0 + 3)
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,b
	mov	r1,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	genIpush
	push	_asincosf_sloc0_1_0
	push	(_asincosf_sloc0_1_0 + 1)
	push	(_asincosf_sloc0_1_0 + 2)
	push	(_asincosf_sloc0_1_0 + 3)
;	genCall
	mov	dpl,r6
	mov	dph,r7
	mov	b,r0
	mov	a,r1
	lcall	___fsadd
	mov	r4,dpl
	mov	r5,dph
	mov	r2,b
	mov	r3,a
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:84: if (x<0.0) r=-r;
;	genIpush
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	Peephole 181	changed mov to clr
	clr	a
	push	acc
	push	acc
	push	acc
	push	acc
;	genCall
	mov	dpl,_asincosf_x_1_1
	mov	dph,(_asincosf_x_1_1 + 1)
	mov	b,(_asincosf_x_1_1 + 2)
	mov	a,(_asincosf_x_1_1 + 3)
	lcall	___fslt
	mov	r6,dpl
	mov	a,sp
	add	a,#0xfc
	mov	sp,a
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00116$
;	Peephole 300	removed redundant label 00130$
;	genUminus
;	genUminusFloat
	mov	a,r3
	cpl	acc.7
	mov	r3,a
00116$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/asincosf.c:86: return r;
;	genRet
	mov	dpl,r4
	mov	dph,r5
	mov	b,r2
	mov	a,r3
;	Peephole 300	removed redundant label 00117$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
_asincosf_a_1_1:
	.byte #0x00,#0x00,#0x00,#0x00
	.byte #0xDB,#0x0F,#0x49,#0x3F
_asincosf_b_1_1:
	.byte #0xDB,#0x0F,#0xC9,#0x3F
	.byte #0xDB,#0x0F,#0x49,#0x3F
	.area XINIT   (CODE)
