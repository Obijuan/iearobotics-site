;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:05 2006
;--------------------------------------------------------
	.module _divslong
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divslong_PARM_2
	.globl __divslong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__divslong_sloc0_1_0:
	.ds 4
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__divslong_PARM_2:
	.ds 4
__divslong_r_1_1:
	.ds 4
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divslong'
;------------------------------------------------------------
;sloc0                     Allocated with name '__divslong_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:255: _divslong (long x, long y)
;	-----------------------------------------
;	 function _divslong
;	-----------------------------------------
__divslong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:259: r = _divulong((x < 0 ? -x : x),
;	genCmpLt
;	genCmp
	mov	r5,a
;	Peephole 105	removed redundant mov
	rlc	a
	clr	a
	rlc	a
;	genIfx
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00106$
;	Peephole 300	removed redundant label 00113$
;	genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	__divslong_sloc0_1_0,a
	clr	a
	subb	a,r3
	mov	(__divslong_sloc0_1_0 + 1),a
	clr	a
	subb	a,r4
	mov	(__divslong_sloc0_1_0 + 2),a
	clr	a
	subb	a,r5
	mov	(__divslong_sloc0_1_0 + 3),a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00107$
00106$:
;	genAssign
	mov	__divslong_sloc0_1_0,r2
	mov	(__divslong_sloc0_1_0 + 1),r3
	mov	(__divslong_sloc0_1_0 + 2),r4
	mov	(__divslong_sloc0_1_0 + 3),r5
00107$:
;	genAssign
	mov	r2,__divslong_sloc0_1_0
	mov	r3,(__divslong_sloc0_1_0 + 1)
	mov	r4,(__divslong_sloc0_1_0 + 2)
	mov	r5,(__divslong_sloc0_1_0 + 3)
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:260: (y < 0 ? -y : y));
;	genCmpLt
;	genCmp
;	Peephole 263.a	optimized loading const
	mov	r0,#(__divslong_PARM_2 + 3)
	movx	a,@r0
	rlc	a
	clr	a
	rlc	a
;	genIfx
	mov	r7,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00108$
;	Peephole 300	removed redundant label 00114$
;	genUminus
	mov	r0,#__divslong_PARM_2
	movx	a,@r0
	setb	c
	cpl	a
	addc	a,#0
	mov	__divslong_sloc0_1_0,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	mov	(__divslong_sloc0_1_0 + 1),a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	mov	(__divslong_sloc0_1_0 + 2),a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	mov	(__divslong_sloc0_1_0 + 3),a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00109$
00108$:
;	genAssign
	mov	r0,#__divslong_PARM_2
	movx	a,@r0
	mov	__divslong_sloc0_1_0,a
	inc	r0
	movx	a,@r0
	mov	(__divslong_sloc0_1_0 + 1),a
	inc	r0
	movx	a,@r0
	mov	(__divslong_sloc0_1_0 + 2),a
	inc	r0
	movx	a,@r0
	mov	(__divslong_sloc0_1_0 + 3),a
00109$:
;	genAssign
	mov	r0,#__divulong_PARM_2
	mov	a,__divslong_sloc0_1_0
	movx	@r0,a
	inc	r0
	mov	a,(__divslong_sloc0_1_0 + 1)
	movx	@r0,a
	inc	r0
	mov	a,(__divslong_sloc0_1_0 + 2)
	movx	@r0,a
	inc	r0
	mov	a,(__divslong_sloc0_1_0 + 3)
	movx	@r0,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	mov	a,r5
	push	ar6
	push	ar7
	lcall	__divulong
	mov	r0,#__divslong_r_1_1
	push	acc
	mov	a,dpl
	movx	@r0,a
	inc	r0
	mov	a,dph
	movx	@r0,a
	inc	r0
	mov	a,b
	movx	@r0,a
	pop	acc
	inc	r0
	movx	@r0,a
	pop	ar7
	pop	ar6
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:261: if ( (x < 0) ^ (y < 0))
;	genXor
	mov	a,r7
;	Peephole 236.n	used r6 instead of ar6
	xrl	a,r6
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00115$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:262: return -r;
;	genUminus
	mov	r0,#__divslong_r_1_1
	movx	a,@r0
	setb	c
	cpl	a
	addc	a,#0
	mov	r6,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	mov	r7,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
	mov	r2,a
	inc	r0
	movx	a,@r0
	cpl	a
	addc	a,#0
;	genRet
	mov	r3,a
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
;	Peephole 191	removed redundant mov
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 251.b	replaced sjmp to ret with ret
	ret
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_divslong.c:264: return r;
;	genRet
	mov	r0,#__divslong_r_1_1
	movx	a,@r0
	mov	dpl,a
	inc	r0
	movx	a,@r0
	mov	dph,a
	inc	r0
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
;	Peephole 300	removed redundant label 00104$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
