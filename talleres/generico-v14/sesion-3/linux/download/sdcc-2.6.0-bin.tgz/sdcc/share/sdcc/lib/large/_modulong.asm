;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:25 2006
;--------------------------------------------------------
	.module _modulong
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __modulong_PARM_2
	.globl __modulong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
__modulong_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__modulong_PARM_2:
	.ds 4
__modulong_a_1_1:
	.ds 4
__modulong_count_1_1:
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modulong'
;------------------------------------------------------------
;b                         Allocated with name '__modulong_PARM_2'
;a                         Allocated with name '__modulong_a_1_1'
;count                     Allocated with name '__modulong_count_1_1'
;sloc0                     Allocated with name '__modulong_sloc0_1_0'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:340: _modulong (unsigned long a, unsigned long b)
;	-----------------------------------------
;	 function _modulong
;	-----------------------------------------
__modulong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
	mov	dptr,#__modulong_a_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:342: unsigned char count = 0;
;	genAssign
	mov	dptr,#__modulong_count_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:344: while (!MSB_SET(b))
;	genAssign
	mov	dptr,#__modulong_a_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign
	mov	r6,#0x00
00103$:
;	genAssign
	mov	dptr,#__modulong_PARM_2
	movx	a,@dptr
	mov	__modulong_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 3),a
;	genGetHbit
	mov	a,(__modulong_sloc0_1_0 + 3)
	rl	a
	anl	a,#0x01
;	genIfx
	mov	r7,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.d	removed sjmp by inverse jump logic
	jnz	00117$
;	Peephole 300	removed redundant label 00120$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:346: b <<= 1;
;	genIpush
	push	ar6
;	genLeftShift
;	genLeftShiftLiteral
;	genlshFour
	mov	a,__modulong_sloc0_1_0
	add	a,acc
	mov	r7,a
	mov	a,(__modulong_sloc0_1_0 + 1)
	rlc	a
	mov	r0,a
	mov	a,(__modulong_sloc0_1_0 + 2)
	rlc	a
	mov	r1,a
	mov	a,(__modulong_sloc0_1_0 + 3)
	rlc	a
	mov	r6,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:347: if (b > a)
;	genAssign
	mov	dptr,#__modulong_PARM_2
	movx	a,@dptr
	mov	__modulong_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 3),a
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,__modulong_sloc0_1_0
	mov	a,r3
	subb	a,(__modulong_sloc0_1_0 + 1)
	mov	a,r4
	subb	a,(__modulong_sloc0_1_0 + 2)
	mov	a,r5
	subb	a,(__modulong_sloc0_1_0 + 3)
	clr	a
	rlc	a
;	genIpop
	pop	ar6
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00102$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:349: b >>=1;
;	genRightShift
;	genRightShiftLiteral
;	genrshFour
	mov	a,(__modulong_sloc0_1_0 + 3)
	clr	c
	rrc	a
	mov	(__modulong_sloc0_1_0 + 3),a
	mov	a,(__modulong_sloc0_1_0 + 2)
	rrc	a
	mov	(__modulong_sloc0_1_0 + 2),a
	mov	a,(__modulong_sloc0_1_0 + 1)
	rrc	a
	mov	(__modulong_sloc0_1_0 + 1),a
	mov	a,__modulong_sloc0_1_0
	rrc	a
	mov	__modulong_sloc0_1_0,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	mov	a,__modulong_sloc0_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(__modulong_sloc0_1_0 + 1)
	movx	@dptr,a
	inc	dptr
	mov	a,(__modulong_sloc0_1_0 + 2)
	movx	@dptr,a
	inc	dptr
	mov	a,(__modulong_sloc0_1_0 + 3)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:350: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00117$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:352: count++;
;	genPlus
;     genPlusIncr
	inc	r6
;	genAssign
	mov	dptr,#__modulong_count_1_1
	mov	a,r6
	movx	@dptr,a
	ljmp	00103$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:354: do
00117$:
;	genAssign
	mov	dptr,#__modulong_count_1_1
	movx	a,@dptr
	mov	r2,a
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:356: if (a >= b)
;	genAssign
	mov	dptr,#__modulong_a_1_1
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genAssign
	mov	dptr,#__modulong_PARM_2
	movx	a,@dptr
	mov	__modulong_sloc0_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 2),a
	inc	dptr
	movx	a,@dptr
	mov	(__modulong_sloc0_1_0 + 3),a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r3
	subb	a,__modulong_sloc0_1_0
	mov	a,r4
	subb	a,(__modulong_sloc0_1_0 + 1)
	mov	a,r5
	subb	a,(__modulong_sloc0_1_0 + 2)
	mov	a,r6
	subb	a,(__modulong_sloc0_1_0 + 3)
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00107$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:357: a -= b;
;	genMinus
	mov	dptr,#__modulong_a_1_1
	mov	a,r3
	clr	c
	subb	a,__modulong_sloc0_1_0
	movx	@dptr,a
	mov	a,r4
	subb	a,(__modulong_sloc0_1_0 + 1)
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	subb	a,(__modulong_sloc0_1_0 + 2)
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	subb	a,(__modulong_sloc0_1_0 + 3)
	inc	dptr
	movx	@dptr,a
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:358: b >>= 1;
;	genAssign
	mov	dptr,#__modulong_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
;	genRightShift
;	genRightShiftLiteral
;	genrshFour
	mov	r6,a
;	Peephole 105	removed redundant mov
	clr	c
	rrc	a
	mov	r6,a
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	mov	a,r3
	rrc	a
;	genAssign
	mov	r3,a
	mov	dptr,#__modulong_PARM_2
;	Peephole 100	removed redundant mov
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:360: while (count--);
;	genAssign
	mov	ar3,r2
;	genMinus
;	genMinusDec
	dec	r2
;	genIfx
	mov	a,r3
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00108$
;	Peephole 300	removed redundant label 00123$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:362: return a;
;	genAssign
	mov	dptr,#__modulong_a_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genRet
	mov	r5,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 191	removed redundant mov
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
