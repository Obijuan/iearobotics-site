;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:07:55 2006
;--------------------------------------------------------
	.module _modulong
	.optsdcc -mmcs51 --model-small
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modlong_dummy'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:47: _modlong_dummy (void) _naked
;	-----------------------------------------
;	 function _modlong_dummy
;	-----------------------------------------
__modlong_dummy:
;	naked function: no prologue.
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c:175: mov	b0,a
;	genInline
	                .globl __modulong
        __modulong:
;	# 69 "/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_modulong.c"
	                .area OSEG (OVR,DATA)
	                .globl __modulong_PARM_2
	                .globl __modslong_PARM_2
        __modulong_PARM_2:
        __modslong_PARM_2:
	                .ds 4
	                .area CSEG (CODE)
	                                        ; parameter a comes in a, b, dph, dpl
	                mov r1,a ; save parameter r1
	                mov a,(__modulong_PARM_2) ; b == 0? avoid endless loop
	                orl a,(__modulong_PARM_2 + 1)
	                orl a,(__modulong_PARM_2 + 2)
	                orl a,(__modulong_PARM_2 + 3)
	                jz div_by_0
	                mov r0,#0
	                clr c ; when loop1 jumps immediately to loop2
        loop1:
	inc r0
	                mov a,(__modulong_PARM_2 + 3) ; if (!MSB_SET(b))
	                jb acc.7,loop2
	                mov a,(__modulong_PARM_2) ; b <<= 1
	                add a,acc
	                mov (__modulong_PARM_2),a
	                mov a,(__modulong_PARM_2 + 1)
	                rlc a
	                mov (__modulong_PARM_2 + 1),a
	                mov a,(__modulong_PARM_2 + 2)
	                rlc a
	                mov (__modulong_PARM_2 + 2),a
	                mov a,(__modulong_PARM_2 + 3)
	                rlc a
	                mov (__modulong_PARM_2 + 3),a
	                mov a,dpl ; a - b
	                subb a,(__modulong_PARM_2) ; here carry is always clear
	                mov a,dph
	                subb a,(__modulong_PARM_2 + 1)
	                mov a,b
	                subb a,(__modulong_PARM_2 + 2)
	                mov a,r1
	                subb a,(__modulong_PARM_2 + 3)
	                jnc loop1
	                clr c
	                mov a,(__modulong_PARM_2 + 3) ; b >>= 1;
	                rrc a
	                mov (__modulong_PARM_2 + 3),a
	                mov a,(__modulong_PARM_2 + 2)
	                rrc a
	                mov (__modulong_PARM_2 + 2),a
	                mov a,(__modulong_PARM_2 + 1)
	                rrc a
	                mov (__modulong_PARM_2 + 1),a
	                mov a,(__modulong_PARM_2)
	                rrc a
	                mov (__modulong_PARM_2),a
        loop2:
; clr c never set
	                mov a,dpl ; a - b
	                subb a,(__modulong_PARM_2)
	                mov r4,a
	                mov a,dph
	                subb a,(__modulong_PARM_2 + 1)
	                mov r5,a
	                mov a,b
	                subb a,(__modulong_PARM_2 + 2)
	                mov r6,a
	                mov a,r1
	                subb a,(__modulong_PARM_2 + 3)
	                jc smaller ; a >= b?
	                mov r1,a ; -> yes; a = a - b;
	                mov b,r6
	                mov dph,r5
	                mov dpl,r4
        smaller:
; -> no
	                clr c
	                mov a,(__modulong_PARM_2 + 3) ; b >>= 1;
	                rrc a
	                mov (__modulong_PARM_2 + 3),a
	                mov a,(__modulong_PARM_2 + 2)
	                rrc a
	                mov (__modulong_PARM_2 + 2),a
	                mov a,(__modulong_PARM_2 + 1)
	                rrc a
	                mov (__modulong_PARM_2 + 1),a
	                mov a,(__modulong_PARM_2)
	                rrc a
	                mov (__modulong_PARM_2),a
	                djnz r0,loop2
	                mov a,r1 ; prepare the return value
        div_by_0:
	                ret
;	Peephole 300	removed redundant label 00101$
;	naked function: no epilogue.
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
