;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:28 2006
;--------------------------------------------------------
	.module printf_large
	.optsdcc -mmcs51 --model-large
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __print_format_PARM_4
	.globl __print_format_PARM_3
	.globl __print_format_PARM_2
	.globl __print_format
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
__print_format_sloc1_1_0:
	.ds 3
__print_format_sloc2_1_0:
	.ds 2
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area	OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_lower_case:
	.ds 1
__print_format_left_justify_1_1:
	.ds 1
__print_format_zero_padding_1_1:
	.ds 1
__print_format_prefix_sign_1_1:
	.ds 1
__print_format_prefix_space_1_1:
	.ds 1
__print_format_signed_argument_1_1:
	.ds 1
__print_format_char_argument_1_1:
	.ds 1
__print_format_long_argument_1_1:
	.ds 1
__print_format_float_argument_1_1:
	.ds 1
__print_format_lsd_1_1:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_output_char:
	.ds 2
_p:
	.ds 3
_value:
	.ds 5
_charsOutputted:
	.ds 2
__output_char_c_1_1:
	.ds 1
_output_digit_n_1_1:
	.ds 1
_output_2digits_b_1_1:
	.ds 1
_calculate_digit_radix_1_1:
	.ds 1
__print_format_PARM_2:
	.ds 3
__print_format_PARM_3:
	.ds 3
__print_format_PARM_4:
	.ds 1
__print_format_pfn_1_1:
	.ds 2
__print_format_radix_1_1:
	.ds 1
__print_format_width_1_1:
	.ds 1
__print_format_decimals_1_1:
	.ds 1
__print_format_length_1_1:
	.ds 1
__print_format_c_1_1:
	.ds 1
__print_format_store_4_22:
	.ds 6
__print_format_pstore_4_22:
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_output_char'
;------------------------------------------------------------
;c                         Allocated with name '__output_char_c_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:88: static void _output_char( unsigned char c )
;	-----------------------------------------
;	 function _output_char
;	-----------------------------------------
__output_char:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	a,dpl
	mov	dptr,#__output_char_c_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:90: output_char( c, p );
;	genAssign
	mov	dptr,#__output_char_c_1_1
	movx	a,@dptr
	mov	r2,a
;	genIpush
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall
	mov	a,#00103$
	push	acc
	mov	a,#(00103$ >> 8)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	mov	dpl,r2
	ret
00103$:
	dec	sp
	dec	sp
	dec	sp
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:91: charsOutputted++;
;	genAssign
	mov	dptr,#_charsOutputted
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPlus
	mov	dptr,#_charsOutputted
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
;	Peephole 300	removed redundant label 00101$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_digit'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;n                         Allocated with name '_output_digit_n_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:111: static void output_digit( unsigned char n )
;	-----------------------------------------
;	 function output_digit
;	-----------------------------------------
_output_digit:
;	genReceive
	mov	a,dpl
	mov	dptr,#_output_digit_n_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:113: register unsigned char c = n + (unsigned char)'0';
;	genAssign
	mov	dptr,#_output_digit_n_1_1
	movx	a,@dptr
	mov	r2,a
;	genPlus
;     genPlusIncr
	mov	a,#0x30
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:115: if (c > (unsigned char)'9')
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r2,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x39
	jnc	00104$
;	Peephole 300	removed redundant label 00109$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:117: c += (unsigned char)('A' - '0' - 10);
;	genPlus
;     genPlusIncr
	mov	a,#0x07
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	mov	r2,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:118: if (lower_case)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_lower_case,00104$
;	Peephole 300	removed redundant label 00110$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:119: c = tolower(c);
;	genOr
	orl	ar2,#0x20
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:121: _output_char( c );
;	genCall
	mov	dpl,r2
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	__output_char
;
;------------------------------------------------------------
;Allocation info for local variables in function 'output_2digits'
;------------------------------------------------------------
;b                         Allocated with name '_output_2digits_b_1_1'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:136: static void output_2digits( unsigned char b )
;	-----------------------------------------
;	 function output_2digits
;	-----------------------------------------
_output_2digits:
;	genReceive
	mov	a,dpl
	mov	dptr,#_output_2digits_b_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:138: output_digit( b>>4   );
;	genAssign
	mov	dptr,#_output_2digits_b_1_1
	movx	a,@dptr
;	genRightShift
;	genRightShiftLiteral
;	genrshOne
	mov	r2,a
;	Peephole 105	removed redundant mov
	swap	a
	anl	a,#0x0f
;	genCall
	mov	r3,a
;	Peephole 244.c	loading dpl from a instead of r3
	mov	dpl,a
	push	ar2
	lcall	_output_digit
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:139: output_digit( b&0x0F );
;	genAnd
	anl	ar2,#0x0F
;	genCall
	mov	dpl,r2
;	Peephole 253.b	replaced lcall/ret with ljmp
	ljmp	_output_digit
;
;------------------------------------------------------------
;Allocation info for local variables in function 'calculate_digit'
;------------------------------------------------------------
;radix                     Allocated with name '_calculate_digit_radix_1_1'
;ul                        Allocated to registers r2 r3 r4 r5 
;b4                        Allocated to registers r6 
;i                         Allocated to registers r0 
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:166: static void calculate_digit( unsigned char radix )
;	-----------------------------------------
;	 function calculate_digit
;	-----------------------------------------
_calculate_digit:
;	genReceive
	mov	a,dpl
	mov	dptr,#_calculate_digit_radix_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:168: register unsigned long ul = value.ul;
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:169: register unsigned char b4 = value.byte[4];
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:172: do
;	genAssign
	mov	dptr,#_calculate_digit_radix_1_1
	movx	a,@dptr
	mov	r7,a
;	genAssign
	mov	r0,#0x20
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:174: b4 = (b4 << 1);
;	genLeftShift
;	genLeftShiftLiteral
;	genlshOne
	mov	a,r6
;	Peephole 254	optimized left shift
	add	a,r6
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:175: b4 |= (ul >> 31) & 0x01;
;	genGetHbit
	mov	a,r5
	rl	a
	anl	a,#0x01
;	genOr
	mov	r1,a
;	Peephole 105	removed redundant mov
	orl	ar6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:176: ul <<= 1;
;	genLeftShift
;	genLeftShiftLiteral
;	genlshFour
	mov	a,r2
;	Peephole 254	optimized left shift
	add	a,r2
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:178: if (radix <= b4 )
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r6
	subb	a,r7
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00104$
;	Peephole 300	removed redundant label 00112$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:180: b4 -= radix;
;	genMinus
	mov	a,r6
	clr	c
;	Peephole 236.l	used r7 instead of ar7
	subb	a,r7
	mov	r6,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:181: ul |= 1;
;	genOr
	orl	ar2,#0x01
00104$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:183: } while (--i);
;	genDjnz
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 205	optimized misc jump sequence
	djnz	r0,00103$
;	Peephole 300	removed redundant label 00113$
;	Peephole 300	removed redundant label 00114$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:184: value.ul = ul;
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:185: value.byte[4] = b4;
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_value + 0x0004)
	mov	a,r6
	movx	@dptr,a
;	Peephole 300	removed redundant label 00106$
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_print_format'
;------------------------------------------------------------
;sloc0                     Allocated with name '__print_format_sloc0_1_0'
;sloc1                     Allocated with name '__print_format_sloc1_1_0'
;sloc2                     Allocated with name '__print_format_sloc2_1_0'
;pvoid                     Allocated with name '__print_format_PARM_2'
;format                    Allocated with name '__print_format_PARM_3'
;ap                        Allocated with name '__print_format_PARM_4'
;pfn                       Allocated with name '__print_format_pfn_1_1'
;radix                     Allocated with name '__print_format_radix_1_1'
;width                     Allocated with name '__print_format_width_1_1'
;decimals                  Allocated with name '__print_format_decimals_1_1'
;length                    Allocated with name '__print_format_length_1_1'
;c                         Allocated with name '__print_format_c_1_1'
;memtype                   Allocated with name '__print_format_memtype_5_18'
;store                     Allocated with name '__print_format_store_4_22'
;pstore                    Allocated with name '__print_format_pstore_4_22'
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:385: int _print_format (pfn_outputchar pfn, void* pvoid, const char *format, va_list ap)
;	-----------------------------------------
;	 function _print_format
;	-----------------------------------------
__print_format:
;	genReceive
	mov	r2,dph
	mov	a,dpl
	mov	dptr,#__print_format_pfn_1_1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:412: output_char = pfn;
;	genAssign
	mov	dptr,#__print_format_pfn_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genAssign
	mov	dptr,#_output_char
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:413: p = pvoid;
;	genAssign
	mov	dptr,#__print_format_PARM_2
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign
	mov	dptr,#_p
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:417: charsOutputted = 0;
;	genAssign
	mov	dptr,#_charsOutputted
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:425: while( c=*format++ )
00234$:
;	genAssign
	mov	dptr,#__print_format_PARM_3
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r5,a
;	genPlus
	mov	dptr,#__print_format_PARM_3
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r3 instead of ar3
	addc	a,r3
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genIfx
	mov	a,r5
;	genIfxJump
	jnz	00320$
	ljmp	00236$
00320$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:427: if ( c=='%' )
;	genCmpEq
;	gencjneshort
	cjne	r5,#0x25,00321$
	sjmp	00322$
00321$:
	ljmp	00232$
00322$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:429: left_justify    = 0;
;	genAssign
	clr	__print_format_left_justify_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:430: zero_padding    = 0;
;	genAssign
	clr	__print_format_zero_padding_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:431: prefix_sign     = 0;
;	genAssign
	clr	__print_format_prefix_sign_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:432: prefix_space    = 0;
;	genAssign
	clr	__print_format_prefix_space_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:433: signed_argument = 0;
;	genAssign
	clr	__print_format_signed_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:434: char_argument   = 0;
;	genAssign
	clr	__print_format_char_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:435: long_argument   = 0;
;	genAssign
	clr	__print_format_long_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:436: float_argument  = 0;
;	genAssign
	clr	__print_format_float_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:437: radix           = 0;
;	genAssign
	mov	dptr,#__print_format_radix_1_1
;	Peephole 181	changed mov to clr
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:438: width           = 0;
;	genAssign
;	Peephole 181	changed mov to clr
;	Peephole 219.a	removed redundant clear
	clr	a
	movx	@dptr,a
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:439: decimals        = -1;
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
	mov	a,#0xFF
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:441: get_conversion_spec:
;	genAssign
	mov	dptr,#__print_format_PARM_3
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
00101$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:443: c = *format++;
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	__gptrget
	mov	r6,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
;	genAssign
	mov	dptr,#__print_format_PARM_3
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genAssign
	mov	dptr,#__print_format_c_1_1
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:445: if (c=='%') {
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r6,#0x25,00103$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00323$
;	Peephole 300	removed redundant label 00324$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:446: OUTPUT_CHAR(c, p);
;	genCall
	mov	dpl,r6
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:447: continue;
	ljmp	00234$
00103$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:450: if (isdigit(c)) {
;	genAssign
	mov	ar7,r6
;	genCmpLt
;	genCmp
	cjne	r7,#0x30,00325$
00325$:
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00110$
;	Peephole 300	removed redundant label 00326$
;	genAssign
	mov	ar7,r6
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r7
	add	a,#0xff - 0x39
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00110$
;	Peephole 300	removed redundant label 00327$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:451: if (decimals==-1) {
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
	movx	a,@dptr
	mov	r7,a
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r7,#0xFF,00107$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00328$
;	Peephole 300	removed redundant label 00329$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:452: width = 10*width + (c - '0');
;	genIpush
	push	ar2
	push	ar3
	push	ar4
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genMult
;	genMultOneByte
	mov	r2,a
;	Peephole 105	removed redundant mov
	mov	b,#0x0A
	mul	ab
	mov	r2,a
;	genMinus
	mov	a,r6
	add	a,#0xd0
;	genPlus
	mov	dptr,#__print_format_width_1_1
;	Peephole 236.a	used r2 instead of ar2
	add	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:453: if (width == 0) {
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIpop
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00101$
;	Peephole 300	removed redundant label 00330$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:455: zero_padding = 1;
;	genAssign
	setb	__print_format_zero_padding_1_1
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00101$
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:458: decimals = 10*decimals + (c-'0');
;	genMult
;	genMultOneByte
	mov	a,r7
	mov	b,#0x0A
	mul	ab
	mov	r7,a
;	genMinus
	mov	a,r6
	add	a,#0xd0
;	genPlus
	mov	dptr,#__print_format_decimals_1_1
;	Peephole 236.a	used r7 instead of ar7
	add	a,r7
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:460: goto get_conversion_spec;
	ljmp	00101$
00110$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:463: if (c=='.') {
;	genAssign
	mov	dptr,#__print_format_c_1_1
	movx	a,@dptr
	mov	r6,a
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r6,#0x2E,00115$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00331$
;	Peephole 300	removed redundant label 00332$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:464: if (decimals=-1) decimals=0;
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:467: goto get_conversion_spec;
	ljmp	00101$
00115$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:470: lower_case = islower(c);
;	genCall
	mov	dpl,r6
	push	ar2
	push	ar3
	push	ar4
	push	ar6
	lcall	_islower
	mov	a,dpl
	add	a,#0xff
	mov	_lower_case,c
	pop	ar6
	pop	ar4
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:471: if (lower_case)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	_lower_case,00117$
;	Peephole 300	removed redundant label 00333$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:473: c = toupper(c);
;	genAnd
	mov	dptr,#__print_format_c_1_1
	mov	a,#0xDF
	anl	a,r6
	movx	@dptr,a
00117$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:476: switch( c )
;	genAssign
	mov	dptr,#__print_format_c_1_1
	movx	a,@dptr
	mov	r6,a
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x20,00334$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00120$
00334$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x2B,00335$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00119$
00335$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x2D,00336$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00118$
00336$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x42,00337$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00121$
00337$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x43,00338$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00123$
00338$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x44,00339$
	ljmp	00157$
00339$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x46,00340$
	ljmp	00161$
00340$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x49,00341$
	ljmp	00157$
00341$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x4C,00342$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00122$
00342$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x4F,00343$
	ljmp	00158$
00343$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x50,00344$
	ljmp	00143$
00344$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x53,00345$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00124$
00345$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x55,00346$
	ljmp	00159$
00346$:
;	genCmpEq
;	gencjneshort
	cjne	r6,#0x58,00347$
	ljmp	00160$
00347$:
	ljmp	00162$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:478: case '-':
00118$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:479: left_justify = 1;
;	genAssign
	setb	__print_format_left_justify_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:480: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:481: case '+':
00119$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:482: prefix_sign = 1;
;	genAssign
	setb	__print_format_prefix_sign_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:483: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:484: case ' ':
00120$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:485: prefix_space = 1;
;	genAssign
	setb	__print_format_prefix_space_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:486: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:487: case 'B':
00121$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:488: char_argument = 1;
;	genAssign
	setb	__print_format_char_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:489: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:490: case 'L':
00122$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:491: long_argument = 1;
;	genAssign
	setb	__print_format_long_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:492: goto get_conversion_spec;
	ljmp	00101$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:494: case 'C':
00123$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:495: OUTPUT_CHAR( va_arg(ap,int), p );
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	add	a,#0xfe
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	dec	r0
;	genCast
;	genCall
	mov	dpl,r2
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:496: break;
	ljmp	00163$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:498: case 'S':
00124$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:499: PTR = va_arg(ap,ptr_t);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	add	a,#0xfd
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	dec	r0
	dec	r0
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:509: length = strlen(PTR);
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genCall
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
	lcall	_strlen
	mov	r2,dpl
	mov	r3,dph
;	genCast
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:511: if ( decimals == -1 )
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
	movx	a,@dptr
	mov	r3,a
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 198.b	optimized misc jump sequence
	cjne	r3,#0xFF,00126$
;	Peephole 200.b	removed redundant sjmp
;	Peephole 300	removed redundant label 00348$
;	Peephole 300	removed redundant label 00349$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:513: decimals = length;
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
	mov	a,r2
	movx	@dptr,a
00126$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:515: if ( ( !left_justify ) && (length < width) )
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_left_justify_1_1,00273$
;	Peephole 300	removed redundant label 00350$
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r3,a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r3
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00273$
;	Peephole 300	removed redundant label 00351$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:517: width -= length;
;	genMinus
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	clr	c
;	Peephole 236.l	used r2 instead of ar2
	subb	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:518: while( width-- != 0 )
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r3,a
00127$:
;	genAssign
	mov	ar4,r3
;	genMinus
;	genMinusDec
	dec	r3
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	movx	@dptr,a
;	genCmpEq
;	gencjneshort
	cjne	r4,#0x00,00352$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00313$
00352$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:520: OUTPUT_CHAR( ' ', p );
;	genCall
	mov	dpl,#0x20
	push	ar2
	push	ar3
	lcall	__output_char
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:524: while ( *PTR  && (decimals-- > 0))
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00127$
00313$:
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	movx	@dptr,a
00273$:
;	genAssign
	mov	dptr,#__print_format_decimals_1_1
	movx	a,@dptr
	mov	r5,a
00134$:
;	genIpush
	push	ar2
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r4
	mov	dph,r7
	mov	b,r2
	lcall	__gptrget
;	genIpop
	pop	ar2
;	genIfx
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00136$
;	Peephole 300	removed redundant label 00353$
;	genAssign
	mov	ar4,r5
;	genMinus
;	genMinusDec
	dec	r5
;	genCmpGt
;	genCmp
	clr	c
;	Peephole 159	avoided xrl during execution
	mov	a,#(0x00 ^ 0x80)
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00136$
;	Peephole 300	removed redundant label 00354$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:526: OUTPUT_CHAR( *PTR++, p );
;	genIpush
	push	ar2
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	__print_format_sloc1_1_0,a
	inc	dptr
	movx	a,@dptr
	mov	(__print_format_sloc1_1_0 + 1),a
	inc	dptr
	movx	a,@dptr
	mov	(__print_format_sloc1_1_0 + 2),a
;	genPlus
;     genPlusIncr
	mov	a,#0x01
	add	a,__print_format_sloc1_1_0
	mov	r3,a
;	Peephole 181	changed mov to clr
	clr	a
	addc	a,(__print_format_sloc1_1_0 + 1)
	mov	r2,a
	mov	r4,(__print_format_sloc1_1_0 + 2)
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,__print_format_sloc1_1_0
	mov	dph,(__print_format_sloc1_1_0 + 1)
	mov	b,(__print_format_sloc1_1_0 + 2)
	lcall	__gptrget
;	genCall
	mov	r2,a
;	Peephole 244.c	loading dpl from a instead of r2
	mov	dpl,a
	push	ar2
	push	ar5
	lcall	__output_char
	pop	ar5
	pop	ar2
;	genIpop
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00134$
00136$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:529: if ( left_justify && (length < width))
;	genIfx
;	genIfxJump
	jb	__print_format_left_justify_1_1,00355$
	ljmp	00163$
00355$:
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r3,a
;	genCmpLt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r3
;	genIfxJump
	jc	00356$
	ljmp	00163$
00356$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:531: width -= length;
;	genMinus
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	clr	c
;	Peephole 236.l	used r2 instead of ar2
	subb	a,r2
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:532: while( width-- != 0 )
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r2,a
00137$:
;	genAssign
	mov	ar3,r2
;	genMinus
;	genMinusDec
	dec	r2
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r2
	movx	@dptr,a
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x00,00357$
	ljmp	00315$
00357$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:534: OUTPUT_CHAR( ' ', p );
;	genCall
	mov	dpl,#0x20
	push	ar2
	lcall	__output_char
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:539: case 'P':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00137$
00143$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:540: PTR = va_arg(ap,ptr_t);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r3,a
;	Peephole 105	removed redundant mov
	add	a,#0xfd
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar7,@r0
	dec	r0
	dec	r0
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:563: unsigned char memtype = value.byte[2];
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0002)
	movx	a,@dptr
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:564: if (memtype > 0x80)
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov  r3,a
;	Peephole 177.a	removed redundant mov
	add	a,#0xff - 0x80
	jnc	00151$
;	Peephole 300	removed redundant label 00358$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:565: c = 'C';
;	genAssign
	mov	dptr,#__print_format_c_1_1
	mov	a,#0x43
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00151$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:566: else if (memtype > 0x60)
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r3
	add	a,#0xff - 0x60
	jnc	00148$
;	Peephole 300	removed redundant label 00359$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:567: c = 'P';
;	genAssign
	mov	dptr,#__print_format_c_1_1
	mov	a,#0x50
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00148$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:568: else if (memtype > 0x40)
;	genCmpGt
;	genCmp
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
;	Peephole 132.b	optimized genCmpGt by inverse logic (acc differs)
	mov	a,r3
	add	a,#0xff - 0x40
	jnc	00145$
;	Peephole 300	removed redundant label 00360$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:569: c = 'I';
;	genAssign
	mov	dptr,#__print_format_c_1_1
	mov	a,#0x49
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00152$
00145$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:571: c = 'X';
;	genAssign
	mov	dptr,#__print_format_c_1_1
	mov	a,#0x58
	movx	@dptr,a
00152$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:573: OUTPUT_CHAR(c, p);
;	genAssign
	mov	dptr,#__print_format_c_1_1
	movx	a,@dptr
;	genCall
	mov	r3,a
;	Peephole 244.c	loading dpl from a instead of r3
	mov	dpl,a
	push	ar3
	lcall	__output_char
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:574: OUTPUT_CHAR(':', p);
;	genCall
	mov	dpl,#0x3A
	push	ar3
	lcall	__output_char
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:575: OUTPUT_CHAR('0', p);
;	genCall
	mov	dpl,#0x30
	push	ar3
	lcall	__output_char
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:576: OUTPUT_CHAR('x', p);
;	genCall
	mov	dpl,#0x78
	push	ar3
	lcall	__output_char
	pop	ar3
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:577: if ((c != 'I' /* idata */) &&
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x49,00361$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00154$
00361$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:578: (c != 'P' /* pdata */))
;	genCmpEq
;	gencjneshort
	cjne	r3,#0x50,00362$
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00154$
00362$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:580: OUTPUT_2DIGITS( value.byte[1] );
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0001)
	movx	a,@dptr
;	genCall
	mov	r3,a
;	Peephole 244.c	loading dpl from a instead of r3
	mov	dpl,a
	lcall	_output_2digits
00154$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:582: OUTPUT_2DIGITS( value.byte[0] );
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
;	genCall
	mov	r3,a
;	Peephole 244.c	loading dpl from a instead of r3
	mov	dpl,a
	lcall	_output_2digits
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:589: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:592: case 'I':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00157$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:593: signed_argument = 1;
;	genAssign
	setb	__print_format_signed_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:594: radix = 10;
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x0A
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:595: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:597: case 'O':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00158$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:598: radix = 8;
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x08
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:599: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:601: case 'U':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00159$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:602: radix = 10;
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x0A
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:603: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:605: case 'X':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00160$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:606: radix = 16;
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x10
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:607: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:609: case 'F':
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00161$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:610: float_argument=1;
;	genAssign
	setb	__print_format_float_argument_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:611: break;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:613: default:
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00162$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:615: OUTPUT_CHAR( c, p );
;	genCall
	mov	dpl,r6
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:617: }
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00163$
00315$:
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r2
	movx	@dptr,a
00163$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:619: if (float_argument) {
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_float_argument_1_1,00229$
;	Peephole 300	removed redundant label 00363$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:620: value.f=va_arg(ap,float);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	add	a,#0xfc
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar6,@r0
	dec	r0
	dec	r0
	dec	r0
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:622: PTR="<NO FLOAT>";
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,#__str_0
	movx	@dptr,a
	inc	dptr
	mov	a,#(__str_0 >> 8)
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:623: while (c=*PTR++)
00164$:
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r3 instead of ar3
	add	a,r3
	mov	r6,a
;	Peephole 181	changed mov to clr
	clr	a
;	Peephole 236.b	used r4 instead of ar4
	addc	a,r4
	mov	r7,a
	mov	ar2,r5
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	genPointerGet
;	genGenPointerGet
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrget
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
	jnz	00364$
	ljmp	00234$
00364$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:625: OUTPUT_CHAR (c, p);
;	genCall
	mov	dpl,r2
	lcall	__output_char
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00164$
00229$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:642: } else if (radix != 0)
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	movx	a,@dptr
	mov	r2,a
;	genCmpEq
;	gencjneshort
	cjne	r2,#0x00,00365$
	ljmp	00234$
00365$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:647: unsigned char _AUTOMEM *pstore = &store[5];
;	genAssign
	mov	dptr,#__print_format_pstore_4_22
	mov	a,#(__print_format_store_4_22 + 0x0005)
	movx	@dptr,a
	inc	dptr
	mov	a,#((__print_format_store_4_22 + 0x0005) >> 8)
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:650: if (char_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_char_argument_1_1,00175$
;	Peephole 300	removed redundant label 00366$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:652: value.l = va_arg(ap,char);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	dec	a
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
;	genCast
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r3,a
	mov	r4,a
	mov	r6,a
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:653: if (!signed_argument)
;	genIfx
;	genIfxJump
	jnb	__print_format_signed_argument_1_1,00367$
	ljmp	00176$
00367$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:655: value.l &= 0xFF;
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genAnd
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r6,#0x00
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00176$
00175$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:658: else if (long_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_long_argument_1_1,00172$
;	Peephole 300	removed redundant label 00368$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:660: value.l = va_arg(ap,long);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	add	a,#0xfc
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	inc	r0
	mov	ar4,@r0
	inc	r0
	mov	ar6,@r0
	dec	r0
	dec	r0
	dec	r0
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00176$
00172$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:664: value.l = va_arg(ap,int);
;	genAssign
	mov	dptr,#__print_format_PARM_4
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	add	a,#0xfe
;	genAssign
	mov	r0,a
	mov	dptr,#__print_format_PARM_4
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	genPointerGet
;	genNearPointerGet
	mov	ar2,@r0
	inc	r0
	mov	ar3,@r0
	dec	r0
;	genCast
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r6,a
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:665: if (!signed_argument)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_signed_argument_1_1,00176$
;	Peephole 300	removed redundant label 00369$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:667: value.l &= 0xFFFF;
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genAnd
	mov	r4,#0x00
	mov	r6,#0x00
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
00176$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:671: if ( signed_argument )
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_signed_argument_1_1,00181$
;	Peephole 300	removed redundant label 00370$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:673: if (value.l < 0)
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genCmpLt
;	genCmp
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	acc.7,00178$
;	Peephole 300	removed redundant label 00371$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:674: value.l = -value.l;
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genUminus
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r6
	mov	r6,a
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#_value
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00181$
00178$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:676: signed_argument = 0;
;	genAssign
	clr	__print_format_signed_argument_1_1
00181$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:680: lsd = 1;
;	genAssign
	setb	__print_format_lsd_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:682: do {
;	genAssign
	mov	dptr,#__print_format_radix_1_1
	movx	a,@dptr
	mov	r4,a
;	genAssign
	mov	__print_format_sloc2_1_0,#(__print_format_store_4_22 + 0x0005)
	mov	(__print_format_sloc2_1_0 + 1),#((__print_format_store_4_22 + 0x0005) >> 8)
;	genAssign
	mov	r5,#0x00
00185$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:683: value.byte[4] = 0;
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_value + 0x0004)
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:687: calculate_digit(radix);
;	genCall
	mov	dpl,r4
	push	ar4
	push	ar5
	lcall	_calculate_digit
	pop	ar5
	pop	ar4
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:689: if (!lsd)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_lsd_1_1,00183$
;	Peephole 300	removed redundant label 00372$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:691: *pstore = (value.byte[4] << 4) | (value.byte[4] >> 4) | *pstore;
;	genIpush
	push	ar4
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;     genSwap
	mov	r7,a
;	Peephole 105	removed redundant mov
	swap	a
	mov	r7,a
;	genPointerGet
;	genFarPointerGet
	mov	dpl,__print_format_sloc2_1_0
	mov	dph,(__print_format_sloc2_1_0 + 1)
	movx	a,@dptr
;	genOr
	mov	r2,a
;	Peephole 105	removed redundant mov
	orl	ar7,a
;	genPointerSet
;     genFarPointerSet
	mov	dpl,__print_format_sloc2_1_0
	mov	dph,(__print_format_sloc2_1_0 + 1)
	mov	a,r7
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:692: pstore--;
;	genMinus
;	genMinusDec
	dec	__print_format_sloc2_1_0
	mov	a,#0xff
	cjne	a,__print_format_sloc2_1_0,00373$
	dec	(__print_format_sloc2_1_0 + 1)
00373$:
;	genAssign
	mov	dptr,#__print_format_pstore_4_22
	mov	a,__print_format_sloc2_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(__print_format_sloc2_1_0 + 1)
	movx	@dptr,a
;	genIpop
	pop	ar4
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00184$
00183$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:696: *pstore = value.byte[4];
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genPointerSet
;     genFarPointerSet
	mov	r7,a
	mov	dpl,__print_format_sloc2_1_0
	mov	dph,(__print_format_sloc2_1_0 + 1)
;	Peephole 136	removed redundant move
	movx	@dptr,a
00184$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:698: length++;
;	genPlus
;     genPlusIncr
	inc	r5
;	genAssign
	mov	dptr,#__print_format_length_1_1
	mov	a,r5
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:699: lsd = !lsd;
;	genNot
	cpl	__print_format_lsd_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:700: } while( value.ul );
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genIfx
	mov	a,r7
	orl	a,r2
	orl	a,r6
	orl	a,r3
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00185$
;	Peephole 300	removed redundant label 00374$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:702: if (width == 0)
;	genAssign
	mov	dptr,#__print_format_pstore_4_22
	mov	a,__print_format_sloc2_1_0
	movx	@dptr,a
	inc	dptr
	mov	a,(__print_format_sloc2_1_0 + 1)
	movx	@dptr,a
;	genAssign
	mov	dptr,#__print_format_length_1_1
	mov	a,r5
	movx	@dptr,a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genIfx
	mov	r2,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00189$
;	Peephole 300	removed redundant label 00375$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:707: width=1;
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,#0x01
	movx	@dptr,a
00189$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:711: if (!zero_padding && !left_justify)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_zero_padding_1_1,00194$
;	Peephole 300	removed redundant label 00376$
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_left_justify_1_1,00194$
;	Peephole 300	removed redundant label 00377$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:713: while ( width > (unsigned char) (length+1) )
;	genPlus
;     genPlusIncr
	mov	a,#0x01
;	Peephole 236.a	used r5 instead of ar5
	add	a,r5
	mov	r2,a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r3,a
00190$:
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r3
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00317$
;	Peephole 300	removed redundant label 00378$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:715: OUTPUT_CHAR( ' ', p );
;	genCall
	mov	dpl,#0x20
	push	ar2
	push	ar3
	lcall	__output_char
	pop	ar3
	pop	ar2
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:716: width--;
;	genMinus
;	genMinusDec
	dec	r3
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00190$
00317$:
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	movx	@dptr,a
00194$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:720: if (signed_argument) // this now means the original value was negative
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_signed_argument_1_1,00204$
;	Peephole 300	removed redundant label 00379$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:722: OUTPUT_CHAR( '-', p );
;	genCall
	mov	dpl,#0x2D
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:724: width--;
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	dec	a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00205$
00204$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:726: else if (length != 0)
;	genAssign
	mov	dptr,#__print_format_length_1_1
	movx	a,@dptr
;	genCmpEq
;	gencjneshort
;	Peephole 112.b	changed ljmp to sjmp
	mov	r2,a
;	Peephole 115.b	jump optimization
	jz	00205$
;	Peephole 300	removed redundant label 00380$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:729: if (prefix_sign)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_prefix_sign_1_1,00199$
;	Peephole 300	removed redundant label 00381$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:731: OUTPUT_CHAR( '+', p );
;	genCall
	mov	dpl,#0x2B
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:733: width--;
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	dec	a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00205$
00199$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:735: else if (prefix_space)
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_prefix_space_1_1,00205$
;	Peephole 300	removed redundant label 00382$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:737: OUTPUT_CHAR( ' ', p );
;	genCall
	mov	dpl,#0x20
	lcall	__output_char
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:739: width--;
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
;	genMinus
;	genMinusDec
	mov	r2,a
;	Peephole 105	removed redundant mov
	dec	a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
00205$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:744: if (!left_justify)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_left_justify_1_1,00213$
;	Peephole 300	removed redundant label 00383$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:745: while ( width-- > length )
;	genAssign
	mov	dptr,#__print_format_length_1_1
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r3,a
00206$:
;	genAssign
	mov	ar4,r3
;	genMinus
;	genMinusDec
	dec	r3
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	movx	@dptr,a
;	genCmpGt
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r4
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00318$
;	Peephole 300	removed redundant label 00384$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:747: OUTPUT_CHAR( zero_padding ? '0' : ' ', p );
;	genIfx
;	genIfxJump
;	Peephole 108.d	removed ljmp by inverse jump logic
	jnb	__print_format_zero_padding_1_1,00239$
;	Peephole 300	removed redundant label 00385$
;	genAssign
	mov	r4,#0x30
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00240$
00239$:
;	genAssign
	mov	r4,#0x20
00240$:
;	genCall
	mov	dpl,r4
	push	ar2
	push	ar3
	lcall	__output_char
	pop	ar3
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00206$
00213$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:752: if (width > length)
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r2,a
;	genAssign
	mov	dptr,#__print_format_length_1_1
	movx	a,@dptr
;	genCmpGt
;	genCmp
	mov	r4,a
	clr	c
;	Peephole 106	removed redundant mov
	subb	a,r2
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00210$
;	Peephole 300	removed redundant label 00386$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:753: width -= length;
;	genMinus
	mov	dptr,#__print_format_width_1_1
	mov	a,r2
	clr	c
;	Peephole 236.l	used r4 instead of ar4
	subb	a,r4
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00310$
00210$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:755: width = 0;
;	genAssign
	mov	dptr,#__print_format_width_1_1
;	Peephole 181	changed mov to clr
	clr	a
	movx	@dptr,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:759: while( length-- )
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00310$
00318$:
;	genAssign
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	movx	@dptr,a
00310$:
;	genAssign
	mov	dptr,#__print_format_pstore_4_22
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genAssign
	mov	dptr,#__print_format_length_1_1
	movx	a,@dptr
	mov	r4,a
00218$:
;	genAssign
	mov	ar6,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genIfx
	mov	a,r6
;	genIfxJump
;	Peephole 108.c	removed ljmp by inverse jump logic
	jz	00220$
;	Peephole 300	removed redundant label 00387$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:761: lsd = !lsd;
;	genNot
	cpl	__print_format_lsd_1_1
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:762: if (!lsd)
;	genIfx
;	genIfxJump
;	Peephole 108.e	removed ljmp by inverse jump logic
	jb	__print_format_lsd_1_1,00216$
;	Peephole 300	removed redundant label 00388$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:764: pstore++;
;	genPlus
;     genPlusIncr
	inc	r2
	cjne	r2,#0x00,00389$
	inc	r3
00389$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:765: value.byte[4] = *pstore >> 4;
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
;	genRightShift
;	genRightShiftLiteral
;	genrshOne
	mov	r6,a
;	Peephole 105	removed redundant mov
	swap	a
	anl	a,#0x0f
;	genPointerSet
;     genFarPointerSet
	mov	r6,a
	mov	dptr,#(_value + 0x0004)
;	Peephole 100	removed redundant mov
	movx	@dptr,a
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00217$
00216$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:769: value.byte[4] = *pstore & 0x0F;
;	genPointerGet
;	genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	mov	r6,a
;	genAnd
	anl	ar6,#0x0F
;	genPointerSet
;     genFarPointerSet
	mov	dptr,#(_value + 0x0004)
	mov	a,r6
	movx	@dptr,a
00217$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:775: output_digit( value.byte[4] );
;	genPointerGet
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genCall
	mov	r6,a
;	Peephole 244.c	loading dpl from a instead of r6
	mov	dpl,a
	push	ar2
	push	ar3
	push	ar4
	lcall	_output_digit
	pop	ar4
	pop	ar3
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00218$
00220$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:778: if (left_justify)
;	genIfx
;	genIfxJump
	jb	__print_format_left_justify_1_1,00390$
	ljmp	00234$
00390$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:779: while (width-- > 0)
;	genAssign
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	mov	r2,a
00221$:
;	genAssign
	mov	ar3,r2
;	genMinus
;	genMinusDec
	dec	r2
;	genIfx
	mov	a,r3
;	genIfxJump
	jnz	00391$
	ljmp	00234$
00391$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:781: OUTPUT_CHAR(' ', p);
;	genCall
	mov	dpl,#0x20
	push	ar2
	lcall	__output_char
	pop	ar2
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00221$
00232$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:788: OUTPUT_CHAR( c, p );
;	genCall
	mov	dpl,r5
	lcall	__output_char
	ljmp	00234$
00236$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/printf_large.c:792: return charsOutputted;
;	genAssign
	mov	dptr,#_charsOutputted
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
;	genRet
;	Peephole 234.b	loading dph directly from a(ccumulator), r3 not set
	mov	dpl,r2
	mov	dph,a
;	Peephole 300	removed redundant label 00237$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
__str_0:
	.ascii "<NO FLOAT>"
	.db 0x00
	.area XINIT   (CODE)
