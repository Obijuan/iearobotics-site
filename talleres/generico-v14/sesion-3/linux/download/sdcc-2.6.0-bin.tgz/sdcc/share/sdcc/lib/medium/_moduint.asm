;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:08 2006
;--------------------------------------------------------
	.module _moduint
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __moduint_PARM_2
	.globl __moduint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
__moduint_PARM_2:
	.ds 2
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_moduint'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:172: _moduint (unsigned int a, unsigned int b)
;	-----------------------------------------
;	 function _moduint
;	-----------------------------------------
__moduint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive
	mov	r2,dpl
	mov	r3,dph
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:174: unsigned char count = 0;
;	genAssign
	mov	r4,#0x00
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:177: while (!MSB_SET(b))
;	genAssign
	mov	r5,#0x00
00103$:
;	genGetHbit
;	Peephole 263.c	optimized loading const
	mov	r0,#(__moduint_PARM_2 + 1)
	movx	a,@r0
	rl	a
	anl	a,#0x01
;	genIfx
	mov	r6,a
;	Peephole 105	removed redundant mov
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00117$
;	Peephole 300	removed redundant label 00120$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:179: b <<= 1;
;	genLeftShift
;	genLeftShiftLiteral
;	genlshTwo
;	Peephole 263.c	optimized loading const
	mov	r0,#(__moduint_PARM_2 + 1)
	movx	a,@r0
	mov	b,a
	dec	r0
	movx	a,@r0
;	Peephole 2.a	removed redundant xch xch
	add	a,acc
	xch	a,b
	rlc	a
	xch	a,b
	movx	@r0,a
	inc	r0
	mov	a,b
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:180: if (b > a)
;	genCmpGt
	mov	r0,#__moduint_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r2
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r3
	subb	a,b
;	genIfxJump
;	Peephole 108.a	removed ljmp by inverse jump logic
	jnc	00102$
;	Peephole 300	removed redundant label 00121$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:182: b >>=1;
;	genRightShift
;	genRightShiftLiteral
	mov	r0,#__moduint_PARM_2
;	genrshTwo
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	clr	c
	rrc	a
	xch	a,b
	rrc	a
;	Peephole 2.a	removed redundant xch xch
	dec	r0
	movx	@r0,a
	xch	a,b
	inc	r0
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:183: break;
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00117$
00102$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:185: count++;
;	genPlus
;     genPlusIncr
	inc	r5
;	genAssign
	mov	ar4,r5
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:187: do
;	Peephole 112.b	changed ljmp to sjmp
	sjmp	00103$
00117$:
;	genAssign
00108$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:189: if (a >= b)
;	genCmpLt
	mov	r0,#__moduint_PARM_2
;	genCmp
	clr	c
	movx	a,@r0
	mov	b,a
	mov	a,r2
	subb	a,b
	inc	r0
	movx	a,@r0
	mov	b,a
	mov	a,r3
	subb	a,b
;	genIfxJump
;	Peephole 112.b	changed ljmp to sjmp
;	Peephole 160.a	removed sjmp by inverse jump logic
	jc	00107$
;	Peephole 300	removed redundant label 00122$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:190: a -= b;
;	genMinus
	mov	r0,#__moduint_PARM_2
	setb	c
	movx	a,@r0
;	Peephole 236.l	used r2 instead of ar2
	subb	a,r2
	cpl	a
	cpl	c
	mov	r2,a
	cpl	c
	inc	r0
	movx	a,@r0
;	Peephole 236.l	used r3 instead of ar3
	subb	a,r3
	cpl	a
	mov	r3,a
00107$:
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:191: b >>= 1;
;	genRightShift
;	genRightShiftLiteral
	mov	r0,#__moduint_PARM_2
;	genrshTwo
	movx	a,@r0
	mov	b,a
	inc	r0
	movx	a,@r0
	clr	c
	rrc	a
	xch	a,b
	rrc	a
;	Peephole 2.a	removed redundant xch xch
	dec	r0
	movx	@r0,a
	xch	a,b
	inc	r0
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:193: while (count--);
;	genAssign
	mov	ar5,r4
;	genMinus
;	genMinusDec
	dec	r4
;	genIfx
	mov	a,r5
;	genIfxJump
;	Peephole 108.b	removed ljmp by inverse jump logic
	jnz	00108$
;	Peephole 300	removed redundant label 00123$
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/_moduint.c:194: return a;
;	genRet
	mov	dpl,r2
	mov	dph,r3
;	Peephole 300	removed redundant label 00111$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
