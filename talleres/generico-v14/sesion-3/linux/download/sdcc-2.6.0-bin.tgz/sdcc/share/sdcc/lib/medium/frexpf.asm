;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.6.0 #4309 (Jul 28 2006)
; This file generated Fri Jul 28 09:08:16 2006
;--------------------------------------------------------
	.module frexpf
	.optsdcc -mmcs51 --model-medium
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _frexpf_PARM_2
	.globl _frexpf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (DATA)
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
_frexpf_PARM_2:
	.ds 3
_frexpf_fl_1_1:
	.ds 4
_frexpf_i_1_1:
	.ds 4
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'frexpf'
;------------------------------------------------------------
;------------------------------------------------------------
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:24: float frexpf(const float x, int *pw2)
;	-----------------------------------------
;	 function frexpf
;	-----------------------------------------
_frexpf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;     genReceive
	mov	r2,dpl
	mov	r3,dph
	mov	r4,b
	mov	r5,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:29: fl.f=x;
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#_frexpf_fl_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:31: i  = ( fl.l >> 23) & 0x000000ff;
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#_frexpf_fl_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
;	genRightShift
;	genSignedRightShift
;	genRightShiftLiteral
;	genrshFour
	mov	r5,a
	mov	ar2,r4
;	Peephole 177.d	removed redundant move
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	jnb	acc.0,00103$
	orl	a,#0xfe
00103$:
	mov	r3,a
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genAnd
	mov	r0,#_frexpf_i_1_1
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 181	changed mov to clr
;	Peephole 181	changed mov to clr
;	Peephole 226.a	removed unnecessary clr
;	Peephole 181	changed mov to clr
	clr	a
	movx	@r0,a
	inc	r0
	movx	@r0,a
	inc	r0
;	Peephole 226.b	removed unnecessary clr
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:32: i -= 0x7e;
;	genMinus
	mov	r0,#_frexpf_i_1_1
	movx	a,@r0
	add	a,#0x82
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0xff
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0xff
	movx	@r0,a
	inc	r0
	movx	a,@r0
	addc	a,#0xff
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:33: *pw2 = i;
;	genAssign
	mov	r0,#_frexpf_PARM_2
	movx	a,@r0
	mov	r6,a
	inc	r0
	movx	a,@r0
	mov	r7,a
	inc	r0
	movx	a,@r0
	mov	r2,a
;	genCast
	mov	r0,#_frexpf_i_1_1
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
;	genPointerSet
;	genGenPointerSet
	mov	dpl,r6
	mov	dph,r7
	mov	b,r2
	mov	a,r3
	lcall	__gptrput
	inc	dptr
	mov	a,r4
	lcall	__gptrput
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:34: fl.l &= 0x807fffff; /* strip all exponent bits */
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#_frexpf_fl_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genAnd
	anl	ar4,#0x7F
	anl	ar5,#0x80
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#_frexpf_fl_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:35: fl.l |= 0x3f000000; /* mantissa between 0.5 and 1 */
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#_frexpf_fl_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
	mov	r5,a
;	genOr
	orl	ar5,#0x3F
;	genPointerSet
;	genPagedPointerSet
	mov	r0,#_frexpf_fl_1_1
;	Peephole 236.g	used r2 instead of ar2
	mov	a,r2
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r3 instead of ar3
	mov	a,r3
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r4 instead of ar4
	mov	a,r4
	movx	@r0,a
	inc	r0
;	Peephole 236.g	used r5 instead of ar5
	mov	a,r5
	movx	@r0,a
;	/home/users/s/sd/sdcc-builder/build/sdcc-build/orig/sdcc/device/lib/frexpf.c:36: return(fl.f);
;	genPointerGet
;	genPagedPointerGet
	mov	r0,#_frexpf_fl_1_1
	movx	a,@r0
	mov	r2,a
	inc	r0
	movx	a,@r0
	mov	r3,a
	inc	r0
	movx	a,@r0
	mov	r4,a
	inc	r0
	movx	a,@r0
;	genRet
	mov	r5,a
	mov	dpl,r2
	mov	dph,r3
	mov	b,r4
;	Peephole 191	removed redundant mov
;	Peephole 300	removed redundant label 00101$
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
