/****************************************************/
/* skybot-test.c   Juan Gonzalez Gomez. Julio 2005            */
/*--------------------------------------------------*/
/* Ejemplo de cliente de prueba. Se monitoriza      */
/* el estado de los sensores 1,2,3 y 4 de la GPBOT  */
/* Con un menu de opciones se puede enviar un valor */
/* al puerto B                                      */
/*--------------------------------------------------*/
/* Licencia GPL                                     */
/****************************************************/

#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stargate/stargate.h>

#include "consola_io.h"

/****************/
/* CONSTANTES   */
/****************/

//-------------------------------------------------------
//-- Cambiar estos valores segun las pruebas a realizar
//-------------------------------------------------------

//-- Recursos de la skypic
#define TRISB   0x86
#define PUERTOB 0x06

//-- Constantes para mover el skybot
#define ADELANTE  0x18 
#define ATRAS     0x78 
#define IZQUIERDA 0x58 
#define DERECHA   0x38 
#define STOP      0x00 


//--------------------
//-- VARIABLES
//--------------------
//-- Dispositivo serie a utilizar
char disp_serie[255];

/*****************************/
/*    FUNCIONES              */
/*****************************/

/******************/
/* Opcion de PING */
/******************/
void ping()
{
  int status;

  status=sg_ping();
  switch(status) {
  case 1: 
    printf ("PING OK\n");
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }
}


/********************************/
/* Identificacion del servidor  */
/********************************/
int id()
{
  int status;
  char is_cad[80];
  char im_cad[80];
  char placa_cad[80];
  byte is,im,ipv;

  status=sg_id(&is,&im,&ipv);
  switch(status) {
  case 1: 
    sg_tramas_is_to_string(is, is_cad);
    sg_tramas_im_to_string(im, im_cad);
    sg_tramas_ipv_to_string(im, ipv, placa_cad);
    printf ("SG-%s-%s-%s-%d\n",is_cad,im_cad,
	    placa_cad, (ipv&0x0F));
    break;
  case 0:
    printf ("[TIMEOUT]\n");
    break;
  default:
    printf ("[ERROR]\n");
  }

  return status;
}

/*********************/
/* Opcion de STORE   */
/*********************/
void store(int dir, int valor)
{
  int status;

  status=sg_store(dir,valor);
  if (status!=1) {
    printf ("Error en Store. Status: %d\n",status);
  }  
}

/********************/
/* Opcion de LOAD   */
/********************/
int load(int dir)
{
  int status;
  int valor;

  status=sg_load(dir,&valor);
  valor=(valor&0xFF);
  if (status!=1) {
    printf ("[Conexion perdida]\n");
    usleep(300000);
    return 0;
  }

  return valor;  

}

/*********************/
/* Imprimir el MENU  */
/*********************/

void print_menu(void)
{
  printf ("\n");
  printf ("Men� de Opciones\n");
  printf ("----------------\n");
  printf ("q.-   Adelante\n");
  printf ("a.-   Atras\n");
  printf ("o.-   Izquierda\n");
  printf ("p.-   Derecha\n");
  printf ("ESP.- STOP\n");
  printf ("\n");
  printf ("m.- Volver a imprimir el menu\n");
  printf ("ESC.- Terminar\n\n");
  printf ("4  3  2  1\n");
}

/*******************/
/* Menu Principal  */
/*******************/
void menu(void)
{
  char c;
  int s1,s2,s3,s4;
  int portb;

  //-- Imprimir el menu
  print_menu();

  //-- Bucle principal
  do {
    //-- Ha pulsado el usuario una tecla?
		if (consola_io_kbhit()) {
      
      //-- Si, leerla 
			c=consola_io_getch();
      
      //-- Seleccionar la opcion
      switch(c) {
         case 'q': 
           sg_store(PUERTOB,ADELANTE);
           break;
         case 'a':
           sg_store(PUERTOB,ATRAS);
           break;
         case 'o':
           sg_store(PUERTOB,IZQUIERDA);
           break;
         case 'p':
           sg_store(PUERTOB,DERECHA);
           break;
         case ' ':
            sg_store(PUERTOB,STOP);
            break;
         case 'm':
            print_menu();
            break;
         } 
		}	
		else {  //-- Leer sensor 1
		  portb=load(PUERTOB);
      s1 = (portb & 0x01) ? 1 : 0;
      s2 = (portb & 0x02) ? 1 : 0;
      s3 = (portb & 0x80) ? 1 : 0;
      s4 = (portb & 0x04) ? 1 : 0;
      //printf ("%2X\b\b",portb);
		  printf ("%1x  %1x  %1x  %1x\b\b\b\b\b\b\b\b\b\b",s4,s3,s2,s1);
      fflush(stdout);
    }  
    
  } while (c!=27);
}

/****************************************/
/* Establecer conexion con el servidor  */
/****************************************/
void inicio(void)
{
  int status;
  int intentos=0;

  printf ("\n");
  printf ("Cliente de prueba\n");

  do {
    printf ("Conectando...");
    fflush(stdout);
    status=id();
    intentos++;
  } while (status!=1 && intentos<3);

  if (status==1) printf ("Conexi�n establecida\n");
  else printf ("Conexi�n NO establecida\n");

}

int main (int argc, char* argv[])
{
  int serial_fd;  /*-- Descriptor puerto serie */
  
  //-- Si no se ha especificado el puerto serie como parametro
  //-- se toma por defecto el /dev/ttyS0
  if (argc<2) {
    strcpy(disp_serie,"/dev/ttyS0");
  }
  else 
    strcpy(disp_serie,argv[1]);

  //-- Abrir el puerto serie
  serial_fd=sg_serial_open(disp_serie);
  
  if (serial_fd==-1) {
    printf ("Error al abrir puerto serie: %s\n",disp_serie);
    perror("OPEN");
    exit(0);
  }
  
  //-- Configurar la consola
  consola_io_open();


  //-- Inicializar el m�dulo sg-tramas
  sg_tramas_init(serial_fd);
  
  //-- Conectar con el servidor
  inicio();
  
  //-- Opciones para el usuario
  menu();

  //-- Consola a su estado inicial
   consola_io_close();

  //-- Cerrar puerto serie
  close(serial_fd);

  printf ("\n");
  return 0;
}
