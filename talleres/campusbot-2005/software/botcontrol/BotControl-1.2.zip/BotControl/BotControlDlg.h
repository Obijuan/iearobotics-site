// BotControlDlg.h : header file
//

#if !defined(AFX_BOTCONTROLDLG_H__2DB27A77_C10F_49DE_B7B2_CE3BA65F7743__INCLUDED_)
#define AFX_BOTCONTROLDLG_H__2DB27A77_C10F_49DE_B7B2_CE3BA65F7743__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CBotControlDlg dialog

#include "CCheckSK.h"
#include "TriangleButton.h"
#include "listports.h"
#include "SGTramas.h"

class CBotControlDlg : public CDialog
{
// Construction
public:
	CBotControlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CBotControlDlg)
	enum { IDD = IDD_BOTCONTROL_DIALOG };
	CStatic	m_ctlStaticTexto;
	CButton	m_ctlButtonConectar;
	CCheckSK	m_ctlCheckSensor4;
	CCheckSK	m_ctlCheckSensor3;
	CCheckSK	m_ctlCheckSensor2;
	CCheckSK	m_ctlCheckSensor1;
	CComboBox	m_ctlComboCom;
	CTriangleButton	m_ctlButtonAtras;
	CTriangleButton	m_ctlButtonDerecha;
	CTriangleButton	m_ctlButtonIzquierda;
	CTriangleButton	m_ctlButtonAlante;
	int		m_iComPort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBotControlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CBotControlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
   	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnEditchangeCombo1();
	afx_msg void OnSelchangeCombo1();
	afx_msg void OnConnect();
	afx_msg void OnAlante();
	afx_msg void OnDerecha();
	afx_msg void OnAtras();
	afx_msg void OnIzquierda();
   afx_msg void OnMenSalir();
   afx_msg void OnMenAbout();
	
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
	//CSerial *m_pSerie;
	CSGTramas *m_pSerie;
	BOOL m_bPortOpen;
	BOOL m_bHiloEjecucion;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOTCONTROLDLG_H__2DB27A77_C10F_49DE_B7B2_CE3BA65F7743__INCLUDED_)
