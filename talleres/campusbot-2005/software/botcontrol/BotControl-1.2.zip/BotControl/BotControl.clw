; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CBotControlDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "BotControl.h"

ClassCount=3
Class1=CBotControlApp
Class2=CBotControlDlg
Class3=CAboutDlg

ResourceCount=7
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDR_MENU1 (English (U.K.))
Resource4=IDD_ABOUTBOX (Spanish (Modern))
Resource5=IDD_BOTCONTROL_DIALOG (Spanish (Modern))
Resource6=IDR_MENU1
Resource7=IDD_BOTCONTROL_DIALOG

[CLS:CBotControlApp]
Type=0
HeaderFile=BotControl.h
ImplementationFile=BotControl.cpp
Filter=N

[CLS:CBotControlDlg]
Type=0
HeaderFile=BotControlDlg.h
ImplementationFile=BotControlDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CBotControlDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=BotControlDlg.h
ImplementationFile=BotControlDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352

[DLG:IDD_BOTCONTROL_DIALOG]
Type=1
Class=CBotControlDlg
ControlCount=19
Control1=IDC_SENSOR1,button,1342246659
Control2=IDC_SENSOR2,button,1342246659
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,button,1342177287
Control5=IDC_ALANTE,button,1342242816
Control6=IDC_DERECHA,button,1342242816
Control7=IDC_ATRAS,button,1342242816
Control8=IDC_IZQUIERDA,button,1342242816
Control9=IDC_STATIC,button,1342177287
Control10=IDC_SENSOR3,button,1342246659
Control11=IDC_SENSOR4,button,1342246659
Control12=IDC_COMBO1,combobox,1344340227
Control13=IDC_BUTTON_CONECTAR,button,1342275584
Control14=IDC_TEXTO,static,1342308353
Control15=IDC_STATIC,static,1342308353
Control16=IDC_STATIC,static,1342308353
Control17=IDC_STATIC,static,1342308353
Control18=IDC_STATIC,static,1342308353
Control19=IDC_STATIC,static,1342308353

[DLG:IDD_ABOUTBOX (Spanish (Modern))]
Type=1
Class=?
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352

[DLG:IDD_BOTCONTROL_DIALOG (Spanish (Modern))]
Type=1
Class=CBotControlDlg
ControlCount=19
Control1=IDC_SENSOR1,button,1342246659
Control2=IDC_SENSOR2,button,1342246659
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,button,1342177287
Control5=IDC_ALANTE,button,1342242816
Control6=IDC_DERECHA,button,1342242816
Control7=IDC_ATRAS,button,1342242816
Control8=IDC_IZQUIERDA,button,1342242816
Control9=IDC_STATIC,button,1342177287
Control10=IDC_SENSOR3,button,1342246659
Control11=IDC_SENSOR4,button,1342246659
Control12=IDC_COMBO1,combobox,1344340227
Control13=IDC_BUTTON_CONECTAR,button,1342275584
Control14=IDC_TEXTO,static,1342308353
Control15=IDC_STATIC,static,1342308353
Control16=IDC_STATIC,static,1342308353
Control17=IDC_STATIC,static,1342308353
Control18=IDC_STATIC,static,1342308353
Control19=IDC_STATIC,static,1342308353

[MNU:IDR_MENU1]
Type=1
Class=?
Command1=ID_MEN_ABOUT
Command2=ID_MEN_SALIR
CommandCount=2

[MNU:IDR_MENU1 (English (U.K.))]
Type=1
Class=?
Command1=ID_MEN_ABOUT
Command2=ID_MEN_SALIR
CommandCount=2

