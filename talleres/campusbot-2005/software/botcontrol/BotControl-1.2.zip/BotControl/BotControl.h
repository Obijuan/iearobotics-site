// BotControl.h : main header file for the BOTCONTROL application
//

#if !defined(AFX_BOTCONTROL_H__31350C83_1D61_4DB5_A780_07A31EBF8293__INCLUDED_)
#define AFX_BOTCONTROL_H__31350C83_1D61_4DB5_A780_07A31EBF8293__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "SGTramas.h"

#define PORTB	  0x06

#define ATRAS	  0x78 
#define ALANTE    0x18 
#define IZQUIERDA 0x58 
#define DERECHA   0x38 
#define STOP      0x00


/////////////////////////////////////////////////////////////////////////////
// CBotControlApp:
// See BotControl.cpp for the implementation of this class
//

class CBotControlApp : public CWinApp
{
public:
	CBotControlApp();
	CSGTramas *m_pSerie;
	HANDLE    hIOMutex;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBotControlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBotControlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BOTCONTROL_H__31350C83_1D61_4DB5_A780_07A31EBF8293__INCLUDED_)
