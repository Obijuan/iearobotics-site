;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:58 2005
;--------------------------------------------------------
	.module _atoi
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atoi
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_atoi_sloc0_1_0::
	.ds 2
_atoi_sloc1_1_0::
	.ds 2
_atoi_sloc2_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_atoi_s_1_1::
	.ds 2
_atoi_rv_1_1::
	.ds 2
_atoi_sign_1_1::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atoi'
;------------------------------------------------------------
;sloc0                     Allocated with name '_atoi_sloc0_1_0'
;sloc1                     Allocated with name '_atoi_sloc1_1_0'
;sloc2                     Allocated with name '_atoi_sloc2_1_0'
;s                         Allocated with name '_atoi_s_1_1'
;rv                        Allocated with name '_atoi_rv_1_1'
;sign                      Allocated with name '_atoi_sign_1_1'
;------------------------------------------------------------
;_atoi.c:25: int atoi(char * s)
;	-----------------------------------------
;	 function atoi
;	-----------------------------------------
_atoi:
	sta	(_atoi_s_1_1 + 1)
	stx	_atoi_s_1_1
;_atoi.c:27: register int rv=0; 
; Peephole 5c   - eliminated redundant clra
	clra
	sta	_atoi_rv_1_1
	sta	(_atoi_rv_1_1 + 1)
;_atoi.c:31: while (*s) {
	lda	_atoi_s_1_1
	sta	*_atoi_sloc0_1_0
	lda	(_atoi_s_1_1 + 1)
	sta	*(_atoi_sloc0_1_0 + 1)
00107$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
; Peephole 2d	- eliminated jmp
	beq	00109$
00133$:
;_atoi.c:32: if (*s <= '9' && *s >= '0')
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x39
; Peephole 2i	- eliminated bra
	bgt	00102$
00134$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x30
; Peephole 2l	- eliminated bra
	bge	00109$
00135$:
;_atoi.c:33: break;
00102$:
;_atoi.c:34: if (*s == '-' || *s == '+') 
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x2D
; Peephole 2d	- eliminated jmp
	beq	00109$
00136$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x2B
; Peephole 2d	- eliminated jmp
	beq	00109$
00137$:
;_atoi.c:36: s++;
	ldhx	*_atoi_sloc0_1_0
	aix	#1
	sthx	*_atoi_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00107$
00109$:
;_atoi.c:39: sign = (*s == '-');
	lda	*_atoi_sloc0_1_0
	sta	_atoi_s_1_1
	lda	*(_atoi_sloc0_1_0 + 1)
	sta	(_atoi_s_1_1 + 1)
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x2D
	beq	00139$
	clra
	bra	00138$
00139$:
	lda	#0x01
00138$:
	sta	_atoi_sign_1_1
;_atoi.c:40: if (*s == '-' || *s == '+') s++;
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x2D
; Peephole 2d	- eliminated jmp
	beq	00110$
00140$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x2B
; Peephole 2c	- eliminated jmp
	bne	00131$
00141$:
00110$:
	lda	(_atoi_s_1_1 + 1)
	inca
	sta	(_atoi_s_1_1 + 1)
	bne	00142$
	lda	_atoi_s_1_1
	inca
	sta	_atoi_s_1_1
00142$:
;_atoi.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
	lda	_atoi_s_1_1
	sta	*_atoi_sloc0_1_0
	lda	(_atoi_s_1_1 + 1)
	sta	*(_atoi_sloc0_1_0 + 1)
00115$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	bne	00143$
; Peephole 3	- shortened jmp to bra
	bra	00117$
00143$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x30
; Peephole 2k	- eliminated bra
	blt	00117$
00144$:
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	cmp	#0x39
; Peephole 2i	- eliminated bra
	bgt	00117$
00145$:
;_atoi.c:43: rv = (rv * 10) + (*s - '0');
	clra
	sta	__mulint_PARM_2
	lda	#0x0A
	sta	(__mulint_PARM_2 + 1)
	ldx	_atoi_rv_1_1
	lda	(_atoi_rv_1_1 + 1)
	jsr	__mulint
	sta	*(_atoi_sloc1_1_0 + 1)
	stx	*_atoi_sloc1_1_0
	ldhx	*_atoi_sloc0_1_0
	lda	,x
	aix	#1
	sthx	*_atoi_sloc0_1_0
	sta	*(_atoi_sloc2_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atoi_sloc2_1_0
	lda	*(_atoi_sloc2_1_0 + 1)
	sub	#0x30
	sta	*(_atoi_sloc2_1_0 + 1)
	lda	*_atoi_sloc2_1_0
	sbc	#0x00
	sta	*_atoi_sloc2_1_0
	lda	*(_atoi_sloc1_1_0 + 1)
	add	*(_atoi_sloc2_1_0 + 1)
	sta	(_atoi_rv_1_1 + 1)
	lda	*_atoi_sloc1_1_0
	adc	*_atoi_sloc2_1_0
	sta	_atoi_rv_1_1
;_atoi.c:44: s++;
	jmp	00115$
00117$:
;_atoi.c:47: return (sign ? -rv : rv);
	lda	_atoi_sign_1_1
; Peephole 2d	- eliminated jmp
	beq	00120$
00146$:
	clra
	sub	(_atoi_rv_1_1 + 1)
	sta	*(_atoi_sloc2_1_0 + 1)
	clra
	sbc	_atoi_rv_1_1
	sta	*_atoi_sloc2_1_0
; Peephole 3	- shortened jmp to bra
	bra	00121$
00120$:
	lda	_atoi_rv_1_1
	sta	*_atoi_sloc2_1_0
	lda	(_atoi_rv_1_1 + 1)
	sta	*(_atoi_sloc2_1_0 + 1)
00121$:
	ldx	*_atoi_sloc2_1_0
	lda	*(_atoi_sloc2_1_0 + 1)
00118$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
