;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:09 2005
;--------------------------------------------------------
	.module _fs2sint
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fs2sint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fs2sint'
;------------------------------------------------------------
;f                         Allocated to registers r2 r3 r4 r5 
;sl                        Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	_fs2sint.c:65: signed int __fs2sint (float f) {
;	genFunction 
;	-----------------------------------------
;	 function __fs2sint
;	-----------------------------------------
___fs2sint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
;	_fs2sint.c:66: signed long sl=__fs2slong(f);
;	genCall 
;	genSend argreg = 1, size = 4 
	mov     r2,dpl
	mov     r3,dph
	mov     r4,dpx
	mov     r5,b
;       Peephole 238.b  removed 3 redundant moves
	mov	b,r5
	lcall	___fs2slong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	_fs2sint.c:67: if (sl>=INT_MAX)
;	genCmpLt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,#0xFF
	mov	a,r3
	subb	a,#0x7F
	mov	a,r4
	subb	a,#0x00
	mov	a,r5
	xrl	a,#0x80
	subb	a,#0x80
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00102$
00109$:
;	_fs2sint.c:68: return INT_MAX;
;	genRet 
; Peephole 182c   used 16 bit load of dptr
	mov  dptr,#0x7FFF
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00105$
00102$:
;	_fs2sint.c:69: if (sl<=INT_MIN) 
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 180   changed mov to clr
	clr  a
	subb	a,r2
	mov	a,#0x80
	subb	a,r3
	mov	a,#0xFF
	subb	a,r4
; Peephole 159   avoided xrl during execution
	mov  a,#(0xFF ^ 0x80)
	mov	b,r5
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00104$
00110$:
;	_fs2sint.c:70: return -INT_MIN;
;	genRet 
; Peephole 182c   used 16 bit load of dptr
	mov  dptr,#0x8000
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00105$
00104$:
;	_fs2sint.c:71: return sl;
;	genCast 
	mov	dpl,r2
	mov	dph,r3
;	genRet 
;	genLabel 
00105$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
