;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:22 2005
;--------------------------------------------------------
	.module _strncmp
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strncmp_PARM_3
	.globl _strncmp_PARM_2
	.globl _strncmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strncmp_PARM_2::
	.ds 4
_strncmp_PARM_3::
	.ds 2
_strncmp_sloc0_1_0::
	.ds 2
_strncmp_sloc1_1_0::
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strncmp'
;------------------------------------------------------------
;last                      Allocated with name '_strncmp_PARM_2'
;count                     Allocated with name '_strncmp_PARM_3'
;first                     Allocated to registers r2 r3 r4 r5 
;sloc0                     Allocated with name '_strncmp_sloc0_1_0'
;sloc1                     Allocated with name '_strncmp_sloc1_1_0'
;------------------------------------------------------------
;	_strncmp.c:26: int strncmp (
;	genFunction 
;	-----------------------------------------
;	 function strncmp
;	-----------------------------------------
_strncmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_strncmp.c:32: if (!count)
;	genIfx 
	mov	dptr,#_strncmp_PARM_3
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00114$
00115$:
;	_strncmp.c:33: return(0);
;	genRet 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
	ljmp	00108$
;	_strncmp.c:35: while (--count && *first && *first == *last) {
;	genLabel 
00114$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genAssign 
	mov	dptr,#_strncmp_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genAssign 
	mov	dptr,#_strncmp_PARM_3
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_strncmp_sloc0_1_0
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00105$:
;	genMinus 
	mov	dptr,#_strncmp_sloc0_1_0
	movx	a,@dptr
	add	a,#0xFF
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	movx	@dptr,a
;	genIfx 
	mov	dptr,#_strncmp_sloc0_1_0
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00116$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	mov	dps, #1
	mov	dptr, #_strncmp_sloc1_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genIfx 
	mov	dptr,#_strncmp_sloc1_1_0
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00117$:
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genCmpEq 
	mov	dptr,#_strncmp_sloc1_1_0
;	gencjne
;	gencjneshort
	movx	a,@dptr
	cjne	a,ar2,00118$
	mov	a,#1
	sjmp	00119$
00118$:
	clr	a
00119$:
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00120$:
;	_strncmp.c:36: first++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00121$
	inc	r3
	cjne	r3,#0,00121$
	inc	r4
00121$:
;	did genPlusIncr
;	_strncmp.c:37: last++;
;	genPlus 
	inc	r6
	cjne	r6,#0,00122$
	inc	r7
	cjne	r7,#0,00122$
	inc	r0
00122$:
;	did genPlusIncr
;	genGoto 
	ljmp	00105$
;	genLabel 
00107$:
;	_strncmp.c:40: return( *first - *last );
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genCast 
; Peephole 105   removed redundant mov
	mov  r2,a
	rlc	a
	subb	a,acc
	mov	r3,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
;	genCast 
; Peephole 105   removed redundant mov
	mov  r6,a
	rlc	a
	subb	a,acc
	mov	r4,a
;	genMinus 
	clr	c
	mov	a,r2
	subb	a,r6
	mov	dpl,a
	mov	a,r3
	subb	a,r4
	mov	dph,a
;	genRet 
;	genLabel 
00108$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
