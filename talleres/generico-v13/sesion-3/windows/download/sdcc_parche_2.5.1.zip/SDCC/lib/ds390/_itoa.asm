;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:41 2005
;--------------------------------------------------------
	.module _itoa
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __itoa
	.globl __uitoa
	.globl __itoa_PARM_3
	.globl __itoa_PARM_2
	.globl __uitoa_PARM_3
	.globl __uitoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__uitoa_PARM_2::
	.ds 4
__uitoa_PARM_3::
	.ds 1
__uitoa_sloc0_1_0::
	.ds 4
__uitoa_sloc1_1_0::
	.ds 2
__uitoa_sloc2_1_0::
	.ds 4
__itoa_PARM_2::
	.ds 4
__itoa_PARM_3::
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_uitoa'
;------------------------------------------------------------
;string                    Allocated with name '__uitoa_PARM_2'
;radix                     Allocated with name '__uitoa_PARM_3'
;value                     Allocated to registers r2 r3 
;index                     Allocated to registers 
;i                         Allocated to registers 
;sloc0                     Allocated with name '__uitoa_sloc0_1_0'
;sloc1                     Allocated with name '__uitoa_sloc1_1_0'
;sloc2                     Allocated with name '__uitoa_sloc2_1_0'
;------------------------------------------------------------
;	_itoa.c:18: void _uitoa(unsigned int value, char* string, unsigned char radix)
;	genFunction 
;	-----------------------------------------
;	 function _uitoa
;	-----------------------------------------
__uitoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
;	_itoa.c:26: do {
;	genAssign 
	mov	dptr,#__uitoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r0,#0x10
;	genLabel 
00103$:
;	_itoa.c:27: string[--index] = '0' + (value % radix);
;	genMinus 
	dec	r0
;	genPlus 
	mov	dptr,#__uitoa_sloc0_1_0
	mov	a,r0
	add	a,r4
	movx	@dptr,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r5
	inc	dptr
	movx	@dptr,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genCast 
	mov	dptr,#__uitoa_PARM_3
	mov	dps, #1
	mov	dptr, #__uitoa_sloc1_1_0
	dec	dps
	movx	a,@dptr
	inc	dps
	movx	@dptr,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	mov	dps,#0
;	genAssign 
	mov	dptr,#__uitoa_sloc1_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#__moduint_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	ar0
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	__moduint
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast 
	mov	r1,dpl
;	genPlus 
	mov	a,#0x30
	add	a,r1
	mov	r1,a
;	genPointerSet 
	mov     dps, #1
	mov     dptr, #__uitoa_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	mov	a,r1
	lcall	__gptrput
;	_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x39
	subb	a,r1
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00102$
00115$:
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #__uitoa_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
;	genPlus 
; Peephole 214 reduced some extra movs
; Peephole 215 removed some movs
	add  a,#0x07
	mov  r1,a
;	genPointerSet 
	mov     dps, #1
	mov     dptr, #__uitoa_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	mov	a,r1
	lcall	__gptrput
;	genLabel 
00102$:
;	_itoa.c:29: value /= radix;
;	genIpush 
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;	genAssign 
	mov	dptr,#__uitoa_sloc1_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#__divuint_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
	push	ar5
	push	ar6
	push	ar7
	push	ar0
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	__divuint
	mov	r1,dpl
	mov	r4,dph
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r1
	mov	ar3,r4
;	_itoa.c:30: } while (value != 0);
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,r2
	cjne	a,#0x00,00116$
	mov	a,r3
	cjne	a,#0x00,00116$
	mov	a,#1
	sjmp	00117$
00116$:
	clr	a
00117$:
;	genIpop 
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
;	genIfx 
;	genIfxJump
	jnz	00118$
	ljmp	00103$
00118$:
;	_itoa.c:32: do {
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r3,#0x00
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar1,r0
;	genLabel 
00106$:
;	_itoa.c:33: string[i++] = string[index++];
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar0,r3
;	genPlus 
	inc	r3
;	did genPlusIncr
;	genPlus 
	mov	dptr,#__uitoa_sloc2_1_0
	mov	a,r0
	add	a,r4
	movx	@dptr,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r5
	inc	dptr
	movx	@dptr,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r1
;	genPlus 
	inc	r1
;	did genPlusIncr
;	genPlus 
	mov	a,r2
	add	a,r4
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r5
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r6
	mov	dpx,a
	mov	b,r7
;	genPointerGet 
;	genGenPointerGet 
	lcall	__gptrget
	mov	r2,a
;	genPointerSet 
	mov     dps, #1
	mov     dptr, #__uitoa_sloc2_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	mov	a,r2
	lcall	__gptrput
;	_itoa.c:34: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt 
;	genCmp
	cjne	r1,#0x10,00119$
00119$:
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00106$
00120$:
;	_itoa.c:36: string[i] = 0; /* string terminator */
;	genPlus 
	mov	a,r3
	add	a,r4
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r5
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r6
	mov	dpx,a
	mov	b,r7
;	genPointerSet 
; Peephole 180   changed mov to clr
	clr  a
	lcall	__gptrput
;	genLabel 
00109$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_itoa'
;------------------------------------------------------------
;string                    Allocated with name '__itoa_PARM_2'
;radix                     Allocated with name '__itoa_PARM_3'
;value                     Allocated to registers r2 r3 
;------------------------------------------------------------
;	_itoa.c:39: void _itoa(int value, char* string, unsigned char radix)
;	genFunction 
;	-----------------------------------------
;	 function _itoa
;	-----------------------------------------
__itoa:
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
;	_itoa.c:41: if (value < 0 && radix == 10) {
;	genCmpLt 
;	genCmp
	mov	a,r3
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00102$
00108$:
;	genCmpEq 
	mov	dptr,#__itoa_PARM_3
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x0A,00102$
;00109$:
; Peephole 200   removed redundant sjmp
00110$:
;	_itoa.c:42: *string++ = '-';
;	genAssign 
	mov	dptr,#__itoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPointerSet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r6
	mov	b,r7
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus 
	mov	dptr,#__itoa_PARM_2
	mov	a,#0x01
	add	a,r4
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r5
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	_itoa.c:43: value = -value;
;	genUminus 
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
;	genLabel 
00102$:
;	_itoa.c:45: _uitoa(value, string, radix);
;	genAssign 
	mov	dptr,#__itoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__uitoa_PARM_2
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genAssign 
	mov	dptr,#__itoa_PARM_3
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
	mov	dptr,#__uitoa_PARM_3
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	__uitoa
;	genLabel 
00104$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
