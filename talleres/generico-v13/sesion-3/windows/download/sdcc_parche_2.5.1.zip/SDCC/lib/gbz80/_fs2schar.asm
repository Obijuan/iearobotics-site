;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:25 2005
;--------------------------------------------------------
	.module _fs2schar
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fs2schar
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_fs2schar.c:70: signed char __fs2schar (float f) {
;	genLabel
;	genFunction
;	---------------------------------
; Function __fs2schar
; ---------------------------------
___fs2schar_start::
___fs2schar:
	lda	sp,-4(sp)
;_fs2schar.c:71: signed long sl=__fs2slong(f);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fs2slong
;	AOP_STK for ___fs2schar_sl_1_1
	push	hl
	lda	hl,6(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,4(sp)
;	genAssign
;	AOP_STK for ___fs2schar_sl_1_1
;	(registers are the same)
;_fs2schar.c:72: if (sl>=CHAR_MAX)
;	genCmpLt
;	AOP_STK for ___fs2schar_sl_1_1
	lda	hl,0(sp)
	ld	a,(hl)
	sub	a,#0x7F
	inc	hl
	ld	a,(hl)
	sbc	a,#0x00
	inc	hl
	ld	a,(hl)
	sbc	a,#0x00
	inc	hl
	ld	a,(hl)
	sbc	a,#0x00
	rlca
	jp	c,00102$
;_fs2schar.c:73: return CHAR_MAX;
;	genRet
; Dump of IC_LEFT: type AOP_LIT size 1
	ld	e,#0x7F
	jp	00105$
;	genLabel
00102$:
;_fs2schar.c:74: if (sl<=CHAR_MIN) 
;	genCmpGt
;	AOP_STK for ___fs2schar_sl_1_1
	ld	a,#0x80
	lda	hl,0(sp)
	sub	a,(hl)
	ld	a,#0xFF
	inc	hl
	sbc	a,(hl)
	ld	a,#0xFF
	inc	hl
	sbc	a,(hl)
	ld	a,#0xFF
	inc	hl
	sbc	a,(hl)
	rlca
	jp	c,00104$
;_fs2schar.c:75: return -CHAR_MIN;
;	genRet
; Dump of IC_LEFT: type AOP_LIT size 1
	ld	e,#0x80
	jp	00105$
;	genLabel
00104$:
;_fs2schar.c:76: return sl;
;	genCast
;	AOP_STK for ___fs2schar_sl_1_1
	lda	hl,0(sp)
	ld	e,(hl)
;	genRet
; Dump of IC_LEFT: type AOP_STR size 1
;	genLabel
00105$:
;	genEndFunction
	lda	sp,4(sp)
	ret
___fs2schar_end::
	.area _CODE
