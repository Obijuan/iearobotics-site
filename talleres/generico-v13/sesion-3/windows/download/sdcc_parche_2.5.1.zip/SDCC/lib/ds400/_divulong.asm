;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:50:14 2005
;--------------------------------------------------------
	.module _divulong
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divulong_PARM_2
	.globl __divulong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
__divulong_c_1_1::
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__divulong_PARM_2::
	.ds 4
__divulong_reste_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divulong'
;------------------------------------------------------------
;b                         Allocated with name '__divulong_PARM_2'
;a                         Allocated to registers r2 r3 r4 r5 
;reste                     Allocated with name '__divulong_reste_1_1'
;count                     Allocated to registers 
;------------------------------------------------------------
;	_divulong.c:329: _divulong (unsigned long a, unsigned long b)
;	genFunction 
;	-----------------------------------------
;	 function _divulong
;	-----------------------------------------
__divulong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_divulong.c:331: unsigned long reste = 0L;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_reste_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	_divulong.c:335: do
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0x20
;	genLabel 
00105$:
;	_divulong.c:338: c = MSB_SET(a);
;	genIpush 
	push	ar6
;	genGetHbit 
	mov	a,r5
	rlc	a
	mov	__divulong_c_1_1,c
;	_divulong.c:339: a <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	r7,ar2
	mov	r0,ar3
	mov	r1,ar4
	mov	r6,ar5
	sjmp	00115$
00114$:
	mov	a,r7
	add	a,acc
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
	mov	a,r6
	rlc	a
	mov	r6,a
00115$:
	djnz	b,00114$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r7
	mov	ar3,r0
	mov	ar4,r1
	mov	ar5,r6
;	_divulong.c:340: reste <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	dptr,#__divulong_reste_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r6,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r7,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r0,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r1,a
	sjmp	00117$
00116$:
	mov	a,r6
	add	a,acc
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
00117$:
	djnz	b,00116$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_reste_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	_divulong.c:341: if (c)
;	genIpop 
	pop	ar6
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __divulong_c_1_1,00102$
00118$:
;	_divulong.c:342: reste |= 1L;
;	genOr 
	mov	dptr,#__divulong_reste_1_1
;	better literal OR.
	movx	a,@dptr
	orl	a, #0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genLabel 
00102$:
;	_divulong.c:344: if (reste >= b)
;	genCmpLt 
	mov	dptr,#__divulong_PARM_2
	mov	dps, #1
	mov	dptr, #__divulong_reste_1_1
	dec	dps
;	genCmp
	clr	c
	mov	dps,#1
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00106$
00119$:
;	_divulong.c:346: reste -= b;
;	genIpush 
	push	ar6
;	genMinus 
	mov	dptr,#__divulong_PARM_2
	mov	dps, #1
	mov	dptr, #__divulong_reste_1_1
	dec	dps
	clr	c
	movx	a,@dptr
	mov	b,a
	inc	dps
	movx	a,@dptr
	subb	a,b
	mov	r7,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r0,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r1,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r6,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_reste_1_1
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_divulong.c:348: a |= 1L;
;	genOr 
	orl	ar2,#0x01
;	_divulong.c:352: return a;
;	genIpop 
	pop	ar6
;	_divulong.c:348: a |= 1L;
;	genLabel 
00106$:
;	_divulong.c:351: while (--count);
;	genDjnz
; Peephole 236e
	djnz  r6,00120$
	sjmp	00121$
00120$:
	ljmp	00105$
00121$:
;	_divulong.c:352: return a;
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00108$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
