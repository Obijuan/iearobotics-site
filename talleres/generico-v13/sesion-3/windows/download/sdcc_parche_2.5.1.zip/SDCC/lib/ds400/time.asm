;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:52:01 2005
;--------------------------------------------------------
	.module time
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___day
	.globl ___month
	.globl _time
	.globl _asctime
	.globl _ctime
	.globl _localtime
	.globl _gmtime
	.globl _mktime
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_P4	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_DPL1	=	0x0084
_DPH1	=	0x0085
_DPS	=	0x0086
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_CKCON	=	0x008e
_P1	=	0x0090
_EXIF	=	0x0091
_P4CNT	=	0x0092
_DPX	=	0x0093
_DPX1	=	0x0095
_SCON0	=	0x0098
_SBUF0	=	0x0099
_ESP	=	0x009b
_AP	=	0x009c
_ACON	=	0x009d
_P2	=	0x00a0
_P5	=	0x00a1
_P5CNT	=	0x00a2
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_SCON1	=	0x00c0
_SBUF1	=	0x00c1
_PMR	=	0x00c4
_MCON	=	0x00c6
_TA	=	0x00c7
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2L	=	0x00ca
_RTL2	=	0x00ca
_RCAP2H	=	0x00cb
_RTH2	=	0x00cb
_TL2	=	0x00cc
_TH2	=	0x00cd
_PSW	=	0x00d0
_MCNT0	=	0x00d1
_MCNT1	=	0x00d2
_MA	=	0x00d3
_MB	=	0x00d4
_MC	=	0x00d5
_WDCON	=	0x00d8
_ACC	=	0x00e0
_EIE	=	0x00e8
_MXAX	=	0x00ea
_B	=	0x00f0
_EIP	=	0x00f8
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_T2	=	0x0090
_T2EX	=	0x0091
_RXD1	=	0x0092
_TXD1	=	0x0093
_INT2	=	0x0094
_INT3	=	0x0095
_INT4	=	0x0096
_INT5	=	0x0097
_RI_0	=	0x0098
_TI_0	=	0x0099
_RB8_0	=	0x009a
_TB8_0	=	0x009b
_REN_0	=	0x009c
_SM2_0	=	0x009d
_SM1_0	=	0x009e
_SM0_0	=	0x009f
_FE_0	=	0x009f
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES0	=	0x00ac
_ET2	=	0x00ad
_ES1	=	0x00ae
_EA	=	0x00af
_RXD0	=	0x00b0
_TXD0	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS0	=	0x00bc
_PT2	=	0x00bd
_PS1	=	0x00be
_RI_1	=	0x00c0
_TI_1	=	0x00c1
_RB8_1	=	0x00c2
_TB8_1	=	0x00c3
_REN_1	=	0x00c4
_SM2_1	=	0x00c5
_SM1_1	=	0x00c6
_SM0_1	=	0x00c7
_FE_1	=	0x00c7
_CP_RL	=	0x00c8
_C_T	=	0x00c9
_TR2	=	0x00ca
_EXEN2	=	0x00cb
_TCLK	=	0x00cc
_RCLK	=	0x00cd
_EXF2	=	0x00ce
_TF2	=	0x00cf
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_RWT	=	0x00d8
_EWT	=	0x00d9
_WDRF	=	0x00da
_WDIF	=	0x00db
_PFI	=	0x00dc
_EPFI	=	0x00dd
_POR	=	0x00de
_SMOD_1	=	0x00df
_EX2	=	0x00e8
_EX3	=	0x00e9
_EX4	=	0x00ea
_EX5	=	0x00eb
_EWDI	=	0x00ec
_C1IE	=	0x00ed
_C0IE	=	0x00ee
_CANBIE	=	0x00ef
_PX2	=	0x00f8
_PX3	=	0x00f9
_PX4	=	0x00fa
_PX5	=	0x00fb
_PWDI	=	0x00fc
_C1IP	=	0x00fd
_C0IP	=	0x00fe
_CANBIP	=	0x00ff
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_time_timeptr_1_1::
	.ds 4
_time_now_1_1::
	.ds 12
_ascTimeBuffer:
	.ds 32
_CheckTime_sloc0_1_0::
	.ds 1
_asctime_timeptr_1_1::
	.ds 4
_asctime_sloc0_1_0::
	.ds 2
_asctime_sloc1_1_0::
	.ds 2
_asctime_sloc2_1_0::
	.ds 2
_asctime_sloc3_1_0::
	.ds 2
_asctime_sloc4_1_0::
	.ds 2
_lastTime:
	.ds 12
_gmtime_days_1_1::
	.ds 4
_gmtime_sloc0_1_0::
	.ds 4
_mktime_timeptr_1_1::
	.ds 4
_mktime_month_1_1::
	.ds 2
_mktime_seconds_1_1::
	.ds 4
_mktime_sloc0_1_0::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'time'
;------------------------------------------------------------
;timeptr                   Allocated with name '_time_timeptr_1_1'
;now                       Allocated with name '_time_now_1_1'
;t                         Allocated to registers r6 r7 r0 r1 
;------------------------------------------------------------
;	time.c:46: time_t time(time_t *timeptr) {
;	genFunction 
;	-----------------------------------------
;	 function time
;	-----------------------------------------
_time:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_time_timeptr_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	time.c:48: time_t t=-1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r6,#0xFF
	mov	r7,#0xFF
	mov	r0,#0xFF
	mov	r1,#0xFF
;	time.c:50: if (RtcRead(&now)) {
;	genCall 
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 4 
; Peephole 182b used 24 bit load of DPTR
	mov dptr,#_time_now_1_1
	mov	b,#0x00
	lcall	_RtcRead
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00109$:
;	time.c:51: t=mktime(&now);
;	genCall 
;	genSend argreg = 1, size = 4 
; Peephole 182b used 24 bit load of DPTR
	mov dptr,#_time_now_1_1
	mov	b,#0x00
	lcall	_mktime
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar6,r2
	mov	ar7,r3
	mov	ar0,r4
	mov	ar1,r5
;	genLabel 
00102$:
;	time.c:53: if (timeptr) {
;	genIfx 
	mov	dptr,#_time_timeptr_1_1
;	toBoolean: generic ptr special case.
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00104$
00110$:
;	time.c:54: *timeptr=t;
;	genPointerSet 
	mov     dps, #1
	mov     dptr, #_time_timeptr_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	mov	_ap, r6
	mov	a,r7
	lcall	__gptrputWord
	inc	dptr
	mov	_ap, r0
	mov	a,r1
	lcall	__gptrputWord
;	genLabel 
00104$:
;	time.c:56: return t;
;	genRet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
;	genLabel 
00105$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'CheckTime'
;------------------------------------------------------------
;timeptr                   Allocated to registers r2 r3 r4 r5 
;sloc0                     Allocated with name '_CheckTime_sloc0_1_0'
;------------------------------------------------------------
;	time.c:69: static void CheckTime(struct tm *timeptr) {
;	genFunction 
;	-----------------------------------------
;	 function CheckTime
;	-----------------------------------------
_CheckTime:
;	genReceive 
;	time.c:80: if (timeptr->tm_sec>59) timeptr->tm_sec=59;
;	genPointerGet 
;	genGenPointerGet 
	mov     r2,dpl
	mov     r3,dph
	mov     r4,dpx
	mov     r5,b
;       Peephole 238.b  removed 3 redundant moves
	mov	b,r5
	lcall	__gptrget
	mov	r6,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x3B
	subb	a,r6
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00102$
00128$:
;	genPointerSet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	mov	a,#0x3B
	lcall	__gptrput
;	genLabel 
00102$:
;	time.c:81: if (timeptr->tm_min>59) timeptr->tm_min=59;
;	genPlus 
	mov	a,#0x01
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x3B
	subb	a,r2
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00104$
00129$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x3B
	lcall	__gptrput
;	genLabel 
00104$:
;	time.c:82: if (timeptr->tm_hour>23) timeptr->tm_hour=23;
;	genPlus 
	mov	a,#0x02
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x17
	subb	a,r2
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00130$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x17
	lcall	__gptrput
;	genLabel 
00106$:
;	time.c:83: if (timeptr->tm_wday>6) timeptr->tm_wday=6;
;	genPlus 
	mov	a,#0x07
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x06
	subb	a,r2
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00108$
00131$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x06
	lcall	__gptrput
;	genLabel 
00108$:
;	time.c:84: if (timeptr->tm_mday<1) timeptr->tm_mday=1;
;	genPlus 
	mov	a,#0x03
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	dps, #1
	mov	dptr, #_CheckTime_sloc0_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genCmpLt 
	mov	dptr,#_CheckTime_sloc0_1_0
;	genCmp
	movx	a,@dptr
	cjne	a,#0x01,00132$
00132$:
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00112$
00133$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x01
	lcall	__gptrput
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00113$
00112$:
;	time.c:85: else if (timeptr->tm_mday>31) timeptr->tm_mday=31;
;	genCmpGt 
	mov	dptr,#_CheckTime_sloc0_1_0
;	genCmp
	clr	c
	mov	a,#0x1F
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00113$
00134$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x1F
	lcall	__gptrput
;	genLabel 
00113$:
;	time.c:86: if (timeptr->tm_mon>11) timeptr->tm_mon=11;
;	genPlus 
	mov	a,#0x04
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r2,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x0B
	subb	a,r2
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00115$
00135$:
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x0B
	lcall	__gptrput
;	genLabel 
00115$:
;	time.c:87: if (timeptr->tm_year<0) timeptr->tm_year=0;
;	genPlus 
	mov	a,#0x05
	add	a,r2
	mov	r2,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r3,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r4,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrgetWord
	mov	r6,_ap
;	genCmpLt 
;	genCmp
; Peephole 105   removed redundant mov
	mov  r7,a
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00118$
00136$:
;	genPointerSet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
; Peephole 3.a   changed mov to clr
	clr  a
	mov  _ap,a
	lcall	__gptrputWord
;	genLabel 
00118$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'asctime'
;------------------------------------------------------------
;timeptr                   Allocated with name '_asctime_timeptr_1_1'
;sloc0                     Allocated with name '_asctime_sloc0_1_0'
;sloc1                     Allocated with name '_asctime_sloc1_1_0'
;sloc2                     Allocated with name '_asctime_sloc2_1_0'
;sloc3                     Allocated with name '_asctime_sloc3_1_0'
;sloc4                     Allocated with name '_asctime_sloc4_1_0'
;------------------------------------------------------------
;	time.c:91: char *asctime(struct tm *timeptr) {
;	genFunction 
;	-----------------------------------------
;	 function asctime
;	-----------------------------------------
_asctime:
;	genReceive 
	mov     dps, #1
	mov     dptr, #_asctime_timeptr_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
;	time.c:92: CheckTime(timeptr);
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_asctime_timeptr_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_CheckTime
;	time.c:96: timeptr->tm_year+1900);
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x05
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
;	genPlus 
	mov	dptr,#_asctime_sloc4_1_0
	mov	a,#0x6C
	add	a,r6
	movx	@dptr,a
	mov	a,#0x07
	addc	a,r7
	inc	dptr
	movx	@dptr,a
;	time.c:95: timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec, 
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_asctime_timeptr_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
;	genCast 
; Peephole 100   removed redundant mov
	mov  r0,a
	mov  dptr,#_asctime_sloc3_1_0
	movx @dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genCast 
; Peephole 100   removed redundant mov
	mov  r2,a
	mov  dptr,#_asctime_sloc0_1_0
	movx @dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x02
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r2
	mov	b,r3
	lcall	__gptrget
;	genCast 
; Peephole 100   removed redundant mov
	mov  r4,a
	mov  dptr,#_asctime_sloc1_1_0
	movx @dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	time.c:94: __day[timeptr->tm_wday], __month[timeptr->tm_mon], timeptr->tm_mday,
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x03
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r3
	mov	dph,r5
	mov	dpx,r2
	mov	b,r4
	lcall	__gptrget
;	genCast 
; Peephole 100   removed redundant mov
	mov  r3,a
	mov  dptr,#_asctime_sloc2_1_0
	movx @dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x04
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r2
	mov	b,r3
	lcall	__gptrget
	mov	r4,a
;	genMult 
	mov	b,#0x03
	mov	a,r4
	mul	ab
;	genPlus 
; Peephole 229.b redundant move
	mov	r4,a
	mov	r2,b
	add	a,#___month
	mov	dpl,a
	mov	a,r2
	addc	a,#(___month >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(___month >> 16)
	mov	dpx,a
;	genPointerGet 
	clr	a
	movc	a,@a+dptr
	inc	dptr
	mov	r2,a
	clr	a
	movc	a,@a+dptr
	inc	dptr
	mov	r3,a
	clr	a
	movc	a,@a+dptr
	mov	r4,a
;	genCast 
	mov	r5,#0x80
;	genPlus 
	mov	dptr,#_asctime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x07
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r6
	mov	b,r7
	lcall	__gptrget
	mov	r0,a
;	genMult 
	mov	b,#0x03
	mov	a,r0
	mul	ab
;	genPlus 
; Peephole 229.b redundant move
	mov	r0,a
	mov	r6,b
	add	a,#___day
	mov	dpl,a
	mov	a,r6
	addc	a,#(___day >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(___day >> 16)
	mov	dpx,a
;	genPointerGet 
	clr	a
	movc	a,@a+dptr
	inc	dptr
	mov	r6,a
	clr	a
	movc	a,@a+dptr
	inc	dptr
	mov	r7,a
	clr	a
	movc	a,@a+dptr
	mov	r0,a
;	genCast 
	mov	r1,#0x80
;	time.c:93: sprintf (ascTimeBuffer, "%s %s %2d %02d:%02d:%02d %04d\n",
;	genIpush 
	mov	dptr,#_asctime_sloc4_1_0
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genIpush 
	mov	dptr,#_asctime_sloc3_1_0
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genIpush 
	mov	dptr,#_asctime_sloc0_1_0
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genIpush 
	mov	dptr,#_asctime_sloc1_1_0
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genIpush 
	mov	dptr,#_asctime_sloc2_1_0
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genIpush 
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genIpush 
	mov	a,#__str_0
	push	acc
	mov	a,#(__str_0 >> 8)
	push	acc
	mov	a,#(__str_0 >> 16)
	push	acc
	mov	a,#0x80
	push	acc
;	genIpush 
	mov	a,#_ascTimeBuffer
	push	acc
	mov	a,#(_ascTimeBuffer >> 8)
	push	acc
	mov	a,#(_ascTimeBuffer >> 16)
	push	acc
; Peephole 180   changed mov to clr
	clr  a
	push	acc
;	genCall 
	lcall	_sprintf
	clr	c
	mov	a,sp
	subb	a,#0x1A
	mov	sp,a
	mov	a,esp
	anl	a,#3
	orl	a,#0xDC
	subb	a,#0x00
	mov	esp,a
;	time.c:97: return ascTimeBuffer;
;	genRet 
; Peephole 182b used 24 bit load of DPTR
	mov dptr,#_ascTimeBuffer
	mov	b,#0x00
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ctime'
;------------------------------------------------------------
;timep                     Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	time.c:100: char *ctime(time_t *timep) {
;	genFunction 
;	-----------------------------------------
;	 function ctime
;	-----------------------------------------
_ctime:
;	genReceive 
;	time.c:101: return asctime(localtime(timep));
;	genCall 
;	genSend argreg = 1, size = 4 
	mov     r2,dpl
	mov     r3,dph
	mov     r4,dpx
	mov     r5,b
;       Peephole 238.b  removed 3 redundant moves
	mov	b,r5
	lcall	_localtime
;	genCall 
;	genSend argreg = 1, size = 4 
	lcall	_asctime
;	genRet 
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'localtime'
;------------------------------------------------------------
;timep                     Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	time.c:117: struct tm *localtime(time_t *timep) {
;	genFunction 
;	-----------------------------------------
;	 function localtime
;	-----------------------------------------
_localtime:
;	genReceive 
;	time.c:118: return gmtime(timep);
;	genCall 
;	genSend argreg = 1, size = 4 
	mov     r2,dpl
	mov     r3,dph
	mov     r4,dpx
	mov     r5,b
;       Peephole 238.b  removed 3 redundant moves
	mov	b,r5
	lcall	_gmtime
;	genRet 
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'gmtime'
;------------------------------------------------------------
;timep                     Allocated to registers 
;epoch                     Allocated to registers r2 r3 r4 r5 
;year                      Allocated to registers 
;month                     Allocated to registers 
;monthLength               Allocated to registers r0 
;days                      Allocated with name '_gmtime_days_1_1'
;sloc0                     Allocated with name '_gmtime_sloc0_1_0'
;------------------------------------------------------------
;	time.c:121: struct tm *gmtime(time_t *timep) {
;	genFunction 
;	-----------------------------------------
;	 function gmtime
;	-----------------------------------------
_gmtime:
;	genReceive 
;	time.c:122: unsigned long epoch=*timep;
;	genPointerGet 
;	genGenPointerGet 
	lcall	__gptrgetWord
	mov	r2,_ap
	mov	r3,a
	inc	dptr
	lcall	__gptrgetWord
	mov	r4,_ap
	mov	r5,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	time.c:127: lastTime.tm_sec=epoch%60;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__modulong
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast 
	mov	r6,dpl
;	genPointerSet 
	mov	dptr,#_lastTime
	mov	a,r6
	movx	@dptr,a
;	time.c:128: epoch/=60; // now it is minutes
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__divulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	time.c:129: lastTime.tm_min=epoch%60;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__modulong
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast 
	mov	r6,dpl
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0001)
	mov	a,r6
	movx	@dptr,a
;	time.c:130: epoch/=60; // now it is hours
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x3C
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__divulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	time.c:131: lastTime.tm_hour=epoch%24;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__modulong
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast 
	mov	r6,dpl
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0002)
	mov	a,r6
	movx	@dptr,a
;	time.c:132: epoch/=24; // now it is days
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x18
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__divulong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	time.c:133: lastTime.tm_wday=(epoch+4)%7;
;	genPlus 
	mov	a,#0x04
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r5
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x07
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__modulong
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genCast 
	mov	r6,dpl
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0007)
	mov	a,r6
	movx	@dptr,a
;	time.c:136: days=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_gmtime_days_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	time.c:137: while((days += (LEAP_YEAR(year) ? 366 : 365)) <= epoch) {
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0xB2
	mov	r7,#0x07
;	genLabel 
00101$:
;	genAnd 
;	better literal AND.
	mov	a,r6
	anl	a, #0x03
	mov	r0,a
	mov	r1,#0
;	genCmpEq 
;	gencjneshort
	mov	a,r0
; Peephole 132   changed ljmp to sjmp
; Peephole 197   optimized misc jump sequence
	cjne a,#0x00,00119$
	mov  a,r1
	cjne a,#0x00,00119$
;00132$:
; Peephole 200   removed redundant sjmp
00133$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r0,#0x6E
	mov	r1,#0x01
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00120$
00119$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r0,#0x6D
	mov	r1,#0x01
;	genLabel 
00120$:
;	genIpush 
	push	ar6
	push	ar7
;	genCast 
	mov	a,r1
	rlc	a
	subb	a,acc
	mov	r6,a
	mov	r7,a
;	genPlus 
	mov	dptr,#_gmtime_days_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r0
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	addc	a,r1
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	addc	a,r6
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,r7
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_gmtime_days_1_1
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r0
	mov	a,r3
	subb	a,r1
	mov	a,r4
	subb	a,r6
	mov	a,r5
	subb	a,r7
	clr	a
	rlc	a
;	genIpop 
	pop	ar7
	pop	ar6
;	genIfx 
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00103$
00134$:
;	time.c:138: year++;
;	genPlus 
	inc	r6
	cjne	r6,#0,00135$
	inc	r7
00135$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00101$
00103$:
;	time.c:140: lastTime.tm_year=year-1900;
;	genMinus 
	mov	a,r6
	add	a,#0x94
	mov	r0,a
	mov	a,r7
	addc	a,#0xF8
	mov	r1,a
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0005)
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	time.c:142: days -= LEAP_YEAR(year) ? 366 : 365;
;	genAnd 
	anl	ar6,#0x03
	mov	r7,#0
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,r6
	cjne	a,#0x00,00136$
	mov	a,r7
	cjne	a,#0x00,00136$
	mov	a,#1
	sjmp	00137$
00136$:
	clr	a
00137$:
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00121$
00138$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r7,#0x6E
	mov	r0,#0x01
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00122$
00121$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r7,#0x6D
	mov	r0,#0x01
;	genLabel 
00122$:
;	genIpush 
	push	ar6
;	genCast 
	mov	a,r0
	rlc	a
	subb	a,acc
	mov	r1,a
	mov	r6,a
;	genMinus 
	mov	dptr,#_gmtime_days_1_1
	clr	c
	movx	a,@dptr
	subb	a,r7
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	subb	a,r0
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	subb	a,r1
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	subb	a,r6
	movx	@dptr,a
;	time.c:143: epoch -= days; // now it is days in this year, starting at 0
;	genMinus 
	mov	dptr,#_gmtime_days_1_1
	clr	c
	movx	a,@dptr
	mov	b,a
	mov	a,r2
	subb	a,b
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r3
	subb	a,b
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r4
	subb	a,b
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r5
	subb	a,b
	mov	r5,a
;	time.c:144: lastTime.tm_yday=epoch;
;	genCast 
	mov	ar6,r2
	mov	ar7,r3
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0008)
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	time.c:171: return &lastTime;
;	genIpop 
	pop	ar6
;	time.c:149: for (month=0; month<12; month++) {
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r7,#0x00
;	genLabel 
00113$:
;	genCmpLt 
;	genCmp
	cjne	r7,#0x0C,00139$
00139$:
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 161   removed sjmp by inverse jump logic
	jnc  00116$
00140$:
;	time.c:150: if (month==1) { // februari
;	genCmpEq 
;	gencjneshort
	mov	a,r7
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x01,00108$
;00141$:
; Peephole 200   removed redundant sjmp
00142$:
;	time.c:151: if (LEAP_YEAR(year)) {
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00105$
00143$:
;	time.c:152: monthLength=29;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r0,#0x1D
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00105$:
;	time.c:154: monthLength=28;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r0,#0x1C
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00108$:
;	time.c:157: monthLength = monthDays[month];
;	genPlus 
	mov	a,r7
; Peephole 3.d   changed mov to clr
; Peephole 3.d   changed mov to clr
;	genPointerGet 
; Peephole 227.a movc optimize
	mov	dptr,#_monthDays
	movc	a,@a+dptr
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar0,r1
;	genLabel 
00109$:
;	time.c:160: if (epoch>=monthLength) {
;	genCast 
	mov	dptr,#_gmtime_sloc0_1_0
	mov	a,r0
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	genCmpLt 
	mov	dptr,#_gmtime_sloc0_1_0
;	genCmp
	clr	c
	mov	a,r2
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r3
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r4
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r5
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00116$
00144$:
;	time.c:161: epoch-=monthLength;
;	genMinus 
	mov	dptr,#_gmtime_sloc0_1_0
	clr	c
	movx	a,@dptr
	mov	b,a
	mov	a,r2
	subb	a,b
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r3
	subb	a,b
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r4
	subb	a,b
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,r5
	subb	a,b
	mov	r5,a
;	time.c:149: for (month=0; month<12; month++) {
;	genPlus 
	inc	r7
;	did genPlusIncr
;	genGoto 
	ljmp	00113$
;	genLabel 
00116$:
;	time.c:166: lastTime.tm_mon=month;
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0004)
	mov	a,r7
	movx	@dptr,a
;	time.c:167: lastTime.tm_mday=epoch+1;
;	genCast 
;	genPlus 
	inc	r2
;	did genPlusIncr
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x0003)
	mov	a,r2
	movx	@dptr,a
;	time.c:169: lastTime.tm_isdst=0;
;	genPointerSet 
	mov	dptr,#(_lastTime + 0x000a)
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	time.c:171: return &lastTime;
;	genRet 
; Peephole 182b used 24 bit load of DPTR
	mov dptr,#_lastTime
	mov	b,#0x00
;	genLabel 
00117$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'mktime'
;------------------------------------------------------------
;timeptr                   Allocated with name '_mktime_timeptr_1_1'
;year                      Allocated to registers r3 r4 
;month                     Allocated with name '_mktime_month_1_1'
;i                         Allocated to registers 
;seconds                   Allocated with name '_mktime_seconds_1_1'
;sloc0                     Allocated with name '_mktime_sloc0_1_0'
;sloc1                     Allocated with name '_mktime_sloc1_1_0'
;------------------------------------------------------------
;	time.c:175: time_t mktime(struct tm *timeptr) {
;	genFunction 
;	-----------------------------------------
;	 function mktime
;	-----------------------------------------
_mktime:
;	genReceive 
	mov     dps, #1
	mov     dptr, #_mktime_timeptr_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	time.c:176: int year=timeptr->tm_year+1900, month=timeptr->tm_mon, i;
;	genPlus 
	mov	dptr,#_mktime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x05
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
;	genPlus 
	mov	a,#0x6C
	add	a,r6
	mov	r3,a
	mov	a,#0x07
	addc	a,r7
	mov	r4,a
;	genPlus 
	mov	dptr,#_mktime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x04
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r6
	mov	b,r7
	lcall	__gptrget
;	genCast 
; Peephole 100   removed redundant mov
	mov  r0,a
	mov  dptr,#_mktime_month_1_1
	movx @dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	time.c:179: CheckTime(timeptr);
;	genCall 
	push	ar3
	push	ar4
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_mktime_timeptr_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_CheckTime
	pop	ar4
	pop	ar3
;	time.c:182: seconds= (year-1970)*(60*60*24L*365);
;	genMinus 
	mov	a,r3
	add	a,#0x4E
	mov	r0,a
	mov	a,r4
	addc	a,#0xF8
;	genCast 
; Peephole 105   removed redundant mov
	mov  r1,a
	rlc	a
	subb	a,acc
	mov	r6,a
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x33
	movx	@dptr,a
	inc	dptr
	mov	a,#0xE1
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
;	genCall 
	push	ar3
	push	ar4
;	genSend argreg = 1, size = 4 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r6
	mov	b,r7
	lcall	__mullong
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar4
	pop	ar3
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_mktime_seconds_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	time.c:185: for (i=1970; i<year; i++) {
;	genAssign 
	mov	dptr,#_mktime_seconds_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_mktime_sloc0_1_0
	mov	a,#0xB2
	movx	@dptr,a
	inc	dptr
	mov	a,#0x07
	movx	@dptr,a
;	genLabel 
00107$:
;	genCmpLt 
	mov	dptr,#_mktime_sloc0_1_0
;	genCmp
	clr	c
	movx	a,@dptr
	subb	a,r3
	inc	dptr
	movx	a,@dptr
	xrl	a,#0x80
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
	clr	a
	rlc	a
	mov	r2,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_mktime_seconds_1_1
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genIfx 
	mov	a,r2
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00123$
00124$:
;	time.c:186: if (LEAP_YEAR(i)) {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modsint_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	ar0
;	genSend argreg = 1, size = 2 
	inc	dps
	mov	dptr,#_mktime_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
	lcall	__modsint
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
;	genCmpEq 
;	gencjneshort
	mov	a,dpl
; Peephole 132   changed ljmp to sjmp
; Peephole 197   optimized misc jump sequence
	cjne a,#0x00,00109$
	mov  a,dph
	cjne a,#0x00,00109$
;00125$:
; Peephole 200   removed redundant sjmp
00126$:
;	time.c:187: seconds+= 60*60*24L;
;	genPlus 
	mov	a,#0x80
	add	a,r5
	mov	r5,a
	mov	a,#0x51
	addc	a,r6
	mov	r6,a
	mov	a,#0x01
	addc	a,r7
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	mov	r0,a
;	genLabel 
00109$:
;	time.c:185: for (i=1970; i<year; i++) {
;	genPlus 
	mov	dptr,#_mktime_sloc0_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genGoto 
	ljmp	00107$
;	time.c:192: for (i=0; i<month; i++) {
;	genLabel 
00123$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modsint_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 2 
	mov	dpl,r3
	mov	dph,r4
	lcall	__modsint
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,dpl
	cjne	a,#0x00,00127$
	mov	a,dph
	cjne	a,#0x00,00127$
	mov	a,#1
	sjmp	00128$
00127$:
	clr	a
00128$:
	mov	r2,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r3,#0x00
	mov	r4,#0x00
;	genLabel 
00111$:
;	genCmpLt 
	mov	dptr,#_mktime_month_1_1
;	genCmp
	clr	c
	mov	a,r3
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r4
	xrl	a,#0x80
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00129$
	ljmp	00114$
00129$:
;	time.c:193: if (i==1 && LEAP_YEAR(year)) { 
;	genCmpEq 
;	gencjneshort
	mov	a,r3
; Peephole 132   changed ljmp to sjmp
; Peephole 197   optimized misc jump sequence
	cjne a,#0x01,00104$
	mov  a,r4
	cjne a,#0x00,00104$
;00130$:
; Peephole 200   removed redundant sjmp
00131$:
;	genIfx 
	mov	a,r2
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00104$
00132$:
;	time.c:194: seconds+= 60*60*24L*29;
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x80
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x3B
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x26
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00113$
00104$:
;	time.c:196: seconds+= 60*60*24L*monthDays[i];
;	genIpush 
	push	ar2
;	genPlus 
	mov	a,r3
	add	a,#_monthDays
	mov	dpl,a
	mov	a,r4
	addc	a,#(_monthDays >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_monthDays >> 16)
	mov	dpx,a
;	genPointerGet 
	clr	a
	movc	a,@a+dptr
;	genCast 
; Peephole 105   removed redundant mov
	mov  r5,a
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r6,a
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x51
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar3
	push	ar4
;	genSend argreg = 1, size = 4 
	mov	dpl,r5
	mov	dph,r2
	mov	dpx,r6
	mov	b,r7
	lcall	__mullong
	mov	r2,dpl
	mov	r5,dph
	mov	r6,dpx
	mov	r7,b
	pop	ar4
	pop	ar3
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r7
	movx	@dptr,a
;	time.c:204: return seconds;
;	genIpop 
	pop	ar2
;	time.c:196: seconds+= 60*60*24L*monthDays[i];
;	genLabel 
00113$:
;	time.c:192: for (i=0; i<month; i++) {
;	genPlus 
	inc	r3
	cjne	r3,#0,00133$
	inc	r4
00133$:
;	did genPlusIncr
;	genGoto 
	ljmp	00111$
;	genLabel 
00114$:
;	time.c:200: seconds+= (timeptr->tm_mday-1)*60*60*24L;
;	genPlus 
	mov	dptr,#_mktime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x03
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r2,a
;	genCast 
	mov	r3,#0
;	genMinus 
	dec	r2
	cjne	r2,#0xFF,00134$
	dec	r3
00134$:
;	genCast 
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x51
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	time.c:201: seconds+= timeptr->tm_hour*60*60;
;	genPlus 
	mov	dptr,#_mktime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x02
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r2,a
;	genCast 
	mov	r3,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mulint_PARM_2
	mov	a,#0x10
	movx	@dptr,a
	inc	dptr
	mov	a,#0x0E
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	__mulint
	mov	r2,dpl
	mov	r3,dph
;	genCast 
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	time.c:202: seconds+= timeptr->tm_min*60;
;	genPlus 
	mov	dptr,#_mktime_timeptr_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r2,a
;	genMult 
	mov	b,#0x3C
	mov	a,r2
	mul	ab
	mov	r2,a
	mov	r3,b
;	genCast 
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	time.c:203: seconds+= timeptr->tm_sec;
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_mktime_timeptr_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
	mov	r2,a
;	genCast 
	mov	r3,#0
;	genCast 
	mov	a,r3
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genPlus 
	mov	dptr,#_mktime_seconds_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	time.c:204: return seconds;
;	genRet 
	mov     dps, #1
	mov     dptr, #_mktime_seconds_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
;	genLabel 
00115$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
_monthDays:
	.db #0x1F
	.db #0x1C
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
___month:
	.byte _str_1,(_str_1 >> 8),(_str_1 >> 16)
	.byte _str_2,(_str_2 >> 8),(_str_2 >> 16)
	.byte _str_3,(_str_3 >> 8),(_str_3 >> 16)
	.byte _str_4,(_str_4 >> 8),(_str_4 >> 16)
	.byte _str_5,(_str_5 >> 8),(_str_5 >> 16)
	.byte _str_6,(_str_6 >> 8),(_str_6 >> 16)
	.byte _str_7,(_str_7 >> 8),(_str_7 >> 16)
	.byte _str_8,(_str_8 >> 8),(_str_8 >> 16)
	.byte _str_9,(_str_9 >> 8),(_str_9 >> 16)
	.byte _str_10,(_str_10 >> 8),(_str_10 >> 16)
	.byte _str_11,(_str_11 >> 8),(_str_11 >> 16)
	.byte _str_12,(_str_12 >> 8),(_str_12 >> 16)
___day:
	.byte _str_13,(_str_13 >> 8),(_str_13 >> 16)
	.byte _str_14,(_str_14 >> 8),(_str_14 >> 16)
	.byte _str_15,(_str_15 >> 8),(_str_15 >> 16)
	.byte _str_16,(_str_16 >> 8),(_str_16 >> 16)
	.byte _str_17,(_str_17 >> 8),(_str_17 >> 16)
	.byte _str_18,(_str_18 >> 8),(_str_18 >> 16)
	.byte _str_19,(_str_19 >> 8),(_str_19 >> 16)
__str_0:
	.ascii "%s %s %2d %02d:%02d:%02d %04d"
	.db 0x0A
	.db 0x00
_str_1:
	.ascii "Jan"
	.db 0x00
_str_2:
	.ascii "Feb"
	.db 0x00
_str_3:
	.ascii "Mar"
	.db 0x00
_str_4:
	.ascii "Apr"
	.db 0x00
_str_5:
	.ascii "May"
	.db 0x00
_str_6:
	.ascii "Jun"
	.db 0x00
_str_7:
	.ascii "Jul"
	.db 0x00
_str_8:
	.ascii "Aug"
	.db 0x00
_str_9:
	.ascii "Sep"
	.db 0x00
_str_10:
	.ascii "Oct"
	.db 0x00
_str_11:
	.ascii "Nov"
	.db 0x00
_str_12:
	.ascii "Dec"
	.db 0x00
_str_13:
	.ascii "Sun"
	.db 0x00
_str_14:
	.ascii "Mon"
	.db 0x00
_str_15:
	.ascii "Tue"
	.db 0x00
_str_16:
	.ascii "Wed"
	.db 0x00
_str_17:
	.ascii "Thu"
	.db 0x00
_str_18:
	.ascii "Fri"
	.db 0x00
_str_19:
	.ascii "Sat"
	.db 0x00
	.area XINIT   (CODE)
