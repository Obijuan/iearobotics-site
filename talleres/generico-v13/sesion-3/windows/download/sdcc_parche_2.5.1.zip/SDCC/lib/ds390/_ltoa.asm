;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:42 2005
;--------------------------------------------------------
	.module _ltoa
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __ltoa
	.globl __ultoa
	.globl __ltoa_PARM_3
	.globl __ltoa_PARM_2
	.globl __ultoa_PARM_3
	.globl __ultoa_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__ultoa_PARM_2::
	.ds 4
__ultoa_PARM_3::
	.ds 1
__ultoa_buffer_1_1::
	.ds 32
__ultoa_sloc0_1_0::
	.ds 4
__ultoa_sloc1_1_0::
	.ds 1
__ltoa_PARM_2::
	.ds 4
__ltoa_PARM_3::
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_ultoa'
;------------------------------------------------------------
;string                    Allocated with name '__ultoa_PARM_2'
;radix                     Allocated with name '__ultoa_PARM_3'
;value                     Allocated to registers r2 r3 r4 r5 
;index                     Allocated to registers 
;buffer                    Allocated with name '__ultoa_buffer_1_1'
;sloc0                     Allocated with name '__ultoa_sloc0_1_0'
;sloc1                     Allocated with name '__ultoa_sloc1_1_0'
;------------------------------------------------------------
;	_ltoa.c:18: void _ultoa(unsigned long value, char* string, unsigned char radix)
;	genFunction 
;	-----------------------------------------
;	 function _ultoa
;	-----------------------------------------
__ultoa:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_ltoa.c:25: do {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__ultoa_sloc1_1_0
	mov	a,#0x20
	movx	@dptr,a
;	genLabel 
00103$:
;	_ltoa.c:26: buffer[--index] = '0' + (value % radix);
;	genMinus 
	mov	dptr,#__ultoa_sloc1_1_0
	movx	a,@dptr
	dec	a
	movx	@dptr,a
;	genPlus 
	mov	dptr,#__ultoa_sloc1_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#__ultoa_buffer_1_1
	mov	r7,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(__ultoa_buffer_1_1 >> 8)
	mov	r0,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(__ultoa_buffer_1_1 >> 16)
	mov	r1,a
;	genCast 
	mov	dptr,#__ultoa_PARM_3
	mov	dps, #1
	mov	dptr, #__ultoa_sloc0_1_0
	dec	dps
	movx	a,@dptr
	inc	dps
	movx	@dptr,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	mov	dps,#0
;	genAssign 
	mov	dptr,#__ultoa_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#__modulong_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar7
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__modulong
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCast 
	mov	r2,dpl
;	genPlus 
	mov	a,#0x30
	add	a,r2
;	genPointerSet 
; Peephole 136a   removed redundant moves
	mov  r2,a
	mov  dpl,r7
	mov  dph,r0
	mov  dpx,r1
	movx	@dptr,a
;	_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x39
	subb	a,r2
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00115$:
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dpl,r7
	mov	dph,r0
	mov	dpx,r1
	movx	a,@dptr
;	genPlus 
; Peephole 214 reduced some extra movs
;	genPointerSet 
; Peephole 136a   removed redundant moves
; Peephole 215 removed some movs
	add  a,#0x07
	mov  r6,a
	mov  dpl,r7
	mov  dph,r0
	mov  dpx,r1
	movx	@dptr,a
;	_ltoa.c:35: *string = 0;  /* string terminator */
;	genIpop 
;	_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
;	genLabel 
00102$:
;	_ltoa.c:28: value /= radix;
;	genAssign 
	mov	dptr,#__ultoa_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#__divulong_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__divulong
	mov	r7,dpl
	mov	r0,dph
	mov	r1,dpx
	mov	r6,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r7
	mov	ar3,r0
	mov	ar4,r1
	mov	ar5,r6
;	_ltoa.c:29: } while (value != 0);
;	genCmpEq 
;	gencjneshort
	mov	a,r2
	cjne	a,#0x00,00116$
	mov	a,r3
	cjne	a,#0x00,00116$
	mov	a,r4
	cjne	a,#0x00,00116$
	mov	a,r5
	cjne	a,#0x00,00116$
	sjmp	00117$
00116$:
	ljmp	00103$
00117$:
;	_ltoa.c:31: do {
;	genAssign 
	mov	dptr,#__ultoa_sloc1_1_0
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
;	genAssign 
	mov	dptr,#__ultoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genLabel 
00106$:
;	_ltoa.c:32: *string++ = buffer[index++];
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar7,r2
;	genPlus 
	inc	r2
;	did genPlusIncr
;	genPlus 
	mov	a,r7
	add	a,#__ultoa_buffer_1_1
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(__ultoa_buffer_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(__ultoa_buffer_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	movx	a,@dptr
	mov	r7,a
;	genPointerSet 
	mov	dpl,r3
	mov	dph,r4
	mov	dpx,r5
	mov	b,r6
	mov	a,r7
	lcall	__gptrput
	inc	dptr
	mov	r3,dpl
	mov	r4,dph
	mov	r5,dpx
	mov	r6,b
;	_ltoa.c:33: } while ( index < NUMBER_OF_DIGITS );
;	genCmpLt 
;	genCmp
	cjne	r2,#0x20,00118$
00118$:
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00106$
00119$:
;	_ltoa.c:35: *string = 0;  /* string terminator */
;	genPointerSet 
	mov	dpl,r3
	mov	dph,r4
	mov	dpx,r5
	mov	b,r6
; Peephole 180   changed mov to clr
	clr  a
	lcall	__gptrput
;	genLabel 
00109$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_ltoa'
;------------------------------------------------------------
;string                    Allocated with name '__ltoa_PARM_2'
;radix                     Allocated with name '__ltoa_PARM_3'
;value                     Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	_ltoa.c:38: void _ltoa(long value, char* string, unsigned char radix)
;	genFunction 
;	-----------------------------------------
;	 function _ltoa
;	-----------------------------------------
__ltoa:
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_ltoa.c:40: if (value < 0 && radix == 10) {
;	genCmpLt 
;	genCmp
	mov	a,r5
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00102$
00108$:
;	genCmpEq 
	mov	dptr,#__ltoa_PARM_3
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x0A,00102$
;00109$:
; Peephole 200   removed redundant sjmp
00110$:
;	_ltoa.c:41: *string++ = '-';
;	genAssign 
	mov	dptr,#__ltoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,#0x2D
	lcall	__gptrput
;	genPlus 
	mov	dptr,#__ltoa_PARM_2
	mov	a,#0x01
	add	a,r6
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	_ltoa.c:42: value = -value;
;	genUminus 
	clr	c
	clr	a
	subb	a,r2
	mov	r2,a
	clr	a
	subb	a,r3
	mov	r3,a
	clr	a
	subb	a,r4
	mov	r4,a
	clr	a
	subb	a,r5
	mov	r5,a
;	genLabel 
00102$:
;	_ltoa.c:44: _ultoa(value, string, radix);
;	genAssign 
	mov	dptr,#__ltoa_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__ultoa_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genAssign 
	mov	dptr,#__ltoa_PARM_3
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
	mov	dptr,#__ultoa_PARM_3
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__ultoa
;	genLabel 
00104$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
