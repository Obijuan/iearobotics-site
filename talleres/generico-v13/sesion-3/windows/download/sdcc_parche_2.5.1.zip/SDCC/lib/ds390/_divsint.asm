;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:03 2005
;--------------------------------------------------------
	.module _divsint
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divsint_PARM_2
	.globl __divsint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__divsint_PARM_2::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divsint'
;------------------------------------------------------------
;b                         Allocated with name '__divsint_PARM_2'
;a                         Allocated to registers r2 r3 
;r                         Allocated to registers r2 r3 
;------------------------------------------------------------
;	_divsint.c:206: _divsint (int a, int b)
;	genFunction 
;	-----------------------------------------
;	 function _divsint
;	-----------------------------------------
__divsint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
;	_divsint.c:210: r = _divuint((a < 0 ? -a : a),
;	genCmpLt 
;	genCmp
	mov	a,dph
	rlc	a
	clr	a
	rlc	a
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r4,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00113$:
;	genUminus 
	clr	c
	clr	a
	subb	a,dpl
	mov	r5,a
	clr	a
	subb	a,dph
	mov	r6,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00106$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r5,dpl
	mov	r6,dph
;	genLabel 
00107$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl1,r5
	mov	dph1,r6
;	_divsint.c:211: (b < 0 ? -b : b));
;	genCmpLt 
	mov	dptr,#__divsint_PARM_2
;	genCmp
	inc	dptr
	movx	a,@dptr
	rlc	a
	clr	a
	rlc	a
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r5,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00108$
00114$:
;	genUminus 
	mov	dptr,#__divsint_PARM_2
	movx	a,@dptr
	setb	c
	cpl	a
	addc	a,#0
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	mov	r7,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00108$:
;	genAssign 
	mov	dptr,#__divsint_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genLabel 
00109$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divuint_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genCall 
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 2 
	mov	dpl,dpl1
	mov	dph,dph1
	lcall	__divuint
	mov	r2,dpl
	mov	r3,dph
	pop	ar5
	pop	ar4
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,r2
	mov	dph,r3
;	_divsint.c:212: if ( (a < 0) ^ (b < 0))
;	genXor 
	mov	a,r4
	xrl	a,r5
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00115$:
;	_divsint.c:213: return -r;
;	genUminus 
	clr	c
	clr	a
	subb	a,dpl
	mov	dpl1,a
	clr	a
	subb	a,dph
	mov	dph1,a
;	genRet 
	mov	dpl,dpl1
	mov	dph,dph1
;	genLabel 
; Peephole 132   changed ljmp to sjmp
;	_divsint.c:215: return r;
;	genRet 
;	genLabel 
; Peephole 201   removed redundant sjmp
00102$:
00104$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
