;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:03 2005
;--------------------------------------------------------
	.module _divslong
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divslong_PARM_2
	.globl __divslong_PARM_1
	.globl __divslong
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
__divslong_sloc0_1_0::
	.ds 4
__divslong_sloc1_1_0::
	.ds 4
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__divslong_PARM_1::
	.ds 4
__divslong_PARM_2::
	.ds 4
__divslong_r_1_1::
	.ds 4
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divslong'
;------------------------------------------------------------
;sloc0                     Allocated with name '__divslong_sloc0_1_0'
;sloc1                     Allocated with name '__divslong_sloc1_1_0'
;a                         Allocated with name '__divslong_PARM_1'
;b                         Allocated with name '__divslong_PARM_2'
;r                         Allocated with name '__divslong_r_1_1'
;------------------------------------------------------------
;_divslong.c:257: _divslong (long a, long b)
;	-----------------------------------------
;	 function _divslong
;	-----------------------------------------
__divslong:
;_divslong.c:261: r = _divulong((a < 0 ? -a : a),
	lda	__divslong_PARM_1
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00106$
00113$:
	clra
	sub	(__divslong_PARM_1 + 3)
	sta	*(__divslong_sloc0_1_0 + 3)
	clra
	sbc	(__divslong_PARM_1 + 2)
	sta	*(__divslong_sloc0_1_0 + 2)
	clra
	sbc	(__divslong_PARM_1 + 1)
	sta	*(__divslong_sloc0_1_0 + 1)
	clra
	sbc	__divslong_PARM_1
	sta	*__divslong_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00107$
00106$:
	lda	__divslong_PARM_1
	sta	*__divslong_sloc0_1_0
	lda	(__divslong_PARM_1 + 1)
	sta	*(__divslong_sloc0_1_0 + 1)
	lda	(__divslong_PARM_1 + 2)
	sta	*(__divslong_sloc0_1_0 + 2)
	lda	(__divslong_PARM_1 + 3)
	sta	*(__divslong_sloc0_1_0 + 3)
00107$:
;_divslong.c:262: (b < 0 ? -b : b));
	lda	__divslong_PARM_2
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00108$
00114$:
	clra
	sub	(__divslong_PARM_2 + 3)
	sta	*(__divslong_sloc1_1_0 + 3)
	clra
	sbc	(__divslong_PARM_2 + 2)
	sta	*(__divslong_sloc1_1_0 + 2)
	clra
	sbc	(__divslong_PARM_2 + 1)
	sta	*(__divslong_sloc1_1_0 + 1)
	clra
	sbc	__divslong_PARM_2
	sta	*__divslong_sloc1_1_0
; Peephole 3	- shortened jmp to bra
	bra	00109$
00108$:
	lda	__divslong_PARM_2
	sta	*__divslong_sloc1_1_0
	lda	(__divslong_PARM_2 + 1)
	sta	*(__divslong_sloc1_1_0 + 1)
	lda	(__divslong_PARM_2 + 2)
	sta	*(__divslong_sloc1_1_0 + 2)
	lda	(__divslong_PARM_2 + 3)
	sta	*(__divslong_sloc1_1_0 + 3)
00109$:
	lda	*__divslong_sloc0_1_0
	sta	__divulong_PARM_1
	lda	*(__divslong_sloc0_1_0 + 1)
	sta	(__divulong_PARM_1 + 1)
	lda	*(__divslong_sloc0_1_0 + 2)
	sta	(__divulong_PARM_1 + 2)
	lda	*(__divslong_sloc0_1_0 + 3)
	sta	(__divulong_PARM_1 + 3)
	lda	*__divslong_sloc1_1_0
	sta	__divulong_PARM_2
	lda	*(__divslong_sloc1_1_0 + 1)
	sta	(__divulong_PARM_2 + 1)
	lda	*(__divslong_sloc1_1_0 + 2)
	sta	(__divulong_PARM_2 + 2)
	lda	*(__divslong_sloc1_1_0 + 3)
	sta	(__divulong_PARM_2 + 3)
	jsr	__divulong
	sta	(__divslong_r_1_1 + 3)
	stx	(__divslong_r_1_1 + 2)
	lda	*__ret2
	sta	(__divslong_r_1_1 + 1)
	lda	*__ret3
	sta	__divslong_r_1_1
;_divslong.c:263: if ( (a < 0) ^ (b < 0))
	lda	__divslong_PARM_1
	sub	#0x00
	blt	00115$
	clra
	bra	00116$
00115$:
	lda	#0x01
00116$:
	sta	*__divslong_sloc1_1_0
	lda	__divslong_PARM_2
	sub	#0x00
	blt	00117$
	clra
	bra	00118$
00117$:
	lda	#0x01
00118$:
	eor	*__divslong_sloc1_1_0
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00119$:
;_divslong.c:264: return -r;
	clra
	sub	(__divslong_r_1_1 + 3)
	sta	*(__divslong_sloc1_1_0 + 3)
	clra
	sbc	(__divslong_r_1_1 + 2)
	sta	*(__divslong_sloc1_1_0 + 2)
	clra
	sbc	(__divslong_r_1_1 + 1)
	sta	*(__divslong_sloc1_1_0 + 1)
	clra
	sbc	__divslong_r_1_1
	sta	*__divslong_sloc1_1_0
	mov	*__divslong_sloc1_1_0,*__ret3
	mov	*(__divslong_sloc1_1_0 + 1),*__ret2
	ldx	*(__divslong_sloc1_1_0 + 2)
	lda	*(__divslong_sloc1_1_0 + 3)
; Peephole 3	- shortened jmp to bra
; Peephole 6b  - replaced jmp to rts with rts
	rts
00102$:
;_divslong.c:266: return r;
	lda	__divslong_r_1_1
	sta	*__ret3
	lda	(__divslong_r_1_1 + 1)
	sta	*__ret2
	ldx	(__divslong_r_1_1 + 2)
	lda	(__divslong_r_1_1 + 3)
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
