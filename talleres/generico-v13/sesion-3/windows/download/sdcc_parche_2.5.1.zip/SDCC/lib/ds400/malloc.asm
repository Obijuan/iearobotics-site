;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:36 2005
;--------------------------------------------------------
	.module malloc
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _init_dynamic_memory_PARM_2
	.globl __sdcc_first_memheader
	.globl _init_dynamic_memory
	.globl _malloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__sdcc_first_memheader::
	.ds 3
_init_dynamic_memory_PARM_2::
	.ds 2
_malloc_size_1_1::
	.ds 2
_malloc_current_header_1_1::
	.ds 3
_malloc_new_header_1_1::
	.ds 3
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'init_dynamic_memory'
;------------------------------------------------------------
;size                      Allocated with name '_init_dynamic_memory_PARM_2'
;heap                      Allocated to registers r2 r3 r4 
;array                     Allocated to registers r5 r6 r7 
;------------------------------------------------------------
;	malloc.c:146: void init_dynamic_memory(void xdata * heap, unsigned int size)
;	genFunction 
;	-----------------------------------------
;	 function init_dynamic_memory
;	-----------------------------------------
_init_dynamic_memory:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
;	malloc.c:167: char xdata * array = (char xdata *)heap;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dpl1,dpl
	mov	dph1,dph
	mov	dpx1,dpx
;	malloc.c:169: if ( !array ) //Reserved memory starts at 0x0000 but that's NULL...
;	genIfx 
	mov	a,dpl
	orl	a,dph
	orl	a,dpx
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00106$:
;	malloc.c:171: array++;
;	genPlus 
	mov	a,#0x01
	add	a,dpl
	mov	dpl1,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,dph
	mov	dph1,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,dpx
	mov	dpx1,a
;	malloc.c:172: size--;
;	genAssign 
	mov	dptr,#_init_dynamic_memory_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genMinus 
	dec	r2
	cjne	r2,#0xFF,00107$
	dec	r3
00107$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_init_dynamic_memory_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genLabel 
00102$:
;	malloc.c:174: _sdcc_first_memheader = (MEMHEADER xdata * ) array;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__sdcc_first_memheader
	mov	a,dpl1
	movx	@dptr,a
	inc	dptr
	mov	a,dph1
	movx	@dptr,a
	inc	dptr
	mov	a,dpx1
	movx	@dptr,a
;	malloc.c:176: _sdcc_first_memheader->next = (MEMHEADER xdata * )(array + size - sizeof(MEMHEADER xdata *));
;	genPlus 
	mov	dptr,#_init_dynamic_memory_PARM_2
	movx	a,@dptr
	add	a,dpl1
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,dph1
	mov	r3,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,dpx1
	mov	r4,a
;	genMinus 
	mov	a,r2
	add	a,#0xFD
	mov	r2,a
	mov	a,r3
	addc	a,#0xFF
	mov	r3,a
	mov	a,r4
	addc	a,#0xFF
	mov	r4,a
;	genPointerSet 
	mov	a,r2
	inc	dps
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	lcall	__decdptr
	lcall	__decdptr
	mov	dps,#0
;	malloc.c:177: _sdcc_first_memheader->next->next = (MEMHEADER xdata * ) NULL; //And mark it as last
;	genCast 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
;	genPointerSet 
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	malloc.c:178: _sdcc_first_memheader->len        = 0;    //Empty and ready.
;	genPlus 
	mov	dpx,dpx1
	mov	dph,dph1
	mov	dpl,dpl1
	inc	dptr
	inc	dptr
	inc	dptr
;	did genPlusIncr
;	genPointerSet 
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genLabel 
00103$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'malloc'
;------------------------------------------------------------
;size                      Allocated with name '_malloc_size_1_1'
;current_header            Allocated with name '_malloc_current_header_1_1'
;new_header                Allocated with name '_malloc_new_header_1_1'
;ret                       Allocated to registers r2 r3 r4 
;------------------------------------------------------------
;	malloc.c:181: void xdata * malloc (unsigned int size)
;	genFunction 
;	-----------------------------------------
;	 function malloc
;	-----------------------------------------
_malloc:
;	genReceive 
	mov     dps, #1
	mov     dptr, #_malloc_size_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	mov	dps,#0
;	malloc.c:187: if (size>(0xFFFF-HEADER_SIZE)) return (void xdata *) NULL; //To prevent overflow in next line
;	genCmpGt 
	mov	dptr,#_malloc_size_1_1
;	genCmp
	clr	c
	mov	a,#0xFA
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,#0xFF
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00102$
00123$:
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	ljmp	00115$
;	genLabel 
00102$:
;	malloc.c:188: size += HEADER_SIZE; //We need a memory for header too
;	genPlus 
	mov	dptr,#_malloc_size_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x05
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	malloc.c:189: current_header = _sdcc_first_memheader;
;	genAssign 
	mov	dptr,#__sdcc_first_memheader
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_malloc_current_header_1_1
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	malloc.c:192: while (1)
;	genLabel 
00108$:
;	malloc.c:202: if ((((unsigned int)current_header->next) -
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_malloc_current_header_1_1
;	genFarPointerGet -- indirection special case.
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	pop	dph
	pop	dpl
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
;	genCast 
	mov	ar2,r7
	mov	ar3,r0
;	malloc.c:203: ((unsigned int)current_header) -
;	genAssign 
	mov	dptr,#_malloc_current_header_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genCast 
;	genMinus 
	clr	c
	mov	a,r2
	subb	a,r4
	mov	r2,a
	mov	a,r3
	subb	a,r5
	mov	r3,a
;	malloc.c:204: current_header->len) >= size)
;	genPlus 
	mov	dptr,#_malloc_current_header_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x03
	mov	dpl1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dph1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dpx1,a
;	genPointerGet 
;	genFarPointerGet
	inc	dps
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	lcall	__decdptr
	mov	dps,#0
;	genMinus 
	clr	c
	mov	a,r2
	subb	a,r4
	mov	r2,a
	mov	a,r3
	subb	a,r5
	mov	r3,a
;	genCmpLt 
	mov	dptr,#_malloc_size_1_1
;	genCmp
	clr	c
	mov	a,r2
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r3
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00104$
00124$:
;	malloc.c:206: ret = current_header->mem;
;	genPlus 
	mov	dptr,#_malloc_current_header_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x05
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
;	malloc.c:207: break;
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00104$:
;	malloc.c:209: current_header = current_header->next;    //else try next
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_malloc_current_header_1_1
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	malloc.c:210: if (!current_header->next)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_malloc_current_header_1_1
;	genFarPointerGet -- indirection special case.
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	pop	dph
	pop	dpl
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	mov	r7,a
;	genIfx 
	mov	a,r5
	orl	a,r6
	orl	a,r7
;	genIfxJump
	jz	00125$
	ljmp	00108$
00125$:
;	malloc.c:212: ret = (void xdata *) NULL;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
;	malloc.c:213: break;
;	genLabel 
00109$:
;	malloc.c:216: if (ret)
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r4
;	genIfxJump
	jnz	00126$
	ljmp	00114$
00126$:
;	malloc.c:218: if (!current_header->len)
;	genPlus 
	mov	dptr,#_malloc_current_header_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x03
	mov	dpl1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dph1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dpx1,a
;	genPointerGet 
;	genFarPointerGet
	inc	dps
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	lcall	__decdptr
	mov	dps,#0
;	genIfx 
	mov	a,r0
	orl	a,r1
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00111$
00127$:
;	malloc.c:220: current_header->len = size; //for first allocation
;	genPointerSet 
	mov	dptr,#_malloc_size_1_1
	movx	a,@dptr
	mov	dps,#1
	movx	@dptr,a
	inc	dptr
	mov	dps,#0
	inc	dptr
	movx	a,@dptr
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genGoto 
	ljmp	00114$
;	genLabel 
00111$:
;	malloc.c:224: new_header = (MEMHEADER xdata * )((char xdata *)current_header + current_header->len);
;	genPlus 
	mov	dptr,#_malloc_current_header_1_1
	mov	dps, #1
	mov	dptr, #_malloc_new_header_1_1
	dec	dps
;	Swapped plus args.
	movx	a,@dptr
	add	a,r0
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	addc	a,r1
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	malloc.c:225: new_header->next = current_header->next; //and plug it into the chain
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_malloc_current_header_1_1
;	genFarPointerGet -- indirection special case.
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	pop	dph
	pop	dpl
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	mov	r5,a
;	genPointerSet 
	mov	dptr,#_malloc_new_header_1_1
;	genFarPointerSet -- indirection special case.
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	pop	dph
	pop	dpl
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	malloc.c:226: current_header->next  = new_header;
;	genPointerSet 
	mov	dptr,#_malloc_current_header_1_1
;	genFarPointerSet -- indirection special case.
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	pop	dph
	pop	dpl
	mov     dps, #1
	mov     dptr, #_malloc_new_header_1_1
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
;	malloc.c:227: new_header->len  = size; //mark as used
;	genPlus 
	mov	dptr,#_malloc_new_header_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x03
	mov	dpl1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dph1,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	dpx1,a
;	genPointerSet 
	mov	dptr,#_malloc_size_1_1
	movx	a,@dptr
	mov	dps,#1
	movx	@dptr,a
	inc	dptr
	mov	dps,#0
	inc	dptr
	movx	a,@dptr
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	malloc.c:228: ret = new_header->mem;
;	genPlus 
	mov	dptr,#_malloc_new_header_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x05
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r4,a
;	genLabel 
00114$:
;	malloc.c:232: return ret;
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
;	genLabel 
00115$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
