;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:47 2005
;--------------------------------------------------------
	.module _memmove
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memmove_PARM_3
	.globl _memmove_PARM_2
	.globl _memmove
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_memmove_PARM_2::
	.ds 4
_memmove_PARM_3::
	.ds 2
_memmove_dst_1_1::
	.ds 4
_memmove_ret_1_1::
	.ds 4
_memmove_d_1_1::
	.ds 4
_memmove_sloc0_1_0::
	.ds 2
_memmove_sloc1_1_0::
	.ds 4
_memmove_sloc2_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'memmove'
;------------------------------------------------------------
;src                       Allocated with name '_memmove_PARM_2'
;acount                    Allocated with name '_memmove_PARM_3'
;dst                       Allocated with name '_memmove_dst_1_1'
;ret                       Allocated with name '_memmove_ret_1_1'
;d                         Allocated with name '_memmove_d_1_1'
;s                         Allocated to registers r6 r7 r0 r1 
;sloc0                     Allocated with name '_memmove_sloc0_1_0'
;sloc1                     Allocated with name '_memmove_sloc1_1_0'
;sloc2                     Allocated with name '_memmove_sloc2_1_0'
;------------------------------------------------------------
;	_memmove.c:35: void * memmove (
;	genFunction 
;	-----------------------------------------
;	 function memmove
;	-----------------------------------------
_memmove:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_memmove_dst_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	_memmove.c:96: void * ret = dst;
;	genAssign 
	mov	dptr,#_memmove_dst_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_memmove_ret_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	_memmove.c:100: if (((int)src < (int)dst) && ((((int)src)+acount) > (int)dst)) {
;	genAssign 
	mov	dptr,#_memmove_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genCast 
	mov	dptr,#_memmove_sloc0_1_0
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genAssign 
	mov	dptr,#_memmove_dst_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genCast 
;	genCmpLt 
	mov	dptr,#_memmove_sloc0_1_0
;	genCmp
	clr	c
	movx	a,@dptr
	subb	a,r0
	inc	dptr
	movx	a,@dptr
	xrl	a,#0x80
	mov	b,r1
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00119$
	ljmp	00108$
00119$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r2
	mov	ar7,r3
	mov	ar0,r4
	mov	ar1,r5
;	genCast 
;	genPlus 
	mov	dptr,#_memmove_PARM_3
	movx	a,@dptr
	add	a,r6
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,r7
	mov	r7,a
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genAssign 
	mov	dptr,#_memmove_dst_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genCast 
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r0
	subb	a,r6
	mov	a,r1
	subb	a,r7
	clr	a
	rlc	a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
;	genIfxJump
	jnz	00120$
	ljmp	00108$
00120$:
;	_memmove.c:104: d = ((char *)dst)+acount-1;
;	genPlus 
	mov	dptr,#_memmove_PARM_3
	mov	dps, #1
	mov	dptr, #_memmove_dst_1_1
	dec	dps
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	movx	a,@dptr
	xch	a, _ap
	add	a,_ap
	mov	r6,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	addc	a,_ap
	mov	r7,a
; Peephole 3.d   changed mov to clr
	clr	a
	xch	a, _ap
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	addc	a,_ap
	mov	r0,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	mov	r1,a
;	genMinus 
	dec	r6
	cjne	r6,#0xFF,00121$
	dec	r7
	cjne	r7,#0xFF,00121$
	dec	r0
00121$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_memmove_d_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	_memmove.c:105: s = ((char *)src)+acount-1;
;	genPlus 
	mov	dptr,#_memmove_PARM_3
	movx	a,@dptr
	add	a,r2
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	mov	r7,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genMinus 
	dec	r6
	cjne	r6,#0xFF,00122$
	dec	r7
	cjne	r7,#0xFF,00122$
	dec	r0
00122$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	_memmove.c:106: while (acount--) {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_memmove_sloc2_1_0
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genAssign 
	mov	dptr,#_memmove_d_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genAssign 
	mov	dptr,#_memmove_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genLabel 
00101$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r2
	mov	ar7,r3
;	genMinus 
	dec	r2
	cjne	r2,#0xFF,00123$
	dec	r3
00123$:
;	genIfx 
	mov	a,r6
	orl	a,r7
;	genIfxJump
	jnz	00124$
	ljmp	00109$
00124$:
;	_memmove.c:107: *d-- = *s--;
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_memmove_sloc2_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
	mov	r6,a
;	genMinus 
	mov	dptr,#_memmove_sloc2_1_0
	movx	a,@dptr
	add	a,#0xFF
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genPointerSet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r0
	mov	b,r1
	mov	a,r6
	lcall	__gptrput
;	genMinus 
	dec	r4
	cjne	r4,#0xFF,00125$
	dec	r5
	cjne	r5,#0xFF,00125$
	dec	r0
00125$:
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00101$
00108$:
;	_memmove.c:115: s = src;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r2
	mov	ar7,r3
	mov	ar0,r4
	mov	ar1,r5
;	_memmove.c:116: while (acount--) {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_memmove_sloc1_1_0
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genAssign 
	mov	dptr,#_memmove_dst_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genAssign 
	mov	dptr,#_memmove_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00104$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r4
	mov	ar3,r5
;	genMinus 
	dec	r4
	cjne	r4,#0xFF,00126$
	dec	r5
00126$:
;	genIfx 
	mov	a,r2
	orl	a,r3
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00109$
00127$:
;	_memmove.c:117: *d++ = *s++;
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_memmove_sloc1_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	inc	dps
	lcall	__decdptr
	lcall	__decdptr
	lcall	__decdptr
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	a,r2
	lcall	__gptrput
	inc	dptr
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00104$
00109$:
;	_memmove.c:121: return(ret);
;	genRet 
	mov     dps, #1
	mov     dptr, #_memmove_ret_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
;	genLabel 
00111$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
