;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:56:10 2005
;--------------------------------------------------------
	.module cotf
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _cotf
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'cotf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 2
;y                         Allocated to registers 
;sloc0                     Allocated to stack - offset -4
;------------------------------------------------------------
;cotf.c:26: float cotf(const float x) _FLOAT_FUNC_REENTRANT
;	-----------------------------------------
;	 function cotf
;	-----------------------------------------
_cotf:
	ais	#-4
;cotf.c:30: y=fabsf(x);
	lda	10,s
	psha
	lda	10,s
	psha
	lda	10,s
	psha
	lda	10,s
	psha
	jsr	_fabsf
	sta	(___fslt_PARM_1 + 3)
	stx	(___fslt_PARM_1 + 2)
	lda	*__ret2
	sta	(___fslt_PARM_1 + 1)
	lda	*__ret3
	sta	___fslt_PARM_1
	ais	#4
;cotf.c:31: if (y<1.0E-30) //This one requires more thinking...
	lda	#0x0D
	sta	___fslt_PARM_2
	lda	#0xA2
	sta	(___fslt_PARM_2 + 1)
	lda	#0x42
	sta	(___fslt_PARM_2 + 2)
	lda	#0x60
	sta	(___fslt_PARM_2 + 3)
	jsr	___fslt
	tsta
; Peephole 2d	- eliminated jmp
	beq	00105$
00110$:
;cotf.c:33: errno = ERANGE;
	clra
	sta	_errno
	lda	#0x22
	sta	(_errno + 1)
;cotf.c:34: if (x<0.0)
	lda	7,s
	sta	___fslt_PARM_1
	lda	8,s
	sta	(___fslt_PARM_1 + 1)
	lda	9,s
	sta	(___fslt_PARM_1 + 2)
	lda	10,s
	sta	(___fslt_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fslt_PARM_2
	sta	(___fslt_PARM_2 + 1)
	sta	(___fslt_PARM_2 + 2)
	sta	(___fslt_PARM_2 + 3)
	jsr	___fslt
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00111$:
;cotf.c:35: return -XMAX;
	clr	*__ret3
	clr	*__ret2
	ldx	#0xFF
	lda	#0xFF
; Peephole 3	- shortened jmp to bra
	bra	00106$
00102$:
;cotf.c:37: return XMAX;
	clr	*__ret3
	clr	*__ret2
	ldx	#0xFF
	lda	#0xFF
; Peephole 3	- shortened jmp to bra
	bra	00106$
00105$:
;cotf.c:39: return tancotf(x, 1);
	lda	7,s
	sta	_tancotf_PARM_1
	lda	8,s
	sta	(_tancotf_PARM_1 + 1)
	lda	9,s
	sta	(_tancotf_PARM_1 + 2)
	lda	10,s
	sta	(_tancotf_PARM_1 + 3)
	clra
	sta	_tancotf_PARM_2
	lda	#0x01
	sta	(_tancotf_PARM_2 + 1)
	jsr	_tancotf
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	*__ret3
	lda	2,s
	sta	*__ret2
	ldx	3,s
	lda	4,s
00106$:
	ais	#4
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
