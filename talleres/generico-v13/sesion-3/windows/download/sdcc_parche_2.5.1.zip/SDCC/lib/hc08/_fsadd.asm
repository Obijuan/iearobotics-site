;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:09 2005
;--------------------------------------------------------
	.module _fsadd
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsadd_PARM_2
	.globl ___fsadd_PARM_1
	.globl ___fsadd
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area	OSEG    (OVR)
___fsadd_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
___fsadd_PARM_1::
	.ds 4
___fsadd_PARM_2::
	.ds 4
___fsadd_mant1_1_1::
	.ds 4
___fsadd_mant2_1_1::
	.ds 4
___fsadd_fl1_1_1::
	.ds 4
___fsadd_fl2_1_1::
	.ds 4
___fsadd_exp1_1_1::
	.ds 2
___fsadd_exp2_1_1::
	.ds 2
___fsadd_sign_1_1::
	.ds 4
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsadd'
;------------------------------------------------------------
;a1                        Allocated with name '___fsadd_PARM_1'
;a2                        Allocated with name '___fsadd_PARM_2'
;mant1                     Allocated with name '___fsadd_mant1_1_1'
;mant2                     Allocated with name '___fsadd_mant2_1_1'
;fl1                       Allocated with name '___fsadd_fl1_1_1'
;fl2                       Allocated with name '___fsadd_fl2_1_1'
;exp1                      Allocated with name '___fsadd_exp1_1_1'
;exp2                      Allocated with name '___fsadd_exp2_1_1'
;sign                      Allocated with name '___fsadd_sign_1_1'
;sloc0                     Allocated with name '___fsadd_sloc0_1_0'
;------------------------------------------------------------
;_fsadd.c:161: float __fsadd (float a1, float a2)
;	-----------------------------------------
;	 function __fsadd
;	-----------------------------------------
___fsadd:
;_fsadd.c:166: volatile unsigned long sign = 0;
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fsadd_sign_1_1
	sta	(___fsadd_sign_1_1 + 1)
	sta	(___fsadd_sign_1_1 + 2)
	sta	(___fsadd_sign_1_1 + 3)
;_fsadd.c:168: fl1.f = a1;
	lda	___fsadd_PARM_1
	sta	___fsadd_fl1_1_1
	lda	(___fsadd_PARM_1 + 1)
	sta	(___fsadd_fl1_1_1 + 1)
	lda	(___fsadd_PARM_1 + 2)
	sta	(___fsadd_fl1_1_1 + 2)
	lda	(___fsadd_PARM_1 + 3)
	sta	(___fsadd_fl1_1_1 + 3)
;_fsadd.c:169: fl2.f = a2;
	lda	___fsadd_PARM_2
	sta	___fsadd_fl2_1_1
	lda	(___fsadd_PARM_2 + 1)
	sta	(___fsadd_fl2_1_1 + 1)
	lda	(___fsadd_PARM_2 + 2)
	sta	(___fsadd_fl2_1_1 + 2)
	lda	(___fsadd_PARM_2 + 3)
	sta	(___fsadd_fl2_1_1 + 3)
;_fsadd.c:172: if (!fl1.l)
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 3)
	ora	*(___fsadd_sloc0_1_0 + 2)
	ora	*(___fsadd_sloc0_1_0 + 1)
	ora	*___fsadd_sloc0_1_0
; Peephole 2c	- eliminated jmp
	bne	00102$
00145$:
;_fsadd.c:173: return (fl2.f);
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	mov	*___fsadd_sloc0_1_0,*__ret3
	mov	*(___fsadd_sloc0_1_0 + 1),*__ret2
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
; Peephole 6a  - replaced jmp to rts with rts
	rts
00102$:
;_fsadd.c:174: if (!fl2.l)
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 3)
	ora	*(___fsadd_sloc0_1_0 + 2)
	ora	*(___fsadd_sloc0_1_0 + 1)
	ora	*___fsadd_sloc0_1_0
; Peephole 2c	- eliminated jmp
	bne	00104$
00146$:
;_fsadd.c:175: return (fl1.f);
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	mov	*___fsadd_sloc0_1_0,*__ret3
	mov	*(___fsadd_sloc0_1_0 + 1),*__ret2
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
; Peephole 6a  - replaced jmp to rts with rts
	rts
00104$:
;_fsadd.c:177: exp1 = EXP (fl1.l);
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 1)
	ldx	*___fsadd_sloc0_1_0
	lsla
	txa
	rola
	clrx
	rolx
	sta	*(___fsadd_sloc0_1_0 + 3)
	stx	*(___fsadd_sloc0_1_0 + 2)
	clr	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	clr	*(___fsadd_sloc0_1_0 + 2)
	clr	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	sta	(___fsadd_exp1_1_1 + 1)
	lda	*(___fsadd_sloc0_1_0 + 2)
	sta	___fsadd_exp1_1_1
;_fsadd.c:178: exp2 = EXP (fl2.l);
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 1)
	ldx	*___fsadd_sloc0_1_0
	lsla
	txa
	rola
	clrx
	rolx
	sta	*(___fsadd_sloc0_1_0 + 3)
	stx	*(___fsadd_sloc0_1_0 + 2)
	clr	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	clr	*(___fsadd_sloc0_1_0 + 2)
	clr	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	sta	(___fsadd_exp2_1_1 + 1)
	lda	*(___fsadd_sloc0_1_0 + 2)
	sta	___fsadd_exp2_1_1
;_fsadd.c:180: if (exp1 > exp2 + 25)
	lda	(___fsadd_exp2_1_1 + 1)
	add	#0x19
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	___fsadd_exp2_1_1
	adc	#0x00
	sta	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 1)
	sub	(___fsadd_exp1_1_1 + 1)
	lda	*___fsadd_sloc0_1_0
	sbc	___fsadd_exp1_1_1
; Peephole 2l	- eliminated bra
	bge	00106$
00147$:
;_fsadd.c:181: return (fl1.f);
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	mov	*___fsadd_sloc0_1_0,*__ret3
	mov	*(___fsadd_sloc0_1_0 + 1),*__ret2
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
; Peephole 6a  - replaced jmp to rts with rts
	rts
00106$:
;_fsadd.c:182: if (exp2 > exp1 + 25)
	lda	(___fsadd_exp1_1_1 + 1)
	add	#0x19
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	___fsadd_exp1_1_1
	adc	#0x00
	sta	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 1)
	sub	(___fsadd_exp2_1_1 + 1)
	lda	*___fsadd_sloc0_1_0
	sbc	___fsadd_exp2_1_1
; Peephole 2l	- eliminated bra
	bge	00108$
00148$:
;_fsadd.c:183: return (fl2.f);
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	mov	*___fsadd_sloc0_1_0,*__ret3
	mov	*(___fsadd_sloc0_1_0 + 1),*__ret2
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
; Peephole 6a  - replaced jmp to rts with rts
	rts
00108$:
;_fsadd.c:185: mant1 = MANT (fl1.l);
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 1)
	and	#0x7F
	sta	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
	lda	*(___fsadd_sloc0_1_0 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	lda	*(___fsadd_sloc0_1_0 + 1)
	ora	#0x80
	sta	(___fsadd_mant1_1_1 + 1)
	lda	*___fsadd_sloc0_1_0
	sta	___fsadd_mant1_1_1
;_fsadd.c:186: mant2 = MANT (fl2.l);
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 1)
	and	#0x7F
	sta	*(___fsadd_sloc0_1_0 + 1)
	clr	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	sta	(___fsadd_mant2_1_1 + 3)
	lda	*(___fsadd_sloc0_1_0 + 2)
	sta	(___fsadd_mant2_1_1 + 2)
	lda	*(___fsadd_sloc0_1_0 + 1)
	ora	#0x80
	sta	(___fsadd_mant2_1_1 + 1)
	lda	*___fsadd_sloc0_1_0
	sta	___fsadd_mant2_1_1
;_fsadd.c:188: if (SIGN (fl1.l))
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*___fsadd_sloc0_1_0
	rola
	clra
	rola
	tsta
; Peephole 2d	- eliminated jmp
	beq	00110$
00149$:
;_fsadd.c:189: mant1 = -mant1;
	clra
	sub	(___fsadd_mant1_1_1 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
	clra
	sbc	(___fsadd_mant1_1_1 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	clra
	sbc	(___fsadd_mant1_1_1 + 1)
	sta	(___fsadd_mant1_1_1 + 1)
	clra
	sbc	___fsadd_mant1_1_1
	sta	___fsadd_mant1_1_1
00110$:
;_fsadd.c:190: if (SIGN (fl2.l))
	lda	___fsadd_fl2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl2_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl2_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*___fsadd_sloc0_1_0
	rola
	clra
	rola
	tsta
; Peephole 2d	- eliminated jmp
	beq	00112$
00150$:
;_fsadd.c:191: mant2 = -mant2;
	clra
	sub	(___fsadd_mant2_1_1 + 3)
	sta	(___fsadd_mant2_1_1 + 3)
	clra
	sbc	(___fsadd_mant2_1_1 + 2)
	sta	(___fsadd_mant2_1_1 + 2)
	clra
	sbc	(___fsadd_mant2_1_1 + 1)
	sta	(___fsadd_mant2_1_1 + 1)
	clra
	sbc	___fsadd_mant2_1_1
	sta	___fsadd_mant2_1_1
00112$:
;_fsadd.c:193: if (exp1 > exp2)
	lda	(___fsadd_exp2_1_1 + 1)
	sub	(___fsadd_exp1_1_1 + 1)
	lda	___fsadd_exp2_1_1
	sbc	___fsadd_exp1_1_1
; Peephole 2l	- eliminated bra
	bge	00114$
00151$:
;_fsadd.c:195: mant2 >>= exp1 - exp2;
	lda	(___fsadd_exp1_1_1 + 1)
	sub	(___fsadd_exp2_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	___fsadd_exp1_1_1
	sbc	___fsadd_exp2_1_1
	sta	*___fsadd_sloc0_1_0
	lda	___fsadd_mant2_1_1
	sta	___fsadd_mant2_1_1
	lda	(___fsadd_mant2_1_1 + 1)
	sta	(___fsadd_mant2_1_1 + 1)
	lda	(___fsadd_mant2_1_1 + 2)
	sta	(___fsadd_mant2_1_1 + 2)
	lda	(___fsadd_mant2_1_1 + 3)
	sta	(___fsadd_mant2_1_1 + 3)
; Peephole 4c	- eliminated redundant tstx
	ldx	*(___fsadd_sloc0_1_0 + 1)
	beq	00153$
00152$:
	lda	___fsadd_mant2_1_1
	asra
	sta	___fsadd_mant2_1_1
	lda	(___fsadd_mant2_1_1 + 1)
	rora
	sta	(___fsadd_mant2_1_1 + 1)
	lda	(___fsadd_mant2_1_1 + 2)
	rora
	sta	(___fsadd_mant2_1_1 + 2)
	lda	(___fsadd_mant2_1_1 + 3)
	rora
	sta	(___fsadd_mant2_1_1 + 3)
	decx
	bne	00152$
00153$:
; Peephole 3	- shortened jmp to bra
	bra	00115$
00114$:
;_fsadd.c:199: mant1 >>= exp2 - exp1;
	lda	(___fsadd_exp2_1_1 + 1)
	sub	(___fsadd_exp1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	___fsadd_exp2_1_1
	sbc	___fsadd_exp1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	___fsadd_mant1_1_1
	sta	___fsadd_mant1_1_1
	lda	(___fsadd_mant1_1_1 + 1)
	sta	(___fsadd_mant1_1_1 + 1)
	lda	(___fsadd_mant1_1_1 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	lda	(___fsadd_mant1_1_1 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
; Peephole 4c	- eliminated redundant tstx
	ldx	*(___fsadd_sloc0_1_0 + 1)
	beq	00155$
00154$:
	lda	___fsadd_mant1_1_1
	asra
	sta	___fsadd_mant1_1_1
	lda	(___fsadd_mant1_1_1 + 1)
	rora
	sta	(___fsadd_mant1_1_1 + 1)
	lda	(___fsadd_mant1_1_1 + 2)
	rora
	sta	(___fsadd_mant1_1_1 + 2)
	lda	(___fsadd_mant1_1_1 + 3)
	rora
	sta	(___fsadd_mant1_1_1 + 3)
	decx
	bne	00154$
00155$:
;_fsadd.c:200: exp1 = exp2;
	lda	___fsadd_exp2_1_1
	sta	___fsadd_exp1_1_1
	lda	(___fsadd_exp2_1_1 + 1)
	sta	(___fsadd_exp1_1_1 + 1)
00115$:
;_fsadd.c:202: mant1 += mant2;
	lda	(___fsadd_mant1_1_1 + 3)
	add	(___fsadd_mant2_1_1 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
	lda	(___fsadd_mant1_1_1 + 2)
	adc	(___fsadd_mant2_1_1 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	lda	(___fsadd_mant1_1_1 + 1)
	adc	(___fsadd_mant2_1_1 + 1)
	sta	(___fsadd_mant1_1_1 + 1)
	lda	___fsadd_mant1_1_1
	adc	___fsadd_mant2_1_1
	sta	___fsadd_mant1_1_1
;_fsadd.c:204: if (mant1 < 0)
	lda	(___fsadd_mant1_1_1 + 3)
	sub	#0x00
	lda	(___fsadd_mant1_1_1 + 2)
	sbc	#0x00
	lda	(___fsadd_mant1_1_1 + 1)
	sbc	#0x00
	lda	___fsadd_mant1_1_1
	sbc	#0x00
; Peephole 2l	- eliminated bra
	bge	00119$
00156$:
;_fsadd.c:206: mant1 = -mant1;
	clra
	sub	(___fsadd_mant1_1_1 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
	clra
	sbc	(___fsadd_mant1_1_1 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	clra
	sbc	(___fsadd_mant1_1_1 + 1)
	sta	(___fsadd_mant1_1_1 + 1)
	clra
	sbc	___fsadd_mant1_1_1
	sta	___fsadd_mant1_1_1
;_fsadd.c:207: sign = SIGNBIT;
	lda	#0x80
	sta	___fsadd_sign_1_1
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsadd_sign_1_1 + 1)
	sta	(___fsadd_sign_1_1 + 2)
	sta	(___fsadd_sign_1_1 + 3)
; Peephole 3	- shortened jmp to bra
	bra	00121$
00119$:
;_fsadd.c:209: else if (!mant1)
	lda	(___fsadd_mant1_1_1 + 3)
	ora	(___fsadd_mant1_1_1 + 2)
	ora	(___fsadd_mant1_1_1 + 1)
	ora	___fsadd_mant1_1_1
; Peephole 2c	- eliminated jmp
	bne	00121$
00157$:
;_fsadd.c:210: return (0);
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
; Peephole 6a  - replaced jmp to rts with rts
	rts
;_fsadd.c:213: while (mant1<HIDDEN) {
00121$:
	lda	(___fsadd_mant1_1_1 + 1)
	sub	#0x80
	lda	___fsadd_mant1_1_1
	sbc	#0x00
; Peephole 2a	- eliminated jmp
	bcc	00126$
00158$:
;_fsadd.c:214: mant1 <<= 1;
	lda	(___fsadd_mant1_1_1 + 3)
	ldx	(___fsadd_mant1_1_1 + 2)
	lsla
	rolx
	sta	(___fsadd_mant1_1_1 + 3)
	stx	(___fsadd_mant1_1_1 + 2)
	lda	(___fsadd_mant1_1_1 + 1)
	ldx	___fsadd_mant1_1_1
	rola
	rolx
	sta	(___fsadd_mant1_1_1 + 1)
	stx	___fsadd_mant1_1_1
;_fsadd.c:215: exp1--;
	lda	(___fsadd_exp1_1_1 + 1)
	sub	#0x01
	sta	(___fsadd_exp1_1_1 + 1)
	lda	___fsadd_exp1_1_1
	sbc	#0x00
	sta	___fsadd_exp1_1_1
; Peephole 3	- shortened jmp to bra
	bra	00121$
;_fsadd.c:219: while (mant1 & 0xff000000) {
00126$:
; Peephole 4a	- eliminated redundant tsta
	lda	___fsadd_mant1_1_1
	bne	00159$
	jmp	00128$
00159$:
;_fsadd.c:220: if (mant1&1)
	clra
	psha
	lda	(___fsadd_mant1_1_1 + 3)
	and	#0x01
	ora	1,s
	sta	1,s
	lda	(___fsadd_mant1_1_1 + 2)
	and	#0x00
	ora	1,s
	sta	1,s
	lda	(___fsadd_mant1_1_1 + 1)
	and	#0x00
	ora	1,s
	sta	1,s
	lda	___fsadd_mant1_1_1
	and	#0x00
	ora	1,s
	sta	1,s
	pula
	tsta
; Peephole 2d	- eliminated jmp
	beq	00125$
00160$:
;_fsadd.c:221: mant1 += 2;
	lda	(___fsadd_mant1_1_1 + 3)
	add	#0x02
	sta	(___fsadd_mant1_1_1 + 3)
	bcc	00161$
	lda	(___fsadd_mant1_1_1 + 2)
	inca
	sta	(___fsadd_mant1_1_1 + 2)
	bne	00161$
	lda	(___fsadd_mant1_1_1 + 1)
	inca
	sta	(___fsadd_mant1_1_1 + 1)
	bne	00161$
	lda	___fsadd_mant1_1_1
	inca
	sta	___fsadd_mant1_1_1
00161$:
00125$:
;_fsadd.c:222: mant1 >>= 1 ;
	lda	(___fsadd_mant1_1_1 + 1)
	ldx	___fsadd_mant1_1_1
	asrx
	rora
	sta	(___fsadd_mant1_1_1 + 1)
	stx	___fsadd_mant1_1_1
	lda	(___fsadd_mant1_1_1 + 3)
	ldx	(___fsadd_mant1_1_1 + 2)
	rorx
	rora
	sta	(___fsadd_mant1_1_1 + 3)
	stx	(___fsadd_mant1_1_1 + 2)
;_fsadd.c:223: exp1++;
	lda	(___fsadd_exp1_1_1 + 1)
	inca
	sta	(___fsadd_exp1_1_1 + 1)
	bne	00162$
	lda	___fsadd_exp1_1_1
	inca
	sta	___fsadd_exp1_1_1
00162$:
	jmp	00126$
00128$:
;_fsadd.c:227: mant1 &= ~HIDDEN;
	lda	(___fsadd_mant1_1_1 + 3)
	sta	(___fsadd_mant1_1_1 + 3)
	lda	(___fsadd_mant1_1_1 + 2)
	sta	(___fsadd_mant1_1_1 + 2)
	lda	(___fsadd_mant1_1_1 + 1)
	and	#0x7F
	sta	(___fsadd_mant1_1_1 + 1)
	lda	___fsadd_mant1_1_1
	sta	___fsadd_mant1_1_1
;_fsadd.c:230: fl1.l = PACK (sign, (unsigned long) exp1, mant1);
	lda	(___fsadd_exp1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	___fsadd_exp1_1_1
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	___fsadd_exp1_1_1
	rola	
	clra	
	sbc	#0x00
	sta	*(___fsadd_sloc0_1_0 + 1)
	sta	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lsrx
	rora
	tax
	clra
	rora
	sta	*(___fsadd_sloc0_1_0 + 1)
	stx	*___fsadd_sloc0_1_0
	clr	*(___fsadd_sloc0_1_0 + 3)
	clr	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_sign_1_1 + 3)
	ora	*(___fsadd_sloc0_1_0 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	(___fsadd_sign_1_1 + 2)
	ora	*(___fsadd_sloc0_1_0 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_sign_1_1 + 1)
	ora	*(___fsadd_sloc0_1_0 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	___fsadd_sign_1_1
	ora	*___fsadd_sloc0_1_0
	sta	*___fsadd_sloc0_1_0
	lda	*(___fsadd_sloc0_1_0 + 3)
	ora	(___fsadd_mant1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	lda	*(___fsadd_sloc0_1_0 + 2)
	ora	(___fsadd_mant1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 1)
	ora	(___fsadd_mant1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	*___fsadd_sloc0_1_0
	ora	___fsadd_mant1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	*___fsadd_sloc0_1_0
	sta	___fsadd_fl1_1_1
	lda	*(___fsadd_sloc0_1_0 + 1)
	sta	(___fsadd_fl1_1_1 + 1)
	lda	*(___fsadd_sloc0_1_0 + 2)
	sta	(___fsadd_fl1_1_1 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
	sta	(___fsadd_fl1_1_1 + 3)
;_fsadd.c:232: return (fl1.f);
	lda	___fsadd_fl1_1_1
	sta	*___fsadd_sloc0_1_0
	lda	(___fsadd_fl1_1_1 + 1)
	sta	*(___fsadd_sloc0_1_0 + 1)
	lda	(___fsadd_fl1_1_1 + 2)
	sta	*(___fsadd_sloc0_1_0 + 2)
	lda	(___fsadd_fl1_1_1 + 3)
	sta	*(___fsadd_sloc0_1_0 + 3)
	mov	*___fsadd_sloc0_1_0,*__ret3
	mov	*(___fsadd_sloc0_1_0 + 1),*__ret2
	ldx	*(___fsadd_sloc0_1_0 + 2)
	lda	*(___fsadd_sloc0_1_0 + 3)
00129$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
