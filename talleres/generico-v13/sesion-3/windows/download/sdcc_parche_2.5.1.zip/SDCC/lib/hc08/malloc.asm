;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:52 2005
;--------------------------------------------------------
	.module malloc
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _init_dynamic_memory_PARM_2
	.globl __sdcc_first_memheader
	.globl _init_dynamic_memory
	.globl _malloc
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area	OSEG    (OVR)
_init_dynamic_memory_sloc0_1_0::
	.ds 2
	.area	OSEG    (OVR)
_malloc_sloc0_1_0::
	.ds 2
_malloc_sloc1_1_0::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__sdcc_first_memheader::
	.ds 2
_init_dynamic_memory_PARM_2::
	.ds 2
_init_dynamic_memory_heap_1_1::
	.ds 2
_init_dynamic_memory_array_1_1::
	.ds 2
_malloc_size_1_1::
	.ds 2
_malloc_current_header_1_1::
	.ds 2
_malloc_new_header_1_1::
	.ds 2
_malloc_ret_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'init_dynamic_memory'
;------------------------------------------------------------
;size                      Allocated with name '_init_dynamic_memory_PARM_2'
;heap                      Allocated with name '_init_dynamic_memory_heap_1_1'
;array                     Allocated with name '_init_dynamic_memory_array_1_1'
;sloc0                     Allocated with name '_init_dynamic_memory_sloc0_1_0'
;------------------------------------------------------------
;malloc.c:146: void init_dynamic_memory(void xdata * heap, unsigned int size)
;	-----------------------------------------
;	 function init_dynamic_memory
;	-----------------------------------------
_init_dynamic_memory:
	sta	(_init_dynamic_memory_heap_1_1 + 1)
	stx	_init_dynamic_memory_heap_1_1
;malloc.c:167: char xdata * array = (char xdata *)heap;
	lda	_init_dynamic_memory_heap_1_1
	sta	_init_dynamic_memory_array_1_1
	lda	(_init_dynamic_memory_heap_1_1 + 1)
	sta	(_init_dynamic_memory_array_1_1 + 1)
;malloc.c:169: if ( !array ) //Reserved memory starts at 0x0000 but that's NULL...
	lda	(_init_dynamic_memory_heap_1_1 + 1)
	ora	_init_dynamic_memory_heap_1_1
; Peephole 2c	- eliminated jmp
	bne	00102$
00106$:
;malloc.c:171: array++;
	lda	(_init_dynamic_memory_heap_1_1 + 1)
	add	#0x01
	sta	(_init_dynamic_memory_array_1_1 + 1)
	lda	_init_dynamic_memory_heap_1_1
	adc	#0x00
	sta	_init_dynamic_memory_array_1_1
;malloc.c:172: size--;
	lda	(_init_dynamic_memory_PARM_2 + 1)
	sub	#0x01
	sta	(_init_dynamic_memory_PARM_2 + 1)
	lda	_init_dynamic_memory_PARM_2
	sbc	#0x00
	sta	_init_dynamic_memory_PARM_2
00102$:
;malloc.c:174: _sdcc_first_memheader = (MEMHEADER xdata * ) array;
	lda	_init_dynamic_memory_array_1_1
	sta	__sdcc_first_memheader
	lda	(_init_dynamic_memory_array_1_1 + 1)
	sta	(__sdcc_first_memheader + 1)
;malloc.c:176: _sdcc_first_memheader->next = (MEMHEADER xdata * )(array + size - sizeof(MEMHEADER xdata *));
	lda	(_init_dynamic_memory_array_1_1 + 1)
	add	(_init_dynamic_memory_PARM_2 + 1)
	sta	*(_init_dynamic_memory_sloc0_1_0 + 1)
	lda	_init_dynamic_memory_array_1_1
	adc	_init_dynamic_memory_PARM_2
	sta	*_init_dynamic_memory_sloc0_1_0
	lda	*(_init_dynamic_memory_sloc0_1_0 + 1)
	sub	#0x02
	sta	*(_init_dynamic_memory_sloc0_1_0 + 1)
	lda	*_init_dynamic_memory_sloc0_1_0
	sbc	#0x00
	sta	*_init_dynamic_memory_sloc0_1_0
	lda	_init_dynamic_memory_array_1_1
	ldx	(_init_dynamic_memory_array_1_1 + 1)
	psha
	pulh
	lda	*_init_dynamic_memory_sloc0_1_0
	sta	,x
	aix	#1
	lda	*(_init_dynamic_memory_sloc0_1_0 + 1)
	sta	,x
;malloc.c:177: _sdcc_first_memheader->next->next = (MEMHEADER xdata * ) NULL; //And mark it as last
	ldhx	*_init_dynamic_memory_sloc0_1_0
	clra
	sta	,x
	aix	#1
	clra
	sta	,x
;malloc.c:178: _sdcc_first_memheader->len        = 0;    //Empty and ready.
	lda	(_init_dynamic_memory_array_1_1 + 1)
	add	#0x02
	sta	*(_init_dynamic_memory_sloc0_1_0 + 1)
	lda	_init_dynamic_memory_array_1_1
	adc	#0x00
	sta	*_init_dynamic_memory_sloc0_1_0
	ldhx	*_init_dynamic_memory_sloc0_1_0
	clra
	sta	,x
	aix	#1
	clra
	sta	,x
00103$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'malloc'
;------------------------------------------------------------
;size                      Allocated with name '_malloc_size_1_1'
;current_header            Allocated with name '_malloc_current_header_1_1'
;new_header                Allocated with name '_malloc_new_header_1_1'
;ret                       Allocated with name '_malloc_ret_1_1'
;sloc0                     Allocated with name '_malloc_sloc0_1_0'
;sloc1                     Allocated with name '_malloc_sloc1_1_0'
;------------------------------------------------------------
;malloc.c:181: void xdata * malloc (unsigned int size)
;	-----------------------------------------
;	 function malloc
;	-----------------------------------------
_malloc:
	sta	(_malloc_size_1_1 + 1)
	stx	_malloc_size_1_1
;malloc.c:187: if (size>(0xFFFF-HEADER_SIZE)) return (void xdata *) NULL; //To prevent overflow in next line
	lda	#0xFB
	sub	(_malloc_size_1_1 + 1)
	lda	#0xFF
	sbc	_malloc_size_1_1
; Peephole 2a	- eliminated jmp
	bcc	00102$
00123$:
	clrx
	clra
; Peephole 6a  - replaced jmp to rts with rts
	rts
00102$:
;malloc.c:188: size += HEADER_SIZE; //We need a memory for header too
	lda	(_malloc_size_1_1 + 1)
	add	#0x04
	sta	(_malloc_size_1_1 + 1)
	bcc	00124$
	lda	_malloc_size_1_1
	inca
	sta	_malloc_size_1_1
00124$:
;malloc.c:189: current_header = _sdcc_first_memheader;
	lda	__sdcc_first_memheader
	sta	_malloc_current_header_1_1
	lda	(__sdcc_first_memheader + 1)
	sta	(_malloc_current_header_1_1 + 1)
;malloc.c:192: while (1)
00108$:
;malloc.c:202: if ((((unsigned int)current_header->next) -
	lda	_malloc_current_header_1_1
	ldx	(_malloc_current_header_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	*_malloc_sloc0_1_0
	lda	,x
	sta	*(_malloc_sloc0_1_0 + 1)
;malloc.c:203: ((unsigned int)current_header) -
	lda	(_malloc_current_header_1_1 + 1)
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_current_header_1_1
	sta	*_malloc_sloc1_1_0
	lda	*(_malloc_sloc0_1_0 + 1)
	sub	*(_malloc_sloc1_1_0 + 1)
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	*_malloc_sloc0_1_0
	sbc	*_malloc_sloc1_1_0
	sta	*_malloc_sloc1_1_0
;malloc.c:204: current_header->len) >= size)
	lda	(_malloc_current_header_1_1 + 1)
	add	#0x02
	sta	*(_malloc_sloc0_1_0 + 1)
	lda	_malloc_current_header_1_1
	adc	#0x00
	sta	*_malloc_sloc0_1_0
	ldhx	*_malloc_sloc0_1_0
	lda	,x
	aix	#1
	sta	*_malloc_sloc0_1_0
	lda	,x
	sta	*(_malloc_sloc0_1_0 + 1)
	lda	*(_malloc_sloc1_1_0 + 1)
	sub	*(_malloc_sloc0_1_0 + 1)
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	*_malloc_sloc1_1_0
	sbc	*_malloc_sloc0_1_0
	sta	*_malloc_sloc1_1_0
	lda	*(_malloc_sloc1_1_0 + 1)
	sub	(_malloc_size_1_1 + 1)
	lda	*_malloc_sloc1_1_0
	sbc	_malloc_size_1_1
; Peephole 2b	- eliminated jmp
	bcs	00104$
00125$:
;malloc.c:206: ret = current_header->mem;
	lda	(_malloc_current_header_1_1 + 1)
	add	#0x04
	sta	(_malloc_ret_1_1 + 1)
	lda	_malloc_current_header_1_1
	adc	#0x00
	sta	_malloc_ret_1_1
;malloc.c:207: break;
; Peephole 3	- shortened jmp to bra
	bra	00109$
00104$:
;malloc.c:209: current_header = current_header->next;    //else try next
	lda	_malloc_current_header_1_1
	ldx	(_malloc_current_header_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	_malloc_current_header_1_1
	lda	,x
	sta	(_malloc_current_header_1_1 + 1)
;malloc.c:210: if (!current_header->next)
	lda	_malloc_current_header_1_1
	ldx	(_malloc_current_header_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	*_malloc_sloc1_1_0
	lda	,x
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	*(_malloc_sloc1_1_0 + 1)
	ora	*_malloc_sloc1_1_0
	beq	00126$
	jmp	00108$
00126$:
;malloc.c:212: ret = (void xdata *) NULL;
; Peephole 5c   - eliminated redundant clra
	clra
	sta	_malloc_ret_1_1
	sta	(_malloc_ret_1_1 + 1)
;malloc.c:213: break;
00109$:
;malloc.c:216: if (ret)
	lda	(_malloc_ret_1_1 + 1)
	ora	_malloc_ret_1_1
	bne	00127$
	jmp	00114$
00127$:
;malloc.c:218: if (!current_header->len)
	lda	(_malloc_current_header_1_1 + 1)
	add	#0x02
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_current_header_1_1
	adc	#0x00
	sta	*_malloc_sloc1_1_0
	ldhx	*_malloc_sloc1_1_0
	lda	,x
	aix	#1
	sta	*_malloc_sloc1_1_0
	lda	,x
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	*(_malloc_sloc1_1_0 + 1)
	ora	*_malloc_sloc1_1_0
; Peephole 2c	- eliminated jmp
	bne	00111$
00128$:
;malloc.c:220: current_header->len = size; //for first allocation
	lda	(_malloc_current_header_1_1 + 1)
	add	#0x02
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_current_header_1_1
	adc	#0x00
	sta	*_malloc_sloc1_1_0
	ldhx	*_malloc_sloc1_1_0
	lda	_malloc_size_1_1
	sta	,x
	aix	#1
	lda	(_malloc_size_1_1 + 1)
	sta	,x
	jmp	00114$
00111$:
;malloc.c:224: new_header = (MEMHEADER xdata * )((char xdata *)current_header + current_header->len);
	lda	(_malloc_current_header_1_1 + 1)
	add	#0x02
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_current_header_1_1
	adc	#0x00
	sta	*_malloc_sloc1_1_0
	ldhx	*_malloc_sloc1_1_0
	lda	,x
	aix	#1
	sta	*_malloc_sloc1_1_0
	lda	,x
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	(_malloc_current_header_1_1 + 1)
	add	*(_malloc_sloc1_1_0 + 1)
	sta	(_malloc_new_header_1_1 + 1)
	lda	_malloc_current_header_1_1
	adc	*_malloc_sloc1_1_0
	sta	_malloc_new_header_1_1
;malloc.c:225: new_header->next = current_header->next; //and plug it into the chain
	lda	_malloc_current_header_1_1
	ldx	(_malloc_current_header_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	*_malloc_sloc1_1_0
	lda	,x
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_new_header_1_1
	ldx	(_malloc_new_header_1_1 + 1)
	psha
	pulh
	lda	*_malloc_sloc1_1_0
	sta	,x
	aix	#1
	lda	*(_malloc_sloc1_1_0 + 1)
	sta	,x
;malloc.c:226: current_header->next  = new_header;
	lda	_malloc_current_header_1_1
	ldx	(_malloc_current_header_1_1 + 1)
	psha
	pulh
	lda	_malloc_new_header_1_1
	sta	,x
	aix	#1
	lda	(_malloc_new_header_1_1 + 1)
	sta	,x
;malloc.c:227: new_header->len  = size; //mark as used
	lda	(_malloc_new_header_1_1 + 1)
	add	#0x02
	sta	*(_malloc_sloc1_1_0 + 1)
	lda	_malloc_new_header_1_1
	adc	#0x00
	sta	*_malloc_sloc1_1_0
	ldhx	*_malloc_sloc1_1_0
	lda	_malloc_size_1_1
	sta	,x
	aix	#1
	lda	(_malloc_size_1_1 + 1)
	sta	,x
;malloc.c:228: ret = new_header->mem;
	lda	(_malloc_new_header_1_1 + 1)
	add	#0x04
	sta	(_malloc_ret_1_1 + 1)
	lda	_malloc_new_header_1_1
	adc	#0x00
	sta	_malloc_ret_1_1
00114$:
;malloc.c:232: return ret;
	ldx	_malloc_ret_1_1
	lda	(_malloc_ret_1_1 + 1)
00115$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
