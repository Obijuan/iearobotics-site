;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:01 2005
;--------------------------------------------------------
	.module _divsint
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __divsint_PARM_2
	.globl __divsint
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
__divsint_sloc0_1_0::
	.ds 2
__divsint_sloc1_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__divsint_PARM_2::
	.ds 2
__divsint_a_1_1::
	.ds 2
__divsint_r_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_divsint'
;------------------------------------------------------------
;sloc0                     Allocated with name '__divsint_sloc0_1_0'
;sloc1                     Allocated with name '__divsint_sloc1_1_0'
;b                         Allocated with name '__divsint_PARM_2'
;a                         Allocated with name '__divsint_a_1_1'
;r                         Allocated with name '__divsint_r_1_1'
;------------------------------------------------------------
;_divsint.c:206: _divsint (int a, int b)
;	-----------------------------------------
;	 function _divsint
;	-----------------------------------------
__divsint:
	sta	(__divsint_a_1_1 + 1)
	stx	__divsint_a_1_1
;_divsint.c:210: r = _divuint((a < 0 ? -a : a),
	lda	__divsint_a_1_1
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00106$
00113$:
	clra
	sub	(__divsint_a_1_1 + 1)
	sta	*(__divsint_sloc0_1_0 + 1)
	clra
	sbc	__divsint_a_1_1
	sta	*__divsint_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00107$
00106$:
	lda	__divsint_a_1_1
	sta	*__divsint_sloc0_1_0
	lda	(__divsint_a_1_1 + 1)
	sta	*(__divsint_sloc0_1_0 + 1)
00107$:
;_divsint.c:211: (b < 0 ? -b : b));
	lda	__divsint_PARM_2
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00108$
00114$:
	clra
	sub	(__divsint_PARM_2 + 1)
	sta	*(__divsint_sloc1_1_0 + 1)
	clra
	sbc	__divsint_PARM_2
	sta	*__divsint_sloc1_1_0
; Peephole 3	- shortened jmp to bra
	bra	00109$
00108$:
	lda	__divsint_PARM_2
	sta	*__divsint_sloc1_1_0
	lda	(__divsint_PARM_2 + 1)
	sta	*(__divsint_sloc1_1_0 + 1)
00109$:
	lda	*__divsint_sloc1_1_0
	sta	__divuint_PARM_2
	lda	*(__divsint_sloc1_1_0 + 1)
	sta	(__divuint_PARM_2 + 1)
	ldx	*__divsint_sloc0_1_0
	lda	*(__divsint_sloc0_1_0 + 1)
	jsr	__divuint
	sta	(__divsint_r_1_1 + 1)
	stx	__divsint_r_1_1
;_divsint.c:212: if ( (a < 0) ^ (b < 0))
	lda	__divsint_a_1_1
	sub	#0x00
	blt	00115$
	clra
	bra	00116$
00115$:
	lda	#0x01
00116$:
	sta	*__divsint_sloc1_1_0
	lda	__divsint_PARM_2
	sub	#0x00
	blt	00117$
	clra
	bra	00118$
00117$:
	lda	#0x01
00118$:
	eor	*__divsint_sloc1_1_0
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00119$:
;_divsint.c:213: return -r;
	clra
	sub	(__divsint_r_1_1 + 1)
	sta	*(__divsint_sloc1_1_0 + 1)
	clra
	sbc	__divsint_r_1_1
	sta	*__divsint_sloc1_1_0
	ldx	*__divsint_sloc1_1_0
	lda	*(__divsint_sloc1_1_0 + 1)
; Peephole 3	- shortened jmp to bra
; Peephole 6b  - replaced jmp to rts with rts
	rts
00102$:
;_divsint.c:215: return r;
	ldx	__divsint_r_1_1
	lda	(__divsint_r_1_1 + 1)
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
