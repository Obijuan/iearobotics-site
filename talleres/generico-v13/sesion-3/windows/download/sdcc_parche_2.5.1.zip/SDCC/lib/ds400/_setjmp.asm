;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:10 2005
;--------------------------------------------------------
	.module _setjmp
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _setjmp
	.globl _longjmp
	.globl _longjmp_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_longjmp_PARM_2::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'longjmp'
;------------------------------------------------------------
;rv                        Allocated with name '_longjmp_PARM_2'
;bp                        Allocated to registers r2 r3 r4 r5 
;lsp                       Allocated to registers r6 
;------------------------------------------------------------
;	_setjmp.c:28: int longjmp (unsigned char *bp, int rv)
;	genFunction 
;	-----------------------------------------
;	 function longjmp
;	-----------------------------------------
_longjmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_setjmp.c:31: lsp = *(bp+2);
;	genPlus 
	mov	a,#0x02
	add	a,r2
	mov	r6,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r7,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	mov	r0,a
	mov	ar1,r5
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	_setjmp.c:32: *((unsigned char data *) lsp) = *bp++;
;	genCast 
	mov	ar0,r6
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r7,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genPointerSet 
	mov	@r0,ar7
;	_setjmp.c:33: *((unsigned char data *) lsp - 1) = *bp;
;	genCast 
	mov	ar7,r6
;	genMinus 
	mov	a,r7
	dec	a
	mov	r0,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genPointerSet 
; Peephole 192   used a instead of ar2 as source
	mov  r2,a
	mov  @r0,a
;	_setjmp.c:34: SP = lsp;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_SP,r6
;	_setjmp.c:35: return rv;
;	genRet 
	mov     dps, #1
	mov     dptr, #_longjmp_PARM_2
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'setjmp'
;------------------------------------------------------------
;bp                        Allocated to registers 
;------------------------------------------------------------
;	_setjmp.c:38: int setjmp (unsigned char *bp)
;	genFunction 
;	-----------------------------------------
;	 function setjmp
;	-----------------------------------------
_setjmp:
;	genReceive 
;	_setjmp.c:43: *bp++ = *((unsigned char data *) SP  );   
;	genCast 
	mov	r0,_SP
;	genPointerGet 
	mov	ar2,@r0
;	genPointerSet 
	mov	a,r2
	lcall	__gptrput
	inc	dptr
;	_setjmp.c:44: *bp++ = *((unsigned char data *)SP - 1);    
;	genCast 
	mov	r2,_SP
;	genMinus 
	mov	a,r2
	dec	a
	mov	r0,a
;	genPointerGet 
	mov	ar2,@r0
;	genPointerSet 
	mov	a,r2
	lcall	__gptrput
	inc	dptr
;	_setjmp.c:45: *bp   = SP;
;	genPointerSet 
	mov	a,_SP
	lcall	__gptrput
;	_setjmp.c:46: return 0;
;	genRet 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
;	genLabel 
00101$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
