;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:16 2005
;--------------------------------------------------------
	.module _strcmp
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strcmp_PARM_2
	.globl _strcmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strcmp_PARM_2::
	.ds 4
_strcmp_ret_1_1::
	.ds 2
_strcmp_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strcmp'
;------------------------------------------------------------
;adst                      Allocated with name '_strcmp_PARM_2'
;asrc                      Allocated to registers r2 r3 r4 r5 
;ret                       Allocated with name '_strcmp_ret_1_1'
;sloc0                     Allocated with name '_strcmp_sloc0_1_0'
;------------------------------------------------------------
;	_strcmp.c:29: int strcmp (
;	genFunction 
;	-----------------------------------------
;	 function strcmp
;	-----------------------------------------
_strcmp:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_strcmp.c:48: while( ! (ret = *asrc - *adst) && *adst)
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genAssign 
	mov	dptr,#_strcmp_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_strcmp_sloc0_1_0
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00102$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genCast 
; Peephole 105   removed redundant mov
	mov  r6,a
	rlc	a
	subb	a,acc
	mov	r7,a
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_strcmp_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
	mov	r0,a
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genCast 
	mov	ar1,r0
	mov	a,r0
	rlc	a
	subb	a,acc
	mov	r2,a
;	genMinus 
	clr	c
	mov	a,r6
	subb	a,r1
	mov	r6,a
	mov	a,r7
	subb	a,r2
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strcmp_ret_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genIpop 
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,r6
	orl	a,r7
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00104$
00117$:
;	genIfx 
	mov	a,r0
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00104$
00118$:
;	_strcmp.c:49: ++asrc, ++adst;
;	genPlus 
	inc	r2
	cjne	r2,#0,00119$
	inc	r3
	cjne	r3,#0,00119$
	inc	r4
00119$:
;	did genPlusIncr
;	genPlus 
	mov	dptr,#_strcmp_sloc0_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00102$
;	genLabel 
00104$:
;	_strcmp.c:51: if ( ret < 0 )
;	genCmpLt 
	mov	dptr,#_strcmp_ret_1_1
;	genCmp
	inc	dptr
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00108$
00120$:
;	_strcmp.c:52: ret = -1 ;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strcmp_ret_1_1
; Peephole 101   removed redundant mov
	mov  a,#0xFF
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00108$:
;	_strcmp.c:53: else if ( ret > 0 )
;	genCmpGt 
	mov	dptr,#_strcmp_ret_1_1
;	genCmp
	clr	c
; Peephole 180   changed mov to clr
	clr  a
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
; Peephole 159   avoided xrl during execution
	mov  a,#(0x00 ^ 0x80)
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00109$
00121$:
;	_strcmp.c:54: ret = 1 ;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strcmp_ret_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genLabel 
00109$:
;	_strcmp.c:56: return( ret );
;	genRet 
	mov     dps, #1
	mov     dptr, #_strcmp_ret_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
;	genLabel 
00110$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
