;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:51 2005
;--------------------------------------------------------
	.module calloc
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _calloc_PARM_2
	.globl _calloc
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_calloc_PARM_2::
	.ds 2
_calloc_nmemb_1_1::
	.ds 2
_calloc_ptr_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'calloc'
;------------------------------------------------------------
;size                      Allocated with name '_calloc_PARM_2'
;nmemb                     Allocated with name '_calloc_nmemb_1_1'
;ptr                       Allocated with name '_calloc_ptr_1_1'
;------------------------------------------------------------
;calloc.c:53: void xdata * calloc (size_t nmemb, size_t size)
;	-----------------------------------------
;	 function calloc
;	-----------------------------------------
_calloc:
	sta	(_calloc_nmemb_1_1 + 1)
	stx	_calloc_nmemb_1_1
;calloc.c:57: ptr = malloc(nmemb * size);
	lda	_calloc_PARM_2
	sta	__mulint_PARM_2
	lda	(_calloc_PARM_2 + 1)
	sta	(__mulint_PARM_2 + 1)
	ldx	_calloc_nmemb_1_1
	lda	(_calloc_nmemb_1_1 + 1)
	jsr	__mulint
	jsr	_malloc
	sta	(_calloc_ptr_1_1 + 1)
	stx	_calloc_ptr_1_1
;calloc.c:58: if (ptr)
	lda	(_calloc_ptr_1_1 + 1)
	ora	_calloc_ptr_1_1
; Peephole 2d	- eliminated jmp
	beq	00102$
00106$:
;calloc.c:60: memset(ptr, 0, nmemb * size);
	lda	_calloc_PARM_2
	sta	__mulint_PARM_2
	lda	(_calloc_PARM_2 + 1)
	sta	(__mulint_PARM_2 + 1)
	ldx	_calloc_nmemb_1_1
	lda	(_calloc_nmemb_1_1 + 1)
	jsr	__mulint
	sta	(_memset_PARM_3 + 1)
	stx	_memset_PARM_3
	clra
	sta	_memset_PARM_2
	ldx	_calloc_ptr_1_1
	lda	(_calloc_ptr_1_1 + 1)
	jsr	_memset
00102$:
;calloc.c:62: return ptr;
	ldx	_calloc_ptr_1_1
	lda	(_calloc_ptr_1_1 + 1)
00103$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
