;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:52:17 2005
;--------------------------------------------------------
	.module ldexpf
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ldexpf_PARM_2
	.globl _ldexpf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_ldexpf_PARM_2::
	.ds 2
_ldexpf_fl_1_1::
	.ds 4
_ldexpf_e_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ldexpf'
;------------------------------------------------------------
;pw2                       Allocated with name '_ldexpf_PARM_2'
;x                         Allocated to registers r2 r3 r4 r5 
;fl                        Allocated with name '_ldexpf_fl_1_1'
;e                         Allocated with name '_ldexpf_e_1_1'
;------------------------------------------------------------
;	ldexpf.c:24: float ldexpf(const float x, const int pw2)
;	genFunction 
;	-----------------------------------------
;	 function ldexpf
;	-----------------------------------------
_ldexpf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	ldexpf.c:29: fl.f = x;
;	genPointerSet 
	mov	dptr,#_ldexpf_fl_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	ldexpf.c:31: e=(fl.l >> 23) & 0x000000ff;
;	genRightShift 
;	genSignedRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar6,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r6
	rlc	a
	xch	a,r6
	rlc	a
	xch	a,r6
	anl	a,#0x01
	jnb	acc.0,00103$
	orl	a,#0xFE
00103$:
	mov	r7,a
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genAnd 
	mov	dptr,#_ldexpf_e_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
;	ldexpf.c:32: e+=pw2;
;	genCast 
	mov	dptr,#_ldexpf_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genPlus 
	mov	dptr,#_ldexpf_e_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r7
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r0
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r1
	movx	@dptr,a
;	ldexpf.c:33: fl.l= ((e & 0xff) << 23) | (fl.l & 0x807fffff);
;	genAnd 
	mov	dptr,#_ldexpf_e_1_1
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0
	mov	r0,#0
	mov	r1,#0
;	genLeftShift 
;	genLeftShiftLiteral (23), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x18
	sjmp	00105$
00104$:
	mov	a,r6
	add	a,acc
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
00105$:
	djnz	b,00104$
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genAnd 
	anl	ar4,#0x7F
	anl	ar5,#0x80
;	genOr 
	mov	a,r2
	orl	ar6,a
	mov	a,r3
	orl	ar7,a
	mov	a,r4
	orl	ar0,a
	mov	a,r5
	orl	ar1,a
;	genPointerSet 
	mov	dptr,#_ldexpf_fl_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	ldexpf.c:35: return(fl.f);
;	genRet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
;	genLabel 
00101$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
