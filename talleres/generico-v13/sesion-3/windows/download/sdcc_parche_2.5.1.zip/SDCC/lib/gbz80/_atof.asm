;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:53:23 2005
;--------------------------------------------------------
	.module _atof
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atof
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_atof.c:23: float atof(char * s)
;	genLabel
;	genFunction
;	---------------------------------
; Function atof
; ---------------------------------
_atof_start::
_atof:
	lda	sp,-19(sp)
;_atof.c:30: while (isspace(*s)) s++;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _atof__1_0
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00101$:
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genCall
	call	_isspace
	ld	c,e
	lda	sp,1(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for 
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00103$
;	genPlus
;	AOP_STK for _atof__1_0
;	genPlusIncr
	lda	hl,8(sp)
	inc	(hl)
	jr	nz,00148$
	inc	hl
	inc	(hl)
00148$:
;	genGoto
	jp	00101$
;	genLabel
00103$:
;_atof.c:33: if (*s == '-')
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	c,a
	cp	a,#0x2D
	jp	nz,00107$
	jr	00150$
00149$:
	jp	00107$
00150$:
;_atof.c:35: sign=1;
;	genAssign
;	AOP_STK for _atof_sign_1_1
	lda	hl,10(sp)
	ld	(hl),#0x01
;_atof.c:36: s++;
;	genPlus
;	AOP_STK for _atof__1_0
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),d
;	genGoto
	jp	00108$
;	genLabel
00107$:
;_atof.c:40: sign=0;
;	genAssign
;	AOP_STK for _atof_sign_1_1
	lda	hl,10(sp)
	ld	(hl),#0x00
;_atof.c:41: if (*s == '+') s++;
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,c
	cp	a,#0x2B
	jp	nz,00108$
	jr	00152$
00151$:
	jp	00108$
00152$:
;	genPlus
;	AOP_STK for _atof__1_0
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),d
;	genLabel
00108$:
;_atof.c:45: for (value=0.0; isdigit(*s); s++)
;	genAssign
;	AOP_STK for _atof_value_1_1
	lda	hl,15(sp)
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;	genAssign
;	AOP_STK for 
;	AOP_STK for _atof__1_0
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00121$:
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genCall
	call	_isdigit
	ld	c,e
	lda	sp,1(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for 
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00124$
;_atof.c:47: value=10.0*value+(*s-'0');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	hl,#0x4120
	push	hl
	ld	hl,#0x0000
	push	hl
;	genIpush
;	AOP_STK for _atof_value_1_1
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,14(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCast
; Removed redundent load
	ld	c,a
	rla	
	sbc	a,a
	ld	b,a
;	genMinus
	ld	a,c
	add	a,#0xD0
	ld	c,a
	ld	a,b
	adc	a,#0xFF
	ld	b,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	push	bc
;	genCall
	call	___sint2fs
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,4(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,2(sp)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for _atof__1_0
	lda	hl,2(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,2(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for _atof__1_0
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsadd
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,10(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_value_1_1
	lda	hl,0(sp)
	ld	d,h
	ld	e,l
	lda	hl,15(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;_atof.c:45: for (value=0.0; isdigit(*s); s++)
;	genPlus
;	AOP_STK for _atof__1_0
;	genPlusIncr
	lda	hl,8(sp)
	inc	(hl)
	jr	nz,00153$
	inc	hl
	inc	(hl)
00153$:
;	genGoto
	jp	00121$
;	genLabel
00124$:
;_atof.c:51: if (*s == '.')
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	c,a
	cp	a,#0x2E
	jp	nz,00110$
	jr	00155$
00154$:
	jp	00110$
00155$:
;_atof.c:53: s++;
;	genPlus
;	AOP_STK for _atof__1_0
;	genPlusIncr
	lda	hl,8(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
;	genAssign
;	AOP_STK for _atof_fraction_1_1
	inc	hl
	inc	hl
	ld	(hl),#0xCD
	inc	hl
	ld	(hl),#0xCC
	inc	hl
	ld	(hl),#0xCC
	inc	hl
	ld	(hl),#0x3D
;	genAssign
;	AOP_STK for _atof__1_0
	lda	hl,0(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genLabel
00125$:
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genCall
	call	_isdigit
	ld	c,e
	lda	sp,1(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for 
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00110$
;_atof.c:56: value+=(*s-'0')*fraction;
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCast
; Removed redundent load
	ld	c,a
	rla	
	sbc	a,a
	ld	b,a
;	genMinus
	ld	a,c
	add	a,#0xD0
	ld	c,a
	ld	a,b
	adc	a,#0xFF
	ld	b,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	push	bc
;	genCall
	call	___sint2fs
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,8(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,2(sp)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for _atof_fraction_1_1
	lda	hl,13(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,13(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for _atof__1_0
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,14(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for _atof__1_0
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for _atof_value_1_1
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsadd
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,14(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_value_1_1
	lda	hl,4(sp)
	ld	d,h
	ld	e,l
	lda	hl,15(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;_atof.c:57: fraction*=0.1;
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	hl,#0x3DCC
	push	hl
	ld	hl,#0xCCCD
	push	hl
;	genIpush
;	AOP_STK for _atof_fraction_1_1
	lda	hl,17(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,17(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,14(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_fraction_1_1
	lda	hl,4(sp)
	ld	d,h
	ld	e,l
	lda	hl,11(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
;	genPlus
;	AOP_STK for _atof__1_0
;	genPlusIncr
	lda	hl,0(sp)
	inc	(hl)
	jr	nz,00156$
	inc	hl
	inc	(hl)
00156$:
;	genGoto
	jp	00125$
;	genLabel
00110$:
;_atof.c:62: if (toupper(*s)=='E')
;	genAssign
;	AOP_STK for 
;	AOP_STK for _atof__1_0
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),e
;	genPointerGet
;	AOP_STK for _atof__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genCall
	call	_islower
	ld	c,e
	lda	sp,1(sp)
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00131$
;	genPointerGet
;	AOP_STK for _atof__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCast
; Removed redundent load
	ld	c,a
	rla	
	sbc	a,a
	ld	b,a
;	genAnd
	ld	a,c
	and	a,#0xDF
	ld	c,a
;	genGoto
	jp	00132$
;	genLabel
00131$:
;	genPointerGet
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	dec	hl
;	genCast
;	AOP_STK for _atof__1_0
	ld      (hl),a
	ld      c,a
	ld	a,(hl)
	rla	
	sbc	a,a
	ld	b,a
;	genLabel
00132$:
;	genCmpEq
; genCmpEq: left 2, right 2, result 0
	ld	a,c
	cp	a,#0x45
	jp	nz,00157$
	ld	a,b
	or	a,a
	jp	nz,00118$
	jr	00158$
00157$:
	jp	00118$
00158$:
;_atof.c:64: s++;
;	genAssign
;	AOP_STK for 
	lda	hl,21(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	ld	hl,#0x0001
	add	hl,bc
	ld	a,l
	ld	d,h
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),d
;_atof.c:65: iexp=(char)atoi(s);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	dec	hl
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_atoi
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genCast
; Removed redundent load
;_atof.c:67: while(iexp!=0)
;	genLabel
00114$:
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,c
	or	a,a
	jp	z,00118$
00159$:
;_atof.c:69: if(iexp<0)
;	genCmpLt
	ld	a,c
	bit	7,a
	jp	z,00112$
;_atof.c:71: value*=0.1;
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
	ld	hl,#0x3DCC
	push	hl
	ld	hl,#0xCCCD
	push	hl
;	genIpush
;	AOP_STK for _atof_value_1_1
	lda	hl,23(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,23(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,12(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
	pop	bc
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_value_1_1
	lda	hl,0(sp)
	ld	d,h
	ld	e,l
	lda	hl,15(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;_atof.c:72: iexp++;
;	genPlus
;	genPlusIncr
; Removed redundent load
	inc	c
;	genGoto
	jp	00114$
;	genLabel
00112$:
;_atof.c:76: value*=10.0;
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
	ld	hl,#0x4120
	push	hl
	ld	hl,#0x0000
	push	hl
;	genIpush
;	AOP_STK for _atof_value_1_1
	lda	hl,23(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,23(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,12(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
	pop	bc
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_value_1_1
	lda	hl,0(sp)
	ld	d,h
	ld	e,l
	lda	hl,15(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;_atof.c:77: iexp--;
;	genMinus
	dec	c
;	genGoto
	jp	00114$
;	genLabel
00118$:
;_atof.c:83: if(sign) value*=-1.0;
;	genIfx
;	AOP_STK for _atof_sign_1_1
	xor	a,a
	lda	hl,10(sp)
	or	a,(hl)
	jp	z,00120$
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	hl,#0xBF80
	push	hl
	ld	hl,#0x0000
	push	hl
;	genIpush
;	AOP_STK for _atof_value_1_1
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,21(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	___fsmul
;	AOP_STK for _atof__1_0
	push	hl
	lda	hl,10(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
;	genAssign
;	AOP_STK for _atof__1_0
;	AOP_STK for _atof_value_1_1
	lda	hl,0(sp)
	ld	d,h
	ld	e,l
	lda	hl,15(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genLabel
00120$:
;_atof.c:84: return (value);
;	genRet
;	AOP_STK for _atof_value_1_1
; Dump of IC_LEFT: type AOP_STK size 4
;	 aop_stk -4
	lda	hl,15(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
;	genLabel
00129$:
;	genEndFunction
	lda	sp,19(sp)
	ret
_atof_end::
	.area _CODE
