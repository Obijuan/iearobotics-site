;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:26 2005
;--------------------------------------------------------
	.module _strrchr
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strrchr_PARM_2
	.globl _strrchr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strrchr_PARM_2::
	.ds 1
_strrchr_start_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strrchr'
;------------------------------------------------------------
;ch                        Allocated with name '_strrchr_PARM_2'
;string                    Allocated to registers r2 r3 r4 r5 
;start                     Allocated with name '_strrchr_start_1_1'
;------------------------------------------------------------
;	_strrchr.c:26: char * strrchr (
;	genFunction 
;	-----------------------------------------
;	 function strrchr
;	-----------------------------------------
_strrchr:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_strrchr.c:31: char * start = string;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strrchr_start_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_strrchr.c:33: while (*string++)                       /* find end of string */
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00101$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r6,a
	inc	dptr
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00101$
00116$:
;	_strrchr.c:36: while (--string != start && *string != ch)
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00105$:
;	genMinus 
	dec	r2
	cjne	r2,#0xFF,00117$
	dec	r3
	cjne	r3,#0xFF,00117$
	dec	r4
00117$:
;	genCmpEq 
	mov	dptr,#_strrchr_start_1_1
;	gencjneshort
;	cjneshort: generic ptr special case.
	mov	b,r2
	movx	a,@dptr
	cjne	a,b,00118$
	mov	b,r3
	inc	dptr
	movx	a,@dptr
	cjne	a,b,00118$
	mov	b,r4
	inc	dptr
	movx	a,@dptr
	cjne	a,b,00118$
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00118$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r6,a
;	genCmpEq 
	mov	dptr,#_strrchr_PARM_2
;	gencjneshort
	mov	b,r6
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,b,00105$
;00119$:
; Peephole 200   removed redundant sjmp
00120$:
;	genLabel 
00107$:
;	_strrchr.c:39: if (*string == ch)                /* char found ? */
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
	mov	r6,a
;	genCmpEq 
	mov	dptr,#_strrchr_PARM_2
;	gencjneshort
	mov	b,r6
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,b,00109$
;00121$:
; Peephole 200   removed redundant sjmp
00122$:
;	_strrchr.c:40: return( (char *)string );
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00110$
00109$:
;	_strrchr.c:42: return (NULL) ;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
;	genLabel 
00110$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
