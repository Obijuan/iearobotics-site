;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:56:12 2005
;--------------------------------------------------------
	.module asinf
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _asinf
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'asinf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 2
;sloc0                     Allocated to stack - offset -4
;------------------------------------------------------------
;asinf.c:25: float asinf(const float x) _FLOAT_FUNC_REENTRANT
;	-----------------------------------------
;	 function asinf
;	-----------------------------------------
_asinf:
	ais	#-4
;asinf.c:27: if(x== 1.0) return  HALF_PI;
	lda	7,s
	sta	___fseq_PARM_1
	lda	8,s
	sta	(___fseq_PARM_1 + 1)
	lda	9,s
	sta	(___fseq_PARM_1 + 2)
	lda	10,s
	sta	(___fseq_PARM_1 + 3)
	lda	#0x3F
	sta	___fseq_PARM_2
	lda	#0x80
	sta	(___fseq_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fseq_PARM_2 + 2)
	sta	(___fseq_PARM_2 + 3)
	jsr	___fseq
	tsta
; Peephole 2d	- eliminated jmp
	beq	00108$
00115$:
	clr	*__ret3
	clr	*__ret2
	ldx	#0x0F
	lda	#0xDB
	jmp	00110$
00108$:
;asinf.c:28: else if(x==-1.0) return -HALF_PI;
	lda	7,s
	sta	___fseq_PARM_1
	lda	8,s
	sta	(___fseq_PARM_1 + 1)
	lda	9,s
	sta	(___fseq_PARM_1 + 2)
	lda	10,s
	sta	(___fseq_PARM_1 + 3)
	lda	#0xBF
	sta	___fseq_PARM_2
	lda	#0x80
	sta	(___fseq_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fseq_PARM_2 + 2)
	sta	(___fseq_PARM_2 + 3)
	jsr	___fseq
	tsta
; Peephole 2d	- eliminated jmp
	beq	00105$
00116$:
	mov	#0xBF,*__ret3
	mov	#0xC9,*__ret2
	ldx	#0x0F
	lda	#0xDB
	jmp	00110$
00105$:
;asinf.c:29: else if(x== 0.0) return 0.0;
	lda	7,s
	sta	___fseq_PARM_1
	lda	8,s
	sta	(___fseq_PARM_1 + 1)
	lda	9,s
	sta	(___fseq_PARM_1 + 2)
	lda	10,s
	sta	(___fseq_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fseq_PARM_2
	sta	(___fseq_PARM_2 + 1)
	sta	(___fseq_PARM_2 + 2)
	sta	(___fseq_PARM_2 + 3)
	jsr	___fseq
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00117$:
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
; Peephole 3	- shortened jmp to bra
	bra	00110$
00102$:
;asinf.c:30: else return asincosf(x,0);
	lda	7,s
	sta	_asincosf_PARM_1
	lda	8,s
	sta	(_asincosf_PARM_1 + 1)
	lda	9,s
	sta	(_asincosf_PARM_1 + 2)
	lda	10,s
	sta	(_asincosf_PARM_1 + 3)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	_asincosf_PARM_2
	sta	(_asincosf_PARM_2 + 1)
	jsr	_asincosf
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	*__ret3
	lda	2,s
	sta	*__ret2
	ldx	3,s
	lda	4,s
00110$:
	ais	#4
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
