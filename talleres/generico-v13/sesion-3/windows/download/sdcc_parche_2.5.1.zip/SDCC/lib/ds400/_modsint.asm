;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:01 2005
;--------------------------------------------------------
	.module _modsint
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __modsint_PARM_2
	.globl __modsint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__modsint_PARM_2::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_modsint'
;------------------------------------------------------------
;b                         Allocated with name '__modsint_PARM_2'
;a                         Allocated to registers r2 r3 
;r                         Allocated to registers r2 r3 
;------------------------------------------------------------
;	_modsint.c:199: int _modsint (int a, int b)
;	genFunction 
;	-----------------------------------------
;	 function _modsint
;	-----------------------------------------
__modsint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
;	_modsint.c:203: r = _moduint((a < 0 ? -a : a),
;	genCmpLt 
;	genCmp
	mov	a,dph
	rlc	a
	clr	a
	rlc	a
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r4,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00113$:
;	genUminus 
	clr	c
	clr	a
	subb	a,dpl
	mov	r5,a
	clr	a
	subb	a,dph
	mov	r6,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00106$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r5,dpl
	mov	r6,dph
;	genLabel 
00107$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl1,r5
	mov	dph1,r6
;	_modsint.c:204: (b < 0 ? -b : b));
;	genCmpLt 
	mov	dptr,#__modsint_PARM_2
;	genCmp
	inc	dptr
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00108$
00114$:
;	genUminus 
	mov	dptr,#__modsint_PARM_2
	movx	a,@dptr
	setb	c
	cpl	a
	addc	a,#0
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	mov	r6,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00108$:
;	genAssign 
	mov	dptr,#__modsint_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genLabel 
00109$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__moduint_PARM_2
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	genCall 
	push	ar4
;	genSend argreg = 1, size = 2 
	mov	dpl,dpl1
	mov	dph,dph1
	lcall	__moduint
	mov	r2,dpl
	mov	r3,dph
	pop	ar4
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,r2
	mov	dph,r3
;	_modsint.c:206: if (a < 0)
;	genIfx 
	mov	a,r4
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00115$:
;	_modsint.c:207: return -r;
;	genUminus 
	clr	c
	clr	a
	subb	a,dpl
	mov	dpl1,a
	clr	a
	subb	a,dph
	mov	dph1,a
;	genRet 
	mov	dpl,dpl1
	mov	dph,dph1
;	genLabel 
; Peephole 132   changed ljmp to sjmp
;	_modsint.c:209: return r;
;	genRet 
;	genLabel 
; Peephole 201   removed redundant sjmp
00102$:
00104$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
