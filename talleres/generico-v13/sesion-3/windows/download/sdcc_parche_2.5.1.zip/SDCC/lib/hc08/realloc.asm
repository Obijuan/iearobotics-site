;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:53 2005
;--------------------------------------------------------
	.module realloc
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc_PARM_2
	.globl _realloc
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_realloc_sloc0_1_0::
	.ds 2
_realloc_sloc1_1_0::
	.ds 2
_realloc_sloc2_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_realloc_PARM_2::
	.ds 2
_realloc_p_1_1::
	.ds 2
_realloc_pthis_1_1::
	.ds 2
_realloc_pnew_1_1::
	.ds 2
_realloc_ret_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'realloc'
;------------------------------------------------------------
;sloc0                     Allocated with name '_realloc_sloc0_1_0'
;sloc1                     Allocated with name '_realloc_sloc1_1_0'
;sloc2                     Allocated with name '_realloc_sloc2_1_0'
;size                      Allocated with name '_realloc_PARM_2'
;p                         Allocated with name '_realloc_p_1_1'
;pthis                     Allocated with name '_realloc_pthis_1_1'
;pnew                      Allocated with name '_realloc_pnew_1_1'
;ret                       Allocated with name '_realloc_ret_1_1'
;------------------------------------------------------------
;realloc.c:67: void xdata * realloc (void * p, size_t size)
;	-----------------------------------------
;	 function realloc
;	-----------------------------------------
_realloc:
	sta	(_realloc_p_1_1 + 1)
	stx	_realloc_p_1_1
;realloc.c:75: pthis = _sdcc_find_memheader(p);
	ldx	_realloc_p_1_1
	lda	(_realloc_p_1_1 + 1)
	jsr	__sdcc_find_memheader
	sta	(_realloc_pthis_1_1 + 1)
	stx	_realloc_pthis_1_1
;realloc.c:76: if (pthis)
	lda	(_realloc_pthis_1_1 + 1)
	ora	_realloc_pthis_1_1
	bne	00124$
	jmp	00114$
00124$:
;realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
	lda	#0xFB
	sub	(_realloc_PARM_2 + 1)
	lda	#0xFF
	sbc	_realloc_PARM_2
; Peephole 2a	- eliminated jmp
	bcc	00111$
00125$:
;realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
; Peephole 5c   - eliminated redundant clra
	clra
	sta	_realloc_ret_1_1
	sta	(_realloc_ret_1_1 + 1)
	jmp	00115$
00111$:
;realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
	lda	(_realloc_PARM_2 + 1)
	add	#0x04
	sta	(_realloc_PARM_2 + 1)
	bcc	00126$
	lda	_realloc_PARM_2
	inca
	sta	_realloc_PARM_2
00126$:
;realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
	lda	_realloc_pthis_1_1
	ldx	(_realloc_pthis_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	*_realloc_sloc0_1_0
	lda	,x
	sta	*(_realloc_sloc0_1_0 + 1)
	lda	(_realloc_pthis_1_1 + 1)
	sta	*(_realloc_sloc1_1_0 + 1)
	lda	_realloc_pthis_1_1
	sta	*_realloc_sloc1_1_0
	lda	*(_realloc_sloc0_1_0 + 1)
	sub	*(_realloc_sloc1_1_0 + 1)
	sta	*(_realloc_sloc1_1_0 + 1)
	lda	*_realloc_sloc0_1_0
	sbc	*_realloc_sloc1_1_0
	sta	*_realloc_sloc1_1_0
	lda	*(_realloc_sloc1_1_0 + 1)
	sub	(_realloc_PARM_2 + 1)
	lda	*_realloc_sloc1_1_0
	sbc	_realloc_PARM_2
; Peephole 2b	- eliminated jmp
	bcs	00108$
00127$:
;realloc.c:88: pthis->len = size;
	lda	(_realloc_pthis_1_1 + 1)
	add	#0x02
	sta	*(_realloc_sloc1_1_0 + 1)
	lda	_realloc_pthis_1_1
	adc	#0x00
	sta	*_realloc_sloc1_1_0
	ldhx	*_realloc_sloc1_1_0
	lda	_realloc_PARM_2
	sta	,x
	aix	#1
	lda	(_realloc_PARM_2 + 1)
	sta	,x
;realloc.c:89: ret = p;
	lda	_realloc_p_1_1
	sta	_realloc_ret_1_1
	lda	(_realloc_p_1_1 + 1)
	sta	(_realloc_ret_1_1 + 1)
	jmp	00115$
00108$:
;realloc.c:93: if ((_sdcc_prev_memheader) &&
	lda	(__sdcc_prev_memheader + 1)
	ora	__sdcc_prev_memheader
	bne	00128$
	jmp	00104$
00128$:
;realloc.c:94: ((((unsigned int)pthis->next) -
	lda	_realloc_pthis_1_1
	ldx	(_realloc_pthis_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	*_realloc_sloc1_1_0
	lda	,x
	sta	*(_realloc_sloc1_1_0 + 1)
;realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
	lda	(__sdcc_prev_memheader + 1)
	sta	*(_realloc_sloc0_1_0 + 1)
	lda	__sdcc_prev_memheader
	sta	*_realloc_sloc0_1_0
	lda	*(_realloc_sloc1_1_0 + 1)
	sub	*(_realloc_sloc0_1_0 + 1)
	sta	*(_realloc_sloc1_1_0 + 1)
	lda	*_realloc_sloc1_1_0
	sbc	*_realloc_sloc0_1_0
	sta	*_realloc_sloc1_1_0
;realloc.c:96: _sdcc_prev_memheader->len) >= size))
	lda	__sdcc_prev_memheader
	sta	*_realloc_sloc0_1_0
	lda	(__sdcc_prev_memheader + 1)
	sta	*(_realloc_sloc0_1_0 + 1)
	ldhx	*_realloc_sloc0_1_0
	aix	#2
	sthx	*_realloc_sloc2_1_0
	ldhx	*_realloc_sloc2_1_0
	lda	,x
	aix	#1
	sta	*_realloc_sloc2_1_0
	lda	,x
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	*(_realloc_sloc1_1_0 + 1)
	sub	*(_realloc_sloc2_1_0 + 1)
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	*_realloc_sloc1_1_0
	sbc	*_realloc_sloc2_1_0
	sta	*_realloc_sloc2_1_0
	lda	*(_realloc_sloc2_1_0 + 1)
	sub	(_realloc_PARM_2 + 1)
	lda	*_realloc_sloc2_1_0
	sbc	_realloc_PARM_2
	bcc	00129$
	jmp	00104$
00129$:
;realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
	lda	*_realloc_sloc0_1_0
	sta	__sdcc_prev_memheader
	lda	*(_realloc_sloc0_1_0 + 1)
	sta	(__sdcc_prev_memheader + 1)
	lda	(__sdcc_prev_memheader + 1)
	add	#0x02
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	__sdcc_prev_memheader
	adc	#0x00
	sta	*_realloc_sloc2_1_0
	ldhx	*_realloc_sloc2_1_0
	lda	,x
	aix	#1
	sta	*_realloc_sloc2_1_0
	lda	,x
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	(__sdcc_prev_memheader + 1)
	add	*(_realloc_sloc2_1_0 + 1)
	sta	(_realloc_pnew_1_1 + 1)
	lda	__sdcc_prev_memheader
	adc	*_realloc_sloc2_1_0
	sta	_realloc_pnew_1_1
;realloc.c:99: _sdcc_prev_memheader->next = pnew;
	lda	__sdcc_prev_memheader
	ldx	(__sdcc_prev_memheader + 1)
	psha
	pulh
	lda	_realloc_pnew_1_1
	sta	,x
	aix	#1
	lda	(_realloc_pnew_1_1 + 1)
	sta	,x
;realloc.c:100: memmove(pnew, pthis, pthis->len);
	lda	(_realloc_pthis_1_1 + 1)
	add	#0x02
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	_realloc_pthis_1_1
	adc	#0x00
	sta	*_realloc_sloc2_1_0
	ldhx	*_realloc_sloc2_1_0
	lda	,x
	aix	#1
	sta	_memmove_PARM_3
	lda	,x
	sta	(_memmove_PARM_3 + 1)
	lda	_realloc_pthis_1_1
	sta	_memmove_PARM_2
	lda	(_realloc_pthis_1_1 + 1)
	sta	(_memmove_PARM_2 + 1)
	ldx	_realloc_pnew_1_1
	lda	(_realloc_pnew_1_1 + 1)
	jsr	_memmove
;realloc.c:101: pnew->len = size;
	lda	(_realloc_pnew_1_1 + 1)
	add	#0x02
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	_realloc_pnew_1_1
	adc	#0x00
	sta	*_realloc_sloc2_1_0
	ldhx	*_realloc_sloc2_1_0
	lda	_realloc_PARM_2
	sta	,x
	aix	#1
	lda	(_realloc_PARM_2 + 1)
	sta	,x
;realloc.c:102: ret = MEM(pnew);
	lda	(_realloc_pnew_1_1 + 1)
	add	#0x04
	sta	(_realloc_ret_1_1 + 1)
	lda	_realloc_pnew_1_1
	adc	#0x00
	sta	_realloc_ret_1_1
	jmp	00115$
00104$:
;realloc.c:106: ret = malloc(size - HEADER_SIZE);
	lda	(_realloc_PARM_2 + 1)
	sub	#0x04
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	_realloc_PARM_2
	sbc	#0x00
	sta	*_realloc_sloc2_1_0
	ldx	*_realloc_sloc2_1_0
	lda	*(_realloc_sloc2_1_0 + 1)
	jsr	_malloc
	sta	(_realloc_ret_1_1 + 1)
	stx	_realloc_ret_1_1
;realloc.c:107: if (ret)
	lda	(_realloc_ret_1_1 + 1)
	ora	_realloc_ret_1_1
; Peephole 2d	- eliminated jmp
	beq	00115$
00130$:
;realloc.c:109: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
	lda	(_realloc_pthis_1_1 + 1)
	add	#0x04
	sta	(_memcpy_PARM_2 + 1)
	lda	_realloc_pthis_1_1
	adc	#0x00
	sta	_memcpy_PARM_2
	lda	(_realloc_pthis_1_1 + 1)
	add	#0x02
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	_realloc_pthis_1_1
	adc	#0x00
	sta	*_realloc_sloc2_1_0
	ldhx	*_realloc_sloc2_1_0
	lda	,x
	aix	#1
	sta	*_realloc_sloc2_1_0
	lda	,x
	sta	*(_realloc_sloc2_1_0 + 1)
	lda	*(_realloc_sloc2_1_0 + 1)
	sub	#0x04
	sta	(_memcpy_PARM_3 + 1)
	lda	*_realloc_sloc2_1_0
	sbc	#0x00
	sta	_memcpy_PARM_3
	ldx	_realloc_ret_1_1
	lda	(_realloc_ret_1_1 + 1)
	jsr	_memcpy
;realloc.c:110: free(p);
	ldx	_realloc_p_1_1
	lda	(_realloc_p_1_1 + 1)
	jsr	_free
; Peephole 3	- shortened jmp to bra
	bra	00115$
00114$:
;realloc.c:118: ret = malloc(size);
	ldx	_realloc_PARM_2
	lda	(_realloc_PARM_2 + 1)
	jsr	_malloc
	sta	(_realloc_ret_1_1 + 1)
	stx	_realloc_ret_1_1
00115$:
;realloc.c:121: return ret;
	ldx	_realloc_ret_1_1
	lda	(_realloc_ret_1_1 + 1)
00116$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
