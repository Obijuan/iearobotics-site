;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:59 2005
;--------------------------------------------------------
	.module _atol
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atol
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_atol_sloc0_1_0::
	.ds 2
_atol_sloc1_1_0::
	.ds 4
_atol_sloc2_1_0::
	.ds 2
_atol_sloc3_1_0::
	.ds 4
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_atol_s_1_1::
	.ds 2
_atol_rv_1_1::
	.ds 4
_atol_sign_1_1::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atol'
;------------------------------------------------------------
;sloc0                     Allocated with name '_atol_sloc0_1_0'
;sloc1                     Allocated with name '_atol_sloc1_1_0'
;sloc2                     Allocated with name '_atol_sloc2_1_0'
;sloc3                     Allocated with name '_atol_sloc3_1_0'
;s                         Allocated with name '_atol_s_1_1'
;rv                        Allocated with name '_atol_rv_1_1'
;sign                      Allocated with name '_atol_sign_1_1'
;------------------------------------------------------------
;_atol.c:25: long atol(char * s)
;	-----------------------------------------
;	 function atol
;	-----------------------------------------
_atol:
	sta	(_atol_s_1_1 + 1)
	stx	_atol_s_1_1
;_atol.c:27: register long rv=0; 
; Peephole 5a   - eliminated redundant clra
	clra
	sta	_atol_rv_1_1
	sta	(_atol_rv_1_1 + 1)
	sta	(_atol_rv_1_1 + 2)
	sta	(_atol_rv_1_1 + 3)
;_atol.c:31: while (*s) {
	lda	_atol_s_1_1
	sta	*_atol_sloc0_1_0
	lda	(_atol_s_1_1 + 1)
	sta	*(_atol_sloc0_1_0 + 1)
00107$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
; Peephole 2d	- eliminated jmp
	beq	00109$
00133$:
;_atol.c:32: if (*s <= '9' && *s >= '0')
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x39
; Peephole 2i	- eliminated bra
	bgt	00102$
00134$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x30
; Peephole 2l	- eliminated bra
	bge	00109$
00135$:
;_atol.c:33: break;
00102$:
;_atol.c:34: if (*s == '-' || *s == '+') 
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x2D
; Peephole 2d	- eliminated jmp
	beq	00109$
00136$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x2B
; Peephole 2d	- eliminated jmp
	beq	00109$
00137$:
;_atol.c:36: s++;
	ldhx	*_atol_sloc0_1_0
	aix	#1
	sthx	*_atol_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00107$
00109$:
;_atol.c:39: sign = (*s == '-');
	lda	*_atol_sloc0_1_0
	sta	_atol_s_1_1
	lda	*(_atol_sloc0_1_0 + 1)
	sta	(_atol_s_1_1 + 1)
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x2D
	beq	00139$
	clra
	bra	00138$
00139$:
	lda	#0x01
00138$:
	sta	_atol_sign_1_1
;_atol.c:40: if (*s == '-' || *s == '+') s++;
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x2D
; Peephole 2d	- eliminated jmp
	beq	00110$
00140$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x2B
; Peephole 2c	- eliminated jmp
	bne	00131$
00141$:
00110$:
	lda	(_atol_s_1_1 + 1)
	inca
	sta	(_atol_s_1_1 + 1)
	bne	00142$
	lda	_atol_s_1_1
	inca
	sta	_atol_s_1_1
00142$:
;_atol.c:42: while (*s && *s >= '0' && *s <= '9') {
00131$:
	lda	_atol_s_1_1
	sta	*_atol_sloc0_1_0
	lda	(_atol_s_1_1 + 1)
	sta	*(_atol_sloc0_1_0 + 1)
00115$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	bne	00143$
	jmp	00117$
00143$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x30
	bge	00144$
	jmp	00117$
00144$:
	ldhx	*_atol_sloc0_1_0
	lda	,x
	cmp	#0x39
	ble	00145$
	jmp	00117$
00145$:
;_atol.c:43: rv = (rv * 10) + (*s - '0');
	lda	_atol_rv_1_1
	sta	__mullong_PARM_1
	lda	(_atol_rv_1_1 + 1)
	sta	(__mullong_PARM_1 + 1)
	lda	(_atol_rv_1_1 + 2)
	sta	(__mullong_PARM_1 + 2)
	lda	(_atol_rv_1_1 + 3)
	sta	(__mullong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__mullong_PARM_2
	sta	(__mullong_PARM_2 + 1)
	sta	(__mullong_PARM_2 + 2)
	lda	#0x0A
	sta	(__mullong_PARM_2 + 3)
	jsr	__mullong
	sta	*(_atol_sloc1_1_0 + 3)
	stx	*(_atol_sloc1_1_0 + 2)
	mov	*__ret2,*(_atol_sloc1_1_0 + 1)
	mov	*__ret3,*_atol_sloc1_1_0
	ldhx	*_atol_sloc0_1_0
	lda	,x
	aix	#1
	sthx	*_atol_sloc0_1_0
	sta	*(_atol_sloc2_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atol_sloc2_1_0
	lda	*(_atol_sloc2_1_0 + 1)
	sub	#0x30
	sta	*(_atol_sloc2_1_0 + 1)
	lda	*_atol_sloc2_1_0
	sbc	#0x00
	sta	*_atol_sloc2_1_0
	mov	*(_atol_sloc2_1_0 + 1),*(_atol_sloc3_1_0 + 3)
	mov	*_atol_sloc2_1_0,*(_atol_sloc3_1_0 + 2)
	lda	*_atol_sloc2_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_atol_sloc3_1_0 + 1)
	sta	*_atol_sloc3_1_0
	lda	*(_atol_sloc1_1_0 + 3)
	add	*(_atol_sloc3_1_0 + 3)
	sta	(_atol_rv_1_1 + 3)
	lda	*(_atol_sloc1_1_0 + 2)
	adc	*(_atol_sloc3_1_0 + 2)
	sta	(_atol_rv_1_1 + 2)
	lda	*(_atol_sloc1_1_0 + 1)
	adc	*(_atol_sloc3_1_0 + 1)
	sta	(_atol_rv_1_1 + 1)
	lda	*_atol_sloc1_1_0
	adc	*_atol_sloc3_1_0
	sta	_atol_rv_1_1
;_atol.c:44: s++;
	jmp	00115$
00117$:
;_atol.c:47: return (sign ? -rv : rv);
	lda	_atol_sign_1_1
; Peephole 2d	- eliminated jmp
	beq	00120$
00146$:
	clra
	sub	(_atol_rv_1_1 + 3)
	sta	*(_atol_sloc3_1_0 + 3)
	clra
	sbc	(_atol_rv_1_1 + 2)
	sta	*(_atol_sloc3_1_0 + 2)
	clra
	sbc	(_atol_rv_1_1 + 1)
	sta	*(_atol_sloc3_1_0 + 1)
	clra
	sbc	_atol_rv_1_1
	sta	*_atol_sloc3_1_0
; Peephole 3	- shortened jmp to bra
	bra	00121$
00120$:
	lda	_atol_rv_1_1
	sta	*_atol_sloc3_1_0
	lda	(_atol_rv_1_1 + 1)
	sta	*(_atol_sloc3_1_0 + 1)
	lda	(_atol_rv_1_1 + 2)
	sta	*(_atol_sloc3_1_0 + 2)
	lda	(_atol_rv_1_1 + 3)
	sta	*(_atol_sloc3_1_0 + 3)
00121$:
	mov	*_atol_sloc3_1_0,*__ret3
	mov	*(_atol_sloc3_1_0 + 1),*__ret2
	ldx	*(_atol_sloc3_1_0 + 2)
	lda	*(_atol_sloc3_1_0 + 3)
00118$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
