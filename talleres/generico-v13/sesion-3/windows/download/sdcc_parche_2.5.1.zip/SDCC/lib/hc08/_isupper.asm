;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:21 2005
;--------------------------------------------------------
	.module _isupper
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _isupper
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_isupper_c_1_1::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'isupper'
;------------------------------------------------------------
;c                         Allocated with name '_isupper_c_1_1'
;------------------------------------------------------------
;_isupper.c:24: char isupper (unsigned char c) 
;	-----------------------------------------
;	 function isupper
;	-----------------------------------------
_isupper:
	sta	_isupper_c_1_1
;_isupper.c:27: if ( c >= 'A' && c <= 'Z') 	
	lda	_isupper_c_1_1
	cmp	#0x41
; Peephole 2b	- eliminated jmp
	bcs	00102$
00108$:
	lda	_isupper_c_1_1
	cmp	#0x5A
; Peephole 2g	- eliminated bra
	bhi	00102$
00109$:
;_isupper.c:28: return 1;
	lda	#0x01
; Peephole 3	- shortened jmp to bra
; Peephole 6b  - replaced jmp to rts with rts
	rts
00102$:
;_isupper.c:29: return 0;
	clra
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
