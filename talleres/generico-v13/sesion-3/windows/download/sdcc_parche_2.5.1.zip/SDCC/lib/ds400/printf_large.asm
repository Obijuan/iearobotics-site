;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:48 2005
;--------------------------------------------------------
	.module printf_large
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __print_format_PARM_4
	.globl __print_format_PARM_3
	.globl __print_format_PARM_2
	.globl _output_float_PARM_3
	.globl _output_float_PARM_2
	.globl _output_float_PARM_7
	.globl _output_float_PARM_6
	.globl _output_float_PARM_5
	.globl _output_float_PARM_4
	.globl __print_format
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_P4	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_DPL1	=	0x0084
_DPH1	=	0x0085
_DPS	=	0x0086
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_CKCON	=	0x008e
_P1	=	0x0090
_EXIF	=	0x0091
_P4CNT	=	0x0092
_DPX	=	0x0093
_DPX1	=	0x0095
_SCON0	=	0x0098
_SBUF0	=	0x0099
_ESP	=	0x009b
_AP	=	0x009c
_ACON	=	0x009d
_P2	=	0x00a0
_P5	=	0x00a1
_P5CNT	=	0x00a2
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_SCON1	=	0x00c0
_SBUF1	=	0x00c1
_PMR	=	0x00c4
_MCON	=	0x00c6
_TA	=	0x00c7
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2L	=	0x00ca
_RTL2	=	0x00ca
_RCAP2H	=	0x00cb
_RTH2	=	0x00cb
_TL2	=	0x00cc
_TH2	=	0x00cd
_PSW	=	0x00d0
_MCNT0	=	0x00d1
_MCNT1	=	0x00d2
_MA	=	0x00d3
_MB	=	0x00d4
_MC	=	0x00d5
_WDCON	=	0x00d8
_ACC	=	0x00e0
_EIE	=	0x00e8
_MXAX	=	0x00ea
_B	=	0x00f0
_EIP	=	0x00f8
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_T2	=	0x0090
_T2EX	=	0x0091
_RXD1	=	0x0092
_TXD1	=	0x0093
_INT2	=	0x0094
_INT3	=	0x0095
_INT4	=	0x0096
_INT5	=	0x0097
_RI_0	=	0x0098
_TI_0	=	0x0099
_RB8_0	=	0x009a
_TB8_0	=	0x009b
_REN_0	=	0x009c
_SM2_0	=	0x009d
_SM1_0	=	0x009e
_SM0_0	=	0x009f
_FE_0	=	0x009f
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES0	=	0x00ac
_ET2	=	0x00ad
_ES1	=	0x00ae
_EA	=	0x00af
_RXD0	=	0x00b0
_TXD0	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS0	=	0x00bc
_PT2	=	0x00bd
_PS1	=	0x00be
_RI_1	=	0x00c0
_TI_1	=	0x00c1
_RB8_1	=	0x00c2
_TB8_1	=	0x00c3
_REN_1	=	0x00c4
_SM2_1	=	0x00c5
_SM1_1	=	0x00c6
_SM0_1	=	0x00c7
_FE_1	=	0x00c7
_CP_RL	=	0x00c8
_C_T	=	0x00c9
_TR2	=	0x00ca
_EXEN2	=	0x00cb
_TCLK	=	0x00cc
_RCLK	=	0x00cd
_EXF2	=	0x00ce
_TF2	=	0x00cf
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_RWT	=	0x00d8
_EWT	=	0x00d9
_WDRF	=	0x00da
_WDIF	=	0x00db
_PFI	=	0x00dc
_EPFI	=	0x00dd
_POR	=	0x00de
_SMOD_1	=	0x00df
_EX2	=	0x00e8
_EX3	=	0x00e9
_EX4	=	0x00ea
_EX5	=	0x00eb
_EWDI	=	0x00ec
_C1IE	=	0x00ed
_C0IE	=	0x00ee
_CANBIE	=	0x00ef
_PX2	=	0x00f8
_PX3	=	0x00f9
_PX4	=	0x00fa
_PX5	=	0x00fb
_PWDI	=	0x00fc
_C1IP	=	0x00fd
_C0IP	=	0x00fe
_CANBIP	=	0x00ff
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_lower_case:
	.ds 1
_output_float_PARM_4::
	.ds 1
_output_float_PARM_5::
	.ds 1
_output_float_PARM_6::
	.ds 1
_output_float_PARM_7::
	.ds 1
__print_format_left_justify_1_1::
	.ds 1
__print_format_zero_padding_1_1::
	.ds 1
__print_format_prefix_sign_1_1::
	.ds 1
__print_format_prefix_space_1_1::
	.ds 1
__print_format_signed_argument_1_1::
	.ds 1
__print_format_char_argument_1_1::
	.ds 1
__print_format_long_argument_1_1::
	.ds 1
__print_format_float_argument_1_1::
	.ds 1
__print_format_lsd_1_1::
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_output_char:
	.ds 3
_p:
	.ds 4
_value:
	.ds 5
_output_float_PARM_2::
	.ds 1
_output_float_PARM_3::
	.ds 1
_output_float_f_1_1::
	.ds 4
_output_float_negative_1_1::
	.ds 1
_output_float_integerPart_1_1::
	.ds 4
_output_float_decimalPart_1_1::
	.ds 4
_output_float_fpBuffer_1_1::
	.ds 128
_output_float_charsOutputted_1_1::
	.ds 2
_output_float_sloc1_1_0::
	.ds 4
_output_float_sloc2_1_0::
	.ds 4
__print_format_PARM_2::
	.ds 4
__print_format_PARM_3::
	.ds 4
__print_format_PARM_4::
	.ds 4
__print_format_radix_1_1::
	.ds 1
__print_format_charsOutputted_1_1::
	.ds 2
__print_format_width_1_1::
	.ds 1
__print_format_decimals_1_1::
	.ds 1
__print_format_store_4_22::
	.ds 6
__print_format_pstore_4_22::
	.ds 3
__print_format_sloc1_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'output_digit'
;------------------------------------------------------------
;n                         Allocated to registers r2 
;------------------------------------------------------------
;	printf_large.c:80: static void output_digit( unsigned char n )
;	genFunction 
;	-----------------------------------------
;	 function output_digit
;	-----------------------------------------
_output_digit:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
;	printf_large.c:84: (lower_case ? n+(char)('a'-10) : n+(char)('A'-10)), p );
;	genAssign 
	mov	dptr,#_p
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	printf_large.c:83: output_char( n <= 9 ? '0'+n :
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x09
	subb	a,r2
	clr	a
	rlc	a
;	genNot 
; Peephole 105   removed redundant mov
	mov  r7,a
	cjne	a,#1,00109$
00109$:
	clr	a
	rlc	a
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r7,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00103$
00110$:
;	genPlus 
	mov	a,#0x30
	add	a,r2
	mov	r7,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00104$
00103$:
;	printf_large.c:84: (lower_case ? n+(char)('a'-10) : n+(char)('A'-10)), p );
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _lower_case,00105$
00111$:
;	genPlus 
	mov	a,#0x57
	add	a,r2
	mov	r0,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00106$
00105$:
;	genPlus 
	mov	a,#0x37
	add	a,r2
	mov	r0,a
;	genLabel 
00106$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar7,r0
;	genLabel 
00104$:
;	genIpush 
	push	ar3
	push	ar4
	push	ar5
	push	ar6
;	genPcall 
	mov	a,#00112$
	push	acc
	mov	a,#(00112$ >> 8)
	push	acc
	mov	a,#(00112$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r7
	ret
00112$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_2digits'
;------------------------------------------------------------
;b                         Allocated to registers r2 
;------------------------------------------------------------
;	printf_large.c:98: static void output_2digits( unsigned char b )
;	genFunction 
;	-----------------------------------------
;	 function output_2digits
;	-----------------------------------------
_output_2digits:
;	genReceive 
	mov	r2,dpl
;	printf_large.c:100: output_digit( b>>4   );
;	genRightShift 
;	genRightShiftLiteral (4), size 1
;	genrshOne
	mov	a,r2
	swap	a
	anl	a,#0x0F
	mov	r3,a
;	genCall 
	push	ar2
;	genSend argreg = 1, size = 1 
	mov	dpl,r3
	lcall	_output_digit
	pop	ar2
;	printf_large.c:101: output_digit( b&0x0F );
;	genAnd 
	anl	ar2,#0x0F
;	genCall 
;	genSend argreg = 1, size = 1 
	mov	dpl,r2
	lcall	_output_digit
;	genLabel 
00101$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'calculate_digit'
;------------------------------------------------------------
;radix                     Allocated to registers r2 
;i                         Allocated to registers 
;------------------------------------------------------------
;	printf_large.c:125: static void calculate_digit( unsigned char radix )
;	genFunction 
;	-----------------------------------------
;	 function calculate_digit
;	-----------------------------------------
_calculate_digit:
;	genReceive 
	mov	r2,dpl
;	printf_large.c:129: for( i = 32; i != 0; i-- )
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r3,#0x20
;	genLabel 
00103$:
;	genCmpEq 
;	gencjneshort
	mov	a,r3
	cjne	a,#0x00,00112$
	ljmp	00107$
00112$:
;	printf_large.c:131: value.byte[4] = (value.byte[4] << 1) | ((value.ul >> 31) & 0x01);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genLeftShift 
;	genLeftShiftLiteral (1), size 1
;	genlshOne 
; Peephole 105   removed redundant mov
; Peephole 204   removed redundant mov
	add  a,acc
	mov  r4,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r0,a
	rl	a
	anl	a,#1
;	genOr 
; Peephole 105   removed redundant mov
	mov  r1,a
	orl	ar4,a
;	genPointerSet 
	mov	dptr,#(_value + 0x0004)
	mov	a,r4
	movx	@dptr,a
;	printf_large.c:132: value.ul <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	sjmp	00114$
00113$:
	mov	a,r5
	add	a,acc
	mov	r5,a
	mov	a,r6
	rlc	a
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
00114$:
	djnz	b,00113$
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	printf_large.c:134: if (radix <= value.byte[4] )
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genCmpGt 
;	genCmp
; Peephole 106   removed redundant mov 
	mov  r4,a
	clr  c
	subb	a,r2
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00105$
00115$:
;	printf_large.c:136: value.byte[4] -= radix;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genMinus 
; Peephole 106   removed redundant mov 
	mov  r4,a
	clr  c
	subb	a,r2
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r4,a
	mov  dptr,#(_value + 0x0004)
	movx @dptr,a
;	printf_large.c:137: value.ul |= 1;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	mov	r7,a
;	genOr 
	orl	ar4,#0x01
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genLabel 
00105$:
;	printf_large.c:129: for( i = 32; i != 0; i-- )
;	genMinus 
	dec	r3
;	genGoto 
	ljmp	00103$
;	genLabel 
00107$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'output_float'
;------------------------------------------------------------
;reqWidth                  Allocated with name '_output_float_PARM_2'
;reqDecimals               Allocated with name '_output_float_PARM_3'
;f                         Allocated with name '_output_float_f_1_1'
;negative                  Allocated with name '_output_float_negative_1_1'
;integerPart               Allocated with name '_output_float_integerPart_1_1'
;decimalPart               Allocated with name '_output_float_decimalPart_1_1'
;fpBuffer                  Allocated with name '_output_float_fpBuffer_1_1'
;fpBI                      Allocated to registers r7 
;fpBD                      Allocated to registers 
;minWidth                  Allocated to registers r2 
;i                         Allocated to registers r0 
;charsOutputted            Allocated with name '_output_float_charsOutputted_1_1'
;exp                       Allocated to registers r1 
;sloc0                     Allocated with name '_output_float_sloc0_1_0'
;sloc1                     Allocated with name '_output_float_sloc1_1_0'
;sloc2                     Allocated with name '_output_float_sloc2_1_0'
;sloc3                     Allocated with name '_output_float_sloc3_1_0'
;------------------------------------------------------------
;	printf_large.c:163: static int output_float (float f, unsigned char reqWidth,
;	genFunction 
;	-----------------------------------------
;	 function output_float
;	-----------------------------------------
_output_float:
;	genReceive 
	mov     dps, #1
	mov     dptr, #_output_float_f_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	printf_large.c:168: char negative=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_negative_1_1
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:172: char fpBI=0, fpBD;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r7,#0x00
;	printf_large.c:174: int charsOutputted=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	printf_large.c:177: if (f<0) {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00232$:
;	printf_large.c:178: negative=1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_negative_1_1
	mov	a,#0x01
	movx	@dptr,a
;	printf_large.c:179: f=-f;
;	genUminus 
	mov	dptr,#_output_float_f_1_1
	mov	dps, #1
	mov	dptr, #_output_float_f_1_1
	dec	dps
;	genUminusFloat
	movx	a,@dptr
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	acc.7
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00102$:
;	printf_large.c:182: if (f>0x00ffffff) {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsgt_PARM_2
; Peephole 101   removed redundant mov
	mov  a,#0xFF
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x7F
	movx	@dptr,a
	inc	dptr
	mov	a,#0x4B
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsgt
;	genIfx 
	mov	a,dpl
;	genIfxJump
	jnz	00233$
	ljmp	00111$
00233$:
;	printf_large.c:186: for (exp = 0; f >= 10.0; exp++) f /=10.0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0x00
;	genLabel 
00179$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x20
	movx	@dptr,a
	inc	dptr
	mov	a,#0x41
	movx	@dptr,a
;	genCall 
	push	ar6
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar6
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00196$
00234$:
;	genIpush 
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x20
	movx	@dptr,a
	inc	dptr
	mov	a,#0x41
	movx	@dptr,a
;	genCall 
	push	ar6
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsdiv
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_f_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genPlus 
	inc	r6
;	did genPlusIncr
;	genIpop 
;	genGoto 
	ljmp	00179$
;	genLabel 
00196$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00183$:
;	printf_large.c:187: for (       ; f < 1.0;   exp--) f *=10.0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
	push	ar6
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	mov	r0,dpl
	pop	ar6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar1,r6
;	genIfx 
	mov	a,r0
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00186$
00235$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x20
	movx	@dptr,a
	inc	dptr
	mov	a,#0x41
	movx	@dptr,a
;	genCall 
	push	ar6
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_f_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genMinus 
	dec	r6
;	genGoto 
	ljmp	00183$
;	genLabel 
00186$:
;	printf_large.c:189: if (negative) {
;	genIfx 
	mov	dptr,#_output_float_negative_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00236$:
;	printf_large.c:190: output_char ('-', p);
;	genIpush 
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00237$
	push	acc
	mov	a,#(00237$ >> 8)
	push	acc
	mov	a,#(00237$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00237$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
;	printf_large.c:191: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00106$:
;	printf_large.c:193: if (sign) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_6,00107$
00238$:
;	printf_large.c:194: output_char ('+', p);
;	genIpush 
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00239$
	push	acc
	mov	a,#(00239$ >> 8)
	push	acc
	mov	a,#(00239$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2B
	ret
00239$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
;	printf_large.c:195: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genLabel 
00107$:
;	printf_large.c:198: charsOutputted += OUTPUT_FLOAT(f, 0, reqDecimals, 0, 0, 0, 0);
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_PARM_2
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_output_float_PARM_4
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_output_float_PARM_5
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_output_float_PARM_6
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_output_float_PARM_7
;	genCall 
	push	ar1
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_output_float
	mov	r6,dpl
	mov	r0,dph
	pop	ar1
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r0
	movx	@dptr,a
;	printf_large.c:199: output_char ('e', p);
;	genIpush 
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00240$
	push	acc
	mov	a,#(00240$ >> 8)
	push	acc
	mov	a,#(00240$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x65
	ret
00240$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
;	printf_large.c:200: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:201: if (exp<0) {
;	genCmpLt 
;	genCmp
	mov	a,r1
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00109$
00241$:
;	printf_large.c:202: output_char ('-', p);
;	genIpush 
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00242$
	push	acc
	mov	a,#(00242$ >> 8)
	push	acc
	mov	a,#(00242$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00242$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
;	printf_large.c:203: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:204: exp = -exp;
;	genUminus 
	clr	c
	clr	a
	subb	a,r1
	mov	r1,a
;	genLabel 
00109$:
;	printf_large.c:206: output_char ('0'+exp/10, p);
;	genDiv 
	clr	F0
	mov	b,#0x0a
	mov	a,r1
	jnb	acc.7,00243$
	cpl	F0
	cpl	a
	inc	a
00243$:
	nop	; workaround for DS80C390 div bug.
	div	ab
	jnb	F0,00244$
	cpl	a
	inc	a
00244$:
;	genPlus 
; Peephole 214 reduced some extra movs
; Peephole 215 removed some movs
	add  a,#0x30
	mov  r6,a
;	genIpush 
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00245$
	push	acc
	mov	a,#(00245$ >> 8)
	push	acc
	mov	a,#(00245$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	ret
00245$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
;	printf_large.c:207: output_char ('0'+exp%10, p);
;	genMod 
	mov	b,#0x0a
	mov	a,r1
	clr	F0
	jnb	acc.7,00246$
	setb	F0
	cpl	a
	inc	a
00246$:
	nop	; workaround for DS80C390 div bug.
	div	ab
	mov	a,b
	jnb	F0,00247$
	cpl	a
	inc	a
00247$:
;	genPlus 
; Peephole 214 reduced some extra movs
; Peephole 215 removed some movs
	add  a,#0x30
	mov  r1,a
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00248$
	push	acc
	mov	a,#(00248$ >> 8)
	push	acc
	mov	a,#(00248$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r1
	ret
00248$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:208: charsOutputted += 2;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:209: return charsOutputted;
;	genRet 
	mov     dps, #1
	mov     dptr, #_output_float_charsOutputted_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
	ljmp	00187$
;	genLabel 
00111$:
;	printf_large.c:213: integerPart=f;
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fs2ulong
	mov	r6,dpl
	mov	r0,dph
	mov	r1,dpx
	mov	r2,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_integerPart_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	printf_large.c:214: decimalPart=f-integerPart;
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___ulong2fs
	mov	r6,dpl
	mov	r0,dph
	mov	r1,dpx
	mov	r2,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_f_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fssub
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_decimalPart_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	printf_large.c:217: while (integerPart) {
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0x00
;	genLabel 
00112$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar7,r6
;	genIfx 
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
	jnz	00249$
	ljmp	00114$
00249$:
;	printf_large.c:218: fpBuffer[fpBI++]='0' + integerPart%10;
;	genIpush 
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar0,r6
;	genPlus 
	inc	r6
;	did genPlusIncr
;	genPlus 
	mov	a,r0
	add	a,#_output_float_fpBuffer_1_1
	mov	r0,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 8)
	mov	r1,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 16)
	mov	r2,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x0A
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar6
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__modulong
	pop	ar1
	pop	ar0
	pop	ar6
	pop	ar2
;	genCast 
	mov	r3,dpl
;	genPlus 
	mov	a,#0x30
	add	a,r3
;	genPointerSet 
; Peephole 136a   removed redundant moves
	mov  r3,a
	mov  dpl,r0
	mov  dph,r1
	mov  dpx,r2
	movx	@dptr,a
;	printf_large.c:219: integerPart /= 10;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x0A
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar6
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__divulong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_integerPart_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genIpop 
;	genGoto 
	ljmp	00112$
;	genLabel 
00114$:
;	printf_large.c:221: if (!fpBI) {
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00116$
00250$:
;	printf_large.c:223: fpBuffer[fpBI++]='0';
;	genPlus 
	mov	a,#0x01
	add	a,r6
	mov	r7,a
;	genPlus 
	mov	a,r6
	add	a,#_output_float_fpBuffer_1_1
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 16)
	mov	dpx,a
;	genPointerSet 
	mov	a,#0x30
	movx	@dptr,a
;	genLabel 
00116$:
;	printf_large.c:227: if (reqDecimals==-1)
;	genCmpEq 
	mov	dptr,#_output_float_PARM_3
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0xFF,00118$
;00251$:
; Peephole 200   removed redundant sjmp
00252$:
;	printf_large.c:228: reqDecimals=DEFAULT_FLOAT_PRECISION;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_PARM_3
	mov	a,#0x06
	movx	@dptr,a
;	genLabel 
00118$:
;	printf_large.c:232: if (i=reqDecimals /* that's an assignment */) {
;	genAssign 
	mov	dptr,#_output_float_PARM_3
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	genIfx 
; Peephole 166   removed redundant mov
	mov  r6,a
	mov  ar0,r6 
;	genIfxJump
	jnz	00253$
	ljmp	00123$
00253$:
;	printf_large.c:233: do {
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_sloc2_1_0
	mov	a,r7
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_sloc1_1_0
	mov	a,r6
	movx	@dptr,a
;	genLabel 
00119$:
;	printf_large.c:234: decimalPart *= 10.0;
;	genIpush 
	push	ar7
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x20
	movx	@dptr,a
	inc	dptr
	mov	a,#0x41
	movx	@dptr,a
;	genCall 
	push	ar7
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_decimalPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar7
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_decimalPart_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	printf_large.c:236: integerPart=decimalPart;
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_decimalPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fs2ulong
	mov	r6,dpl
	mov	r7,dph
	mov	r1,dpx
	mov	r2,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_integerPart_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
;	printf_large.c:237: fpBuffer[fpBD++]='0' + integerPart;
;	genAssign 
	mov	dptr,#_output_float_sloc2_1_0
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
;	genPlus 
	mov	dptr,#_output_float_sloc2_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
;	genPlus 
	mov	a,r2
	add	a,#_output_float_fpBuffer_1_1
	mov	dpl1,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 8)
	mov	dph1,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 16)
	mov	dpx1,a
;	genCast 
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
;	genPlus 
; Peephole 214 reduced some extra movs
;	genPointerSet 
; Peephole 105   removed redundant mov
; Peephole 215 removed some movs
	add  a,#0x30
	mov  r5,a
	inc	dps
	movx	@dptr,a
	mov	dps,#0
;	printf_large.c:238: decimalPart-=integerPart;
;	genCall 
	push	ar7
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_integerPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___ulong2fs
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar7
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genCall 
	push	ar7
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_output_float_decimalPart_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fssub
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar7
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_decimalPart_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	printf_large.c:239: } while (--i);
;	genMinus 
	mov	dptr,#_output_float_sloc1_1_0
	movx	a,@dptr
	dec	a
	movx	@dptr,a
;	genAssign 
	mov	dptr,#_output_float_sloc1_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
	mov	r0,a
;	genIpop 
	pop	ar7
;	genIfx 
	mov	dptr,#_output_float_sloc1_1_0
	movx	a,@dptr
;	genIfxJump
	jz	00254$
	ljmp	00119$
00254$:
;	genLabel 
00123$:
;	printf_large.c:242: minWidth=fpBI; // we need at least these
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r7
;	printf_large.c:243: minWidth+=reqDecimals?reqDecimals+1:0; // maybe these
;	genIfx 
	mov	dptr,#_output_float_PARM_3
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00189$
00255$:
;	genPlus 
	mov	dptr,#_output_float_PARM_3
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	mov	r3,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00190$
00189$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r3,#0x00
;	genLabel 
00190$:
;	genPlus 
	mov	a,r3
	add	a,r2
	mov	r2,a
;	printf_large.c:244: if (negative || sign || space)
;	genIfx 
	mov	dptr,#_output_float_negative_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00124$
00256$:
;	genIfx 
;	genIfxJump
; Peephole 112   removed ljmp by inverse jump logic
	jb   _output_float_PARM_6,00124$
00257$:
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_7,00125$
00258$:
;	genLabel 
00124$:
;	printf_large.c:245: minWidth++; // and maybe even this :)
;	genPlus 
	inc	r2
;	did genPlusIncr
;	genLabel 
00125$:
;	printf_large.c:247: if (!left && reqWidth>i) {
;	genIfx 
;	genIfxJump
	jnb	_output_float_PARM_4,00259$
	ljmp	00162$
00259$:
;	genCmpGt 
	mov	dptr,#_output_float_PARM_2
;	genCmp
	clr	c
	mov	a,r0
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
	jc	00260$
	ljmp	00162$
00260$:
;	printf_large.c:248: if (zero) {
;	genIfx 
;	genIfxJump
	jb	_output_float_PARM_5,00261$
	ljmp	00217$
00261$:
;	printf_large.c:249: if (negative)
;	genIfx 
	mov	dptr,#_output_float_negative_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00134$
00262$:
;	printf_large.c:251: output_char('-', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00263$
	push	acc
	mov	a,#(00263$ >> 8)
	push	acc
	mov	a,#(00263$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00263$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:252: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00215$
;	genLabel 
00134$:
;	printf_large.c:254: else if (sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_6,00131$
00264$:
;	printf_large.c:256: output_char('+', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00265$
	push	acc
	mov	a,#(00265$ >> 8)
	push	acc
	mov	a,#(00265$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2B
	ret
00265$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:257: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00215$
00131$:
;	printf_large.c:259: else if (space)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_7,00215$
00266$:
;	printf_large.c:261: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00267$
	push	acc
	mov	a,#(00267$ >> 8)
	push	acc
	mov	a,#(00267$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00267$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:262: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	printf_large.c:264: while (reqWidth-->minWidth)
;	genLabel 
00215$:
;	genAssign 
	mov	dptr,#_output_float_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign 
	mov	dptr,#_output_float_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00136$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_PARM_2
	mov	a,r5
	movx	@dptr,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r6
	clr	a
	rlc	a
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genIfx 
	mov	a,r6
;	genIfxJump
	jnz	00268$
	ljmp	00163$
00268$:
;	printf_large.c:266: output_char('0', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00269$
	push	acc
	mov	a,#(00269$ >> 8)
	push	acc
	mov	a,#(00269$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x30
	ret
00269$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:267: charsOutputted++;
;	genPlus 
	inc	r3
	cjne	r3,#0,00270$
	inc	r4
00270$:
;	did genPlusIncr
;	genGoto 
;	printf_large.c:270: while (reqWidth-->minWidth)
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00136$
00217$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r3,#0x00
	mov	r4,#0x00
;	genAssign 
	mov	dptr,#_output_float_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00139$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_PARM_2
	mov	a,r5
	movx	@dptr,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r6
	clr	a
	rlc	a
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00141$
00271$:
;	printf_large.c:272: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00272$
	push	acc
	mov	a,#(00272$ >> 8)
	push	acc
	mov	a,#(00272$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00272$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:273: charsOutputted++;
;	genPlus 
	inc	r3
	cjne	r3,#0,00273$
	inc	r4
00273$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00139$
00141$:
;	printf_large.c:275: if (negative)
;	genIfx 
	mov	dptr,#_output_float_negative_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00148$
00274$:
;	printf_large.c:277: output_char('-', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00275$
	push	acc
	mov	a,#(00275$ >> 8)
	push	acc
	mov	a,#(00275$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00275$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:278: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	add	a,r3
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	inc	dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00163$
;	genLabel 
00148$:
;	printf_large.c:280: else if (sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_6,00145$
00276$:
;	printf_large.c:282: output_char('+', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00277$
	push	acc
	mov	a,#(00277$ >> 8)
	push	acc
	mov	a,#(00277$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2B
	ret
00277$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:283: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	add	a,r3
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	inc	dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00163$
;	genLabel 
00145$:
;	printf_large.c:285: else if (space)
;	genIfx 
;	genIfxJump
	jb	_output_float_PARM_7,00278$
	ljmp	00163$
00278$:
;	printf_large.c:287: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00279$
	push	acc
	mov	a,#(00279$ >> 8)
	push	acc
	mov	a,#(00279$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00279$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:288: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	add	a,r3
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	inc	dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00163$
;	genLabel 
00162$:
;	printf_large.c:292: if (negative)
;	genIfx 
	mov	dptr,#_output_float_negative_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00159$
00280$:
;	printf_large.c:294: output_char('-', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00281$
	push	acc
	mov	a,#(00281$ >> 8)
	push	acc
	mov	a,#(00281$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00281$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:295: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00163$
;	genLabel 
00159$:
;	printf_large.c:297: else if (sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_6,00156$
00282$:
;	printf_large.c:299: output_char('+', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00283$
	push	acc
	mov	a,#(00283$ >> 8)
	push	acc
	mov	a,#(00283$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2B
	ret
00283$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:300: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00163$
00156$:
;	printf_large.c:302: else if (space)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _output_float_PARM_7,00163$
00284$:
;	printf_large.c:304: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00285$
	push	acc
	mov	a,#(00285$ >> 8)
	push	acc
	mov	a,#(00285$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00285$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar2
;	printf_large.c:305: charsOutputted++;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genLabel 
00163$:
;	printf_large.c:310: i=fpBI-1;
;	genMinus 
	mov	a,r7
	dec	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r0,a
;	printf_large.c:311: do {
;	genAssign 
	mov	dptr,#_output_float_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar5,r0
;	genLabel 
00165$:
;	printf_large.c:312: output_char (fpBuffer[i], p);
;	genPlus 
	mov	a,r5
	add	a,#_output_float_fpBuffer_1_1
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	movx	a,@dptr
	mov	r6,a
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00286$
	push	acc
	mov	a,#(00286$ >> 8)
	push	acc
	mov	a,#(00286$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	ret
00286$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:313: charsOutputted++;
;	genPlus 
	inc	r3
	cjne	r3,#0,00287$
	inc	r4
00287$:
;	did genPlusIncr
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	printf_large.c:314: } while (i--);
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00165$
00288$:
;	printf_large.c:317: if (reqDecimals) {
;	genIfx 
	mov	dptr,#_output_float_PARM_3
	movx	a,@dptr
;	genIfxJump
	jnz	00289$
	ljmp	00172$
00289$:
;	printf_large.c:318: output_char ('.', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00290$
	push	acc
	mov	a,#(00290$ >> 8)
	push	acc
	mov	a,#(00290$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2E
	ret
00290$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:319: charsOutputted++;
;	genPlus 
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,#0x01
	add	a,r3
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r4
	inc	dptr
	movx	@dptr,a
;	printf_large.c:321: while (reqDecimals--)
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar3,r7
;	genAssign 
	mov	dptr,#_output_float_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign 
	mov	dptr,#_output_float_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
;	genLabel 
00168$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar7,r6
;	genMinus 
	dec	r6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genIfx 
	mov	a,r7
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00172$
00291$:
;	printf_large.c:323: output_char (fpBuffer[i++], p);
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar7,r3
;	genPlus 
	inc	r3
;	did genPlusIncr
;	genPlus 
	mov	a,r7
	add	a,#_output_float_fpBuffer_1_1
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_output_float_fpBuffer_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	movx	a,@dptr
	mov	r7,a
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00292$
	push	acc
	mov	a,#(00292$ >> 8)
	push	acc
	mov	a,#(00292$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r7
	ret
00292$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:324: charsOutputted++;
;	genPlus 
	inc	r4
	cjne	r4,#0,00293$
	inc	r5
00293$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00168$
00172$:
;	printf_large.c:328: if (left && reqWidth>minWidth) {
;	genIfx 
;	genIfxJump
	jb	_output_float_PARM_4,00294$
	ljmp	00177$
00294$:
;	genCmpGt 
	mov	dptr,#_output_float_PARM_2
;	genCmp
	clr	c
	mov	a,r2
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 161   removed sjmp by inverse jump logic
	jnc  00177$
00295$:
;	printf_large.c:329: while (reqWidth-->minWidth)
;	genAssign 
	mov	dptr,#_output_float_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
;	genAssign 
	mov	dptr,#_output_float_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00173$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r6
	clr	a
	rlc	a
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_output_float_charsOutputted_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genIfx 
	mov	a,r6
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00177$
00296$:
;	printf_large.c:331: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00297$
	push	acc
	mov	a,#(00297$ >> 8)
	push	acc
	mov	a,#(00297$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00297$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:332: charsOutputted++;
;	genPlus 
	inc	r3
	cjne	r3,#0,00298$
	inc	r4
00298$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00173$
00177$:
;	printf_large.c:335: return charsOutputted;
;	genRet 
	mov     dps, #1
	mov     dptr, #_output_float_charsOutputted_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
;	genLabel 
00187$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function '_print_format'
;------------------------------------------------------------
;pvoid                     Allocated with name '__print_format_PARM_2'
;format                    Allocated with name '__print_format_PARM_3'
;ap                        Allocated with name '__print_format_PARM_4'
;pfn                       Allocated to registers 
;radix                     Allocated with name '__print_format_radix_1_1'
;charsOutputted            Allocated with name '__print_format_charsOutputted_1_1'
;width                     Allocated with name '__print_format_width_1_1'
;decimals                  Allocated with name '__print_format_decimals_1_1'
;length                    Allocated to registers r4 
;c                         Allocated to registers r4 
;store                     Allocated with name '__print_format_store_4_22'
;pstore                    Allocated with name '__print_format_pstore_4_22'
;sloc0                     Allocated with name '__print_format_sloc0_1_0'
;sloc1                     Allocated with name '__print_format_sloc1_1_0'
;------------------------------------------------------------
;	printf_large.c:339: int _print_format (pfn_outputchar pfn, void* pvoid, const char *format, va_list ap)
;	genFunction 
;	-----------------------------------------
;	 function _print_format
;	-----------------------------------------
__print_format:
;	genReceive 
	mov     dps, #1
	mov     dptr, #_output_char
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	mov	dps,#0
;	printf_large.c:367: p = pvoid;
;	genAssign 
	mov	dptr,#__print_format_PARM_2
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_p
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	printf_large.c:371: charsOutputted=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	printf_large.c:374: if (format==0) {
;	genAssign 
	mov	dptr,#__print_format_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genCmpEq 
;	gencjneshort
;	cjneshort: generic ptr special case.
	mov	a,r4
; Peephole 132   changed ljmp to sjmp
; Peephole 195   optimized misc jump sequence
	cjne a,#0x00,00236$
	mov  a,r5
	cjne a,#0x00,00236$
	mov  a,r6
	cjne a,#0x00,00236$
;00299$:
; Peephole 200   removed redundant sjmp
00300$:
;	printf_large.c:375: format=NULL_STRING;
;	genCast 
	mov	dptr,#__print_format_PARM_3
	mov	a,#__str_0
	movx	@dptr,a
	inc	dptr
	mov	a,#(__str_0 >> 8)
	movx	@dptr,a
	inc	dptr
	mov	a,#(__str_0 >> 16)
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
;	printf_large.c:379: while( c=*format++ )
;	genLabel 
00236$:
;	genLabel 
00223$:
;	genAssign 
	mov	dptr,#__print_format_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r6
	mov	b,r7
	lcall	__gptrget
	mov	r0,a
;	genPlus 
	mov	dptr,#__print_format_PARM_3
	mov	a,#0x01
	add	a,r4
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r5
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r6
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r0
;	genIfx 
	mov	a,r0
;	genIfxJump
	jnz	00301$
	ljmp	00225$
00301$:
;	printf_large.c:381: if ( c=='%' )
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x25,00302$
	sjmp	00303$
00302$:
	ljmp	00221$
00303$:
;	printf_large.c:383: left_justify    = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_left_justify_1_1
;	printf_large.c:384: zero_padding    = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_zero_padding_1_1
;	printf_large.c:385: prefix_sign     = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_prefix_sign_1_1
;	printf_large.c:386: prefix_space    = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_prefix_space_1_1
;	printf_large.c:387: signed_argument = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_signed_argument_1_1
;	printf_large.c:388: radix           = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_radix_1_1
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:389: char_argument   = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_char_argument_1_1
;	printf_large.c:390: long_argument   = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_long_argument_1_1
;	printf_large.c:391: float_argument  = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_float_argument_1_1
;	printf_large.c:392: width           = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:393: decimals        = -1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_decimals_1_1
	mov	a,#0xFF
	movx	@dptr,a
;	printf_large.c:395: get_conversion_spec:
;	genAssign 
	mov	dptr,#__print_format_PARM_3
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genLabel 
00103$:
;	printf_large.c:397: c = *format++;
;	genIpush 
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r7
	mov	b,r6
	lcall	__gptrget
	mov	r2,a
	inc	dptr
	mov	r0,dpl
	mov	r1,dph
	mov	r7,dpx
	mov	r6,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_3
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r2
;	printf_large.c:399: if (c=='%') {
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,r4
	cjne	a,#0x25,00304$
	mov	a,#1
	sjmp	00305$
00304$:
	clr	a
00305$:
;	genIpop 
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00105$
00306$:
;	printf_large.c:400: output_char(c, p);
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00307$
	push	acc
	mov	a,#(00307$ >> 8)
	push	acc
	mov	a,#(00307$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r4
	ret
00307$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:401: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:402: continue;
;	genGoto 
	ljmp	00223$
;	genLabel 
00105$:
;	printf_large.c:405: if (isdigit(c)) {
;	genCall 
	push	ar4
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 1 
	mov	dpl,r4
	lcall	_isdigit
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar4
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00112$
00308$:
;	printf_large.c:406: if (decimals==-1) {
;	genCmpEq 
	mov	dptr,#__print_format_decimals_1_1
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0xFF,00109$
;00309$:
; Peephole 200   removed redundant sjmp
00310$:
;	printf_large.c:407: width = 10*width + (c - '0');
;	genIpush 
;	genMult 
	mov	dptr,#__print_format_width_1_1
	mov	b,#0x0A
	movx	a,@dptr
	mul	ab
	mov	r2,a
;	genMinus 
	mov	a,r4
	add	a,#0xD0
	mov	r3,a
;	genPlus 
	mov	dptr,#__print_format_width_1_1
	mov	a,r3
	add	a,r2
	movx	@dptr,a
;	printf_large.c:408: if (width == 0) {
;	genCmpEq 
	mov	dptr,#__print_format_width_1_1
;	gencjne
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x00,00311$
	mov	a,#1
	sjmp	00312$
00311$:
	clr	a
00312$:
;	genIpop 
;	genIfx 
;	genIfxJump
	jnz	00313$
	ljmp	00103$
00313$:
;	printf_large.c:410: zero_padding = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_zero_padding_1_1
;	genGoto 
	ljmp	00103$
;	genLabel 
00109$:
;	printf_large.c:413: decimals = 10*decimals + (c-'0');
;	genIpush 
;	genMult 
	mov	dptr,#__print_format_decimals_1_1
	clr	F0
	mov	b,#0x0A
	movx	a,@dptr
	jnb	acc.7,00314$
	cpl	F0
	cpl	a
	inc	a
00314$:
	mul	ab
	jnb	F0,00315$
	cpl	a
	inc	a
00315$:
	mov	r2,a
;	genMinus 
	mov	a,r4
	add	a,#0xD0
	mov	r3,a
;	genPlus 
	mov	dptr,#__print_format_decimals_1_1
	mov	a,r3
	add	a,r2
	movx	@dptr,a
;	printf_large.c:415: goto get_conversion_spec;
;	genIpop 
;	genGoto 
	ljmp	00103$
;	genLabel 
00112$:
;	printf_large.c:418: if (c=='.') {
;	genCmpEq 
;	gencjneshort
	mov	a,r4
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x2E,00116$
;00316$:
; Peephole 200   removed redundant sjmp
00317$:
;	printf_large.c:419: if (decimals=-1) decimals=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_decimals_1_1
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:422: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	genLabel 
00116$:
;	printf_large.c:425: lower_case = islower(c);
;	genCall 
	push	ar4
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 1 
	mov	dpl,r4
	lcall	_islower
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar4
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	a,dpl
	add	a,#0xFF
	mov	_lower_case,c
;	printf_large.c:426: if (lower_case)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _lower_case,00118$
00318$:
;	printf_large.c:428: c = toupper(c);
;	genAnd 
	anl	ar4,#0xDF
;	genLabel 
00118$:
;	printf_large.c:431: switch( c )
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x20,00319$
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00319$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x2B,00320$
; Peephole 132   changed ljmp to sjmp
	sjmp 00120$
00320$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x2D,00321$
; Peephole 132   changed ljmp to sjmp
	sjmp 00119$
00321$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x42,00322$
; Peephole 132   changed ljmp to sjmp
	sjmp 00122$
00322$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x43,00323$
; Peephole 132   changed ljmp to sjmp
	sjmp 00124$
00323$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x44,00324$
	ljmp	00149$
00324$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x46,00325$
	ljmp	00153$
00325$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x49,00326$
	ljmp	00149$
00326$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x4C,00327$
; Peephole 132   changed ljmp to sjmp
	sjmp 00123$
00327$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x4F,00328$
	ljmp	00150$
00328$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x50,00329$
	ljmp	00147$
00329$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x53,00330$
	ljmp	00125$
00330$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x55,00331$
	ljmp	00151$
00331$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x58,00332$
	ljmp	00152$
00332$:
;	genGoto 
	ljmp	00154$
;	printf_large.c:433: case '-':
;	genLabel 
00119$:
;	printf_large.c:434: left_justify = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_left_justify_1_1
;	printf_large.c:435: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	printf_large.c:436: case '+':
;	genLabel 
00120$:
;	printf_large.c:437: prefix_sign = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_prefix_sign_1_1
;	printf_large.c:438: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	printf_large.c:439: case ' ':
;	genLabel 
00121$:
;	printf_large.c:440: prefix_space = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_prefix_space_1_1
;	printf_large.c:441: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	printf_large.c:442: case 'B':
;	genLabel 
00122$:
;	printf_large.c:443: char_argument = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_char_argument_1_1
;	printf_large.c:444: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	printf_large.c:445: case 'L':
;	genLabel 
00123$:
;	printf_large.c:446: long_argument = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_long_argument_1_1
;	printf_large.c:447: goto get_conversion_spec;
;	genGoto 
	ljmp	00103$
;	printf_large.c:449: case 'C':
;	genLabel 
00124$:
;	printf_large.c:450: output_char( va_arg(ap,int), p );
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus 
	mov	a,r6
	add	a,#0xFE
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
	mov	a,r0
	addc	a,#0xFF
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
;	genCast 
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00333$
	push	acc
	mov	a,#(00333$ >> 8)
	push	acc
	mov	a,#(00333$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	ret
00333$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:451: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:452: break;
;	genGoto 
	ljmp	00155$
;	printf_large.c:454: case 'S':
;	genLabel 
00125$:
;	printf_large.c:455: PTR = va_arg(ap,ptr_t);
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus 
	mov	a,r6
	add	a,#0xFC
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
	mov	a,r0
	addc	a,#0xFF
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
	inc	dptr
	lcall	__gptrgetWord
	mov	r0,_ap
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printf_large.c:458: if (PTR==0) {
;	genCmpEq 
;	gencjneshort
;	cjneshort: generic ptr special case.
	mov	a,r6
; Peephole 132   changed ljmp to sjmp
; Peephole 195   optimized misc jump sequence
	cjne a,#0x0,00127$
	mov  a,r7
	cjne a,#(0x0 >> 8),00127$
	mov  a,r0
	cjne a,#(0x0 >> 16),00127$
;00334$:
; Peephole 200   removed redundant sjmp
00335$:
;	printf_large.c:459: PTR=NULL_STRING;
;	genPointerSet 
	mov	dptr,#_value
	mov	a,#__str_0
	movx	@dptr,a
	inc	dptr
	mov	a,#(__str_0 >> 8)
	movx	@dptr,a
	inc	dptr
	mov	a,#(__str_0 >> 16)
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
;	printf_large.c:460: length=NULL_STRING_LENGTH;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r4,#0x06
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00128$
00127$:
;	printf_large.c:462: length = strlen(PTR);
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	inc	dptr
	mov	r1,a
	movx	a,@dptr
	mov	r2,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r7
	mov	dph,r0
	mov	dpx,r1
	mov	b,r2
	lcall	_strlen
	mov	r2,dpl
	mov	r3,dph
;	genCast 
	mov	ar4,r2
;	printf_large.c:731: return charsOutputted;
;	genIpop 
;	printf_large.c:462: length = strlen(PTR);
;	genLabel 
00128$:
;	printf_large.c:467: if ( decimals == -1 )
;	genCmpEq 
	mov	dptr,#__print_format_decimals_1_1
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0xFF,00130$
;00336$:
; Peephole 200   removed redundant sjmp
00337$:
;	printf_large.c:469: decimals = length;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_decimals_1_1
	mov	a,r4
	movx	@dptr,a
;	genLabel 
00130$:
;	printf_large.c:471: if ( ( !left_justify ) && (length < width) )
;	genIfx 
;	genIfxJump
	jnb	__print_format_left_justify_1_1,00338$
	ljmp	00265$
00338$:
;	genCmpLt 
	mov	dptr,#__print_format_width_1_1
;	genCmp
	clr	c
	mov	a,r4
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
	jc	00339$
	ljmp	00265$
00339$:
;	printf_large.c:473: width -= length;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	clr	c
	movx	a,@dptr
	subb	a,r4
	movx	@dptr,a
;	printf_large.c:474: while( width-- != 0 )
;	genAssign 
	mov	dptr,#__print_format_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r1,a
;	genLabel 
00131$:
;	genIpush 
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar5,r1
;	genMinus 
	dec	r1
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	mov	a,r1
	movx	@dptr,a
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,r5
	cjne	a,#0x00,00340$
	mov	a,#1
	sjmp	00341$
00340$:
	clr	a
00341$:
	mov	r5,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genIfx 
	mov	a,r5
;	genIpop 
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00265$
00342$:
;	printf_large.c:476: output_char( ' ', p );
;	genIpush 
	push	ar4
	push	ar7
	push	ar0
	push	ar1
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00343$
	push	acc
	mov	a,#(00343$ >> 8)
	push	acc
	mov	a,#(00343$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00343$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar4
;	printf_large.c:477: charsOutputted++;
;	genPlus 
	inc	r7
	cjne	r7,#0,00344$
	inc	r0
00344$:
;	did genPlusIncr
;	genGoto 
;	printf_large.c:481: while ( *PTR  && (decimals-- > 0))
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00131$
00265$:
;	genAssign 
	mov	dptr,#__print_format_decimals_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r7,a
;	genAssign 
	mov	dptr,#__print_format_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genLabel 
00138$:
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r5
	mov	dph,r6
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r5,a
;	genIpop 
;	genIfxJump
	jnz	00345$
	ljmp	00140$
00345$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r7
;	genMinus 
	dec	r7
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_decimals_1_1
	mov	a,r7
	movx	@dptr,a
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 159   avoided xrl during execution
	mov  a,#(0x00 ^ 0x80)
	mov	b,r6
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jc	00346$
	ljmp	00140$
00346$:
;	printf_large.c:483: output_char( *PTR++, p );
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	mov	dps, #1
	mov	dptr, #__print_format_sloc1_1_0
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genPlus 
	mov	dptr,#__print_format_sloc1_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #__print_format_sloc1_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
	mov	r5,a
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar7
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00347$
	push	acc
	mov	a,#(00347$ >> 8)
	push	acc
	mov	a,#(00347$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r5
	ret
00347$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar7
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:484: charsOutputted++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00348$
	inc	r3
00348$:
;	did genPlusIncr
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genIpop 
;	genGoto 
	ljmp	00138$
;	genLabel 
00140$:
;	printf_large.c:487: if ( left_justify && (length < width))
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_decimals_1_1
	mov	a,r7
	movx	@dptr,a
;	genIfx 
;	genIfxJump
	jb	__print_format_left_justify_1_1,00349$
	ljmp	00155$
00349$:
;	genCmpLt 
	mov	dptr,#__print_format_width_1_1
;	genCmp
	clr	c
	mov	a,r4
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
	jc	00350$
	ljmp	00155$
00350$:
;	printf_large.c:489: width -= length;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	clr	c
	movx	a,@dptr
	subb	a,r4
	movx	@dptr,a
;	printf_large.c:490: while( width-- != 0 )
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r2
	mov	ar7,r3
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r0,a
;	genLabel 
00141$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar1,r0
;	genMinus 
	dec	r0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	mov	a,r0
	movx	@dptr,a
;	genCmpEq 
;	gencjne
;	gencjneshort
	mov	a,r1
	cjne	a,#0x00,00351$
	mov	a,#1
	sjmp	00352$
00351$:
	clr	a
00352$:
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genIfx 
	mov	a,r1
;	genIfxJump
	jz	00353$
	ljmp	00155$
00353$:
;	printf_large.c:492: output_char( ' ', p );
;	genIpush 
	push	ar6
	push	ar7
	push	ar0
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00354$
	push	acc
	mov	a,#(00354$ >> 8)
	push	acc
	mov	a,#(00354$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00354$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar0
	pop	ar7
	pop	ar6
;	printf_large.c:493: charsOutputted++;
;	genPlus 
	inc	r6
	cjne	r6,#0,00355$
	inc	r7
00355$:
;	did genPlusIncr
;	genGoto 
;	printf_large.c:498: case 'P':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00141$
00147$:
;	printf_large.c:499: PTR = va_arg(ap,ptr_t);
;	genIpush 
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus 
	mov	a,r6
	add	a,#0xFC
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
	mov	a,r0
	addc	a,#0xFF
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
	inc	dptr
	lcall	__gptrgetWord
	mov	r0,_ap
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printf_large.c:502: output_char(memory_id[(value.byte[3] > 3) ? 4 : value.byte[3]], p );
;	genAssign 
	mov	dptr,#_p
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0003)
	movx	a,@dptr
	mov	r2,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,#0x03
	subb	a,r2
;	genIpop 
;	genIfx 
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
; Peephole 128   jump optimization
	jnc  00228$
00356$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r2,#0x04
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00229$
00228$:
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0003)
	movx	a,@dptr
	mov	r2,a
;	genLabel 
00229$:
;	genIpush 
;	genPlus 
	mov	a,r2
; Peephole 3.d   changed mov to clr
; Peephole 3.d   changed mov to clr
;	genPointerGet 
; Peephole 227.a movc optimize
	mov	dptr,#_memory_id
	movc	a,@a+dptr
	mov	r5,a
;	genIpush 
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genPcall 
	mov	a,#00357$
	push	acc
	mov	a,#(00357$ >> 8)
	push	acc
	mov	a,#(00357$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r5
	ret
00357$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:503: output_char(':', p);
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00358$
	push	acc
	mov	a,#(00358$ >> 8)
	push	acc
	mov	a,#(00358$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x3A
	ret
00358$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:504: output_char('0', p);
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00359$
	push	acc
	mov	a,#(00359$ >> 8)
	push	acc
	mov	a,#(00359$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x30
	ret
00359$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:505: output_char('x', p);
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00360$
	push	acc
	mov	a,#(00360$ >> 8)
	push	acc
	mov	a,#(00360$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x78
	ret
00360$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:506: OUTPUT_2DIGITS( value.byte[2] );
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0002)
	movx	a,@dptr
	mov	r5,a
;	genCall 
;	genSend argreg = 1, size = 1 
	mov	dpl,r5
	lcall	_output_2digits
;	printf_large.c:507: OUTPUT_2DIGITS( value.byte[1] );
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0001)
	movx	a,@dptr
	mov	r5,a
;	genCall 
;	genSend argreg = 1, size = 1 
	mov	dpl,r5
	lcall	_output_2digits
;	printf_large.c:508: OUTPUT_2DIGITS( value.byte[0] );
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	mov	r5,a
;	genCall 
;	genSend argreg = 1, size = 1 
	mov	dpl,r5
	lcall	_output_2digits
;	printf_large.c:509: charsOutputted += 10;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x0A
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:524: break;
;	genIpop 
;	genGoto 
;	printf_large.c:527: case 'I':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00149$:
;	printf_large.c:528: signed_argument = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_signed_argument_1_1
;	printf_large.c:529: radix = 10;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x0A
	movx	@dptr,a
;	printf_large.c:530: break;
;	genGoto 
;	printf_large.c:532: case 'O':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00150$:
;	printf_large.c:533: radix = 8;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x08
	movx	@dptr,a
;	printf_large.c:534: break;
;	genGoto 
;	printf_large.c:536: case 'U':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00151$:
;	printf_large.c:537: radix = 10;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x0A
	movx	@dptr,a
;	printf_large.c:538: break;
;	genGoto 
;	printf_large.c:540: case 'X':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00152$:
;	printf_large.c:541: radix = 16;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_radix_1_1
	mov	a,#0x10
	movx	@dptr,a
;	printf_large.c:542: break;
;	genGoto 
;	printf_large.c:544: case 'F':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00153$:
;	printf_large.c:545: float_argument=1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_float_argument_1_1
;	printf_large.c:546: break;
;	genGoto 
;	printf_large.c:548: default:
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00155$
00154$:
;	printf_large.c:550: output_char( c, p );
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00361$
	push	acc
	mov	a,#(00361$ >> 8)
	push	acc
	mov	a,#(00361$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r4
	ret
00361$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:551: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:553: }
;	genLabel 
00155$:
;	printf_large.c:555: if (float_argument) {
;	genIfx 
;	genIfxJump
	jb	__print_format_float_argument_1_1,00362$
	ljmp	00218$
00362$:
;	printf_large.c:556: value.f=va_arg(ap,float);
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genMinus 
	mov	a,r6
	add	a,#0xFC
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
	mov	a,r0
	addc	a,#0xFF
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
	inc	dptr
	lcall	__gptrgetWord
	mov	r0,_ap
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printf_large.c:571: charsOutputted += OUTPUT_FLOAT(value.f, width, decimals, left_justify,
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
	mov	dptr,#_output_float_PARM_2
	movx	@dptr,a
;	genAssign 
	mov	dptr,#__print_format_decimals_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (1 byte case)
	movx	a,@dptr
	mov	dptr,#_output_float_PARM_3
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	c,__print_format_left_justify_1_1
	mov	_output_float_PARM_4,c
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	c,__print_format_zero_padding_1_1
	mov	_output_float_PARM_5,c
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	c,__print_format_prefix_sign_1_1
	mov	_output_float_PARM_6,c
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	c,__print_format_prefix_space_1_1
	mov	_output_float_PARM_7,c
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	_output_float
	mov	r6,dpl
	mov	r7,dph
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r6
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r7
	movx	@dptr,a
;	genGoto 
	ljmp	00223$
;	genLabel 
00218$:
;	printf_large.c:574: } else if (radix != 0)
;	genCmpEq 
	mov	dptr,#__print_format_radix_1_1
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x00,00363$
	ljmp	00223$
00363$:
;	printf_large.c:579: unsigned char _AUTOMEM *pstore = &store[5];
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_pstore_4_22
	mov	a,#(__print_format_store_4_22 + 0x0005)
	movx	@dptr,a
	inc	dptr
	mov	a,#((__print_format_store_4_22 + 0x0005) >> 8)
	movx	@dptr,a
	inc	dptr
	mov	a,#((__print_format_store_4_22 + 0x0005) >> 16)
	movx	@dptr,a
;	printf_large.c:582: if (char_argument)
;	genIfx 
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 165   removed sjmp by inverse jump logic
	jnb  __print_format_char_argument_1_1,00164$
00364$:
;	printf_large.c:584: value.l = va_arg(ap,char);
;	genIpush 
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genMinus 
	dec	r1
	cjne	r1,#0xFF,00365$
	dec	r6
	cjne	r6,#0xFF,00365$
	dec	r7
00365$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r1
	mov	dph,r6
	mov	dpx,r7
	mov	b,r0
	lcall	__gptrget
;	genCast 
; Peephole 166   removed redundant mov
	mov  r1,a
	mov  ar6,r1 
	rlc	a
	subb	a,acc
	mov	r7,a
	mov	r0,a
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printf_large.c:585: if (!signed_argument)
;	genIpop 
;	genIfx 
;	genIfxJump
	jnb	__print_format_signed_argument_1_1,00366$
	ljmp	00165$
00366$:
;	printf_large.c:587: value.l &= 0xFF;
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r1,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	mov	r0,a
;	genAnd 
	mov	r6,#0
	mov	r7,#0
	mov	r0,#0
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genIpop 
;	genGoto 
	ljmp	00165$
;	genLabel 
00164$:
;	printf_large.c:590: else if (long_argument)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_long_argument_1_1,00161$
00367$:
;	printf_large.c:592: value.l = va_arg(ap,long);
;	genIpush 
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genMinus 
	mov	a,r1
	add	a,#0xFC
	mov	r1,a
	mov	a,r6
	addc	a,#0xFF
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r1
	mov	dph,r6
	mov	dpx,r7
	mov	b,r0
	lcall	__gptrgetWord
	mov	r1,_ap
	mov	r6,a
	inc	dptr
	lcall	__gptrgetWord
	mov	r7,_ap
	mov	r0,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genIpop 
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00165$
00161$:
;	printf_large.c:596: value.l = va_arg(ap,int);
;	genIpush 
;	genAssign 
	mov	dptr,#__print_format_PARM_4
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genMinus 
	mov	a,r1
	add	a,#0xFE
	mov	r1,a
	mov	a,r6
	addc	a,#0xFF
	mov	r6,a
	mov	a,r7
	addc	a,#0xFF
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_PARM_4
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r1
	mov	dph,r6
	mov	dpx,r7
	mov	b,r0
	lcall	__gptrgetWord
	mov	r1,_ap
	mov	r6,a
;	genCast 
	mov	ar7,r1
	mov	a,r6
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printf_large.c:597: if (!signed_argument)
;	genIpop 
;	genIfx 
;	genIfxJump
; Peephole 112   removed ljmp by inverse jump logic
	jb   __print_format_signed_argument_1_1,00165$
00368$:
;	printf_large.c:599: value.l &= 0xFFFF;
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r1,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	mov	r0,a
;	genAnd 
	mov	r7,#0
	mov	r0,#0
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	printf_large.c:731: return charsOutputted;
;	genIpop 
;	printf_large.c:599: value.l &= 0xFFFF;
;	genLabel 
00165$:
;	printf_large.c:603: if ( signed_argument )
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_signed_argument_1_1,00170$
00369$:
;	printf_large.c:605: if (value.l < 0)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r1,a
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
;	genCmpLt 
;	genCmp
; Peephole 105   removed redundant mov
	mov  r0,a
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00167$
00370$:
;	printf_large.c:606: value.l = -value.l;
;	genUminus 
	clr	c
	clr	a
	subb	a,r1
	mov	r1,a
	clr	a
	subb	a,r6
	mov	r6,a
	clr	a
	subb	a,r7
	mov	r7,a
	clr	a
	subb	a,r0
	mov	r0,a
;	genPointerSet 
	mov	dptr,#_value
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00170$
00167$:
;	printf_large.c:608: signed_argument = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	__print_format_signed_argument_1_1
;	genLabel 
00170$:
;	printf_large.c:612: lsd = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	__print_format_lsd_1_1
;	printf_large.c:614: do {
;	genAssign 
	mov	dptr,#__print_format_pstore_4_22
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_sloc1_1_0
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	genLabel 
00174$:
;	printf_large.c:615: value.byte[4] = 0;
;	genPointerSet 
	mov	dptr,#(_value + 0x0004)
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:619: calculate_digit(radix);
;	genCall 
	push	ar6
	push	ar7
	push	ar0
;	genSend argreg = 1, size = 1 
	mov	dptr,#__print_format_radix_1_1
	movx	a,@dptr
	mov	dpl,a
	lcall	_calculate_digit
	pop	ar0
	pop	ar7
	pop	ar6
;	printf_large.c:621: if (!lsd)
;	genIfx 
;	genIfxJump
; Peephole 112   removed ljmp by inverse jump logic
	jb   __print_format_lsd_1_1,00172$
00371$:
;	printf_large.c:623: *pstore = (value.byte[4] << 4) | (value.byte[4] >> 4) | *pstore;
;	genIpush 
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;     genSwap
; Peephole 105   removed redundant mov
	mov  r2,a
	swap	a
	mov	r2,a
;	genPointerGet 
;	genFarPointerGet
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	movx	a,@dptr
;	genOr 
; Peephole 105   removed redundant mov
	mov  r3,a
	orl	ar2,a
;	genPointerSet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	a,r2
	movx	@dptr,a
;	printf_large.c:624: pstore--;
;	genMinus 
	dec	r6
	cjne	r6,#0xFF,00372$
	dec	r7
	cjne	r7,#0xFF,00372$
	dec	r0
00372$:
;	genIpop 
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00173$
00172$:
;	printf_large.c:628: *pstore = value.byte[4];
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
;	genPointerSet 
; Peephole 136a   removed redundant moves
	mov  r2,a
	mov  dpl,r6
	mov  dph,r7
	mov  dpx,r0
	movx	@dptr,a
;	genLabel 
00173$:
;	printf_large.c:630: length++;
;	genPlus 
	mov	dptr,#__print_format_sloc1_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
;	genAssign 
	mov	dptr,#__print_format_sloc1_1_0
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r4,a
;	printf_large.c:631: lsd = !lsd;
;	genNot 
; Peephole 167   removed redundant bit moves (c not set to __print_format_lsd_1_1)
	cpl  __print_format_lsd_1_1 
;	printf_large.c:632: } while( value.ul );
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#_value
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_pstore_4_22
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r5
	orl	a,r1
;	genIfxJump
	jz	00373$
	ljmp	00174$
00373$:
;	printf_large.c:634: if (width == 0)
;	genCmpEq 
	mov	dptr,#__print_format_width_1_1
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x00,00178$
;00374$:
; Peephole 200   removed redundant sjmp
00375$:
;	printf_large.c:639: width=1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	mov	a,#0x01
	movx	@dptr,a
;	genLabel 
00178$:
;	printf_large.c:643: if (!zero_padding && !left_justify)
;	genIfx 
;	genIfxJump
	jnb	__print_format_zero_padding_1_1,00376$
	ljmp	00183$
00376$:
;	genIfx 
;	genIfxJump
	jnb	__print_format_left_justify_1_1,00377$
	ljmp	00183$
00377$:
;	printf_large.c:645: while ( width > (unsigned char) (length+1) )
;	genPlus 
	mov	a,#0x01
	add	a,r4
	mov	r2,a
;	genAssign 
	mov	dptr,#__print_format_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
;	genLabel 
00179$:
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,r6
	clr	a
	rlc	a
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	mov	a,r6
	movx	@dptr,a
;	genIfx 
	mov	a,r7
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00183$
00378$:
;	printf_large.c:647: output_char( ' ', p );
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00379$
	push	acc
	mov	a,#(00379$ >> 8)
	push	acc
	mov	a,#(00379$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00379$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:648: charsOutputted++;
;	genPlus 
	inc	r3
	cjne	r3,#0,00380$
	inc	r5
00380$:
;	did genPlusIncr
;	printf_large.c:649: width--;
;	genMinus 
	dec	r6
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00179$
00183$:
;	printf_large.c:653: if (signed_argument) // this now means the original value was negative
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_signed_argument_1_1,00193$
00381$:
;	printf_large.c:655: output_char( '-', p );
;	genIpush 
	push	ar4
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00382$
	push	acc
	mov	a,#(00382$ >> 8)
	push	acc
	mov	a,#(00382$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2D
	ret
00382$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar4
;	printf_large.c:656: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:658: width--;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	dec	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	genGoto 
	ljmp	00194$
;	genLabel 
00193$:
;	printf_large.c:660: else if (length != 0)
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x00,00383$
	ljmp	00194$
00383$:
;	printf_large.c:663: if (prefix_sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_prefix_sign_1_1,00188$
00384$:
;	printf_large.c:665: output_char( '+', p );
;	genIpush 
	push	ar4
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00385$
	push	acc
	mov	a,#(00385$ >> 8)
	push	acc
	mov	a,#(00385$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x2B
	ret
00385$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar4
;	printf_large.c:666: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:668: width--;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	dec	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00194$
00188$:
;	printf_large.c:670: else if (prefix_space)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_prefix_space_1_1,00194$
00386$:
;	printf_large.c:672: output_char( ' ', p );
;	genIpush 
	push	ar4
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00387$
	push	acc
	mov	a,#(00387$ >> 8)
	push	acc
	mov	a,#(00387$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00387$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar4
;	printf_large.c:673: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	printf_large.c:675: width--;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	movx	a,@dptr
	dec	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	movx	@dptr,a
;	genLabel 
00194$:
;	printf_large.c:680: if (!left_justify)
;	genIfx 
;	genIfxJump
	jnb	__print_format_left_justify_1_1,00388$
	ljmp	00202$
00388$:
;	printf_large.c:681: while ( width-- > length )
;	genAssign 
	mov	dptr,#__print_format_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00195$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
	mov	a,r5
	movx	@dptr,a
;	genCmpGt 
;	genCmp
	clr	c
	mov	a,r4
	subb	a,r6
	clr	a
	rlc	a
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genIfx 
	mov	a,r6
;	genIfxJump
	jnz	00389$
	ljmp	00296$
00389$:
;	printf_large.c:683: output_char( zero_padding ? '0' : ' ', p );
;	genAssign 
	mov	dptr,#_p
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  __print_format_zero_padding_1_1,00230$
00390$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_sloc1_1_0
	mov	a,#0x30
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00231$
00230$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_sloc1_1_0
	mov	a,#0x20
	movx	@dptr,a
;	genLabel 
00231$:
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genPcall 
	mov	a,#00391$
	push	acc
	mov	a,#(00391$ >> 8)
	push	acc
	mov	a,#(00391$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dptr,#__print_format_sloc1_1_0
	movx	a,@dptr
	mov	dpl,a
	ret
00391$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printf_large.c:684: charsOutputted++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00392$
	inc	r3
00392$:
;	did genPlusIncr
;	genGoto 
	ljmp	00195$
;	genLabel 
00202$:
;	printf_large.c:689: if (width > length)
;	genCmpGt 
	mov	dptr,#__print_format_width_1_1
;	genCmp
	clr	c
	mov	a,r4
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00199$
00393$:
;	printf_large.c:690: width -= length;
;	genMinus 
	mov	dptr,#__print_format_width_1_1
	clr	c
	movx	a,@dptr
	subb	a,r4
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00296$
00199$:
;	printf_large.c:692: width = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_width_1_1
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	printf_large.c:696: while( length-- )
;	genLabel 
00296$:
;	genAssign 
	mov	dptr,#__print_format_pstore_4_22
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genAssign 
	mov	dptr,#__print_format_charsOutputted_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar0,r4
;	genLabel 
00207$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar1,r0
;	genMinus 
	dec	r0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genIfx 
	mov	a,r1
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00209$
00394$:
;	printf_large.c:698: lsd = !lsd;
;	genNot 
; Peephole 167   removed redundant bit moves (c not set to __print_format_lsd_1_1)
	cpl  __print_format_lsd_1_1 
;	printf_large.c:699: if (!lsd)
;	genIfx 
;	genIfxJump
; Peephole 112   removed ljmp by inverse jump logic
	jb   __print_format_lsd_1_1,00205$
00395$:
;	printf_large.c:701: pstore++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00396$
	inc	r3
	cjne	r3,#0,00396$
	inc	r5
00396$:
;	did genPlusIncr
;	printf_large.c:702: value.byte[4] = *pstore >> 4;
;	genPointerGet 
;	genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r5
	movx	a,@dptr
;	genRightShift 
;	genRightShiftLiteral (4), size 1
;	genrshOne
; Peephole 105   removed redundant mov
	mov  r1,a
	swap	a
	anl	a,#0x0F
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r1,a
	mov  dptr,#(_value + 0x0004)
	movx @dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00206$
00205$:
;	printf_large.c:706: value.byte[4] = *pstore & 0x0F;
;	genPointerGet 
;	genFarPointerGet
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r5
	movx	a,@dptr
	mov	r1,a
;	genAnd 
	anl	ar1,#0x0F
;	genPointerSet 
	mov	dptr,#(_value + 0x0004)
	mov	a,r1
	movx	@dptr,a
;	genLabel 
00206$:
;	printf_large.c:711: output_digit( value.byte[4] );
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(_value + 0x0004)
	movx	a,@dptr
	mov	r1,a
;	genCall 
	push	ar2
	push	ar3
	push	ar5
	push	ar6
	push	ar7
	push	ar0
;	genSend argreg = 1, size = 1 
	mov	dpl,r1
	lcall	_output_digit
	pop	ar0
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar3
	pop	ar2
;	printf_large.c:713: charsOutputted++;
;	genPlus 
	inc	r6
	cjne	r6,#0,00397$
	inc	r7
00397$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00207$
00209$:
;	printf_large.c:715: if (left_justify)
;	genIfx 
;	genIfxJump
	jb	__print_format_left_justify_1_1,00398$
	ljmp	00223$
00398$:
;	printf_large.c:716: while (width-- > 0)
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
;	genAssign 
	mov	dptr,#__print_format_width_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00210$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar6,r5
;	genMinus 
	dec	r5
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 180   changed mov to clr
	clr  a
	subb	a,r6
	clr	a
	rlc	a
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__print_format_charsOutputted_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genIfx 
	mov	a,r6
;	genIfxJump
	jnz	00399$
	ljmp	00223$
00399$:
;	printf_large.c:718: output_char(' ', p);
;	genIpush 
	push	ar2
	push	ar3
	push	ar5
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00400$
	push	acc
	mov	a,#(00400$ >> 8)
	push	acc
	mov	a,#(00400$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x20
	ret
00400$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
	pop	ar5
	pop	ar3
	pop	ar2
;	printf_large.c:719: charsOutputted++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00401$
	inc	r3
00401$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00210$
00221$:
;	printf_large.c:726: output_char( c, p );
;	genIpush 
	mov	dptr,#_p
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
;	genPcall 
	mov	a,#00402$
	push	acc
	mov	a,#(00402$ >> 8)
	push	acc
	mov	a,#(00402$ >> 16)
	push	acc
	mov	dptr,#_output_char
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
	inc	dptr
	movx	a,@dptr
;  Peephole 100.a   removed redundant mov
	push	acc
;	genSend argreg = 1, size = 1 
	mov	dpl,r4
	ret
00402$:
;	stack adjustment for parms
	pop	acc
	pop	acc
	pop	acc
	pop	acc
;	printf_large.c:727: charsOutputted++;
;	genPlus 
	mov	dptr,#__print_format_charsOutputted_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genGoto 
	ljmp	00223$
;	genLabel 
00225$:
;	printf_large.c:731: return charsOutputted;
;	genRet 
	mov     dps, #1
	mov     dptr, #__print_format_charsOutputted_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
;	genLabel 
00226$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
_memory_id:
	.ascii "IXCP-"
	.db 0x00
__str_0:
	.ascii "<NULL>"
	.db 0x00
	.area XINIT   (CODE)
