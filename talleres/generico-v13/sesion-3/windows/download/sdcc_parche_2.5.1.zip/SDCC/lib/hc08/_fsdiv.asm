;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:09 2005
;--------------------------------------------------------
	.module _fsdiv
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsdiv_PARM_2
	.globl ___fsdiv_PARM_1
	.globl ___fsdiv
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area	OSEG    (OVR)
___fsdiv_sloc0_1_0::
	.ds 4
___fsdiv_sloc1_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
___fsdiv_PARM_1::
	.ds 4
___fsdiv_PARM_2::
	.ds 4
___fsdiv_fl1_1_1::
	.ds 4
___fsdiv_fl2_1_1::
	.ds 4
___fsdiv_result_1_1::
	.ds 4
___fsdiv_mask_1_1::
	.ds 4
___fsdiv_mant1_1_1::
	.ds 4
___fsdiv_mant2_1_1::
	.ds 4
___fsdiv_exp_1_1::
	.ds 2
___fsdiv_sign_1_1::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsdiv'
;------------------------------------------------------------
;a1                        Allocated with name '___fsdiv_PARM_1'
;a2                        Allocated with name '___fsdiv_PARM_2'
;fl1                       Allocated with name '___fsdiv_fl1_1_1'
;fl2                       Allocated with name '___fsdiv_fl2_1_1'
;result                    Allocated with name '___fsdiv_result_1_1'
;mask                      Allocated with name '___fsdiv_mask_1_1'
;mant1                     Allocated with name '___fsdiv_mant1_1_1'
;mant2                     Allocated with name '___fsdiv_mant2_1_1'
;exp                       Allocated with name '___fsdiv_exp_1_1'
;sign                      Allocated with name '___fsdiv_sign_1_1'
;sloc0                     Allocated with name '___fsdiv_sloc0_1_0'
;sloc1                     Allocated with name '___fsdiv_sloc1_1_0'
;------------------------------------------------------------
;_fsdiv.c:235: float __fsdiv (float a1, float a2)
;	-----------------------------------------
;	 function __fsdiv
;	-----------------------------------------
___fsdiv:
;_fsdiv.c:244: fl1.f = a1;
	lda	___fsdiv_PARM_1
	sta	___fsdiv_fl1_1_1
	lda	(___fsdiv_PARM_1 + 1)
	sta	(___fsdiv_fl1_1_1 + 1)
	lda	(___fsdiv_PARM_1 + 2)
	sta	(___fsdiv_fl1_1_1 + 2)
	lda	(___fsdiv_PARM_1 + 3)
	sta	(___fsdiv_fl1_1_1 + 3)
;_fsdiv.c:245: fl2.f = a2;
	lda	___fsdiv_PARM_2
	sta	___fsdiv_fl2_1_1
	lda	(___fsdiv_PARM_2 + 1)
	sta	(___fsdiv_fl2_1_1 + 1)
	lda	(___fsdiv_PARM_2 + 2)
	sta	(___fsdiv_fl2_1_1 + 2)
	lda	(___fsdiv_PARM_2 + 3)
	sta	(___fsdiv_fl2_1_1 + 3)
;_fsdiv.c:248: exp = EXP (fl1.l) ;
	lda	___fsdiv_fl1_1_1
	sta	*___fsdiv_sloc0_1_0
	lda	(___fsdiv_fl1_1_1 + 1)
	sta	*(___fsdiv_sloc0_1_0 + 1)
	lda	(___fsdiv_fl1_1_1 + 2)
	sta	*(___fsdiv_sloc0_1_0 + 2)
	lda	(___fsdiv_fl1_1_1 + 3)
	sta	*(___fsdiv_sloc0_1_0 + 3)
	lda	*(___fsdiv_sloc0_1_0 + 1)
	ldx	*___fsdiv_sloc0_1_0
	lsla
	txa
	rola
	clrx
	rolx
	sta	*(___fsdiv_sloc0_1_0 + 3)
	stx	*(___fsdiv_sloc0_1_0 + 2)
	clr	*(___fsdiv_sloc0_1_0 + 1)
	clr	*___fsdiv_sloc0_1_0
	clr	*(___fsdiv_sloc0_1_0 + 2)
	clr	*(___fsdiv_sloc0_1_0 + 1)
	clr	*___fsdiv_sloc0_1_0
	lda	*(___fsdiv_sloc0_1_0 + 3)
	sta	(___fsdiv_exp_1_1 + 1)
	lda	*(___fsdiv_sloc0_1_0 + 2)
	sta	___fsdiv_exp_1_1
;_fsdiv.c:249: exp -= EXP (fl2.l);
	lda	___fsdiv_fl2_1_1
	sta	*___fsdiv_sloc0_1_0
	lda	(___fsdiv_fl2_1_1 + 1)
	sta	*(___fsdiv_sloc0_1_0 + 1)
	lda	(___fsdiv_fl2_1_1 + 2)
	sta	*(___fsdiv_sloc0_1_0 + 2)
	lda	(___fsdiv_fl2_1_1 + 3)
	sta	*(___fsdiv_sloc0_1_0 + 3)
	lda	*(___fsdiv_sloc0_1_0 + 1)
	ldx	*___fsdiv_sloc0_1_0
	lsla
	txa
	rola
	clrx
	rolx
	sta	*(___fsdiv_sloc0_1_0 + 3)
	stx	*(___fsdiv_sloc0_1_0 + 2)
	clr	*(___fsdiv_sloc0_1_0 + 1)
	clr	*___fsdiv_sloc0_1_0
	clr	*(___fsdiv_sloc0_1_0 + 2)
	clr	*(___fsdiv_sloc0_1_0 + 1)
	clr	*___fsdiv_sloc0_1_0
	lda	(___fsdiv_exp_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	___fsdiv_exp_1_1
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	___fsdiv_exp_1_1
	rola	
	clra	
	sbc	#0x00
	sta	*(___fsdiv_sloc1_1_0 + 1)
	sta	*___fsdiv_sloc1_1_0
	lda	*(___fsdiv_sloc1_1_0 + 3)
	sub	*(___fsdiv_sloc0_1_0 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	sbc	*(___fsdiv_sloc0_1_0 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	sbc	*(___fsdiv_sloc0_1_0 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	*___fsdiv_sloc1_1_0
	sbc	*___fsdiv_sloc0_1_0
	sta	*___fsdiv_sloc1_1_0
	lda	*(___fsdiv_sloc1_1_0 + 3)
	sta	(___fsdiv_exp_1_1 + 1)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	sta	___fsdiv_exp_1_1
;_fsdiv.c:250: exp += EXCESS;
	lda	(___fsdiv_exp_1_1 + 1)
	add	#0x7E
	sta	(___fsdiv_exp_1_1 + 1)
	bcc	00123$
	lda	___fsdiv_exp_1_1
	inca
	sta	___fsdiv_exp_1_1
00123$:
;_fsdiv.c:253: sign = SIGN (fl1.l) ^ SIGN (fl2.l);
	lda	___fsdiv_fl1_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl1_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl1_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl1_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*___fsdiv_sloc1_1_0
	rola
	clra
	rola
	sta	*___fsdiv_sloc1_1_0
	lda	___fsdiv_fl2_1_1
	sta	*___fsdiv_sloc0_1_0
	lda	(___fsdiv_fl2_1_1 + 1)
	sta	*(___fsdiv_sloc0_1_0 + 1)
	lda	(___fsdiv_fl2_1_1 + 2)
	sta	*(___fsdiv_sloc0_1_0 + 2)
	lda	(___fsdiv_fl2_1_1 + 3)
	sta	*(___fsdiv_sloc0_1_0 + 3)
	lda	*___fsdiv_sloc0_1_0
	rola
	clra
	rola
	eor	*___fsdiv_sloc1_1_0
	sta	___fsdiv_sign_1_1
;_fsdiv.c:256: if (!fl2.l)
	lda	___fsdiv_fl2_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl2_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl2_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl2_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 3)
	ora	*(___fsdiv_sloc1_1_0 + 2)
	ora	*(___fsdiv_sloc1_1_0 + 1)
	ora	*___fsdiv_sloc1_1_0
; Peephole 2c	- eliminated jmp
	bne	00102$
00124$:
;_fsdiv.c:258: return (-1.0);
	mov	#0xBF,*__ret3
	mov	#0x80,*__ret2
	clrx
	clra
; Peephole 6a  - replaced jmp to rts with rts
	rts
00102$:
;_fsdiv.c:261: if (!fl1.l)
	lda	___fsdiv_fl1_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl1_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl1_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl1_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 3)
	ora	*(___fsdiv_sloc1_1_0 + 2)
	ora	*(___fsdiv_sloc1_1_0 + 1)
	ora	*___fsdiv_sloc1_1_0
; Peephole 2c	- eliminated jmp
	bne	00104$
00125$:
;_fsdiv.c:262: return (0);
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
; Peephole 6a  - replaced jmp to rts with rts
	rts
00104$:
;_fsdiv.c:265: mant1 = MANT (fl1.l);
	lda	___fsdiv_fl1_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl1_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl1_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl1_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	and	#0x7F
	sta	*(___fsdiv_sloc1_1_0 + 1)
	clr	*___fsdiv_sloc1_1_0
	lda	*(___fsdiv_sloc1_1_0 + 3)
	sta	(___fsdiv_mant1_1_1 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	sta	(___fsdiv_mant1_1_1 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	ora	#0x80
	sta	(___fsdiv_mant1_1_1 + 1)
	lda	*___fsdiv_sloc1_1_0
	sta	___fsdiv_mant1_1_1
;_fsdiv.c:266: mant2 = MANT (fl2.l);
	lda	___fsdiv_fl2_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl2_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl2_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl2_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	and	#0x7F
	sta	*(___fsdiv_sloc1_1_0 + 1)
	clr	*___fsdiv_sloc1_1_0
	lda	*(___fsdiv_sloc1_1_0 + 3)
	sta	(___fsdiv_mant2_1_1 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	sta	(___fsdiv_mant2_1_1 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	ora	#0x80
	sta	(___fsdiv_mant2_1_1 + 1)
	lda	*___fsdiv_sloc1_1_0
	sta	___fsdiv_mant2_1_1
;_fsdiv.c:269: if (mant1 < mant2)
	lda	(___fsdiv_mant1_1_1 + 3)
	sub	(___fsdiv_mant2_1_1 + 3)
	lda	(___fsdiv_mant1_1_1 + 2)
	sbc	(___fsdiv_mant2_1_1 + 2)
	lda	(___fsdiv_mant1_1_1 + 1)
	sbc	(___fsdiv_mant2_1_1 + 1)
	lda	___fsdiv_mant1_1_1
	sbc	___fsdiv_mant2_1_1
; Peephole 2l	- eliminated bra
	bge	00106$
00126$:
;_fsdiv.c:271: mant1 <<= 1;
	lda	(___fsdiv_mant1_1_1 + 3)
	ldx	(___fsdiv_mant1_1_1 + 2)
	lsla
	rolx
	sta	(___fsdiv_mant1_1_1 + 3)
	stx	(___fsdiv_mant1_1_1 + 2)
	lda	(___fsdiv_mant1_1_1 + 1)
	ldx	___fsdiv_mant1_1_1
	rola
	rolx
	sta	(___fsdiv_mant1_1_1 + 1)
	stx	___fsdiv_mant1_1_1
;_fsdiv.c:272: exp--;
	lda	(___fsdiv_exp_1_1 + 1)
	sub	#0x01
	sta	(___fsdiv_exp_1_1 + 1)
	lda	___fsdiv_exp_1_1
	sbc	#0x00
	sta	___fsdiv_exp_1_1
00106$:
;_fsdiv.c:276: mask = 0x1000000;
	lda	#0x01
	sta	___fsdiv_mask_1_1
;_fsdiv.c:277: result = 0;
; Peephole 5a   - eliminated redundant clra
	clra
	sta	(___fsdiv_mask_1_1 + 1)
	sta	(___fsdiv_mask_1_1 + 2)
	sta	(___fsdiv_mask_1_1 + 3)
	sta	___fsdiv_result_1_1
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsdiv_result_1_1 + 1)
	sta	(___fsdiv_result_1_1 + 2)
	sta	(___fsdiv_result_1_1 + 3)
;_fsdiv.c:278: while (mask)
00109$:
	lda	(___fsdiv_mask_1_1 + 3)
	ora	(___fsdiv_mask_1_1 + 2)
	ora	(___fsdiv_mask_1_1 + 1)
	ora	___fsdiv_mask_1_1
	bne	00127$
	jmp	00111$
00127$:
;_fsdiv.c:280: if (mant1 >= mant2)
	lda	(___fsdiv_mant1_1_1 + 3)
	sub	(___fsdiv_mant2_1_1 + 3)
	lda	(___fsdiv_mant1_1_1 + 2)
	sbc	(___fsdiv_mant2_1_1 + 2)
	lda	(___fsdiv_mant1_1_1 + 1)
	sbc	(___fsdiv_mant2_1_1 + 1)
	lda	___fsdiv_mant1_1_1
	sbc	___fsdiv_mant2_1_1
; Peephole 2k	- eliminated bra
	blt	00108$
00128$:
;_fsdiv.c:282: result |= mask;
	lda	(___fsdiv_result_1_1 + 3)
	ora	(___fsdiv_mask_1_1 + 3)
	sta	(___fsdiv_result_1_1 + 3)
	lda	(___fsdiv_result_1_1 + 2)
	ora	(___fsdiv_mask_1_1 + 2)
	sta	(___fsdiv_result_1_1 + 2)
	lda	(___fsdiv_result_1_1 + 1)
	ora	(___fsdiv_mask_1_1 + 1)
	sta	(___fsdiv_result_1_1 + 1)
	lda	___fsdiv_result_1_1
	ora	___fsdiv_mask_1_1
	sta	___fsdiv_result_1_1
;_fsdiv.c:283: mant1 -= mant2;
	lda	(___fsdiv_mant1_1_1 + 3)
	sub	(___fsdiv_mant2_1_1 + 3)
	sta	(___fsdiv_mant1_1_1 + 3)
	lda	(___fsdiv_mant1_1_1 + 2)
	sbc	(___fsdiv_mant2_1_1 + 2)
	sta	(___fsdiv_mant1_1_1 + 2)
	lda	(___fsdiv_mant1_1_1 + 1)
	sbc	(___fsdiv_mant2_1_1 + 1)
	sta	(___fsdiv_mant1_1_1 + 1)
	lda	___fsdiv_mant1_1_1
	sbc	___fsdiv_mant2_1_1
	sta	___fsdiv_mant1_1_1
00108$:
;_fsdiv.c:285: mant1 <<= 1;
	lda	(___fsdiv_mant1_1_1 + 3)
	ldx	(___fsdiv_mant1_1_1 + 2)
	lsla
	rolx
	sta	(___fsdiv_mant1_1_1 + 3)
	stx	(___fsdiv_mant1_1_1 + 2)
	lda	(___fsdiv_mant1_1_1 + 1)
	ldx	___fsdiv_mant1_1_1
	rola
	rolx
	sta	(___fsdiv_mant1_1_1 + 1)
	stx	___fsdiv_mant1_1_1
;_fsdiv.c:286: mask >>= 1;
	lda	(___fsdiv_mask_1_1 + 1)
	ldx	___fsdiv_mask_1_1
	lsrx
	rora
	sta	(___fsdiv_mask_1_1 + 1)
	stx	___fsdiv_mask_1_1
	lda	(___fsdiv_mask_1_1 + 3)
	ldx	(___fsdiv_mask_1_1 + 2)
	rorx
	rora
	sta	(___fsdiv_mask_1_1 + 3)
	stx	(___fsdiv_mask_1_1 + 2)
	jmp	00109$
00111$:
;_fsdiv.c:290: result += 1;
	lda	(___fsdiv_result_1_1 + 3)
	inca
	sta	(___fsdiv_result_1_1 + 3)
	bne	00129$
	lda	(___fsdiv_result_1_1 + 2)
	inca
	sta	(___fsdiv_result_1_1 + 2)
	bne	00129$
	lda	(___fsdiv_result_1_1 + 1)
	inca
	sta	(___fsdiv_result_1_1 + 1)
	bne	00129$
	lda	___fsdiv_result_1_1
	inca
	sta	___fsdiv_result_1_1
00129$:
;_fsdiv.c:293: exp++;
	lda	(___fsdiv_exp_1_1 + 1)
	inca
	sta	(___fsdiv_exp_1_1 + 1)
	bne	00130$
	lda	___fsdiv_exp_1_1
	inca
	sta	___fsdiv_exp_1_1
00130$:
;_fsdiv.c:294: result >>= 1;
	lda	(___fsdiv_result_1_1 + 1)
	ldx	___fsdiv_result_1_1
	asrx
	rora
	sta	(___fsdiv_result_1_1 + 1)
	stx	___fsdiv_result_1_1
	lda	(___fsdiv_result_1_1 + 3)
	ldx	(___fsdiv_result_1_1 + 2)
	rorx
	rora
	sta	(___fsdiv_result_1_1 + 3)
	stx	(___fsdiv_result_1_1 + 2)
;_fsdiv.c:296: result &= ~HIDDEN;
	lda	(___fsdiv_result_1_1 + 3)
	sta	(___fsdiv_result_1_1 + 3)
	lda	(___fsdiv_result_1_1 + 2)
	sta	(___fsdiv_result_1_1 + 2)
	lda	(___fsdiv_result_1_1 + 1)
	and	#0x7F
	sta	(___fsdiv_result_1_1 + 1)
	lda	___fsdiv_result_1_1
	sta	___fsdiv_result_1_1
;_fsdiv.c:299: fl1.l = PACK (sign ? 1ul<<31 : 0, (unsigned long) exp, result);
	lda	___fsdiv_sign_1_1
; Peephole 2d	- eliminated jmp
	beq	00114$
00131$:
	mov	#0x80,*___fsdiv_sloc1_1_0
	clr	*(___fsdiv_sloc1_1_0 + 1)
	clr	*(___fsdiv_sloc1_1_0 + 2)
	clr	*(___fsdiv_sloc1_1_0 + 3)
; Peephole 3	- shortened jmp to bra
	bra	00115$
00114$:
	clr	*___fsdiv_sloc1_1_0
	clr	*(___fsdiv_sloc1_1_0 + 1)
	clr	*(___fsdiv_sloc1_1_0 + 2)
	clr	*(___fsdiv_sloc1_1_0 + 3)
00115$:
	lda	(___fsdiv_exp_1_1 + 1)
	sta	*(___fsdiv_sloc0_1_0 + 3)
	lda	___fsdiv_exp_1_1
	sta	*(___fsdiv_sloc0_1_0 + 2)
	lda	___fsdiv_exp_1_1
	rola	
	clra	
	sbc	#0x00
	sta	*(___fsdiv_sloc0_1_0 + 1)
	sta	*___fsdiv_sloc0_1_0
	lda	*(___fsdiv_sloc0_1_0 + 3)
	ldx	*(___fsdiv_sloc0_1_0 + 2)
	lsrx
	rora
	tax
	clra
	rora
	sta	*(___fsdiv_sloc0_1_0 + 1)
	stx	*___fsdiv_sloc0_1_0
	clr	*(___fsdiv_sloc0_1_0 + 3)
	clr	*(___fsdiv_sloc0_1_0 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 3)
	ora	*(___fsdiv_sloc0_1_0 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	ora	*(___fsdiv_sloc0_1_0 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	ora	*(___fsdiv_sloc0_1_0 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	*___fsdiv_sloc1_1_0
	ora	*___fsdiv_sloc0_1_0
	sta	*___fsdiv_sloc1_1_0
	lda	*(___fsdiv_sloc1_1_0 + 3)
	ora	(___fsdiv_result_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	ora	(___fsdiv_result_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 1)
	ora	(___fsdiv_result_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	*___fsdiv_sloc1_1_0
	ora	___fsdiv_result_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	*___fsdiv_sloc1_1_0
	sta	___fsdiv_fl1_1_1
	lda	*(___fsdiv_sloc1_1_0 + 1)
	sta	(___fsdiv_fl1_1_1 + 1)
	lda	*(___fsdiv_sloc1_1_0 + 2)
	sta	(___fsdiv_fl1_1_1 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 3)
	sta	(___fsdiv_fl1_1_1 + 3)
;_fsdiv.c:300: return (fl1.f);
	lda	___fsdiv_fl1_1_1
	sta	*___fsdiv_sloc1_1_0
	lda	(___fsdiv_fl1_1_1 + 1)
	sta	*(___fsdiv_sloc1_1_0 + 1)
	lda	(___fsdiv_fl1_1_1 + 2)
	sta	*(___fsdiv_sloc1_1_0 + 2)
	lda	(___fsdiv_fl1_1_1 + 3)
	sta	*(___fsdiv_sloc1_1_0 + 3)
	mov	*___fsdiv_sloc1_1_0,*__ret3
	mov	*(___fsdiv_sloc1_1_0 + 1),*__ret2
	ldx	*(___fsdiv_sloc1_1_0 + 2)
	lda	*(___fsdiv_sloc1_1_0 + 3)
00112$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
