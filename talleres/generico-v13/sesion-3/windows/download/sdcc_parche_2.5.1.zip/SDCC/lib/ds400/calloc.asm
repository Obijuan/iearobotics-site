;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:35 2005
;--------------------------------------------------------
	.module calloc
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _calloc_PARM_2
	.globl _calloc
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_calloc_PARM_2::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'calloc'
;------------------------------------------------------------
;size                      Allocated with name '_calloc_PARM_2'
;nmemb                     Allocated to registers r2 r3 
;ptr                       Allocated to registers r4 r5 r6 
;------------------------------------------------------------
;	calloc.c:53: void xdata * calloc (size_t nmemb, size_t size)
;	genFunction 
;	-----------------------------------------
;	 function calloc
;	-----------------------------------------
_calloc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
;	calloc.c:57: ptr = malloc(nmemb * size);
;	genAssign 
	mov	dptr,#_calloc_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#__mulint_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	__mulint
	mov	r2,dpl
	mov	r3,dph
;	genCall 
	push	ar2
	push	ar3
;	genSend argreg = 1, size = 2 
	mov	dpl,r2
	mov	dph,r3
	lcall	_malloc
	mov	r4,dpl
	mov	r5,dph
	mov	r6,dpx
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	calloc.c:58: if (ptr)
;	genIfx 
	mov	a,r4
	orl	a,r5
	orl	a,r6
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00106$:
;	calloc.c:60: memset(ptr, 0, nmemb * size);
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar7,r4
	mov	ar0,r5
	mov	ar1,r6
;	genIpush 
	push	ar4
	push	ar5
	push	ar6
;	genCast 
	mov	r4,#0x0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_memset_PARM_2
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_memset_PARM_3
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genCall 
	push	ar4
	push	ar5
	push	ar6
;	genSend argreg = 1, size = 4 
	mov	dpl,r7
	mov	dph,r0
	mov	dpx,r1
	mov	b,r4
	lcall	_memset
	pop	ar6
	pop	ar5
	pop	ar4
;	calloc.c:62: return ptr;
;	genIpop 
	pop	ar6
	pop	ar5
	pop	ar4
;	calloc.c:60: memset(ptr, 0, nmemb * size);
;	genLabel 
00102$:
;	calloc.c:62: return ptr;
;	genRet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r6
;	genLabel 
00103$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
