;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:03 2005
;--------------------------------------------------------
	.module _modslong
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __modslong
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_modslong.c:256: _modslong (long a, long b)
;	genLabel
;	genFunction
;	---------------------------------
; Function _modslong
; ---------------------------------
__modslong_start::
__modslong:
	lda	sp,-12(sp)
;_modslong.c:261: (b < 0 ? -b : b));
;	genCmpLt
;	AOP_STK for 
	lda	hl,21(sp)
	ld	a,(hl)
	bit	7,a
	jp	z,00106$
;	genUminus
;	AOP_STK for 
;	AOP_STK for __modslong__1_0
	ld	de,#0x0000
	ld	a,e
	lda	hl,18(sp)
	sub	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	push	af
	lda	hl,7(sp)
	ld      (hl-),a
	ld	(hl),e
	ld	de,#0x0000
	lda	hl,22(sp)
	pop	af
	ld	a,e
	sbc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	lda	hl,7(sp)
	ld      (hl-),a
	ld	(hl),e
;	genGoto
	jp	00107$
;	genLabel
00106$:
;	genAssign
;	AOP_STK for 
;	AOP_STK for __modslong__1_0
	lda	hl,18(sp)
	ld	d,h
	ld	e,l
	lda	hl,4(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genLabel
00107$:
;	genAssign
;	AOP_STK for __modslong__1_0
;	(registers are the same)
;_modslong.c:260: r = _modulong((a < 0 ? -a : a),
;	genCmpLt
;	AOP_STK for 
	lda	hl,17(sp)
	ld	a,(hl)
	rlca
	ld	a,#0x00
	rla
	ld	c,a
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00108$
;	genUminus
;	AOP_STK for 
;	AOP_STK for __modslong__1_0
	ld	de,#0x0000
	ld	a,e
	lda	hl,14(sp)
	sub	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	push	af
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
	ld	de,#0x0000
	lda	hl,18(sp)
	pop	af
	ld	a,e
	sbc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
;	genGoto
	jp	00109$
;	genLabel
00108$:
;	genAssign
;	AOP_STK for 
;	AOP_STK for __modslong__1_0
	lda	hl,14(sp)
	ld	d,h
	ld	e,l
	lda	hl,0(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genLabel
00109$:
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for __modslong__1_0
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __modslong__1_0
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	__modulong
;	AOP_STK for __modslong__1_0
	push	hl
	lda	hl,12(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,8(sp)
	pop	bc
;	genAssign
;	AOP_STK for __modslong__1_0
;	AOP_STK for __modslong_r_1_1
	lda	hl,0(sp)
	ld	d,h
	ld	e,l
	lda	hl,8(sp)
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genAssign
;	AOP_STK for __modslong_r_1_1
;	(registers are the same)
;_modslong.c:262: if (a < 0)
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00102$
;_modslong.c:263: return -r;
;	genUminus
;	AOP_STK for __modslong_r_1_1
;	AOP_STK for __modslong__1_0
	ld	de,#0x0000
	ld	a,e
	lda	hl,8(sp)
	sub	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	push	af
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
	ld	de,#0x0000
	lda	hl,12(sp)
	pop	af
	ld	a,e
	sbc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
;	genRet
;	AOP_STK for __modslong__1_0
; Dump of IC_LEFT: type AOP_STK size 4
;	 aop_stk -12
	dec	hl
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	00104$
;	genLabel
00102$:
;_modslong.c:265: return r;
;	genRet
;	AOP_STK for __modslong_r_1_1
; Dump of IC_LEFT: type AOP_STK size 4
;	 aop_stk -4
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
;	genLabel
00104$:
;	genEndFunction
	lda	sp,12(sp)
	ret
__modslong_end::
	.area _CODE
