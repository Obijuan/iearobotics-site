;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:51:09 2005
;--------------------------------------------------------
	.module _ser
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ser_rxBuffer
	.globl _ser_txBuffer
	.globl _ser_rxIndexOut
	.globl _ser_rxIndexIn
	.globl _ser_txIndexOut
	.globl _ser_txIndexIn
	.globl _ser_init
	.globl _ser_interrupt_handler
	.globl _ser_putc
	.globl _ser_getc
	.globl _ser_printString
	.globl _ser_charAvail
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_P0	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_P1	=	0x0090
_SCON	=	0x0098
_SBUF	=	0x0099
_P2	=	0x00a0
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_T2CON	=	0x00c8
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_TL2	=	0x00cc
_TH2	=	0x00cd
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
_P0_0	=	0x0080
_P0_1	=	0x0081
_P0_2	=	0x0082
_P0_3	=	0x0083
_P0_4	=	0x0084
_P0_5	=	0x0085
_P0_6	=	0x0086
_P0_7	=	0x0087
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_P1_0	=	0x0090
_P1_1	=	0x0091
_P1_2	=	0x0092
_P1_3	=	0x0093
_P1_4	=	0x0094
_P1_5	=	0x0095
_P1_6	=	0x0096
_P1_7	=	0x0097
_RI	=	0x0098
_TI	=	0x0099
_RB8	=	0x009a
_TB8	=	0x009b
_REN	=	0x009c
_SM2	=	0x009d
_SM1	=	0x009e
_SM0	=	0x009f
_P2_0	=	0x00a0
_P2_1	=	0x00a1
_P2_2	=	0x00a2
_P2_3	=	0x00a3
_P2_4	=	0x00a4
_P2_5	=	0x00a5
_P2_6	=	0x00a6
_P2_7	=	0x00a7
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES	=	0x00ac
_EA	=	0x00af
_P3_0	=	0x00b0
_P3_1	=	0x00b1
_P3_2	=	0x00b2
_P3_3	=	0x00b3
_P3_4	=	0x00b4
_P3_5	=	0x00b5
_P3_6	=	0x00b6
_P3_7	=	0x00b7
_RXD	=	0x00b0
_TXD	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS	=	0x00bc
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_ET2	=	0x00ad
_T2CON_0	=	0x00c8
_T2CON_1	=	0x00c9
_T2CON_2	=	0x00ca
_T2CON_3	=	0x00cb
_T2CON_4	=	0x00cc
_T2CON_5	=	0x00cd
_T2CON_6	=	0x00ce
_T2CON_7	=	0x00cf
_CP_RL2	=	0x00c8
_C_T2	=	0x00c9
_TR2	=	0x00ca
_EXEN2	=	0x00cb
_TCLK	=	0x00cc
_RCLK	=	0x00cd
_EXF2	=	0x00ce
_TF2	=	0x00cf
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_1	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_ser_txBusy:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_ser_txIndexIn::
	.ds 1
_ser_txIndexOut::
	.ds 1
_ser_rxIndexIn::
	.ds 1
_ser_rxIndexOut::
	.ds 1
_ser_txBuffer::
	.ds 256
_ser_rxBuffer::
	.ds 256
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_init'
;------------------------------------------------------------
;------------------------------------------------------------
;	_ser.c:49: ser_init(void)
;	genFunction 
;	-----------------------------------------
;	 function ser_init
;	-----------------------------------------
_ser_init:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	_ser.c:51: ES = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_ES
;	_ser.c:53: ser_txBusy     = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_ser_txBusy
;	_ser.c:55: ser_txIndexIn  = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_ser_txIndexIn
; Peephole 180   changed mov to clr
;	_ser.c:56: ser_txIndexOut = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 180   changed mov to clr
; Peephole 219 removed redundant clear
;	_ser.c:57: ser_rxIndexIn  = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 180   changed mov to clr
;	_ser.c:58: ser_rxIndexOut = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 180   changed mov to clr
; Peephole 219 removed redundant clear
; Peephole 219a removed redundant clear
	clr   a
	movx  @dptr,a
	mov   dptr,#_ser_txIndexOut
	movx  @dptr,a
	mov   dptr,#_ser_rxIndexIn
	movx  @dptr,a
	mov   dptr,#_ser_rxIndexOut
	movx  @dptr,a
;	_ser.c:60: T2CON = 0x30;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_T2CON,#0x30
;	_ser.c:63: RCAP2H = 0xFF;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_RCAP2H,#0xFF
;	_ser.c:64: RCAP2L = 0xDD;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_RCAP2L,#0xDD
;	_ser.c:67: T2CON = 0x34;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_T2CON,#0x34
;	_ser.c:69: SCON = 0x50;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_SCON,#0x50
;	_ser.c:71: if (TI) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
;	_ser.c:72: TI = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
;       Peephole 244.a  using atomic test and clear
	jbc     _TI,00109$
	sjmp    00102$
00109$:
;	genLabel 
00102$:
;	_ser.c:74: if (RI) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
;	_ser.c:75: RI = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
;       Peephole 244.a  using atomic test and clear
	jbc     _RI,00110$
	sjmp    00104$
00110$:
;	genLabel 
00104$:
;	_ser.c:78: ES=1;  
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_ES
;	genLabel 
00105$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_interrupt_handler'
;------------------------------------------------------------
;------------------------------------------------------------
;	_ser.c:82: ser_interrupt_handler(void) interrupt 4 using 1
;	genFunction 
;	-----------------------------------------
;	 function ser_interrupt_handler
;	-----------------------------------------
_ser_interrupt_handler:
	ar2 = 0x0A
	ar3 = 0x0B
	ar4 = 0x0C
	ar5 = 0x0D
	ar6 = 0x0E
	ar7 = 0x0F
	ar0 = 0x08
	ar1 = 0x09
	push	acc
	push	b
	push	dpl
	push	dph
	push	dpx
	push	dps
	mov	dps,#0
	push	psw
	mov	psw,#0x08
;	_ser.c:84: ES=0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_ES
;	_ser.c:86: if (RI) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
;	_ser.c:87: RI = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
;       Peephole 244.a  using atomic test and clear
	jbc     _RI,00113$
	sjmp    00102$
00113$:
;	_ser.c:88: ser_rxBuffer[ser_rxIndexIn++] = SBUF;
;	genAssign 
	mov	dptr,#_ser_rxIndexIn
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
;	genPlus 
	mov	dptr,#_ser_rxIndexIn
	mov	a,#0x01
	add	a,r2
	movx	@dptr,a
;	genPlus 
	mov	a,r2
	add	a,#_ser_rxBuffer
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 16)
	mov	dpx,a
;	genPointerSet 
	mov	a,_SBUF
	movx	@dptr,a
;	genLabel 
00102$:
;	_ser.c:91: if (TI) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
;	_ser.c:92: TI = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
;       Peephole 244.a  using atomic test and clear
	jbc     _TI,00114$
	sjmp    00107$
00114$:
;	_ser.c:93: if (ser_txIndexIn == ser_txIndexOut) {
;	genCmpEq 
	mov	dptr,#_ser_txIndexOut
;	gencjneshort
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	mov     dptr, #_ser_txIndexIn
	movx	a,@dptr
	mov	dps,#0
	mov	b,a
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,b,00104$
;00115$:
; Peephole 200   removed redundant sjmp
00116$:
;	_ser.c:94: ser_txBusy = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_ser_txBusy
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00104$:
;	_ser.c:97: SBUF = ser_txBuffer[ser_txIndexOut++];
;	genAssign 
	mov	dptr,#_ser_txIndexOut
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
;	genPlus 
	mov	dptr,#_ser_txIndexOut
	mov	a,#0x01
	add	a,r2
	movx	@dptr,a
;	genPlus 
	mov	a,r2
	add	a,#_ser_txBuffer
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	movx	a,@dptr
	mov	_SBUF,a
;	genLabel 
00107$:
;	_ser.c:101: ES=1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_ES
;	genLabel 
00108$:
;	genEndFunction 
	pop	psw
	pop	dps
	pop	dpx
	pop	dph
	pop	dpl
	pop	b
	pop	acc
	reti
;	eliminated unneeded push/pop dpl1
;	eliminated unneeded push/pop dph1
;	eliminated unneeded push/pop dpx1
;	eliminated unneeded push/pop ap
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_putc'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;	_ser.c:105: ser_putc(unsigned char c)
;	genFunction 
;	-----------------------------------------
;	 function ser_putc
;	-----------------------------------------
_ser_putc:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
;	_ser.c:107: ES=0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_ES
;	_ser.c:109: if (ser_txBusy) {
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _ser_txBusy,00102$
00107$:
;	_ser.c:110: ser_txBuffer[ser_txIndexIn++] = c;
;	genAssign 
	mov	dptr,#_ser_txIndexIn
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r3,a
;	genPlus 
	mov	dptr,#_ser_txIndexIn
	mov	a,#0x01
	add	a,r3
	movx	@dptr,a
;	genPlus 
	mov	a,r3
	add	a,#_ser_txBuffer
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_txBuffer >> 16)
	mov	dpx,a
;	genPointerSet 
	mov	a,r2
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00102$:
;	_ser.c:113: ser_txBusy = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_ser_txBusy
;	_ser.c:114: SBUF = c;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_SBUF,r2
;	genLabel 
00103$:
;	_ser.c:117: ES=1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_ES
;	genLabel 
00104$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_getc'
;------------------------------------------------------------
;tmp                       Allocated to registers r2 
;------------------------------------------------------------
;	_ser.c:121: ser_getc(void)
;	genFunction 
;	-----------------------------------------
;	 function ser_getc
;	-----------------------------------------
_ser_getc:
;	_ser.c:126: if (ser_rxIndexIn != ser_rxIndexOut) {
;	genCmpEq 
	mov	dptr,#_ser_rxIndexOut
;	gencjneshort
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	mov     dptr, #_ser_rxIndexIn
	movx	a,@dptr
	mov	dps,#0
	mov	b,a
	movx	a,@dptr
	cjne	a,b,00107$
; Peephole 132   changed ljmp to sjmp
	sjmp 00102$
00107$:
;	_ser.c:127: tmp = ser_rxBuffer[ser_rxIndexOut++];
;	genAssign 
	mov	dptr,#_ser_rxIndexOut
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
;	genPlus 
	mov	dptr,#_ser_rxIndexOut
	mov	a,#0x01
	add	a,r2
	movx	@dptr,a
;	genPlus 
	mov	a,r2
	add	a,#_ser_rxBuffer
	mov	dpl,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_ser_rxBuffer >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	movx	a,@dptr
	mov	r2,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00102$:
;	_ser.c:130: tmp = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r2,#0x00
;	genLabel 
00103$:
;	_ser.c:134: return(tmp);
;	genRet 
	mov	dpl,r2
;	genLabel 
00104$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_printString'
;------------------------------------------------------------
;String                    Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	_ser.c:138: ser_printString(char *String)
;	genFunction 
;	-----------------------------------------
;	 function ser_printString
;	-----------------------------------------
_ser_printString:
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_ser.c:140: while (*String) {
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00101$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00104$
00108$:
;	_ser.c:141: ser_putc(*String++);
;	genPlus 
	inc	r2
	cjne	r2,#0,00109$
	inc	r3
	cjne	r3,#0,00109$
	inc	r4
00109$:
;	did genPlusIncr
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	lcall	_ser_putc
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00101$
00104$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'ser_charAvail'
;------------------------------------------------------------
;ret                       Allocated to registers r2 
;------------------------------------------------------------
;	_ser.c:146: ser_charAvail(void)
;	genFunction 
;	-----------------------------------------
;	 function ser_charAvail
;	-----------------------------------------
_ser_charAvail:
;	_ser.c:148: char ret = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r2,#0x00
;	_ser.c:150: if (ser_rxIndexIn != ser_rxIndexOut) {
;	genCmpEq 
	mov	dptr,#_ser_rxIndexOut
;	gencjneshort
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	mov     dptr, #_ser_rxIndexIn
	movx	a,@dptr
	mov	dps,#0
	mov	b,a
	movx	a,@dptr
	cjne	a,b,00106$
; Peephole 132   changed ljmp to sjmp
	sjmp 00102$
00106$:
;	_ser.c:151: ret = 1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r2,#0x01
;	genLabel 
00102$:
;	_ser.c:154: return(ret);
;	genRet 
	mov	dpl,r2
;	genLabel 
00103$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
