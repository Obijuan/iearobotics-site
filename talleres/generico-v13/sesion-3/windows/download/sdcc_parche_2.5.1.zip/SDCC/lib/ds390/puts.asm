;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:48:36 2005
;--------------------------------------------------------
	.module puts
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _puts
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'puts'
;------------------------------------------------------------
;s                         Allocated to registers r2 r3 r4 r5 
;i                         Allocated to registers 
;------------------------------------------------------------
;	puts.c:27: int puts (char *s)
;	genFunction 
;	-----------------------------------------
;	 function puts
;	-----------------------------------------
_puts:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	puts.c:30: while (*s){
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0x00
	mov	r7,#0x00
;	genLabel 
00101$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r0,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00103$
00108$:
;	puts.c:31: putchar(*s++);
;	genPlus 
	inc	r2
	cjne	r2,#0,00109$
	inc	r3
	cjne	r3,#0,00109$
	inc	r4
00109$:
;	did genPlusIncr
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
	push	ar6
	push	ar7
;	genSend argreg = 1, size = 1 
	mov	dpl,r0
	lcall	_putchar
	pop	ar7
	pop	ar6
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	puts.c:32: i++;
;	genPlus 
	inc	r6
	cjne	r6,#0,00110$
	inc	r7
00110$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00101$
00103$:
;	puts.c:34: putchar('\n');
;	genCall 
	push	ar6
	push	ar7
;	genSend argreg = 1, size = 1 
	mov	dpl,#0x0A
	lcall	_putchar
	pop	ar7
	pop	ar6
;	puts.c:35: return i+1;
;	genPlus 
	mov	dph,r7
	mov	dpl,r6
	inc	dptr
;	did genPlusIncr
;	genRet 
;	genLabel 
00104$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
