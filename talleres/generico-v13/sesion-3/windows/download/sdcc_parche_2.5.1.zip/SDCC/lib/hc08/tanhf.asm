;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:56:17 2005
;--------------------------------------------------------
	.module tanhf
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _tanhf
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'tanhf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 2
;f                         Allocated to stack - offset -4
;g                         Allocated to stack - offset -8
;r                         Allocated to stack - offset -12
;sloc0                     Allocated to stack - offset -16
;------------------------------------------------------------
;tanhf.c:40: float tanhf(const float x) _FLOAT_FUNC_REENTRANT
;	-----------------------------------------
;	 function tanhf
;	-----------------------------------------
_tanhf:
	ais	#-16
;tanhf.c:44: f=fabsf(x);
	lda	22,s
	psha
	lda	22,s
	psha
	lda	22,s
	psha
	lda	22,s
	psha
	jsr	_fabsf
	sta	20,s
	stx	19,s
	lda	*__ret2
	sta	18,s
	lda	*__ret3
	sta	17,s
	ais	#4
;tanhf.c:45: if(f>SBIG) r=1.0;
	lda	13,s
	sta	___fsgt_PARM_1
	lda	14,s
	sta	(___fsgt_PARM_1 + 1)
	lda	15,s
	sta	(___fsgt_PARM_1 + 2)
	lda	16,s
	sta	(___fsgt_PARM_1 + 3)
	lda	#0x41
	sta	___fsgt_PARM_2
	lda	#0x10
	sta	(___fsgt_PARM_2 + 1)
	lda	#0x2C
	sta	(___fsgt_PARM_2 + 2)
	lda	#0xB0
	sta	(___fsgt_PARM_2 + 3)
	jsr	___fsgt
	tsta
; Peephole 2d	- eliminated jmp
	beq	00108$
00118$:
	lda	#0x3F
	sta	5,s
	lda	#0x80
	sta	6,s
	clra
	sta	7,s
	clra
	sta	8,s
	jmp	00109$
00108$:
;tanhf.c:46: else if(f>K1)
	lda	13,s
	sta	___fsgt_PARM_1
	lda	14,s
	sta	(___fsgt_PARM_1 + 1)
	lda	15,s
	sta	(___fsgt_PARM_1 + 2)
	lda	16,s
	sta	(___fsgt_PARM_1 + 3)
	lda	#0x3F
	sta	___fsgt_PARM_2
	lda	#0x0C
	sta	(___fsgt_PARM_2 + 1)
	lda	#0x9F
	sta	(___fsgt_PARM_2 + 2)
	lda	#0x54
	sta	(___fsgt_PARM_2 + 3)
	jsr	___fsgt
	tsta
	bne	00119$
	jmp	00105$
00119$:
;tanhf.c:48: r=0.5-1.0/(expf(f+f)+1.0);
	lda	13,s
	sta	___fsadd_PARM_1
	lda	14,s
	sta	(___fsadd_PARM_1 + 1)
	lda	15,s
	sta	(___fsadd_PARM_1 + 2)
	lda	16,s
	sta	(___fsadd_PARM_1 + 3)
	lda	13,s
	sta	___fsadd_PARM_2
	lda	14,s
	sta	(___fsadd_PARM_2 + 1)
	lda	15,s
	sta	(___fsadd_PARM_2 + 2)
	lda	16,s
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	(_expf_PARM_1 + 3)
	stx	(_expf_PARM_1 + 2)
	lda	*__ret2
	sta	(_expf_PARM_1 + 1)
	lda	*__ret3
	sta	_expf_PARM_1
	jsr	_expf
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	lda	#0x3F
	sta	___fsadd_PARM_2
	lda	#0x80
	sta	(___fsadd_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fsadd_PARM_2 + 2)
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	(___fsdiv_PARM_2 + 3)
	stx	(___fsdiv_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsdiv_PARM_2 + 1)
	lda	*__ret3
	sta	___fsdiv_PARM_2
	lda	#0x3F
	sta	___fsdiv_PARM_1
	lda	#0x80
	sta	(___fsdiv_PARM_1 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fsdiv_PARM_1 + 2)
	sta	(___fsdiv_PARM_1 + 3)
	jsr	___fsdiv
	sta	(___fssub_PARM_2 + 3)
	stx	(___fssub_PARM_2 + 2)
	lda	*__ret2
	sta	(___fssub_PARM_2 + 1)
	lda	*__ret3
	sta	___fssub_PARM_2
	lda	#0x3F
	sta	___fssub_PARM_1
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fssub_PARM_1 + 1)
	sta	(___fssub_PARM_1 + 2)
	sta	(___fssub_PARM_1 + 3)
	jsr	___fssub
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	5,s
	lda	2,s
	sta	6,s
	lda	3,s
	sta	7,s
	lda	4,s
	sta	8,s
;tanhf.c:49: r+=r;
	lda	5,s
	sta	___fsadd_PARM_1
	lda	6,s
	sta	(___fsadd_PARM_1 + 1)
	lda	7,s
	sta	(___fsadd_PARM_1 + 2)
	lda	8,s
	sta	(___fsadd_PARM_1 + 3)
	lda	5,s
	sta	___fsadd_PARM_2
	lda	6,s
	sta	(___fsadd_PARM_2 + 1)
	lda	7,s
	sta	(___fsadd_PARM_2 + 2)
	lda	8,s
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	5,s
	lda	2,s
	sta	6,s
	lda	3,s
	sta	7,s
	lda	4,s
	sta	8,s
	jmp	00109$
00105$:
;tanhf.c:51: else if(f<EPS) r=f;
	lda	13,s
	sta	___fslt_PARM_1
	lda	14,s
	sta	(___fslt_PARM_1 + 1)
	lda	15,s
	sta	(___fslt_PARM_1 + 2)
	lda	16,s
	sta	(___fslt_PARM_1 + 3)
	lda	#0x39
	sta	___fslt_PARM_2
	lda	#0x80
	sta	(___fslt_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fslt_PARM_2 + 2)
	sta	(___fslt_PARM_2 + 3)
	jsr	___fslt
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00120$:
	lda	13,s
	sta	5,s
	lda	14,s
	sta	6,s
	lda	15,s
	sta	7,s
	lda	16,s
	sta	8,s
	jmp	00109$
00102$:
;tanhf.c:54: g=f*f;
	lda	13,s
	sta	___fsmul_PARM_1
	lda	14,s
	sta	(___fsmul_PARM_1 + 1)
	lda	15,s
	sta	(___fsmul_PARM_1 + 2)
	lda	16,s
	sta	(___fsmul_PARM_1 + 3)
	lda	13,s
	sta	___fsmul_PARM_2
	lda	14,s
	sta	(___fsmul_PARM_2 + 1)
	lda	15,s
	sta	(___fsmul_PARM_2 + 2)
	lda	16,s
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	12,s
	stx	11,s
	lda	*__ret2
	sta	10,s
	lda	*__ret3
	sta	9,s
;tanhf.c:55: r=f+f*(P(g)/Q(g));
	lda	9,s
	sta	___fsmul_PARM_1
	lda	10,s
	sta	(___fsmul_PARM_1 + 1)
	lda	11,s
	sta	(___fsmul_PARM_1 + 2)
	lda	12,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0xBB
	sta	___fsmul_PARM_2
	lda	#0x7B
	sta	(___fsmul_PARM_2 + 1)
	lda	#0x11
	sta	(___fsmul_PARM_2 + 2)
	lda	#0xB2
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	lda	#0xBF
	sta	___fsadd_PARM_2
	lda	#0x52
	sta	(___fsadd_PARM_2 + 1)
	lda	#0xE2
	sta	(___fsadd_PARM_2 + 2)
	lda	#0xC6
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	(___fsmul_PARM_1 + 3)
	stx	(___fsmul_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsmul_PARM_1 + 1)
	lda	*__ret3
	sta	___fsmul_PARM_1
	lda	9,s
	sta	___fsmul_PARM_2
	lda	10,s
	sta	(___fsmul_PARM_2 + 1)
	lda	11,s
	sta	(___fsmul_PARM_2 + 2)
	lda	12,s
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsdiv_PARM_1 + 3)
	stx	(___fsdiv_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsdiv_PARM_1 + 1)
	lda	*__ret3
	sta	___fsdiv_PARM_1
	lda	9,s
	sta	___fsadd_PARM_1
	lda	10,s
	sta	(___fsadd_PARM_1 + 1)
	lda	11,s
	sta	(___fsadd_PARM_1 + 2)
	lda	12,s
	sta	(___fsadd_PARM_1 + 3)
	lda	#0x40
	sta	___fsadd_PARM_2
	lda	#0x1E
	sta	(___fsadd_PARM_2 + 1)
	lda	#0x2A
	sta	(___fsadd_PARM_2 + 2)
	lda	#0x1A
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	(___fsdiv_PARM_2 + 3)
	stx	(___fsdiv_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsdiv_PARM_2 + 1)
	lda	*__ret3
	sta	___fsdiv_PARM_2
	jsr	___fsdiv
	sta	(___fsmul_PARM_2 + 3)
	stx	(___fsmul_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsmul_PARM_2 + 1)
	lda	*__ret3
	sta	___fsmul_PARM_2
	lda	13,s
	sta	___fsmul_PARM_1
	lda	14,s
	sta	(___fsmul_PARM_1 + 1)
	lda	15,s
	sta	(___fsmul_PARM_1 + 2)
	lda	16,s
	sta	(___fsmul_PARM_1 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
	lda	13,s
	sta	___fsadd_PARM_1
	lda	14,s
	sta	(___fsadd_PARM_1 + 1)
	lda	15,s
	sta	(___fsadd_PARM_1 + 2)
	lda	16,s
	sta	(___fsadd_PARM_1 + 3)
	jsr	___fsadd
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	5,s
	lda	2,s
	sta	6,s
	lda	3,s
	sta	7,s
	lda	4,s
	sta	8,s
00109$:
;tanhf.c:57: if(x<0.0) r=-r;
	lda	19,s
	sta	___fslt_PARM_1
	lda	20,s
	sta	(___fslt_PARM_1 + 1)
	lda	21,s
	sta	(___fslt_PARM_1 + 2)
	lda	22,s
	sta	(___fslt_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fslt_PARM_2
	sta	(___fslt_PARM_2 + 1)
	sta	(___fslt_PARM_2 + 2)
	sta	(___fslt_PARM_2 + 3)
	jsr	___fslt
	tsta
; Peephole 2d	- eliminated jmp
	beq	00111$
00121$:
	lda	5,s
	eor	#0x80
	sta	5,s
00111$:
;tanhf.c:58: return r;
	lda	5,s
	sta	*__ret3
	lda	6,s
	sta	*__ret2
	ldx	7,s
	lda	8,s
00112$:
	ais	#16
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
