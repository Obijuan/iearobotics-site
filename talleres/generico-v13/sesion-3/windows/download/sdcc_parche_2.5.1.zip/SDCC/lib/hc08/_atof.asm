;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:57 2005
;--------------------------------------------------------
	.module _atof
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atof
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_atof_sloc0_1_0::
	.ds 2
_atof_sloc1_1_0::
	.ds 1
_atof_sloc2_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_atof_s_1_1::
	.ds 2
_atof_value_1_1::
	.ds 4
_atof_fraction_1_1::
	.ds 4
_atof_iexp_1_1::
	.ds 1
_atof_sign_1_1::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atof'
;------------------------------------------------------------
;sloc0                     Allocated with name '_atof_sloc0_1_0'
;sloc1                     Allocated with name '_atof_sloc1_1_0'
;sloc2                     Allocated with name '_atof_sloc2_1_0'
;s                         Allocated with name '_atof_s_1_1'
;value                     Allocated with name '_atof_value_1_1'
;fraction                  Allocated with name '_atof_fraction_1_1'
;iexp                      Allocated with name '_atof_iexp_1_1'
;sign                      Allocated with name '_atof_sign_1_1'
;------------------------------------------------------------
;_atof.c:23: float atof(char * s)
;	-----------------------------------------
;	 function atof
;	-----------------------------------------
_atof:
	sta	(_atof_s_1_1 + 1)
	stx	_atof_s_1_1
;_atof.c:30: while (isspace(*s)) s++;
	lda	_atof_s_1_1
	sta	*_atof_sloc0_1_0
	lda	(_atof_s_1_1 + 1)
	sta	*(_atof_sloc0_1_0 + 1)
00101$:
	ldhx	*_atof_sloc0_1_0
	lda	,x
	jsr	_isspace
	sta	*_atof_sloc1_1_0
	lda	*_atof_sloc0_1_0
	sta	_atof_s_1_1
	lda	*(_atof_sloc0_1_0 + 1)
	sta	(_atof_s_1_1 + 1)
	tst	*_atof_sloc1_1_0
; Peephole 2d	- eliminated jmp
	beq	00103$
00148$:
	ldhx	*_atof_sloc0_1_0
	aix	#1
	sthx	*_atof_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00101$
00103$:
;_atof.c:33: if (*s == '-')
	ldhx	*_atof_sloc0_1_0
	lda	,x
	cmp	#0x2D
; Peephole 2c	- eliminated jmp
	bne	00107$
00149$:
;_atof.c:35: sign=1;
	lda	#0x01
	sta	_atof_sign_1_1
;_atof.c:36: s++;
	lda	*(_atof_sloc0_1_0 + 1)
	add	#0x01
	sta	(_atof_s_1_1 + 1)
	lda	*_atof_sloc0_1_0
	adc	#0x00
	sta	_atof_s_1_1
; Peephole 3	- shortened jmp to bra
	bra	00108$
00107$:
;_atof.c:40: sign=0;
	clra
	sta	_atof_sign_1_1
;_atof.c:41: if (*s == '+') s++;
	ldhx	*_atof_sloc0_1_0
	lda	,x
	cmp	#0x2B
; Peephole 2c	- eliminated jmp
	bne	00108$
00150$:
	lda	*(_atof_sloc0_1_0 + 1)
	add	#0x01
	sta	(_atof_s_1_1 + 1)
	lda	*_atof_sloc0_1_0
	adc	#0x00
	sta	_atof_s_1_1
00108$:
;_atof.c:45: for (value=0.0; isdigit(*s); s++)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	_atof_value_1_1
	sta	(_atof_value_1_1 + 1)
	sta	(_atof_value_1_1 + 2)
	sta	(_atof_value_1_1 + 3)
	lda	_atof_s_1_1
	sta	*_atof_sloc0_1_0
	lda	(_atof_s_1_1 + 1)
	sta	*(_atof_sloc0_1_0 + 1)
00121$:
	ldhx	*_atof_sloc0_1_0
	lda	,x
	jsr	_isdigit
	sta	*_atof_sloc1_1_0
	lda	*_atof_sloc0_1_0
	sta	_atof_s_1_1
	lda	*(_atof_sloc0_1_0 + 1)
	sta	(_atof_s_1_1 + 1)
	tst	*_atof_sloc1_1_0
	bne	00151$
	jmp	00124$
00151$:
;_atof.c:47: value=10.0*value+(*s-'0');
	lda	_atof_value_1_1
	sta	___fsmul_PARM_1
	lda	(_atof_value_1_1 + 1)
	sta	(___fsmul_PARM_1 + 1)
	lda	(_atof_value_1_1 + 2)
	sta	(___fsmul_PARM_1 + 2)
	lda	(_atof_value_1_1 + 3)
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x41
	sta	___fsmul_PARM_2
	lda	#0x20
	sta	(___fsmul_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fsmul_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	ldhx	*_atof_sloc0_1_0
	lda	,x
	aix	#1
	sthx	*_atof_sloc0_1_0
	sta	*(_atof_sloc2_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atof_sloc2_1_0
	lda	*(_atof_sloc2_1_0 + 1)
	sub	#0x30
	sta	*(_atof_sloc2_1_0 + 1)
	lda	*_atof_sloc2_1_0
	sbc	#0x00
	sta	*_atof_sloc2_1_0
	ldx	*_atof_sloc2_1_0
	lda	*(_atof_sloc2_1_0 + 1)
	jsr	___sint2fs
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
	jsr	___fsadd
	sta	(_atof_value_1_1 + 3)
	stx	(_atof_value_1_1 + 2)
	lda	*__ret2
	sta	(_atof_value_1_1 + 1)
	lda	*__ret3
	sta	_atof_value_1_1
;_atof.c:45: for (value=0.0; isdigit(*s); s++)
	jmp	00121$
00124$:
;_atof.c:51: if (*s == '.')
	ldhx	*_atof_sloc0_1_0
	lda	,x
	cmp	#0x2E
	beq	00152$
	jmp	00110$
00152$:
;_atof.c:53: s++;
	lda	*(_atof_sloc0_1_0 + 1)
	add	#0x01
	sta	(_atof_s_1_1 + 1)
	lda	*_atof_sloc0_1_0
	adc	#0x00
	sta	_atof_s_1_1
;_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
	lda	#0x3D
	sta	_atof_fraction_1_1
; Peephole 5f   - eliminated redundant lda
	lda	#0xCC
	sta	(_atof_fraction_1_1 + 1)
	sta	(_atof_fraction_1_1 + 2)
	lda	#0xCD
	sta	(_atof_fraction_1_1 + 3)
	lda	_atof_s_1_1
	sta	*_atof_sloc2_1_0
	lda	(_atof_s_1_1 + 1)
	sta	*(_atof_sloc2_1_0 + 1)
00125$:
	ldhx	*_atof_sloc2_1_0
	lda	,x
	jsr	_isdigit
	sta	*_atof_sloc1_1_0
	lda	*_atof_sloc2_1_0
	sta	_atof_s_1_1
	lda	*(_atof_sloc2_1_0 + 1)
	sta	(_atof_s_1_1 + 1)
	tst	*_atof_sloc1_1_0
	bne	00153$
	jmp	00110$
00153$:
;_atof.c:56: value+=(*s-'0')*fraction;
	ldhx	*_atof_sloc2_1_0
	lda	,x
	aix	#1
	sthx	*_atof_sloc2_1_0
	sta	*(_atof_sloc0_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atof_sloc0_1_0
	lda	*(_atof_sloc0_1_0 + 1)
	sub	#0x30
	sta	*(_atof_sloc0_1_0 + 1)
	lda	*_atof_sloc0_1_0
	sbc	#0x00
	sta	*_atof_sloc0_1_0
	ldx	*_atof_sloc0_1_0
	lda	*(_atof_sloc0_1_0 + 1)
	jsr	___sint2fs
	sta	(___fsmul_PARM_1 + 3)
	stx	(___fsmul_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsmul_PARM_1 + 1)
	lda	*__ret3
	sta	___fsmul_PARM_1
	lda	_atof_fraction_1_1
	sta	___fsmul_PARM_2
	lda	(_atof_fraction_1_1 + 1)
	sta	(___fsmul_PARM_2 + 1)
	lda	(_atof_fraction_1_1 + 2)
	sta	(___fsmul_PARM_2 + 2)
	lda	(_atof_fraction_1_1 + 3)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
	lda	_atof_value_1_1
	sta	___fsadd_PARM_1
	lda	(_atof_value_1_1 + 1)
	sta	(___fsadd_PARM_1 + 1)
	lda	(_atof_value_1_1 + 2)
	sta	(___fsadd_PARM_1 + 2)
	lda	(_atof_value_1_1 + 3)
	sta	(___fsadd_PARM_1 + 3)
	jsr	___fsadd
	sta	(_atof_value_1_1 + 3)
	stx	(_atof_value_1_1 + 2)
	lda	*__ret2
	sta	(_atof_value_1_1 + 1)
	lda	*__ret3
	sta	_atof_value_1_1
;_atof.c:57: fraction*=0.1;
	lda	_atof_fraction_1_1
	sta	___fsmul_PARM_1
	lda	(_atof_fraction_1_1 + 1)
	sta	(___fsmul_PARM_1 + 1)
	lda	(_atof_fraction_1_1 + 2)
	sta	(___fsmul_PARM_1 + 2)
	lda	(_atof_fraction_1_1 + 3)
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x3D
	sta	___fsmul_PARM_2
; Peephole 5f   - eliminated redundant lda
	lda	#0xCC
	sta	(___fsmul_PARM_2 + 1)
	sta	(___fsmul_PARM_2 + 2)
	lda	#0xCD
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(_atof_fraction_1_1 + 3)
	stx	(_atof_fraction_1_1 + 2)
	lda	*__ret2
	sta	(_atof_fraction_1_1 + 1)
	lda	*__ret3
	sta	_atof_fraction_1_1
;_atof.c:54: for (fraction=0.1; isdigit(*s); s++)
	jmp	00125$
00110$:
;_atof.c:62: if (toupper(*s)=='E')
	lda	_atof_s_1_1
	ldx	(_atof_s_1_1 + 1)
	psha
	pulh
	lda	,x
	jsr	_islower
	tsta
; Peephole 2d	- eliminated jmp
	beq	00131$
00154$:
	lda	_atof_s_1_1
	ldx	(_atof_s_1_1 + 1)
	psha
	pulh
	lda	,x
	sta	*(_atof_sloc2_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atof_sloc2_1_0
	bclr	#5,*(_atof_sloc2_1_0 + 1)
; Peephole 3	- shortened jmp to bra
	bra	00132$
00131$:
	lda	_atof_s_1_1
	ldx	(_atof_s_1_1 + 1)
	psha
	pulh
	lda	,x
	sta	*(_atof_sloc2_1_0 + 1)
	rola	
	clra	
	sbc	#0x00
	sta	*_atof_sloc2_1_0
00132$:
	ldhx	*_atof_sloc2_1_0
	cphx	#0x0045
	beq	00155$
	jmp	00118$
00155$:
;_atof.c:64: s++;
	lda	(_atof_s_1_1 + 1)
	inca
	sta	(_atof_s_1_1 + 1)
	bne	00156$
	lda	_atof_s_1_1
	inca
	sta	_atof_s_1_1
00156$:
;_atof.c:65: iexp=(char)atoi(s);
	ldx	_atof_s_1_1
	lda	(_atof_s_1_1 + 1)
	jsr	_atoi
	sta	*(_atof_sloc2_1_0 + 1)
	stx	*_atof_sloc2_1_0
	lda	*(_atof_sloc2_1_0 + 1)
	sta	_atof_iexp_1_1
;_atof.c:67: while(iexp!=0)
00114$:
	lda	_atof_iexp_1_1
	cmp	#0x00
	bne	00157$
	jmp	00118$
00157$:
;_atof.c:69: if(iexp<0)
	lda	_atof_iexp_1_1
	cmp	#0x00
; Peephole 2l	- eliminated bra
	bge	00112$
00158$:
;_atof.c:71: value*=0.1;
	lda	_atof_value_1_1
	sta	___fsmul_PARM_1
	lda	(_atof_value_1_1 + 1)
	sta	(___fsmul_PARM_1 + 1)
	lda	(_atof_value_1_1 + 2)
	sta	(___fsmul_PARM_1 + 2)
	lda	(_atof_value_1_1 + 3)
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x3D
	sta	___fsmul_PARM_2
; Peephole 5f   - eliminated redundant lda
	lda	#0xCC
	sta	(___fsmul_PARM_2 + 1)
	sta	(___fsmul_PARM_2 + 2)
	lda	#0xCD
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(_atof_value_1_1 + 3)
	stx	(_atof_value_1_1 + 2)
	lda	*__ret2
	sta	(_atof_value_1_1 + 1)
	lda	*__ret3
	sta	_atof_value_1_1
;_atof.c:72: iexp++;
	lda	_atof_iexp_1_1
	inca
	sta	_atof_iexp_1_1
; Peephole 3	- shortened jmp to bra
	bra	00114$
00112$:
;_atof.c:76: value*=10.0;
	lda	_atof_value_1_1
	sta	___fsmul_PARM_1
	lda	(_atof_value_1_1 + 1)
	sta	(___fsmul_PARM_1 + 1)
	lda	(_atof_value_1_1 + 2)
	sta	(___fsmul_PARM_1 + 2)
	lda	(_atof_value_1_1 + 3)
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x41
	sta	___fsmul_PARM_2
	lda	#0x20
	sta	(___fsmul_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fsmul_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(_atof_value_1_1 + 3)
	stx	(_atof_value_1_1 + 2)
	lda	*__ret2
	sta	(_atof_value_1_1 + 1)
	lda	*__ret3
	sta	_atof_value_1_1
;_atof.c:77: iexp--;
	lda	_atof_iexp_1_1
	deca
	sta	_atof_iexp_1_1
	jmp	00114$
00118$:
;_atof.c:83: if(sign) value*=-1.0;
	lda	_atof_sign_1_1
; Peephole 2d	- eliminated jmp
	beq	00120$
00159$:
	lda	_atof_value_1_1
	sta	___fsmul_PARM_1
	lda	(_atof_value_1_1 + 1)
	sta	(___fsmul_PARM_1 + 1)
	lda	(_atof_value_1_1 + 2)
	sta	(___fsmul_PARM_1 + 2)
	lda	(_atof_value_1_1 + 3)
	sta	(___fsmul_PARM_1 + 3)
	lda	#0xBF
	sta	___fsmul_PARM_2
	lda	#0x80
	sta	(___fsmul_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fsmul_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(_atof_value_1_1 + 3)
	stx	(_atof_value_1_1 + 2)
	lda	*__ret2
	sta	(_atof_value_1_1 + 1)
	lda	*__ret3
	sta	_atof_value_1_1
00120$:
;_atof.c:84: return (value);
	lda	_atof_value_1_1
	sta	*__ret3
	lda	(_atof_value_1_1 + 1)
	sta	*__ret2
	ldx	(_atof_value_1_1 + 2)
	lda	(_atof_value_1_1 + 3)
00129$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
