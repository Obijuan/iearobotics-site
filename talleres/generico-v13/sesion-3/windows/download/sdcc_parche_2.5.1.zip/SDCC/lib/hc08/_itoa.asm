;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:23 2005
;--------------------------------------------------------
	.module _itoa
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __itoa
	.globl __uitoa
	.globl __itoa_PARM_3
	.globl __itoa_PARM_2
	.globl __uitoa_PARM_3
	.globl __uitoa_PARM_2
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
__uitoa_sloc0_1_0::
	.ds 1
__uitoa_sloc1_1_0::
	.ds 2
__uitoa_sloc2_1_0::
	.ds 2
__uitoa_sloc3_1_0::
	.ds 2
__uitoa_sloc4_1_0::
	.ds 2
__itoa_sloc0_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__uitoa_PARM_2::
	.ds 2
__uitoa_PARM_3::
	.ds 1
__uitoa_value_1_1::
	.ds 2
__itoa_PARM_2::
	.ds 2
__itoa_PARM_3::
	.ds 1
__itoa_value_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_uitoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__uitoa_sloc0_1_0'
;sloc1                     Allocated with name '__uitoa_sloc1_1_0'
;sloc2                     Allocated with name '__uitoa_sloc2_1_0'
;sloc3                     Allocated with name '__uitoa_sloc3_1_0'
;sloc4                     Allocated with name '__uitoa_sloc4_1_0'
;string                    Allocated with name '__uitoa_PARM_2'
;radix                     Allocated with name '__uitoa_PARM_3'
;value                     Allocated with name '__uitoa_value_1_1'
;index                     Allocated to registers 
;i                         Allocated to registers 
;------------------------------------------------------------
;_itoa.c:18: void _uitoa(unsigned int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _uitoa
;	-----------------------------------------
__uitoa:
	sta	(__uitoa_value_1_1 + 1)
	stx	__uitoa_value_1_1
;_itoa.c:26: do {
	mov	#0x10,*__uitoa_sloc0_1_0
00103$:
;_itoa.c:27: string[--index] = '0' + (value % radix);
	dec	*__uitoa_sloc0_1_0
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc1_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc1_1_0
	lda	__uitoa_PARM_3
	sta	(__moduint_PARM_2 + 1)
	clra
	sta	__moduint_PARM_2
	ldx	__uitoa_value_1_1
	lda	(__uitoa_value_1_1 + 1)
	jsr	__moduint
	sta	*(__uitoa_sloc2_1_0 + 1)
	stx	*__uitoa_sloc2_1_0
	lda	*(__uitoa_sloc2_1_0 + 1)
	add	#0x30
	ldhx	*__uitoa_sloc1_1_0
	sta	,x
;_itoa.c:28: if ( string[index] > '9') string[index] += 'A' - '9' - 1;
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc2_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc2_1_0
	ldhx	*__uitoa_sloc2_1_0
	lda	,x
	cmp	#0x39
; Peephole 2j	- eliminated bra
	ble	00102$
00115$:
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc2_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc2_1_0
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc1_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc1_1_0
	ldhx	*__uitoa_sloc1_1_0
	lda	,x
	add	#0x07
	ldhx	*__uitoa_sloc2_1_0
	sta	,x
00102$:
;_itoa.c:29: value /= radix;
	lda	__uitoa_PARM_3
	sta	(__divuint_PARM_2 + 1)
	clra
	sta	__divuint_PARM_2
	ldx	__uitoa_value_1_1
	lda	(__uitoa_value_1_1 + 1)
	jsr	__divuint
	sta	(__uitoa_value_1_1 + 1)
	stx	__uitoa_value_1_1
;_itoa.c:30: } while (value != 0);
	lda	(__uitoa_value_1_1 + 1)
	cmp	#0x00
	bne	00116$
	lda	__uitoa_value_1_1
	cmp	#0x00
	beq	00117$
00116$:
	jmp	00103$
00117$:
;_itoa.c:32: do {
	clr	*__uitoa_sloc2_1_0
	mov	*__uitoa_sloc0_1_0,*__uitoa_sloc1_1_0
00106$:
;_itoa.c:33: string[i++] = string[index++];
	mov	*__uitoa_sloc2_1_0,*__uitoa_sloc0_1_0
	inc	*__uitoa_sloc2_1_0
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc3_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc3_1_0
	mov	*__uitoa_sloc1_1_0,*__uitoa_sloc0_1_0
	inc	*__uitoa_sloc1_1_0
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc0_1_0
	sta	*(__uitoa_sloc4_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc4_1_0
	ldhx	*__uitoa_sloc4_1_0
	lda	,x
	ldhx	*__uitoa_sloc3_1_0
	sta	,x
;_itoa.c:34: } while ( index < NUMBER_OF_DIGITS );
	lda	*__uitoa_sloc1_1_0
	cmp	#0x10
; Peephole 2b	- eliminated jmp
	bcs	00106$
00118$:
;_itoa.c:36: string[i] = 0; /* string terminator */
	lda	(__uitoa_PARM_2 + 1)
	add	*__uitoa_sloc2_1_0
	sta	*(__uitoa_sloc4_1_0 + 1)
	lda	__uitoa_PARM_2
	adc	#0x00
	sta	*__uitoa_sloc4_1_0
	ldhx	*__uitoa_sloc4_1_0
	clra
	sta	,x
00109$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function '_itoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__itoa_sloc0_1_0'
;string                    Allocated with name '__itoa_PARM_2'
;radix                     Allocated with name '__itoa_PARM_3'
;value                     Allocated with name '__itoa_value_1_1'
;------------------------------------------------------------
;_itoa.c:39: void _itoa(int value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _itoa
;	-----------------------------------------
__itoa:
	sta	(__itoa_value_1_1 + 1)
	stx	__itoa_value_1_1
;_itoa.c:41: if (value < 0 && radix == 10) {
	lda	__itoa_value_1_1
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00102$
00108$:
	lda	__itoa_PARM_3
	cmp	#0x0A
; Peephole 2c	- eliminated jmp
	bne	00102$
00109$:
;_itoa.c:42: *string++ = '-';
	lda	__itoa_PARM_2
	sta	*__itoa_sloc0_1_0
	lda	(__itoa_PARM_2 + 1)
	sta	*(__itoa_sloc0_1_0 + 1)
	ldhx	*__itoa_sloc0_1_0
	lda	#0x2D
	sta	,x
	lda	*(__itoa_sloc0_1_0 + 1)
	add	#0x01
	sta	(__itoa_PARM_2 + 1)
	lda	*__itoa_sloc0_1_0
	adc	#0x00
	sta	__itoa_PARM_2
;_itoa.c:43: value = -value;
	clra
	sub	(__itoa_value_1_1 + 1)
	sta	(__itoa_value_1_1 + 1)
	clra
	sbc	__itoa_value_1_1
	sta	__itoa_value_1_1
00102$:
;_itoa.c:45: _uitoa(value, string, radix);
	lda	__itoa_PARM_2
	sta	__uitoa_PARM_2
	lda	(__itoa_PARM_2 + 1)
	sta	(__uitoa_PARM_2 + 1)
	lda	__itoa_PARM_3
	sta	__uitoa_PARM_3
	ldx	__itoa_value_1_1
	lda	(__itoa_value_1_1 + 1)
	jsr	__uitoa
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
