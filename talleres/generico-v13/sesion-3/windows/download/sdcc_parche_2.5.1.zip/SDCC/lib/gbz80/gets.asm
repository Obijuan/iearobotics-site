;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:24 2005
;--------------------------------------------------------
	.module gets
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _gets
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;gets.c:3: char * gets(const char *str) {
;	genLabel
;	genFunction
;	---------------------------------
; Function gets
; ---------------------------------
_gets_start::
_gets:
	lda	sp,-4(sp)
;gets.c:4: char *s=str;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _gets_s_1_1
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,2(sp)
	ld	(hl+),a
	ld	(hl),e
;gets.c:6: unsigned int count=0;
;	genAssign
;	AOP_STK for _gets_count_1_1
	lda	hl,0(sp)
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;gets.c:8: while (1) {
;	genLabel
00109$:
;gets.c:9: c=getchar();
;	genCall
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	call	_getchar
	ld	c,e
;	genAssign
;	(registers are the same)
;gets.c:10: switch(c) {
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,c
	cp	a,#0x08
	jp	z,00101$
00118$:
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,c
	cp	a,#0x0A
	jp	z,00105$
00119$:
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,c
	cp	a,#0x0D
	jp	z,00105$
00120$:
;	genGoto
	jp	00106$
;gets.c:11: case '\b': // backspace
;	genLabel
00101$:
;gets.c:12: if (count) {
;	genIfx
;	AOP_STK for _gets_count_1_1
	lda	hl,0(sp)
	ld	a,(hl+)
	or	a,(hl)
	jp	z,00109$
;gets.c:13: putchar ('\b');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x08
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:14: putchar (' ');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x20
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:15: putchar ('\b');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x08
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:16: s--;
;	genMinus
;	AOP_STK for _gets_s_1_1
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	dec	de
	dec	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;gets.c:17: count--;
;	genMinus
;	AOP_STK for _gets_count_1_1
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	dec	de
	dec	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;gets.c:19: break;
;	genGoto
	jp	00109$
;gets.c:21: case '\r': // CR or LF
;	genLabel
00105$:
;gets.c:22: putchar('\r');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x0D
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:23: putchar('\n');
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x0A
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:24: *s=0;
;	genAssign (pointer)
;	AOP_STK for _gets_s_1_1
;	isBitvar = 0
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,#0x00
	ld	(de),a
;gets.c:25: return str;
;	genRet
;	AOP_STK for 
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk 2
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jp	00111$
;gets.c:26: default:
;	genLabel
00106$:
;gets.c:27: *s++=c;
;	genAssign (pointer)
;	AOP_STK for _gets_s_1_1
;	isBitvar = 0
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
;	genPlus
;	AOP_STK for _gets_s_1_1
;	genPlusIncr
	dec	hl
	inc	(hl)
	jr	nz,00121$
	inc	hl
	inc	(hl)
00121$:
;gets.c:28: count++;
;	genPlus
;	AOP_STK for _gets_count_1_1
;	genPlusIncr
	lda	hl,0(sp)
	inc	(hl)
	jr	nz,00122$
	inc	hl
	inc	(hl)
00122$:
;gets.c:29: putchar(c);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_putchar
	lda	sp,1(sp)
;gets.c:31: }
;	genGoto
	jp	00109$
;	genLabel
00111$:
;	genEndFunction
	lda	sp,4(sp)
	ret
_gets_end::
	.area _CODE
