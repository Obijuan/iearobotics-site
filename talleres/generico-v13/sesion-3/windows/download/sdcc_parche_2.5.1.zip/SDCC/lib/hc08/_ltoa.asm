;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:23 2005
;--------------------------------------------------------
	.module _ltoa
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __ltoa
	.globl __ultoa
	.globl __ltoa_PARM_3
	.globl __ltoa_PARM_2
	.globl __ltoa_PARM_1
	.globl __ultoa_PARM_3
	.globl __ultoa_PARM_2
	.globl __ultoa_PARM_1
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
__ultoa_sloc0_1_0::
	.ds 1
__ultoa_sloc1_1_0::
	.ds 2
__ultoa_sloc2_1_0::
	.ds 4
__ultoa_sloc3_1_0::
	.ds 2
__ltoa_sloc0_1_0::
	.ds 2
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__ultoa_PARM_1::
	.ds 4
__ultoa_PARM_2::
	.ds 2
__ultoa_PARM_3::
	.ds 1
__ultoa_buffer_1_1::
	.ds 32
__ltoa_PARM_1::
	.ds 4
__ltoa_PARM_2::
	.ds 2
__ltoa_PARM_3::
	.ds 1
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_ultoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__ultoa_sloc0_1_0'
;sloc1                     Allocated with name '__ultoa_sloc1_1_0'
;sloc2                     Allocated with name '__ultoa_sloc2_1_0'
;sloc3                     Allocated with name '__ultoa_sloc3_1_0'
;value                     Allocated with name '__ultoa_PARM_1'
;string                    Allocated with name '__ultoa_PARM_2'
;radix                     Allocated with name '__ultoa_PARM_3'
;index                     Allocated to registers 
;buffer                    Allocated with name '__ultoa_buffer_1_1'
;------------------------------------------------------------
;_ltoa.c:18: void _ultoa(unsigned long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ultoa
;	-----------------------------------------
__ultoa:
;_ltoa.c:25: do {
	mov	#0x20,*__ultoa_sloc0_1_0
00103$:
;_ltoa.c:26: buffer[--index] = '0' + (value % radix);
	dec	*__ultoa_sloc0_1_0
	lda	#__ultoa_buffer_1_1
	add	*__ultoa_sloc0_1_0
	sta	*(__ultoa_sloc1_1_0 + 1)
	lda	#>__ultoa_buffer_1_1
	adc	#0x00
	sta	*__ultoa_sloc1_1_0
	lda	__ultoa_PARM_3
	sta	(__modulong_PARM_2 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(__modulong_PARM_2 + 2)
	sta	(__modulong_PARM_2 + 1)
	sta	__modulong_PARM_2
	lda	__ultoa_PARM_1
	sta	__modulong_PARM_1
	lda	(__ultoa_PARM_1 + 1)
	sta	(__modulong_PARM_1 + 1)
	lda	(__ultoa_PARM_1 + 2)
	sta	(__modulong_PARM_1 + 2)
	lda	(__ultoa_PARM_1 + 3)
	sta	(__modulong_PARM_1 + 3)
	jsr	__modulong
	sta	*(__ultoa_sloc2_1_0 + 3)
	stx	*(__ultoa_sloc2_1_0 + 2)
	mov	*__ret2,*(__ultoa_sloc2_1_0 + 1)
	mov	*__ret3,*__ultoa_sloc2_1_0
	lda	*(__ultoa_sloc2_1_0 + 3)
	add	#0x30
	ldhx	*__ultoa_sloc1_1_0
	sta	,x
;_ltoa.c:27: if ( buffer[index] > '9') buffer[index] += 'A' - '9' - 1;
	ldx	*__ultoa_sloc0_1_0
	clrh
	lda	__ultoa_buffer_1_1,x
	cmp	#0x39
; Peephole 2j	- eliminated bra
	ble	00102$
00115$:
	lda	#__ultoa_buffer_1_1
	add	*__ultoa_sloc0_1_0
	sta	*(__ultoa_sloc2_1_0 + 1)
	lda	#>__ultoa_buffer_1_1
	adc	#0x00
	sta	*__ultoa_sloc2_1_0
	ldx	*__ultoa_sloc0_1_0
	clrh
	lda	__ultoa_buffer_1_1,x
	add	#0x07
	ldhx	*__ultoa_sloc2_1_0
	sta	,x
00102$:
;_ltoa.c:28: value /= radix;
	lda	__ultoa_PARM_3
	sta	(__divulong_PARM_2 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(__divulong_PARM_2 + 2)
	sta	(__divulong_PARM_2 + 1)
	sta	__divulong_PARM_2
	lda	__ultoa_PARM_1
	sta	__divulong_PARM_1
	lda	(__ultoa_PARM_1 + 1)
	sta	(__divulong_PARM_1 + 1)
	lda	(__ultoa_PARM_1 + 2)
	sta	(__divulong_PARM_1 + 2)
	lda	(__ultoa_PARM_1 + 3)
	sta	(__divulong_PARM_1 + 3)
	jsr	__divulong
	sta	(__ultoa_PARM_1 + 3)
	stx	(__ultoa_PARM_1 + 2)
	lda	*__ret2
	sta	(__ultoa_PARM_1 + 1)
	lda	*__ret3
	sta	__ultoa_PARM_1
;_ltoa.c:29: } while (value != 0);
	lda	(__ultoa_PARM_1 + 3)
	cmp	#0x00
	bne	00116$
	lda	(__ultoa_PARM_1 + 2)
	cmp	#0x00
	bne	00116$
	lda	(__ultoa_PARM_1 + 1)
	cmp	#0x00
	bne	00116$
	lda	__ultoa_PARM_1
	cmp	#0x00
	beq	00117$
00116$:
	jmp	00103$
00117$:
;_ltoa.c:31: do {
	mov	*__ultoa_sloc0_1_0,*__ultoa_sloc2_1_0
	lda	__ultoa_PARM_2
	sta	*__ultoa_sloc1_1_0
	lda	(__ultoa_PARM_2 + 1)
	sta	*(__ultoa_sloc1_1_0 + 1)
00106$:
;_ltoa.c:32: *string++ = buffer[index++];
	mov	*__ultoa_sloc2_1_0,*__ultoa_sloc0_1_0
	inc	*__ultoa_sloc2_1_0
	ldx	*__ultoa_sloc0_1_0
	clrh
	lda	__ultoa_buffer_1_1,x
	ldhx	*__ultoa_sloc1_1_0
	sta	,x
	aix	#1
	sthx	*__ultoa_sloc1_1_0
;_ltoa.c:33: } while ( index < NUMBER_OF_DIGITS );
	lda	*__ultoa_sloc2_1_0
	cmp	#0x20
; Peephole 2b	- eliminated jmp
	bcs	00106$
00118$:
;_ltoa.c:35: *string = 0;  /* string terminator */
	ldhx	*__ultoa_sloc1_1_0
	clra
	sta	,x
00109$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function '_ltoa'
;------------------------------------------------------------
;sloc0                     Allocated with name '__ltoa_sloc0_1_0'
;value                     Allocated with name '__ltoa_PARM_1'
;string                    Allocated with name '__ltoa_PARM_2'
;radix                     Allocated with name '__ltoa_PARM_3'
;------------------------------------------------------------
;_ltoa.c:38: void _ltoa(long value, char* string, unsigned char radix)
;	-----------------------------------------
;	 function _ltoa
;	-----------------------------------------
__ltoa:
;_ltoa.c:40: if (value < 0 && radix == 10) {
	lda	__ltoa_PARM_1
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00102$
00108$:
	lda	__ltoa_PARM_3
	cmp	#0x0A
; Peephole 2c	- eliminated jmp
	bne	00102$
00109$:
;_ltoa.c:41: *string++ = '-';
	lda	__ltoa_PARM_2
	sta	*__ltoa_sloc0_1_0
	lda	(__ltoa_PARM_2 + 1)
	sta	*(__ltoa_sloc0_1_0 + 1)
	ldhx	*__ltoa_sloc0_1_0
	lda	#0x2D
	sta	,x
	lda	*(__ltoa_sloc0_1_0 + 1)
	add	#0x01
	sta	(__ltoa_PARM_2 + 1)
	lda	*__ltoa_sloc0_1_0
	adc	#0x00
	sta	__ltoa_PARM_2
;_ltoa.c:42: value = -value;
	clra
	sub	(__ltoa_PARM_1 + 3)
	sta	(__ltoa_PARM_1 + 3)
	clra
	sbc	(__ltoa_PARM_1 + 2)
	sta	(__ltoa_PARM_1 + 2)
	clra
	sbc	(__ltoa_PARM_1 + 1)
	sta	(__ltoa_PARM_1 + 1)
	clra
	sbc	__ltoa_PARM_1
	sta	__ltoa_PARM_1
00102$:
;_ltoa.c:44: _ultoa(value, string, radix);
	lda	__ltoa_PARM_1
	sta	__ultoa_PARM_1
	lda	(__ltoa_PARM_1 + 1)
	sta	(__ultoa_PARM_1 + 1)
	lda	(__ltoa_PARM_1 + 2)
	sta	(__ultoa_PARM_1 + 2)
	lda	(__ltoa_PARM_1 + 3)
	sta	(__ultoa_PARM_1 + 3)
	lda	__ltoa_PARM_2
	sta	__ultoa_PARM_2
	lda	(__ltoa_PARM_2 + 1)
	sta	(__ultoa_PARM_2 + 1)
	lda	__ltoa_PARM_3
	sta	__ultoa_PARM_3
	jsr	__ultoa
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
