;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:16 2005
;--------------------------------------------------------
	.module realloc
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _realloc
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;realloc.c:67: void xdata * realloc (void * p, size_t size)
;	genLabel
;	genFunction
;	---------------------------------
; Function realloc
; ---------------------------------
_realloc_start::
_realloc:
	lda	sp,-10(sp)
;realloc.c:120: }
;realloc.c:75: pthis = _sdcc_find_memheader(p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,12(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	__sdcc_find_memheader
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign
;	AOP_STK for _realloc_pthis_1_1
	lda	hl,8(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;realloc.c:76: if (pthis)
;	genIfx
;	AOP_STK for _realloc_pthis_1_1
	dec	hl
	ld	a,(hl+)
	or	a,(hl)
	jp	z,00114$
;realloc.c:78: if (size > (0xFFFF-HEADER_SIZE))
;	genCmpGt
;	AOP_STK for 
	ld	a,#0xF9
	lda	hl,14(sp)
	sub	a,(hl)
	ld	a,#0xFF
	inc	hl
	sbc	a,(hl)
	jp	nc,00111$
;realloc.c:80: ret = (void xdata *) NULL; //To prevent overflow in next line
;	genAssign
;	AOP_STK for _realloc_ret_1_1
	lda	hl,4(sp)
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;	genGoto
	jp	00115$
;	genLabel
00111$:
;realloc.c:84: size += HEADER_SIZE; //We need a memory for header too
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,14(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0006
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),d
;realloc.c:86: if ((((unsigned int)pthis->next) - ((unsigned int)pthis)) >= size)
;	genPointerGet
;	AOP_STK for _realloc_pthis_1_1
;	AOP_STK for _realloc__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,2(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genCast
;	AOP_STK for _realloc__1_0
;	AOP_STK for _realloc__1_0
	ld      (hl-),a
	ld	a,(hl)
	dec	hl
	dec	hl
	ld	(hl),a
	lda	hl,3(sp)
	ld	a,(hl)
	dec	hl
	dec	hl
	ld	(hl),a
;	genCast
;	AOP_STK for _realloc_pthis_1_1
	lda	hl,8(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genMinus
;	AOP_STK for _realloc__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	sub	a,c
	ld	e,a
	ld	a,d
	sbc	a,b
	ld	b,a
	ld	c,e
;	genCmpLt
;	AOP_STK for 
	ld	a,c
	lda	hl,14(sp)
	sub	a,(hl)
	ld	a,b
	inc	hl
	sbc	a,(hl)
	jp	c,00108$
;realloc.c:88: pthis->len = size;
;	genPlus
;	AOP_STK for _realloc_pthis_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genAssign (pointer)
;	AOP_STK for 
;	isBitvar = 0
	ld	e,c
	ld	d,b
	lda	hl,14(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;realloc.c:89: ret = p;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _realloc_ret_1_1
	lda	hl,12(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genGoto
	jp	00115$
;	genLabel
00108$:
;realloc.c:93: if ((_sdcc_prev_memheader) &&
;	genIfx
;	AOP_HL for __sdcc_prev_memheader
	ld	hl,#__sdcc_prev_memheader
	ld	a,(hl+)
	or	a,(hl)
	jp	z,00104$
;realloc.c:94: ((((unsigned int)pthis->next) -
;	genAssign
;	AOP_STK for _realloc__1_0
	lda	hl,2(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genCast
;	AOP_STK for _realloc__1_0
	lda	hl,0(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;realloc.c:95: ((unsigned int)_sdcc_prev_memheader) -
;	genCast
;	AOP_HL for __sdcc_prev_memheader
	ld	hl,#__sdcc_prev_memheader
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genMinus
;	AOP_STK for _realloc__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	sub	a,c
	ld	e,a
	ld	a,d
	sbc	a,b
	ld      (hl-),a
	ld	(hl),e
;realloc.c:96: _sdcc_prev_memheader->len) >= size))
;	genAssign
;	AOP_HL for __sdcc_prev_memheader
	ld	hl,#__sdcc_prev_memheader
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genPlus
;	genPlusIncr
	inc	bc
	inc	bc
	inc	bc
	inc	bc
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genMinus
;	AOP_STK for _realloc__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	sub	a,c
	ld	e,a
	ld	a,d
	sbc	a,b
	ld	b,a
	ld	c,e
;	genCmpLt
;	AOP_STK for 
	ld	a,c
	lda	hl,14(sp)
	sub	a,(hl)
	ld	a,b
	inc	hl
	sbc	a,(hl)
	jp	c,00104$
;realloc.c:98: pnew = (MEMHEADER xdata * )((char xdata *)_sdcc_prev_memheader + _sdcc_prev_memheader->len);
;	genAssign
;	(operands are equal 3)
;	genAssign
;	AOP_HL for __sdcc_prev_memheader
	ld	hl,#__sdcc_prev_memheader
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genPlus
;	genPlusIncr
	inc	bc
	inc	bc
	inc	bc
	inc	bc
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genPlus
;	AOP_HL for __sdcc_prev_memheader
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	a,(hl)
	add	a,c
	ld	c,a
	inc	hl
	ld	a,(hl)
	adc	a,b
	ld	b,a
;	genAssign
;	AOP_STK for _realloc_pnew_1_1
	lda	hl,6(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;realloc.c:99: _sdcc_prev_memheader->next = pnew;
;	genAssign
;	AOP_HL for __sdcc_prev_memheader
	ld	hl,#__sdcc_prev_memheader
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genAssign (pointer)
;	AOP_STK for _realloc_pnew_1_1
;	isBitvar = 0
	ld	e,c
	ld	d,b
	lda	hl,6(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;realloc.c:100: memmove(pnew, pthis, pthis->len);
;	genPlus
;	AOP_STK for _realloc_pthis_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	push	bc
;	genIpush
;	AOP_STK for _realloc_pthis_1_1
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for _realloc_pnew_1_1
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_memmove
	lda	sp,6(sp)
;realloc.c:101: pnew->len = size;
;	genPlus
;	AOP_STK for _realloc_pnew_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genAssign (pointer)
;	AOP_STK for 
;	isBitvar = 0
	ld	e,c
	ld	d,b
	lda	hl,14(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;realloc.c:102: ret = MEM(pnew);
;	genPlus
;	AOP_STK for _realloc_pnew_1_1
;	AOP_STK for _realloc_ret_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0006
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),d
;	genGoto
	jp	00115$
;	genLabel
00104$:
;realloc.c:106: ret = malloc(size - HEADER_SIZE);
;	genMinus
;	AOP_STK for 
	lda	hl,14(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0006
	ld	a,e
	sub	a,l
	ld	e,a
	ld	a,d
	sbc	a,h
	ld	b,a
	ld	c,e
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	push	bc
;	genCall
	call	_malloc
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign
;	AOP_STK for _realloc_ret_1_1
	lda	hl,4(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;realloc.c:107: if (ret)
;	genIfx
;	AOP_STK for _realloc_ret_1_1
	dec	hl
	ld	a,(hl+)
	or	a,(hl)
	jp	z,00115$
;realloc.c:109: memcpy(ret, MEM(pthis), pthis->len - HEADER_SIZE);
;	genPlus
;	AOP_STK for _realloc_pthis_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genMinus
;	AOP_STK for _realloc__1_0
	ld	de,#0x0006
	ld	a,c
	sub	a,e
	ld	e,a
	ld	a,b
	sbc	a,d
	lda	hl,1(sp)
	ld      (hl-),a
	ld	(hl),e
;	genPlus
;	AOP_STK for _realloc_pthis_1_1
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0006
	add	hl,de
	ld	c,l
	ld	b,h
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for _realloc__1_0
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	push	bc
;	genIpush
;	AOP_STK for _realloc_ret_1_1
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_memcpy
	lda	sp,6(sp)
;realloc.c:110: free(p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,12(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_free
	lda	sp,2(sp)
;	genGoto
	jp	00115$
;	genLabel
00114$:
;realloc.c:118: ret = malloc(size);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_malloc
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign
;	AOP_STK for _realloc_ret_1_1
	lda	hl,4(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genLabel
00115$:
;realloc.c:121: return ret;
;	genRet
;	AOP_STK for _realloc_ret_1_1
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk -6
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;	genLabel
00116$:
;	genEndFunction
	lda	sp,10(sp)
	ret
_realloc_end::
	.area _CODE
