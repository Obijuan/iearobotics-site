;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:48:12 2005
;--------------------------------------------------------
	.module _strstr
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strstr_PARM_2
	.globl _strstr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_strstr_PARM_2::
	.ds 4
_strstr_cp_1_1::
	.ds 4
_strstr_sloc0_1_0::
	.ds 4
_strstr_sloc1_1_0::
	.ds 4
_strstr_sloc2_1_0::
	.ds 1
_strstr_sloc3_1_0::
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'strstr'
;------------------------------------------------------------
;str2                      Allocated with name '_strstr_PARM_2'
;str1                      Allocated to registers r6 r3 r4 r5 
;cp                        Allocated with name '_strstr_cp_1_1'
;s1                        Allocated to registers 
;s2                        Allocated to registers r6 r7 r0 r1 
;sloc0                     Allocated with name '_strstr_sloc0_1_0'
;sloc1                     Allocated with name '_strstr_sloc1_1_0'
;sloc2                     Allocated with name '_strstr_sloc2_1_0'
;sloc3                     Allocated with name '_strstr_sloc3_1_0'
;------------------------------------------------------------
;	_strstr.c:26: char * strstr (
;	genFunction 
;	-----------------------------------------
;	 function strstr
;	-----------------------------------------
_strstr:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r6,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_strstr.c:31: char * cp = str1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strstr_cp_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_strstr.c:35: if ( !*str2 )
;	genAssign 
	mov	dptr,#_strstr_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_strstr_sloc0_1_0
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	mov     dptr, #_strstr_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r2,a
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00122$
00123$:
;	_strstr.c:36: return str1;
;	genRet 
	mov	dpl,r6
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	ljmp	00113$
;	_strstr.c:38: while (*cp)
;	genLabel 
00122$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
;	genLabel 
00110$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
	jnz	00124$
	ljmp	00112$
00124$:
;	_strstr.c:41: s2 = str2;
;	genAssign 
	mov	dptr,#_strstr_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	_strstr.c:43: while ( *s1 && *s2 && !(*s1-*s2) )
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strstr_sloc1_1_0
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00105$:
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_strstr_sloc1_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
; Peephole 220a removed bogus DPS set
	mov	dps, #1
	mov	dptr, #_strstr_sloc2_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genIfx 
	mov	dptr,#_strstr_sloc2_1_0
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00125$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	dps, #1
	mov	dptr, #_strstr_sloc3_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genIfx 
	mov	dptr,#_strstr_sloc3_1_0
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00126$:
;	genMinus 
	mov	dptr,#_strstr_sloc3_1_0
	mov	dps, #1
	mov	dptr, #_strstr_sloc2_1_0
	dec	dps
	clr	c
	movx	a,@dptr
	mov	b,a
	inc	dps
	movx	a,@dptr
	subb	a,b
	mov	dps,#0
;	genIfx 
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00107$
00127$:
;	_strstr.c:44: s1++, s2++;
;	genPlus 
	mov	dptr,#_strstr_sloc1_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genPlus 
	inc	r6
	cjne	r6,#0,00128$
	inc	r7
	cjne	r7,#0,00128$
	inc	r0
00128$:
;	did genPlusIncr
;	genGoto 
	ljmp	00105$
;	genLabel 
00107$:
;	_strstr.c:46: if (!*s2)
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00109$
00129$:
;	_strstr.c:47: return(cp);
;	genRet 
	mov     dps, #1
	mov     dptr, #_strstr_cp_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00113$
00109$:
;	_strstr.c:49: cp++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00130$
	inc	r3
	cjne	r3,#0,00130$
	inc	r4
00130$:
;	did genPlusIncr
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_strstr_cp_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genGoto 
	ljmp	00110$
;	genLabel 
00112$:
;	_strstr.c:52: return (NULL) ;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
;	genLabel 
00113$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
