;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:53:53 2005
;--------------------------------------------------------
	.module _strncmp
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strncmp
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_strncmp.c:26: int strncmp (
;	genLabel
;	genFunction
;	---------------------------------
; Function strncmp
; ---------------------------------
_strncmp_start::
_strncmp:
	lda	sp,-6(sp)
;_strncmp.c:32: if (!count)
;	genIfx
;	AOP_STK for 
	lda	hl,12(sp)
	ld	a,(hl+)
	or	a,(hl)
	jp	nz,00114$
;_strncmp.c:33: return(0);
;	genRet
; Dump of IC_LEFT: type AOP_LIT size 2
	ld	de,#0x0000
	jp	00108$
;_strncmp.c:35: while (--count && *first && *first == *last) {
;	genLabel
00114$:
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strncmp__1_0
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strncmp__1_0
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strncmp__1_0
	lda	hl,12(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,2(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00105$:
;	genMinus
;	AOP_STK for _strncmp__1_0
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	dec	de
	dec	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;	genIfx
;	AOP_STK for _strncmp__1_0
	dec	hl
	ld	a,(hl+)
	or	a,(hl)
	jp	z,00107$
;	genPointerGet
;	AOP_STK for _strncmp__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	b,a
;	genIfx
	xor	a,a
	or	a,b
	jp	z,00107$
;	genPointerGet
;	AOP_STK for _strncmp__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	a,b
	cp	c
	jp	nz,00107$
	jr	00116$
00115$:
	jp	00107$
00116$:
;_strncmp.c:36: first++;
;	genPlus
;	AOP_STK for _strncmp__1_0
;	genPlusIncr
	lda	hl,0(sp)
	inc	(hl)
	jr	nz,00117$
	inc	hl
	inc	(hl)
00117$:
;_strncmp.c:37: last++;
;	genPlus
;	AOP_STK for _strncmp__1_0
;	genPlusIncr
	lda	hl,4(sp)
	inc	(hl)
	jr	nz,00118$
	inc	hl
	inc	(hl)
00118$:
;	genGoto
	jp	00105$
;	genLabel
00107$:
;_strncmp.c:40: return( *first - *last );
;	genPointerGet
;	AOP_STK for _strncmp__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genCast
;	AOP_STK for _strncmp__1_0
	dec	hl
	ld	(hl),c
	ld	a,c
	rla	
	sbc	a,a
	inc	hl
	ld	(hl),a
;	genPointerGet
;	AOP_STK for _strncmp__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCast
; Removed redundent load
	ld	c,a
	rla	
	sbc	a,a
	ld	b,a
;	genMinus
;	AOP_STK for _strncmp__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	sub	a,c
	ld	e,a
	ld	a,d
	sbc	a,b
	ld	d,a
;	genRet
; Dump of IC_LEFT: type AOP_STR size 2
;	genLabel
00108$:
;	genEndFunction
	lda	sp,6(sp)
	ret
_strncmp_end::
	.area _CODE
