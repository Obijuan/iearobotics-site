;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:50:08 2005
;--------------------------------------------------------
	.module _atol
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atol
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_atol_s_1_1::
	.ds 4
_atol_sign_1_1::
	.ds 1
_atol_sloc0_1_0::
	.ds 1
_atol_sloc1_1_0::
	.ds 4
_atol_sloc2_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atol'
;------------------------------------------------------------
;s                         Allocated with name '_atol_s_1_1'
;rv                        Allocated to registers r6 r7 r0 r1 
;sign                      Allocated with name '_atol_sign_1_1'
;sloc0                     Allocated with name '_atol_sloc0_1_0'
;sloc1                     Allocated with name '_atol_sloc1_1_0'
;sloc2                     Allocated with name '_atol_sloc2_1_0'
;------------------------------------------------------------
;	_atol.c:25: long atol(char * s)
;	genFunction 
;	-----------------------------------------
;	 function atol
;	-----------------------------------------
_atol:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_atol_s_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	_atol.c:27: register long rv=0; 
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r6,#0x00
	mov	r7,#0x00
	mov	r0,#0x00
	mov	r1,#0x00
;	_atol.c:31: while (*s) {
;	genAssign 
	mov	dptr,#_atol_s_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genLabel 
00107$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	mov	dps, #1
	mov	dptr, #_atol_sloc0_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genIfx 
	mov	dptr,#_atol_sloc0_1_0
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00109$
00133$:
;	_atol.c:32: if (*s <= '9' && *s >= '0')
;	genCmpGt 
	mov	dptr,#_atol_sloc0_1_0
;	genCmp
	clr	c
; Peephole 159   avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	xch	a, b
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00102$
00134$:
;	genCmpLt 
	mov	dptr,#_atol_sloc0_1_0
;	genCmp
	clr	c
	movx	a,@dptr
	xrl	a,#0x80
	subb	a,#0xB0
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00109$
00135$:
;	_atol.c:33: break;
;	genLabel 
00102$:
;	_atol.c:34: if (*s == '-' || *s == '+') 
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	mov	dps, #1
	mov	dptr, #_atol_sloc0_1_0
	dec	dps
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genCmpEq 
	mov	dptr,#_atol_sloc0_1_0
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x2D,00136$
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00136$:
;	genCmpEq 
	mov	dptr,#_atol_sloc0_1_0
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x2B,00137$
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00137$:
;	_atol.c:36: s++;
;	genPlus 
	inc	r2
	cjne	r2,#0,00138$
	inc	r3
	cjne	r3,#0,00138$
	inc	r4
00138$:
;	did genPlusIncr
;	genGoto 
	ljmp	00107$
;	genLabel 
00109$:
;	_atol.c:39: sign = (*s == '-');
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_atol_s_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__gptrget
;	genCmpEq 
;	gencjne
;	gencjneshort
; Peephole 105   removed redundant mov
	mov  r2,a
	cjne	a,#0x2D,00139$
	mov	a,#1
	sjmp	00140$
00139$:
	clr	a
00140$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 100   removed redundant mov
	mov  r3,a
	mov  dptr,#_atol_sign_1_1
	movx @dptr,a
;	_atol.c:40: if (*s == '-' || *s == '+') s++;
;	genIfx 
	mov	a,r3
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00110$
00141$:
;	genCmpEq 
;	gencjneshort
	mov	a,r2
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x2B,00131$
;00142$:
; Peephole 200   removed redundant sjmp
00143$:
;	genLabel 
00110$:
;	genPlus 
	mov	dptr,#_atol_s_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_atol.c:42: while (*s && *s >= '0' && *s <= '9') {
;	genLabel 
00131$:
;	genAssign 
	mov	dptr,#_atol_s_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_atol_sloc1_1_0
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00115$:
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_atol_sloc1_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r2,a
;	genIfxJump
	jnz	00144$
	ljmp	00117$
00144$:
;	genCmpLt 
;	genCmp
	clr	c
	mov	a,r2
	xrl	a,#0x80
	subb	a,#0xB0
;	genIfxJump
	jnc	00145$
	ljmp	00117$
00145$:
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 159   avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r2
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00117$
00146$:
;	_atol.c:43: rv = (rv * 10) + (*s - '0');
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,#0x0A
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar2
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__mullong
	mov     dps, #1
	mov     dptr, #_atol_sloc2_1_0
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
	pop	ar2
;	genCast 
	mov	a,r2
	rlc	a
	subb	a,acc
	mov	r3,a
;	genMinus 
	mov	a,r2
	add	a,#0xD0
	mov	r2,a
	mov	a,r3
	addc	a,#0xFF
;	genCast 
; Peephole 105   removed redundant mov
	mov  r3,a
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genPlus 
	mov	dptr,#_atol_sloc2_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	mov	r1,a
;	_atol.c:44: s++;
;	genPlus 
	mov	dptr,#_atol_sloc1_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genGoto 
	ljmp	00115$
;	genLabel 
00117$:
;	_atol.c:47: return (sign ? -rv : rv);
;	genIfx 
	mov	dptr,#_atol_sign_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00120$
00147$:
;	genUminus 
	clr	c
	clr	a
	subb	a,r6
	mov	r2,a
	clr	a
	subb	a,r7
	mov	r3,a
	clr	a
	subb	a,r0
	mov	r4,a
	clr	a
	subb	a,r1
	mov	r5,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00120$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genLabel 
00121$:
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00118$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
