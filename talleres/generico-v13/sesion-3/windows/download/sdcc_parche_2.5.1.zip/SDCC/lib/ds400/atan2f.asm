;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:52:41 2005
;--------------------------------------------------------
	.module atan2f
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atan2f_PARM_2
	.globl _atan2f
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_atan2f_PARM_2::
	.ds 4
_atan2f_x_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atan2f'
;------------------------------------------------------------
;y                         Allocated with name '_atan2f_PARM_2'
;x                         Allocated with name '_atan2f_x_1_1'
;r                         Allocated to registers r2 r3 r4 r5 
;------------------------------------------------------------
;	atan2f.c:24: float atan2f(const float x, const float y)
;	genFunction 
;	-----------------------------------------
;	 function atan2f
;	-----------------------------------------
_atan2f:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_atan2f_x_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	atan2f.c:28: if ((x==0.0) && (y==0.0))
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fseq_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fseq
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00121$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fseq_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_PARM_2
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fseq
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00122$:
;	atan2f.c:30: errno=EDOM;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_errno
	mov	a,#0x21
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	atan2f.c:31: return 0.0;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00109$
;	genLabel 
00102$:
;	atan2f.c:34: if(fabsf(y)>=fabsf(x))
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_PARM_2
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_fabsf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genCall 
	push	ar6
	push	ar7
	push	ar0
	push	ar1
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_fabsf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
	pop	ar1
	pop	ar0
	pop	ar7
	pop	ar6
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fslt
;	genIfx 
	mov	a,dpl
;	genIfxJump
	jz	00123$
	ljmp	00107$
00123$:
;	atan2f.c:36: r=atanf(x/y);
;	genAssign 
	mov	dptr,#_atan2f_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsdiv_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_atan2f_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsdiv
;	genCall 
;	genSend argreg = 1, size = 4 
	lcall	_atanf
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	atan2f.c:37: if(y<0.0) r+=(x>=0?PI:-PI);
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_PARM_2
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
	jnz	00124$
	ljmp	00108$
00124$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genNot 
	mov	a,dpl
	cjne	a,#1,00125$
00125$:
	clr	a
	rlc	a
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00111$
00126$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0x49
	mov	r1,#0x40
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00112$
00111$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0x49
	mov	r1,#0xC0
;	genLabel 
00112$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genGoto 
	ljmp	00108$
;	genLabel 
00107$:
;	atan2f.c:41: r=-atanf(y/x);
;	genAssign 
	mov	dptr,#_atan2f_x_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsdiv_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_atan2f_PARM_2
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsdiv
;	genCall 
;	genSend argreg = 1, size = 4 
	lcall	_atanf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genUminus 
;	genUminusFloat
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	a,r1
	cpl	acc.7
	mov	r5,a
;	atan2f.c:42: r+=(x<0.0?-HALF_PI:HALF_PI);
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_atan2f_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00113$
00127$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0xC9
	mov	r1,#0xBF
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00114$
00113$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0xDB
	mov	r7,#0x0F
	mov	r0,#0xC9
	mov	r1,#0x3F
;	genLabel 
00114$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genLabel 
00108$:
;	atan2f.c:44: return r;
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00109$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
