;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:58 2005
;--------------------------------------------------------
	.module assert
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __assert
	.globl __assert_PARM_3
	.globl __assert_PARM_2
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
__assert_PARM_2::
	.ds 2
__assert_PARM_3::
	.ds 2
__assert_expr_1_1::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_assert'
;------------------------------------------------------------
;filename                  Allocated with name '__assert_PARM_2'
;linenumber                Allocated with name '__assert_PARM_3'
;expr                      Allocated with name '__assert_expr_1_1'
;------------------------------------------------------------
;assert.c:4: void _assert(char *expr, const char *filename, unsigned int linenumber)
;	-----------------------------------------
;	 function _assert
;	-----------------------------------------
__assert:
	sta	(__assert_expr_1_1 + 1)
	stx	__assert_expr_1_1
;assert.c:6: printf("Assert(%s) failed at line %u in file %s.\n",
	lda	(__assert_PARM_2 + 1)
	psha
	lda	__assert_PARM_2
	psha
	lda	(__assert_PARM_3 + 1)
	psha
	lda	__assert_PARM_3
	psha
	lda	(__assert_expr_1_1 + 1)
	psha
	lda	__assert_expr_1_1
	psha
	ldhx	#__str_0
	pshx
	pshh
	jsr	_printf
	ais	#8
;assert.c:8: while(1);
00102$:
; Peephole 3	- shortened jmp to bra
	bra	00102$
00104$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
__str_0:
	.ascii "Assert(%s) failed at line %u in file %s."
	.db 0x0A
	.db 0x00
	.area XINIT
