;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:50 2005
;--------------------------------------------------------
	.module _moduint
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __moduint_PARM_2
	.globl __moduint
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__moduint_PARM_2::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_moduint'
;------------------------------------------------------------
;b                         Allocated with name '__moduint_PARM_2'
;a                         Allocated to registers r2 r3 
;count                     Allocated to registers r4 
;------------------------------------------------------------
;	_moduint.c:172: _moduint (unsigned int a, unsigned int b)
;	genFunction 
;	-----------------------------------------
;	 function _moduint
;	-----------------------------------------
__moduint:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	dpl1,dpl
	mov	dph1,dph
;	_moduint.c:174: unsigned char count = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r4,#0x00
;	_moduint.c:177: while (!MSB_SET(b))
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r5,#0x00
;	genLabel 
00103$:
	mov	dptr,#__moduint_PARM_2
;	genGetHbit 
	inc	dptr
	movx	a,@dptr
	rl	a
	anl	a,#1
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00117$
00119$:
;	_moduint.c:179: b <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 2
	mov	dptr,#__moduint_PARM_2
;	genlshTwo 
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__moduint_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	_moduint.c:180: if (b > a)
;	genCmpGt 
	mov	dptr,#__moduint_PARM_2
;	genCmp
	clr	c
	mov	a,dpl1
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,dph1
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00102$
00120$:
;	_moduint.c:182: b >>=1;
;	genRightShift 
;	genRightShiftLiteral (1), size 2
	mov	dptr,#__moduint_PARM_2
;	genrshTwo
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	xch	a,r6
	rrc	a
	xch	a,r6
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__moduint_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	_moduint.c:183: break;
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00117$
00102$:
;	_moduint.c:185: count++;
;	genPlus 
	inc	r5
;	did genPlusIncr
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r5
;	genGoto 
;	_moduint.c:187: do
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00117$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	genLabel 
00108$:
;	_moduint.c:189: if (a >= b)
;	genCmpLt 
	mov	dptr,#__moduint_PARM_2
;	genCmp
	clr	c
	mov	a,dpl1
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,dph1
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00107$
00121$:
;	_moduint.c:190: a -= b;
;	genMinus 
	mov	dptr,#__moduint_PARM_2
	clr	c
	movx	a,@dptr
	mov	b,a
	mov	a,dpl1
	subb	a,b
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	a,dph1
	subb	a,b
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dpl1,r5
	mov	dph1,r6
;	genLabel 
00107$:
;	_moduint.c:191: b >>= 1;
;	genRightShift 
;	genRightShiftLiteral (1), size 2
	mov	dptr,#__moduint_PARM_2
;	genrshTwo
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	xch	a,r5
	rrc	a
	xch	a,r5
	mov	r6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__moduint_PARM_2
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_moduint.c:193: while (count--);
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar5,r4
;	genMinus 
	dec	r4
;	genIfx 
	mov	a,r5
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00108$
00122$:
;	_moduint.c:194: return a;
;	genRet 
	mov	dpl,dpl1
	mov	dph,dph1
;	genLabel 
00111$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
