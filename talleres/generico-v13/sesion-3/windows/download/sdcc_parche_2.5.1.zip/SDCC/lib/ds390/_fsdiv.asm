;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:17 2005
;--------------------------------------------------------
	.module _fsdiv
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsdiv_PARM_2
	.globl ___fsdiv
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
___fsdiv_PARM_2::
	.ds 4
___fsdiv_fl1_1_1::
	.ds 4
___fsdiv_fl2_1_1::
	.ds 4
___fsdiv_result_1_1::
	.ds 4
___fsdiv_mask_1_1::
	.ds 4
___fsdiv_mant1_1_1::
	.ds 4
___fsdiv_mant2_1_1::
	.ds 4
___fsdiv_exp_1_1::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsdiv'
;------------------------------------------------------------
;a2                        Allocated with name '___fsdiv_PARM_2'
;a1                        Allocated to registers r2 r3 r4 r5 
;fl1                       Allocated with name '___fsdiv_fl1_1_1'
;fl2                       Allocated with name '___fsdiv_fl2_1_1'
;result                    Allocated with name '___fsdiv_result_1_1'
;mask                      Allocated with name '___fsdiv_mask_1_1'
;mant1                     Allocated with name '___fsdiv_mant1_1_1'
;mant2                     Allocated with name '___fsdiv_mant2_1_1'
;exp                       Allocated with name '___fsdiv_exp_1_1'
;sign                      Allocated to registers r2 
;------------------------------------------------------------
;	_fsdiv.c:235: float __fsdiv (float a1, float a2)
;	genFunction 
;	-----------------------------------------
;	 function __fsdiv
;	-----------------------------------------
___fsdiv:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_fsdiv.c:244: fl1.f = a1;
;	genPointerSet 
	mov	dptr,#___fsdiv_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsdiv.c:245: fl2.f = a2;
;	genPointerSet 
	mov	dptr,#___fsdiv_fl2_1_1
	mov     dps, #1
	mov     dptr, #___fsdiv_PARM_2
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
;	_fsdiv.c:248: exp = EXP (fl1.l) ;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0
	mov	r5,#0
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genCast 
	mov	dptr,#___fsdiv_exp_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_fsdiv.c:249: exp -= EXP (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0
	mov	r5,#0
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genCast 
	mov	dptr,#___fsdiv_exp_1_1
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genMinus 
	clr	c
	mov	a,r6
	subb	a,r2
	mov	r2,a
	mov	a,r7
	subb	a,r3
	mov	r3,a
	mov	a,r0
	subb	a,r4
	mov	r4,a
	mov	a,r1
	subb	a,r5
	mov	r5,a
;	genCast 
	mov	dptr,#___fsdiv_exp_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_fsdiv.c:250: exp += EXCESS;
;	genPlus 
	mov	dptr,#___fsdiv_exp_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x7E
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	_fsdiv.c:253: sign = SIGN (fl1.l) ^ SIGN (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r5,a
	rl	a
	anl	a,#1
	mov	r2,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r6,a
	rl	a
	anl	a,#1
;	genXor 
; Peephole 105   removed redundant mov
	mov  r3,a
	xrl	ar2,a
;	_fsdiv.c:256: if (!fl2.l)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genIfx 
	mov	a,r3
	orl	a,r4
	orl	a,r5
	orl	a,r6
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00123$:
;	_fsdiv.c:258: return (-1.0);
;	genRet 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
	mov	dpx,#0x80
	mov	b,#0xBF
	ljmp	00112$
;	genLabel 
00102$:
;	_fsdiv.c:261: if (!fl1.l)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genIfx 
	mov	a,r3
	orl	a,r4
	orl	a,r5
	orl	a,r6
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00104$
00124$:
;	_fsdiv.c:262: return (0);
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00112$
;	genLabel 
00104$:
;	_fsdiv.c:265: mant1 = MANT (fl1.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genAnd 
	anl	ar5,#0x7F
	mov	r6,#0
;	genOr 
	mov	dptr,#___fsdiv_mant1_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	better literal OR.
	mov	a,r5
	orl	a, #0x80
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:266: mant2 = MANT (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genAnd 
	anl	ar5,#0x7F
	mov	r6,#0
;	genOr 
	mov	dptr,#___fsdiv_mant2_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	better literal OR.
	mov	a,r5
	orl	a, #0x80
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:269: if (mant1 < mant2)
;	genCmpLt 
	mov	dptr,#___fsdiv_mant2_1_1
	mov	dps, #1
	mov	dptr, #___fsdiv_mant1_1_1
	dec	dps
;	genCmp
	clr	c
	mov	dps,#1
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xrl	a,#0x80
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00106$
00125$:
;	_fsdiv.c:271: mant1 <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	dptr,#___fsdiv_mant1_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r3,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r5,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r6,a
	sjmp	00127$
00126$:
	mov	a,r3
	add	a,acc
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
	mov	a,r6
	rlc	a
	mov	r6,a
00127$:
	djnz	b,00126$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_mant1_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:272: exp--;
;	genMinus 
	mov	dptr,#___fsdiv_exp_1_1
	movx	a,@dptr
	add	a,#0xFF
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	mov	r4,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_exp_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genLabel 
00106$:
;	_fsdiv.c:276: mask = 0x1000000;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_mask_1_1
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
;	_fsdiv.c:277: result = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_result_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	_fsdiv.c:278: while (mask)
;	genLabel 
00109$:
;	genIfx 
	mov	dptr,#___fsdiv_mask_1_1
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
	jnz	00128$
	ljmp	00111$
00128$:
;	_fsdiv.c:280: if (mant1 >= mant2)
;	genCmpLt 
	mov	dptr,#___fsdiv_mant2_1_1
	mov	dps, #1
	mov	dptr, #___fsdiv_mant1_1_1
	dec	dps
;	genCmp
	clr	c
	mov	dps,#1
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	dps,#1
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xrl	a,#0x80
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
	jnc	00129$
	ljmp	00108$
00129$:
;	_fsdiv.c:282: result |= mask;
;	genAssign 
	mov	dptr,#___fsdiv_result_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
;	genOr 
	mov	dptr,#___fsdiv_mask_1_1
	movx	a,@dptr
	orl	ar3,a
	inc	dptr
	movx	a,@dptr
	orl	ar4,a
	inc	dptr
	movx	a,@dptr
	orl	ar5,a
	inc	dptr
	movx	a,@dptr
	orl	ar6,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_result_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:283: mant1 -= mant2;
;	genMinus 
	mov	dptr,#___fsdiv_mant2_1_1
	mov	dps, #1
	mov	dptr, #___fsdiv_mant1_1_1
	dec	dps
	clr	c
	movx	a,@dptr
	mov	b,a
	inc	dps
	movx	a,@dptr
	subb	a,b
	mov	r3,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r4,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r5,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r6,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_mant1_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	genLabel 
00108$:
;	_fsdiv.c:285: mant1 <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	dptr,#___fsdiv_mant1_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r3,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r5,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r6,a
	sjmp	00131$
00130$:
	mov	a,r3
	add	a,acc
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
	mov	a,r6
	rlc	a
	mov	r6,a
00131$:
	djnz	b,00130$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_mant1_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:286: mask >>= 1;
;	genRightShift 
;	genRightShiftLiteral (1), size 4
	mov	dptr,#___fsdiv_mask_1_1
;	genrshFour
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	mov	r6,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r5,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r4,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 100   removed redundant mov
	mov  r3,a
	mov  dptr,#___fsdiv_mask_1_1
	movx @dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	genGoto 
	ljmp	00109$
;	genLabel 
00111$:
;	_fsdiv.c:290: result += 1;
;	genPlus 
	mov	dptr,#___fsdiv_result_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	_fsdiv.c:293: exp++;
;	genPlus 
	mov	dptr,#___fsdiv_exp_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	_fsdiv.c:294: result >>= 1;
;	genRightShift 
;	genSignedRightShift 
;	genRightShiftLiteral (1), size 4
	mov	dptr,#___fsdiv_result_1_1
;	genrshFour
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	c,acc.7
	rrc	a
	mov	r6,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r5,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r4,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 100   removed redundant mov
	mov  r3,a
	mov  dptr,#___fsdiv_result_1_1
	movx @dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
;	_fsdiv.c:296: result &= ~HIDDEN;
;	genAnd 
	mov	dptr,#___fsdiv_result_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	better literal AND.
	inc	dptr
	movx	a,@dptr
	anl	a, #0x7F
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_fsdiv.c:299: fl1.l = PACK (sign ? 1ul<<31 : 0, (unsigned long) exp, result);
;	genIfx 
	mov	a,r2
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00114$
00132$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0x80
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00115$
00114$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0x00
;	genLabel 
00115$:
;	genCast 
	mov	dptr,#___fsdiv_exp_1_1
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genLeftShift 
;	genLeftShiftLiteral (23), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x18
	sjmp	00134$
00133$:
	mov	a,r6
	add	a,acc
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
00134$:
	djnz	b,00133$
;	genOr 
	mov	a,r6
	orl	ar2,a
	mov	a,r7
	orl	ar3,a
	mov	a,r0
	orl	ar4,a
	mov	a,r1
	orl	ar5,a
;	genAssign 
	mov	dptr,#___fsdiv_result_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genOr 
	mov	a,r6
	orl	ar2,a
	mov	a,r7
	orl	ar3,a
	mov	a,r0
	orl	ar4,a
	mov	a,r1
	orl	ar5,a
;	genPointerSet 
	mov	dptr,#___fsdiv_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsdiv.c:300: return (fl1.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsdiv_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00112$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
