;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:53:59 2005
;--------------------------------------------------------
	.module _strstr
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strstr
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_strstr.c:26: char * strstr (
;	genLabel
;	genFunction
;	---------------------------------
; Function strstr
; ---------------------------------
_strstr_start::
_strstr:
	lda	sp,-10(sp)
;_strstr.c:31: char * cp = str1;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strstr_cp_1_1
	lda	hl,12(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),e
;_strstr.c:35: if ( !*str2 )
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strstr_s2_1_1
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genPointerGet
;	AOP_STK for _strstr_s2_1_1
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIfx
	or	a,a
	jp	nz,00122$
;_strstr.c:36: return str1;
;	genRet
;	AOP_STK for _strstr_cp_1_1
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk -2
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jp	00113$
;_strstr.c:38: while (*cp)
;	genLabel
00122$:
;	genAssign
;	AOP_STK for _strstr_cp_1_1
;	AOP_STK for _strstr_s1_1_1
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,6(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00110$:
;	genPointerGet
;	AOP_STK for _strstr_s1_1_1
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIfx
	or	a,a
	jp	z,00112$
;_strstr.c:41: s2 = str2;
;	genAssign
;	AOP_STK for _strstr_s2_1_1
	lda	hl,4(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;_strstr.c:43: while ( *s1 && *s2 && !(*s1-*s2) )
;	genAssign
;	AOP_STK for _strstr_s1_1_1
;	AOP_STK for _strstr__1_0
	inc	hl
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,2(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	(registers are the same)
;	genLabel
00105$:
;	genPointerGet
;	AOP_STK for _strstr__1_0
;	AOP_STK for _strstr__1_0
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	dec	hl
	dec	hl
	ld	(hl),a
;	genIfx
;	AOP_STK for _strstr__1_0
	xor	a,a
	or	a,(hl)
	jp	z,00107$
;	genPointerGet
;	AOP_STK for _strstr__1_0
	ld	a,(bc)
	dec	hl
	ld	(hl),a
;	genIfx
;	AOP_STK for _strstr__1_0
	xor	a,a
	or	a,(hl)
	jp	z,00107$
;	genMinus
;	AOP_STK for _strstr__1_0
;	AOP_STK for _strstr__1_0
	inc	hl
	ld	a,(hl)
	dec	hl
	sub	a,(hl)
;	genIfx
	or	a,a
	jp	nz,00107$
;_strstr.c:44: s1++, s2++;
;	genPlus
;	AOP_STK for _strstr__1_0
;	genPlusIncr
	inc	hl
	inc	hl
	inc	(hl)
	jr	nz,00123$
	inc	hl
	inc	(hl)
00123$:
;	genPlus
;	genPlusIncr
	inc	bc
;	genGoto
	jp	00105$
;	genLabel
00107$:
;_strstr.c:46: if (!*s2)
;	genPointerGet
	ld	a,(bc)
;	genIfx
	or	a,a
	jp	nz,00109$
;_strstr.c:47: return(cp);
;	genRet
;	AOP_STK for _strstr_cp_1_1
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk -2
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jp	00113$
;	genLabel
00109$:
;_strstr.c:49: cp++;
;	genPlus
;	AOP_STK for _strstr_s1_1_1
;	genPlusIncr
	lda	hl,6(sp)
	inc	(hl)
	jr	nz,00124$
	inc	hl
	inc	(hl)
00124$:
;	genAssign
;	AOP_STK for _strstr_s1_1_1
;	AOP_STK for _strstr_cp_1_1
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	e,(hl)
	inc	hl
	ld	(hl+),a
	ld	(hl),e
;	genGoto
	jp	00110$
;	genLabel
00112$:
;_strstr.c:52: return (NULL) ;
;	genRet
; Dump of IC_LEFT: type AOP_LIT size 2
	ld	de,#0x0000
;	genLabel
00113$:
;	genEndFunction
	lda	sp,10(sp)
	ret
_strstr_end::
	.area _CODE
