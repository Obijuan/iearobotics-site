;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:05 2005
;--------------------------------------------------------
	.module _mullong
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __mullong
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_mullong.c:709: _mullong (long a, long b)
;	genLabel
;	genFunction
;	---------------------------------
; Function _mullong
; ---------------------------------
__mullong_start::
__mullong:
	lda	sp,-29(sp)
;_mullong.c:713: t.i.hi = bcast(a)->b.b0 * bcast(b)->b.b2;       // A
;	genAddrOf
;	AOP_STK for __mullong__1_0
	lda	hl,25(sp)
	ld	a,l
	ld	d,h
	lda	hl,23(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,21(sp)
	ld	(hl+),a
	ld	(hl),d
;	genAddrOf
;	AOP_STK for __mullong__1_0
	lda	hl,31(sp)
	ld	a,l
	ld	d,h
	lda	hl,19(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	dec	hl
	dec	hl
	ld	(hl),a
;	genAddrOf
;	AOP_STK for __mullong__1_0
	lda	hl,35(sp)
	ld	a,l
	ld	d,h
	lda	hl,16(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,14(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __mullong__1_0
	lda	hl,19(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,21(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;_mullong.c:714: t.i.lo = bcast(a)->b.b0 * bcast(b)->b.b0;       // A
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	lda	hl,16(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,13(sp)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __mullong__1_0
	ld      (hl),a
; Removed redundent load
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __mullong__1_0
	lda	hl,19(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	c,d
	ld	b,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,23(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,b
	ld	(de),a
	inc	de
	ld	a,c
	ld	(de),a
;_mullong.c:715: t.b.b3 += bcast(a)->b.b3 *
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0003
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,11(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	b,a
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,19(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0003
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,9(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	c,a
;_mullong.c:716: bcast(b)->b.b0;       // G
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for __mullong__1_0
	lda	hl,15(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	c,e
	lda	sp,2(sp)
	pop	af
;	genPlus
;	Can't optimise plus by inc, falling back to the normal way
	ld	b,a
	add	a,c
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,11(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;_mullong.c:717: t.b.b3 += bcast(a)->b.b2 *
;	genPointerGet
;	AOP_STK for __mullong__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	b,a
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,19(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,7(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	dec	hl
	dec	hl
	ld	(hl),a
;_mullong.c:718: bcast(b)->b.b1;       // F
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,16(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
	ld	a,c
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __mullong__1_0
	inc	hl
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	c,e
	lda	sp,2(sp)
	pop	af
;	genPlus
;	Can't optimise plus by inc, falling back to the normal way
	ld	b,a
	add	a,c
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,11(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;_mullong.c:719: t.i.hi += bcast(a)->b.b2 * bcast(b)->b.b0;      // E <- b lost in .lst
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	lda	hl,21(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,11(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genPointerGet
;	AOP_STK for __mullong__1_0
	lda	hl,7(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __mullong__1_0
	lda	hl,13(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genPlus
;	AOP_STK for __mullong__1_0
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,11(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	add	hl,bc
	ld	c,l
	ld	b,h
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,21(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;_mullong.c:721: t.i.hi += bcast(a)->b.b1 * bcast(b)->b.b1;      // D <- b lost in .lst
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,7(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,19(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,11(sp)
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	c,a
;	genPointerGet
;	AOP_STK for __mullong__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	b,a
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genPlus
;	AOP_STK for __mullong__1_0
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,7(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	add	hl,bc
	ld	c,l
	ld	b,h
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,21(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;_mullong.c:723: bcast(a)->bi.b3 = bcast(a)->b.b1 *
;	genPointerGet
;	AOP_STK for __mullong__1_0
	lda	hl,11(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;_mullong.c:724: bcast(b)->b.b2;
;	genPointerGet
;	AOP_STK for __mullong__1_0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	b,a
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	c,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,9(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
;_mullong.c:725: bcast(a)->bi.i12 = bcast(a)->b.b1 *
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,19(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for __mullong__1_0
;	genPlusIncr
	lda	hl,19(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;_mullong.c:726: bcast(b)->b.b0;              // C
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __mullong__1_0
	lda	hl,13(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;_mullong.c:728: bcast(b)->bi.b3 = bcast(a)->b.b0 *
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,16(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0003
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
;_mullong.c:729: bcast(b)->b.b3;
;	genPointerGet
;	AOP_STK for __mullong__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __mullong__1_0
	lda	hl,19(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	c,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
;_mullong.c:730: bcast(b)->bi.i12 = bcast(a)->b.b0 *
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,16(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),d
;_mullong.c:731: bcast(b)->b.b1;              // B
;	genPlus
;	AOP_STK for __mullong__1_0
;	genPlusIncr
	lda	hl,16(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genPointerGet
	ld	a,(bc)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	c,a
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __mullong__1_0
	inc	hl
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	__muluchar_rrx_s
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;_mullong.c:732: bcast(b)->bi.b0 = 0;                            // B
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,16(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,#0x00
	ld	(de),a
;_mullong.c:733: bcast(a)->bi.b0 = 0;                            // C
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,#0x00
	ld	(de),a
;_mullong.c:734: t.l += a;
;	genPointerGet
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
	lda	hl,23(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,0(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genAssign
;	(operands are equal 3)
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for 
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	lda	hl,31(sp)
	add	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	adc	a,(hl)
	push	af
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,35(sp)
	pop	af
	ld	a,e
	adc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	adc	a,(hl)
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
;	genAssign (pointer)
;	AOP_STK for __mullong__1_0
;	AOP_STK for __mullong__1_0
;	isBitvar = 0
	lda	hl,23(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,0(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;_mullong.c:736: return t.l + b;
;	genAssign
;	(operands are equal 3)
;	genPlus
;	AOP_STK for __mullong__1_0
;	AOP_STK for 
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	lda	hl,35(sp)
	add	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	adc	a,(hl)
	push	af
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,39(sp)
	pop	af
	ld	a,e
	adc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	adc	a,(hl)
	lda	hl,3(sp)
	ld      (hl-),a
	ld	(hl),e
;	genRet
;	AOP_STK for __mullong__1_0
; Dump of IC_LEFT: type AOP_STK size 4
;	 aop_stk -29
	dec	hl
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	inc	hl
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
;	genLabel
00101$:
;	genEndFunction
	lda	sp,29(sp)
	ret
__mullong_end::
	.area _CODE
