;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:48:23 2005
;--------------------------------------------------------
	.module free
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __sdcc_find_memheader
	.globl __sdcc_prev_memheader
	.globl _free
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__sdcc_prev_memheader::
	.ds 3
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_sdcc_find_memheader'
;------------------------------------------------------------
;p                         Allocated to registers r2 r3 r4 
;pthis                     Allocated to registers r2 r3 r4 
;cur_header                Allocated to registers r5 r6 r7 
;------------------------------------------------------------
;	free.c:112: MEMHEADER xdata * _sdcc_find_memheader(void xdata * p)
;	genFunction 
;	-----------------------------------------
;	 function _sdcc_find_memheader
;	-----------------------------------------
__sdcc_find_memheader:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
;	free.c:117: if (!p)
;	genIfx 
	mov	a,dpl
	orl	a,dph
	orl	a,dpx
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00113$:
;	free.c:118: return NULL;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	ljmp	00107$
;	genLabel 
00102$:
;	free.c:120: pthis -= 1; //to start of header
;	genMinus 
	mov	a,dpl
	add	a,#0xFB
	mov	r2,a
	mov	a,dph
	addc	a,#0xFF
	mov	r3,a
	mov	a,dpx
	addc	a,#0xFF
	mov	r4,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	free.c:121: cur_header = _sdcc_first_memheader;
;	genAssign 
	mov	dptr,#__sdcc_first_memheader
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dpl1,r5
	mov	dph1,r6
	mov	dpx1,r7
;	free.c:122: _sdcc_prev_memheader = NULL;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__sdcc_prev_memheader
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	free.c:123: while (cur_header && pthis != cur_header)
;	genLabel 
00104$:
;	genIfx 
	mov	a,dpl1
	orl	a,dph1
	orl	a,dpx1
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00114$:
;	genCmpEq 
;	gencjneshort
	mov	b,r2
	mov	a,dpl1
	cjne	a,b,00115$
	mov	b,r3
	mov	a,dph1
	cjne	a,b,00115$
	mov	b,r4
	mov	a,dpx1
	cjne	a,b,00115$
; Peephole 132   changed ljmp to sjmp
	sjmp 00106$
00115$:
;	free.c:125: _sdcc_prev_memheader = cur_header;
;	genIpush 
	push	ar2
	push	ar3
	push	ar4
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__sdcc_prev_memheader
	mov	a,dpl1
	movx	@dptr,a
	inc	dptr
	mov	a,dph1
	movx	@dptr,a
	inc	dptr
	mov	a,dpx1
	movx	@dptr,a
;	free.c:126: cur_header = cur_header->next;
;	genPointerGet 
;	genFarPointerGet
	inc	dps
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	inc	dptr
	mov	r1,a
	movx	a,@dptr
	mov	r2,a
; Peephole 220a removed bogus DPS set
	mov     dps, #1
	lcall	__decdptr
	lcall	__decdptr
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dpl1,r0
	mov	dph1,r1
	mov	dpx1,r2
;	genIpop 
	pop	ar4
	pop	ar3
	pop	ar2
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00104$
00106$:
;	free.c:128: return (cur_header);
;	genRet 
	mov	dpl,dpl1
	mov	dph,dph1
	mov	dpx,dpx1
;	genLabel 
00107$:
;	genEndFunction 
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'free'
;------------------------------------------------------------
;p                         Allocated to registers 
;pthis                     Allocated to registers r2 r3 r4 
;------------------------------------------------------------
;	free.c:131: void free (void * p)
;	genFunction 
;	-----------------------------------------
;	 function free
;	-----------------------------------------
_free:
;	genReceive 
;	free.c:137: pthis = _sdcc_find_memheader(p);
;	genCast 
	mov     r2,dpl
	mov     r3,dph
	mov     r4,dpx
	mov     r5,b
;       Peephole 238.b  removed 3 redundant moves
;	genCall 
;	genSend argreg = 1, size = 3 
	lcall	__sdcc_find_memheader
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl1,r2
	mov	dph1,r3
	mov	dpx1,r4
;	free.c:138: if (pthis) //For allocated pointers only!
;	genIfx 
	mov	a,dpl1
	orl	a,dph1
	orl	a,dpx1
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00106$
00110$:
;	free.c:140: if (!_sdcc_prev_memheader)
;	genAssign 
	mov	dptr,#__sdcc_prev_memheader
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	genIfx 
	mov	a,r5
	orl	a,r6
	orl	a,r7
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00111$:
;	free.c:142: pthis->len = 0;
;	genPlus 
	mov	dpx,dpx1
	mov	dph,dph1
	mov	dpl,dpl1
	inc	dptr
	inc	dptr
	inc	dptr
;	did genPlusIncr
;	genPointerSet 
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00106$
00102$:
;	free.c:146: _sdcc_prev_memheader->next = pthis->next;
;	genPointerGet 
;	genFarPointerGet
	inc	dps
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	mov	r4,a
	mov	dps,#0
;	genPointerSet 
	mov	dpl,r5
	mov	dph,r6
	mov	dpx,r7
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	genLabel 
00106$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
