;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:50:46 2005
;--------------------------------------------------------
	.module _ispunct
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ispunct
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'ispunct'
;------------------------------------------------------------
;c                         Allocated to registers r2 
;------------------------------------------------------------
;	_ispunct.c:25: char ispunct (unsigned char c) 
;	genFunction 
;	-----------------------------------------
;	 function ispunct
;	-----------------------------------------
_ispunct:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
;	_ispunct.c:28: if (isprint (c)    && 
;	genCall 
	push	ar2
;	genSend argreg = 1, size = 1 
	mov	dpl,r2
	lcall	_isprint
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00114$:
;	_ispunct.c:29: !islower(c)     && 
;	genCall 
	push	ar2
;	genSend argreg = 1, size = 1 
	mov	dpl,r2
	lcall	_islower
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00115$:
;	_ispunct.c:30: !isupper(c)     &&
;	genCall 
	push	ar2
;	genSend argreg = 1, size = 1 
	mov	dpl,r2
	lcall	_isupper
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00116$:
;	_ispunct.c:31: c != ' '        &&
;	genCmpEq 
;	gencjneshort
	mov	a,r2
	cjne	a,#0x20,00117$
; Peephole 132   changed ljmp to sjmp
	sjmp 00102$
00117$:
;	_ispunct.c:32: !isdigit(c)) 
;	genCall 
;	genSend argreg = 1, size = 1 
	mov	dpl,r2
	lcall	_isdigit
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00118$:
;	_ispunct.c:33: return 1;
;	genRet 
	mov	dpl,#0x01
;	genLabel 
; Peephole 132   changed ljmp to sjmp
;	_ispunct.c:34: return 0;
;	genRet 
;	genLabel 
;	genEndFunction 
; Peephole 237a  removed sjmp to ret
	ret
00102$:
	mov     dpl,#0x00
00107$:
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
