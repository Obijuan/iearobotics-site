;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:19 2005
;--------------------------------------------------------
	.module printf_large
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __print_format
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;printf_large.c:78: static void output_digit( unsigned char n, BOOL lower_case, pfn_outputchar output_char, void* p )
;	genLabel
;	genFunction
;	---------------------------------
; Function output_digit
; ---------------------------------
_output_digit:
	
;printf_large.c:83: output_char( n <= 9 ? '0'+n :
;	genCmpGt
;	AOP_STK for 
	ld	a,#0x09
	lda	hl,2(sp)
	sub	a,(hl)
	ld	a,#0x00
	rla
	ld	c,a
;	genNot
	xor	a,a
	or	a,c
	sub	a,#0x01
	ld	a,#0x00
	rla
	ld	c,a
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00103$
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,(hl)
	add	a,#0x30
	ld	c,a
;	genGoto
	jp	00104$
;	genLabel
00103$:
;printf_large.c:84: (lower_case ? n+(char)('a'-10) : n+(char)('A'-10)), p );
;	genIfx
;	AOP_STK for 
	xor	a,a
	lda	hl,3(sp)
	or	a,(hl)
	jp	z,00105$
;	genAssign
;	AOP_STK for 
	dec	hl
	ld	b,(hl)
;	genPlus
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,b
	add	a,#0x57
	ld	b,a
;	genGoto
	jp	00106$
;	genLabel
00105$:
;	genAssign
;	AOP_STK for 
	lda	hl,2(sp)
	ld	c,(hl)
;	genPlus
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,c
	add	a,#0x37
	ld	b,a
;	genLabel
00106$:
;	genAssign
	ld	c,b
;	genLabel
00104$:
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00109$
	push	hl
	lda	hl,9(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00109$:
	lda	sp,3(sp)
;	genLabel
00101$:
;	genEndFunction
	
	ret
_memory_id:
	.ascii "IXCP-"
	.db 0x00
;printf_large.c:91: static void output_2digits( unsigned char b, BOOL lower_case, pfn_outputchar output_char, void* p )
;	genLabel
;	genFunction
;	---------------------------------
; Function output_2digits
; ---------------------------------
_output_2digits:
	
;printf_large.c:93: output_digit( b>>4,   lower_case, output_char, p );
;	genRightShift
;	AOP_STK for 
	lda	hl,2(sp)
	ld	c,(hl)
	srl	c
	srl	c
	srl	c
	srl	c
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,7(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_output_digit
	lda	sp,6(sp)
;printf_large.c:94: output_digit( b&0x0F, lower_case, output_char, p );
;	genAnd
;	AOP_STK for 
	lda	hl,2(sp)
	ld	a,(hl)
	and	a,#0x0F
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,7(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_output_digit
	lda	sp,6(sp)
;	genLabel
00101$:
;	genEndFunction
	
	ret
;printf_large.c:108: static void calculate_digit( value_t* value, unsigned char radix )
;	genLabel
;	genFunction
;	---------------------------------
; Function calculate_digit
; ---------------------------------
_calculate_digit:
	lda	sp,-9(sp)
;printf_large.c:112: for( i = 32; i != 0; i-- )
;	genAssign
;	AOP_STK for _calculate_digit_i_1_1
	lda	hl,8(sp)
	ld	(hl),#0x20
;	genLabel
00103$:
;	genCmpEq
;	AOP_STK for _calculate_digit_i_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,8(sp)
	ld	a,(hl)
	or	a,a
	jp	z,00107$
00112$:
;printf_large.c:114: value->byte[4] = (value->byte[4] << 1) | ((value->ul >> 31) & 0x01);
;	genAssign
;	AOP_STK for 
;	AOP_STK for _calculate_digit__1_0
	lda	hl,11(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genPlus
;	AOP_STK for _calculate_digit__1_0
;	AOP_STK for _calculate_digit__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,6(sp)
;	genPointerGet
;	AOP_STK for _calculate_digit__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
;	genLeftShift
	ld	c,a
	add	a,a
	ld	b,a
;	genPointerGet
;	AOP_STK for _calculate_digit__1_0
;	AOP_STK for _calculate_digit__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,0(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genGetHBIT
;	AOP_STK for _calculate_digit__1_0
	ld      (hl),a
; Removed redundent load
	rlc	a
	and	a,#0x01
	ld	c,a
;	genOr
	ld	a,b
	or	a,c
;	genAssign (pointer)
;	AOP_STK for _calculate_digit__1_0
;	isBitvar = 0
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;printf_large.c:115: value->ul <<= 1;
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	ld	a,#0x01
	push	af
	inc	sp
;	genIpush
;	AOP_STK for _calculate_digit__1_0
	lda	hl,3(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
	lda	hl,3(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	__rlulong_rrx_s
;	AOP_STK for _calculate_digit__1_0
	push	hl
	lda	hl,7(sp)
	ld	(hl),e
	inc	hl
	ld	(hl),d
	pop	de
	inc	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
	lda	sp,5(sp)
;	genAssign (pointer)
;	AOP_STK for _calculate_digit__1_0
;	AOP_STK for _calculate_digit__1_0
;	isBitvar = 0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,0(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;printf_large.c:117: if (radix <= value->byte[4] )
;	genPointerGet
;	AOP_STK for _calculate_digit__1_0
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCmpGt
;	AOP_STK for 
	ld	c,a
	lda	hl,13(sp)
	sub	a,(hl)
	jp	c,00105$
;printf_large.c:119: value->byte[4] -= radix;
;	genPointerGet
;	AOP_STK for _calculate_digit__1_0
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genMinus
;	AOP_STK for 
	ld	c,a
	lda	hl,13(sp)
	sub	a,(hl)
;	genAssign (pointer)
;	AOP_STK for _calculate_digit__1_0
;	isBitvar = 0
	lda	hl,6(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;printf_large.c:120: value->ul |= 1;
;	genPointerGet
;	AOP_STK for _calculate_digit__1_0
;	AOP_STK for _calculate_digit__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,0(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genOr
;	AOP_STK for _calculate_digit__1_0
	lda	hl,0(sp)
	ld	a,(hl)
	or	a,#0x01
	ld	(hl),a
;	genAssign (pointer)
;	AOP_STK for _calculate_digit__1_0
;	AOP_STK for _calculate_digit__1_0
;	isBitvar = 0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,0(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;	genLabel
00105$:
;printf_large.c:112: for( i = 32; i != 0; i-- )
;	genMinus
;	AOP_STK for _calculate_digit_i_1_1
	lda	hl,8(sp)
	dec	(hl)
;	genGoto
	jp	00103$
;	genLabel
00107$:
;	genEndFunction
	lda	sp,9(sp)
	ret
;printf_large.c:339: int _print_format (pfn_outputchar pfn, void* pvoid, const char *format, va_list ap)
;	genLabel
;	genFunction
;	---------------------------------
; Function _print_format
; ---------------------------------
__print_format_start::
__print_format:
	lda	sp,-62(sp)
;printf_large.c:371: charsOutputted=0;
;	genAssign
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;printf_large.c:379: while( c=*format++ )
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,30(sp)
	ld	(hl+),a
	ld	(hl),d
;	genAddrOf
	lda	hl,34(sp)
	ld	c,l
	ld	b,h
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	ld	hl,#0x0005
	add	hl,bc
	ld	a,l
	ld	d,h
	lda	hl,16(sp)
	ld	(hl+),a
	ld	(hl),d
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,30(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,26(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,30(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,24(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,30(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,22(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,30(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,20(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,30(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,18(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00224$:
;	genAssign
;	AOP_STK for 
;	AOP_STK for __print_format__1_0
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),e
;	genPointerGet
;	AOP_STK for __print_format__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0001
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,68(sp)
	ld	(hl+),a
	ld	(hl),d
;	genAssign
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	(hl),c
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00226$
;printf_large.c:381: if ( c=='%' )
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	ld	a,(hl)
	cp	a,#0x25
	jp	nz,00222$
	jr	00303$
00302$:
	jp	00222$
00303$:
;printf_large.c:383: left_justify    = 0;
;	genAssign
;	AOP_STK for __print_format_left_justify_1_1
	lda	hl,61(sp)
	ld	(hl),#0x00
;printf_large.c:384: zero_padding    = 0;
;	genAssign
;	AOP_STK for __print_format_zero_padding_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:385: prefix_sign     = 0;
;	genAssign
;	AOP_STK for __print_format_prefix_sign_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:386: prefix_space    = 0;
;	genAssign
;	AOP_STK for __print_format_prefix_space_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:387: signed_argument = 0;
;	genAssign
;	AOP_STK for __print_format_signed_argument_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:388: radix           = 0;
;	genAssign
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	(hl),#0x00
;printf_large.c:389: char_argument   = 0;
;	genAssign
;	AOP_STK for __print_format_char_argument_1_1
	lda	hl,56(sp)
	ld	(hl),#0x00
;printf_large.c:390: long_argument   = 0;
;	genAssign
;	AOP_STK for __print_format_long_argument_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:391: float_argument  = 0;
;	genAssign
;	AOP_STK for __print_format_float_argument_1_1
	dec	hl
	ld	(hl),#0x00
;printf_large.c:392: width           = 0;
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),#0x00
;printf_large.c:393: decimals        = -1;
;	genAssign
;	AOP_STK for __print_format_decimals_1_1
	dec	hl
	ld	(hl),#0xFF
;printf_large.c:395: get_conversion_spec:
;	genAssign
;	AOP_STK for 
;	AOP_STK for __print_format__1_0
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00101$:
;printf_large.c:397: c = *format++;
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,14(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	dec	hl
	inc	(hl)
	jr	nz,00304$
	inc	hl
	inc	(hl)
00304$:
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for 
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,68(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	(hl),c
;printf_large.c:399: if (c=='%') {
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	ld	a,(hl)
	cp	a,#0x25
	jp	nz,00103$
	jr	00306$
00305$:
	jp	00103$
00306$:
;printf_large.c:400: output_char(c, p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_c_1_1
	lda	hl,42(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00307$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00307$:
	lda	sp,3(sp)
;printf_large.c:401: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00308$
	inc	hl
	inc	(hl)
00308$:
;printf_large.c:402: continue;
;	genGoto
	jp	00224$
;	genLabel
00103$:
;printf_large.c:405: if (isdigit(c)) {
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	_isdigit
	ld	c,e
	lda	sp,1(sp)
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00110$
;printf_large.c:406: if (decimals==-1) {
;	genCmpEq
;	AOP_STK for __print_format_decimals_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,42(sp)
	ld	a,(hl)
	cp	a,#0xFF
	jp	nz,00107$
	jr	00310$
00309$:
	jp	00107$
00310$:
;printf_large.c:407: width = 10*width + (c - '0');
;	genMult
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	e,(hl)
	ld	d,#0x00
	ld	l,e
	add	hl,hl
	add	hl,hl
	add	hl,de
	add	hl,hl
	ld	c,l
;	genMinus
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	a,(hl)
	add	a,#0xD0
	ld	b,a
;	genPlus
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,c
	add	a,b
	ld	c,a
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),c
;printf_large.c:408: if (width == 0) {
;	genCmpEq
;	AOP_STK for __print_format_width_1_1
; genCmpEq: left 1, right 1, result 0
	ld	a,(hl)
	or	a,a
	jp	nz,00101$
	jr	00312$
00311$:
	jp	00101$
00312$:
;printf_large.c:410: zero_padding = 1;
;	genAssign
;	AOP_STK for __print_format_zero_padding_1_1
	lda	hl,60(sp)
	ld	(hl),#0x01
;	genGoto
	jp	00101$
;	genLabel
00107$:
;printf_large.c:413: decimals = 10*decimals + (c-'0');
;	genMult
;	AOP_STK for __print_format_decimals_1_1
	lda	hl,42(sp)
	ld	e,(hl)
	ld	l,e
	add	hl,hl
	add	hl,hl
	add	hl,de
	add	hl,hl
	ld	c,l
;	genMinus
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	a,(hl)
	add	a,#0xD0
	ld	b,a
;	genPlus
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,c
	add	a,b
	ld	c,a
;	genAssign
;	AOP_STK for __print_format_decimals_1_1
	inc	hl
	inc	hl
	ld	(hl),c
;printf_large.c:415: goto get_conversion_spec;
;	genGoto
	jp	00101$
;	genLabel
00110$:
;printf_large.c:418: if (c=='.') {
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x2E
	jp	nz,00114$
	jr	00314$
00313$:
	jp	00114$
00314$:
;printf_large.c:419: if (decimals=-1) decimals=0;
;	genAssign
;	AOP_STK for __print_format_decimals_1_1
	lda	hl,42(sp)
	ld	(hl),#0x00
;printf_large.c:422: goto get_conversion_spec;
;	genGoto
	jp	00101$
;	genLabel
00114$:
;printf_large.c:425: lower_case = islower(c);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genCall
	call	_islower
	ld	c,e
	lda	sp,1(sp)
;	genAssign
;	AOP_STK for __print_format_lower_case_1_1
	lda	hl,53(sp)
	ld	(hl),c
;printf_large.c:426: if (lower_case)
;	genIfx
;	AOP_STK for __print_format_lower_case_1_1
	xor	a,a
	or	a,(hl)
	jp	z,00116$
;printf_large.c:428: c = toupper(c);
;	genAnd
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	a,(hl)
	and	a,#0xDF
	ld	(hl),a
;	genLabel
00116$:
;printf_large.c:431: switch( c )
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x20
	jp	z,00119$
00315$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x2B
	jp	z,00118$
00316$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x2D
	jp	z,00117$
00317$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x42
	jp	z,00120$
00318$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x43
	jp	z,00122$
00319$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x44
	jp	z,00147$
00320$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x46
	jp	z,00151$
00321$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x49
	jp	z,00147$
00322$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x4C
	jp	z,00121$
00323$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x4F
	jp	z,00148$
00324$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x50
	jp	z,00142$
00325$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x53
	jp	z,00123$
00326$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x55
	jp	z,00149$
00327$:
;	genCmpEq
;	AOP_STK for __print_format_c_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,40(sp)
	ld	a,(hl)
	cp	a,#0x58
	jp	z,00150$
00328$:
;	genGoto
	jp	00152$
;printf_large.c:433: case '-':
;	genLabel
00117$:
;printf_large.c:434: left_justify = 1;
;	genAssign
;	AOP_STK for __print_format_left_justify_1_1
	lda	hl,61(sp)
	ld	(hl),#0x01
;printf_large.c:435: goto get_conversion_spec;
;	genGoto
	jp	00101$
;printf_large.c:436: case '+':
;	genLabel
00118$:
;printf_large.c:437: prefix_sign = 1;
;	genAssign
;	AOP_STK for __print_format_prefix_sign_1_1
	lda	hl,59(sp)
	ld	(hl),#0x01
;printf_large.c:438: goto get_conversion_spec;
;	genGoto
	jp	00101$
;printf_large.c:439: case ' ':
;	genLabel
00119$:
;printf_large.c:440: prefix_space = 1;
;	genAssign
;	AOP_STK for __print_format_prefix_space_1_1
	lda	hl,58(sp)
	ld	(hl),#0x01
;printf_large.c:441: goto get_conversion_spec;
;	genGoto
	jp	00101$
;printf_large.c:442: case 'B':
;	genLabel
00120$:
;printf_large.c:443: char_argument = 1;
;	genAssign
;	AOP_STK for __print_format_char_argument_1_1
	lda	hl,56(sp)
	ld	(hl),#0x01
;printf_large.c:444: goto get_conversion_spec;
;	genGoto
	jp	00101$
;printf_large.c:445: case 'L':
;	genLabel
00121$:
;printf_large.c:446: long_argument = 1;
;	genAssign
;	AOP_STK for __print_format_long_argument_1_1
	lda	hl,55(sp)
	ld	(hl),#0x01
;printf_large.c:447: goto get_conversion_spec;
;	genGoto
	jp	00101$
;printf_large.c:449: case 'C':
;	genLabel
00122$:
;printf_large.c:450: output_char( va_arg(ap,int), p );
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,70(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	b,l
	ld	c,h
;	genAssign
;	AOP_STK for 
	lda	hl,70(sp)
	ld	(hl),b
	inc	hl
	ld	(hl),c
;	genMinus
	ld	e,b
	ld	d,c
	dec	de
	dec	de
;	genPointerGet
	ld	b,e
	ld	c,d
	ld	a,(de)
	ld	b,a
	inc	de
	ld	a,(de)
	ld	c,a
;	genCast
; Removed redundent load
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	push	bc
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00329$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00329$:
	lda	sp,3(sp)
;printf_large.c:451: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00330$
	inc	hl
	inc	(hl)
00330$:
;printf_large.c:452: break;
;	genGoto
	jp	00153$
;printf_large.c:454: case 'S':
;	genLabel
00123$:
;printf_large.c:455: PTR = va_arg(ap,ptr_t);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
	lda	hl,70(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
	inc	bc
;	genAssign
;	AOP_STK for 
	dec	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	dec	bc
	dec	bc
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,14(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;printf_large.c:465: length = strlen(PTR);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
	push	bc
;	genCall
	call	_strlen
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genCast
;	AOP_STK for __print_format__1_0
	lda	hl,13(sp)
	ld	(hl),c
;printf_large.c:467: if ( decimals == -1 )
;	genCmpEq
;	AOP_STK for __print_format_decimals_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,42(sp)
	ld	a,(hl)
	cp	a,#0xFF
	jp	nz,00125$
	jr	00332$
00331$:
	jp	00125$
00332$:
;printf_large.c:469: decimals = length;
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_decimals_1_1
	lda	hl,13(sp)
	ld	a,(hl)
	lda	hl,42(sp)
	ld	(hl),a
;	genLabel
00125$:
;printf_large.c:471: if ( ( !left_justify ) && (length < width) )
;	genIfx
;	AOP_STK for __print_format_left_justify_1_1
	xor	a,a
	lda	hl,61(sp)
	or	a,(hl)
	jp	nz,00264$
;	genCmpLt
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_width_1_1
	lda	hl,13(sp)
	ld	a,(hl)
	lda	hl,43(sp)
	sub	a,(hl)
	jp	nc,00264$
;printf_large.c:473: width -= length;
;	genMinus
;	AOP_STK for __print_format_width_1_1
;	AOP_STK for __print_format__1_0
	ld	a,(hl)
	lda	hl,13(sp)
	sub	a,(hl)
	lda	hl,43(sp)
	ld	(hl),a
;printf_large.c:474: while( width-- != 0 )
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	b,(hl)
;	genLabel
00126$:
;	genAssign
	ld	c,b
;	genMinus
	dec	b
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),b
;	genCmpEq
; genCmpEq: left 1, right 1, result 1
;4
	ld	a,c
	or	a,a
	jp	nz,00333$
	ld	a,#0x01
	jr	00334$
00333$:
	xor	a,a
00334$:
;6
	ld	c,a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	nz,00264$
;printf_large.c:476: output_char( ' ', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for 
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x20
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00335$
	push	hl
	lda	hl,71(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00335$:
	lda	sp,3(sp)
	pop	bc
;printf_large.c:477: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,14(sp)
	inc	(hl)
	jr	nz,00336$
	inc	hl
	inc	(hl)
00336$:
;	genGoto
	jp	00126$
;printf_large.c:481: while ( *PTR  && (decimals-- > 0))
;	genLabel
00264$:
;	genAssign
;	AOP_STK for __print_format_decimals_1_1
;	AOP_STK for __print_format__1_0
	lda	hl,42(sp)
	ld	a,(hl)
	lda	hl,10(sp)
	ld	(hl),a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,14(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00133$:
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,11(sp)
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	b,a
	inc	de
	ld	a,(de)
	ld	c,a
;	genPointerGet
	ld	e,b
	ld	d,c
	ld	a,(de)
;	genIfx
	or	a,a
	jp	z,00135$
;	genAssign
;	AOP_STK for __print_format__1_0
	dec	hl
	dec	hl
	ld	c,(hl)
;	genMinus
;	AOP_STK for __print_format__1_0
	dec	(hl)
;	genCmpGt
	ld	a,#0x00
	sub	a,c
	rlca
	jp	nc,00135$
;printf_large.c:483: output_char( *PTR++, p );
;	genPointerGet
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,8(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	ld      (hl-),a
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00337$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00337$:
	lda	sp,3(sp)
;printf_large.c:484: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,14(sp)
	inc	(hl)
	jr	nz,00338$
	inc	hl
	inc	(hl)
00338$:
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genGoto
	jp	00133$
;	genLabel
00135$:
;printf_large.c:487: if ( left_justify && (length < width))
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
;	AOP_STK for __print_format_left_justify_1_1
	xor	a,a
	lda	hl,61(sp)
	or	a,(hl)
	jp	z,00153$
;	genCmpLt
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_width_1_1
	lda	hl,13(sp)
	ld	a,(hl)
	lda	hl,43(sp)
	sub	a,(hl)
	jp	nc,00153$
;printf_large.c:489: width -= length;
;	genMinus
;	AOP_STK for __print_format_width_1_1
;	AOP_STK for __print_format__1_0
	ld	a,(hl)
	lda	hl,13(sp)
	sub	a,(hl)
	lda	hl,43(sp)
	ld	(hl),a
;printf_large.c:490: while( width-- != 0 )
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_charsOutputted_1_1
	lda	hl,14(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,44(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	dec	hl
	dec	hl
	ld	c,(hl)
;	genLabel
00136$:
;	genAssign
	ld	b,c
;	genMinus
	dec	c
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),c
;	genCmpEq
; genCmpEq: left 1, right 1, result 1
;4
	ld	a,b
	or	a,a
	jp	nz,00339$
	ld	a,#0x01
	jr	00340$
00339$:
	xor	a,a
00340$:
;6
	ld	b,a
;	genAssign
;	AOP_STK for __print_format_charsOutputted_1_1
;	AOP_STK for __print_format__1_0
	lda	hl,44(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,b
	jp	nz,00153$
;printf_large.c:492: output_char( ' ', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for 
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x20
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00341$
	push	hl
	lda	hl,71(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00341$:
	lda	sp,3(sp)
	pop	bc
;printf_large.c:493: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format_charsOutputted_1_1
;	genPlusIncr
	lda	hl,44(sp)
	inc	(hl)
	jr	nz,00342$
	inc	hl
	inc	(hl)
00342$:
;	genGoto
	jp	00136$
;printf_large.c:498: case 'P':
;	genLabel
00142$:
;printf_large.c:499: PTR = va_arg(ap,ptr_t);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
	lda	hl,70(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
	inc	bc
;	genAssign
;	AOP_STK for 
	dec	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	dec	bc
	dec	bc
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;printf_large.c:511: output_char( memory_id[(value.byte[2] > 3) ? 4 : value.byte[2]], p );
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,8(sp)
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	ld	c,a
;	genCmpGt
	ld	a,#0x03
	sub	a,c
	jp	nc,00229$
;	genAssign
	ld	c,#0x04
;	genGoto
	jp	00230$
;	genLabel
00229$:
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genLabel
00230$:
;	genPlus
;	Can't optimise plus by inc, falling back to the normal way
	ld	a,#<_memory_id
	add	a,c
	ld	c,a
	ld	a,#>_memory_id
	adc	a,#0x00
	ld	b,a
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00343$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00343$:
	lda	sp,3(sp)
;printf_large.c:512: output_char(':', p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x3A
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00344$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00344$:
	lda	sp,3(sp)
;printf_large.c:513: output_char('0', p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x30
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00345$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00345$:
	lda	sp,3(sp)
;printf_large.c:514: output_char('x', p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x78
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00346$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00346$:
	lda	sp,3(sp)
;printf_large.c:515: if ((value.byte[2] != 0x00 /* DSEG */) &&
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,30(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,8(sp)
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	c,a
	or	a,a
	jp	z,00144$
00347$:
;printf_large.c:516: (value.byte[2] != 0x03 /* SSEG */))
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCmpEq
; genCmpEq: left 1, right 1, result 0
	ld	c,a
	cp	a,#0x03
	jp	z,00144$
00348$:
;printf_large.c:518: OUTPUT_2DIGITS( value.byte[1] );
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,30(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_lower_case_1_1
	lda	hl,57(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_output_2digits
	lda	sp,6(sp)
;printf_large.c:519: charsOutputted += 2;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,28(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0002
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),d
;	genLabel
00144$:
;printf_large.c:521: OUTPUT_2DIGITS( value.byte[0] );
;	genAddrOf
	lda	hl,48(sp)
	ld	c,l
	ld	b,h
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_lower_case_1_1
	lda	hl,57(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_output_2digits
	lda	sp,6(sp)
;printf_large.c:522: charsOutputted += 6;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,28(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0006
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),d
;printf_large.c:524: break;
;	genGoto
	jp	00153$
;printf_large.c:527: case 'I':
;	genLabel
00147$:
;printf_large.c:528: signed_argument = 1;
;	genAssign
;	AOP_STK for __print_format_signed_argument_1_1
	lda	hl,57(sp)
	ld	(hl),#0x01
;printf_large.c:529: radix = 10;
;	genAssign
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	(hl),#0x0A
;printf_large.c:530: break;
;	genGoto
	jp	00153$
;printf_large.c:532: case 'O':
;	genLabel
00148$:
;printf_large.c:533: radix = 8;
;	genAssign
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	(hl),#0x08
;printf_large.c:534: break;
;	genGoto
	jp	00153$
;printf_large.c:536: case 'U':
;	genLabel
00149$:
;printf_large.c:537: radix = 10;
;	genAssign
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	(hl),#0x0A
;printf_large.c:538: break;
;	genGoto
	jp	00153$
;printf_large.c:540: case 'X':
;	genLabel
00150$:
;printf_large.c:541: radix = 16;
;	genAssign
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	(hl),#0x10
;printf_large.c:542: break;
;	genGoto
	jp	00153$
;printf_large.c:544: case 'F':
;	genLabel
00151$:
;printf_large.c:545: float_argument=1;
;	genAssign
;	AOP_STK for __print_format_float_argument_1_1
	lda	hl,54(sp)
	ld	(hl),#0x01
;printf_large.c:546: break;
;	genGoto
	jp	00153$
;printf_large.c:548: default:
;	genLabel
00152$:
;printf_large.c:550: output_char( c, p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_c_1_1
	lda	hl,42(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00349$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00349$:
	lda	sp,3(sp)
;printf_large.c:551: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00350$
	inc	hl
	inc	(hl)
00350$:
;printf_large.c:553: }
;	genLabel
00153$:
;printf_large.c:555: if (float_argument) {
;	genIfx
;	AOP_STK for __print_format_float_argument_1_1
	xor	a,a
	lda	hl,54(sp)
	or	a,(hl)
	jp	z,00219$
;printf_large.c:556: value.f=va_arg(ap,float);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,70(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genAssign
;	AOP_STK for 
	lda	hl,70(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	ld	a,c
	add	a,#0xFC
	ld	c,a
	ld	a,b
	adc	a,#0xFF
	ld	b,a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	e,c
	ld	d,b
	ld	a,(de)
	lda	hl,4(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	ld	(hl+),a
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,4(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;printf_large.c:558: PTR="<NO FLOAT>";
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,#<__str_1
	ld	(de),a
	inc	de
	ld	a,#>__str_1
	ld	(de),a
;printf_large.c:559: while (c=*PTR++)
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genLabel
00154$:
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,8(sp)
;	genPointerGet
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
	inc	hl
	inc	hl
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	ld      (hl-),a
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
	inc	de
	ld	a,b
	ld	(de),a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genAssign
;	AOP_STK for __print_format_c_1_1
	lda	hl,40(sp)
	ld	(hl),c
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00224$
;printf_large.c:561: output_char (c, p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_c_1_1
	lda	hl,42(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00351$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00351$:
	lda	sp,3(sp)
;printf_large.c:562: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,4(sp)
	inc	(hl)
	jr	nz,00352$
	inc	hl
	inc	(hl)
00352$:
;	genGoto
	jp	00154$
;	genLabel
00219$:
;printf_large.c:574: } else if (radix != 0)
;	genCmpEq
;	AOP_STK for __print_format_radix_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,46(sp)
	ld	a,(hl)
	or	a,a
	jp	z,00224$
00353$:
;printf_large.c:579: unsigned char _AUTOMEM *pstore = &store[5];
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_pstore_4_21
	lda	hl,16(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,32(sp)
	ld	(hl+),a
	ld	(hl),e
;printf_large.c:582: if (char_argument)
;	genIfx
;	AOP_STK for __print_format_char_argument_1_1
	xor	a,a
	lda	hl,56(sp)
	or	a,(hl)
	jp	z,00165$
;printf_large.c:584: value.l = va_arg(ap,char);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
	lda	hl,70(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
;	genAssign
;	AOP_STK for 
	dec	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	dec	bc
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;	genCast
;	AOP_STK for __print_format__1_0
	lda	hl,0(sp)
	ld	(hl),c
	ld	a,c
	rla	
	sbc	a,a
	inc	hl
	ld	(hl+),a
	ld	(hl+),a
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	ld	(hl+),a
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,0(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;printf_large.c:585: if (!signed_argument)
;	genIfx
;	AOP_STK for __print_format_signed_argument_1_1
	xor	a,a
	lda	hl,57(sp)
	or	a,(hl)
	jp	nz,00166$
;printf_large.c:587: value.l &= 0xFF;
;	genPointerGet
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,0(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genAnd
;	AOP_STK for __print_format__1_0
	ld      (hl-),a
	dec	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,0(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;	genGoto
	jp	00166$
;	genLabel
00165$:
;printf_large.c:590: else if (long_argument)
;	genIfx
;	AOP_STK for __print_format_long_argument_1_1
	xor	a,a
	lda	hl,55(sp)
	or	a,(hl)
	jp	z,00162$
;printf_large.c:592: value.l = va_arg(ap,long);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,70(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genAssign
;	AOP_STK for 
	lda	hl,70(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	ld	a,c
	add	a,#0xFC
	ld	c,a
	ld	a,b
	adc	a,#0xFF
	ld	b,a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	e,c
	ld	d,b
	ld	a,(de)
	lda	hl,4(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,4(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;	genGoto
	jp	00166$
;	genLabel
00162$:
;printf_large.c:596: value.l = va_arg(ap,int);
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for 
;	genPlusIncr
	lda	hl,70(sp)
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
	inc	bc
	inc	bc
;	genAssign
;	AOP_STK for 
	dec	hl
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genMinus
	dec	bc
	dec	bc
;	genPointerGet
	ld	e,c
	ld	d,b
	ld	a,(de)
	ld	c,a
	inc	de
	ld	a,(de)
	ld	b,a
;	genCast
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
	ld	a,b
	rla	
	sbc	a,a
	inc	hl
	ld	(hl+),a
	ld	(hl),a
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,4(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;printf_large.c:597: if (!signed_argument)
;	genIfx
;	AOP_STK for __print_format_signed_argument_1_1
	xor	a,a
	lda	hl,57(sp)
	or	a,(hl)
	jp	nz,00166$
;printf_large.c:599: value.l &= 0xFFFF;
;	genPointerGet
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,4(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genAnd
;	AOP_STK for __print_format__1_0
	ld      (hl-),a
	ld	(hl),#0x00
	inc	hl
	ld	(hl),#0x00
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	lda	hl,4(sp)
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;	genLabel
00166$:
;printf_large.c:603: if ( signed_argument )
;	genIfx
;	AOP_STK for __print_format_signed_argument_1_1
	xor	a,a
	lda	hl,57(sp)
	or	a,(hl)
	jp	z,00171$
;printf_large.c:605: if (value.l < 0)
;	genAddrOf
	lda	hl,48(sp)
	ld	c,l
	ld	b,h
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	e,c
	ld	d,b
	ld	a,(de)
	lda	hl,0(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
;	genCmpLt
;	AOP_STK for __print_format__1_0
	ld      (hl),a
; Removed redundent load
	bit	7,a
	jp	z,00168$
;printf_large.c:606: value.l = -value.l;
;	genUminus
;	AOP_STK for __print_format__1_0
	ld	de,#0x0000
	ld	a,e
	lda	hl,0(sp)
	sub	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	push	af
	ld      (hl-),a
	ld	(hl),e
	ld	de,#0x0000
	inc	hl
	inc	hl
	pop	af
	ld	a,e
	sbc	a,(hl)
	ld	e,a
	ld	a,d
	inc	hl
	sbc	a,(hl)
	ld      (hl-),a
	ld	(hl),e
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	ld	e,c
	ld	d,b
	dec	hl
	dec	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
	inc	de
	inc	hl
	ld	a,(hl)
	ld	(de),a
;	genGoto
	jp	00171$
;	genLabel
00168$:
;printf_large.c:608: signed_argument = 0;
;	genAssign
;	AOP_STK for __print_format_signed_argument_1_1
	lda	hl,57(sp)
	ld	(hl),#0x00
;	genLabel
00171$:
;printf_large.c:612: lsd = 1;
;	genAssign
;	AOP_STK for __print_format_lsd_1_1
	lda	hl,47(sp)
	ld	(hl),#0x01
;printf_large.c:614: do {
;	genAssign
;	AOP_STK for __print_format_pstore_4_21
;	AOP_STK for __print_format__1_0
	lda	hl,32(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_length_1_1
	lda	hl,41(sp)
	ld	(hl),#0x00
;	genLabel
00175$:
;printf_large.c:615: value.byte[4] = 0;
;	genAddrOf
;	AOP_STK for __print_format__1_0
	lda	hl,48(sp)
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genAssign (pointer)
;	isBitvar = 0
	ld	a,#0x00
	ld	(bc),a
;printf_large.c:617: calculate_digit(&value, radix);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for __print_format_radix_1_1
	lda	hl,46(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
;	AOP_STK for __print_format__1_0
	lda	hl,5(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_calculate_digit
	lda	sp,3(sp)
;printf_large.c:621: if (!lsd)
;	genIfx
;	AOP_STK for __print_format_lsd_1_1
	xor	a,a
	lda	hl,47(sp)
	or	a,(hl)
	jp	nz,00173$
;printf_large.c:623: *pstore = (value.byte[4] << 4) | (value.byte[4] >> 4) | *pstore;
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,24(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,4(sp)
;	genPointerGet
;	AOP_STK for __print_format__1_0
	ld	(hl+),a
	ld	(hl),d
	ld	e,a
	ld	a,(de)
;	genLeftShift
	ld	c,a
	rlca
	rlca
	rlca
	rlca
	and	a,#0xF0
	ld	c,a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	b,a
;	genRightShift
; Removed redundent load
	srl	b
	srl	b
	srl	b
	srl	b
;	genOr
	ld	a,c
	or	a,b
	ld	c,a
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	b,a
;	genOr
	ld	a,c
	or	a,b
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;printf_large.c:624: pstore--;
;	genMinus
;	AOP_STK for __print_format__1_0
	dec	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	dec	de
	dec	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;	genGoto
	jp	00174$
;	genLabel
00173$:
;printf_large.c:628: *pstore = value.byte[4];
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,26(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	c,l
	ld	b,h
;	genPointerGet
	ld	a,(bc)
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;	genLabel
00174$:
;printf_large.c:630: length++;
;	genPlus
;	AOP_STK for __print_format_length_1_1
;	genPlusIncr
	lda	hl,41(sp)
	inc	(hl)
;	genAssign
;	AOP_STK for __print_format_length_1_1
;	AOP_STK for __print_format__1_0
	ld	a,(hl)
	lda	hl,13(sp)
	ld	(hl),a
;printf_large.c:631: lsd = !lsd;
;	genNot
;	AOP_STK for __print_format_lsd_1_1
	xor	a,a
	lda	hl,47(sp)
	or	a,(hl)
	sub	a,#0x01
	ld	a,#0x00
	rla
	ld	(hl),a
;printf_large.c:632: } while( value.ul );
;	genPointerGet
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,22(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	lda	hl,4(sp)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl+),a
	inc	de
	ld	a,(de)
	ld	(hl),a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_pstore_4_21
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,32(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	a,(hl+)
	or	a,(hl)
	inc	hl
	or	a,(hl)
	inc	hl
	or	a,(hl)
	jp	nz,00175$
;printf_large.c:634: if (width == 0)
;	genCmpEq
;	AOP_STK for __print_format_width_1_1
; genCmpEq: left 1, right 1, result 0
	lda	hl,43(sp)
	ld	a,(hl)
	or	a,a
	jp	nz,00179$
	jr	00355$
00354$:
	jp	00179$
00355$:
;printf_large.c:639: width=1;
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),#0x01
;	genLabel
00179$:
;printf_large.c:643: if (!zero_padding && !left_justify)
;	genIfx
;	AOP_STK for __print_format_zero_padding_1_1
	xor	a,a
	lda	hl,60(sp)
	or	a,(hl)
	jp	nz,00184$
;	genIfx
;	AOP_STK for __print_format_left_justify_1_1
	xor	a,a
	inc	hl
	or	a,(hl)
	jp	nz,00184$
;printf_large.c:645: while ( width > (unsigned char) (length+1) )
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,13(sp)
	ld	a,(hl)
	add	a,#0x01
	lda	hl,4(sp)
	ld	(hl),a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	b,(hl)
;	genLabel
00180$:
;	genCmpGt
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	a,(hl)
	sub	a,b
	ld	a,#0x00
	rla
	ld	c,a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),b
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00184$
;printf_large.c:647: output_char( ' ', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for 
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x20
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00356$
	push	hl
	lda	hl,71(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00356$:
	lda	sp,3(sp)
	pop	bc
;printf_large.c:648: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,0(sp)
	inc	(hl)
	jr	nz,00357$
	inc	hl
	inc	(hl)
00357$:
;printf_large.c:649: width--;
;	genMinus
	dec	b
;	genGoto
	jp	00180$
;	genLabel
00184$:
;printf_large.c:653: if (signed_argument) // this now means the original value was negative
;	genIfx
;	AOP_STK for __print_format_signed_argument_1_1
	xor	a,a
	lda	hl,57(sp)
	or	a,(hl)
	jp	z,00194$
;printf_large.c:655: output_char( '-', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x2D
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00358$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00358$:
	lda	sp,3(sp)
;printf_large.c:656: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00359$
	inc	hl
	inc	(hl)
00359$:
;printf_large.c:658: width--;
;	genMinus
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	dec	(hl)
;	genGoto
	jp	00195$
;	genLabel
00194$:
;printf_large.c:660: else if (length != 0)
;	genCmpEq
;	AOP_STK for __print_format__1_0
; genCmpEq: left 1, right 1, result 0
	lda	hl,13(sp)
	ld	a,(hl)
	or	a,a
	jp	z,00195$
00360$:
;printf_large.c:663: if (prefix_sign)
;	genIfx
;	AOP_STK for __print_format_prefix_sign_1_1
	xor	a,a
	lda	hl,59(sp)
	or	a,(hl)
	jp	z,00189$
;printf_large.c:665: output_char( '+', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x2B
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00361$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00361$:
	lda	sp,3(sp)
;printf_large.c:666: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00362$
	inc	hl
	inc	(hl)
00362$:
;printf_large.c:668: width--;
;	genMinus
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	dec	(hl)
;	genGoto
	jp	00195$
;	genLabel
00189$:
;printf_large.c:670: else if (prefix_space)
;	genIfx
;	AOP_STK for __print_format_prefix_space_1_1
	xor	a,a
	lda	hl,58(sp)
	or	a,(hl)
	jp	z,00195$
;printf_large.c:672: output_char( ' ', p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x20
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00363$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00363$:
	lda	sp,3(sp)
;printf_large.c:673: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00364$
	inc	hl
	inc	(hl)
00364$:
;printf_large.c:675: width--;
;	genMinus
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	dec	(hl)
;	genLabel
00195$:
;printf_large.c:680: if (!left_justify)
;	genIfx
;	AOP_STK for __print_format_left_justify_1_1
	xor	a,a
	lda	hl,61(sp)
	or	a,(hl)
	jp	nz,00203$
;printf_large.c:681: while ( width-- > length )
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	b,(hl)
;	genLabel
00196$:
;	genAssign
	ld	c,b
;	genMinus
	dec	b
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),b
;	genCmpGt
;	AOP_STK for __print_format__1_0
	lda	hl,13(sp)
	ld	a,(hl)
	sub	a,c
	ld	a,#0x00
	rla
	ld	c,a
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00299$
;printf_large.c:683: output_char( zero_padding ? '0' : ' ', p );
;	genIfx
;	AOP_STK for __print_format_zero_padding_1_1
	xor	a,a
	lda	hl,60(sp)
	or	a,(hl)
	jp	z,00231$
;	genAssign
	ld	c,#0x30
;	genGoto
	jp	00232$
;	genLabel
00231$:
;	genAssign
	ld	c,#0x20
;	genLabel
00232$:
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for 
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00365$
	push	hl
	lda	hl,71(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00365$:
	lda	sp,3(sp)
	pop	bc
;printf_large.c:684: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,4(sp)
	inc	(hl)
	jr	nz,00366$
	inc	hl
	inc	(hl)
00366$:
;	genGoto
	jp	00196$
;	genLabel
00203$:
;printf_large.c:689: if (width > length)
;	genCmpGt
;	AOP_STK for __print_format_width_1_1
;	AOP_STK for __print_format__1_0
	lda	hl,13(sp)
	ld	a,(hl)
	lda	hl,43(sp)
	sub	a,(hl)
	jp	nc,00200$
;printf_large.c:690: width -= length;
;	genMinus
;	AOP_STK for __print_format_width_1_1
;	AOP_STK for __print_format__1_0
	ld	a,(hl)
	lda	hl,13(sp)
	sub	a,(hl)
	lda	hl,43(sp)
	ld	(hl),a
;	genGoto
	jp	00299$
;	genLabel
00200$:
;printf_large.c:692: width = 0;
;	genAssign
;	AOP_STK for __print_format_width_1_1
	lda	hl,43(sp)
	ld	(hl),#0x00
;printf_large.c:696: while( length-- )
;	genLabel
00299$:
;	genAssign
;	AOP_STK for __print_format_pstore_4_21
;	AOP_STK for __print_format__1_0
	lda	hl,32(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,8(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,28(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,0(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,13(sp)
	ld	a,(hl)
	lda	hl,4(sp)
	ld	(hl),a
;	genLabel
00208$:
;	genAssign
;	AOP_STK for __print_format__1_0
	lda	hl,4(sp)
	ld	c,(hl)
;	genMinus
;	AOP_STK for __print_format__1_0
	dec	(hl)
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,c
	jp	z,00210$
;printf_large.c:698: lsd = !lsd;
;	genNot
;	AOP_STK for __print_format_lsd_1_1
	xor	a,a
	lda	hl,47(sp)
	or	a,(hl)
	sub	a,#0x01
	ld	a,#0x00
	rla
	ld	(hl),a
;printf_large.c:699: if (!lsd)
;	genIfx
;	AOP_STK for __print_format_lsd_1_1
	xor	a,a
	or	a,(hl)
	jp	nz,00206$
;printf_large.c:701: pstore++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,8(sp)
	inc	(hl)
	jr	nz,00367$
	inc	hl
	inc	(hl)
00367$:
;printf_large.c:702: value.byte[4] = *pstore >> 4;
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,18(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,11(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genRightShift
; Removed redundent load
	srl	c
	srl	c
	srl	c
	srl	c
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,c
	ld	(de),a
;	genGoto
	jp	00207$
;	genLabel
00206$:
;printf_large.c:706: value.byte[4] = *pstore & 0x0F;
;	genPlus
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format__1_0
;	genPlusIncr
;	Can't optimise plus by inc, falling back to the normal way
	lda	hl,20(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	hl,#0x0004
	add	hl,de
	ld	a,l
	ld	d,h
	lda	hl,11(sp)
	ld	(hl+),a
	ld	(hl),d
;	genPointerGet
;	AOP_STK for __print_format__1_0
	lda	hl,8(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genAnd
	ld	c,a
	and	a,#0x0F
;	genAssign (pointer)
;	AOP_STK for __print_format__1_0
;	isBitvar = 0
	inc	hl
	inc	hl
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	(de),a
;	genLabel
00207$:
;printf_large.c:709: output_digit( value.byte[4], lower_case, output_char, p );
;	genAddrOf
	lda	hl,48(sp)
	ld	c,l
	ld	b,h
;	genPlus
;	genPlusIncr
	inc	bc
	inc	bc
	inc	bc
	inc	bc
;	genPointerGet
	ld	a,(bc)
	ld	c,a
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_lower_case_1_1
	lda	hl,57(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genIpush
	ld	a,c
	push	af
	inc	sp
;	genCall
	call	_output_digit
	lda	sp,6(sp)
;printf_large.c:713: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,0(sp)
	inc	(hl)
	jr	nz,00368$
	inc	hl
	inc	(hl)
00368$:
;	genGoto
	jp	00208$
;	genLabel
00210$:
;printf_large.c:715: if (left_justify)
;	genIfx
;	AOP_STK for __print_format_left_justify_1_1
	xor	a,a
	lda	hl,61(sp)
	or	a,(hl)
	jp	z,00224$
;printf_large.c:716: while (width-- > 0)
;	genAssign
;	AOP_STK for __print_format__1_0
;	AOP_STK for __print_format_charsOutputted_1_1
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,44(sp)
	ld	(hl+),a
	ld	(hl),e
;	genAssign
;	AOP_STK for __print_format_width_1_1
	dec	hl
	dec	hl
	ld	c,(hl)
;	genLabel
00211$:
;	genAssign
	ld	b,c
;	genMinus
	dec	c
;	genCmpGt
	ld	a,#0x00
	sub	a,b
	ld	a,#0x00
	rla
	ld	b,a
;	genAssign
;	AOP_STK for __print_format_charsOutputted_1_1
;	AOP_STK for __print_format__1_0
	lda	hl,44(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,28(sp)
	ld	(hl+),a
	ld	(hl),e
;	genIfx
	xor	a,a
	or	a,b
	jp	z,00224$
;printf_large.c:718: output_char(' ', p);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for 
	lda	hl,68(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x20
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00369$
	push	hl
	lda	hl,71(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00369$:
	lda	sp,3(sp)
	pop	bc
;printf_large.c:719: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format_charsOutputted_1_1
;	genPlusIncr
	lda	hl,44(sp)
	inc	(hl)
	jr	nz,00370$
	inc	hl
	inc	(hl)
00370$:
;	genGoto
	jp	00211$
;	genLabel
00222$:
;printf_large.c:726: output_char( c, p );
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,66(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for __print_format_c_1_1
	lda	hl,42(sp)
	ld	a,(hl)
	push	af
	inc	sp
;	genPcall
;	AOP_STK for 
	ld	hl,#00371$
	push	hl
	lda	hl,69(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	jp	(hl)
00371$:
	lda	sp,3(sp)
;printf_large.c:727: charsOutputted++;
;	genPlus
;	AOP_STK for __print_format__1_0
;	genPlusIncr
	lda	hl,28(sp)
	inc	(hl)
	jr	nz,00372$
	inc	hl
	inc	(hl)
00372$:
;	genGoto
	jp	00224$
;	genLabel
00226$:
;printf_large.c:731: return charsOutputted;
;	genRet
;	AOP_STK for __print_format__1_0
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk -34
	lda	hl,28(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
;	genLabel
00227$:
;	genEndFunction
	lda	sp,62(sp)
	ret
__print_format_end::
__str_1:
	.ascii "<NO FLOAT>"
	.db 0x00
	.area _CODE
