;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:56:04 2005
;--------------------------------------------------------
	.module powf
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _powf_PARM_2
	.globl _powf_PARM_1
	.globl _powf
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_powf_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_powf_PARM_1::
	.ds 4
_powf_PARM_2::
	.ds 4
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'powf'
;------------------------------------------------------------
;sloc0                     Allocated with name '_powf_sloc0_1_0'
;x                         Allocated with name '_powf_PARM_1'
;y                         Allocated with name '_powf_PARM_2'
;------------------------------------------------------------
;powf.c:25: float powf(const float x, const float y)
;	-----------------------------------------
;	 function powf
;	-----------------------------------------
_powf:
;powf.c:27: if(y == 0.0) return 1.0;
	lda	_powf_PARM_2
	sta	___fseq_PARM_1
	lda	(_powf_PARM_2 + 1)
	sta	(___fseq_PARM_1 + 1)
	lda	(_powf_PARM_2 + 2)
	sta	(___fseq_PARM_1 + 2)
	lda	(_powf_PARM_2 + 3)
	sta	(___fseq_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fseq_PARM_2
	sta	(___fseq_PARM_2 + 1)
	sta	(___fseq_PARM_2 + 2)
	sta	(___fseq_PARM_2 + 3)
	jsr	___fseq
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00112$:
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
; Peephole 6a  - replaced jmp to rts with rts
	rts
00102$:
;powf.c:28: if(y==1.0) return x;
	lda	_powf_PARM_2
	sta	___fseq_PARM_1
	lda	(_powf_PARM_2 + 1)
	sta	(___fseq_PARM_1 + 1)
	lda	(_powf_PARM_2 + 2)
	sta	(___fseq_PARM_1 + 2)
	lda	(_powf_PARM_2 + 3)
	sta	(___fseq_PARM_1 + 3)
	lda	#0x3F
	sta	___fseq_PARM_2
	lda	#0x80
	sta	(___fseq_PARM_2 + 1)
; Peephole 5c   - eliminated redundant clra
	clra
	sta	(___fseq_PARM_2 + 2)
	sta	(___fseq_PARM_2 + 3)
	jsr	___fseq
	tsta
; Peephole 2d	- eliminated jmp
	beq	00104$
00113$:
	lda	_powf_PARM_1
	sta	*__ret3
	lda	(_powf_PARM_1 + 1)
	sta	*__ret2
	ldx	(_powf_PARM_1 + 2)
	lda	(_powf_PARM_1 + 3)
; Peephole 6a  - replaced jmp to rts with rts
	rts
00104$:
;powf.c:29: if(x <= 0.0) return 0.0;
	lda	_powf_PARM_1
	sta	___fsgt_PARM_1
	lda	(_powf_PARM_1 + 1)
	sta	(___fsgt_PARM_1 + 1)
	lda	(_powf_PARM_1 + 2)
	sta	(___fsgt_PARM_1 + 2)
	lda	(_powf_PARM_1 + 3)
	sta	(___fsgt_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fsgt_PARM_2
	sta	(___fsgt_PARM_2 + 1)
	sta	(___fsgt_PARM_2 + 2)
	sta	(___fsgt_PARM_2 + 3)
	jsr	___fsgt
	tsta
; Peephole 2c	- eliminated jmp
	bne	00106$
00114$:
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
; Peephole 3	- shortened jmp to bra
; Peephole 6b  - replaced jmp to rts with rts
	rts
00106$:
;powf.c:30: return expf(logf(x) * y);
	lda	(_powf_PARM_1 + 3)
	psha
	lda	(_powf_PARM_1 + 2)
	psha
	lda	(_powf_PARM_1 + 1)
	psha
	lda	_powf_PARM_1
	psha
	jsr	_logf
	sta	(___fsmul_PARM_1 + 3)
	stx	(___fsmul_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsmul_PARM_1 + 1)
	lda	*__ret3
	sta	___fsmul_PARM_1
	ais	#4
	lda	_powf_PARM_2
	sta	___fsmul_PARM_2
	lda	(_powf_PARM_2 + 1)
	sta	(___fsmul_PARM_2 + 1)
	lda	(_powf_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 2)
	lda	(_powf_PARM_2 + 3)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(_expf_PARM_1 + 3)
	stx	(_expf_PARM_1 + 2)
	lda	*__ret2
	sta	(_expf_PARM_1 + 1)
	lda	*__ret3
	sta	_expf_PARM_1
	jsr	_expf
	sta	*(_powf_sloc0_1_0 + 3)
	stx	*(_powf_sloc0_1_0 + 2)
	mov	*__ret2,*(_powf_sloc0_1_0 + 1)
	mov	*__ret3,*_powf_sloc0_1_0
	mov	*_powf_sloc0_1_0,*__ret3
	mov	*(_powf_sloc0_1_0 + 1),*__ret2
	ldx	*(_powf_sloc0_1_0 + 2)
	lda	*(_powf_sloc0_1_0 + 3)
00107$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
