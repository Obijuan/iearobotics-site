;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:53:47 2005
;--------------------------------------------------------
	.module _strcmp
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strcmp
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_strcmp.c:29: int strcmp (
;	genLabel
;	genFunction
;	---------------------------------
; Function strcmp
; ---------------------------------
_strcmp_start::
_strcmp:
	lda	sp,-6(sp)
;_strcmp.c:38: char * src = asrc;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strcmp_src_1_1
	lda	hl,8(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,4(sp)
	ld	(hl+),a
	ld	(hl),e
;_strcmp.c:39: char * dst = adst;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strcmp_dst_1_1
	lda	hl,10(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,2(sp)
	ld	(hl+),a
	ld	(hl),e
;_strcmp.c:41: while( ! (*src - *dst) && *dst)
;	genLabel
00102$:
;	genPointerGet
;	AOP_STK for _strcmp_src_1_1
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genPointerGet
;	AOP_STK for _strcmp_dst_1_1
	lda	hl,2(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	b,a
;	genMinus
	ld	a,c
	sub	a,b
;	genIfx
	or	a,a
	jp	nz,00104$
;	genIfx
	xor	a,a
	or	a,b
	jp	z,00104$
;_strcmp.c:42: ++src, ++dst;
;	genPlus
;	AOP_STK for _strcmp_src_1_1
;	genPlusIncr
	inc	hl
	inc	(hl)
	jr	nz,00110$
	inc	hl
	inc	(hl)
00110$:
;	genPlus
;	AOP_STK for _strcmp_dst_1_1
;	genPlusIncr
	lda	hl,2(sp)
	inc	(hl)
	jr	nz,00111$
	inc	hl
	inc	(hl)
00111$:
;	genGoto
	jp	00102$
;	genLabel
00104$:
;_strcmp.c:44: return *src - *dst;
;	genPointerGet
;	AOP_STK for _strcmp_src_1_1
	lda	hl,4(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genCast
;	AOP_STK for _strcmp__1_0
	lda	hl,0(sp)
	ld	(hl),c
	ld	a,c
	rla	
	sbc	a,a
	inc	hl
;	genPointerGet
;	AOP_STK for _strcmp_dst_1_1
	ld	(hl+),a
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
;	genCast
; Removed redundent load
	ld	c,a
	rla	
	sbc	a,a
	ld	b,a
;	genMinus
;	AOP_STK for _strcmp__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,e
	sub	a,c
	ld	e,a
	ld	a,d
	sbc	a,b
	ld	d,a
;	genRet
; Dump of IC_LEFT: type AOP_STR size 2
;	genLabel
00105$:
;	genEndFunction
	lda	sp,6(sp)
	ret
_strcmp_end::
	.area _CODE
