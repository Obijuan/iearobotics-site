;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:46:56 2005
;--------------------------------------------------------
	.module _atoi
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _atoi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_atoi_s_1_1::
	.ds 4
_atoi_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'atoi'
;------------------------------------------------------------
;s                         Allocated with name '_atoi_s_1_1'
;rv                        Allocated to registers r6 r7 
;sign                      Allocated to registers r4 
;sloc0                     Allocated with name '_atoi_sloc0_1_0'
;------------------------------------------------------------
;	_atoi.c:25: int atoi(char * s)
;	genFunction 
;	-----------------------------------------
;	 function atoi
;	-----------------------------------------
_atoi:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_atoi_s_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	_atoi.c:27: register int rv=0; 
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	r6,#0x00
	mov	r7,#0x00
;	_atoi.c:31: while (*s) {
;	genAssign 
	mov	dptr,#_atoi_s_1_1
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genLabel 
00107$:
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r2
	mov	b,r3
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r4,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00109$
00133$:
;	_atoi.c:32: if (*s <= '9' && *s >= '0')
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 159   avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r4
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00102$
00134$:
;	genCmpLt 
;	genCmp
	clr	c
	mov	a,r4
	xrl	a,#0x80
	subb	a,#0xB0
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00109$
00135$:
;	_atoi.c:33: break;
;	genLabel 
00102$:
;	_atoi.c:34: if (*s == '-' || *s == '+') 
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r2
	mov	b,r3
	lcall	__gptrget
;	genCmpEq 
;	gencjneshort
; Peephole 105   removed redundant mov
	mov  r4,a
	cjne	a,#0x2D,00136$
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00136$:
;	genCmpEq 
;	gencjneshort
	mov	a,r4
	cjne	a,#0x2B,00137$
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00137$:
;	_atoi.c:36: s++;
;	genPlus 
	inc	r0
	cjne	r0,#0,00138$
	inc	r1
	cjne	r1,#0,00138$
	inc	r2
00138$:
;	did genPlusIncr
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00109$:
;	_atoi.c:39: sign = (*s == '-');
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_atoi_s_1_1
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r0
	mov	dph,r1
	mov	dpx,r2
	mov	b,r3
	lcall	__gptrget
;	genCmpEq 
;	gencjne
;	gencjneshort
; Peephole 105   removed redundant mov
	mov  r2,a
	cjne	a,#0x2D,00139$
	mov	a,#1
	sjmp	00140$
00139$:
	clr	a
00140$:
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	_atoi.c:40: if (*s == '-' || *s == '+') s++;
;	genIfx 
; Peephole 166   removed redundant mov
	mov  r3,a
	mov  ar4,r3 
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00110$
00141$:
;	genCmpEq 
;	gencjneshort
	mov	a,r2
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x2B,00131$
;00142$:
; Peephole 200   removed redundant sjmp
00143$:
;	genLabel 
00110$:
;	genPlus 
	mov	dptr,#_atoi_s_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_atoi.c:42: while (*s && *s >= '0' && *s <= '9') {
;	genLabel 
00131$:
;	genAssign 
	mov	dptr,#_atoi_s_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_atoi_sloc0_1_0
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00115$:
;	genPointerGet 
;	genGenPointerGet 
	mov     dps, #1
	mov     dptr, #_atoi_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r1,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00117$
00144$:
;	genCmpLt 
;	genCmp
	clr	c
	mov	a,r1
	xrl	a,#0x80
	subb	a,#0xB0
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00117$
00145$:
;	genCmpGt 
;	genCmp
	clr	c
; Peephole 159   avoided xrl during execution
	mov  a,#(0x39 ^ 0x80)
	mov	b,r1
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 132   changed ljmp to sjmp
; Peephole 160   removed sjmp by inverse jump logic
	jc   00117$
00146$:
;	_atoi.c:43: rv = (rv * 10) + (*s - '0');
;	genIpush 
	push	ar4
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mulint_PARM_2
	mov	a,#0x0A
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	genCall 
	push	ar1
;	genSend argreg = 1, size = 2 
	mov	dpl,r6
	mov	dph,r7
	lcall	__mulint
	mov	r4,dpl
	mov	r2,dph
	pop	ar1
;	genCast 
	mov	a,r1
	rlc	a
	subb	a,acc
	mov	r3,a
;	genMinus 
	mov	a,r1
	add	a,#0xD0
	mov	r1,a
	mov	a,r3
	addc	a,#0xFF
	mov	r3,a
;	genPlus 
	mov	a,r1
	add	a,r4
	mov	r6,a
	mov	a,r3
	addc	a,r2
	mov	r7,a
;	_atoi.c:44: s++;
;	genPlus 
	mov	dptr,#_atoi_sloc0_1_0
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genIpop 
	pop	ar4
;	genGoto 
	ljmp	00115$
;	genLabel 
00117$:
;	_atoi.c:47: return (sign ? -rv : rv);
;	genIfx 
	mov	a,r4
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00120$
00147$:
;	genUminus 
	clr	c
	clr	a
	subb	a,r6
	mov	dpl,a
	clr	a
	subb	a,r7
	mov	dph,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00120$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,r6
	mov	dph,r7
;	genLabel 
00121$:
;	genRet 
;	genLabel 
00118$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
