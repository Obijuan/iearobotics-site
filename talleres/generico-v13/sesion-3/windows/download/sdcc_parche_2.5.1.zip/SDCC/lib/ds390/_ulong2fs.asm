;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:48:16 2005
;--------------------------------------------------------
	.module _ulong2fs
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___ulong2fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
___ulong2fs_a_1_1::
	.ds 4
___ulong2fs_fl_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__ulong2fs'
;------------------------------------------------------------
;a                         Allocated with name '___ulong2fs_a_1_1'
;exp                       Allocated to registers r5 r6 
;fl                        Allocated with name '___ulong2fs_fl_1_1'
;------------------------------------------------------------
;	_ulong2fs.c:75: float __ulong2fs (unsigned long a )
;	genFunction 
;	-----------------------------------------
;	 function __ulong2fs
;	-----------------------------------------
___ulong2fs:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #___ulong2fs_a_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	_ulong2fs.c:80: if (!a)
;	genIfx 
	mov	dptr,#___ulong2fs_a_1_1
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00115$
00119$:
;	_ulong2fs.c:82: return 0.0;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00111$
;	_ulong2fs.c:85: while (a & NORM) 
;	genLabel 
00115$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,#0x96
	mov	r7,#0x00
;	genLabel 
00103$:
;	genAnd 
	mov	dptr,#___ulong2fs_a_1_1
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
; Peephole 110   removed ljmp by inverse jump logic
	jz  00117$
00120$:
;	_ulong2fs.c:88: a >>= 1;
;	genRightShift 
;	genRightShiftLiteral (1), size 4
	mov	dptr,#___ulong2fs_a_1_1
;	genrshFour
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	clr	c
	rrc	a
	mov	r3,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r2,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r1,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 100   removed redundant mov
	mov  r0,a
	mov  dptr,#___ulong2fs_a_1_1
	movx @dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_ulong2fs.c:89: exp++;
;	genPlus 
;	tail increment optimized (range 5)
	inc	r6
	cjne	r6,#0,00103$
	inc	r7
;	did genPlusIncr
;	genGoto 
;	_ulong2fs.c:92: while (a < HIDDEN)
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00117$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
;	genLabel 
00106$:
;	genCmpLt 
	mov	dptr,#___ulong2fs_a_1_1
;	genCmp
	clr	c
	movx	a,@dptr
	subb	a,#0x00
	inc	dptr
	movx	a,@dptr
	subb	a,#0x00
	inc	dptr
	movx	a,@dptr
	subb	a,#0x80
	inc	dptr
	movx	a,@dptr
	subb	a,#0x00
	clr	a
	rlc	a
	mov	r4,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar5,r2
	mov	ar6,r3
;	genIfx 
	mov	a,r4
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00108$
00121$:
;	_ulong2fs.c:94: a <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	dptr,#___ulong2fs_a_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r7,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r0,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r1,a
	sjmp	00123$
00122$:
	mov	a,r4
	add	a,acc
	mov	r4,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
00123$:
	djnz	b,00122$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___ulong2fs_a_1_1
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	_ulong2fs.c:95: exp--;
;	genMinus 
	dec	r2
	cjne	r2,#0xFF,00124$
	dec	r3
00124$:
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00106$
00108$:
;	_ulong2fs.c:99: if ((a&0x7fffff)==0x7fffff) {
;	genAnd 
	mov	dptr,#___ulong2fs_a_1_1
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	better literal AND.
	inc	dptr
	movx	a,@dptr
	anl	a, #0x7F
	mov	r0,a
	mov	r1,#0
;	genCmpEq 
;	gencjneshort
	mov	a,r4
; Peephole 132   changed ljmp to sjmp
; Peephole 193   optimized misc jump sequence
	cjne a,#0xFF,00110$
	mov  a,r7
	cjne a,#0xFF,00110$
	mov  a,r0
	cjne a,#0x7F,00110$
	mov  a,r1
	cjne a,#0x00,00110$
;00125$:
; Peephole 200   removed redundant sjmp
00126$:
;	_ulong2fs.c:100: a=0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___ulong2fs_a_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	_ulong2fs.c:101: exp++;
;	genPlus 
	mov	a,#0x01
	add	a,r2
	mov	r5,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r3
	mov	r6,a
;	genLabel 
00110$:
;	_ulong2fs.c:105: a &= ~HIDDEN ;
;	genAnd 
	mov	dptr,#___ulong2fs_a_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	better literal AND.
	inc	dptr
	movx	a,@dptr
	anl	a, #0x7F
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_ulong2fs.c:107: fl.l = PACK(0,(unsigned long)exp, a);
;	genCast 
	mov	a,r6
	rlc	a
	subb	a,acc
	mov	r2,a
	mov	r3,a
;	genLeftShift 
;	genLeftShiftLiteral (23), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x18
	sjmp	00128$
00127$:
	mov	a,r5
	add	a,acc
	mov	r5,a
	mov	a,r6
	rlc	a
	mov	r6,a
	mov	a,r2
	rlc	a
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
00128$:
	djnz	b,00127$
;	genOr 
	mov	dptr,#___ulong2fs_a_1_1
	movx	a,@dptr
	orl	ar5,a
	inc	dptr
	movx	a,@dptr
	orl	ar6,a
	inc	dptr
	movx	a,@dptr
	orl	ar2,a
	inc	dptr
	movx	a,@dptr
	orl	ar3,a
;	genPointerSet 
	mov	dptr,#___ulong2fs_fl_1_1
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_ulong2fs.c:109: return (fl.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___ulong2fs_fl_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00111$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
