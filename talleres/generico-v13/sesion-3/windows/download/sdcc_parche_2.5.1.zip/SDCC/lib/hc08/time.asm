;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:59 2005
;--------------------------------------------------------
	.module time
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___day
	.globl ___month
	.globl _RtcRead
	.globl _time
	.globl _asctime
	.globl _ctime
	.globl _localtime
	.globl _gmtime
	.globl _mktime
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_asctime_sloc0_1_0::
	.ds 2
_asctime_sloc1_1_0::
	.ds 2
_asctime_sloc2_1_0::
	.ds 2
_asctime_sloc3_1_0::
	.ds 2
_asctime_sloc4_1_0::
	.ds 2
_asctime_sloc5_1_0::
	.ds 2
_asctime_sloc6_1_0::
	.ds 2
_ctime_sloc0_1_0::
	.ds 2
_localtime_sloc0_1_0::
	.ds 2
_gmtime_sloc0_1_0::
	.ds 4
_gmtime_sloc1_1_0::
	.ds 2
_gmtime_sloc2_1_0::
	.ds 4
_mktime_sloc0_1_0::
	.ds 2
_mktime_sloc1_1_0::
	.ds 4
_mktime_sloc2_1_0::
	.ds 1
_mktime_sloc3_1_0::
	.ds 2
_mktime_sloc4_1_0::
	.ds 4
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area	OSEG    (OVR)
_CheckTime_sloc0_1_0::
	.ds 2
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_time_timeptr_1_1::
	.ds 2
_time_now_1_1::
	.ds 12
_time_t_1_1::
	.ds 4
_ascTimeBuffer:
	.ds 32
_CheckTime_timeptr_1_1::
	.ds 2
_asctime_timeptr_1_1::
	.ds 2
_lastTime:
	.ds 12
_gmtime_timep_1_1::
	.ds 2
_gmtime_epoch_1_1::
	.ds 4
_gmtime_year_1_1::
	.ds 2
_gmtime_monthLength_1_1::
	.ds 1
_gmtime_days_1_1::
	.ds 4
_mktime_timeptr_1_1::
	.ds 2
_mktime_year_1_1::
	.ds 2
_mktime_month_1_1::
	.ds 2
_mktime_seconds_1_1::
	.ds 4
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'RtcRead'
;------------------------------------------------------------
;timeptr                   Allocated to registers 
;------------------------------------------------------------
;time.c:38: unsigned char RtcRead(struct tm *timeptr) {
;	-----------------------------------------
;	 function RtcRead
;	-----------------------------------------
_RtcRead:
;time.c:41: return 0;
	clra
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'time'
;------------------------------------------------------------
;timeptr                   Allocated with name '_time_timeptr_1_1'
;now                       Allocated with name '_time_now_1_1'
;t                         Allocated with name '_time_t_1_1'
;------------------------------------------------------------
;time.c:46: time_t time(time_t *timeptr) {
;	-----------------------------------------
;	 function time
;	-----------------------------------------
_time:
	sta	(_time_timeptr_1_1 + 1)
	stx	_time_timeptr_1_1
;time.c:48: time_t t=-1;
; Peephole 5d   - eliminated redundant lda
	lda	#0xFF
	sta	_time_t_1_1
	sta	(_time_t_1_1 + 1)
	sta	(_time_t_1_1 + 2)
	sta	(_time_t_1_1 + 3)
;time.c:50: if (RtcRead(&now)) {
	ldx	#>_time_now_1_1
	lda	#_time_now_1_1
	jsr	_RtcRead
	tsta
; Peephole 2d	- eliminated jmp
	beq	00102$
00109$:
;time.c:51: t=mktime(&now);
	ldx	#>_time_now_1_1
	lda	#_time_now_1_1
	jsr	_mktime
	sta	(_time_t_1_1 + 3)
	stx	(_time_t_1_1 + 2)
	lda	*__ret2
	sta	(_time_t_1_1 + 1)
	lda	*__ret3
	sta	_time_t_1_1
00102$:
;time.c:53: if (timeptr) {
	lda	(_time_timeptr_1_1 + 1)
	ora	_time_timeptr_1_1
; Peephole 2d	- eliminated jmp
	beq	00104$
00110$:
;time.c:54: *timeptr=t;
	lda	_time_timeptr_1_1
	ldx	(_time_timeptr_1_1 + 1)
	psha
	pulh
	lda	_time_t_1_1
	sta	,x
	aix	#1
	lda	(_time_t_1_1 + 1)
	sta	,x
	aix	#1
	lda	(_time_t_1_1 + 2)
	sta	,x
	aix	#1
	lda	(_time_t_1_1 + 3)
	sta	,x
00104$:
;time.c:56: return t;
	lda	_time_t_1_1
	sta	*__ret3
	lda	(_time_t_1_1 + 1)
	sta	*__ret2
	ldx	(_time_t_1_1 + 2)
	lda	(_time_t_1_1 + 3)
00105$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'CheckTime'
;------------------------------------------------------------
;timeptr                   Allocated with name '_CheckTime_timeptr_1_1'
;sloc0                     Allocated with name '_CheckTime_sloc0_1_0'
;------------------------------------------------------------
;time.c:69: static void CheckTime(struct tm *timeptr) {
;	-----------------------------------------
;	 function CheckTime
;	-----------------------------------------
_CheckTime:
	sta	(_CheckTime_timeptr_1_1 + 1)
	stx	_CheckTime_timeptr_1_1
;time.c:80: if (timeptr->tm_sec>59) timeptr->tm_sec=59;
	lda	_CheckTime_timeptr_1_1
	ldx	(_CheckTime_timeptr_1_1 + 1)
	psha
	pulh
	lda	,x
	cmp	#0x3B
; Peephole 2h	- eliminated bra
	bls	00102$
00128$:
	lda	_CheckTime_timeptr_1_1
	ldx	(_CheckTime_timeptr_1_1 + 1)
	psha
	pulh
	lda	#0x3B
	sta	,x
00102$:
;time.c:81: if (timeptr->tm_min>59) timeptr->tm_min=59;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x01
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x3B
; Peephole 2h	- eliminated bra
	bls	00104$
00129$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x01
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x3B
	sta	,x
00104$:
;time.c:82: if (timeptr->tm_hour>23) timeptr->tm_hour=23;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x02
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x17
; Peephole 2h	- eliminated bra
	bls	00106$
00130$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x02
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x17
	sta	,x
00106$:
;time.c:83: if (timeptr->tm_wday>6) timeptr->tm_wday=6;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x07
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x06
; Peephole 2h	- eliminated bra
	bls	00108$
00131$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x07
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x06
	sta	,x
00108$:
;time.c:84: if (timeptr->tm_mday<1) timeptr->tm_mday=1;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x01
; Peephole 2a	- eliminated jmp
	bcc	00112$
00132$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x01
	sta	,x
; Peephole 3	- shortened jmp to bra
	bra	00113$
00112$:
;time.c:85: else if (timeptr->tm_mday>31) timeptr->tm_mday=31;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x1F
; Peephole 2h	- eliminated bra
	bls	00113$
00133$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x1F
	sta	,x
00113$:
;time.c:86: if (timeptr->tm_mon>11) timeptr->tm_mon=11;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x04
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	cmp	#0x0B
; Peephole 2h	- eliminated bra
	bls	00115$
00134$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x04
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	#0x0B
	sta	,x
00115$:
;time.c:87: if (timeptr->tm_year<0) timeptr->tm_year=0;
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x05
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	lda	,x
	aix	#1
	sta	*_CheckTime_sloc0_1_0
	lda	,x
	sta	*(_CheckTime_sloc0_1_0 + 1)
	ldhx	*_CheckTime_sloc0_1_0
	cphx	#0x0000
; Peephole 2l	- eliminated bra
	bge	00118$
00135$:
	lda	(_CheckTime_timeptr_1_1 + 1)
	add	#0x05
	sta	*(_CheckTime_sloc0_1_0 + 1)
	lda	_CheckTime_timeptr_1_1
	adc	#0x00
	sta	*_CheckTime_sloc0_1_0
	ldhx	*_CheckTime_sloc0_1_0
	clra
	sta	,x
	aix	#1
	clra
	sta	,x
00118$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'asctime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_asctime_sloc0_1_0'
;sloc1                     Allocated with name '_asctime_sloc1_1_0'
;sloc2                     Allocated with name '_asctime_sloc2_1_0'
;sloc3                     Allocated with name '_asctime_sloc3_1_0'
;sloc4                     Allocated with name '_asctime_sloc4_1_0'
;sloc5                     Allocated with name '_asctime_sloc5_1_0'
;sloc6                     Allocated with name '_asctime_sloc6_1_0'
;timeptr                   Allocated with name '_asctime_timeptr_1_1'
;------------------------------------------------------------
;time.c:91: char *asctime(struct tm *timeptr) {
;	-----------------------------------------
;	 function asctime
;	-----------------------------------------
_asctime:
	sta	(_asctime_timeptr_1_1 + 1)
	stx	_asctime_timeptr_1_1
;time.c:92: CheckTime(timeptr);
	ldx	_asctime_timeptr_1_1
	lda	(_asctime_timeptr_1_1 + 1)
	jsr	_CheckTime
;time.c:96: timeptr->tm_year+1900);
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x05
	sta	*(_asctime_sloc0_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc0_1_0
	ldhx	*_asctime_sloc0_1_0
	lda	,x
	aix	#1
	sta	*_asctime_sloc0_1_0
	lda	,x
	sta	*(_asctime_sloc0_1_0 + 1)
	lda	*(_asctime_sloc0_1_0 + 1)
	add	#0x6C
	sta	*(_asctime_sloc0_1_0 + 1)
	lda	*_asctime_sloc0_1_0
	adc	#0x07
	sta	*_asctime_sloc0_1_0
;time.c:95: timeptr->tm_hour, timeptr->tm_min, timeptr->tm_sec, 
	lda	_asctime_timeptr_1_1
	ldx	(_asctime_timeptr_1_1 + 1)
	psha
	pulh
	lda	,x
	sta	*(_asctime_sloc1_1_0 + 1)
	clr	*_asctime_sloc1_1_0
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x01
	sta	*(_asctime_sloc2_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc2_1_0
	ldhx	*_asctime_sloc2_1_0
	lda	,x
	sta	*(_asctime_sloc2_1_0 + 1)
	clr	*_asctime_sloc2_1_0
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x02
	sta	*(_asctime_sloc3_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc3_1_0
	ldhx	*_asctime_sloc3_1_0
	lda	,x
	sta	*(_asctime_sloc3_1_0 + 1)
	clr	*_asctime_sloc3_1_0
;time.c:94: __day[timeptr->tm_wday], __month[timeptr->tm_mon], timeptr->tm_mday,
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_asctime_sloc4_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc4_1_0
	ldhx	*_asctime_sloc4_1_0
	lda	,x
	sta	*(_asctime_sloc4_1_0 + 1)
	clr	*_asctime_sloc4_1_0
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x04
	sta	*(_asctime_sloc5_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc5_1_0
	ldhx	*_asctime_sloc5_1_0
	lda	,x
	ldx	#0x02
	mul
	sta	*(_asctime_sloc5_1_0 + 1)
	stx	*_asctime_sloc5_1_0
	ldhx	*_asctime_sloc5_1_0
	lda	___month,x
	sta	*_asctime_sloc5_1_0
	lda	(___month + 1),x
	sta	*(_asctime_sloc5_1_0 + 1)
	lda	(_asctime_timeptr_1_1 + 1)
	add	#0x07
	sta	*(_asctime_sloc6_1_0 + 1)
	lda	_asctime_timeptr_1_1
	adc	#0x00
	sta	*_asctime_sloc6_1_0
	ldhx	*_asctime_sloc6_1_0
	lda	,x
	ldx	#0x02
	mul
	sta	*(_asctime_sloc6_1_0 + 1)
	stx	*_asctime_sloc6_1_0
	ldhx	*_asctime_sloc6_1_0
	lda	___day,x
	sta	*_asctime_sloc6_1_0
	lda	(___day + 1),x
	sta	*(_asctime_sloc6_1_0 + 1)
;time.c:93: sprintf (ascTimeBuffer, "%s %s %2d %02d:%02d:%02d %04d\n",
	lda	*(_asctime_sloc0_1_0 + 1)
	psha
	lda	*_asctime_sloc0_1_0
	psha
	lda	*(_asctime_sloc1_1_0 + 1)
	psha
	lda	*_asctime_sloc1_1_0
	psha
	lda	*(_asctime_sloc2_1_0 + 1)
	psha
	lda	*_asctime_sloc2_1_0
	psha
	lda	*(_asctime_sloc3_1_0 + 1)
	psha
	lda	*_asctime_sloc3_1_0
	psha
	lda	*(_asctime_sloc4_1_0 + 1)
	psha
	lda	*_asctime_sloc4_1_0
	psha
	lda	*(_asctime_sloc5_1_0 + 1)
	psha
	lda	*_asctime_sloc5_1_0
	psha
	lda	*(_asctime_sloc6_1_0 + 1)
	psha
	lda	*_asctime_sloc6_1_0
	psha
	ldhx	#__str_0
	pshx
	pshh
	ldhx	#_ascTimeBuffer
	pshx
	pshh
	jsr	_sprintf
	ais	#18
;time.c:97: return ascTimeBuffer;
	ldx	#>_ascTimeBuffer
	lda	#_ascTimeBuffer
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'ctime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_ctime_sloc0_1_0'
;timep                     Allocated to registers 
;------------------------------------------------------------
;time.c:100: char *ctime(time_t *timep) {
;	-----------------------------------------
;	 function ctime
;	-----------------------------------------
_ctime:
;time.c:101: return asctime(localtime(timep));
	jsr	_localtime
	jsr	_asctime
	sta	*(_ctime_sloc0_1_0 + 1)
	stx	*_ctime_sloc0_1_0
	ldx	*_ctime_sloc0_1_0
	lda	*(_ctime_sloc0_1_0 + 1)
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'localtime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_localtime_sloc0_1_0'
;timep                     Allocated to registers 
;------------------------------------------------------------
;time.c:117: struct tm *localtime(time_t *timep) {
;	-----------------------------------------
;	 function localtime
;	-----------------------------------------
_localtime:
;time.c:118: return gmtime(timep);
	jsr	_gmtime
	sta	*(_localtime_sloc0_1_0 + 1)
	stx	*_localtime_sloc0_1_0
	ldx	*_localtime_sloc0_1_0
	lda	*(_localtime_sloc0_1_0 + 1)
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'gmtime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_gmtime_sloc0_1_0'
;sloc1                     Allocated with name '_gmtime_sloc1_1_0'
;sloc2                     Allocated with name '_gmtime_sloc2_1_0'
;timep                     Allocated with name '_gmtime_timep_1_1'
;epoch                     Allocated with name '_gmtime_epoch_1_1'
;year                      Allocated with name '_gmtime_year_1_1'
;month                     Allocated to registers 
;monthLength               Allocated with name '_gmtime_monthLength_1_1'
;days                      Allocated with name '_gmtime_days_1_1'
;------------------------------------------------------------
;time.c:121: struct tm *gmtime(time_t *timep) {
;	-----------------------------------------
;	 function gmtime
;	-----------------------------------------
_gmtime:
	sta	(_gmtime_timep_1_1 + 1)
	stx	_gmtime_timep_1_1
;time.c:122: unsigned long epoch=*timep;
	lda	_gmtime_timep_1_1
	ldx	(_gmtime_timep_1_1 + 1)
	psha
	pulh
	lda	,x
	aix	#1
	sta	_gmtime_epoch_1_1
	lda	,x
	aix	#1
	sta	(_gmtime_epoch_1_1 + 1)
	lda	,x
	aix	#1
	sta	(_gmtime_epoch_1_1 + 2)
	lda	,x
	sta	(_gmtime_epoch_1_1 + 3)
;time.c:127: lastTime.tm_sec=epoch%60;
	lda	_gmtime_epoch_1_1
	sta	__modulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__modulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__modulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__modulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__modulong_PARM_2
	sta	(__modulong_PARM_2 + 1)
	sta	(__modulong_PARM_2 + 2)
	lda	#0x3C
	sta	(__modulong_PARM_2 + 3)
	jsr	__modulong
	sta	*(_gmtime_sloc0_1_0 + 3)
	stx	*(_gmtime_sloc0_1_0 + 2)
	mov	*__ret2,*(_gmtime_sloc0_1_0 + 1)
	mov	*__ret3,*_gmtime_sloc0_1_0
	lda	*(_gmtime_sloc0_1_0 + 3)
	sta	_lastTime
;time.c:128: epoch/=60; // now it is minutes
	lda	_gmtime_epoch_1_1
	sta	__divulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__divulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__divulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__divulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__divulong_PARM_2
	sta	(__divulong_PARM_2 + 1)
	sta	(__divulong_PARM_2 + 2)
	lda	#0x3C
	sta	(__divulong_PARM_2 + 3)
	jsr	__divulong
	sta	(_gmtime_epoch_1_1 + 3)
	stx	(_gmtime_epoch_1_1 + 2)
	lda	*__ret2
	sta	(_gmtime_epoch_1_1 + 1)
	lda	*__ret3
	sta	_gmtime_epoch_1_1
;time.c:129: lastTime.tm_min=epoch%60;
	lda	_gmtime_epoch_1_1
	sta	__modulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__modulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__modulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__modulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__modulong_PARM_2
	sta	(__modulong_PARM_2 + 1)
	sta	(__modulong_PARM_2 + 2)
	lda	#0x3C
	sta	(__modulong_PARM_2 + 3)
	jsr	__modulong
	sta	*(_gmtime_sloc0_1_0 + 3)
	stx	*(_gmtime_sloc0_1_0 + 2)
	mov	*__ret2,*(_gmtime_sloc0_1_0 + 1)
	mov	*__ret3,*_gmtime_sloc0_1_0
	lda	*(_gmtime_sloc0_1_0 + 3)
	sta	(_lastTime + 0x0001)
;time.c:130: epoch/=60; // now it is hours
	lda	_gmtime_epoch_1_1
	sta	__divulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__divulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__divulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__divulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__divulong_PARM_2
	sta	(__divulong_PARM_2 + 1)
	sta	(__divulong_PARM_2 + 2)
	lda	#0x3C
	sta	(__divulong_PARM_2 + 3)
	jsr	__divulong
	sta	(_gmtime_epoch_1_1 + 3)
	stx	(_gmtime_epoch_1_1 + 2)
	lda	*__ret2
	sta	(_gmtime_epoch_1_1 + 1)
	lda	*__ret3
	sta	_gmtime_epoch_1_1
;time.c:131: lastTime.tm_hour=epoch%24;
	lda	_gmtime_epoch_1_1
	sta	__modulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__modulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__modulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__modulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__modulong_PARM_2
	sta	(__modulong_PARM_2 + 1)
	sta	(__modulong_PARM_2 + 2)
	lda	#0x18
	sta	(__modulong_PARM_2 + 3)
	jsr	__modulong
	sta	*(_gmtime_sloc0_1_0 + 3)
	stx	*(_gmtime_sloc0_1_0 + 2)
	mov	*__ret2,*(_gmtime_sloc0_1_0 + 1)
	mov	*__ret3,*_gmtime_sloc0_1_0
	lda	*(_gmtime_sloc0_1_0 + 3)
	sta	(_lastTime + 0x0002)
;time.c:132: epoch/=24; // now it is days
	lda	_gmtime_epoch_1_1
	sta	__divulong_PARM_1
	lda	(_gmtime_epoch_1_1 + 1)
	sta	(__divulong_PARM_1 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	(__divulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 3)
	sta	(__divulong_PARM_1 + 3)
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__divulong_PARM_2
	sta	(__divulong_PARM_2 + 1)
	sta	(__divulong_PARM_2 + 2)
	lda	#0x18
	sta	(__divulong_PARM_2 + 3)
	jsr	__divulong
	sta	(_gmtime_epoch_1_1 + 3)
	stx	(_gmtime_epoch_1_1 + 2)
	lda	*__ret2
	sta	(_gmtime_epoch_1_1 + 1)
	lda	*__ret3
	sta	_gmtime_epoch_1_1
;time.c:133: lastTime.tm_wday=(epoch+4)%7;
	lda	(_gmtime_epoch_1_1 + 3)
	add	#0x04
	sta	(__modulong_PARM_1 + 3)
	lda	(_gmtime_epoch_1_1 + 2)
	adc	#0x00
	sta	(__modulong_PARM_1 + 2)
	lda	(_gmtime_epoch_1_1 + 1)
	adc	#0x00
	sta	(__modulong_PARM_1 + 1)
	lda	_gmtime_epoch_1_1
	adc	#0x00
	sta	__modulong_PARM_1
; Peephole 5b   - eliminated redundant clra
	clra
	sta	__modulong_PARM_2
	sta	(__modulong_PARM_2 + 1)
	sta	(__modulong_PARM_2 + 2)
	lda	#0x07
	sta	(__modulong_PARM_2 + 3)
	jsr	__modulong
	sta	*(_gmtime_sloc0_1_0 + 3)
	stx	*(_gmtime_sloc0_1_0 + 2)
	mov	*__ret2,*(_gmtime_sloc0_1_0 + 1)
	mov	*__ret3,*_gmtime_sloc0_1_0
	lda	*(_gmtime_sloc0_1_0 + 3)
	sta	(_lastTime + 0x0007)
;time.c:136: days=0;
; Peephole 5a   - eliminated redundant clra
	clra
	sta	_gmtime_days_1_1
	sta	(_gmtime_days_1_1 + 1)
	sta	(_gmtime_days_1_1 + 2)
	sta	(_gmtime_days_1_1 + 3)
;time.c:137: while((days += (LEAP_YEAR(year) ? 366 : 365)) <= epoch) {
	mov	#0x07,*_gmtime_sloc0_1_0
	mov	#0xB2,*(_gmtime_sloc0_1_0 + 1)
00101$:
	lda	*(_gmtime_sloc0_1_0 + 1)
	and	#0x03
	sta	*(_gmtime_sloc1_1_0 + 1)
	clr	*_gmtime_sloc1_1_0
	ldhx	*_gmtime_sloc1_1_0
	cphx	#0x0000
; Peephole 2c	- eliminated jmp
	bne	00119$
00132$:
	mov	#0x01,*_gmtime_sloc1_1_0
	mov	#0x6E,*(_gmtime_sloc1_1_0 + 1)
; Peephole 3	- shortened jmp to bra
	bra	00120$
00119$:
	mov	#0x01,*_gmtime_sloc1_1_0
	mov	#0x6D,*(_gmtime_sloc1_1_0 + 1)
00120$:
	mov	*(_gmtime_sloc1_1_0 + 1),*(_gmtime_sloc2_1_0 + 3)
	mov	*_gmtime_sloc1_1_0,*(_gmtime_sloc2_1_0 + 2)
	lda	*_gmtime_sloc1_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_gmtime_sloc2_1_0 + 1)
	sta	*_gmtime_sloc2_1_0
	lda	(_gmtime_days_1_1 + 3)
	add	*(_gmtime_sloc2_1_0 + 3)
	sta	*(_gmtime_sloc2_1_0 + 3)
	lda	(_gmtime_days_1_1 + 2)
	adc	*(_gmtime_sloc2_1_0 + 2)
	sta	*(_gmtime_sloc2_1_0 + 2)
	lda	(_gmtime_days_1_1 + 1)
	adc	*(_gmtime_sloc2_1_0 + 1)
	sta	*(_gmtime_sloc2_1_0 + 1)
	lda	_gmtime_days_1_1
	adc	*_gmtime_sloc2_1_0
	sta	*_gmtime_sloc2_1_0
	lda	*_gmtime_sloc2_1_0
	sta	_gmtime_days_1_1
	lda	*(_gmtime_sloc2_1_0 + 1)
	sta	(_gmtime_days_1_1 + 1)
	lda	*(_gmtime_sloc2_1_0 + 2)
	sta	(_gmtime_days_1_1 + 2)
	lda	*(_gmtime_sloc2_1_0 + 3)
	sta	(_gmtime_days_1_1 + 3)
	lda	(_gmtime_epoch_1_1 + 3)
	sub	*(_gmtime_sloc2_1_0 + 3)
	lda	(_gmtime_epoch_1_1 + 2)
	sbc	*(_gmtime_sloc2_1_0 + 2)
	lda	(_gmtime_epoch_1_1 + 1)
	sbc	*(_gmtime_sloc2_1_0 + 1)
	lda	_gmtime_epoch_1_1
	sbc	*_gmtime_sloc2_1_0
	bcs	00133$
	clra
	bra	00134$
00133$:
	lda	#0x01
00134$:
	sta	*_gmtime_sloc2_1_0
	lda	*_gmtime_sloc0_1_0
	sta	_gmtime_year_1_1
	lda	*(_gmtime_sloc0_1_0 + 1)
	sta	(_gmtime_year_1_1 + 1)
	tst	*_gmtime_sloc2_1_0
; Peephole 2c	- eliminated jmp
	bne	00103$
00135$:
;time.c:138: year++;
	ldhx	*_gmtime_sloc0_1_0
	aix	#1
	sthx	*_gmtime_sloc0_1_0
	jmp	00101$
00103$:
;time.c:140: lastTime.tm_year=year-1900;
	lda	*(_gmtime_sloc0_1_0 + 1)
	sub	#0x6C
	sta	*(_gmtime_sloc2_1_0 + 1)
	lda	*_gmtime_sloc0_1_0
	sbc	#0x07
	sta	*_gmtime_sloc2_1_0
	lda	*_gmtime_sloc2_1_0
	sta	(_lastTime + 0x0005)
	lda	*(_gmtime_sloc2_1_0 + 1)
	sta	((_lastTime + 0x0005) + 1)
;time.c:142: days -= LEAP_YEAR(year) ? 366 : 365;
	lda	*(_gmtime_sloc0_1_0 + 1)
	and	#0x03
	sta	*(_gmtime_sloc2_1_0 + 1)
	clr	*_gmtime_sloc2_1_0
	ldhx	*_gmtime_sloc2_1_0
	cphx	#0x0000
; Peephole 2c	- eliminated jmp
	bne	00121$
00136$:
	mov	#0x01,*_gmtime_sloc2_1_0
	mov	#0x6E,*(_gmtime_sloc2_1_0 + 1)
; Peephole 3	- shortened jmp to bra
	bra	00122$
00121$:
	mov	#0x01,*_gmtime_sloc2_1_0
	mov	#0x6D,*(_gmtime_sloc2_1_0 + 1)
00122$:
	mov	*(_gmtime_sloc2_1_0 + 1),*(_gmtime_sloc2_1_0 + 3)
	mov	*_gmtime_sloc2_1_0,*(_gmtime_sloc2_1_0 + 2)
	lda	*_gmtime_sloc2_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_gmtime_sloc2_1_0 + 1)
	sta	*_gmtime_sloc2_1_0
	lda	(_gmtime_days_1_1 + 3)
	sub	*(_gmtime_sloc2_1_0 + 3)
	sta	(_gmtime_days_1_1 + 3)
	lda	(_gmtime_days_1_1 + 2)
	sbc	*(_gmtime_sloc2_1_0 + 2)
	sta	(_gmtime_days_1_1 + 2)
	lda	(_gmtime_days_1_1 + 1)
	sbc	*(_gmtime_sloc2_1_0 + 1)
	sta	(_gmtime_days_1_1 + 1)
	lda	_gmtime_days_1_1
	sbc	*_gmtime_sloc2_1_0
	sta	_gmtime_days_1_1
;time.c:143: epoch -= days; // now it is days in this year, starting at 0
	lda	(_gmtime_epoch_1_1 + 3)
	sub	(_gmtime_days_1_1 + 3)
	sta	(_gmtime_epoch_1_1 + 3)
	lda	(_gmtime_epoch_1_1 + 2)
	sbc	(_gmtime_days_1_1 + 2)
	sta	(_gmtime_epoch_1_1 + 2)
	lda	(_gmtime_epoch_1_1 + 1)
	sbc	(_gmtime_days_1_1 + 1)
	sta	(_gmtime_epoch_1_1 + 1)
	lda	_gmtime_epoch_1_1
	sbc	_gmtime_days_1_1
	sta	_gmtime_epoch_1_1
;time.c:144: lastTime.tm_yday=epoch;
	lda	(_gmtime_epoch_1_1 + 3)
	sta	*(_gmtime_sloc2_1_0 + 1)
	lda	(_gmtime_epoch_1_1 + 2)
	sta	*_gmtime_sloc2_1_0
	lda	*_gmtime_sloc2_1_0
	sta	(_lastTime + 0x0008)
	lda	*(_gmtime_sloc2_1_0 + 1)
	sta	((_lastTime + 0x0008) + 1)
;time.c:149: for (month=0; month<12; month++) {
	lda	(_gmtime_year_1_1 + 1)
	and	#0x03
	sta	*(_gmtime_sloc2_1_0 + 1)
	clr	*_gmtime_sloc2_1_0
	ldhx	*_gmtime_sloc2_1_0
	cphx	#0x0000
	beq	00138$
	clra
	bra	00137$
00138$:
	lda	#0x01
00137$:
	sta	*_gmtime_sloc2_1_0
	clr	*_gmtime_sloc1_1_0
00113$:
	lda	*_gmtime_sloc1_1_0
	cmp	#0x0C
	bcs	00139$
	jmp	00116$
00139$:
;time.c:150: if (month==1) { // februari
	lda	*_gmtime_sloc1_1_0
	cmp	#0x01
; Peephole 2c	- eliminated jmp
	bne	00108$
00140$:
;time.c:151: if (LEAP_YEAR(year)) {
	tst	*_gmtime_sloc2_1_0
; Peephole 2d	- eliminated jmp
	beq	00105$
00141$:
;time.c:152: monthLength=29;
	lda	#0x1D
	sta	_gmtime_monthLength_1_1
; Peephole 3	- shortened jmp to bra
	bra	00109$
00105$:
;time.c:154: monthLength=28;
	lda	#0x1C
	sta	_gmtime_monthLength_1_1
; Peephole 3	- shortened jmp to bra
	bra	00109$
00108$:
;time.c:157: monthLength = monthDays[month];
	ldx	*_gmtime_sloc1_1_0
	clrh
	lda	_monthDays,x
	sta	_gmtime_monthLength_1_1
00109$:
;time.c:160: if (epoch>=monthLength) {
	lda	_gmtime_monthLength_1_1
	sta	*(_gmtime_sloc0_1_0 + 3)
	clr	*(_gmtime_sloc0_1_0 + 2)
	clr	*(_gmtime_sloc0_1_0 + 1)
	clr	*_gmtime_sloc0_1_0
	lda	(_gmtime_epoch_1_1 + 3)
	sub	*(_gmtime_sloc0_1_0 + 3)
	lda	(_gmtime_epoch_1_1 + 2)
	sbc	*(_gmtime_sloc0_1_0 + 2)
	lda	(_gmtime_epoch_1_1 + 1)
	sbc	*(_gmtime_sloc0_1_0 + 1)
	lda	_gmtime_epoch_1_1
	sbc	*_gmtime_sloc0_1_0
; Peephole 2b	- eliminated jmp
	bcs	00116$
00142$:
;time.c:161: epoch-=monthLength;
	lda	_gmtime_monthLength_1_1
	sta	*(_gmtime_sloc0_1_0 + 3)
	clr	*(_gmtime_sloc0_1_0 + 2)
	clr	*(_gmtime_sloc0_1_0 + 1)
	clr	*_gmtime_sloc0_1_0
	lda	(_gmtime_epoch_1_1 + 3)
	sub	*(_gmtime_sloc0_1_0 + 3)
	sta	(_gmtime_epoch_1_1 + 3)
	lda	(_gmtime_epoch_1_1 + 2)
	sbc	*(_gmtime_sloc0_1_0 + 2)
	sta	(_gmtime_epoch_1_1 + 2)
	lda	(_gmtime_epoch_1_1 + 1)
	sbc	*(_gmtime_sloc0_1_0 + 1)
	sta	(_gmtime_epoch_1_1 + 1)
	lda	_gmtime_epoch_1_1
	sbc	*_gmtime_sloc0_1_0
	sta	_gmtime_epoch_1_1
;time.c:149: for (month=0; month<12; month++) {
	inc	*_gmtime_sloc1_1_0
	jmp	00113$
00116$:
;time.c:166: lastTime.tm_mon=month;
	lda	*_gmtime_sloc1_1_0
	sta	(_lastTime + 0x0004)
;time.c:167: lastTime.tm_mday=epoch+1;
	lda	(_gmtime_epoch_1_1 + 3)
	inca
	sta	(_lastTime + 0x0003)
;time.c:169: lastTime.tm_isdst=0;
	clra
	sta	(_lastTime + 0x000a)
;time.c:171: return &lastTime;
	ldx	#>_lastTime
	lda	#_lastTime
00117$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'mktime'
;------------------------------------------------------------
;sloc0                     Allocated with name '_mktime_sloc0_1_0'
;sloc1                     Allocated with name '_mktime_sloc1_1_0'
;sloc2                     Allocated with name '_mktime_sloc2_1_0'
;sloc3                     Allocated with name '_mktime_sloc3_1_0'
;sloc4                     Allocated with name '_mktime_sloc4_1_0'
;timeptr                   Allocated with name '_mktime_timeptr_1_1'
;year                      Allocated with name '_mktime_year_1_1'
;month                     Allocated with name '_mktime_month_1_1'
;i                         Allocated to registers 
;seconds                   Allocated with name '_mktime_seconds_1_1'
;------------------------------------------------------------
;time.c:175: time_t mktime(struct tm *timeptr) {
;	-----------------------------------------
;	 function mktime
;	-----------------------------------------
_mktime:
	sta	(_mktime_timeptr_1_1 + 1)
	stx	_mktime_timeptr_1_1
;time.c:176: int year=timeptr->tm_year+1900, month=timeptr->tm_mon, i;
	lda	(_mktime_timeptr_1_1 + 1)
	add	#0x05
	sta	*(_mktime_sloc0_1_0 + 1)
	lda	_mktime_timeptr_1_1
	adc	#0x00
	sta	*_mktime_sloc0_1_0
	ldhx	*_mktime_sloc0_1_0
	lda	,x
	aix	#1
	sta	*_mktime_sloc0_1_0
	lda	,x
	sta	*(_mktime_sloc0_1_0 + 1)
	lda	*(_mktime_sloc0_1_0 + 1)
	add	#0x6C
	sta	(_mktime_year_1_1 + 1)
	lda	*_mktime_sloc0_1_0
	adc	#0x07
	sta	_mktime_year_1_1
	lda	(_mktime_timeptr_1_1 + 1)
	add	#0x04
	sta	*(_mktime_sloc0_1_0 + 1)
	lda	_mktime_timeptr_1_1
	adc	#0x00
	sta	*_mktime_sloc0_1_0
	ldhx	*_mktime_sloc0_1_0
	lda	,x
	sta	(_mktime_month_1_1 + 1)
	clrx
	stx	_mktime_month_1_1
;time.c:179: CheckTime(timeptr);
	ldx	_mktime_timeptr_1_1
	lda	(_mktime_timeptr_1_1 + 1)
	jsr	_CheckTime
;time.c:182: seconds= (year-1970)*(60*60*24L*365);
	lda	(_mktime_year_1_1 + 1)
	sub	#0xB2
	sta	*(_mktime_sloc0_1_0 + 1)
	lda	_mktime_year_1_1
	sbc	#0x07
	sta	*_mktime_sloc0_1_0
	lda	*(_mktime_sloc0_1_0 + 1)
	sta	(__mullong_PARM_1 + 3)
	lda	*_mktime_sloc0_1_0
	sta	(__mullong_PARM_1 + 2)
	lda	*_mktime_sloc0_1_0
	rola	
	clra	
	sbc	#0x00
	sta	(__mullong_PARM_1 + 1)
	sta	__mullong_PARM_1
	lda	#0x01
	sta	__mullong_PARM_2
	lda	#0xE1
	sta	(__mullong_PARM_2 + 1)
	lda	#0x33
	sta	(__mullong_PARM_2 + 2)
	lda	#0x80
	sta	(__mullong_PARM_2 + 3)
	jsr	__mullong
	sta	(_mktime_seconds_1_1 + 3)
	stx	(_mktime_seconds_1_1 + 2)
	lda	*__ret2
	sta	(_mktime_seconds_1_1 + 1)
	lda	*__ret3
	sta	_mktime_seconds_1_1
;time.c:185: for (i=1970; i<year; i++) {
	lda	_mktime_seconds_1_1
	sta	*_mktime_sloc1_1_0
	lda	(_mktime_seconds_1_1 + 1)
	sta	*(_mktime_sloc1_1_0 + 1)
	lda	(_mktime_seconds_1_1 + 2)
	sta	*(_mktime_sloc1_1_0 + 2)
	lda	(_mktime_seconds_1_1 + 3)
	sta	*(_mktime_sloc1_1_0 + 3)
	mov	#0x07,*_mktime_sloc0_1_0
	mov	#0xB2,*(_mktime_sloc0_1_0 + 1)
00107$:
	lda	*(_mktime_sloc0_1_0 + 1)
	sub	(_mktime_year_1_1 + 1)
	lda	*_mktime_sloc0_1_0
	sbc	_mktime_year_1_1
	blt	00124$
	clra
	bra	00125$
00124$:
	lda	#0x01
00125$:
	sta	*_mktime_sloc2_1_0
	lda	*_mktime_sloc1_1_0
	sta	_mktime_seconds_1_1
	lda	*(_mktime_sloc1_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	*(_mktime_sloc1_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	*(_mktime_sloc1_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	tst	*_mktime_sloc2_1_0
; Peephole 2d	- eliminated jmp
	beq	00123$
00126$:
;time.c:186: if (LEAP_YEAR(i)) {
	clra
	sta	__modsint_PARM_2
	lda	#0x04
	sta	(__modsint_PARM_2 + 1)
	ldx	*_mktime_sloc0_1_0
	lda	*(_mktime_sloc0_1_0 + 1)
	jsr	__modsint
	sta	*(_mktime_sloc3_1_0 + 1)
	stx	*_mktime_sloc3_1_0
	ldhx	*_mktime_sloc3_1_0
	cphx	#0x0000
; Peephole 2c	- eliminated jmp
	bne	00109$
00127$:
;time.c:187: seconds+= 60*60*24L;
	lda	*(_mktime_sloc1_1_0 + 3)
	add	#0x80
	sta	*(_mktime_sloc1_1_0 + 3)
	lda	*(_mktime_sloc1_1_0 + 2)
	adc	#0x51
	sta	*(_mktime_sloc1_1_0 + 2)
	lda	*(_mktime_sloc1_1_0 + 1)
	adc	#0x01
	sta	*(_mktime_sloc1_1_0 + 1)
	lda	*_mktime_sloc1_1_0
	adc	#0x00
	sta	*_mktime_sloc1_1_0
00109$:
;time.c:185: for (i=1970; i<year; i++) {
	ldhx	*_mktime_sloc0_1_0
	aix	#1
	sthx	*_mktime_sloc0_1_0
	jmp	00107$
;time.c:192: for (i=0; i<month; i++) {
00123$:
	clra
	sta	__modsint_PARM_2
	lda	#0x04
	sta	(__modsint_PARM_2 + 1)
	ldx	_mktime_year_1_1
	lda	(_mktime_year_1_1 + 1)
	jsr	__modsint
	sta	*(_mktime_sloc3_1_0 + 1)
	stx	*_mktime_sloc3_1_0
	ldhx	*_mktime_sloc3_1_0
	cphx	#0x0000
	beq	00129$
	clra
	bra	00128$
00129$:
	lda	#0x01
00128$:
	sta	*_mktime_sloc3_1_0
	clr	*_mktime_sloc1_1_0
	clr	*(_mktime_sloc1_1_0 + 1)
00111$:
	lda	*(_mktime_sloc1_1_0 + 1)
	sub	(_mktime_month_1_1 + 1)
	lda	*_mktime_sloc1_1_0
	sbc	_mktime_month_1_1
	blt	00130$
	jmp	00114$
00130$:
;time.c:193: if (i==1 && LEAP_YEAR(year)) { 
	ldhx	*_mktime_sloc1_1_0
	cphx	#0x0001
; Peephole 2c	- eliminated jmp
	bne	00104$
00131$:
	tst	*_mktime_sloc3_1_0
; Peephole 2d	- eliminated jmp
	beq	00104$
00132$:
;time.c:194: seconds+= 60*60*24L*29;
	lda	(_mktime_seconds_1_1 + 3)
	add	#0x80
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	#0x3B
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	#0x26
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	#0x00
	sta	_mktime_seconds_1_1
; Peephole 3	- shortened jmp to bra
	bra	00113$
00104$:
;time.c:196: seconds+= 60*60*24L*monthDays[i];
	ldhx	*_mktime_sloc1_1_0
	lda	_monthDays,x
	sta	(__mullong_PARM_1 + 3)
	rola	
	clra	
	sbc	#0x00
	sta	(__mullong_PARM_1 + 2)
	sta	(__mullong_PARM_1 + 1)
	sta	__mullong_PARM_1
	clra
	sta	__mullong_PARM_2
	lda	#0x01
	sta	(__mullong_PARM_2 + 1)
	lda	#0x51
	sta	(__mullong_PARM_2 + 2)
	lda	#0x80
	sta	(__mullong_PARM_2 + 3)
	jsr	__mullong
	sta	*(_mktime_sloc4_1_0 + 3)
	stx	*(_mktime_sloc4_1_0 + 2)
	mov	*__ret2,*(_mktime_sloc4_1_0 + 1)
	mov	*__ret3,*_mktime_sloc4_1_0
	lda	(_mktime_seconds_1_1 + 3)
	add	*(_mktime_sloc4_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	*(_mktime_sloc4_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	*(_mktime_sloc4_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	*_mktime_sloc4_1_0
	sta	_mktime_seconds_1_1
00113$:
;time.c:192: for (i=0; i<month; i++) {
	ldhx	*_mktime_sloc1_1_0
	aix	#1
	sthx	*_mktime_sloc1_1_0
	jmp	00111$
00114$:
;time.c:200: seconds+= (timeptr->tm_mday-1)*60*60*24L;
	lda	(_mktime_timeptr_1_1 + 1)
	add	#0x03
	sta	*(_mktime_sloc4_1_0 + 1)
	lda	_mktime_timeptr_1_1
	adc	#0x00
	sta	*_mktime_sloc4_1_0
	ldhx	*_mktime_sloc4_1_0
	lda	,x
	sta	*(_mktime_sloc4_1_0 + 1)
	clr	*_mktime_sloc4_1_0
	lda	*(_mktime_sloc4_1_0 + 1)
	sub	#0x01
	sta	*(_mktime_sloc4_1_0 + 1)
	lda	*_mktime_sloc4_1_0
	sbc	#0x00
	sta	*_mktime_sloc4_1_0
	lda	*(_mktime_sloc4_1_0 + 1)
	sta	(__mullong_PARM_1 + 3)
	lda	*_mktime_sloc4_1_0
	sta	(__mullong_PARM_1 + 2)
	lda	*_mktime_sloc4_1_0
	rola	
	clra	
	sbc	#0x00
	sta	(__mullong_PARM_1 + 1)
	sta	__mullong_PARM_1
	clra
	sta	__mullong_PARM_2
	lda	#0x01
	sta	(__mullong_PARM_2 + 1)
	lda	#0x51
	sta	(__mullong_PARM_2 + 2)
	lda	#0x80
	sta	(__mullong_PARM_2 + 3)
	jsr	__mullong
	sta	*(_mktime_sloc4_1_0 + 3)
	stx	*(_mktime_sloc4_1_0 + 2)
	mov	*__ret2,*(_mktime_sloc4_1_0 + 1)
	mov	*__ret3,*_mktime_sloc4_1_0
	lda	(_mktime_seconds_1_1 + 3)
	add	*(_mktime_sloc4_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	*(_mktime_sloc4_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	*(_mktime_sloc4_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	*_mktime_sloc4_1_0
	sta	_mktime_seconds_1_1
;time.c:201: seconds+= timeptr->tm_hour*60*60;
	lda	(_mktime_timeptr_1_1 + 1)
	add	#0x02
	sta	*(_mktime_sloc4_1_0 + 1)
	lda	_mktime_timeptr_1_1
	adc	#0x00
	sta	*_mktime_sloc4_1_0
	ldhx	*_mktime_sloc4_1_0
	lda	,x
	sta	*(_mktime_sloc4_1_0 + 1)
	clr	*_mktime_sloc4_1_0
	lda	#0x0E
	sta	__mulint_PARM_2
	lda	#0x10
	sta	(__mulint_PARM_2 + 1)
	ldx	*_mktime_sloc4_1_0
	lda	*(_mktime_sloc4_1_0 + 1)
	jsr	__mulint
	sta	*(_mktime_sloc4_1_0 + 1)
	stx	*_mktime_sloc4_1_0
	mov	*(_mktime_sloc4_1_0 + 1),*(_mktime_sloc4_1_0 + 3)
	mov	*_mktime_sloc4_1_0,*(_mktime_sloc4_1_0 + 2)
	lda	*_mktime_sloc4_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_mktime_sloc4_1_0 + 1)
	sta	*_mktime_sloc4_1_0
	lda	(_mktime_seconds_1_1 + 3)
	add	*(_mktime_sloc4_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	*(_mktime_sloc4_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	*(_mktime_sloc4_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	*_mktime_sloc4_1_0
	sta	_mktime_seconds_1_1
;time.c:202: seconds+= timeptr->tm_min*60;
	lda	(_mktime_timeptr_1_1 + 1)
	add	#0x01
	sta	*(_mktime_sloc4_1_0 + 1)
	lda	_mktime_timeptr_1_1
	adc	#0x00
	sta	*_mktime_sloc4_1_0
	ldhx	*_mktime_sloc4_1_0
	lda	,x
	ldx	#0x3C
	mul
	sta	*(_mktime_sloc4_1_0 + 1)
	stx	*_mktime_sloc4_1_0
	mov	*(_mktime_sloc4_1_0 + 1),*(_mktime_sloc4_1_0 + 3)
	mov	*_mktime_sloc4_1_0,*(_mktime_sloc4_1_0 + 2)
	lda	*_mktime_sloc4_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_mktime_sloc4_1_0 + 1)
	sta	*_mktime_sloc4_1_0
	lda	(_mktime_seconds_1_1 + 3)
	add	*(_mktime_sloc4_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	*(_mktime_sloc4_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	*(_mktime_sloc4_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	*_mktime_sloc4_1_0
	sta	_mktime_seconds_1_1
;time.c:203: seconds+= timeptr->tm_sec;
	lda	_mktime_timeptr_1_1
	ldx	(_mktime_timeptr_1_1 + 1)
	psha
	pulh
	lda	,x
	sta	*(_mktime_sloc4_1_0 + 1)
	clr	*_mktime_sloc4_1_0
	mov	*(_mktime_sloc4_1_0 + 1),*(_mktime_sloc4_1_0 + 3)
	mov	*_mktime_sloc4_1_0,*(_mktime_sloc4_1_0 + 2)
	lda	*_mktime_sloc4_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(_mktime_sloc4_1_0 + 1)
	sta	*_mktime_sloc4_1_0
	lda	(_mktime_seconds_1_1 + 3)
	add	*(_mktime_sloc4_1_0 + 3)
	sta	(_mktime_seconds_1_1 + 3)
	lda	(_mktime_seconds_1_1 + 2)
	adc	*(_mktime_sloc4_1_0 + 2)
	sta	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 1)
	adc	*(_mktime_sloc4_1_0 + 1)
	sta	(_mktime_seconds_1_1 + 1)
	lda	_mktime_seconds_1_1
	adc	*_mktime_sloc4_1_0
	sta	_mktime_seconds_1_1
;time.c:204: return seconds;
	lda	_mktime_seconds_1_1
	sta	*__ret3
	lda	(_mktime_seconds_1_1 + 1)
	sta	*__ret2
	ldx	(_mktime_seconds_1_1 + 2)
	lda	(_mktime_seconds_1_1 + 3)
00115$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
_monthDays:
	.db #0x1F
	.db #0x1C
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1F
	.db #0x1E
	.db #0x1F
	.db #0x1E
	.db #0x1F
___month:
	.dw _str_1
	.dw _str_2
	.dw _str_3
	.dw _str_4
	.dw _str_5
	.dw _str_6
	.dw _str_7
	.dw _str_8
	.dw _str_9
	.dw _str_10
	.dw _str_11
	.dw _str_12
___day:
	.dw _str_13
	.dw _str_14
	.dw _str_15
	.dw _str_16
	.dw _str_17
	.dw _str_18
	.dw _str_19
__str_0:
	.ascii "%s %s %2d %02d:%02d:%02d %04d"
	.db 0x0A
	.db 0x00
_str_1:
	.ascii "Jan"
	.db 0x00
_str_2:
	.ascii "Feb"
	.db 0x00
_str_3:
	.ascii "Mar"
	.db 0x00
_str_4:
	.ascii "Apr"
	.db 0x00
_str_5:
	.ascii "May"
	.db 0x00
_str_6:
	.ascii "Jun"
	.db 0x00
_str_7:
	.ascii "Jul"
	.db 0x00
_str_8:
	.ascii "Aug"
	.db 0x00
_str_9:
	.ascii "Sep"
	.db 0x00
_str_10:
	.ascii "Oct"
	.db 0x00
_str_11:
	.ascii "Nov"
	.db 0x00
_str_12:
	.ascii "Dec"
	.db 0x00
_str_13:
	.ascii "Sun"
	.db 0x00
_str_14:
	.ascii "Mon"
	.db 0x00
_str_15:
	.ascii "Tue"
	.db 0x00
_str_16:
	.ascii "Wed"
	.db 0x00
_str_17:
	.ascii "Thu"
	.db 0x00
_str_18:
	.ascii "Fri"
	.db 0x00
_str_19:
	.ascii "Sat"
	.db 0x00
	.area XINIT
