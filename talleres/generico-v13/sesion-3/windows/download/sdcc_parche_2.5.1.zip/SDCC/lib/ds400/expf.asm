;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:52:18 2005
;--------------------------------------------------------
	.module expf
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _expf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_expf_sign_1_1::
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_expf_n_1_1::
	.ds 2
_expf_g_1_1::
	.ds 4
_expf_r_1_1::
	.ds 4
_expf_y_1_1::
	.ds 4
_expf_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'expf'
;------------------------------------------------------------
;x                         Allocated to registers r2 r3 r4 r5 
;n                         Allocated with name '_expf_n_1_1'
;xn                        Allocated to registers r2 r3 r4 r5 
;g                         Allocated with name '_expf_g_1_1'
;r                         Allocated with name '_expf_r_1_1'
;z                         Allocated to registers r2 r3 r4 r5 
;y                         Allocated with name '_expf_y_1_1'
;sloc0                     Allocated with name '_expf_sloc0_1_0'
;------------------------------------------------------------
;	expf.c:324: float expf(const float x)
;	genFunction 
;	-----------------------------------------
;	 function expf
;	-----------------------------------------
_expf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	expf.c:330: if(x>=0.0)
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00127$:
;	expf.c:331: { y=x;  sign=0; }
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_y_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_expf_sign_1_1
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00102$:
;	expf.c:333: { y=-x; sign=1; }
;	genUminus 
	mov	dptr,#_expf_y_1_1
;	genUminusFloat
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	cpl	acc.7
	inc	dptr
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_expf_sign_1_1
;	genLabel 
00103$:
;	expf.c:335: if(y<EXPEPS) return 1.0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
	mov	a,#0x95
	movx	@dptr,a
	inc	dptr
	mov	a,#0xBF
	movx	@dptr,a
	inc	dptr
	mov	a,#0xD6
	movx	@dptr,a
	inc	dptr
	mov	a,#0x33
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00105$
00128$:
;	genRet 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
	mov	dpx,#0x80
	mov	b,#0x3F
	ljmp	00118$
;	genLabel 
00105$:
;	expf.c:337: if(y>BIGX)
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsgt_PARM_2
	mov	a,#0x18
	movx	@dptr,a
	inc	dptr
	mov	a,#0x72
	movx	@dptr,a
	inc	dptr
	mov	a,#0xB1
	movx	@dptr,a
	inc	dptr
	mov	a,#0x42
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsgt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00110$
00129$:
;	expf.c:339: if(sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _expf_sign_1_1,00107$
00130$:
;	expf.c:341: errno=ERANGE;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_errno
	mov	a,#0x22
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	expf.c:342: return XMAX;
;	genRet 
; Peephole 182a   used 24 bit load of dptr
	mov	dptr,#0x7FFFFF
	mov	b,#0x7F
	ljmp	00118$
;	genLabel 
00107$:
;	expf.c:346: return 0.0;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00118$
;	genLabel 
00110$:
;	expf.c:350: z=y*K1;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,#0x3B
	movx	@dptr,a
	inc	dptr
	mov	a,#0xAA
	movx	@dptr,a
	inc	dptr
	mov	a,#0xB8
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
;	expf.c:351: n=z;
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fs2sint
	mov	r6,dpl
	mov	r7,dph
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_n_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	expf.c:353: if(n<0) --n;
;	genCmpLt 
	mov	dptr,#_expf_n_1_1
;	genCmp
	inc	dptr
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00112$
00131$:
;	genMinus 
	mov	dptr,#_expf_n_1_1
	movx	a,@dptr
	add	a,#0xFF
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	mov	r1,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_n_1_1
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genLabel 
00112$:
;	expf.c:354: if(z-n>=0.5) ++n;
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 2 
	inc	dps
	mov	dptr,#_expf_n_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
	lcall	___sint2fs
	mov	r0,dpl
	mov	r1,dph
	mov	r6,dpx
	mov	r7,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
	inc	dptr
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fslt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00114$
00132$:
;	genPlus 
	mov	dptr,#_expf_n_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genLabel 
00114$:
;	expf.c:355: xn=n;
;	genCall 
;	genSend argreg = 1, size = 2 
	inc	dps
	mov	dptr,#_expf_n_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	mov	dps,#0
	lcall	___sint2fs
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	expf.c:356: g=((y-xn*C1))-xn*C2;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x31
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fssub
	mov     dps, #1
	mov     dptr, #_expf_sloc0_1_0
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,#0x83
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x5E
	movx	@dptr,a
	inc	dptr
	mov	a,#0xB9
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_g_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	expf.c:357: z=g*g;
;	genAssign 
	mov	dptr,#_expf_g_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsmul_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_expf_g_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	expf.c:358: r=P(z)*g;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,#0x08
	movx	@dptr,a
	inc	dptr
	mov	a,#0x53
	movx	@dptr,a
	inc	dptr
	mov	a,#0x88
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3B
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3E
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
	mov	dptr,#_expf_g_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsmul_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_r_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	expf.c:359: r=0.5+(r/(Q(z)-r));
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,#0x5B
	movx	@dptr,a
	inc	dptr
	mov	a,#0xBF
	movx	@dptr,a
	inc	dptr
	mov	a,#0x4C
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3D
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
	mov	dptr,#_expf_r_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fssub_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_expf_r_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsdiv
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_expf_r_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	expf.c:361: n++;
;	genPlus 
	mov	dptr,#_expf_n_1_1
	mov	dps, #1
	mov	dptr, #_ldexpf_PARM_2
	dec	dps
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	inc	dps
	inc	dptr
	movx	@dptr,a
;	expf.c:362: z=ldexpf(r, n);
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_expf_r_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_ldexpf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	expf.c:363: if(sign)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _expf_sign_1_1,00116$
00133$:
;	expf.c:364: return 1.0/z;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
	mov	dpx,#0x80
	mov	b,#0x3F
	lcall	___fsdiv
;	genRet 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00118$
00116$:
;	expf.c:366: return z;
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00118$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
