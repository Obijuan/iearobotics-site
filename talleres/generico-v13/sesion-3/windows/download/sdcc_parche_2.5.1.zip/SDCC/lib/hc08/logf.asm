;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:56:08 2005
;--------------------------------------------------------
	.module logf
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _logf
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area OSEG    (OVR)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'logf'
;------------------------------------------------------------
;x                         Allocated to stack - offset 2
;Rz                        Allocated to registers 
;f                         Allocated to stack - offset -4
;z                         Allocated to stack - offset -8
;w                         Allocated to stack - offset -12
;znum                      Allocated to stack - offset -16
;zden                      Allocated to stack - offset -20
;xn                        Allocated to stack - offset -24
;n                         Allocated to stack - offset -26
;sloc0                     Allocated to stack - offset -30
;------------------------------------------------------------
;logf.c:206: float logf(const float x) _FLOAT_FUNC_REENTRANT
;	-----------------------------------------
;	 function logf
;	-----------------------------------------
_logf:
	ais	#-30
;logf.c:216: if (x<=0.0)
	lda	33,s
	sta	___fsgt_PARM_1
	lda	34,s
	sta	(___fsgt_PARM_1 + 1)
	lda	35,s
	sta	(___fsgt_PARM_1 + 2)
	lda	36,s
	sta	(___fsgt_PARM_1 + 3)
; Peephole 5a   - eliminated redundant clra
	clra
	sta	___fsgt_PARM_2
	sta	(___fsgt_PARM_2 + 1)
	sta	(___fsgt_PARM_2 + 2)
	sta	(___fsgt_PARM_2 + 3)
	jsr	___fsgt
	tsta
; Peephole 2c	- eliminated jmp
	bne	00102$
00110$:
;logf.c:218: errno=EDOM;
	clra
	sta	_errno
	lda	#0x21
	sta	(_errno + 1)
;logf.c:219: return 0.0;
	clr	*__ret3
	clr	*__ret2
	clrx
	clra
	jmp	00106$
00102$:
;logf.c:221: f=frexpf(x, &n);
	tsx
	aix	#4
	pshh
	pula
	sta	_frexpf_PARM_2
	stx	(_frexpf_PARM_2 + 1)
	lda	33,s
	sta	_frexpf_PARM_1
	lda	34,s
	sta	(_frexpf_PARM_1 + 1)
	lda	35,s
	sta	(_frexpf_PARM_1 + 2)
	lda	36,s
	sta	(_frexpf_PARM_1 + 3)
	jsr	_frexpf
	sta	30,s
	stx	29,s
	lda	*__ret2
	sta	28,s
	lda	*__ret3
	sta	27,s
;logf.c:222: znum=f-0.5;
	lda	27,s
	sta	___fssub_PARM_1
	lda	28,s
	sta	(___fssub_PARM_1 + 1)
	lda	29,s
	sta	(___fssub_PARM_1 + 2)
	lda	30,s
	sta	(___fssub_PARM_1 + 3)
	lda	#0x3F
	sta	___fssub_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fssub_PARM_2 + 1)
	sta	(___fssub_PARM_2 + 2)
	sta	(___fssub_PARM_2 + 3)
	jsr	___fssub
	sta	18,s
	stx	17,s
	lda	*__ret2
	sta	16,s
	lda	*__ret3
	sta	15,s
;logf.c:223: if (f>C0)
	lda	27,s
	sta	___fsgt_PARM_1
	lda	28,s
	sta	(___fsgt_PARM_1 + 1)
	lda	29,s
	sta	(___fsgt_PARM_1 + 2)
	lda	30,s
	sta	(___fsgt_PARM_1 + 3)
	lda	#0x3F
	sta	___fsgt_PARM_2
	lda	#0x35
	sta	(___fsgt_PARM_2 + 1)
	lda	#0x04
	sta	(___fsgt_PARM_2 + 2)
	lda	#0xF3
	sta	(___fsgt_PARM_2 + 3)
	jsr	___fsgt
	tsta
	bne	00111$
	jmp	00104$
00111$:
;logf.c:225: znum-=0.5;
	lda	15,s
	sta	___fssub_PARM_1
	lda	16,s
	sta	(___fssub_PARM_1 + 1)
	lda	17,s
	sta	(___fssub_PARM_1 + 2)
	lda	18,s
	sta	(___fssub_PARM_1 + 3)
	lda	#0x3F
	sta	___fssub_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fssub_PARM_2 + 1)
	sta	(___fssub_PARM_2 + 2)
	sta	(___fssub_PARM_2 + 3)
	jsr	___fssub
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	15,s
	lda	2,s
	sta	16,s
	lda	3,s
	sta	17,s
	lda	4,s
	sta	18,s
;logf.c:226: zden=(f*0.5)+0.5;
	lda	27,s
	sta	___fsmul_PARM_1
	lda	28,s
	sta	(___fsmul_PARM_1 + 1)
	lda	29,s
	sta	(___fsmul_PARM_1 + 2)
	lda	30,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x3F
	sta	___fsmul_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsmul_PARM_2 + 1)
	sta	(___fsmul_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	lda	#0x3F
	sta	___fsadd_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsadd_PARM_2 + 1)
	sta	(___fsadd_PARM_2 + 2)
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	14,s
	stx	13,s
	lda	*__ret2
	sta	12,s
	lda	*__ret3
	sta	11,s
	lda	11,s
	sta	1,s
	lda	12,s
	sta	2,s
	lda	13,s
	sta	3,s
	lda	14,s
	sta	4,s
	jmp	00105$
00104$:
;logf.c:230: n--;
	lda	6,s
	sub	#0x01
	sta	6,s
	lda	5,s
	sbc	#0x00
	sta	5,s
;logf.c:231: zden=znum*0.5+0.5;
	lda	15,s
	sta	___fsmul_PARM_1
	lda	16,s
	sta	(___fsmul_PARM_1 + 1)
	lda	17,s
	sta	(___fsmul_PARM_1 + 2)
	lda	18,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x3F
	sta	___fsmul_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsmul_PARM_2 + 1)
	sta	(___fsmul_PARM_2 + 2)
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	lda	#0x3F
	sta	___fsadd_PARM_2
; Peephole 5b   - eliminated redundant clra
	clra
	sta	(___fsadd_PARM_2 + 1)
	sta	(___fsadd_PARM_2 + 2)
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	14,s
	stx	13,s
	lda	*__ret2
	sta	12,s
	lda	*__ret3
	sta	11,s
	lda	11,s
	sta	1,s
	lda	12,s
	sta	2,s
	lda	13,s
	sta	3,s
	lda	14,s
	sta	4,s
00105$:
;logf.c:233: z=znum/zden;
	lda	15,s
	sta	___fsdiv_PARM_1
	lda	16,s
	sta	(___fsdiv_PARM_1 + 1)
	lda	17,s
	sta	(___fsdiv_PARM_1 + 2)
	lda	18,s
	sta	(___fsdiv_PARM_1 + 3)
	lda	1,s
	sta	___fsdiv_PARM_2
	lda	2,s
	sta	(___fsdiv_PARM_2 + 1)
	lda	3,s
	sta	(___fsdiv_PARM_2 + 2)
	lda	4,s
	sta	(___fsdiv_PARM_2 + 3)
	jsr	___fsdiv
	sta	26,s
	stx	25,s
	lda	*__ret2
	sta	24,s
	lda	*__ret3
	sta	23,s
;logf.c:234: w=z*z;
	lda	23,s
	sta	___fsmul_PARM_1
	lda	24,s
	sta	(___fsmul_PARM_1 + 1)
	lda	25,s
	sta	(___fsmul_PARM_1 + 2)
	lda	26,s
	sta	(___fsmul_PARM_1 + 3)
	lda	23,s
	sta	___fsmul_PARM_2
	lda	24,s
	sta	(___fsmul_PARM_2 + 1)
	lda	25,s
	sta	(___fsmul_PARM_2 + 2)
	lda	26,s
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	22,s
	stx	21,s
	lda	*__ret2
	sta	20,s
	lda	*__ret3
	sta	19,s
;logf.c:236: Rz=z+z*(w*A(w)/B(w));
	lda	19,s
	sta	___fsmul_PARM_1
	lda	20,s
	sta	(___fsmul_PARM_1 + 1)
	lda	21,s
	sta	(___fsmul_PARM_1 + 2)
	lda	22,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0xBF
	sta	___fsmul_PARM_2
	lda	#0x0D
	sta	(___fsmul_PARM_2 + 1)
	lda	#0x7E
	sta	(___fsmul_PARM_2 + 2)
	lda	#0x3D
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsdiv_PARM_1 + 3)
	stx	(___fsdiv_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsdiv_PARM_1 + 1)
	lda	*__ret3
	sta	___fsdiv_PARM_1
	lda	19,s
	sta	___fsadd_PARM_1
	lda	20,s
	sta	(___fsadd_PARM_1 + 1)
	lda	21,s
	sta	(___fsadd_PARM_1 + 2)
	lda	22,s
	sta	(___fsadd_PARM_1 + 3)
	lda	#0xC0
	sta	___fsadd_PARM_2
	lda	#0xD4
	sta	(___fsadd_PARM_2 + 1)
	lda	#0x3F
	sta	(___fsadd_PARM_2 + 2)
	lda	#0x3A
	sta	(___fsadd_PARM_2 + 3)
	jsr	___fsadd
	sta	(___fsdiv_PARM_2 + 3)
	stx	(___fsdiv_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsdiv_PARM_2 + 1)
	lda	*__ret3
	sta	___fsdiv_PARM_2
	jsr	___fsdiv
	sta	(___fsmul_PARM_2 + 3)
	stx	(___fsmul_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsmul_PARM_2 + 1)
	lda	*__ret3
	sta	___fsmul_PARM_2
	lda	23,s
	sta	___fsmul_PARM_1
	lda	24,s
	sta	(___fsmul_PARM_1 + 1)
	lda	25,s
	sta	(___fsmul_PARM_1 + 2)
	lda	26,s
	sta	(___fsmul_PARM_1 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
	lda	23,s
	sta	___fsadd_PARM_1
	lda	24,s
	sta	(___fsadd_PARM_1 + 1)
	lda	25,s
	sta	(___fsadd_PARM_1 + 2)
	lda	26,s
	sta	(___fsadd_PARM_1 + 3)
	jsr	___fsadd
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
;logf.c:237: xn=n;
	ldx	5,s
	lda	6,s
	jsr	___sint2fs
	sta	10,s
	stx	9,s
	lda	*__ret2
	sta	8,s
	lda	*__ret3
	sta	7,s
;logf.c:238: return ((xn*C2+Rz)+xn*C1);
	lda	7,s
	sta	___fsmul_PARM_1
	lda	8,s
	sta	(___fsmul_PARM_1 + 1)
	lda	9,s
	sta	(___fsmul_PARM_1 + 2)
	lda	10,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0xB9
	sta	___fsmul_PARM_2
	lda	#0x5E
	sta	(___fsmul_PARM_2 + 1)
	lda	#0x80
	sta	(___fsmul_PARM_2 + 2)
	lda	#0x83
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	jsr	___fsadd
	sta	(___fsadd_PARM_1 + 3)
	stx	(___fsadd_PARM_1 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_1 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_1
	lda	7,s
	sta	___fsmul_PARM_1
	lda	8,s
	sta	(___fsmul_PARM_1 + 1)
	lda	9,s
	sta	(___fsmul_PARM_1 + 2)
	lda	10,s
	sta	(___fsmul_PARM_1 + 3)
	lda	#0x3F
	sta	___fsmul_PARM_2
	lda	#0x31
	sta	(___fsmul_PARM_2 + 1)
	lda	#0x80
	sta	(___fsmul_PARM_2 + 2)
	clra
	sta	(___fsmul_PARM_2 + 3)
	jsr	___fsmul
	sta	(___fsadd_PARM_2 + 3)
	stx	(___fsadd_PARM_2 + 2)
	lda	*__ret2
	sta	(___fsadd_PARM_2 + 1)
	lda	*__ret3
	sta	___fsadd_PARM_2
	jsr	___fsadd
	sta	4,s
	stx	3,s
	lda	*__ret2
	sta	2,s
	lda	*__ret3
	sta	1,s
	lda	1,s
	sta	*__ret3
	lda	2,s
	sta	*__ret2
	ldx	3,s
	lda	4,s
00106$:
	ais	#30
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
	.area XINIT
