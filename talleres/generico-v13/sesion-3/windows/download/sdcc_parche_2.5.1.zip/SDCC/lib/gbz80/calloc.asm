;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:54:12 2005
;--------------------------------------------------------
	.module calloc
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _calloc
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;calloc.c:53: void xdata * calloc (size_t nmemb, size_t size)
;	genLabel
;	genFunction
;	---------------------------------
; Function calloc
; ---------------------------------
_calloc_start::
_calloc:
	lda	sp,-2(sp)
;calloc.c:57: ptr = malloc(nmemb * size);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
;	AOP_STK for 
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	__mulint_rrx_s
;	AOP_STK for _calloc__1_0
	lda	hl,5(sp)
	ld	(hl),d
	dec	hl
	ld	(hl),e
	lda	sp,4(sp)
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 0 deSending: 0
;	AOP_STK for _calloc__1_0
	lda	hl,0(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genCall
	call	_malloc
	ld	b,d
	ld	c,e
	lda	sp,2(sp)
;	genAssign
;	(registers are the same)
;calloc.c:58: if (ptr)
;	genIfx
	ld	a,c
	or	a,b
	jp	z,00102$
;calloc.c:60: memset(ptr, 0, nmemb * size);
;	genIpush
; _saveRegsForCall: sendSetSize: 0 deInUse: 0 bcInUse: 1 deSending: 0
	push	bc
;	AOP_STK for _calloc__1_0
	lda	hl,2(sp)
	ld	a,(hl+)
	ld	h,(hl)
	ld	l,a
	push	hl
;	genIpush
	ld	a,#0x00
	push	af
	inc	sp
;	genIpush
	push	bc
;	genCall
	call	_memset
	lda	sp,5(sp)
	pop	bc
;	genLabel
00102$:
;calloc.c:62: return ptr;
;	genRet
; Dump of IC_LEFT: type AOP_REG size 2
;	 reg = bc
	ld	e,c
	ld	d,b
;	genLabel
00103$:
;	genEndFunction
	lda	sp,2(sp)
	ret
_calloc_end::
	.area _CODE
