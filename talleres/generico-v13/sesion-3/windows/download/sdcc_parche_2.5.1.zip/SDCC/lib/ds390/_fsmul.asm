;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:23 2005
;--------------------------------------------------------
	.module _fsmul
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsmul_PARM_2
	.globl ___fsmul
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
___fsmul_PARM_2::
	.ds 4
___fsmul_fl1_1_1::
	.ds 4
___fsmul_fl2_1_1::
	.ds 4
___fsmul_result_1_1::
	.ds 4
___fsmul_exp_1_1::
	.ds 2
___fsmul_sign_1_1::
	.ds 1
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsmul'
;------------------------------------------------------------
;a2                        Allocated with name '___fsmul_PARM_2'
;a1                        Allocated to registers r2 r3 r4 r5 
;fl1                       Allocated with name '___fsmul_fl1_1_1'
;fl2                       Allocated with name '___fsmul_fl2_1_1'
;result                    Allocated with name '___fsmul_result_1_1'
;exp                       Allocated with name '___fsmul_exp_1_1'
;sign                      Allocated with name '___fsmul_sign_1_1'
;------------------------------------------------------------
;	_fsmul.c:213: float __fsmul (float a1, float a2) {
;	genFunction 
;	-----------------------------------------
;	 function __fsmul
;	-----------------------------------------
___fsmul:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_fsmul.c:219: fl1.f = a1;
;	genPointerSet 
	mov	dptr,#___fsmul_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:220: fl2.f = a2;
;	genPointerSet 
	mov	dptr,#___fsmul_fl2_1_1
	mov     dps, #1
	mov     dptr, #___fsmul_PARM_2
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
;	_fsmul.c:222: if (!fl1.l || !fl2.l)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00101$
00114$:
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00115$:
;	genLabel 
00101$:
;	_fsmul.c:223: return (0);
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00107$
;	genLabel 
00102$:
;	_fsmul.c:226: sign = SIGN (fl1.l) ^ SIGN (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r5,a
	rl	a
	anl	a,#1
	mov	r2,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r6,a
	rl	a
	anl	a,#1
	mov	r3,a
;	genXor 
	mov	dptr,#___fsmul_sign_1_1
	mov	a,r2
	xrl	a,r3
	movx	@dptr,a
;	_fsmul.c:227: exp = EXP (fl1.l) - EXCESS;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar3,r5
	mov	a,r6
	mov	c,acc.7
	xch	a,r3
	rlc	a
	xch	a,r3
	rlc	a
	xch	a,r3
	anl	a,#0x01
	mov	r4,a
	mov	r5,#0
	mov	r6,#0
;	genAnd 
	mov	r4,#0
	mov	r5,#0
	mov	r6,#0
;	genMinus 
	mov	a,r3
	add	a,#0x82
	mov	r3,a
	mov	a,r4
	addc	a,#0xFF
	mov	r4,a
	mov	a,r5
	addc	a,#0xFF
	mov	r5,a
	mov	a,r6
	addc	a,#0xFF
	mov	r6,a
;	genCast 
	mov	dptr,#___fsmul_exp_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	_fsmul.c:228: exp += EXP (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	inc	dptr
	mov	r5,a
	movx	a,@dptr
	mov	r6,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar3,r5
	mov	a,r6
	mov	c,acc.7
	xch	a,r3
	rlc	a
	xch	a,r3
	rlc	a
	xch	a,r3
	anl	a,#0x01
	mov	r4,a
	mov	r5,#0
	mov	r6,#0
;	genAnd 
	mov	r4,#0
	mov	r5,#0
	mov	r6,#0
;	genCast 
	mov	dptr,#___fsmul_exp_1_1
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r1,a
	mov	r2,a
;	genPlus 
	mov	a,r3
	add	a,r7
	mov	r3,a
	mov	a,r4
	addc	a,r0
	mov	r4,a
	mov	a,r5
	addc	a,r1
	mov	r5,a
	mov	a,r6
	addc	a,r2
	mov	r6,a
;	genCast 
	mov	dptr,#___fsmul_exp_1_1
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	_fsmul.c:230: fl1.l = MANT (fl1.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	anl	ar4,#0x7F
	mov	r5,#0
;	genOr 
	orl	ar4,#0x80
;	genPointerSet 
	mov	dptr,#___fsmul_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:231: fl2.l = MANT (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	anl	ar4,#0x7F
	mov	r5,#0
;	genOr 
	orl	ar4,#0x80
;	genPointerSet 
	mov	dptr,#___fsmul_fl2_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:234: result = (fl1.l >> 8) * (fl2.l >> 8);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar2,r3
	mov	ar3,r4
	mov	ar4,r5
	mov	r5,#0
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar6,r7
	mov	ar7,r0
	mov	ar0,r1
	mov	r1,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_result_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:235: result += ((fl1.l & (unsigned long) 0xFF) * (fl2.l >> 8)) >> 8;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar6,r7
	mov	ar7,r0
	mov	ar0,r1
	mov	r1,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar2,r3
	mov	ar3,r4
	mov	ar4,r5
	mov	r5,#0
;	genPlus 
	mov	dptr,#___fsmul_result_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	_fsmul.c:236: result += ((fl2.l & (unsigned long) 0xFF) * (fl1.l >> 8)) >> 8;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r6,a
	movx	a,@dptr
	inc	dptr
	mov	r7,a
	movx	a,@dptr
	inc	dptr
	mov	r0,a
	movx	a,@dptr
	mov	r1,a
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar6,r7
	mov	ar7,r0
	mov	ar0,r1
	mov	r1,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__mullong_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	__mullong
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genRightShift 
;	genRightShiftLiteral (8), size 4
;	genrshFour
	mov	ar2,r3
	mov	ar3,r4
	mov	ar4,r5
	mov	r5,#0
;	genPlus 
	mov	dptr,#___fsmul_result_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,r2
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r3
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r4
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,r5
	movx	@dptr,a
;	_fsmul.c:238: if (result & SIGNBIT)
;	genAnd 
	mov	dptr,#___fsmul_result_1_1
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00105$
00116$:
;	_fsmul.c:241: result += 0x80;
;	genPlus 
	mov	dptr,#___fsmul_result_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x80
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	_fsmul.c:242: result >>= 8;
;	genRightShift 
;	genRightShiftLiteral (8), size 4
	mov	dptr,#___fsmul_result_1_1
;	genrshFour
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_result_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00106$
00105$:
;	_fsmul.c:247: result += 0x40;
;	genPlus 
	mov	dptr,#___fsmul_result_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x40
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	_fsmul.c:248: result >>= 7;
;	genRightShift 
;	genRightShiftLiteral (7), size 4
	mov	dptr,#___fsmul_result_1_1
;	genrshFour
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	add	a,acc
	orl	a,r3
	mov	r3,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	c,acc.7
	xch	a,r4
	rlc	a
	xch	a,r4
	rlc	a
	xch	a,r4
	anl	a,#0x01
	mov	r5,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_result_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:249: exp--;
;	genMinus 
	mov	dptr,#___fsmul_exp_1_1
	movx	a,@dptr
	add	a,#0xFF
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	mov	r3,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_exp_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genLabel 
00106$:
;	_fsmul.c:252: result &= ~HIDDEN;
;	genAnd 
	mov	dptr,#___fsmul_result_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	better literal AND.
	inc	dptr
	movx	a,@dptr
	anl	a, #0x7F
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_fsmul.c:255: fl1.l = PACK (sign ? SIGNBIT : 0 , (unsigned long)exp, result);  
;	genIfx 
	mov	dptr,#___fsmul_sign_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00109$
00117$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0x80
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00110$
00109$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r2,#0x00
	mov	r3,#0x00
	mov	r4,#0x00
	mov	r5,#0x00
;	genLabel 
00110$:
;	genCast 
	mov	dptr,#___fsmul_exp_1_1
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r0,a
	mov	r1,a
;	genLeftShift 
;	genLeftShiftLiteral (23), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x18
	sjmp	00119$
00118$:
	mov	a,r6
	add	a,acc
	mov	r6,a
	mov	a,r7
	rlc	a
	mov	r7,a
	mov	a,r0
	rlc	a
	mov	r0,a
	mov	a,r1
	rlc	a
	mov	r1,a
00119$:
	djnz	b,00118$
;	genOr 
	mov	a,r6
	orl	ar2,a
	mov	a,r7
	orl	ar3,a
	mov	a,r0
	orl	ar4,a
	mov	a,r1
	orl	ar5,a
;	genOr 
	mov	dptr,#___fsmul_result_1_1
	movx	a,@dptr
	orl	ar2,a
	inc	dptr
	movx	a,@dptr
	orl	ar3,a
	inc	dptr
	movx	a,@dptr
	orl	ar4,a
	inc	dptr
	movx	a,@dptr
	orl	ar5,a
;	genPointerSet 
	mov	dptr,#___fsmul_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsmul.c:256: return (fl1.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsmul_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00107$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
