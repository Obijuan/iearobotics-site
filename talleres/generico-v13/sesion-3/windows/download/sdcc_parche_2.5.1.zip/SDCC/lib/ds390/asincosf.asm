;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:49:14 2005
;--------------------------------------------------------
	.module asincosf
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _asincosf
	.globl _asincosf_PARM_2
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_asincosf_PARM_2::
	.ds 2
_asincosf_x_1_1::
	.ds 4
_asincosf_y_1_1::
	.ds 4
_asincosf_i_1_1::
	.ds 2
_asincosf_a_1_1:
	.ds 8
_asincosf_b_1_1:
	.ds 8
_asincosf_sloc0_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'asincosf'
;------------------------------------------------------------
;isacos                    Allocated with name '_asincosf_PARM_2'
;x                         Allocated with name '_asincosf_x_1_1'
;y                         Allocated with name '_asincosf_y_1_1'
;g                         Allocated to registers r2 r3 r4 r5 
;r                         Allocated to registers r4 r5 r2 r3 
;i                         Allocated with name '_asincosf_i_1_1'
;a                         Allocated with name '_asincosf_a_1_1'
;b                         Allocated with name '_asincosf_b_1_1'
;sloc0                     Allocated with name '_asincosf_sloc0_1_0'
;------------------------------------------------------------
;	asincosf.c:47: static myconst float a[2]={ 0.0, QUART_PI };
;	genPointerSet 
	mov	dptr,#_asincosf_a_1_1
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genPointerSet 
	mov	dptr,#(_asincosf_a_1_1 + 0x0004)
	mov	a,#0xDB
	movx	@dptr,a
	inc	dptr
	mov	a,#0x0F
	movx	@dptr,a
	inc	dptr
	mov	a,#0x49
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	asincosf.c:48: static myconst float b[2]={ HALF_PI, QUART_PI };
;	genPointerSet 
	mov	dptr,#_asincosf_b_1_1
	mov	a,#0xDB
	movx	@dptr,a
	inc	dptr
	mov	a,#0x0F
	movx	@dptr,a
	inc	dptr
	mov	a,#0xC9
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genPointerSet 
	mov	dptr,#(_asincosf_b_1_1 + 0x0004)
	mov	a,#0xDB
	movx	@dptr,a
	inc	dptr
	mov	a,#0x0F
	movx	@dptr,a
	inc	dptr
	mov	a,#0x49
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'asincosf'
;------------------------------------------------------------
;isacos                    Allocated with name '_asincosf_PARM_2'
;x                         Allocated with name '_asincosf_x_1_1'
;y                         Allocated with name '_asincosf_y_1_1'
;g                         Allocated to registers r2 r3 r4 r5 
;r                         Allocated to registers r4 r5 r2 r3 
;i                         Allocated with name '_asincosf_i_1_1'
;a                         Allocated with name '_asincosf_a_1_1'
;b                         Allocated with name '_asincosf_b_1_1'
;sloc0                     Allocated with name '_asincosf_sloc0_1_0'
;------------------------------------------------------------
;	asincosf.c:42: float asincosf(const float x, const int isacos)
;	genFunction 
;	-----------------------------------------
;	 function asincosf
;	-----------------------------------------
_asincosf:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #_asincosf_x_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
;	asincosf.c:50: y=fabsf(x);
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_asincosf_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	_fabsf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_asincosf_y_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	asincosf.c:51: i=isacos;
;	genAssign 
	mov	dptr,#_asincosf_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#_asincosf_i_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	asincosf.c:52: if (y < EPS) r=y;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x39
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00107$
00125$:
;	genAssign 
	mov	dptr,#_asincosf_y_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
;	genGoto 
	ljmp	00108$
;	genLabel 
00107$:
;	asincosf.c:55: if (y > 0.5)
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsgt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsgt
;	genIfx 
	mov	a,dpl
;	genIfxJump
	jnz	00126$
	ljmp	00104$
00126$:
;	asincosf.c:57: i=1-i;
;	genMinus 
	mov	dptr,#_asincosf_i_1_1
	clr	c
	movx	a,@dptr
	mov	b,a
	mov	a,#0x01
	subb	a,b
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
; Peephole 180   changed mov to clr
	clr  a
	subb	a,b
	movx	@dptr,a
;	asincosf.c:58: if (y > 1.0)
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsgt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsgt
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00102$
00127$:
;	asincosf.c:60: errno=EDOM;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_errno
	mov	a,#0x21
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;	asincosf.c:61: return 0.0;
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00117$
;	genLabel 
00102$:
;	asincosf.c:63: g=(0.5-y)+0.5;
;	genAssign 
	mov	dptr,#_asincosf_y_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fssub_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
; Peephole 181   used 16 bit load of dptr
	mov  dptr,#0x0000
	mov	dpx,#0x80
	mov	b,#0x3F
	lcall	___fssub
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	genAssign 
;	genAssign: resultIsFar = FALSE
;	asincosf.c:64: g=ldexpf(g,-1);
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_ldexpf_PARM_2
; Peephole 101   removed redundant mov
	mov  a,#0xFF
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	_ldexpf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	asincosf.c:65: y=sqrtf(g);
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	_sqrtf
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#_asincosf_y_1_1
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	asincosf.c:66: y=-(y+y);
;	genAssign 
	mov	dptr,#_asincosf_y_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsadd_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genUminus 
	mov	dptr,#_asincosf_y_1_1
;	genUminusFloat
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	mov	a,r1
	cpl	acc.7
	inc	dptr
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00105$
00104$:
;	asincosf.c:70: g=y*y;
;	genAssign 
	mov	dptr,#_asincosf_y_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsmul_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dps, #1
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genLabel 
00105$:
;	asincosf.c:72: r=y+y*((P(g)*g)/Q(g));
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,#0x65
	movx	@dptr,a
	inc	dptr
	mov	a,#0x20
	movx	@dptr,a
	inc	dptr
	mov	a,#0x01
	movx	@dptr,a
	inc	dptr
	mov	a,#0xBF
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,#0x6B
	movx	@dptr,a
	inc	dptr
	mov	a,#0x16
	movx	@dptr,a
	inc	dptr
	mov	a,#0x6F
	movx	@dptr,a
	inc	dptr
	mov	a,#0x3F
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsmul
	mov     dps, #1
	mov     dptr, #_asincosf_sloc0_1_0
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,#0x0B
	movx	@dptr,a
	inc	dptr
	mov	a,#0x8D
	movx	@dptr,a
	inc	dptr
	mov	a,#0xB1
	movx	@dptr,a
	inc	dptr
	mov	a,#0xC0
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,#0xF0
	movx	@dptr,a
	inc	dptr
	mov	a,#0x50
	movx	@dptr,a
	inc	dptr
	mov	a,#0xB3
	movx	@dptr,a
	inc	dptr
	mov	a,#0x40
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsdiv_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsdiv
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsmul_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsmul
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,r6
	movx	@dptr,a
	inc	dptr
	mov	a,r7
	movx	@dptr,a
	inc	dptr
	mov	a,r0
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_y_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r6
	mov	ar5,r7
	mov	ar2,r0
	mov	ar3,r1
;	genLabel 
00108$:
;	asincosf.c:74: if (isacos)
;	genIfx 
	mov	dptr,#_asincosf_PARM_2
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
	jnz	00128$
	ljmp	00115$
00128$:
;	asincosf.c:76: if (x < 0.0)
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
	jnz	00129$
	ljmp	00110$
00129$:
;	asincosf.c:77: r=(b[i]+r)+b[i];
;	genLeftShift 
;	genLeftShiftLiteral (2), size 2
	mov	dptr,#_asincosf_i_1_1
;	genlshTwo 
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus 
	mov	a,r6
	add	a,#_asincosf_b_1_1
	mov	dpl,a
	mov	a,r7
	addc	a,#(_asincosf_b_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_asincosf_b_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	mov	dps, #1
	mov	dptr, #_asincosf_sloc0_1_0
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
	mov	dptr,#_asincosf_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsadd_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r6
	mov	ar5,r7
	mov	ar2,r0
	mov	ar3,r1
;	genGoto 
	ljmp	00116$
;	genLabel 
00110$:
;	asincosf.c:79: r=(a[i]-r)+a[i];
;	genLeftShift 
;	genLeftShiftLiteral (2), size 2
	mov	dptr,#_asincosf_i_1_1
;	genlshTwo 
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus 
	mov	a,r6
	add	a,#_asincosf_a_1_1
	mov	dpl,a
	mov	a,r7
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_asincosf_a_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	mov	dps, #1
	mov	dptr, #_asincosf_sloc0_1_0
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fssub_PARM_2
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fssub
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
	mov	dptr,#_asincosf_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsadd_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r6
	mov	ar5,r7
	mov	ar2,r0
	mov	ar3,r1
;	genGoto 
	ljmp	00116$
;	genLabel 
00115$:
;	asincosf.c:83: r=(a[i]+r)+a[i];
;	genLeftShift 
;	genLeftShiftLiteral (2), size 2
	mov	dptr,#_asincosf_i_1_1
;	genlshTwo 
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	xch	a,r6
	add	a,acc
	xch	a,r6
	rlc	a
	mov	r7,a
;	genPlus 
	mov	a,r6
	add	a,#_asincosf_a_1_1
	mov	dpl,a
	mov	a,r7
	addc	a,#(_asincosf_a_1_1 >> 8)
	mov	dph,a
; Peephole 3.d   changed mov to clr
	clr	a
	addc	a,#(_asincosf_a_1_1 >> 16)
	mov	dpx,a
;	genPointerGet 
;	genFarPointerGet
	mov	dps, #1
	mov	dptr, #_asincosf_sloc0_1_0
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	movx	a,@dptr
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_PARM_2
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
	inc	dptr
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genCall 
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_sloc0_1_0
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
	mov	dptr,#_asincosf_sloc0_1_0
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsadd_PARM_2
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genCall 
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	___fsadd
	mov	r6,dpl
	mov	r7,dph
	mov	r0,dpx
	mov	r1,b
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar4,r6
	mov	ar5,r7
	mov	ar2,r0
	mov	ar3,r1
;	asincosf.c:84: if (x<0.0) r=-r;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fslt_PARM_2
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	inc	dps
	mov	dptr,#_asincosf_x_1_1
	movx	a,@dptr
	mov	dpl,a
	inc	dptr
	movx	a,@dptr
	mov	dph,a
	inc	dptr
	movx	a,@dptr
	mov	dpx,a
	inc	dptr
	movx	a,@dptr
	mov	b,a
	mov	dps,#0
	lcall	___fslt
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genIfx 
	mov	a,dpl
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00116$
00130$:
;	genUminus 
;	genUminusFloat
	mov	a,r3
	cpl	acc.7
	mov	r3,a
;	genLabel 
00116$:
;	asincosf.c:86: return r;
;	genRet 
	mov	dpl,r4
	mov	dph,r5
	mov	dpx,r2
	mov	b,r3
;	genLabel 
00117$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
