;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:47:53 2005
;--------------------------------------------------------
	.module _mullong
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __mullong_PARM_2
	.globl __mullong
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
__mullong_PARM_2::
	.ds 4
__mullong_a_1_1::
	.ds 4
__mullong_t_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '_mullong'
;------------------------------------------------------------
;b                         Allocated with name '__mullong_PARM_2'
;a                         Allocated with name '__mullong_a_1_1'
;t                         Allocated with name '__mullong_t_1_1'
;------------------------------------------------------------
;	_mullong.c:709: _mullong (long a, long b)
;	genFunction 
;	-----------------------------------------
;	 function _mullong
;	-----------------------------------------
__mullong:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov     dps, #1
	mov     dptr, #__mullong_a_1_1
	mov	a,dpl
	movx	@dptr,a
	inc	dptr
	mov	a,dph
	movx	@dptr,a
	inc	dptr
	mov	a,dpx
	movx	@dptr,a
	inc	dptr
	mov	a,b
	movx	@dptr,a
	mov	dps,#0
;	_mullong.c:713: t.i.hi = bcast(a)->b.b0 * bcast(b)->b.b2;       // A
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#__mullong_a_1_1
	movx	a,@dptr
	mov	r2,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0002)
	movx	a,@dptr
	mov	r3,a
;	genMult 
	mov	b,r2
	mov	a,r3
	mul	ab
	mov	r3,a
	mov	r4,b
;	genPointerSet 
	mov	dptr,#(__mullong_t_1_1 + 0x0002)
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	_mullong.c:714: t.i.lo = bcast(a)->b.b0 * bcast(b)->b.b0;       // A
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#__mullong_PARM_2
	movx	a,@dptr
	mov	r3,a
;	genMult 
	mov	b,r2
	mov	a,r3
	mul	ab
	mov	r4,a
	mov	r5,b
;	genPointerSet 
	mov	dptr,#__mullong_t_1_1
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_mullong.c:715: t.b.b3 += bcast(a)->b.b3 *
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_t_1_1 + 0x0003)
	movx	a,@dptr
	mov	r4,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0003)
	movx	a,@dptr
	mov	r5,a
;	_mullong.c:716: bcast(b)->b.b0;       // G
;	genMult 
	mov	b,r5
	mov	a,r3
	mul	ab
;	genPlus 
; Peephole 105   removed redundant mov
	mov  r5,a
	add	a,r4
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r4,a
	mov  dptr,#(__mullong_t_1_1 + 0x0003)
	movx @dptr,a
;	_mullong.c:717: t.b.b3 += bcast(a)->b.b2 *
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_t_1_1 + 0x0003)
	movx	a,@dptr
	mov	r4,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0002)
	movx	a,@dptr
	mov	r5,a
;	_mullong.c:718: bcast(b)->b.b1;       // F
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0001)
	movx	a,@dptr
	mov	r6,a
;	genMult 
	mov	b,r5
	mov	a,r6
	mul	ab
;	genPlus 
; Peephole 105   removed redundant mov
	mov  r5,a
	add	a,r4
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r4,a
	mov  dptr,#(__mullong_t_1_1 + 0x0003)
	movx @dptr,a
;	_mullong.c:719: t.i.hi += bcast(a)->b.b2 * bcast(b)->b.b0;      // E <- b lost in .lst
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_t_1_1 + 0x0002)
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0002)
	movx	a,@dptr
	mov	r6,a
;	genMult 
	mov	b,r6
	mov	a,r3
	mul	ab
;	genPlus 
; Peephole 229.b redundant move
	mov	r6,a
	mov	r7,b
	add	a,r4
	mov	r4,a
	mov	a,r7
	addc	a,r5
	mov	r5,a
;	genPointerSet 
	mov	dptr,#(__mullong_t_1_1 + 0x0002)
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_mullong.c:721: t.i.hi += bcast(a)->b.b1 * bcast(b)->b.b1;      // D <- b lost in .lst
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_t_1_1 + 0x0002)
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0001)
	movx	a,@dptr
	mov	r6,a
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0001)
	movx	a,@dptr
	mov	r7,a
;	genMult 
	mov	b,r6
	mov	a,r7
	mul	ab
;	genPlus 
; Peephole 229.b redundant move
	mov	r7,a
	mov	r6,b
	add	a,r4
	mov	r4,a
	mov	a,r6
	addc	a,r5
	mov	r5,a
;	genPointerSet 
	mov	dptr,#(__mullong_t_1_1 + 0x0002)
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_mullong.c:723: bcast(a)->bi.b3 = bcast(a)->b.b1 *
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0001)
	movx	a,@dptr
	mov	r4,a
;	_mullong.c:724: bcast(b)->b.b2;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0002)
	movx	a,@dptr
	mov	r5,a
;	genMult 
	mov	b,r4
	mov	a,r5
	mul	ab
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r4,a
	mov  dptr,#(__mullong_a_1_1 + 0x0003)
	movx @dptr,a
;	_mullong.c:725: bcast(a)->bi.i12 = bcast(a)->b.b1 *
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_a_1_1 + 0x0001)
	movx	a,@dptr
	mov	r4,a
;	_mullong.c:726: bcast(b)->b.b0;              // C
;	genMult 
	mov	b,r4
	mov	a,r3
	mul	ab
	mov	r3,a
	mov	r5,b
;	genPointerSet 
	mov	dptr,#(__mullong_a_1_1 + 0x0001)
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_mullong.c:728: bcast(b)->bi.b3 = bcast(a)->b.b0 *
;	_mullong.c:729: bcast(b)->b.b3;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0003)
	movx	a,@dptr
	mov	r3,a
;	genMult 
	mov	b,r2
	mov	a,r3
	mul	ab
;	genPointerSet 
; Peephole 100   removed redundant mov
	mov  r3,a
	mov  dptr,#(__mullong_PARM_2 + 0x0003)
	movx @dptr,a
;	_mullong.c:730: bcast(b)->bi.i12 = bcast(a)->b.b0 *
;	_mullong.c:731: bcast(b)->b.b1;              // B
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#(__mullong_PARM_2 + 0x0001)
	movx	a,@dptr
	mov	r3,a
;	genMult 
	mov	b,r2
	mov	a,r3
	mul	ab
	mov	r2,a
	mov	r4,b
;	genPointerSet 
	mov	dptr,#(__mullong_PARM_2 + 0x0001)
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
;	_mullong.c:732: bcast(b)->bi.b0 = 0;                            // B
;	genPointerSet 
	mov	dptr,#__mullong_PARM_2
; Peephole 180   changed mov to clr
;	_mullong.c:733: bcast(a)->bi.b0 = 0;                            // C
;	genPointerSet 
; Peephole 180   changed mov to clr
; Peephole 219 removed redundant clear
	clr   a
	movx  @dptr,a
	mov   dptr,#__mullong_a_1_1
	movx  @dptr,a
;	_mullong.c:734: t.l += a;
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#__mullong_t_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAssign 
	mov	dptr,#__mullong_a_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPlus 
	mov	a,r6
	add	a,r2
	mov	r2,a
	mov	a,r7
	addc	a,r3
	mov	r3,a
	mov	a,r0
	addc	a,r4
	mov	r4,a
	mov	a,r1
	addc	a,r5
	mov	r5,a
;	genPointerSet 
	mov	dptr,#__mullong_t_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_mullong.c:736: return t.l + b;
;	genAssign 
	mov	dptr,#__mullong_PARM_2
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPlus 
	mov	a,r6
	add	a,r2
	mov	r2,a
	mov	a,r7
	addc	a,r3
	mov	r3,a
	mov	a,r0
	addc	a,r4
	mov	r4,a
	mov	a,r1
	addc	a,r5
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00101$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
