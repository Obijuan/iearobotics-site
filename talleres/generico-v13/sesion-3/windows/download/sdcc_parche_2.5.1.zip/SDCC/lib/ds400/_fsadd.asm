;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:50:24 2005
;--------------------------------------------------------
	.module _fsadd
	.optsdcc -mds400 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl ___fsadd_PARM_2
	.globl ___fsadd
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
	.area REG_BANK_3	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
___fsadd_PARM_2::
	.ds 4
___fsadd_mant1_1_1::
	.ds 4
___fsadd_mant2_1_1::
	.ds 4
___fsadd_fl1_1_1::
	.ds 4
___fsadd_fl2_1_1::
	.ds 4
___fsadd_exp1_1_1::
	.ds 2
___fsadd_exp2_1_1::
	.ds 2
___fsadd_sign_1_1::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function '__fsadd'
;------------------------------------------------------------
;a2                        Allocated with name '___fsadd_PARM_2'
;a1                        Allocated to registers r2 r3 r4 r5 
;mant1                     Allocated with name '___fsadd_mant1_1_1'
;mant2                     Allocated with name '___fsadd_mant2_1_1'
;fl1                       Allocated with name '___fsadd_fl1_1_1'
;fl2                       Allocated with name '___fsadd_fl2_1_1'
;exp1                      Allocated with name '___fsadd_exp1_1_1'
;exp2                      Allocated with name '___fsadd_exp2_1_1'
;sign                      Allocated with name '___fsadd_sign_1_1'
;------------------------------------------------------------
;	_fsadd.c:161: float __fsadd (float a1, float a2)
;	genFunction 
;	-----------------------------------------
;	 function __fsadd
;	-----------------------------------------
___fsadd:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
;	genReceive 
	mov	r2,dpl
	mov	r3,dph
	mov	r4,dpx
	mov	r5,b
;	_fsadd.c:166: volatile unsigned long sign = 0;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_sign_1_1
	clr	a
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
;	_fsadd.c:168: fl1.f = a1;
;	genPointerSet 
	mov	dptr,#___fsadd_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:169: fl2.f = a2;
;	genPointerSet 
	mov	dptr,#___fsadd_fl2_1_1
	mov     dps, #1
	mov     dptr, #___fsadd_PARM_2
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
	inc	dptr
	inc	dps
	inc	dptr
	movx	a,@dptr
	dec	dps
	movx	@dptr,a
;	_fsadd.c:172: if (!fl1.l)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00102$
00145$:
;	_fsadd.c:173: return (fl2.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	ljmp	00129$
;	genLabel 
00102$:
;	_fsadd.c:174: if (!fl2.l)
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genIfx 
	mov	a,r2
	orl	a,r3
	orl	a,r4
	orl	a,r5
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00104$
00146$:
;	_fsadd.c:175: return (fl1.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	ljmp	00129$
;	genLabel 
00104$:
;	_fsadd.c:177: exp1 = EXP (fl1.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0
	mov	r5,#0
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genCast 
	mov	dptr,#___fsadd_exp1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_fsadd.c:178: exp2 = EXP (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRightShift 
;	genRightShiftLiteral (23), size 4
;	genrshFour
	mov	ar2,r4
	mov	a,r5
	mov	c,acc.7
	xch	a,r2
	rlc	a
	xch	a,r2
	rlc	a
	xch	a,r2
	anl	a,#0x01
	mov	r3,a
	mov	r4,#0
	mov	r5,#0
;	genAnd 
	mov	r3,#0
	mov	r4,#0
	mov	r5,#0
;	genCast 
	mov	dptr,#___fsadd_exp2_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	_fsadd.c:180: if (exp1 > exp2 + 25)
;	genPlus 
	mov	dptr,#___fsadd_exp2_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x19
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
;	genCmpGt 
	mov	dptr,#___fsadd_exp1_1_1
;	genCmp
	clr	c
	mov	a,r2
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r3
	xrl	a,#0x80
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00106$
00147$:
;	_fsadd.c:181: return (fl1.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	ljmp	00129$
;	genLabel 
00106$:
;	_fsadd.c:182: if (exp2 > exp1 + 25)
;	genPlus 
	mov	dptr,#___fsadd_exp1_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x19
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	mov	r3,a
;	genCmpGt 
	mov	dptr,#___fsadd_exp2_1_1
;	genCmp
	clr	c
	mov	a,r2
	xch	a, b
	movx	a,@dptr
	xch	a, b
	subb	a,b
	mov	a,r3
	xrl	a,#0x80
	xch	a, b
	inc	dptr
	movx	a,@dptr
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00108$
00148$:
;	_fsadd.c:183: return (fl2.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
	ljmp	00129$
;	genLabel 
00108$:
;	_fsadd.c:185: mant1 = MANT (fl1.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	anl	ar4,#0x7F
	mov	r5,#0
;	genOr 
	mov	dptr,#___fsadd_mant1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	better literal OR.
	mov	a,r4
	orl	a, #0x80
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:186: mant2 = MANT (fl2.l);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genAnd 
	anl	ar4,#0x7F
	mov	r5,#0
;	genOr 
	mov	dptr,#___fsadd_mant2_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	better literal OR.
	mov	a,r4
	orl	a, #0x80
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:188: if (SIGN (fl1.l))
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r5,a
	rl	a
	anl	a,#1
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r2,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00110$
00149$:
;	_fsadd.c:189: mant1 = -mant1;
;	genUminus 
	mov	dptr,#___fsadd_mant1_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_mant1_1_1
	dec	dps
	movx	a,@dptr
	setb	c
	cpl	a
	addc	a,#0
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00110$:
;	_fsadd.c:190: if (SIGN (fl2.l))
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl2_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
;	genGetHbit 
; Peephole 105   removed redundant mov
	mov  r5,a
	rl	a
	anl	a,#1
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r2,a
;	genIfxJump
; Peephole 110   removed ljmp by inverse jump logic
	jz  00112$
00150$:
;	_fsadd.c:191: mant2 = -mant2;
;	genUminus 
	mov	dptr,#___fsadd_mant2_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_mant2_1_1
	dec	dps
	movx	a,@dptr
	setb	c
	cpl	a
	addc	a,#0
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00112$:
;	_fsadd.c:193: if (exp1 > exp2)
;	genCmpGt 
	mov	dptr,#___fsadd_exp2_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_exp1_1_1
	dec	dps
;	genCmp
	clr	c
	movx	a,@dptr
	mov	dps,#1
	xch	a, b
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	subb	a,b
	inc	dptr
	movx	a,@dptr
	xrl	a,#0x80
	mov	dps,#1
	xch	a, b
	inc	dptr
	movx	a,@dptr
	mov	dps,#0
	xch	a, b
	xrl	b,#0x80
	subb	a,b
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00114$
00151$:
;	_fsadd.c:195: mant2 >>= exp1 - exp2;
;	genMinus 
	mov	dptr,#___fsadd_exp2_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_exp1_1_1
	dec	dps
	clr	c
	movx	a,@dptr
	mov	b,a
	inc	dps
	movx	a,@dptr
	subb	a,b
	mov	r2,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r3,a
	mov	dps,#0
;	genRightShift 
;	genSignedRightShift 
	mov	b,r2
	inc	b
	mov	dptr,#___fsadd_mant2_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r2,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r3,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r5,a
	movx	a,@dptr
	rlc	a
	mov	ov,c
	sjmp	00153$
00152$:
	mov	c,ov
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	mov	a,r3
	rrc	a
	mov	r3,a
	mov	a,r2
	rrc	a
	mov	r2,a
00153$:
	djnz	b,00152$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_mant2_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00115$
00114$:
;	_fsadd.c:199: mant1 >>= exp2 - exp1;
;	genMinus 
	mov	dptr,#___fsadd_exp1_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_exp2_1_1
	dec	dps
	clr	c
	movx	a,@dptr
	mov	b,a
	inc	dps
	movx	a,@dptr
	subb	a,b
	mov	r2,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	mov	b,a
	inc	dps
	inc	dptr
	movx	a,@dptr
	subb	a,b
	mov	r3,a
	mov	dps,#0
;	genRightShift 
;	genSignedRightShift 
	mov	b,r2
	inc	b
	mov	dptr,#___fsadd_mant1_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r2,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r3,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r5,a
	movx	a,@dptr
	rlc	a
	mov	ov,c
	sjmp	00155$
00154$:
	mov	c,ov
	mov	a,r5
	rrc	a
	mov	r5,a
	mov	a,r4
	rrc	a
	mov	r4,a
	mov	a,r3
	rrc	a
	mov	r3,a
	mov	a,r2
	rrc	a
	mov	r2,a
00155$:
	djnz	b,00154$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_mant1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:200: exp1 = exp2;
;	genAssign 
	mov	dptr,#___fsadd_exp2_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign (390 auto-toggle fun)
	mov	dps,#0x21
	mov	dptr,#___fsadd_exp1_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
	mov	dps,#0
;	genLabel 
00115$:
;	_fsadd.c:202: mant1 += mant2;
;	genPlus 
	mov	dptr,#___fsadd_mant2_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_mant1_1_1
	dec	dps
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	movx	a,@dptr
	xch	a, _ap
	add	a,_ap
	mov	r2,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	addc	a,_ap
	mov	r3,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	addc	a,_ap
	mov	r4,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	inc	dps
	inc	dptr
	movx	a,@dptr
	xch	a, _ap
	addc	a,_ap
	mov	r5,a
	mov	dps,#0
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_mant1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:204: if (mant1 < 0)
;	genCmpLt 
	mov	dptr,#___fsadd_mant1_1_1
;	genCmp
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.7,00119$
00156$:
;	_fsadd.c:206: mant1 = -mant1;
;	genUminus 
	mov	dptr,#___fsadd_mant1_1_1
	mov	dps, #1
	mov	dptr, #___fsadd_mant1_1_1
	dec	dps
	movx	a,@dptr
	setb	c
	cpl	a
	addc	a,#0
	inc	dps
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	dec	dps
	inc	dptr
	movx	a,@dptr
	cpl	a
	addc	a,#0
	inc	dps
	inc	dptr
	movx	@dptr,a
	mov	dps,#0
;	_fsadd.c:207: sign = SIGNBIT;
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_sign_1_1
; Peephole 101   removed redundant mov
; Peephole 180   changed mov to clr
	clr  a
	movx @dptr,a
	inc  dptr
	movx @dptr,a
	inc	dptr
; Peephole 180   changed mov to clr
	clr  a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x80
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00119$:
;	_fsadd.c:209: else if (!mant1)
;	genIfx 
	mov	dptr,#___fsadd_mant1_1_1
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	mov	a,b
;	genIfxJump
; Peephole 109   removed ljmp by inverse jump logic
	jnz  00121$
00157$:
;	_fsadd.c:210: return (0);
;	genRet 
; Peephole 181a   used 24 bit load of dptr
	mov  dptr,#0x0000
	mov	b,#0x00
	ljmp	00129$
;	_fsadd.c:213: while (mant1<HIDDEN) {
;	genLabel 
00121$:
;	genAssign 
	mov	dptr,#___fsadd_mant1_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
;	genCmpLt 
;	genCmp
	clr	c
	mov	a,r2
	subb	a,#0x00
	mov	a,r3
	subb	a,#0x00
	mov	a,r4
	subb	a,#0x80
	mov	a,r5
	subb	a,#0x00
;	genIfxJump
; Peephole 108   removed ljmp by inverse jump logic
	jnc  00126$
00158$:
;	_fsadd.c:214: mant1 <<= 1;
;	genLeftShift 
;	genLeftShiftLiteral (1), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x02
	mov	dptr,#___fsadd_mant1_1_1
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r2,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r3,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r4,a
	inc	dptr
	movx	a,@dptr
;       Peephole 239    used a instead of acc
	mov     r5,a
	sjmp	00160$
00159$:
	mov	a,r2
	add	a,acc
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
00160$:
	djnz	b,00159$
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_mant1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:215: exp1--;
;	genMinus 
	mov	dptr,#___fsadd_exp1_1_1
	movx	a,@dptr
	add	a,#0xFF
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0xFF
	mov	r3,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#___fsadd_exp1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
;	genGoto 
;	_fsadd.c:219: while (mant1 & 0xff000000) {
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00126$:
;	genAssign 
	mov	dptr,#___fsadd_mant1_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
;	genAnd 
; Peephole 105   removed redundant mov
	mov  r5,a
; Peephole 110   removed ljmp by inverse jump logic
	jz  00128$
00161$:
;	_fsadd.c:220: if (mant1&1)
;	genAnd 
	mov	dptr,#___fsadd_mant1_1_1
	movx	a,@dptr
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  acc.0,00125$
00162$:
;	_fsadd.c:221: mant1 += 2;
;	genPlus 
	mov	dptr,#___fsadd_mant1_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x02
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genLabel 
00125$:
;	_fsadd.c:222: mant1 >>= 1 ;
;	genRightShift 
;	genSignedRightShift 
;	genRightShiftLiteral (1), size 4
	mov	dptr,#___fsadd_mant1_1_1
;	genrshFour
	inc	dptr
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	c,acc.7
	rrc	a
	mov	r5,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r4,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
	mov	r3,a
	lcall	__decdptr
	movx	a,@dptr
	rrc	a
;	genAssign 
;	genAssign: resultIsFar = TRUE
; Peephole 100   removed redundant mov
	mov  r2,a
	mov  dptr,#___fsadd_mant1_1_1
	movx @dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:223: exp1++;
;	genPlus 
	mov	dptr,#___fsadd_exp1_1_1
;	Swapped plus args.
	movx	a,@dptr
	add	a,#0x01
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	addc	a,#0x00
	movx	@dptr,a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00126$
00128$:
;	_fsadd.c:227: mant1 &= ~HIDDEN;
;	genAnd 
	mov	dptr,#___fsadd_mant1_1_1
	movx	a,@dptr
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	better literal AND.
	inc	dptr
	movx	a,@dptr
	anl	a, #0x7F
	movx	@dptr,a
	inc	dptr
	movx	a,@dptr
	movx	@dptr,a
;	_fsadd.c:230: fl1.l = PACK (sign, (unsigned long) exp1, mant1);
;	genCast 
	mov	dptr,#___fsadd_exp1_1_1
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	movx	a,@dptr
	rlc	a
	subb	a,acc
	mov	r4,a
	mov	r5,a
;	genLeftShift 
;	genLeftShiftLiteral (23), size 4
;	genLeftShiftLiteral wimping out
	mov	b,#0x18
	sjmp	00164$
00163$:
	mov	a,r2
	add	a,acc
	mov	r2,a
	mov	a,r3
	rlc	a
	mov	r3,a
	mov	a,r4
	rlc	a
	mov	r4,a
	mov	a,r5
	rlc	a
	mov	r5,a
00164$:
	djnz	b,00163$
;	genOr 
	mov	dptr,#___fsadd_sign_1_1
	movx	a,@dptr
	orl	ar2,a
	inc	dptr
	movx	a,@dptr
	orl	ar3,a
	inc	dptr
	movx	a,@dptr
	orl	ar4,a
	inc	dptr
	movx	a,@dptr
	orl	ar5,a
;	genAssign 
	mov	dptr,#___fsadd_mant1_1_1
;	genAssign: resultIsFar = TRUE
;	genFarFarAssign
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genOr 
	mov	a,r6
	orl	ar2,a
	mov	a,r7
	orl	ar3,a
	mov	a,r0
	orl	ar4,a
	mov	a,r1
	orl	ar5,a
;	genPointerSet 
	mov	dptr,#___fsadd_fl1_1_1
	mov	a,r2
	movx	@dptr,a
	inc	dptr
	mov	a,r3
	movx	@dptr,a
	inc	dptr
	mov	a,r4
	movx	@dptr,a
	inc	dptr
	mov	a,r5
	movx	@dptr,a
;	_fsadd.c:232: return (fl1.f);
;	genPointerGet 
;	genFarPointerGet
	mov	dptr,#___fsadd_fl1_1_1
	movx	a,@dptr
	inc	dptr
	mov	r2,a
	movx	a,@dptr
	inc	dptr
	mov	r3,a
	movx	a,@dptr
	inc	dptr
	mov	r4,a
	movx	a,@dptr
	mov	r5,a
;	genRet 
	mov	dpl,r2
	mov	dph,r3
	mov	dpx,r4
	mov	b,r5
;	genLabel 
00129$:
;	genEndFunction 
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
