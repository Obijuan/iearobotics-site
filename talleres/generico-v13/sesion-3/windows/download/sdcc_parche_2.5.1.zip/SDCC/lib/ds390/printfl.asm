;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:48:27 2005
;--------------------------------------------------------
	.module printfl
	.optsdcc -mds390 --model-flat24
	
;--------------------------------------------------------
; CPU specific extensions
;--------------------------------------------------------
.flat24 on		; 24 bit flat addressing
dpl1	=	0x84
dph1	=	0x85
dps	=	0x86
dpx	=	0x93
dpx1	=	0x95
esp	=	0x9B
ap	=	0x9C
_ap	=	0x9C
mcnt0	=	0xD1
mcnt1	=	0xD2
ma	=	0xD3
mb	=	0xD4
mc	=	0xD5
F1	=	0xD1	; user flag
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _printf_small
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_P4	=	0x0080
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_DPL1	=	0x0084
_DPH1	=	0x0085
_DPS	=	0x0086
_PCON	=	0x0087
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_CKCON	=	0x008e
_P1	=	0x0090
_EXIF	=	0x0091
_P4CNT	=	0x0092
_DPX	=	0x0093
_DPX1	=	0x0095
_SCON0	=	0x0098
_SBUF0	=	0x0099
_ESP	=	0x009b
_AP	=	0x009c
_ACON	=	0x009d
_P2	=	0x00a0
_P5	=	0x00a1
_P5CNT	=	0x00a2
_IE	=	0x00a8
_P3	=	0x00b0
_IP	=	0x00b8
_SCON1	=	0x00c0
_SBUF1	=	0x00c1
_PMR	=	0x00c4
_MCON	=	0x00c6
_TA	=	0x00c7
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2L	=	0x00ca
_RTL2	=	0x00ca
_RCAP2H	=	0x00cb
_RTH2	=	0x00cb
_TL2	=	0x00cc
_TH2	=	0x00cd
_PSW	=	0x00d0
_MCNT0	=	0x00d1
_MCNT1	=	0x00d2
_MA	=	0x00d3
_MB	=	0x00d4
_MC	=	0x00d5
_WDCON	=	0x00d8
_ACC	=	0x00e0
_EIE	=	0x00e8
_MXAX	=	0x00ea
_B	=	0x00f0
_EIP	=	0x00f8
;--------------------------------------------------------
; special function bits 
;--------------------------------------------------------
_IT0	=	0x0088
_IE0	=	0x0089
_IT1	=	0x008a
_IE1	=	0x008b
_TR0	=	0x008c
_TF0	=	0x008d
_TR1	=	0x008e
_TF1	=	0x008f
_T2	=	0x0090
_T2EX	=	0x0091
_RXD1	=	0x0092
_TXD1	=	0x0093
_INT2	=	0x0094
_INT3	=	0x0095
_INT4	=	0x0096
_INT5	=	0x0097
_RI_0	=	0x0098
_TI_0	=	0x0099
_RB8_0	=	0x009a
_TB8_0	=	0x009b
_REN_0	=	0x009c
_SM2_0	=	0x009d
_SM1_0	=	0x009e
_SM0_0	=	0x009f
_FE_0	=	0x009f
_EX0	=	0x00a8
_ET0	=	0x00a9
_EX1	=	0x00aa
_ET1	=	0x00ab
_ES0	=	0x00ac
_ET2	=	0x00ad
_ES1	=	0x00ae
_EA	=	0x00af
_RXD0	=	0x00b0
_TXD0	=	0x00b1
_INT0	=	0x00b2
_INT1	=	0x00b3
_T0	=	0x00b4
_T1	=	0x00b5
_WR	=	0x00b6
_RD	=	0x00b7
_PX0	=	0x00b8
_PT0	=	0x00b9
_PX1	=	0x00ba
_PT1	=	0x00bb
_PS0	=	0x00bc
_PT2	=	0x00bd
_PS1	=	0x00be
_RI_1	=	0x00c0
_TI_1	=	0x00c1
_RB8_1	=	0x00c2
_TB8_1	=	0x00c3
_REN_1	=	0x00c4
_SM2_1	=	0x00c5
_SM1_1	=	0x00c6
_SM0_1	=	0x00c7
_FE_1	=	0x00c7
_CP_RL	=	0x00c8
_C_T	=	0x00c9
_TR2	=	0x00ca
_EXEN2	=	0x00cb
_TCLK	=	0x00cc
_RCLK	=	0x00cd
_EXF2	=	0x00ce
_TF2	=	0x00cf
_P	=	0x00d0
_F1	=	0x00d1
_OV	=	0x00d2
_RS0	=	0x00d3
_RS1	=	0x00d4
_F0	=	0x00d5
_AC	=	0x00d6
_CY	=	0x00d7
_RWT	=	0x00d8
_EWT	=	0x00d9
_WDRF	=	0x00da
_WDIF	=	0x00db
_PFI	=	0x00dc
_EPFI	=	0x00dd
_POR	=	0x00de
_SMOD_1	=	0x00df
_EX2	=	0x00e8
_EX3	=	0x00e9
_EX4	=	0x00ea
_EX5	=	0x00eb
_EWDI	=	0x00ec
_C1IE	=	0x00ed
_C0IE	=	0x00ee
_CANBIE	=	0x00ef
_PX2	=	0x00f8
_PX3	=	0x00f9
_PX4	=	0x00fa
_PX5	=	0x00fb
_PWDI	=	0x00fc
_C1IP	=	0x00fd
_C0IP	=	0x00fe
_CANBIP	=	0x00ff
;--------------------------------------------------------
; overlayable register banks 
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_radix:
	.ds 1
_str:
	.ds 4
_val:
	.ds 4
_printf_small_buffer_4_8:
	.ds 12
_printf_small_c_4_8:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram 
;--------------------------------------------------------
	.area OSEG    (OVR,DATA)
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_long_flag:
	.ds 1
_string_flag:
	.ds 1
_char_flag:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;	printfl.c:52: static bit  long_flag = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_long_flag
;	printfl.c:53: static bit  string_flag =0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_string_flag
;	printfl.c:54: static bit  char_flag = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_char_flag
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'printf_small'
;------------------------------------------------------------
;fmt                       Allocated to stack - offset -8
;ap                        Allocated to registers r2 r3 r4 r5 
;sloc0                     Allocated to stack - offset 1
;sloc1                     Allocated to stack - offset 2
;buffer                    Allocated with name '_printf_small_buffer_4_8'
;c                         Allocated with name '_printf_small_c_4_8'
;------------------------------------------------------------
;	printfl.c:123: void printf_small (char * fmt, ... ) reentrant
;	genFunction 
;	-----------------------------------------
;	 function printf_small
;	-----------------------------------------
_printf_small:
	ar2 = 0x02
	ar3 = 0x03
	ar4 = 0x04
	ar5 = 0x05
	ar6 = 0x06
	ar7 = 0x07
	ar0 = 0x00
	ar1 = 0x01
	push	_bpx
	push	_bpx+1
	mov	_bpx,sp
	mov	_bpx+1,esp
	anl	_bpx+1,#3
	push	acc
	push	acc
;	printfl.c:127: va_start(ap,fmt);
;	genAddrOf 
	mov	a,_bpx
	add	a,#0xF8
	mov	b,a
	mov	a,_bpx+1
	addc	a,#0xFF
	mov	r2,b
	mov	r3,a
	mov	r4,#0x40
;	genCast 
	mov	r5,#0x0
;	genLabel 
00130$:
;	printfl.c:129: for (; *fmt ; fmt++ ) {
;	genAssign 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	dpx1,#0x40
	mov	dph1,_bpx+1
	mov	dpl1,_bpx
	mov	dps,#1
	inc	dptr
	mov	dps,#0
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genIfx 
	mov	dpx,#0x40
	mov	dph,_bpx+1
	mov	dpl,_bpx
	inc	dptr
	movx	a,@dptr
;	genIfxJump
	jnz	00154$
	ljmp	00134$
00154$:
;	printfl.c:130: if (*fmt == '%') {
;	genCmpEq 
	mov	dpx,#0x40
	mov	dph,_bpx+1
	mov	dpl,_bpx
	inc	dptr
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x25,00155$
	sjmp	00156$
00155$:
	ljmp	00128$
00156$:
;	printfl.c:131: long_flag = string_flag = char_flag = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_char_flag
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_string_flag
;	genAssign 
;	genAssign: resultIsFar = FALSE
	clr	_long_flag
;	printfl.c:132: fmt++ ;
;	genPlus 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
	mov	a,#0x01
	add	a,r6
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printfl.c:133: switch (*fmt) {
;	genAssign 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	mov	dpx1,#0x40
	mov	dph1,_bpx+1
	mov	dpl1,_bpx
	mov	dps,#1
	inc	dptr
	inc	dptr
	mov	dps,#0
	lcall	__gptrget
	mov	dps,#1
	movx	@dptr,a
	mov	dps,#0
;	genCmpEq 
	mov	dpx,#0x40
	mov	dph,_bpx+1
	mov	dpl,_bpx
	inc	dptr
	inc	dptr
;	gencjneshort
	movx	a,@dptr
	cjne	a,#0x68,00157$
; Peephole 132   changed ljmp to sjmp
	sjmp 00102$
00157$:
;	genCmpEq 
	mov	dpx,#0x40
	mov	dph,_bpx+1
	mov	dpl,_bpx
	inc	dptr
	inc	dptr
;	gencjneshort
	movx	a,@dptr
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x6C,00103$
;00158$:
; Peephole 200   removed redundant sjmp
00159$:
;	printfl.c:135: long_flag = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_long_flag
;	printfl.c:136: fmt++;
;	genPlus 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
	mov	a,#0x01
	add	a,r6
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printfl.c:137: break;
;	genGoto 
;	printfl.c:138: case 'h':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00103$
00102$:
;	printfl.c:139: char_flag = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_char_flag
;	printfl.c:140: fmt++;
;	genPlus 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
	mov	a,#0x01
	add	a,r6
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	printfl.c:141: }
;	genLabel 
00103$:
;	printfl.c:143: switch (*fmt) {
;	genAssign 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
;	genCmpEq 
;	gencjneshort
; Peephole 105   removed redundant mov
	mov  r6,a
	cjne	a,#0x63,00160$
; Peephole 132   changed ljmp to sjmp
	sjmp 00107$
00160$:
;	genCmpEq 
;	gencjneshort
	mov	a,r6
	cjne	a,#0x64,00161$
; Peephole 132   changed ljmp to sjmp
	sjmp 00105$
00161$:
;	genCmpEq 
;	gencjneshort
	mov	a,r6
	cjne	a,#0x6F,00162$
; Peephole 132   changed ljmp to sjmp
	sjmp 00108$
00162$:
;	genCmpEq 
;	gencjneshort
	mov	a,r6
	cjne	a,#0x73,00163$
; Peephole 132   changed ljmp to sjmp
	sjmp 00104$
00163$:
;	genCmpEq 
;	gencjneshort
	mov	a,r6
; Peephole 132   changed ljmp to sjmp
;	genGoto 
;	printfl.c:144: case 's':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
; Peephole 199   optimized misc jump sequence
	cjne a,#0x78,00109$
	sjmp 00106$
;00164$:
00104$:
;	printfl.c:145: string_flag = 1;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	setb	_string_flag
;	printfl.c:146: break;
;	genGoto 
;	printfl.c:147: case 'd':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00105$:
;	printfl.c:148: radix = 10;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_radix,#0x0A
;	printfl.c:149: break;
;	genGoto 
;	printfl.c:150: case 'x':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00106$:
;	printfl.c:151: radix = 16;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_radix,#0x10
;	printfl.c:152: break;
;	genGoto 
;	printfl.c:153: case 'c':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00107$:
;	printfl.c:154: radix = 0;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_radix,#0x00
;	printfl.c:155: break;
;	genGoto 
;	printfl.c:156: case 'o':
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00109$
00108$:
;	printfl.c:157: radix = 8;
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_radix,#0x08
;	printfl.c:159: }
;	genLabel 
00109$:
;	printfl.c:161: if (string_flag) {
;	genIfx 
;	genIfxJump
	jb	_string_flag,00165$
	ljmp	00114$
00165$:
;	printfl.c:162: str = va_arg(ap, char *);
;	genMinus 
	mov	a,r2
	add	a,#0xFC
	mov	r6,a
	mov	a,r3
	addc	a,#0xFF
	mov	r7,a
	mov	a,r4
	addc	a,#0xFF
	mov	r0,a
	mov	ar1,r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	_str,_ap
	mov	(_str + 1),a
	inc	dptr
	lcall	__gptrgetWord
	mov	(_str + 2),_ap
	mov	(_str + 3),a
;	printfl.c:163: while (*str) putchar(*str++);
;	genLabel 
00110$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,_str
	mov	dph,(_str + 1)
	mov	dpx,(_str + 2)
	mov	b,(_str + 3)
;	genPointerGet 
;	genGenPointerGet 
	lcall	__gptrget
;	genIfx 
; Peephole 105   removed redundant mov
	mov  r6,a
;	genIfxJump
	jnz	00166$
	ljmp	00132$
00166$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,_str
	mov	dph,(_str + 1)
	mov	dpx,(_str + 2)
	mov	b,(_str + 3)
;	genPointerGet 
;	genGenPointerGet 
	lcall	__gptrget
	mov	r6,a
;	genPlus 
	mov	a,#0x01
	add	a,_str
	mov	_str,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,(_str + 1)
	mov	(_str + 1),a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,(_str + 2)
	mov	(_str + 2),a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	lcall	_putchar
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genGoto 
;	printfl.c:164: continue ;
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00110$
00114$:
;	printfl.c:167: if (long_flag)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _long_flag,00119$
00167$:
;	printfl.c:168: val = va_arg(ap,long);
;	genMinus 
	mov	a,r2
	add	a,#0xFC
	mov	r6,a
	mov	a,r3
	addc	a,#0xFF
	mov	r7,a
	mov	a,r4
	addc	a,#0xFF
	mov	r0,a
	mov	ar1,r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	_val,_ap
	mov	(_val + 1),a
	inc	dptr
	lcall	__gptrgetWord
	mov	(_val + 2),_ap
	mov	(_val + 3),a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00120$
00119$:
;	printfl.c:170: if (char_flag)
;	genIfx 
;	genIfxJump
; Peephole 111   removed ljmp by inverse jump logic
	jnb  _char_flag,00116$
00168$:
;	printfl.c:171: val = va_arg(ap,char);
;	genMinus 
	mov	a,r2
	add	a,#0xFF
	mov	r6,a
	mov	a,r3
	addc	a,#0xFF
	mov	r7,a
	mov	a,r4
	addc	a,#0xFF
	mov	r0,a
	mov	ar1,r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrget
;	genCast 
; Peephole 166   removed redundant mov
	mov  r6,a
	mov  _val,r6 
	rlc	a
	subb	a,acc
	mov	(_val + 1),a
	mov	(_val + 2),a
	mov	(_val + 3),a
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00120$
00116$:
;	printfl.c:173: val = va_arg(ap,int);
;	genMinus 
	mov	a,r2
	add	a,#0xFE
	mov	r6,a
	mov	a,r3
	addc	a,#0xFF
	mov	r7,a
	mov	a,r4
	addc	a,#0xFF
	mov	r0,a
	mov	ar1,r5
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	ar2,r6
	mov	ar3,r7
	mov	ar4,r0
	mov	ar5,r1
;	genPointerGet 
;	genGenPointerGet 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__gptrgetWord
	mov	r6,_ap
	mov	r7,a
;	genCast 
	mov	_val,r6
	mov	(_val + 1),r7
	mov	a,r7
	rlc	a
	subb	a,acc
	mov	(_val + 2),a
	mov	(_val + 3),a
;	genLabel 
00120$:
;	printfl.c:178: if (radix)
;	genIfx 
	mov	a,_radix
;	genIfxJump
	jnz	00169$
	ljmp	00125$
00169$:
;	printfl.c:182: _ltoa (val, buffer, radix);
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	r6,_val
	mov	r7,(_val + 1)
	mov	r0,(_val + 2)
	mov	r1,(_val + 3)
;	genCast 
	mov	dptr,#__ltoa_PARM_2
	mov	a,#_printf_small_buffer_4_8
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
; Peephole 3.d   changed mov to clr
	clr	a
	movx	@dptr,a
	inc	dptr
	mov	a,#0x40
	movx	@dptr,a
;	genAssign 
;	genAssign: resultIsFar = TRUE
	mov	dptr,#__ltoa_PARM_3
	mov	a,_radix
	movx	@dptr,a
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 4 
	mov	dpl,r6
	mov	dph,r7
	mov	dpx,r0
	mov	b,r1
	lcall	__ltoa
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	printfl.c:183: str = buffer;
;	genCast 
	mov	_str,#_printf_small_buffer_4_8
	mov	(_str + 1),#0
	mov	(_str + 2),#0
	mov	(_str + 3),#0x40
;	printfl.c:184: while ((c = *str++) != '\0')
;	genLabel 
00121$:
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	dpl,_str
	mov	dph,(_str + 1)
	mov	dpx,(_str + 2)
	mov	b,(_str + 3)
;	genPointerGet 
;	genGenPointerGet 
	lcall	__gptrget
	mov	r6,a
;	genPlus 
	mov	a,#0x01
	add	a,_str
	mov	_str,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,(_str + 1)
	mov	(_str + 1),a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,(_str + 2)
	mov	(_str + 2),a
;	genAssign 
;	genAssign: resultIsFar = FALSE
	mov	_printf_small_c_4_8,r6
;	genCmpEq 
;	gencjneshort
	mov	a,r6
	cjne	a,#0x00,00170$
; Peephole 132   changed ljmp to sjmp
	sjmp 00132$
00170$:
;	printfl.c:185: putchar (c);
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 1 
	mov	dpl,_printf_small_c_4_8
	lcall	_putchar
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00121$
00125$:
;	printfl.c:189: putchar((char)val);
;	genCast 
	mov	r6,_val
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 1 
	mov	dpl,r6
	lcall	_putchar
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genGoto 
;	genLabel 
; Peephole 132   changed ljmp to sjmp
	sjmp 00132$
00128$:
;	printfl.c:192: putchar(*fmt);
;	genCall 
	push	ar2
	push	ar3
	push	ar4
	push	ar5
;	genSend argreg = 1, size = 1 
	mov	dpx,#0x40
	mov	dph,_bpx+1
	mov	dpl,_bpx
	inc	dptr
	movx	a,@dptr
	mov	dpl,a
	lcall	_putchar
	pop	ar5
	pop	ar4
	pop	ar3
	pop	ar2
;	genLabel 
00132$:
;	printfl.c:129: for (; *fmt ; fmt++ ) {
;	genAssign 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
;	genAssign: resultIsFar = FALSE
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	inc	dptr
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
;	genPlus 
	mov	a,_bpx
	clr	c
	subb	a,#0x08
	mov	b,a
	mov	a,_bpx+1
	subb	a,#0x00
	mov	dpx,#0x40
	mov	dph,a
	mov	dpl,b
	mov	a,#0x01
	add	a,r6
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r7
	inc	dptr
	movx	@dptr,a
; Peephole 180   changed mov to clr
	clr  a
	addc	a,r0
	inc	dptr
	movx	@dptr,a
	inc	dptr
	mov	a,r1
	movx	@dptr,a
;	genGoto 
	ljmp	00130$
;	genLabel 
00134$:
;	genEndFunction 
	mov	sp,_bpx
	mov	esp,_bpx+1
	pop	_bpx+1
	pop	_bpx
	ret
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
