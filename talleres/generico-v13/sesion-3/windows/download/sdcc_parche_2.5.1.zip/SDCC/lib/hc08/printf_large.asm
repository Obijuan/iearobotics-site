;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:55:56 2005
;--------------------------------------------------------
	.module printf_large
	.optsdcc -mhc08
	
	.area CSEG (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area XINIT
	.area CONST   (CODE)
	.area DSEG
	.area OSEG    (OVR)
	.area BSEG
	.area XSEG
	.area XISEG
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl __print_format_PARM_4
	.globl __print_format_PARM_3
	.globl __print_format_PARM_2
	.globl __print_format
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area DSEG
_output_digit_sloc0_1_0::
	.ds 1
_output_digit_sloc1_1_0::
	.ds 1
__print_format_sloc0_1_0::
	.ds 2
__print_format_sloc1_1_0::
	.ds 1
__print_format_sloc2_1_0::
	.ds 1
__print_format_sloc3_1_0::
	.ds 2
__print_format_sloc4_1_0::
	.ds 2
__print_format_sloc5_1_0::
	.ds 4
__print_format_sloc6_1_0::
	.ds 4
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area	OSEG    (OVR)
_calculate_digit_sloc0_1_0::
	.ds 1
_calculate_digit_sloc1_1_0::
	.ds 1
_calculate_digit_sloc2_1_0::
	.ds 4
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
	.area XISEG
;--------------------------------------------------------
; extended address mode data
;--------------------------------------------------------
	.area XSEG
_lower_case:
	.ds 1
_output_char:
	.ds 2
_p:
	.ds 2
_value:
	.ds 5
_output_digit_n_1_1::
	.ds 1
_output_2digits_b_1_1::
	.ds 1
_calculate_digit_radix_1_1::
	.ds 1
__print_format_PARM_2::
	.ds 2
__print_format_PARM_3::
	.ds 2
__print_format_PARM_4::
	.ds 2
__print_format_left_justify_1_1::
	.ds 1
__print_format_zero_padding_1_1::
	.ds 1
__print_format_prefix_sign_1_1::
	.ds 1
__print_format_prefix_space_1_1::
	.ds 1
__print_format_signed_argument_1_1::
	.ds 1
__print_format_char_argument_1_1::
	.ds 1
__print_format_long_argument_1_1::
	.ds 1
__print_format_float_argument_1_1::
	.ds 1
__print_format_lsd_1_1::
	.ds 1
__print_format_radix_1_1::
	.ds 1
__print_format_charsOutputted_1_1::
	.ds 2
__print_format_width_1_1::
	.ds 1
__print_format_decimals_1_1::
	.ds 1
__print_format_length_1_1::
	.ds 1
__print_format_c_1_1::
	.ds 1
__print_format_store_4_21::
	.ds 6
__print_format_pstore_4_21::
	.ds 2
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area CSEG (CODE)
	.area GSINIT (CODE)
	.area GSFINAL (CODE)
	.area GSINIT (CODE)
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME (CODE)
	.area CSEG (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'output_digit'
;------------------------------------------------------------
;sloc0                     Allocated with name '_output_digit_sloc0_1_0'
;sloc1                     Allocated with name '_output_digit_sloc1_1_0'
;n                         Allocated with name '_output_digit_n_1_1'
;------------------------------------------------------------
;printf_large.c:80: static void output_digit( unsigned char n )
;	-----------------------------------------
;	 function output_digit
;	-----------------------------------------
_output_digit:
	sta	_output_digit_n_1_1
;printf_large.c:83: output_char( n <= 9 ? '0'+n :
	lda	_output_digit_n_1_1
	cmp	#0x09
	bhi	00109$
	clra
	bra	00110$
00109$:
	lda	#0x01
00110$:
	tsta
	beq	00111$
	lda	#0x01
00111$:
	eor	#0x01
	tsta
; Peephole 2d	- eliminated jmp
	beq	00103$
00112$:
	lda	_output_digit_n_1_1
	add	#0x30
	sta	*_output_digit_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00104$
00103$:
;printf_large.c:84: (lower_case ? n+(char)('a'-10) : n+(char)('A'-10)), p );
	lda	_lower_case
; Peephole 2d	- eliminated jmp
	beq	00105$
00113$:
	lda	_output_digit_n_1_1
	add	#0x57
	sta	*_output_digit_sloc1_1_0
; Peephole 3	- shortened jmp to bra
	bra	00106$
00105$:
	lda	_output_digit_n_1_1
	add	#0x37
	sta	*_output_digit_sloc1_1_0
00106$:
	mov	*_output_digit_sloc1_1_0,*_output_digit_sloc0_1_0
00104$:
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00115$
	bra	00114$
00115$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	*_output_digit_sloc0_1_0
	rts
00114$:
	ais	#2
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'output_2digits'
;------------------------------------------------------------
;b                         Allocated with name '_output_2digits_b_1_1'
;------------------------------------------------------------
;printf_large.c:98: static void output_2digits( unsigned char b )
;	-----------------------------------------
;	 function output_2digits
;	-----------------------------------------
_output_2digits:
	sta	_output_2digits_b_1_1
;printf_large.c:100: output_digit( b>>4   );
	lda	_output_2digits_b_1_1
	nsa	
	and	#0x0f
	jsr	_output_digit
;printf_large.c:101: output_digit( b&0x0F );
	lda	_output_2digits_b_1_1
	and	#0x0F
	jsr	_output_digit
00101$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function 'calculate_digit'
;------------------------------------------------------------
;radix                     Allocated with name '_calculate_digit_radix_1_1'
;i                         Allocated to registers 
;sloc0                     Allocated with name '_calculate_digit_sloc0_1_0'
;sloc1                     Allocated with name '_calculate_digit_sloc1_1_0'
;sloc2                     Allocated with name '_calculate_digit_sloc2_1_0'
;------------------------------------------------------------
;printf_large.c:125: static void calculate_digit( unsigned char radix )
;	-----------------------------------------
;	 function calculate_digit
;	-----------------------------------------
_calculate_digit:
	sta	_calculate_digit_radix_1_1
;printf_large.c:129: for( i = 32; i != 0; i-- )
	mov	#0x20,*_calculate_digit_sloc0_1_0
00103$:
	lda	*_calculate_digit_sloc0_1_0
	cmp	#0x00
	bne	00112$
; Peephole 6a  - replaced jmp to rts with rts
	rts
00112$:
;printf_large.c:131: value.byte[4] = (value.byte[4] << 1) | ((value.ul >> 31) & 0x01);
	lda	(_value + 0x0004)
	lsla	
	sta	*_calculate_digit_sloc1_1_0
	lda	_value
	sta	*_calculate_digit_sloc2_1_0
	lda	(_value + 1)
	sta	*(_calculate_digit_sloc2_1_0 + 1)
	lda	(_value + 2)
	sta	*(_calculate_digit_sloc2_1_0 + 2)
	lda	(_value + 3)
	sta	*(_calculate_digit_sloc2_1_0 + 3)
	lda	*_calculate_digit_sloc2_1_0
	rola
	clra
	rola
	ora	*_calculate_digit_sloc1_1_0
	sta	(_value + 0x0004)
;printf_large.c:132: value.ul <<= 1;
	lda	_value
	sta	*_calculate_digit_sloc2_1_0
	lda	(_value + 1)
	sta	*(_calculate_digit_sloc2_1_0 + 1)
	lda	(_value + 2)
	sta	*(_calculate_digit_sloc2_1_0 + 2)
	lda	(_value + 3)
	sta	*(_calculate_digit_sloc2_1_0 + 3)
	lda	*(_calculate_digit_sloc2_1_0 + 3)
	ldx	*(_calculate_digit_sloc2_1_0 + 2)
	lsla
	rolx
	sta	*(_calculate_digit_sloc2_1_0 + 3)
	stx	*(_calculate_digit_sloc2_1_0 + 2)
	lda	*(_calculate_digit_sloc2_1_0 + 1)
	ldx	*_calculate_digit_sloc2_1_0
	rola
	rolx
	sta	*(_calculate_digit_sloc2_1_0 + 1)
	stx	*_calculate_digit_sloc2_1_0
	lda	*_calculate_digit_sloc2_1_0
	sta	_value
	lda	*(_calculate_digit_sloc2_1_0 + 1)
	sta	(_value + 1)
	lda	*(_calculate_digit_sloc2_1_0 + 2)
	sta	(_value + 2)
	lda	*(_calculate_digit_sloc2_1_0 + 3)
	sta	(_value + 3)
;printf_large.c:134: if (radix <= value.byte[4] )
	lda	(_value + 0x0004)
	cmp	_calculate_digit_radix_1_1
; Peephole 2b	- eliminated jmp
	bcs	00105$
00113$:
;printf_large.c:136: value.byte[4] -= radix;
	lda	(_value + 0x0004)
	sub	_calculate_digit_radix_1_1
	sta	(_value + 0x0004)
;printf_large.c:137: value.ul |= 1;
	lda	_value
	sta	*_calculate_digit_sloc2_1_0
	lda	(_value + 1)
	sta	*(_calculate_digit_sloc2_1_0 + 1)
	lda	(_value + 2)
	sta	*(_calculate_digit_sloc2_1_0 + 2)
	lda	(_value + 3)
	sta	*(_calculate_digit_sloc2_1_0 + 3)
	bset	#0,*(_calculate_digit_sloc2_1_0 + 3)
	lda	*_calculate_digit_sloc2_1_0
	sta	_value
	lda	*(_calculate_digit_sloc2_1_0 + 1)
	sta	(_value + 1)
	lda	*(_calculate_digit_sloc2_1_0 + 2)
	sta	(_value + 2)
	lda	*(_calculate_digit_sloc2_1_0 + 3)
	sta	(_value + 3)
00105$:
;printf_large.c:129: for( i = 32; i != 0; i-- )
	dec	*_calculate_digit_sloc0_1_0
	jmp	00103$
00107$:
	rts
;------------------------------------------------------------
;Allocation info for local variables in function '_print_format'
;------------------------------------------------------------
;sloc0                     Allocated with name '__print_format_sloc0_1_0'
;sloc1                     Allocated with name '__print_format_sloc1_1_0'
;sloc2                     Allocated with name '__print_format_sloc2_1_0'
;sloc3                     Allocated with name '__print_format_sloc3_1_0'
;sloc4                     Allocated with name '__print_format_sloc4_1_0'
;sloc5                     Allocated with name '__print_format_sloc5_1_0'
;sloc6                     Allocated with name '__print_format_sloc6_1_0'
;pvoid                     Allocated with name '__print_format_PARM_2'
;format                    Allocated with name '__print_format_PARM_3'
;ap                        Allocated with name '__print_format_PARM_4'
;pfn                       Allocated to registers 
;left_justify              Allocated with name '__print_format_left_justify_1_1'
;zero_padding              Allocated with name '__print_format_zero_padding_1_1'
;prefix_sign               Allocated with name '__print_format_prefix_sign_1_1'
;prefix_space              Allocated with name '__print_format_prefix_space_1_1'
;signed_argument           Allocated with name '__print_format_signed_argument_1_1'
;char_argument             Allocated with name '__print_format_char_argument_1_1'
;long_argument             Allocated with name '__print_format_long_argument_1_1'
;float_argument            Allocated with name '__print_format_float_argument_1_1'
;lsd                       Allocated with name '__print_format_lsd_1_1'
;radix                     Allocated with name '__print_format_radix_1_1'
;charsOutputted            Allocated with name '__print_format_charsOutputted_1_1'
;width                     Allocated with name '__print_format_width_1_1'
;decimals                  Allocated with name '__print_format_decimals_1_1'
;length                    Allocated with name '__print_format_length_1_1'
;c                         Allocated with name '__print_format_c_1_1'
;store                     Allocated with name '__print_format_store_4_21'
;pstore                    Allocated with name '__print_format_pstore_4_21'
;------------------------------------------------------------
;printf_large.c:339: int _print_format (pfn_outputchar pfn, void* pvoid, const char *format, va_list ap)
;	-----------------------------------------
;	 function _print_format
;	-----------------------------------------
__print_format:
	sta	(_output_char + 1)
	stx	_output_char
;printf_large.c:367: p = pvoid;
	lda	__print_format_PARM_2
	sta	_p
	lda	(__print_format_PARM_2 + 1)
	sta	(_p + 1)
;printf_large.c:371: charsOutputted=0;
; Peephole 5c   - eliminated redundant clra
	clra
	sta	__print_format_charsOutputted_1_1
	sta	(__print_format_charsOutputted_1_1 + 1)
;printf_large.c:379: while( c=*format++ )
00224$:
	lda	__print_format_PARM_3
	sta	*__print_format_sloc0_1_0
	lda	(__print_format_PARM_3 + 1)
	sta	*(__print_format_sloc0_1_0 + 1)
	ldhx	*__print_format_sloc0_1_0
	lda	,x
	sta	*__print_format_sloc1_1_0
	lda	*(__print_format_sloc0_1_0 + 1)
	add	#0x01
	sta	(__print_format_PARM_3 + 1)
	lda	*__print_format_sloc0_1_0
	adc	#0x00
	sta	__print_format_PARM_3
	lda	*__print_format_sloc1_1_0
	sta	__print_format_c_1_1
	tst	*__print_format_sloc1_1_0
	bne	00302$
	jmp	00226$
00302$:
;printf_large.c:381: if ( c=='%' )
	lda	__print_format_c_1_1
	cmp	#0x25
	beq	00303$
	jmp	00222$
00303$:
;printf_large.c:383: left_justify    = 0;
;printf_large.c:384: zero_padding    = 0;
;printf_large.c:385: prefix_sign     = 0;
;printf_large.c:386: prefix_space    = 0;
; Peephole 5a   - eliminated redundant clra
	clra
	sta	__print_format_left_justify_1_1
	sta	__print_format_zero_padding_1_1
	sta	__print_format_prefix_sign_1_1
	sta	__print_format_prefix_space_1_1
;printf_large.c:387: signed_argument = 0;
;printf_large.c:388: radix           = 0;
;printf_large.c:389: char_argument   = 0;
;printf_large.c:390: long_argument   = 0;
; Peephole 5a   - eliminated redundant clra
	clra
	sta	__print_format_signed_argument_1_1
	sta	__print_format_radix_1_1
	sta	__print_format_char_argument_1_1
	sta	__print_format_long_argument_1_1
;printf_large.c:391: float_argument  = 0;
;printf_large.c:392: width           = 0;
; Peephole 5c   - eliminated redundant clra
	clra
	sta	__print_format_float_argument_1_1
	sta	__print_format_width_1_1
;printf_large.c:393: decimals        = -1;
	lda	#0xFF
	sta	__print_format_decimals_1_1
;printf_large.c:395: get_conversion_spec:
	lda	__print_format_PARM_3
	sta	*__print_format_sloc0_1_0
	lda	(__print_format_PARM_3 + 1)
	sta	*(__print_format_sloc0_1_0 + 1)
00101$:
;printf_large.c:397: c = *format++;
	ldhx	*__print_format_sloc0_1_0
	lda	,x
	aix	#1
	sta	__print_format_c_1_1
	sthx	*__print_format_sloc0_1_0
	lda	*__print_format_sloc0_1_0
	sta	__print_format_PARM_3
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_PARM_3 + 1)
;printf_large.c:399: if (c=='%') {
	lda	__print_format_c_1_1
	cmp	#0x25
; Peephole 2c	- eliminated jmp
	bne	00103$
00304$:
;printf_large.c:400: output_char(c, p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00306$
	bra	00305$
00306$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	__print_format_c_1_1
	rts
00305$:
	ais	#2
;printf_large.c:401: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00307$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00307$:
;printf_large.c:402: continue;
	jmp	00224$
00103$:
;printf_large.c:405: if (isdigit(c)) {
	lda	__print_format_c_1_1
	jsr	_isdigit
	tsta
; Peephole 2d	- eliminated jmp
	beq	00110$
00308$:
;printf_large.c:406: if (decimals==-1) {
	lda	__print_format_decimals_1_1
	cmp	#0xFF
; Peephole 2c	- eliminated jmp
	bne	00107$
00309$:
;printf_large.c:407: width = 10*width + (c - '0');
	lda	__print_format_width_1_1
	ldx	#0x0A
	mul
	sta	*__print_format_sloc1_1_0
	lda	__print_format_c_1_1
	sub	#0x30
	add	*__print_format_sloc1_1_0
	sta	__print_format_width_1_1
;printf_large.c:408: if (width == 0) {
	lda	__print_format_width_1_1
	cmp	#0x00
	beq	00310$
	jmp	00101$
00310$:
;printf_large.c:410: zero_padding = 1;
	lda	#0x01
	sta	__print_format_zero_padding_1_1
	jmp	00101$
00107$:
;printf_large.c:413: decimals = 10*decimals + (c-'0');
	lda	__print_format_decimals_1_1
	ldx	#0x0A
	mul
	sta	*__print_format_sloc1_1_0
	lda	__print_format_c_1_1
	sub	#0x30
	add	*__print_format_sloc1_1_0
	sta	__print_format_decimals_1_1
;printf_large.c:415: goto get_conversion_spec;
	jmp	00101$
00110$:
;printf_large.c:418: if (c=='.') {
	lda	__print_format_c_1_1
	cmp	#0x2E
; Peephole 2c	- eliminated jmp
	bne	00114$
00311$:
;printf_large.c:419: if (decimals=-1) decimals=0;
	clra
	sta	__print_format_decimals_1_1
;printf_large.c:422: goto get_conversion_spec;
	jmp	00101$
00114$:
;printf_large.c:425: lower_case = islower(c);
	lda	__print_format_c_1_1
	jsr	_islower
	sta	*__print_format_sloc1_1_0
	lda	*__print_format_sloc1_1_0
	sta	_lower_case
;printf_large.c:426: if (lower_case)
	tst	*__print_format_sloc1_1_0
; Peephole 2d	- eliminated jmp
	beq	00116$
00312$:
;printf_large.c:428: c = toupper(c);
	lda	__print_format_c_1_1
	and	#0xDF
	sta	__print_format_c_1_1
00116$:
;printf_large.c:431: switch( c )
	lda	__print_format_c_1_1
	cmp	#0x20
	bne	00313$
	jmp	00119$
00313$:
	lda	__print_format_c_1_1
	cmp	#0x2B
	bne	00314$
	jmp	00118$
00314$:
	lda	__print_format_c_1_1
	cmp	#0x2D
	bne	00315$
	jmp	00117$
00315$:
	lda	__print_format_c_1_1
	cmp	#0x42
	bne	00316$
	jmp	00120$
00316$:
	lda	__print_format_c_1_1
	cmp	#0x43
	bne	00317$
	jmp	00122$
00317$:
	lda	__print_format_c_1_1
	cmp	#0x44
	bne	00318$
	jmp	00147$
00318$:
	lda	__print_format_c_1_1
	cmp	#0x46
	bne	00319$
	jmp	00151$
00319$:
	lda	__print_format_c_1_1
	cmp	#0x49
	bne	00320$
	jmp	00147$
00320$:
	lda	__print_format_c_1_1
	cmp	#0x4C
; Peephole 2d	- eliminated jmp
	beq	00121$
00321$:
	lda	__print_format_c_1_1
	cmp	#0x4F
	bne	00322$
	jmp	00148$
00322$:
	lda	__print_format_c_1_1
	cmp	#0x50
	bne	00323$
	jmp	00142$
00323$:
	lda	__print_format_c_1_1
	cmp	#0x53
	bne	00324$
	jmp	00123$
00324$:
	lda	__print_format_c_1_1
	cmp	#0x55
	bne	00325$
	jmp	00149$
00325$:
	lda	__print_format_c_1_1
	cmp	#0x58
	bne	00326$
	jmp	00150$
00326$:
	jmp	00152$
;printf_large.c:433: case '-':
00117$:
;printf_large.c:434: left_justify = 1;
	lda	#0x01
	sta	__print_format_left_justify_1_1
;printf_large.c:435: goto get_conversion_spec;
	jmp	00101$
;printf_large.c:436: case '+':
00118$:
;printf_large.c:437: prefix_sign = 1;
	lda	#0x01
	sta	__print_format_prefix_sign_1_1
;printf_large.c:438: goto get_conversion_spec;
	jmp	00101$
;printf_large.c:439: case ' ':
00119$:
;printf_large.c:440: prefix_space = 1;
	lda	#0x01
	sta	__print_format_prefix_space_1_1
;printf_large.c:441: goto get_conversion_spec;
	jmp	00101$
;printf_large.c:442: case 'B':
00120$:
;printf_large.c:443: char_argument = 1;
	lda	#0x01
	sta	__print_format_char_argument_1_1
;printf_large.c:444: goto get_conversion_spec;
	jmp	00101$
;printf_large.c:445: case 'L':
00121$:
;printf_large.c:446: long_argument = 1;
	lda	#0x01
	sta	__print_format_long_argument_1_1
;printf_large.c:447: goto get_conversion_spec;
	jmp	00101$
;printf_large.c:449: case 'C':
00122$:
;printf_large.c:450: output_char( va_arg(ap,int), p );
	lda	(__print_format_PARM_4 + 1)
	add	#0x02
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc0_1_0
	lda	*__print_format_sloc0_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc0_1_0 + 1)
	sub	#0x02
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	*__print_format_sloc0_1_0
	sbc	#0x00
	sta	*__print_format_sloc0_1_0
	ldhx	*__print_format_sloc0_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc0_1_0
	lda	,x
	sta	*(__print_format_sloc0_1_0 + 1)
	mov	*(__print_format_sloc0_1_0 + 1),*__print_format_sloc1_1_0
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00328$
	bra	00327$
00328$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	*__print_format_sloc1_1_0
	rts
00327$:
	ais	#2
;printf_large.c:451: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00329$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00329$:
;printf_large.c:452: break;
	jmp	00153$
;printf_large.c:454: case 'S':
00123$:
;printf_large.c:455: PTR = va_arg(ap,ptr_t);
	lda	(__print_format_PARM_4 + 1)
	add	#0x02
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc0_1_0
	lda	*__print_format_sloc0_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc0_1_0 + 1)
	sub	#0x02
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	*__print_format_sloc0_1_0
	sbc	#0x00
	sta	*__print_format_sloc0_1_0
	ldhx	*__print_format_sloc0_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc0_1_0
	lda	,x
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	*__print_format_sloc0_1_0
	sta	_value
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(_value + 1)
;printf_large.c:465: length = strlen(PTR);
	lda	_value
	sta	*__print_format_sloc0_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc0_1_0 + 1)
	ldx	*__print_format_sloc0_1_0
	lda	*(__print_format_sloc0_1_0 + 1)
	jsr	_strlen
	sta	*(__print_format_sloc0_1_0 + 1)
	stx	*__print_format_sloc0_1_0
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	__print_format_length_1_1
;printf_large.c:467: if ( decimals == -1 )
	lda	__print_format_decimals_1_1
	cmp	#0xFF
; Peephole 2c	- eliminated jmp
	bne	00125$
00330$:
;printf_large.c:469: decimals = length;
	lda	__print_format_length_1_1
	sta	__print_format_decimals_1_1
00125$:
;printf_large.c:471: if ( ( !left_justify ) && (length < width) )
	lda	__print_format_left_justify_1_1
	beq	00331$
	jmp	00264$
00331$:
	lda	__print_format_length_1_1
	cmp	__print_format_width_1_1
	bcs	00332$
	jmp	00264$
00332$:
;printf_large.c:473: width -= length;
	lda	__print_format_width_1_1
	sub	__print_format_length_1_1
	sta	__print_format_width_1_1
;printf_large.c:474: while( width-- != 0 )
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc0_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc0_1_0 + 1)
	lda	__print_format_width_1_1
	sta	*__print_format_sloc1_1_0
00126$:
	mov	*__print_format_sloc1_1_0,*__print_format_sloc2_1_0
	dec	*__print_format_sloc1_1_0
	lda	*__print_format_sloc1_1_0
	sta	__print_format_width_1_1
	lda	*__print_format_sloc2_1_0
	cmp	#0x00
	beq	00334$
	clra
	bra	00333$
00334$:
	lda	#0x01
00333$:
	sta	*__print_format_sloc2_1_0
	lda	*__print_format_sloc0_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc2_1_0
; Peephole 2c	- eliminated jmp
	bne	00264$
00335$:
;printf_large.c:476: output_char( ' ', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00337$
	bra	00336$
00337$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x20
	rts
00336$:
	ais	#2
;printf_large.c:477: charsOutputted++;
	ldhx	*__print_format_sloc0_1_0
	aix	#1
	sthx	*__print_format_sloc0_1_0
; Peephole 3	- shortened jmp to bra
	bra	00126$
;printf_large.c:481: while ( *PTR  && (decimals-- > 0))
00264$:
	lda	__print_format_decimals_1_1
	sta	*__print_format_sloc2_1_0
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc0_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc0_1_0 + 1)
00133$:
	lda	_value
	sta	*__print_format_sloc3_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc3_1_0 + 1)
	ldhx	*__print_format_sloc3_1_0
	lda	,x
	bne	00338$
; Peephole 3	- shortened jmp to bra
	bra	00135$
00338$:
	mov	*__print_format_sloc2_1_0,*__print_format_sloc3_1_0
	dec	*__print_format_sloc2_1_0
	lda	*__print_format_sloc3_1_0
	cmp	#0x00
; Peephole 2j	- eliminated bra
	ble	00135$
00339$:
;printf_large.c:483: output_char( *PTR++, p );
	lda	_value
	sta	*__print_format_sloc3_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc3_1_0 + 1)
	ldhx	*__print_format_sloc3_1_0
	aix	#1
	sthx	*__print_format_sloc4_1_0
	lda	*__print_format_sloc4_1_0
	sta	_value
	lda	*(__print_format_sloc4_1_0 + 1)
	sta	(_value + 1)
	ldhx	*__print_format_sloc3_1_0
	lda	,x
	sta	*__print_format_sloc4_1_0
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00341$
	bra	00340$
00341$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	*__print_format_sloc4_1_0
	rts
00340$:
	ais	#2
;printf_large.c:484: charsOutputted++;
	ldhx	*__print_format_sloc0_1_0
	aix	#1
	sthx	*__print_format_sloc0_1_0
	lda	*__print_format_sloc0_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	jmp	00133$
00135$:
;printf_large.c:487: if ( left_justify && (length < width))
	lda	*__print_format_sloc0_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc0_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	lda	__print_format_left_justify_1_1
	bne	00342$
	jmp	00153$
00342$:
	lda	__print_format_length_1_1
	cmp	__print_format_width_1_1
	bcs	00343$
	jmp	00153$
00343$:
;printf_large.c:489: width -= length;
	lda	__print_format_width_1_1
	sub	__print_format_length_1_1
	sta	__print_format_width_1_1
;printf_large.c:490: while( width-- != 0 )
	mov	*__print_format_sloc0_1_0,*__print_format_sloc4_1_0
	mov	*(__print_format_sloc0_1_0 + 1),*(__print_format_sloc4_1_0 + 1)
	lda	__print_format_width_1_1
	sta	*__print_format_sloc3_1_0
00136$:
	mov	*__print_format_sloc3_1_0,*__print_format_sloc2_1_0
	dec	*__print_format_sloc3_1_0
	lda	*__print_format_sloc3_1_0
	sta	__print_format_width_1_1
	lda	*__print_format_sloc2_1_0
	cmp	#0x00
	beq	00345$
	clra
	bra	00344$
00345$:
	lda	#0x01
00344$:
	sta	*__print_format_sloc2_1_0
	lda	*__print_format_sloc4_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc4_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc2_1_0
	beq	00346$
	jmp	00153$
00346$:
;printf_large.c:492: output_char( ' ', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00348$
	bra	00347$
00348$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x20
	rts
00347$:
	ais	#2
;printf_large.c:493: charsOutputted++;
	ldhx	*__print_format_sloc4_1_0
	aix	#1
	sthx	*__print_format_sloc4_1_0
; Peephole 3	- shortened jmp to bra
	bra	00136$
;printf_large.c:498: case 'P':
00142$:
;printf_large.c:499: PTR = va_arg(ap,ptr_t);
	lda	(__print_format_PARM_4 + 1)
	add	#0x02
	sta	*(__print_format_sloc4_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc4_1_0
	lda	*__print_format_sloc4_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc4_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc4_1_0 + 1)
	sub	#0x02
	sta	*(__print_format_sloc4_1_0 + 1)
	lda	*__print_format_sloc4_1_0
	sbc	#0x00
	sta	*__print_format_sloc4_1_0
	ldhx	*__print_format_sloc4_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc4_1_0
	lda	,x
	sta	*(__print_format_sloc4_1_0 + 1)
	lda	*__print_format_sloc4_1_0
	sta	_value
	lda	*(__print_format_sloc4_1_0 + 1)
	sta	(_value + 1)
;printf_large.c:511: output_char( memory_id[(value.byte[2] > 3) ? 4 : value.byte[2]], p );
	lda	(_value + 0x0002)
	cmp	#0x03
; Peephole 2h	- eliminated bra
	bls	00229$
00349$:
	mov	#0x04,*__print_format_sloc4_1_0
; Peephole 3	- shortened jmp to bra
	bra	00230$
00229$:
	lda	(_value + 0x0002)
	sta	*__print_format_sloc4_1_0
00230$:
	ldx	*__print_format_sloc4_1_0
	clrh
	lda	_memory_id,x
	sta	*__print_format_sloc4_1_0
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00351$
	bra	00350$
00351$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	*__print_format_sloc4_1_0
	rts
00350$:
	ais	#2
;printf_large.c:512: output_char(':', p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00353$
	bra	00352$
00353$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x3A
	rts
00352$:
	ais	#2
;printf_large.c:513: output_char('0', p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00355$
	bra	00354$
00355$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x30
	rts
00354$:
	ais	#2
;printf_large.c:514: output_char('x', p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00357$
	bra	00356$
00357$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x78
	rts
00356$:
	ais	#2
;printf_large.c:515: if ((value.byte[2] != 0x00 /* DSEG */) &&
	lda	(_value + 0x0002)
	cmp	#0x00
; Peephole 2d	- eliminated jmp
	beq	00144$
00358$:
;printf_large.c:516: (value.byte[2] != 0x03 /* SSEG */))
	lda	(_value + 0x0002)
	cmp	#0x03
; Peephole 2d	- eliminated jmp
	beq	00144$
00359$:
;printf_large.c:518: OUTPUT_2DIGITS( value.byte[1] );
	lda	(_value + 0x0001)
	jsr	_output_2digits
;printf_large.c:519: charsOutputted += 2;
	lda	(__print_format_charsOutputted_1_1 + 1)
	add	#0x02
	sta	(__print_format_charsOutputted_1_1 + 1)
	bcc	00360$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00360$:
00144$:
;printf_large.c:521: OUTPUT_2DIGITS( value.byte[0] );
	lda	_value
	jsr	_output_2digits
;printf_large.c:522: charsOutputted += 6;
	lda	(__print_format_charsOutputted_1_1 + 1)
	add	#0x06
	sta	(__print_format_charsOutputted_1_1 + 1)
	bcc	00361$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00361$:
;printf_large.c:524: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:527: case 'I':
00147$:
;printf_large.c:528: signed_argument = 1;
	lda	#0x01
	sta	__print_format_signed_argument_1_1
;printf_large.c:529: radix = 10;
	lda	#0x0A
	sta	__print_format_radix_1_1
;printf_large.c:530: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:532: case 'O':
00148$:
;printf_large.c:533: radix = 8;
	lda	#0x08
	sta	__print_format_radix_1_1
;printf_large.c:534: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:536: case 'U':
00149$:
;printf_large.c:537: radix = 10;
	lda	#0x0A
	sta	__print_format_radix_1_1
;printf_large.c:538: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:540: case 'X':
00150$:
;printf_large.c:541: radix = 16;
	lda	#0x10
	sta	__print_format_radix_1_1
;printf_large.c:542: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:544: case 'F':
00151$:
;printf_large.c:545: float_argument=1;
	lda	#0x01
	sta	__print_format_float_argument_1_1
;printf_large.c:546: break;
; Peephole 3	- shortened jmp to bra
	bra	00153$
;printf_large.c:548: default:
00152$:
;printf_large.c:550: output_char( c, p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00363$
	bra	00362$
00363$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	__print_format_c_1_1
	rts
00362$:
	ais	#2
;printf_large.c:551: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00364$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00364$:
;printf_large.c:553: }
00153$:
;printf_large.c:555: if (float_argument) {
	lda	__print_format_float_argument_1_1
	bne	00365$
	jmp	00219$
00365$:
;printf_large.c:556: value.f=va_arg(ap,float);
	lda	(__print_format_PARM_4 + 1)
	add	#0x04
	sta	*(__print_format_sloc4_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc4_1_0
	lda	*__print_format_sloc4_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc4_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc4_1_0 + 1)
	sub	#0x04
	sta	*(__print_format_sloc4_1_0 + 1)
	lda	*__print_format_sloc4_1_0
	sbc	#0x00
	sta	*__print_format_sloc4_1_0
	ldhx	*__print_format_sloc4_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc5_1_0
	lda	,x
	aix	#1
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	,x
	aix	#1
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	,x
	sta	*(__print_format_sloc5_1_0 + 3)
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
;printf_large.c:558: PTR="<NO FLOAT>";
	lda	#>__str_0
	sta	_value
	lda	#__str_0
	sta	(_value + 1)
;printf_large.c:559: while (c=*PTR++)
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc5_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
00154$:
	lda	_value
	sta	*__print_format_sloc4_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc4_1_0 + 1)
	ldhx	*__print_format_sloc4_1_0
	aix	#1
	sthx	*__print_format_sloc3_1_0
	lda	*__print_format_sloc3_1_0
	sta	_value
	lda	*(__print_format_sloc3_1_0 + 1)
	sta	(_value + 1)
	ldhx	*__print_format_sloc4_1_0
	lda	,x
	sta	*__print_format_sloc4_1_0
	lda	*__print_format_sloc4_1_0
	sta	__print_format_c_1_1
	lda	*__print_format_sloc5_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc4_1_0
	bne	00366$
	jmp	00224$
00366$:
;printf_large.c:561: output_char (c, p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00368$
	bra	00367$
00368$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	__print_format_c_1_1
	rts
00367$:
	ais	#2
;printf_large.c:562: charsOutputted++;
	ldhx	*__print_format_sloc5_1_0
	aix	#1
	sthx	*__print_format_sloc5_1_0
; Peephole 3	- shortened jmp to bra
	bra	00154$
00219$:
;printf_large.c:574: } else if (radix != 0)
	lda	__print_format_radix_1_1
	cmp	#0x00
	bne	00369$
	jmp	00224$
00369$:
;printf_large.c:579: unsigned char _AUTOMEM *pstore = &store[5];
	lda	#>(__print_format_store_4_21 + 0x0005)
	sta	__print_format_pstore_4_21
	lda	#(__print_format_store_4_21 + 0x0005)
	sta	(__print_format_pstore_4_21 + 1)
;printf_large.c:582: if (char_argument)
	lda	__print_format_char_argument_1_1
	bne	00370$
	jmp	00165$
00370$:
;printf_large.c:584: value.l = va_arg(ap,char);
	lda	(__print_format_PARM_4 + 1)
	add	#0x01
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc5_1_0 + 1)
	sub	#0x01
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	*__print_format_sloc5_1_0
	sbc	#0x00
	sta	*__print_format_sloc5_1_0
	ldhx	*__print_format_sloc5_1_0
	lda	,x
	sta	*(__print_format_sloc5_1_0 + 3)
	rola	
	clra	
	sbc	#0x00
	sta	*(__print_format_sloc5_1_0 + 2)
	sta	*(__print_format_sloc5_1_0 + 1)
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
;printf_large.c:585: if (!signed_argument)
	lda	__print_format_signed_argument_1_1
	beq	00371$
	jmp	00166$
00371$:
;printf_large.c:587: value.l &= 0xFF;
	lda	_value
	sta	*__print_format_sloc5_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	(_value + 2)
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	(_value + 3)
	sta	*(__print_format_sloc5_1_0 + 3)
	clr	*(__print_format_sloc5_1_0 + 2)
	clr	*(__print_format_sloc5_1_0 + 1)
	clr	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
	jmp	00166$
00165$:
;printf_large.c:590: else if (long_argument)
	lda	__print_format_long_argument_1_1
; Peephole 2d	- eliminated jmp
	beq	00162$
00372$:
;printf_large.c:592: value.l = va_arg(ap,long);
	lda	(__print_format_PARM_4 + 1)
	add	#0x04
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc5_1_0 + 1)
	sub	#0x04
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	*__print_format_sloc5_1_0
	sbc	#0x00
	sta	*__print_format_sloc5_1_0
	ldhx	*__print_format_sloc5_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc5_1_0
	lda	,x
	aix	#1
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	,x
	aix	#1
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	,x
	sta	*(__print_format_sloc5_1_0 + 3)
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
	jmp	00166$
00162$:
;printf_large.c:596: value.l = va_arg(ap,int);
	lda	(__print_format_PARM_4 + 1)
	add	#0x02
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	__print_format_PARM_4
	adc	#0x00
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_PARM_4
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_PARM_4 + 1)
	lda	*(__print_format_sloc5_1_0 + 1)
	sub	#0x02
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	*__print_format_sloc5_1_0
	sbc	#0x00
	sta	*__print_format_sloc5_1_0
	ldhx	*__print_format_sloc5_1_0
	lda	,x
	aix	#1
	sta	*__print_format_sloc5_1_0
	lda	,x
	sta	*(__print_format_sloc5_1_0 + 1)
	mov	*(__print_format_sloc5_1_0 + 1),*(__print_format_sloc5_1_0 + 3)
	mov	*__print_format_sloc5_1_0,*(__print_format_sloc5_1_0 + 2)
	lda	*__print_format_sloc5_1_0
	rola	
	clra	
	sbc	#0x00
	sta	*(__print_format_sloc5_1_0 + 1)
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
;printf_large.c:597: if (!signed_argument)
	lda	__print_format_signed_argument_1_1
; Peephole 2c	- eliminated jmp
	bne	00166$
00373$:
;printf_large.c:599: value.l &= 0xFFFF;
	lda	_value
	sta	*__print_format_sloc5_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	(_value + 2)
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	(_value + 3)
	sta	*(__print_format_sloc5_1_0 + 3)
	clr	*(__print_format_sloc5_1_0 + 1)
	clr	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
00166$:
;printf_large.c:603: if ( signed_argument )
	lda	__print_format_signed_argument_1_1
	bne	00374$
	jmp	00171$
00374$:
;printf_large.c:605: if (value.l < 0)
	lda	_value
	sta	*__print_format_sloc5_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	(_value + 2)
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	(_value + 3)
	sta	*(__print_format_sloc5_1_0 + 3)
	lda	*__print_format_sloc5_1_0
	sub	#0x00
; Peephole 2l	- eliminated bra
	bge	00168$
00375$:
;printf_large.c:606: value.l = -value.l;
	lda	_value
	sta	*__print_format_sloc5_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	(_value + 2)
	sta	*(__print_format_sloc5_1_0 + 2)
	lda	(_value + 3)
	sta	*(__print_format_sloc5_1_0 + 3)
	clra
	sub	*(__print_format_sloc5_1_0 + 3)
	sta	*(__print_format_sloc5_1_0 + 3)
	clra
	sbc	*(__print_format_sloc5_1_0 + 2)
	sta	*(__print_format_sloc5_1_0 + 2)
	clra
	sbc	*(__print_format_sloc5_1_0 + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	clra
	sbc	*__print_format_sloc5_1_0
	sta	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	_value
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(_value + 1)
	lda	*(__print_format_sloc5_1_0 + 2)
	sta	(_value + 2)
	lda	*(__print_format_sloc5_1_0 + 3)
	sta	(_value + 3)
; Peephole 3	- shortened jmp to bra
	bra	00171$
00168$:
;printf_large.c:608: signed_argument = 0;
	clra
	sta	__print_format_signed_argument_1_1
00171$:
;printf_large.c:612: lsd = 1;
	lda	#0x01
	sta	__print_format_lsd_1_1
;printf_large.c:614: do {
	lda	__print_format_pstore_4_21
	sta	*__print_format_sloc5_1_0
	lda	(__print_format_pstore_4_21 + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	clr	*__print_format_sloc4_1_0
00175$:
;printf_large.c:615: value.byte[4] = 0;
	clra
	sta	(_value + 0x0004)
;printf_large.c:619: calculate_digit(radix);
	lda	__print_format_radix_1_1
	jsr	_calculate_digit
;printf_large.c:621: if (!lsd)
	lda	__print_format_lsd_1_1
; Peephole 2c	- eliminated jmp
	bne	00173$
00376$:
;printf_large.c:623: *pstore = (value.byte[4] << 4) | (value.byte[4] >> 4) | *pstore;
	lda	(_value + 0x0004)
	nsa
	sta	*__print_format_sloc3_1_0
	ldhx	*__print_format_sloc5_1_0
	lda	,x
	ora	*__print_format_sloc3_1_0
	ldhx	*__print_format_sloc5_1_0
	sta	,x
;printf_large.c:624: pstore--;
	lda	*(__print_format_sloc5_1_0 + 1)
	sub	#0x01
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	*__print_format_sloc5_1_0
	sbc	#0x00
	sta	*__print_format_sloc5_1_0
; Peephole 3	- shortened jmp to bra
	bra	00174$
00173$:
;printf_large.c:628: *pstore = value.byte[4];
	lda	(_value + 0x0004)
	ldhx	*__print_format_sloc5_1_0
	sta	,x
00174$:
;printf_large.c:630: length++;
	inc	*__print_format_sloc4_1_0
	lda	*__print_format_sloc4_1_0
	sta	__print_format_length_1_1
;printf_large.c:631: lsd = !lsd;
	lda	__print_format_lsd_1_1
	beq	00377$
	lda	#0x01
00377$:
	eor	#0x01
	sta	__print_format_lsd_1_1
;printf_large.c:632: } while( value.ul );
	lda	_value
	sta	*__print_format_sloc6_1_0
	lda	(_value + 1)
	sta	*(__print_format_sloc6_1_0 + 1)
	lda	(_value + 2)
	sta	*(__print_format_sloc6_1_0 + 2)
	lda	(_value + 3)
	sta	*(__print_format_sloc6_1_0 + 3)
	lda	*__print_format_sloc5_1_0
	sta	__print_format_pstore_4_21
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_pstore_4_21 + 1)
	lda	*(__print_format_sloc6_1_0 + 3)
	ora	*(__print_format_sloc6_1_0 + 2)
	ora	*(__print_format_sloc6_1_0 + 1)
	ora	*__print_format_sloc6_1_0
	beq	00378$
	jmp	00175$
00378$:
;printf_large.c:634: if (width == 0)
	lda	__print_format_width_1_1
	cmp	#0x00
; Peephole 2c	- eliminated jmp
	bne	00179$
00379$:
;printf_large.c:639: width=1;
	lda	#0x01
	sta	__print_format_width_1_1
00179$:
;printf_large.c:643: if (!zero_padding && !left_justify)
	lda	__print_format_zero_padding_1_1
	beq	00380$
	jmp	00184$
00380$:
	lda	__print_format_left_justify_1_1
	beq	00381$
	jmp	00184$
00381$:
;printf_large.c:645: while ( width > (unsigned char) (length+1) )
	lda	__print_format_length_1_1
	add	#0x01
	sta	*__print_format_sloc6_1_0
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc5_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	__print_format_width_1_1
	sta	*__print_format_sloc4_1_0
00180$:
	lda	*__print_format_sloc4_1_0
	cmp	*__print_format_sloc6_1_0
	bhi	00382$
	clra
	bra	00383$
00382$:
	lda	#0x01
00383$:
	sta	*__print_format_sloc3_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	lda	*__print_format_sloc4_1_0
	sta	__print_format_width_1_1
	tst	*__print_format_sloc3_1_0
; Peephole 2d	- eliminated jmp
	beq	00184$
00384$:
;printf_large.c:647: output_char( ' ', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00386$
	bra	00385$
00386$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x20
	rts
00385$:
	ais	#2
;printf_large.c:648: charsOutputted++;
	ldhx	*__print_format_sloc5_1_0
	aix	#1
	sthx	*__print_format_sloc5_1_0
;printf_large.c:649: width--;
	dec	*__print_format_sloc4_1_0
; Peephole 3	- shortened jmp to bra
	bra	00180$
00184$:
;printf_large.c:653: if (signed_argument) // this now means the original value was negative
	lda	__print_format_signed_argument_1_1
; Peephole 2d	- eliminated jmp
	beq	00194$
00387$:
;printf_large.c:655: output_char( '-', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00389$
	bra	00388$
00389$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x2D
	rts
00388$:
	ais	#2
;printf_large.c:656: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00390$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00390$:
;printf_large.c:658: width--;
	lda	__print_format_width_1_1
	deca
	sta	__print_format_width_1_1
	jmp	00195$
00194$:
;printf_large.c:660: else if (length != 0)
	lda	__print_format_length_1_1
	cmp	#0x00
	bne	00391$
	jmp	00195$
00391$:
;printf_large.c:663: if (prefix_sign)
	lda	__print_format_prefix_sign_1_1
; Peephole 2d	- eliminated jmp
	beq	00189$
00392$:
;printf_large.c:665: output_char( '+', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00394$
	bra	00393$
00394$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x2B
	rts
00393$:
	ais	#2
;printf_large.c:666: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00395$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00395$:
;printf_large.c:668: width--;
	lda	__print_format_width_1_1
	deca
	sta	__print_format_width_1_1
; Peephole 3	- shortened jmp to bra
	bra	00195$
00189$:
;printf_large.c:670: else if (prefix_space)
	lda	__print_format_prefix_space_1_1
; Peephole 2d	- eliminated jmp
	beq	00195$
00396$:
;printf_large.c:672: output_char( ' ', p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00398$
	bra	00397$
00398$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x20
	rts
00397$:
	ais	#2
;printf_large.c:673: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00399$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00399$:
;printf_large.c:675: width--;
	lda	__print_format_width_1_1
	deca
	sta	__print_format_width_1_1
00195$:
;printf_large.c:680: if (!left_justify)
	lda	__print_format_left_justify_1_1
	beq	00400$
	jmp	00203$
00400$:
;printf_large.c:681: while ( width-- > length )
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc6_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc6_1_0 + 1)
	lda	__print_format_width_1_1
	sta	*__print_format_sloc5_1_0
00196$:
	mov	*__print_format_sloc5_1_0,*__print_format_sloc4_1_0
	dec	*__print_format_sloc5_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_width_1_1
	lda	*__print_format_sloc4_1_0
	cmp	__print_format_length_1_1
	bhi	00401$
	clra
	bra	00402$
00401$:
	lda	#0x01
00402$:
	sta	*__print_format_sloc4_1_0
	lda	*__print_format_sloc6_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc6_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc4_1_0
; Peephole 2d	- eliminated jmp
	beq	00299$
00403$:
;printf_large.c:683: output_char( zero_padding ? '0' : ' ', p );
	lda	__print_format_zero_padding_1_1
; Peephole 2d	- eliminated jmp
	beq	00231$
00404$:
	mov	#0x30,*__print_format_sloc4_1_0
; Peephole 3	- shortened jmp to bra
	bra	00232$
00231$:
	mov	#0x20,*__print_format_sloc4_1_0
00232$:
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00406$
	bra	00405$
00406$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	*__print_format_sloc4_1_0
	rts
00405$:
	ais	#2
;printf_large.c:684: charsOutputted++;
	ldhx	*__print_format_sloc6_1_0
	aix	#1
	sthx	*__print_format_sloc6_1_0
; Peephole 3	- shortened jmp to bra
	bra	00196$
00203$:
;printf_large.c:689: if (width > length)
	lda	__print_format_width_1_1
	cmp	__print_format_length_1_1
; Peephole 2h	- eliminated bra
	bls	00200$
00407$:
;printf_large.c:690: width -= length;
	lda	__print_format_width_1_1
	sub	__print_format_length_1_1
	sta	__print_format_width_1_1
; Peephole 3	- shortened jmp to bra
	bra	00299$
00200$:
;printf_large.c:692: width = 0;
	clra
	sta	__print_format_width_1_1
;printf_large.c:696: while( length-- )
00299$:
	lda	__print_format_pstore_4_21
	sta	*__print_format_sloc6_1_0
	lda	(__print_format_pstore_4_21 + 1)
	sta	*(__print_format_sloc6_1_0 + 1)
	lda	__print_format_charsOutputted_1_1
	sta	*__print_format_sloc5_1_0
	lda	(__print_format_charsOutputted_1_1 + 1)
	sta	*(__print_format_sloc5_1_0 + 1)
	lda	__print_format_length_1_1
	sta	*__print_format_sloc4_1_0
00208$:
	mov	*__print_format_sloc4_1_0,*__print_format_sloc3_1_0
	dec	*__print_format_sloc4_1_0
	lda	*__print_format_sloc5_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc5_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc3_1_0
; Peephole 2d	- eliminated jmp
	beq	00210$
00408$:
;printf_large.c:698: lsd = !lsd;
	lda	__print_format_lsd_1_1
	beq	00409$
	lda	#0x01
00409$:
	eor	#0x01
	sta	__print_format_lsd_1_1
;printf_large.c:699: if (!lsd)
	lda	__print_format_lsd_1_1
; Peephole 2c	- eliminated jmp
	bne	00206$
00410$:
;printf_large.c:701: pstore++;
	ldhx	*__print_format_sloc6_1_0
	aix	#1
	sthx	*__print_format_sloc6_1_0
;printf_large.c:702: value.byte[4] = *pstore >> 4;
	ldhx	*__print_format_sloc6_1_0
	lda	,x
	nsa	
	and	#0x0f
	sta	(_value + 0x0004)
; Peephole 3	- shortened jmp to bra
	bra	00207$
00206$:
;printf_large.c:706: value.byte[4] = *pstore & 0x0F;
	ldhx	*__print_format_sloc6_1_0
	lda	,x
	and	#0x0F
	sta	(_value + 0x0004)
00207$:
;printf_large.c:711: output_digit( value.byte[4] );
	lda	(_value + 0x0004)
	jsr	_output_digit
;printf_large.c:713: charsOutputted++;
	ldhx	*__print_format_sloc5_1_0
	aix	#1
	sthx	*__print_format_sloc5_1_0
; Peephole 3	- shortened jmp to bra
	bra	00208$
00210$:
;printf_large.c:715: if (left_justify)
	lda	__print_format_left_justify_1_1
	bne	00411$
	jmp	00224$
00411$:
;printf_large.c:716: while (width-- > 0)
	mov	*__print_format_sloc5_1_0,*__print_format_sloc6_1_0
	mov	*(__print_format_sloc5_1_0 + 1),*(__print_format_sloc6_1_0 + 1)
	lda	__print_format_width_1_1
	sta	*__print_format_sloc5_1_0
00211$:
	mov	*__print_format_sloc5_1_0,*__print_format_sloc4_1_0
	dec	*__print_format_sloc5_1_0
	lda	*__print_format_sloc4_1_0
	cmp	#0x00
	bhi	00412$
	clra
	bra	00413$
00412$:
	lda	#0x01
00413$:
	sta	*__print_format_sloc4_1_0
	lda	*__print_format_sloc6_1_0
	sta	__print_format_charsOutputted_1_1
	lda	*(__print_format_sloc6_1_0 + 1)
	sta	(__print_format_charsOutputted_1_1 + 1)
	tst	*__print_format_sloc4_1_0
	bne	00414$
	jmp	00224$
00414$:
;printf_large.c:718: output_char(' ', p);
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00416$
	bra	00415$
00416$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	#0x20
	rts
00415$:
	ais	#2
;printf_large.c:719: charsOutputted++;
	ldhx	*__print_format_sloc6_1_0
	aix	#1
	sthx	*__print_format_sloc6_1_0
; Peephole 3	- shortened jmp to bra
	bra	00211$
00222$:
;printf_large.c:726: output_char( c, p );
	lda	(_p + 1)
	psha
	lda	_p
	psha
	bsr	00418$
	bra	00417$
00418$:
	lda	(_output_char + 1)
	psha
	lda	_output_char
	psha
	lda	__print_format_c_1_1
	rts
00417$:
	ais	#2
;printf_large.c:727: charsOutputted++;
	lda	(__print_format_charsOutputted_1_1 + 1)
	inca
	sta	(__print_format_charsOutputted_1_1 + 1)
	bne	00419$
	lda	__print_format_charsOutputted_1_1
	inca
	sta	__print_format_charsOutputted_1_1
00419$:
	jmp	00224$
00226$:
;printf_large.c:731: return charsOutputted;
	ldx	__print_format_charsOutputted_1_1
	lda	(__print_format_charsOutputted_1_1 + 1)
00227$:
	rts
	.area CSEG (CODE)
	.area CONST   (CODE)
_memory_id:
	.ascii "IXCP-"
	.db 0x00
__str_0:
	.ascii "<NO FLOAT>"
	.db 0x00
	.area XINIT
