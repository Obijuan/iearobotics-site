;--------------------------------------------------------
; File Created by SDCC : FreeWare ANSI-C Compiler
; Version 2.5.1 #1058 (Jul 15 2005)
; This file generated Fri Jul 15 02:53:56 2005
;--------------------------------------------------------
	.module _strrchr
	.optsdcc -mgbz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _strrchr
;--------------------------------------------------------
;  ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; overlayable items in  ram 
;--------------------------------------------------------
	.area _OVERLAY
;--------------------------------------------------------
; external initialized ram data
;--------------------------------------------------------
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _CODE
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _CODE
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;_strrchr.c:26: char * strrchr (
;	genLabel
;	genFunction
;	---------------------------------
; Function strrchr
; ---------------------------------
_strrchr_start::
_strrchr:
	lda	sp,-4(sp)
;_strrchr.c:31: char * start = string;
;	genAssign
;	AOP_STK for 
;	AOP_STK for _strrchr_start_1_1
	lda	hl,6(sp)
	ld	a,(hl+)
	ld	e,(hl)
	lda	hl,2(sp)
	ld	(hl+),a
	ld	(hl),e
;_strrchr.c:33: while (*string++)                       /* find end of string */
;	genAssign
;	AOP_STK for _strrchr_start_1_1
	dec	hl
	ld	c,(hl)
	inc	hl
	ld	b,(hl)
;	genLabel
00101$:
;	genPointerGet
	ld	a,(bc)
;	genPlus
;	genPlusIncr
	inc	bc
;	genIfx
	or	a,a
	jp	nz,00101$
;_strrchr.c:36: while (--string != start && *string != ch)
;	genAssign
;	AOP_STK for _strrchr__1_0
	lda	hl,0(sp)
	ld	(hl),c
	inc	hl
	ld	(hl),b
;	genLabel
00105$:
;	genMinus
;	AOP_STK for _strrchr__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	dec	de
	dec	hl
	ld	(hl),e
	inc	hl
	ld	(hl),d
;	genCmpEq
;	AOP_STK for _strrchr__1_0
;	AOP_STK for _strrchr_start_1_1
; genCmpEq: left 2, right 2, result 0
	inc	hl
	ld	a,(hl)
	dec	hl
	dec	hl
	cp	(hl)
	jr	nz,00116$
	lda	hl,3(sp)
	ld	a,(hl)
	dec	hl
	dec	hl
	cp	(hl)
	jr	nz,00116$
	jp	00107$
00116$:
;	genPointerGet
;	AOP_STK for _strrchr__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genCmpEq
;	AOP_STK for 
; genCmpEq: left 1, right 1, result 0
	lda	hl,8(sp)
	ld	a,(hl)
	cp	c
	jr	nz,00117$
	jr	00118$
00117$:
	jp	00105$
00118$:
;	genLabel
00107$:
;_strrchr.c:39: if (*string == ch)                /* char found ? */
;	genPointerGet
;	AOP_STK for _strrchr__1_0
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	ld	a,(de)
	ld	c,a
;	genCmpEq
;	AOP_STK for 
; genCmpEq: left 1, right 1, result 0
	lda	hl,8(sp)
	ld	a,(hl)
	cp	c
	jr	nz,00119$
	jr	00120$
00119$:
	jp	00109$
00120$:
;_strrchr.c:40: return( (char *)string );
;	genRet
;	AOP_STK for _strrchr__1_0
; Dump of IC_LEFT: type AOP_STK size 2
;	 aop_stk -4
	lda	hl,0(sp)
	ld	e,(hl)
	inc	hl
	ld	d,(hl)
	jp	00110$
;	genLabel
00109$:
;_strrchr.c:42: return (NULL) ;
;	genRet
; Dump of IC_LEFT: type AOP_LIT size 2
	ld	de,#0x0000
;	genLabel
00110$:
;	genEndFunction
	lda	sp,4(sp)
	ret
_strrchr_end::
	.area _CODE
