;****************************************************************************
;  ledon.asm      Junio-2005                                                *
;---------------------------------------------------------------------------*
; Ejemplo para el skybot                                                    *
; Se carga usando el bootloader                                             *
;---------------------------------------------------------------------------*
;  Encender el led de la Skypic                                             *
;---------------------------------------------------------------------------*
;  Andres Prieto-Moreno <andres@ifara.com>                                  *
;  Juan Gonzalez <juan@iearobotics.com>                                     *
;---------------------------------------------------------------------------*
;  LICENCIA GPL                                                             *
;****************************************************************************

; --- Especificar el PIC a emplear
  LIST P=16F876a
  INCLUDE "p16f876a.inc"

;-- Definiciones
#define LED    1    ; Bit donde esta el led de la Skypic

;---------------------------------
;- Necesario para el Bootloader 
;---------------------------------

   ORG 0
    
   CLRF    0x3
   MOVLW   0  
   MOVWF   0xa
   GOTO    0x4
    
;-------------------------
;- Comienzo del programa 
;-------------------------

;-- Configurar el pin del led para salida
  BSF  STATUS,RP0     ; Cambiar al banco 1
  BCF  TRISB,LED


;-- Encender el led
  BCF STATUS,RP0  ; Cambiar al banco 0
  BSF PORTB,LED   ; Activar led

;-- Bucle infinito  
fin goto fin
 END
