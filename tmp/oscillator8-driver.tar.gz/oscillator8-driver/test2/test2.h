extern void test2_startup(char *configfile);
extern void test2_stop();
extern void test2_suspend();
extern void test2_resume(int father, int *brothers, arbitration fn);
extern void test2_guiresume();
extern void test2_guisuspend();
 
extern int test2_id;    /* schema identifier */
extern int test2_cycle; /* ms */


