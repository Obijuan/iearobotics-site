#include "jde.h"
#include "test2.h"

int finish_flag=0; 

int test2_id=0; 
int test2_brothers[MAX_SCHEMAS];
arbitration test2_callforarbitration;
int test2_cycle=150; 

/*  NULL DRIVER INTERFACE */
/* DRIVER INTERFACE */

/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "oscillator8"
#define DISABLED 0
#define ENABLED  1

typedef struct  {
  int A[8];
  int Phase_ini[8];
  int N[8];
  int state[8];
  int servo_state[8];
} drv_interface;

drv_interface *iface;
/*--------------------------------------------------------------------------*/

void test2_iteration()
{
  int A=30;
  int N=40;
  int PD=-120;
  
  /* Oscillator 3 */
  iface->A[2]=A;
  iface->N[2]=N;
  iface->Phase_ini[2]=0;
  iface->state[2]=ENABLED;
  iface->servo_state[2]=ENABLED;
  
  /* Oscillator 4 */
  iface->A[3]=A;
  iface->N[3]=N;
  iface->Phase_ini[3]=PD;
  iface->state[3]=ENABLED;
  iface->servo_state[3]=ENABLED;
  
}

void test2_suspend()
{
  int i;
  
  pthread_mutex_lock(&(all[test2_id].mymutex));
  put_state(test2_id,slept);
  printf("test2: off\n");
  for (i=0; i<8; i++) {
    iface->state[i]=DISABLED;
    iface->servo_state[i]=DISABLED;
  }
  pthread_mutex_unlock(&(all[test2_id].mymutex));
} 


void test2_resume(int father, int *brothers, arbitration fn)
{
  int i;
 
  pthread_mutex_lock(&(all[test2_id].mymutex));
  /* this schema resumes its execution with no children at all */
  for(i=0;i<MAX_SCHEMAS;i++) all[test2_id].children[i]=FALSE;
 
  all[test2_id].father=father;
  if (brothers!=NULL) {
    for(i=0;i<MAX_SCHEMAS;i++) test2_brothers[i]=-1;
    i=0;
    while(brothers[i]!=-1) {test2_brothers[i]=brothers[i];i++;}
  }
  
  /* Import from null driver */
  iface=myimport(NAME, "interface");
  
  test2_callforarbitration=fn;
  put_state(test2_id,notready);
  printf("test2: on\n");
  
  for (i=0; i<8; i++) {
    iface->state[i]=DISABLED;
    iface->servo_state[i]=ENABLED;
  }
  pthread_cond_signal(&(all[test2_id].condition));
  pthread_mutex_unlock(&(all[test2_id].mymutex));
} 

void *test2_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  for(;finish_flag==0;) {
    pthread_mutex_lock(&(all[test2_id].mymutex));

    if (all[test2_id].state==slept) {
	    pthread_cond_wait(&(all[test2_id].condition),&(all[test2_id].mymutex));
	    pthread_mutex_unlock(&(all[test2_id].mymutex));
	  }
    else {
	    /* check preconditions. For now, preconditions are always satisfied*/
	    if (all[test2_id].state==notready) put_state(test2_id,ready);
      
      /* check brothers and arbitrate. For now this is the only winner */
	    else if (all[test2_id].state==ready) { 
	      put_state(test2_id,winner);
	    }	  
	    else if (all[test2_id].state==winner);

	    if (all[test2_id].state==winner) {
	      /* I'm the winner and must execute my iteration */
	      pthread_mutex_unlock(&(all[test2_id].mymutex));
	      gettimeofday(&a,NULL);
	      test2_iteration();
	      gettimeofday(&b,NULL);  

	      diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	      next = test2_cycle*1000-diff-10000; 
	      if (next>0) 
		      /* discounts 10ms taken by calling usleep itself */
		      usleep(test2_cycle*1000-diff);
	      else { 
		      /* just let this iteration go away. overhead time negligible */
		      printf("time interval violated: test2\n"); 
		      usleep(test2_cycle*1000);
		    }
	    }
	    else {
	      pthread_mutex_unlock(&(all[test2_id].mymutex));
	      usleep(test2_cycle*1000);
	    }
	  }
  }
  
  return NULL;
} 

void test2_stop()
{
  finish_flag=1;
  printf ("test2 close\n");
}

void test2_startup(char *configfile)
{
  printf ("Config file: %s\n",configfile);
  
  pthread_mutex_lock(&(all[test2_id].mymutex));
  myexport("test2","id",&test2_id);
  printf("test2 schema started up\n");
  put_state(test2_id,slept);
  pthread_create(&(all[test2_id].mythread),NULL,test2_thread,NULL);
  pthread_mutex_unlock(&(all[test2_id].mymutex));
}

void test2_guiresume()
{
  printf ("gui_resume\n");
}

void test2_guisuspend()
{
 printf ("gui_suspend\n");
}

