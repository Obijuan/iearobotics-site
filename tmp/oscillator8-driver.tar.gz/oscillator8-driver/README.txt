Instruction for testing the oscillator8 driver 
----------------------------------------

1) Connect a Skypic[1] board to the PC (or another PIC based board)
2) Connect a servo the servos 1 and/or 2
3) Download the firmware to the skypic (servos8 server)
4) Compile the driver and the schemas for testing. Just type make
5) Execute the JDE environment:

$ jde test.conf 
jdec 4.3-svn
Configuration from test.conf
Reading configuration...
graphics_gtk driver loaded (driver 0)
Loading GTK support...
GTK support loaded.
oscillator8 driver loaded (driver 1)
oscillator8 schema loaded (id 0)
oscillator8 driver started up
mastergui schema loaded (id 1)
mastergui schema started up
test1 schema loaded (id 2)
Config file: test.conf
test1 schema started up
test2 schema loaded (id 3)
Config file: test.conf
test2 schema started up
oscillator8 schema resume
Starting cronos...
Starting shell...
jdec$


6) Activate the test1. The servos 1 and 2 begin to oscillate

7) The test2 schema is for the locomotion of the PP modular robot.
   The servos used are 3 and 4.




