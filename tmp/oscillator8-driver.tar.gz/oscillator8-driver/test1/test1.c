#include "jde.h"
#include "test1.h"

int finish_flag=0; 

int test1_id=0; 
int test1_brothers[MAX_SCHEMAS];
arbitration test1_callforarbitration;
int test1_cycle=150; 

/* DRIVER INTERFACE */

/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "oscillator8"
#define DISABLED 0
#define ENABLED  1

typedef struct  {
  int A[8];
  int Phase_ini[8];
  int N[8];
  int state[8];
  int servo_state[8];
} drv_interface;

drv_interface *iface;
/*--------------------------------------------------------------------------*/

void test1_iteration()
{
  
  /* Oscillator 1 */
  iface->A[0]=20;
  iface->N[0]=100;
  iface->Phase_ini[0]=0;
  iface->state[0]=ENABLED;
  iface->servo_state[0]=ENABLED;
  
  /* Oscillator 2 */
  iface->A[1]=45;
  iface->N[1]=60;
  iface->Phase_ini[1]=0;
  iface->state[1]=ENABLED;
  iface->servo_state[1]=ENABLED;
  
}

void test1_suspend()
{
  int i;
  
  pthread_mutex_lock(&(all[test1_id].mymutex));
  put_state(test1_id,slept);
  printf("test1: off\n");
  for (i=0; i<8; i++) {
    iface->state[i]=DISABLED;
    iface->servo_state[i]=DISABLED;
  }
  pthread_mutex_unlock(&(all[test1_id].mymutex));
} 


void test1_resume(int father, int *brothers, arbitration fn)
{
  int i;
 
  pthread_mutex_lock(&(all[test1_id].mymutex));
  /* this schema resumes its execution with no children at all */
  for(i=0;i<MAX_SCHEMAS;i++) all[test1_id].children[i]=FALSE;
 
  all[test1_id].father=father;
  if (brothers!=NULL) {
    for(i=0;i<MAX_SCHEMAS;i++) test1_brothers[i]=-1;
    i=0;
    while(brothers[i]!=-1) {test1_brothers[i]=brothers[i];i++;}
  }
  
  /* Import from null driver */
  iface=myimport(NAME, "interface");
  
  test1_callforarbitration=fn;
  put_state(test1_id,notready);
  printf("test1: on\n");
  
  for (i=0; i<8; i++) {
    iface->state[i]=DISABLED;
    iface->servo_state[i]=ENABLED;
  }
  pthread_cond_signal(&(all[test1_id].condition));
  pthread_mutex_unlock(&(all[test1_id].mymutex));
} 

void *test1_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  for(;finish_flag==0;) {
    pthread_mutex_lock(&(all[test1_id].mymutex));

    if (all[test1_id].state==slept) {
	    pthread_cond_wait(&(all[test1_id].condition),&(all[test1_id].mymutex));
	    pthread_mutex_unlock(&(all[test1_id].mymutex));
	  }
    else {
	    /* check preconditions. For now, preconditions are always satisfied*/
	    if (all[test1_id].state==notready) put_state(test1_id,ready);
      
      /* check brothers and arbitrate. For now this is the only winner */
	    else if (all[test1_id].state==ready) { 
	      put_state(test1_id,winner);
	    }	  
	    else if (all[test1_id].state==winner);

	    if (all[test1_id].state==winner) {
	      /* I'm the winner and must execute my iteration */
	      pthread_mutex_unlock(&(all[test1_id].mymutex));
	      gettimeofday(&a,NULL);
	      test1_iteration();
	      gettimeofday(&b,NULL);  

	      diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	      next = test1_cycle*1000-diff-10000; 
	      if (next>0) 
		      /* discounts 10ms taken by calling usleep itself */
		      usleep(test1_cycle*1000-diff);
	      else { 
		      /* just let this iteration go away. overhead time negligible */
		      printf("time interval violated: test1\n"); 
		      usleep(test1_cycle*1000);
		    }
	    }
	    else {
	      pthread_mutex_unlock(&(all[test1_id].mymutex));
	      usleep(test1_cycle*1000);
	    }
	  }
  }
  
  return NULL;
} 

void test1_stop()
{
  finish_flag=1;
  printf ("test1 close\n");
}

void test1_startup(char *configfile)
{
  printf ("Config file: %s\n",configfile);
  
  pthread_mutex_lock(&(all[test1_id].mymutex));
  myexport("test1","id",&test1_id);
  printf("test1 schema started up\n");
  put_state(test1_id,slept);
  pthread_create(&(all[test1_id].mythread),NULL,test1_thread,NULL);
  pthread_mutex_unlock(&(all[test1_id].mymutex));
}

void test1_guiresume()
{
  printf ("gui_resume\n");
}

void test1_guisuspend()
{
 printf ("gui_suspend\n");
}

