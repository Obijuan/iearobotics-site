extern void test1_startup(char *configfile);
extern void test1_stop();
extern void test1_suspend();
extern void test1_resume(int father, int *brothers, arbitration fn);
extern void test1_guiresume();
extern void test1_guisuspend();
 
extern int test1_id;    /* schema identifier */
extern int test1_cycle; /* ms */


