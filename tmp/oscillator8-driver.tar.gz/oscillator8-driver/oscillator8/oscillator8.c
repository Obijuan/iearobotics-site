/***************************************************************************/
/* JDE driver example.                                                     */
/* It is a driver that controls a 'null actuator' wich only has one input  */
/* variable. It just prints on the screen the value of this input variable */
/* ----------------------------------------------------------------------  */
/* NULL DRIVER API:                                                        */
/*    -value: The actuator input variable                                  */
/***************************************************************************/
#include <stdio.h>
#include <pthread.h>
#include <math.h>
#include "jde.h"
#include "serial.h"

/*-- HEADERS -- */
#define TRAMA_ENA_CAB 0x45
#define TRAMA_POS_CAB 0x57



/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "oscillator8"
#define DISABLED 0
#define ENABLED  1

typedef struct  {
  int A[8];             /* Amplitude     */
  int Phase_ini[8];     /* Initial phase */
  int N[8];             /* Samples       */
  int state[8];         /* Oscillator state: enabled/disabled */
  int servo_state[8];   /* Servo state: enabled/disabled      */
  
} drv_interface;

drv_interface iface;
/*--------------------------------------------------------------------------*/



/* oscillator8 driver main pthread.*/
pthread_t oscillator8_th;

/* oscillator8 driver variable to detect if pthreads must end its execution.*/
int oscillator8_close_command=0;

/* oscillator8 driver state variable for the actuator pthread.*/
int state_actuator;

/* oscillator8 driver mutex for the actuator pthread.*/
pthread_mutex_t mymutex_actuator;

/* oscillator8 driver condition flag for the actuator pthread.*/
pthread_cond_t condition_actuator;

/* 'oscillator8' schema cycle control variable*/
int oscillator8_cycle=30;

/* id for oscillator8 actuator schema.*/
int oscillator8_schema_id;

/* oscillator8 ref counter*/
int oscillator8_refs=0;

/* mutex for ref counters*/
pthread_mutex_t refmutex;

/* Serial port descriptor */
int serial_fd;           

/************************************************/
/* SERIAL COMUNICATIONS                         */
/************************************************/
void sg_oscillator8_pos1(int servo, float pos)
{
	char trama[4];
  int pos2;
  
  pos2 = (int)round(69 + (23.0/30.0)*(float)pos);
  
  /* Construir la trama POS */
  trama[0]=TRAMA_POS_CAB;
	trama[1]=(char)servo;
	trama[2]=(char)pos2;

  /* -- Enviarla al StarGate */
  serial_send(serial_fd, trama,3);
  
}

void sg_oscillator8_enable(int mask)
{
	char trama[3];

  /* Construir la trama ENA */
  trama[0]=TRAMA_ENA_CAB;
	trama[1]=(char)mask;

  /*-- Enviarla al StarGate */
  serial_send(serial_fd, trama,2);
}

/* Entry point: oscillator8 driver function to stop and clean oscillator8 devices */
void oscillator8_close()
{
  oscillator8_close_command=1;
  serial_close(serial_fd);
  printf("driver oscillator8 off\n");
}

/* Entry point: suspend the oscillator8 device */
int oscillator8_suspend()
{
   pthread_mutex_lock(&refmutex);
   if (oscillator8_refs>1){
      oscillator8_refs--;
      pthread_mutex_unlock(&refmutex);
   }
   else{
      oscillator8_refs=0;
      pthread_mutex_unlock(&refmutex);
      
         pthread_mutex_lock(&mymutex_actuator);
         state_actuator=slept;
         put_state(oscillator8_schema_id,slept);
         printf("oscillator8 schema suspend\n");
         sg_oscillator8_enable(0x00);
         pthread_mutex_unlock(&mymutex_actuator);
   }
   return 0;
}

/* Entry point: resume the oscillator8 device */
int oscillator8_resume(int father, int *brothers, arbitration fn)
{
   sg_oscillator8_enable(0xFF);
  
   pthread_mutex_lock(&refmutex);
   if (oscillator8_refs>0){
      oscillator8_refs++;
      pthread_mutex_unlock(&refmutex);
   }
   else{
      oscillator8_refs=1;
      pthread_mutex_unlock(&refmutex);

      pthread_mutex_lock(&mymutex_actuator);
      state_actuator=winner;
      all[oscillator8_schema_id].father = father;
      all[oscillator8_schema_id].fps = 0.;
      all[oscillator8_schema_id].k =0;
      put_state(oscillator8_schema_id,winner);
      printf("oscillator8 schema resume\n");
      pthread_cond_signal(&condition_actuator);
      pthread_mutex_unlock(&mymutex_actuator);
   }
   return 0;
}

/* Perform an interation on the oscillator8 device */
void oscillator8_iteration()
{  
  static int n[8]={0,0,0,0,0,0,0,0};
  static char mask=0;
  static char old_mask=0;
  float pos;
  float Phase_ini;
  int i;
  
  speedcounter(oscillator8_schema_id);
  
  for (i=0; i<8; i++) {
    if (iface.servo_state[i]==DISABLED) 
      mask = mask & ~(1<<i);
    else 
      mask = mask | (1<<i);
  }
  
  if (old_mask!=mask) {
    printf ("ENABLE. Mask: %X, old_mas: %X\n",mask,old_mask);
    sg_oscillator8_enable(mask);
  }
  
  
  for (i=0; i<8; i++) {
    
    if (iface.state[i]==ENABLED) {
      
      /* Phase diference in radians */
      Phase_ini= iface.Phase_ini[i]*M_PI/180;
      pos = (float)iface.A[i]*sin(2*M_PI*n[i]/iface.N[i]+Phase_ini);
    
      sg_oscillator8_pos1(i+1, pos);
      n[i]=(n[i]+1) % iface.N[i];
      
    }  
  }
  
  old_mask=mask;
  
}

/* Nullactuator main thread */
void *oscillator8_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  do{
      
    if (state_actuator==slept) {
	    pthread_mutex_lock(&mymutex_actuator);
	    pthread_cond_wait(&condition_actuator,&mymutex_actuator);
	    pthread_mutex_unlock(&mymutex_actuator);
	  }
	  else  {
	    pthread_mutex_unlock(&mymutex_actuator);
	    gettimeofday(&a,NULL);
	    oscillator8_iteration();
	    gettimeofday(&b,NULL);  
	    diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	    
	    next = oscillator8_cycle*1000-diff-10000; 
	    /* discounts 10ms taken by calling usleep itself */
	    if (next>0) usleep(oscillator8_cycle*1000-diff);
	    else {
	      printf("time interval violated: oscillator8\n");
	      usleep(oscillator8_cycle*1000);
	    }
	  }
      
  }while(oscillator8_close_command==0);

  pthread_exit(0);
}

void oscillator8_init()
{
  /*-- Open the serial port                */
  /*-- The speed is configure at 9600 baud */
  serial_fd=serial_open("/dev/ttyUSB0",B9600);
  
}

/* Entry point: Start the driver and the oscillator8 actuator device */
void oscillator8_startup(char *configfile)
{
  int i;
  
  oscillator8_init();
  
  for (i=0; i<8; i++) {
    iface.N[i]=80;
    iface.A[i]=0;
    iface.Phase_ini[i]=0;
  }
  
  pthread_mutex_lock(&mymutex_actuator);
  state_actuator=slept;
  pthread_create(&oscillator8_th,NULL,oscillator8_thread,NULL);
  pthread_mutex_unlock(&mymutex_actuator);    

  all[num_schemas].id = (int *) &oscillator8_schema_id;
  strcpy(all[num_schemas].name,NAME);
  all[num_schemas].resume = (resumeFn) oscillator8_resume;
  all[num_schemas].suspend = (suspendFn) oscillator8_suspend;
  printf("%s schema loaded (id %d)\n",all[num_schemas].name,num_schemas);
  (*(all[num_schemas].id)) = num_schemas;
  all[num_schemas].fps = 0.;
  all[num_schemas].k =0;
  all[num_schemas].state=slept;
  all[num_schemas].close = NULL;
  all[num_schemas].handle = NULL;
  num_schemas++;
  
  myexport(NAME, "interface", &iface);
  myexport(NAME,"id",&oscillator8_schema_id);
  myexport(NAME,"cycle", &oscillator8_cycle);
  myexport(NAME,"resume",(void *)&oscillator8_resume);
  myexport(NAME,"suspend",(void *)&oscillator8_suspend);

  printf("oscillator8 driver started up\n");
}


