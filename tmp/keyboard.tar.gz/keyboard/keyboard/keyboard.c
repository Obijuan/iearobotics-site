/*
 *  Copyright (C) 2006 José María Cañas Plaza 
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  Authors : José Antonio Santos Cadenas <santoscadenas@gmail.com>
 */

#include "jde.h"
#include "keyboard.h"
#include "graphics_gtk.h"

#include <glade/glade.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>

/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "keyboard"
#define KEY_PRESSED  1
#define KEY_RELEASED 0

typedef struct  {
  unsigned int keycode;
  int key_is_ascii;
  int key_state;
} drv_interface;

drv_interface iface;
/*--------------------------------------------------------------------------*/

#define GLADE_FILE "keyboard.glade"


/* variables necesarias para el funcionamiento */
int keyboard_brothers[MAX_SCHEMAS];
arbitration keyboard_callforarbitration;

registerdisplay myregister_displaycallback;
deletedisplay mydelete_displaycallback;

/*Global variables*/
pthread_mutex_t main_mutex;

/* exported variables */
int keyboard_cycle=40; /* ms */
int keyboard_id=0;

/* GUI Variables */
GladeXML *xml; /*Fichero xml*/
GtkWidget *win; /*Ventana*/

#define MAX_KEYS 20;

typedef struct  {
  int x1,y1;
  int x2,y2;
  unsigned int code;
} key_type;

key_type key[]={
  {-39,-74,-61,-95,'a'}, 
  {-168,-103,-186,-122, 'b'},
  {-111,-103,-131,-122,'c'},
  {-96,-76,-116,-95,'d'},
  
  {-89, -48, -109, -69, 'e'},
  {-123, -75, -144, -95, 'f'},
  {-152,-75,-172,-96,'g'},
  {-180,-74,-200,-94,'h'},
  {-229,-48,-249,-69,'i'},
  {-208,-74,-228,-94,'j'},
  {-236,-74,-255,-95,'k'},
  {-265,-74,-283,-93,'l'},
  {-222,-99,-243,-122,'m'},
  {-193,-101,-213,-122,'n'},
  {-292,-73,-313,-94,'ñ'},
  {-256,-49,-276,-68,'o'},
  {-284,-48,-305,-69,'p'},
  {-33,-49,-54,-69,'q'},
  {-117,-50,-137,-69,'r'},
  {-68,-75,-88,-95,'s'},
  {-146,-50,-165,-68,'t'},
  {-200,-49,-221,-68,'u'},
  {-138,-100,-158,-121,'v'},
  {-62,-49,-83,-69,'w'},
  {-82,-101,-103,-122,'x'},
  {-173,-47,-193,-68,'y'},
  {-55,-101,-75,-121,'z'},
  {-29,-24,-52,-43,'1'},
  {-55,-22,-78,-44,'2'},
  {-84,-23,-103,-43,'3'},
  {-110,-23,-130,-42,'4'},
  {-138,-23,-158,-43,'5'},
  {-166,-20,-185,-41,'6'},
  {-193,-22,-214,-44,'7'},
  {-221,-22,-242,-42,'8'},
  {-249,-21,-269,-44,'9'},
  {-277,-22,-298,-42,'0'},
  {-118,-127,-228,-148,' '},
  {-346,-126,-366,-141,0xFF52}, /* Arriba */
  {-348,-143,-366,-158,0xFF54}, /* Abajo  */
  {-321,-145,-340,-157,0xFF51}, /* Izquierda */
  {-372,-142,-392,-157,0xFF53}, /* Derecha */

};


/*Callbacks*/

gboolean image1_button_release_event(GtkWidget *widget, GdkEvent *event, 
                                   gpointer user)
{
  iface.key_state=KEY_RELEASED;
  /*printf ("But. released\n");*/
}

gboolean image1_button_press_event(GtkWidget *widget, GdkEvent *event, 
                                   gpointer user)
{
  int x,y;
  int keys;
  int i;
  
  //-- Leer coordenadas de pantalla
	x=-(int)event->motion.x;
	y=-(int)event->motion.y;
  
  keys = sizeof(key)/sizeof(key_type);
  
  for (i=0; i<keys; i++) {
    if (x<=key[i].x1 && x>=key[i].x2 && y<=key[i].y1 && y>=key[i].y2) {
      if ((key[i].code&0xFF00)==0xFF00)
        /*printf (" %X" ,key[i].code);*/
        iface.key_is_ascii=1;
      else
        /*printf ("%c",key[i].code&0xFF);*/
        iface.key_is_ascii=0;
        
      break;
    }  
  }
  /*fflush(stdout);*/
  
  iface.keycode=key[i].code;
  iface.key_state=KEY_PRESSED;
  /*printf ("\nx: %d, y: %d",x,y);
  fflush(stdout);*/
  
  return TRUE;
}

gboolean on_keyreleased(GtkWidget *widget, GdkEventKey *event, gpointer user)
{
  /*printf ("Released!\n");*/
  iface.key_state=KEY_RELEASED;
  return TRUE;
}

gboolean on_keypressed(GtkWidget *widget, GdkEventKey *event, gpointer user)
{
  guint keyval;
  
  keyval=event->keyval;
  
  if ((keyval&0xFF00)==0xFF00) {
    /*printf (" %X ",keyval);*/
    iface.key_is_ascii=1;
  }
  else {
    /*printf ("%c",keyval);  */
    iface.key_is_ascii=0;
  }  
    
  /*fflush(stdout);*/
  
  iface.keycode=keyval;
  iface.key_state=KEY_PRESSED;
  
  return TRUE;
}

gboolean on_delete_window (GtkWidget *widget, GdkEvent *event, gpointer user_data){
   gdk_threads_leave();
   keyboard_guisuspend();
   gdk_threads_enter();
   return TRUE;
}

void keyboard_iteration(){
   int i;
   
   speedcounter(keyboard_id);

   pthread_mutex_lock(&main_mutex);
   
   /*printf ("iteration...\n");*/
  
   pthread_mutex_unlock(&main_mutex);
}


/*Importar símbolos*/
void keyboard_imports(){

}

/*Exportar símbolos*/
void keyboard_exports(){
   myexport(NAME, "interface", &iface);
   myexport(NAME, "id", &keyboard_id);
   myexport(NAME,"cycle",&keyboard_cycle);
   myexport(NAME,"resume",(void *)keyboard_resume);
   myexport(NAME,"suspend",(void *)keyboard_suspend);
}

/*Las inicializaciones van en esta parte*/
void keyboard_init(){
   if (myregister_displaycallback==NULL){
      if ((myregister_displaycallback=
           (registerdisplay)myimport ("graphics_gtk",
            "register_displaycallback"))==NULL)
      {
         printf ("I can't fetch register_displaycallback from graphics_gtk\n");
         jdeshutdown(1);
      }
      if ((mydelete_displaycallback=
           (deletedisplay)myimport ("graphics_gtk", "delete_displaycallback"))
           ==NULL)
      {
         printf ("I can't fetch delete_displaycallback from graphics_gtk\n");
         jdeshutdown(1);
      }
   }
}

/*Al suspender el esquema*/
void keyboard_end(){
}

void keyboard_stop(){
}

void keyboard_suspend()
{
  pthread_mutex_lock(&(all[keyboard_id].mymutex));
  put_state(keyboard_id,slept);
  printf("keyboard: off\n");
  pthread_mutex_unlock(&(all[keyboard_id].mymutex));
  keyboard_end();
}


void keyboard_resume(int father, int *brothers, arbitration fn)
{
  int i;
  
  /* update the father incorporating this schema as one of its children */
  if (father!=GUIHUMAN && father!=SHELLHUMAN)
    {
      pthread_mutex_lock(&(all[father].mymutex));
      all[father].children[keyboard_id]=TRUE;
      pthread_mutex_unlock(&(all[father].mymutex));
    }

  pthread_mutex_lock(&(all[keyboard_id].mymutex));
  /* this schema resumes its execution with no children at all */
  for(i=0;i<MAX_SCHEMAS;i++) all[keyboard_id].children[i]=FALSE;
  all[keyboard_id].father=father;
  if (brothers!=NULL)
    {
      for(i=0;i<MAX_SCHEMAS;i++) keyboard_brothers[i]=-1;
      i=0;
      while(brothers[i]!=-1) {keyboard_brothers[i]=brothers[i];i++;}
    }
  keyboard_callforarbitration=fn;
  put_state(keyboard_id,notready);
  printf("keyboard: on\n");
  pthread_cond_signal(&(all[keyboard_id].condition));
  pthread_mutex_unlock(&(all[keyboard_id].mymutex));
  keyboard_imports();
}

void *keyboard_thread(void *not_used)
{
   struct timeval a,b;
   long n=0; /* iteration */
   long next,bb,aa;

   for(;;)
   {
      pthread_mutex_lock(&(all[keyboard_id].mymutex));

      if (all[keyboard_id].state==slept)
      {
	 pthread_cond_wait(&(all[keyboard_id].condition),&(all[keyboard_id].mymutex));
	 pthread_mutex_unlock(&(all[keyboard_id].mymutex));
      }
      else
      {
	 /* check preconditions. For now, preconditions are always satisfied*/
	 if (all[keyboard_id].state==notready)
	    put_state(keyboard_id,ready);
	 /* check brothers and arbitrate. For now this is the only winner */
	 if (all[keyboard_id].state==ready)
	 {put_state(keyboard_id,winner);
	 gettimeofday(&a,NULL);
	 aa=a.tv_sec*1000000+a.tv_usec;
	 n=0;
	 }

	 if (all[keyboard_id].state==winner)
	    /* I'm the winner and must execute my iteration */
	 {
	    pthread_mutex_unlock(&(all[keyboard_id].mymutex));
	    /*      gettimeofday(&a,NULL);*/
	    n++;
	    keyboard_iteration();
	    gettimeofday(&b,NULL);
	    bb=b.tv_sec*1000000+b.tv_usec;
	    next=aa+(n+1)*(long)keyboard_cycle*1000-bb;

	    if (next>5000)
	    {
	       usleep(next-5000);
	       /* discounts 5ms taken by calling usleep itself, on average */
	    }
	    else  ;
	 }
	 else
	    /* just let this iteration go away. overhead time negligible */
	 {
	    pthread_mutex_unlock(&(all[keyboard_id].mymutex));
	    usleep(keyboard_cycle*1000);
	 }
      }
   }
}

void keyboard_close()
{
}

void keyboard_startup(char *configfile)
{
  pthread_mutex_lock(&(all[keyboard_id].mymutex));
  printf("keyboard schema started up\n");
  keyboard_exports();
  put_state(keyboard_id,slept);
  pthread_create(&(all[keyboard_id].mythread),NULL,keyboard_thread,NULL);
  pthread_mutex_unlock(&(all[keyboard_id].mymutex));
}

void keyboard_guidisplay(){
   pthread_mutex_lock(&main_mutex);
   
   gdk_threads_enter();
   gdk_threads_leave();
  
   pthread_mutex_unlock(&main_mutex);
}


void keyboard_guisuspend(void){
   mydelete_displaycallback(keyboard_guidisplay);
   if (win!=NULL){
      gdk_threads_enter();
      gtk_widget_hide(win);
      gdk_threads_leave();
   }
   all[keyboard_id].guistate=pending_off;
}

void keyboard_guiresume(void){
   static int cargado=0;
   static pthread_mutex_t keyboard_gui_mutex;

   printf ("GuiRESUME..\n");
  
   keyboard_init();
  
   pthread_mutex_lock(&keyboard_gui_mutex);
   if (!cargado){
      loadglade ld_fn;
      cargado=1;
      pthread_mutex_unlock(&keyboard_gui_mutex);
     
      /*-- Cargar la ventana desde el archivo xml .glade-- */
      gdk_threads_enter();
      if ((ld_fn=(loadglade)myimport("graphics_gtk","load_glade"))==NULL){
         fprintf (stderr,"I can't fetch 'load_glade' from 'graphics_gtk'.\n");
         jdeshutdown(1);
      }
      xml = ld_fn (GLADE_FILE);
      if (xml==NULL){
         fprintf(stderr, "Error al cargar la interfaz gráfica\n");
         jdeshutdown(1);
      }
      win = glade_xml_get_widget(xml, "window");
     
      if (win==NULL){
         fprintf(stderr, "Error al cargar la interfaz gráfica\n");
         jdeshutdown(1);
      }
      else{
         gtk_widget_show(win);
         gtk_widget_queue_draw(GTK_WIDGET(win));
      }
     
      /* Conectar los callback */
      GtkImage *image;
      GtkEventBox *ebox;
      image = (GtkImage *)glade_xml_get_widget(xml, "image1");
      ebox = (GtkEventBox *)glade_xml_get_widget(xml,"eventbox1");
     
      
      g_signal_connect(G_OBJECT(ebox),"button-press-event",
                      G_CALLBACK(image1_button_press_event),NULL);
     
      g_signal_connect(G_OBJECT(ebox),"button-release-event",
                      G_CALLBACK(image1_button_release_event),NULL);
     
      g_signal_connect(G_OBJECT(image), "key-release-event",
                       G_CALLBACK(on_keyreleased), NULL);
     
      g_signal_connect(G_OBJECT(image), "key-press-event",
                       G_CALLBACK(on_keypressed), NULL);
     
                       
      g_signal_connect(G_OBJECT(win), "delete-event",
                       G_CALLBACK(on_delete_window), NULL);
      
     
      gdk_threads_leave();
   }
   else{
      pthread_mutex_unlock(&keyboard_gui_mutex);
      gdk_threads_enter();
      gtk_widget_show(win);
      gtk_widget_queue_draw(GTK_WIDGET(win));
      gdk_threads_leave();
   }

   myregister_displaycallback(keyboard_guidisplay);
   all[keyboard_id].guistate=pending_on;
}

