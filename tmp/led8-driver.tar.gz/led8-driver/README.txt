Instruction for testing the led8 driver 
----------------------------------------

1) Connect a Skypic[1] board to the PC (or another PIC based board)
2) Connect 8 leds to the PORT B (for example the freeleds board[2])
3) Download the firmware[3] to the skypic
4) Compile the driver8 and the schemas for testing. Just type make
5) Execute the JDE environment:

$ jde test.conf 
jdec 4.3-svn
Configuration from test.conf
Reading configuration...
graphics_gtk driver loaded (driver 0)
Loading GTK support...
GTK support loaded.
led8 driver loaded (driver 1)
led8 schema loaded (id 0)
led8 driver started up
mastergui schema loaded (id 1)
mastergui schema started up
counter schema loaded (id 2)
Config file: test.conf
counter schema started up
krider schema loaded (id 3)
Config file: test.conf
krider schema started up
led8actuator schema resume
Starting cronos...
Starting shell...
jdec$


6) Activate the krider schema. The leds star blinking 
   (like in the knight rider tv show)

7) counter is another squema example. The leds are turn into a binary counter.




