/***************************************************************************/
/* JDE driver example.                                                     */
/* It is a driver that controls a 'null actuator' wich only has one input  */
/* variable. It just prints on the screen the value of this input variable */
/* ----------------------------------------------------------------------  */
/* NULL DRIVER API:                                                        */
/*    -value: The actuator input variable                                  */
/***************************************************************************/
#include <stdio.h>
#include <pthread.h>
#include "jde.h"
#include "serial.h"


/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "led8"

typedef struct  {
  char value;     /* The actuator input variable */
} drv_interface;

drv_interface interface;
/*--------------------------------------------------------------------------*/

/* led8 driver main pthread.*/
pthread_t led8_th;

/* led8 driver variable to detect if pthreads must end its execution.*/
int led8_close_command=0;

/* led8 driver state variable for the actuator pthread.*/
int state_actuator;

/* led8 driver mutex for the actuator pthread.*/
pthread_mutex_t mymutex_actuator;

/* led8 driver condition flag for the actuator pthread.*/
pthread_cond_t condition_actuator;

/* 'led8actuator' schema cycle control variable*/
int led8actuator_cycle=50;

/* id for led8 actuator schema.*/
int led8actuator_schema_id;

/* led8actuator ref counter*/
int led8actuator_refs=0;

/* mutex for ref counters*/
pthread_mutex_t refmutex;

/* Serial port descriptor */
int serial_fd;           

/* Entry point: led8 driver function to stop and clean led8 devices */
void led8_close()
{
  led8_close_command=1;
  serial_close(serial_fd);
  printf("driver led8 off\n");
}

/* Entry point: suspend the led8actuator device */
int led8actuator_suspend()
{
   pthread_mutex_lock(&refmutex);
   if (led8actuator_refs>1){
      led8actuator_refs--;
      pthread_mutex_unlock(&refmutex);
   }
   else{
      led8actuator_refs=0;
      pthread_mutex_unlock(&refmutex);
      
         pthread_mutex_lock(&mymutex_actuator);
         state_actuator=slept;
         put_state(led8actuator_schema_id,slept);
         printf("led8actuator schema suspend\n");
         pthread_mutex_unlock(&mymutex_actuator);
   }
   return 0;
}

/* Entry point: resume the led8actuator device */
int led8actuator_resume(int father, int *brothers, arbitration fn)
{
   pthread_mutex_lock(&refmutex);
   if (led8actuator_refs>0){
      led8actuator_refs++;
      pthread_mutex_unlock(&refmutex);
   }
   else{
      led8actuator_refs=1;
      pthread_mutex_unlock(&refmutex);

      pthread_mutex_lock(&mymutex_actuator);
      state_actuator=winner;
      all[led8actuator_schema_id].father = father;
      all[led8actuator_schema_id].fps = 0.;
      all[led8actuator_schema_id].k =0;
      put_state(led8actuator_schema_id,winner);
      printf("led8actuator schema resume\n");
      pthread_cond_signal(&condition_actuator);
      pthread_mutex_unlock(&mymutex_actuator);
   }
   return 0;
}

/* Perform an interation on the led8actuator device */
void led8actuator_iteration()
{  
  static char old_value=0;
  char msg[2];
  
  speedcounter(led8actuator_schema_id);
  
  /* Print the actuador input variable */
  /* Only if it has changed!           */
  if (interface.value!=old_value) {
    msg[0]=interface.value;
    printf("ECO: car: %02X\n",(unsigned char)interface.value);
    //-- Send the command to the serial port
    serial_send(serial_fd, msg, 1);
  }  
  
  old_value=interface.value;
}

/* Nullactuator main thread */
void *led8actuator_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  do{
      
    if (state_actuator==slept) {
	    pthread_mutex_lock(&mymutex_actuator);
	    pthread_cond_wait(&condition_actuator,&mymutex_actuator);
	    pthread_mutex_unlock(&mymutex_actuator);
	  }
	  else  {
	    pthread_mutex_unlock(&mymutex_actuator);
	    gettimeofday(&a,NULL);
	    led8actuator_iteration();
	    gettimeofday(&b,NULL);  
	    diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	    
	    next = led8actuator_cycle*1000-diff-10000; 
	    /* discounts 10ms taken by calling usleep itself */
	    if (next>0) usleep(led8actuator_cycle*1000-diff);
	    else {
	      printf("time interval violated: led8actuator\n");
	      usleep(led8actuator_cycle*1000);
	    }
	  }
      
  }while(led8_close_command==0);

  pthread_exit(0);
}

void led8_init()
{
  /*-- Open the serial port                */
  /*-- The speed is configure at 9600 baud */
  serial_fd=serial_open("/dev/ttyUSB0",B9600);
  
}

/* Entry point: Start the driver and the led8 actuator device */
void led8_startup(char *configfile)
{
  led8_init();
  interface.value=0;
  serial_send(serial_fd, "\0", 1);
  
  pthread_mutex_lock(&mymutex_actuator);
  state_actuator=slept;
  pthread_create(&led8_th,NULL,led8actuator_thread,NULL);
  pthread_mutex_unlock(&mymutex_actuator);    

  all[num_schemas].id = (int *) &led8actuator_schema_id;
  strcpy(all[num_schemas].name,NAME);
  all[num_schemas].resume = (resumeFn) led8actuator_resume;
  all[num_schemas].suspend = (suspendFn) led8actuator_suspend;
  printf("%s schema loaded (id %d)\n",all[num_schemas].name,num_schemas);
  (*(all[num_schemas].id)) = num_schemas;
  all[num_schemas].fps = 0.;
  all[num_schemas].k =0;
  all[num_schemas].state=slept;
  all[num_schemas].close = NULL;
  all[num_schemas].handle = NULL;
  num_schemas++;
  
  myexport(NAME, "interface", &interface);
  myexport(NAME,"id",&led8actuator_schema_id);
  myexport(NAME,"cycle", &led8actuator_cycle);
  myexport(NAME,"resume",(void *)&led8actuator_resume);
  myexport(NAME,"suspend",(void *)&led8actuator_suspend);

  printf("led8 driver started up\n");
}


