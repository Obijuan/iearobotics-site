#include "jde.h"
#include "krider.h"

int finish_flag=0; 

int krider_id=0; 
int krider_brothers[MAX_SCHEMAS];
arbitration krider_callforarbitration;
int krider_cycle=150; /* ms */ 

/*  NULL DRIVER INTERFACE */
/* DRIVER INTERFACE */

/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "led8"

typedef struct  {
  char value;     /* The actuator input variable */
} drv_interface;

drv_interface *interface;
/*--------------------------------------------------------------------------*/

void krider_iteration()
{
  static char seq[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,
                     0x40,0x20,0x10,0x08,0x04,0x02};
  static int n=0;
  int size;
    
  size=sizeof(seq)/sizeof(char);
  interface->value = seq[n];
  n = (n+1) % size;
  
}

void krider_suspend()
{
  pthread_mutex_lock(&(all[krider_id].mymutex));
  put_state(krider_id,slept);
  printf("krider: off\n");
  pthread_mutex_unlock(&(all[krider_id].mymutex));
} 


void krider_resume(int father, int *brothers, arbitration fn)
{
  int i;
 
  pthread_mutex_lock(&(all[krider_id].mymutex));
  /* this schema resumes its execution with no children at all */
  for(i=0;i<MAX_SCHEMAS;i++) all[krider_id].children[i]=FALSE;
 
  all[krider_id].father=father;
  if (brothers!=NULL) {
    for(i=0;i<MAX_SCHEMAS;i++) krider_brothers[i]=-1;
    i=0;
    while(brothers[i]!=-1) {krider_brothers[i]=brothers[i];i++;}
  }
  
  /* Import from null driver */
  interface=myimport(NAME, "interface");
  
  krider_callforarbitration=fn;
  put_state(krider_id,notready);
  printf("krider: on\n");
  pthread_cond_signal(&(all[krider_id].condition));
  pthread_mutex_unlock(&(all[krider_id].mymutex));
} 

void *krider_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  for(;finish_flag==0;) {
    pthread_mutex_lock(&(all[krider_id].mymutex));

    if (all[krider_id].state==slept) {
	    pthread_cond_wait(&(all[krider_id].condition),&(all[krider_id].mymutex));
	    pthread_mutex_unlock(&(all[krider_id].mymutex));
	  }
    else {
	    /* check preconditions. For now, preconditions are always satisfied*/
	    if (all[krider_id].state==notready) put_state(krider_id,ready);
      
      /* check brothers and arbitrate. For now this is the only winner */
	    else if (all[krider_id].state==ready) { 
	      put_state(krider_id,winner);
	    }	  
	    else if (all[krider_id].state==winner);

	    if (all[krider_id].state==winner) {
	      /* I'm the winner and must execute my iteration */
	      pthread_mutex_unlock(&(all[krider_id].mymutex));
	      gettimeofday(&a,NULL);
	      krider_iteration();
	      gettimeofday(&b,NULL);  

	      diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	      next = krider_cycle*1000-diff-10000; 
	      if (next>0) 
		      /* discounts 10ms taken by calling usleep itself */
		      usleep(krider_cycle*1000-diff);
	      else { 
		      /* just let this iteration go away. overhead time negligible */
		      printf("time interval violated: krider\n"); 
		      usleep(krider_cycle*1000);
		    }
	    }
	    else {
	      pthread_mutex_unlock(&(all[krider_id].mymutex));
	      usleep(krider_cycle*1000);
	    }
	  }
  }
  
  return NULL;
} 

void krider_stop()
{
  finish_flag=1;
  printf ("krider close\n");
}

void krider_startup(char *configfile)
{
  printf ("Config file: %s\n",configfile);
  
  pthread_mutex_lock(&(all[krider_id].mymutex));
  myexport("krider","id",&krider_id);
  printf("krider schema started up\n");
  put_state(krider_id,slept);
  pthread_create(&(all[krider_id].mythread),NULL,krider_thread,NULL);
  pthread_mutex_unlock(&(all[krider_id].mymutex));
}

void krider_guiresume()
{
  printf ("gui_resume\n");
}

void krider_guisuspend()
{
 printf ("gui_suspend\n");
}

