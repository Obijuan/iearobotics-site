extern void krider_startup(char *configfile);
extern void krider_stop();
extern void krider_suspend();
extern void krider_resume(int father, int *brothers, arbitration fn);
extern void krider_guiresume();
extern void krider_guisuspend();
 
extern int krider_id;    /* schema identifier */
extern int krider_cycle; /* ms */


