#include "jde.h"
#include "counter.h"

int finish_flag=0; 

int counter_id=0; 
int counter_brothers[MAX_SCHEMAS];
arbitration counter_callforarbitration;
int counter_cycle=150; /* ms */ 

/*  NULL DRIVER INTERFACE */
/* DRIVER INTERFACE */

/* ----------------------------- DRIVER INTERFACE ------------------------- */
#define NAME "led8"

typedef struct  {
  char value;     /* The actuator input variable */
} drv_interface;

drv_interface *interface;
/*--------------------------------------------------------------------------*/

void counter_iteration()
{
  interface->value = (interface->value + 1) & 0xFF;
}

void counter_suspend()
{
  pthread_mutex_lock(&(all[counter_id].mymutex));
  put_state(counter_id,slept);
  printf("counter: off\n");
  pthread_mutex_unlock(&(all[counter_id].mymutex));
} 


void counter_resume(int father, int *brothers, arbitration fn)
{
  int i;
 
  pthread_mutex_lock(&(all[counter_id].mymutex));
  /* this schema resumes its execution with no children at all */
  for(i=0;i<MAX_SCHEMAS;i++) all[counter_id].children[i]=FALSE;
 
  all[counter_id].father=father;
  if (brothers!=NULL) {
    for(i=0;i<MAX_SCHEMAS;i++) counter_brothers[i]=-1;
    i=0;
    while(brothers[i]!=-1) {counter_brothers[i]=brothers[i];i++;}
  }
  
  /* Import from null driver */
  interface=myimport(NAME, "interface");
  
  counter_callforarbitration=fn;
  put_state(counter_id,notready);
  printf("counter: on\n");
  pthread_cond_signal(&(all[counter_id].condition));
  pthread_mutex_unlock(&(all[counter_id].mymutex));
} 

void *counter_thread(void *not_used) 
{
  struct timeval a,b;
  long diff, next;

  for(;finish_flag==0;) {
    pthread_mutex_lock(&(all[counter_id].mymutex));

    if (all[counter_id].state==slept) {
	    pthread_cond_wait(&(all[counter_id].condition),&(all[counter_id].mymutex));
	    pthread_mutex_unlock(&(all[counter_id].mymutex));
	  }
    else {
	    /* check preconditions. For now, preconditions are always satisfied*/
	    if (all[counter_id].state==notready) put_state(counter_id,ready);
      
      /* check brothers and arbitrate. For now this is the only winner */
	    else if (all[counter_id].state==ready) { 
	      put_state(counter_id,winner);
	    }	  
	    else if (all[counter_id].state==winner);

	    if (all[counter_id].state==winner) {
	      /* I'm the winner and must execute my iteration */
	      pthread_mutex_unlock(&(all[counter_id].mymutex));
	      gettimeofday(&a,NULL);
	      counter_iteration();
	      gettimeofday(&b,NULL);  

	      diff = (b.tv_sec-a.tv_sec)*1000000+b.tv_usec-a.tv_usec;
	      next = counter_cycle*1000-diff-10000; 
	      if (next>0) 
		      /* discounts 10ms taken by calling usleep itself */
		      usleep(counter_cycle*1000-diff);
	      else { 
		      /* just let this iteration go away. overhead time negligible */
		      printf("time interval violated: counter\n"); 
		      usleep(counter_cycle*1000);
		    }
	    }
	    else {
	      pthread_mutex_unlock(&(all[counter_id].mymutex));
	      usleep(counter_cycle*1000);
	    }
	  }
  }
  
  return NULL;
} 

void counter_stop()
{
  finish_flag=1;
  printf ("counter close\n");
}

void counter_startup(char *configfile)
{
  printf ("Config file: %s\n",configfile);
  
  pthread_mutex_lock(&(all[counter_id].mymutex));
  myexport("counter","id",&counter_id);
  printf("counter schema started up\n");
  put_state(counter_id,slept);
  pthread_create(&(all[counter_id].mythread),NULL,counter_thread,NULL);
  pthread_mutex_unlock(&(all[counter_id].mymutex));
}

void counter_guiresume()
{
  printf ("gui_resume\n");
}

void counter_guisuspend()
{
 printf ("gui_suspend\n");
}

