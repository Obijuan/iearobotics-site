extern void counter_startup(char *configfile);
extern void counter_stop();
extern void counter_suspend();
extern void counter_resume(int father, int *brothers, arbitration fn);
extern void counter_guiresume();
extern void counter_guisuspend();
 
extern int counter_id;    /* schema identifier */
extern int counter_cycle; /* ms */


